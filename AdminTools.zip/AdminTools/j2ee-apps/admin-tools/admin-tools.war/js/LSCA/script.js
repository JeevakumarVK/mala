/*
 * @Description: This is combined control script for Agilent LCSA site.
 * @Author: Abnish Singh for HCL Agilent team.
*/

//************************ DO NOT MAKE ANY CHANGES BELOW ************************ //
var LSCA = {
	globalAjax : { //----Global Ajax call----//
		doCall : function(config, callback){
			config = config || {};
			config.type = config.type || 'POST';
			config.url = config.url || {};
			config.dataType = config.dataType || 'json';
			config.context = config.context || $('this');
			config.cache = config.cache || false;
			config.data = config.data || {};
			config.target = config.target || {};
		
			if(config.url!='' && config.url!='undefined'){
				$.ajax({ type:config.type, url:config.url, dataType:config.dataType, cache:config.cache, data:config.data }).done(function(data){if

(typeof(callback)==='function' && callback!='undefined')callback({target:config.target,data:data})}).error(function( xhr,err ){ //console.log( "Error:", err ); 

/*console.log("readyState: "+xhr.readyState+"\nstatus: "+xhr.status+"\nresponseText: "+xhr.responseText);*/ });
			}else{
				return 'Call location not defined!'
			}
		}
	},
	GlobalValidate : {//----Global form validation for all type of forms----//
		init : function(options_){
			var gtg=true, flagArr=[], msgArr=[], alrtmsg='',
			vclass = ['required','alpha','alphanum','chkrequired','selectone','email','confirm2']; 
			els = $(options_.target).map(function(){ return $.makeArray(this.elements); });
			els.each(function(i){
				for(c in vclass){
					if($(els[i]).hasClass(vclass[c])){
						gtg = LSCA.GlobalValidate.doValidate.validate(vclass[c],$(els[i]));
						$.each(gtg, function(i,v){if(i===0)msgArr.push(v);if(i===1)flagArr.push(v);})
					}
				}
			});
			$.each(msgArr, function(i,v){ if(v!='')alrtmsg+=v+'</br>'; });
			if(alrtmsg!=''){
				alrtmsg='<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+alrtmsg+'</div>';
				$(document).find('div.errorMessages:eq(0)').hide();
				$(document).find('div.errorMessages:eq(0)').html(alrtmsg);
				$(document).find('div.errorMessages:eq(0)').show();
				$(document).scrollTop($(document).find('div.errorMessages:eq(0)').position('top'));
			}
			return ($.inArray(false,flagArr)==-1)? true : false; 
		},
		doValidate : {
			validate : function(casechk, element){
			var chk = false, msg = element.attr('title'), rspobj=[];
				if(casechk === 'required'){
					if($.trim(element.val())===''){
						msg = msg || 'This field is required.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'alpha'){
					if(/[^a-zA-Z]+$/.test(element.val())){
						msg = msg || 'Please enter alphabets only.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'alphanum'){
					if(/[^a-zA-Z0-9]+$/.test(element.val())){
						msg = msg || 'Please enter alphnumrics only.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'selectone'){
					if(element.val()==''||element.val()==0){
						msg = msg || 'Please select one.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element);chk = true; rspobj.push('',chk);}
				}else if(casechk === 'chkrequired'){
					if(!element.attr('checked')){
						msg = msg || 'This field is required.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'email'){
					if(element.val()!=''){
						var mailarr=element.val(), f=true; mailarr=mailarr.split(',')
						$.each(mailarr,function(i,v){if( !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))) )f=false;});
						if(!f){
							msg = msg || 'Please enter valid email.';
							LSCA.GlobalValidate.showError(element, '');
							chk = false; rspobj.push(msg,chk);
						}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
					}
				}else if(casechk === 'confirm2'){
					var pass1 = element.val(), pass2 = $('.confirm1').val();
					if( pass1 != pass2 || pass1==''){
						msg = msg || 'Confirm password is not same.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}				
				if(element.attr('minchar')!='undefined' || element.attr('minchar')!=''){
					if(element.val().length < parseInt(element.attr('minchar'))){
						msg = msg || 'Please enter minimum '+element.attr('minchar')+' character.';
						LSCA.GlobalValidate.showError(element, '');
						chk = false;  rspobj.push(msg,chk);
					}
				}else{LSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk); }
			return rspobj;		
			}
		},
		showError : function(element, msg){
			msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+msg+'</div>';
			$(element).css('border-color','red');
			if(msg!=''){
				$(document).find('#error-msg-block').html('');
				$(document).find('div.errorMessages:eq(0)').hide();
				$(document).find('div.errorMessages:eq(0)').html(msgui);
				$(document).find('div.errorMessages:eq(0)').show();
			}
		},
		hideError : function(element){
			$(element).css('border-color','');
			$(document).find('div.errorMessages:eq(0)').hide();
		}
	},
	getQueryParam : function(name){ //---- Get query parameter value ----//
	  name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
	  var regexS = "[\\?&]" + name + "=([^&#]*)";
	  var regex = new RegExp(regexS);
	  var results = regex.exec(window.location.search);
	  if(results == null)
		return "";
	  else
		return decodeURIComponent(results[1].replace(/\+/g, " "));
	},
	addRowQO : { //----Quick Order add row----//
		init : function(params_){
			$('#addpart').on('submit', function(e){
				e.preventDefault();
				$('#readyToUseLink').hide();
				var dovalidate = LSCA.GlobalValidate.init({target:'#addpart',action:'submit'});
				valueObj = $(this).serializeArray();
				url = params_.url+'?part_number='+valueObj[0].value+'&qty='+valueObj[1].value;
				if(dovalidate){
					if(valueObj[1].value > 0 && valueObj[1].value < 1000){
						if(LSCA.addRowQO.iteminlist({target:$(params_.target).find('tbody'),data:valueObj}))
						LSCA.globalAjax.doCall({url:url, target:params_.target}, LSCA.addRowQO.parseme);
					}else{
						LSCA.GlobalValidate.showError('', 'Please enter valid quantity.');
						$(".newError").hide();
					}
				}
			});
		},
		parseme: function(response){
			var data = response.data;
			
			if($(document).find(response.target).length>0 && $(response.data).length>0 && data.status.mStatus!=500){
				if(data.header){
					if($(response.target).find('.skyblueTable').length==0){
						tblui = '<div class="errorMessages"></div><table class="skyblueTable"><thead><tr>';
						$.each(data.header, function(i,v){
							tblui += '<th>'+v+'</th>';
						});
						tblui += '<th></th></tr></thead><tbody></tbody>';
						tblui += '</table><div class="btnPanel text-right"><button type="button" class="btn btn-blue">Add To Cart</button></div>';
						$(response.target).html(tblui);
					}
				}
				if(data.rows){
					tblrow = '<tr id="'+data.rows.mPartNumber+'">';
							
						$.each(data.rows, function(i,v){
							tblrow += (i === 'mQty')?	'<td><input type="text" name="'+data.rows.mPartNumber+'" value="'+v+'" /><input type="hidden" name="partNumber" value="'+data.rows.mPartNumber+'" /></td>' : '<td>'+v+'</td>';						
						});
					
					tblrow += ' <td><a href="javascript:void(0);" part-data="'+data.rows.mPartNumber+'" class="remove"></a></td>';
					tblrow += '</tr>';
				}

				$(response.target).find('.skyblueTable tbody').append(tblrow);
				$(response.target).show();
				
				LSCA.addRowQO.showmsg({status:data.status.mStatus,msg:data.status.mStatusMessage,target:response.target});
				LSCA.addRowQO.removeitem({target:$(response.target).find('#'+data.rows.mPartNumber+" a"), parenttarget:response.target});
			}else if(data.status.mStatus===500){
				LSCA.GlobalValidate.showError('', data.status.mStatusMessage);
			}
			window.onbeforeunload = ($(response.target).find('.skyblueTable tbody tr').length>0)? function(){ return 'You will loose quick order data.' } : 

null; console.log($('#promoImages'));
			($(response.target).find('.skyblueTable tbody tr').length>0)? $('#promoImages').hide() : $('#promoImages').show();
		},
		iteminlist : function(options_){
			itemrow = $(options_.target).find('tr#'+options_.data[0].value);
			tqty = parseInt($(itemrow).find('input[type="text"]').val())+parseInt(options_.data[1].value);
			if(itemrow.length > 0){
				(tqty < 1000)? $(itemrow).find('input[type="text"]').val(tqty) : $(".newError").show();
				return false;
			}else{
				$(".newError").hide();
				return true;
			}
		},
		removeitem : function(options_){
			$(options_.target).on('click', function(){ 
				$(this).parents('tr').remove();
				itemcount = $(options_.parenttarget).find('.skyblueTable tbody tr').length;
				if(itemcount < 1){$(options_.parenttarget).hide(); $('#promoImages').show(); window.onbeforeunload = null}
			});
			
		},
		showmsg : function(options_){
			msgui = '<div class="alert alert-dismissable alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+options_.msg+'</div>';
			if(options_.status===300 || options_.status===500){			
				$(options_.target).find('.errorMessages').html(msgui).show();
			}else{
				$(options_.target).find('.errorMessages').hide();
			}
		}
	},
	toolTipFly : {
		init : function(params_){
			$(params_.target).hover(function(){
				$(params_.selector).hide();
				$(params_.selector,this).show();
			})
		}
	},
	addRowRTU : { //----Quick Order add row----//
		init : function(params_){
			$('#addpart-rtu').on('submit', function(e){
				e.preventDefault();
				var dovalidate = LSCA.GlobalValidate.init({target:'#addpart-rtu',action:'submit'});
				valueObj = $(this).serializeArray();
				var pPartNumber = valueObj[0].value.toUpperCase();				
				url = params_.url + '?part_number=' + (pPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[1].value;
				url = url + '&admintools=true';
				if(dovalidate){
					if(valueObj[1].value > 0 && valueObj[1].value < 1000){
						if(LSCA.addRowRTU.iteminlist({target:$(params_.target).find('tbody'),data:valueObj}))
						LSCA.globalAjax.doCall({url:url, target:params_.target}, LSCA.addRowRTU.parseme);
					}else{
						LSCA.GlobalValidate.showError('', 'Please enter valid quantity.');
						$(".newError").hide();
					}
				}
			});
		},
		parseme: function(response){
			var data = response.data;
			
			if(($(document).find(response.target).length>0 && $(response.data).length>0 && data.status.mStatus!=500) || ($('#readyToUseAdmin').val() == "hiddenReadyToUseAdmin" && data.status.mStatus!=500)){
				if(data.header){
					if($(response.target).find('.skyblueTable').length==0){
						tblui = '<div class="errorMessages"></div><table class="skyblueTable"><thead><tr>';
						$.each(data.header, function(i,v){
							tblui += '<th>'+v+'</th>';
						});
						tblui += '<th></th></tr></thead><tbody></tbody>';
						tblui += '</table><div class="btnPanel text-right"><button type="button" class="btn btn-blue">Add To Cart</button></div>';
						$(response.target).html(tblui);
					}
				}
				if(data.rows){
					tblrow = '<tr id="'+data.rows.mPartNumber+'">';
					if ($('#readyToUseAdmin').val() == "hiddenReadyToUseAdmin") {
						tblrow += '<td><input type="hidden" name="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + data.rows.mQty
                                    + '" /><input type="hidden" name="partNumber" value="' + data.rows.mPartNumber + '" />'+ data.rows.mPartNumber +'</td>';
					} 
					tblrow += ' <td><a href="javascript:void(0);" part-data="'+data.rows.mPartNumber+'" class="remove"></a></td>';
					tblrow += '</tr>';
				}

				$(response.target).find('.skyblueTable tbody').append(tblrow);
				$(response.target).show();
				$('#partNumber').val('');
				$('#createSubmit').prop('disabled', false);
				$('#createSubmit').removeClass('btn-disabled-state');
				LSCA.addRowRTU.showmsg({status:data.status.mStatus,msg:data.status.mStatusMessage,target:response.target});
				LSCA.addRowRTU.removeitem({target:$(response.target).find('#'+data.rows.mPartNumber+" a"), parenttarget:response.target});
			}else if(data.status.mStatus===500){
				LSCA.GlobalValidate.showError('', data.status.mStatusMessage);
			}
			window.onbeforeunload = ($(response.target).find('.skyblueTable tbody tr').length>0)? function(){ return 'You will loose quick order data.' } : 

null; console.log($('#promoImages'));
			($(response.target).find('.skyblueTable tbody tr').length>0)? $('#promoImages').hide() : $('#promoImages').show();
			$('#readyToUseLink').hide();
		},
		iteminlist : function(options_){
			itemrow = $(options_.target).find('tr#'+options_.data[0].value.toUpperCase());
			tqty = parseInt($(itemrow).find('input[type="text"]').val())+parseInt(options_.data[1].value);
			if(itemrow.length > 0){
				var existErrorMsg = "<div id='error-messages' class='alert alert-dismissable alert-danger'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>x</button>Part Number "+options_.data[0].value+" is already added to your Ready to Use list.</div>";
				(tqty < 1000)? $(itemrow).find('input[type="text"]').val(tqty) : $(".newError").html('');$(".newError").html(existErrorMsg);$(".newError").show();
				return false;
			}else{
				$(".newError").hide();
				return true;
			}
		},
		removeitem : function(options_){
			/*$(options_.target).on('click', function(){ 
				$(this).parents('tr').remove();
				itemcount = $(options_.parenttarget).find('.skyblueTable tbody tr').length;
				//if(itemcount < 1){$(options_.parenttarget).hide(); $('#promoImages').show(); window.onbeforeunload = null}
				if(itemcount === 0){
					$('#createSubmit').prop('disabled', true);
					$('#createSubmit').addClass('btn-disabled-state');					
				}				
			});*/
			LSCA.triggerRemoveAjaxCall();
			
		},
		showmsg : function(options_){
			msgui = '<div class="alert alert-dismissable alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+options_.msg+'</div>';
			if(options_.status===300 || options_.status===500){			
				$(options_.target).find('.errorMessages').html(msgui).show();
			}else{
				$(options_.target).find('.errorMessages').hide();
			}
		}
	},
	removeRowItem :{ //Remove item row
		init : function(params_){
			if($(document).find('#mainContainer').hasClass(params_.pageid)){
				$(params_.target).find("a.remove").on('click', function(e){
					e.preventDefault();
					LSCA.globalAjax.doCall({url:params_.url+$(this).attr('part-data'), dataType:'html',target:$(this)}, function(data){
						LSCA.removeRowItem.removeItem(data, function(){
							LSCA.prevNextPaginate.init();
							if(params_.callback && typeof(params_.callback)==='function')params_.callback(params_);
						});
					});
				});
			}
		},
		removeItem : function(params_, callback){
			$(params_.target).parents('tr').remove();
			if(callback && typeof(callback)==='function') callback();
		}
	},
	
	favoriteUpdateItem :{ //favorite item update
		init : function(params_){
			if($(document).find('#mainContainer').hasClass(params_.pageid)){				
					$(params_.target).find("a.favorite").on("click", function(){		
						if($("#loginStatus").val()=="false"){
						$(".newAlert").hide();
						if($(this).hasClass("removeFav")){
							LSCA.globalAjax.doCall({url:params_.url+$(this).attr('skuid'), dataType:'html', target:$(this)});
							var pNo = $(this).parents('tr').find('div.partNo').text();
							$(this).removeAttr("skuid").attr("part-data", $.trim(pNo)).addClass("addFav").removeClass("removeFav");
						}
						
						else if($(this).hasClass("addFav")){
							LSCA.globalAjax.doCall({url:params_.url2+$(this).attr('part-data'), dataType:'html', target:$(this)});
							var sId = $(this).parents('tr').find('#skuID').val();
							$(this).removeAttr("part-data").attr("skuid", sId ).addClass("removeFav").removeClass("addFav");
							
						}
						}
						if($("#loginStatus").val()=="true"){							
						$(".newAlert").show();
						}
					});
				}
				
			
		}		
	},		
	buttonClick : function(){
	  $(".btn").each(function(){
			var btnID = $(this).attr('btn-id');
		
			if(typeof btnID != 'undefined' && btnID != '' && btnID != false){
			
				$(this).on('click',function(e){
					e.preventDefault();
					$(document).find('input#'+btnID).click();
					$("#mainContainer.qckOrderUpload").find('input#addToCart').attr("disabled","disabled");
				});
			}
		});
	},
	RadioShowHide : {
		init : function(params_){
			if($(params_.targetEl).attr(params_.elAttr) === 'checked'){
				params_.toggleClass.hide();
				params_.button.show();
			}
			
			if($(params_.targetE2).attr(params_.e2Attr) === 'checked'){
				params_.toggleClass.show();
				params_.button.hide();
			}
		},
		ShowHide : function(option_){
			option_ = option_ || {};
			option_.selector = option_.selector || {};
			option_.target = option_.target || {};
			option_.selector.change(function(){
				if($(this).val() === 'true'){
					option_.target.show();
					option_.button.hide();
				}else{
					option_.target.hide();
					option_.button.show();
				}
			});
		}
	},
	viewMyCatalogAddItem:{	 // ----View My Catalog Add item----//
		init : function(params_) {
			$('#addpartno').on('submit',function(e) {
					e.preventDefault();
						var dovalidate = LSCA.GlobalValidate.init({target : '#addpartno',action : 'submit'});	
						if (dovalidate)  {
							LSCA.imageLoader.init({target:params_.target});
								LSCA.globalAjax.doCall({url : params_.url + $(this).find("#EnterName").val(),target : params_.target}, function(response){
										LSCA.viewMyCatalogAddItem.parseme(response, function(){
											LSCA.removeRowItem.init({pageid:'viewMyCatalog',url : '/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=',target : '#viewCatalog'});
										})
									});
							} else {
								LSCA.GlobalValidate.showError('','Please enter Part No.');
							
						}
					});
		},
		parseme : function(response, callback) {
			var data = response.data; 
			if(!data.errorMessage){
				if ($(document).find(response.target).length > 0) {
					if ($(response.target).find('.skyblueTable').length == 0) {
						tblui = '<table class="skyblueTable">';
						tblui += '<tbody></tbody>';
						tblui += '</table>';
						$(response.target).html(tblui);
					}
					tblrow = '<tr id="' + data.item + '">';
					tblrow += ' <td class="text-center">' + data.item + '</td>';
					tblrow += ' <td><input name="' + data.partNumber + '" type="text" value="" class="qtyTxtbox"/><input name="partNumber" type="hidden" value="' + data.partNumber + '" /></td>';
					tblrow += ' <td>' + data.partNumber + '</td>';	
					tblrow += ' <td>' + data.descripttion + '</td>';
					tblrow += ' <td>' + data.unit + '</td>';
					tblrow += ' <td>' + data.amount + '</td>';
					tblrow += ' <td>' + data.listprice + '</td>';
					tblrow += ' <td>' + data.yourprice + '</td>';
					tblrow += ' <td><a href="javascript:void(0);" part-data="'+ data.skuId + '" class="remove"></a></td>';
					tblrow += '</tr>';
					$(response.target).find('.skyblueTable tbody').append(tblrow);
	
					//LSCA.addRowQO.removeitem({target : $(response.target).find('#' + data.partNumber + " a")});
					if(callback && typeof(callback)=='function') callback();
				}
			}else{
				LSCA.GlobalValidate.showError('',data.errorMessage);
			}

		}
	},
	qckOrderIframe :{
		init:function(params_){
			$(params_.target).click(function(){
				$(params_.selector).css('height','400px');
				var iframeBlk = $(params_.selector).attr('src');
				$(params_.selector).attr('src',iframeBlk);
			});	
		}
	},
	clickShow : function(params_){
		$(params_.target).click(function(){
			$(params_.selector).toggle();
		})
	},	
	prodFilter : {
		init : function(params_){
			if($(document).find('.mainContainer').hasClass(params_.pageId)){
				LSCA.globalAjax.doCall({url:params_.url+'?catId='+$(params_.target).attr('param-data'), target:params_.target},function(options_){
					LSCA.prodFilter.parseData(options_, function(){
						LSCA.prodFilter.addFilter({target:params_.target}, function(){
							LSCA.prodFilter.addAction({target:params_.target});
							LSCA.prodFilter.submitPart(params_);
						});
					});
				});
			}
		},
		parseData : function(params_, callback){
			var data = params_.data, tblui='', dropval = [], dataCnt=0; for(dataObj in data) dataCnt++, vCnt=0, hide='';
			if(dataCnt > 0){
				$.each(data, function(o,k){ 
					if(o === "headerDataVo"){tblui = '<table class="skyblueTable"><thead>'; tpart = 'h';}else{tblui += '<tbody>'; tpart = 'b';}
					$.each(k, function(i,v){ 
						if(tpart === 'h'){for(vObj in v['dynamicFields']) vCnt++; hide = (vCnt > 2)? 'hide ':''; }
						tblui += (tpart==='h')? '<tr><th>QTY</th>':'<tr>';
						$.each(v, function(j,w){
							isdynamic = (j==='dynamicFields')? ' dynamic' : '';
							if(typeof(w)!=='object'){
								if(tpart==='b'){
									if(j==='partNumber'){tblui += '<td><input name="'+w+'" type="text" value="" /><input name="partNumber" type="hidden" value="'+w+'" /></td>';}
									if(j==='productId'){proid = w;}
								}
								if(j!=='skuId' && j!='productId'){
									w = (tpart==='b' && j==='partNumber') ? '<a href="/store/productDetail.jsp?catId='+LSCA.getQueryParam('catId')+'&navAction=push&prodId='+proid+'" >'+w+'</a>' : w;
									hideme = (j === 'description' && hide!='')? hide : '';
									tblui += (tpart==='h')? '<th class="'+hideme+'">'+w+'</th>':'<td class="'+hideme+'">'+w+'</td>';
								}
							}else{
								$.each(w, function(k,x){
									tblui += (tpart==='h')? '<th class="'+isdynamic+'"><ul><li class="dropdown"><span data-toggle="dropdown" class="dropdown-toggle">'+x+'<span class="caret"></span></span></th>' : '<td class="'+isdynamic+'">'+x+'</td>';
								});
							}
						});
						tblui += '</tr>';
					});
					tblui += (tpart==='h')? '</thead>':'</tbody></table>';
				});
				$(document).find(params_.target+' form').prepend(tblui);
				if(callback && typeof(callback)=='function') callback();
			}
		},
		addFilter : function(params_,callback){
			$(params_.target).find('thead th.dynamic').each(function(i,v){
				var valarr = [], menuui = '', list = '';
				if(i!=params_.fltrindex){
					$(params_.target).find('tbody tr:visible').each(function(){
						dynel = $(this).find('td.dynamic').get(i); dynval = $.trim($(dynel).text());
						if(dynval!=''){ if($.inArray(dynval,valarr)==-1)valarr.push(dynval); }
					});
					$.each(valarr, function(j,w){list += '<li>'+w+'</li>';});
					menuui = '<ul class="dropdown-menu drFilter pull-right"><li>All</li>'+list+'</ul>';
					if($(this).find('li.dropdown > ul.dropdown-menu').length < 1){
						$(this).find('li.dropdown').append(menuui);
					}else{
						$(this).find('li.dropdown > ul.dropdown-menu').remove();
						$(this).find('li.dropdown').append(menuui);
					}
				}
			});
			if(callback && typeof(callback)=='function') callback();
		},
		addAction : function(params_){
			$(params_.target).find('thead th.dynamic').each(function(i,v){
				$(this).find('ul.dropdown-menu > li').on('click', function(){
					var fltrval = $(this).text();
					$(params_.target).find('tbody tr').hide();
					$(params_.target).find('tbody tr').each(function(j,w){
						el = ($(this).find('td.dynamic').get(i)); val = $.trim($(el).text());
						if(fltrval == val){
							$(this).show();
						}else if(fltrval == 'All'){
							$(params_.target).find('tbody tr').show();
						}
					});
					LSCA.prodFilter.addFilter({target:params_.target, fltrindex:i}, function(){LSCA.prodFilter.addAction({target:params_.target})})
				});
			});
		},
		submitPart : function(params_){
			$(params_.target).find('.btn').on('click', function(){
				formdata = $(params_.target+' form').serialize();
				LSCA.globalAjax.doCall({url:$(params_.target+' form').attr('action'), dataType:'json', data:formdata}, function(data){
					msgui = (data.data.status === 'success')? '<div class="alert alert-dismissable alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+data.data.message+'</div>' : '<div class="alert alert-dismissable alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+data.data.message+'</div>';
					$(document).find('div.errorMessages:eq(0)').html(msgui).show();
					$(document).find("#cartcount").html("("+data.data.cartCountToUpdate+")");
				});
			});
		}
	},
	filterSavedCart : {
		init : function(params_){
			if($("#mainContainer").hasClass(params_.pageId)){
				$("#filterTable").on('submit',function(e){
					e.preventDefault(); var trindex = [];
					var dovalidate = LSCA.GlobalValidate.init({target:'#filterTable',action:'submit'});
					if(dovalidate){
						$(".skyblueTable").find('tbody tr').each(function(i,v){
							if($("td:eq(1)",this).text() == ($("#EnterName").val())){
								trindex.push(i);
							}
						});
						if(trindex!='undefined' && trindex.length > 0){
							$(params_.selector).find('tbody tr').hide();
							$.each(trindex,function(j,w){
								$(params_.selector).find("tbody tr:eq("+w+")").show();
							});
						}
						else{LSCA.GlobalValidate.showError('', 'Filter Not Found.');}
					}
				});
			}
		}
	},
	reOrderSavedCart : {
		init : function(params_){
			$(params_.target).find('tbody tr').each(function(i,v){$('td:eq(0)', this).text(i+1);});
		}
	},
	cartShowUpdate : function(params_){
		$(params_.target).on('change',function(){
			var txtVal = $(this).val();
			if(/^[0-9]+$/.test(txtVal) && ((txtVal > 0) && (txtVal <= 999))){
				if($(this).parent().find('.btn').hasClass('hide')){
					$(this).parent().find('.btn').removeClass('hide');
					$(".errorMessages").hide();
				}
			}
			else{LSCA.GlobalValidate.showError('', $(this).attr('title'));}
		});
	},
	populateState : {
		init : function(params_){
			$(params_.target).find('.country').on('change', function(){
				LSCA.globalAjax.doCall({url:params_.url+$(this).val(), target:$(params_.target)}, function(data){
					LSCA.populateState.renderState(data);
				});
			});
		},
		renderState : function(params_){
			var valui = '', $statetext = $(params_.target).find('.statetext'), $statelist = $(params_.target).find('.statelist');
			if($(params_.data).length > 0){
				$statetext.hide().attr('disabled','disabled');
				$statelist.removeAttr('disabled');
				$statelist.parent().show();
				$statelist.prev().text('--');
				$(params_.data).each(function(i,v){
					valui += '<option value='+v.code+'>'+v.name+'</option>';
				});
				$(params_.target).find('.statelist').html(valui);
			}else{
				$statelist.attr('disabled','disabled');
				$statelist.parent().hide();
				$statetext.show().removeAttr('disabled');;
			}
		}
	},
	copyBillAddr : function(params_){
		$(params_.target).on('click', function(){
			if($(this).prop('checked')){
				$('#billingaddress').find('#addr').val($('#shippingaddress').find('#address').val());
				$('#billingaddress').find('#addr2').val($('#shippingaddress').find('#address2').val());
				$('#billingaddress').find('#cty').val($('#shippingaddress').find('#city').val());
				$('#billingaddress').find('#zp').val($('#shippingaddress').find('#zip').val());
				$('#billingaddress').find('.country').prev().text($('#shippingaddress').find('.country').prev().text());
				$('#billingaddress').find('.country').html($('#shippingaddress').find('.country').html());
				$('#billingaddress').find('.statelist').prev().text($('#shippingaddress').find('.statelist').prev().text());
				$('#billingaddress').find('.statelist').html($('#shippingaddress').find('.statelist').html());
				$('#billingaddress').find('.statetext').val($('#shippingaddress').find('.statetext').val());
				if($('#shippingaddress').find('.statetext').is(':visible')){
					$('#billingaddress').find('.statelist').attr('disabled','disabled');
					$('#billingaddress').find('.statelist').parent().hide();
					$('#billingaddress').find('.statetext').removeAttr('disabled').show();
				}else{
					$('#billingaddress').find('.statetext').attr('disabled','disabled').hide();
					$('#billingaddress').find('.statelist').removeAttr('disabled');
					$('#billingaddress').find('.statelist').parent().show();
				}
			}
		});
	},
	selectAll : function(params_){
		$(params_.target).click(function(){
			$(this).parents(params_.parent).find("input:checkbox").each(function(){
				if(!$(this).prop("checked")){
					$(this).click();     
					$(this).attr("checked","checked");
				}
			});	
		});
	},	
	CheckUnCheck : function(params_){                
        	$(params_.target).each(function(){
                        var checkAll = $(this).children("tbody").find("input:checkbox").length;
                        var checkedCount = $(this).children("tbody").find("input:checkbox:checked").length;                                                   
	                        if(checkAll==checkedCount){                                                     
	                                 $(this).children("thead").find("input:checkbox").prop("checked", true);
	                                 $(this).children("thead").find("input:checkbox").parents("label").children("span").text("Deselect All");
	                                 $(this).children("thead").find("input:checkbox").parents("span").addClass("checked");
		                			 }
	                        else{                                                                      
	                        		$(this).children("thead").find("input:checkbox").children("thead").find("input:checkbox").prop("checked", false);
	                                $(params_.target).parents("label").children("span").text("Select All");
	                                $(this).children("thead").find("input:checkbox").parents("span").removeClass("checked"); 
	                 				}
	                        $(this).children("thead").find("input:checkbox").on('click', function(){
	                        	var checker = $(this).prop("checked");
	                			if(checker==true){
	                					$(this).parents("label").children("span").text("Deselect All");
	                					$(this).parents("thead").next("tbody").find(":checkbox").prop("checked", true);
	                					$(this).parents("thead").next("tbody").find(":checkbox").parents("span").addClass("checked")
	                				}
	                				else {
	                					$(this).parents("label").children("span").text("Select All")
	                					$(this).parents("thead").next("tbody").find("input:checkbox").parents("span").removeClass("checked")    
	                					$(this).parents("thead").next("tbody").find("input:checkbox").prop("checked", false);
	                					
	                					}
	                		});
	                        
        			});
        		
		},

	
	
	CheckUncheckAll : function(params_){
		/*$(params_.parent).children("tbody").find("input:checkbox").each(function(){
			if(!$(this).prop('checked')){
				$(params_.target).parents("label").children("span").text("Select All")
				$(this).parents("span").removeClass("checked")    
				$("tbody input:checkbox").prop("checked", false);
				return false;
				}
			
			else{
				
				$(params_.target).parents("label").children("span").text("Deselect All");
				$(this).prop("checked", true);
				$(this).parents("span").addClass("checked");
				
			}*/
			
		//$(params_.parent).each(function(){
			/*lengthChk =$(this).children('tbody').find('input:checkbox').length;
			count = 0;
			$(this).children("tbody").find("input:checkbox").each(function(){
				if($(this).is(':checked')){
					count++; 
					if(lengthChk==count){
						console.log("agree");
					}
					else{console.log("not agree");}
				} 
			})
				
		});*/
			
			
			
		//})
		//alert(checkall);
		$(params_.target).on('click', function(){
			var checker = $(this).prop("checked")
			$(this).next("span").html("")
			$(params_.parent).find("input:checkbox").each(function(){
				if(checker==true){
					$(params_.target).parents("label").children("span").text("Deselect All");
					$(this).prop("checked", true);
					$(this).parents("span").addClass("checked")
				}
				else {
					$(params_.target).parents("label").children("span").text("Select All")
					$(this).parents("span").removeClass("checked")    
					$(this).prop("checked", false);
					
					}
			});	
		});
	},
	submitLocale : function(params_){
		$(params_.target).find('a').on('click', function(){
			$("#setLocale").val($(this).attr('data-lang'));
			$("#userCountry_Code").val($(this).attr('countrycode'));
			$(params_.selector).click();
		});
	},
	getQuoteOrder : function(params_){
		if($(".contentSection").hasClass(params_.pageId)){
			LSCA.imageLoader.init({target:params_.selector});
            LSCA.globalAjax.doCall({url:params_.url, data:$("#quoteForm").serialize(), dataType:'HTML', type:'GET'}, function(data){
                  if(data){
                 	 //console.log($("input[name=ordr]:checked").val());
                 	 $(params_.selector).html(data.data);
                 	 $(params_.target).on('click',function(){
                 		var dovalidate = LSCA.GlobalValidate.init({target:'#quoteForm',action:'submit'});
                 		if (dovalidate){
                 		 $(params_.target).off('click');
                 		 LSCA.getQuoteOrder(params_);
                 		}
                 	 });
                 	 LSCA.prevNextPaginate.init();
                  }
            });
		}
	},
	disableDirectorView : function(params_){
		if($(".contentSection").hasClass(params_.pageId) && ($(params_.boolVal) == true)){
			$("#thirtydays,#sixtydays,#nintydays,#df,#dt").attr('disabled','disabled');
		}
	},
	prevNextPaginate : {
		init : function(){
			params_ = {target : '.paginate-simple', limit : 5}; ///--deafult parameters set here--			
			if($(document).find(params_.target).length > 0){
				LSCA.prevNextPaginate.paginate(params_, function(){LSCA.prevNextPaginate.prevnext(params_)});
			}
		},
		paginate : function(params_, callback){
			$target = (typeof params_.target === 'object')? params_.target : $(document).find(params_.target);
			$target.each(function(i,v){
				params_.limit = parseInt($(this).parent('div:eq(0)').nextAll('div').children('table:eq(0)').attr('data-limit')) || params_.limit;
				var limit = params_.limit, showctr = 0, trecord = 0, start=(params_ && params_.start)? params_.start:0;
				if($(this).parent('div:eq(0)').nextAll('div').find('table:eq(0)').length > 0){
					$tbody = $(this).parent('div:eq(0)').nextAll('div').find('table:eq(0)').children('tbody');
					trecord = $tbody.children('tr').length;
					if(trecord < params_.limit) $(this).hide();
					$tbody.children('tr').hide();
					$tbody.children('tr').each(function(i,v){
						if(i >= start){	
							$(this).show();
							if(i === start)$(this).find('td').css('background','url("images/gridRowImg.png") repeat-x scroll left top #D8E1E8');
							showctr++;
						}
						if(showctr === limit)return false;
					});params_.rowlen = trecord; params_.rowbody = $tbody;
					if(callback || typeof callback === "function") callback();
				}else{ $(this).hide(); }
			});
		},
		prevnext : function(params_){
			 var startfrom = 0;
			$('.paginate-simple').find('li a').on('click', function(e){
				e.preventDefault();
				var $rowbody = $(this).parents('.paginate-simple').parent('div:eq(0)').next('div').find('table:eq(0) > tbody');
				var lvisiblerow = $rowbody.children('tr:visible').last().index()+1;
				var rowcount = $rowbody.children('tr').length;
				params_.target = $(this).parent().parent().parent();
				if($(this).hasClass('rScr')){
					if(lvisiblerow < rowcount){
						startfrom = lvisiblerow;
						params_.start = startfrom;
						LSCA.prevNextPaginate.paginate(params_);
					}
				}else if($(this).hasClass('lScr')){
					startfrom = $rowbody.find('tr:visible').first().index()-params_.limit;
					params_.start = startfrom;
					LSCA.prevNextPaginate.paginate(params_);
				}
			});
		}
	},
	clearFields : function(params_){
		$(params_.target).find('input[type=radio]').each(function(){
			$(this).on('click',function(){
				$(params_.target).find('input[type=text]').val("").attr("disabled","disabled").removeClass("required");
				$(this).parents('div').children('input[type=text]').removeAttr("disabled").addClass("required");
			});
		});
	},
	addRowQOStoreland : { //----Storelanding add row----//
		init : function(params_){
			$('#addpartNew').on('submit', function(e){
				e.preventDefault();
				var dovalidate = LSCA.GlobalValidate.init({target:'#addpartNew',action:'submit'});
				valueObj = $(this).serializeArray();
				if(dovalidate){
					if(valueObj[1].value > 0 && valueObj[1].value < 1000){
						if(LSCA.addRowQOStoreland.iteminlist({target:$(params_.target).find('tbody')}))
						LSCA.addRowQOStoreland.parseme();
						
					}else{
						LSCA.GlobalValidate.showError('', 'Please enter valid quantity.');
						$(".newError").hide();
					}
				}
			});
		},
		parseme: function(e){			    
				var partNum = (valueObj[0].value);
				var partQnt= (valueObj[1].value);
				var tabRow = $('.skyblueTable tbody tr').length
				if(tabRow==0){
					tblui = '<table class="skyblueTable">';
					tblui += '<thead><tr><th>Qty</th><th>Part Number</th><th></th></tr></thead>';
					tblui += '<tbody></tbody>';
					tblui += '</table><div class="btnPanel text-right"><button type="button" class="btn btn-blue">Add To Cart</button></div>';
					$("#quickorderWrap").html(tblui);
				}
				tblrow = '<tr id="'+partNum+'">';
				tblrow += ' <td><input name="'+partNum+'" type="text" value="'+partQnt+'"  /></td>';
				tblrow += ' <td>'+partNum+' <input name="partNumber" type="hidden" value="'+partNum+'"/></td>';
				tblrow += ' <td><a href="javascript:void(0);" part-data="'+partNum+'" class="remove"></a></td>';
				tblrow += '</tr>';
				$('.skyblueTable tbody').append(tblrow);
				
				LSCA.addRowQOStoreland.removeitem({target:$('.skyblueTable tbody').find('#'+partNum+" a")});
				LSCA.addRowQOStoreland.submitAddCart({target:'#quickorder2', selector:'#addToCart'} )
			window.onbeforeunload = ($('.skyblueTable tbody tr').length>0)? function(){ return 'You will lose your cart data!' } : 
		null;
			($('.skyblueTable tbody tr').length>0)? $('#promoImages').hide() : $('#promoImages').show();
		},
		iteminlist : function(options_){
			var partNum = (valueObj[0].value);
			itemrow = $(options_.target).find('tr#'+valueObj[0].value);//partNumber is textbox value
			tqty = parseInt($(itemrow).find('input[name="'+partNum+'"]').val())+parseInt(valueObj[1].value);
			if(itemrow.length > 0){
				(tqty < 1000)?(itemrow).find('input[name="'+partNum+'"]').val(tqty): $(".newError").show();
				return false;
			}else{
				$(".newError").hide();
				return true;
			}
		},
		removeitem : function(options_){
			$(options_.target).on('click', function(){ 
				$(this).parents('tr').remove();
				itemcount = $('.skyblueTable tbody tr').length;
				if(itemcount < 1){
					$('.skyblueTable thead').remove(); $('.skyblueTable').next(".btnPanel").remove(); 
					$('#productlist').show(); window.onbeforeunload = null;
				}
			});
			
		},
		submitAddCart : function(params_){
			$(params_.target).find('button.btn-blue').on('click', function(){
				window.onbeforeunload = null;
				$(params_.selector).click();
			});
		}
	},
	editField : function(params_){
		$(params_.target).each(function(){
			$(this).on('click',function(){
				$(params_.grpId).val($(this).attr('id'));
				var getFormId = $(params_.target).parents('#tableBlock').next().next().attr('id');
				switch(getFormId){
					case 'updateGroupInfo' : {
						$(params_.grpName).val($(this).parents('tr').find('td:eq(0)').text());
						$(params_.grpDesc).val($(this).parents('tr').find('td:eq(1)').text());
						break;
					}
					case 'updateGroupId' : {
						$(params_.grpEmail).val($(this).parents('tr').find('td:eq(0)').text());
						var radioVal = $(this).parents('tr').find('td:eq(1)').text();
						$(params_.grpRadio).find('input[type=radio]').removeAttr('checked');
						$(params_.grpRadio).find('input#'+radioVal).prop('checked');
						$("#radioFields").find('input[type=radio]').each(function(){
							if($(this).val() === radioVal){ $(this).attr('checked','checked'); $(this).click(); }
						});
						break;
					}
				}
				$(".btnSave").removeAttr('disabled').focus();
				$(".btnNew").hide();
			});
		});
	},
	deleteField : function(params_){
		$(params_.target).each(function(){
			$(this).on('click',function(){
				$(params_.grpId).val($(this).attr('id'));
				$('#removeItemBtn').click();
			});
		});
	},
	selectReset : {
	  init : function(params_){ //select option resets
			   $('button[type="reset"]').on('click', function(){
				   if($(document).find('form').hasClass(params_.formid)){
					  $('input[type="text"], input[type="number"], input[type="email"]').attr("value", "");
					  $(params_.target).each(function(){					
						var val_ = $(this).find('option:eq(0)').text();		
						$(this).prev("span").text(val_);					
					  });	
				   }
			  });			
		  }
  },
  setSidebar : {
	init : function(params_){
		params_.allproduct = false;
		LSCA.setSidebar.getSidebar(params_, LSCA.setSidebar.allProducts);
	},
	getSidebar : function(params_, callback){
		var url = (params_.allproduct)? '/store/includes/homePage/browseProduct.jsp':'/store/includes/category/browseProducts.jsp?catId='+LSCA.getQueryParam('catId')+'&prodId='+LSCA.getQueryParam('prodId');
		LSCA.imageLoader.init({target:params_.target});
		LSCA.globalAjax.doCall({url:url, dataType:'html', type:'GET'},function(data){
			if (data != null || data != "")  $("#browseCategory").html(data.data);
			if(callback && typeof callback === "function") callback(params_);
			$("#loader").hide();
		});
	},
	allProducts : function(params_){
		$(params_.target).find('h2').on('click', function(e){
			e.preventDefault();
			params_.allproduct = true;
			LSCA.setSidebar.getSidebar(params_);
			$(this).off('click');
		})		
	}	
	
  },
  getCategoryList : {
	  init : function(params_){
		params_.page = params_.page || 1;
		LSCA.getCategoryList.populateList(params_, LSCA.getCategoryList.setPageing);
	  },
	  populateList : function(params_, callback){
		  var page = params_.page; 
		  LSCA.imageLoader.init({target:params_.selector});
		  LSCA.globalAjax.doCall({url:'/store/includes/category/categoryList.jsp',data:{catId:LSCA.getQueryParam('catId'),pageNumber:page}, dataType:'html', type:'GET'},function(data){
			  if (data != null || data != "") {
				$("#categoryList").html(data.data);
			  }
			  if(callback && typeof callback === "function") callback(params_);
		  })		  
	  },
	  setPageing : function(params_){
		  $(params_.target).find('ul.pagination a').on('click', function(e){
			  e.preventDefault();
			  if(params_.page!=parseInt($(this).attr('id'))){
				  params_.page = parseInt($(this).attr('id'));
				  $(this).off('click');
				  LSCA.getCategoryList.populateList(params_, LSCA.getCategoryList.setPageing);
			  }
			  
		  });
		  
	  }
  },
  buttonClick : function(){
	  $(".btn").each(function(){
			var btnID = $(this).attr('btn-id');
			if(typeof btnID != 'undefined' && btnID != '' && btnID != false){
				$(this).on('click',function(e){
					e.preventDefault();
					$(document).find('input#'+btnID).click();
				});
			}
		});
	},
	PrDetailAddToCart : { //----Product Detail Add To Cart----//
			init : function(params_){
				$('#addCart').on('click', function(e){
					e.preventDefault();
					var dovalidate = LSCA.GlobalValidate.init({target:'#PrDetailForm',action:'submit'});
					var cartQty = $('.qtyTxtbox').val();
					if(dovalidate){
						if(cartQty > 0 && cartQty < 1000){
							$('#addToCart').click();							
						}else{
							$(".newError").show();
														
						}
					}
				});
			}
	  },
	promoData : {
		init: function(params_) {
			if($("#mainContainer").hasClass(params_.pageId)){
				LSCA.imageLoader.init({target:params_.selector});
				LSCA.globalAjax.doCall({url:params_.url, type:'GET', dataType:'html'},function(data){
					if (data != null || data != ""){
						$("#promoImages").html(data.data);
						if($("#promoImages ul li").length > 6){
							$("#promoImages ul li:gt(5)").addClass("hide");
							$("#promoImagesView").show();
							LSCA.promoData.showAll(params_);
						}
		            }
				});
			}
		},
		showAll : function(params_){
			$(params_.target).on('click',function(params_){
				$("#promoImagesView").hide();
				$("#promoImages ul li.hide").removeClass("hide");
			});
		}
	},
	requiredOnce : function(params_){
		$(params_.target).on('click',function(e){
			e.preventDefault();
			$('.selectChk, .interestRow').find('input[type=checkbox]').each(function(){
				//console.log($(this).prop('checked'));
				if($(this).prop('checked')){
						//$("#regProfileForm, #updtAreas").submit();
					$("#regProf,#updateAreaofIntr").click();
				}
				else{LSCA.GlobalValidate.showError('', 'Please select at least one Service to complete your profile.');}
			});
		});
	},
	submitForm : function(params_){
		$button = $(params_.form).find('button'), params_.validate=params_.validate || true;
		$button.on('click', function(e){
			e.preventDefault(); window.onbeforeunload = null;
			if(params_.validate){ 
				var dovalidate = LSCA.GlobalValidate.init({target:params_.form, action : 'submit'});
				if(dovalidate)$(params_.target).click();
			}else{
				$(params_.target).click();
			}
		});
	},	
	checkboxReset : function(params_){ //Clear Check Box//
		$('button[type="reset"]').on('click',function(){
			$(params_.selector).find("input:checkbox").each(function(){
			$(this).attr('checked', false).parent("span").removeClass('checked');
			})			
		  })
	},
	formValidate: { //email form validate
		init: function(params_) {
			$(params_.selector).on('click',function() {
				formdata = $(params_.target).serialize();
				var dovalidate = LSCA.GlobalValidate.init({target:params_.target, action : 'submit'}, LSCA.formOptionalRequired.init({selector:'#givenName', ClassName:'email'}));
				
				if (dovalidate)  {
					LSCA.globalAjax.doCall({url :params_.url, dataType:'html',  data:formdata, target : params_.target}, function(data){
						$( "#pageContentDiv" ).html(data.data);	
						if($(params_.target).hasClass("showpopup")){													
						$("#myModal").modal();
						}
					
					});
				}					
			});	
		}
	},
	
 	langShowHide: {
		init: function(params_){
			var divID = $('#langShowHide input[checked]').attr('value');
			$('#langWrap span').hide();
			$('.'+divID).show();
			$(params_.selector).on('click',function() {
			var divID = $(this).attr('value');
			$('#langWrap span').hide()
			$('.emailGreeting, .emailSubject, .emailBody').attr('disabled','disabled');
			$('.'+divID+' .emailGreeting, .'+divID+' .emailSubject, .'+divID+' .emailBody').removeAttr('disabled');
			$('.'+divID).show();
			});
		 }
	 },	 
	 imageLoader :{
		 init: function(params_){
			$(params_.target).prepend("<div id='loader'><img src='../images/loading.gif' alt='Loading...' /></div>"); 
		 }
	 },
	 formOptionalRequired :{ //Form Optional Required // LSCA.formOptionalRequired.init({selector:'#inputEmail1', ClassName:'email'}); 
		 init: function(params_){
			formvalue = $(params_.selector).val();			
			if(!formvalue==""){
			$(params_.selector2).addClass(params_.ClassName);
			}			
			else{$(params_.selector2).removeClass(params_.ClassName);}
		 }
	 },
	 formMakeRequired :{ //Form Optional Required // LSCA.formOptionalRequired.init({selector:'#inputEmail1', ClassName:'email'}); 
		 init: function(params_){
			
			$(params_.selector).addClass(params_.ClassName);
			
			
		 }
	 },
	 
	 NormalFormValidate: { // Normal Form Validate
			init: function(params_){
				$(params_.selector).on('click',function() {
					if($(params_.target).hasClass("btnValueUpdate")){
						var btnValue = ($(this).attr("rel"));
						$("#sendEmail").val($(this).attr("rel"));
					}
					else{}
					formdata = $(params_.target).serialize();
					if($(params_.target).hasClass("OptionalRequired")){
					/* made changes for CR AP-2979 add cancel to OMT */
					var selected = $("input[type='radio'][name='ordStat']:checked");
					/* made changes for AMS-968 */
					if(selected.val()=="6" || selected.val()=="0" || selected.val()=="1" || selected.val()=="2" || selected.val()=="3" || selected.val()=="4"){
						$('#sapOrder').removeAttr("style");
						$("#sapEmail, #sapOrder").removeClass("required");
						$("#sapEmail").addClass("required");
						var dovalidate = LSCA.GlobalValidate.init({target:params_.target});
						$("#sapEmail, #sapOrder").removeClass("required");
					}else{
						var dovalidate = LSCA.GlobalValidate.init({target:params_.target}, LSCA.formOptionalRequired.init({selector:'#sapOrder',  selector2:'.optionalEmail1',  ClassName:'required'}));
						if($(params_.selector).hasClass("sendEmail")){						
						var dovalidate = LSCA.GlobalValidate.init({target:params_.target}, LSCA.formMakeRequired.init({selector:'#sapOrder, #sapEmail',  ClassName:'required'})); 
						}	
						else{
							$("#sapOrder, #sapEmail").removeClass("required");
							var dovalidate = LSCA.GlobalValidate.init({target:params_.target});
						}
					 } //closing of selected condition 
					}					
					else{
					var dovalidate = LSCA.GlobalValidate.init({target:params_.target});
					}
						if (dovalidate){
							$(params_.target2).click();
							//console.log($("#UploadCSV").val());
						}					
				  	});	
				}
			},	
			mouseInOutFormValidate : function(params_){
				$(params_.target).focusout(function() {
				var $this = $(this);
				if($(this).val()!=(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($this.val())))
				{	
					LSCA.GlobalValidate.showError('', $(this).attr("title"));
					//$(this).val("");
				}      
				});
			},
			
	onCheckButtonDisable : function(params_){ //on Check Button Disable
		$(params_.target).on('click',function(){
			var checkValue = ($(this).prop("checked"));
			if(checkValue==true){
				$(params_.selector).removeAttr("disabled");
			}			
			else{
			$(params_.selector).attr('disabled', "disabled")
			}
		});
	},
	webOrderSubmit : function(params_){
			$(params_.target).on('click', function(){
			$(params_.selector).click();
			});
	},
	onClickButtonEnable : function(params_){ //on Click Button and select Enable
		$(params_.target).on('click',function(){
			$(params_.selector).removeAttr("disabled");
			//$(params_.selector2).removeAttr("disabled");
			
			
		});
	},
	selectOptionSelected : {
		init: function(params_){
		$(params_.target).each(function(){
			$(this).on('click',function(){ 
				prdGrpId = $(this).parents("tr").find('.selectValue2').text();
				$("#webOrderDropdowns .selAllWrap .lableSpace").find("span").removeClass("checked");
				$("#webOrderDropdowns .selAllWrap .lableSpace").find("span input[type='checkbox']").removeAttr("checked");
				prdGrpIdS = prdGrpId.split(',')
				$.each(prdGrpIdS, function(i,v){
				$("#webOrderDropdowns .selAllWrap .lableSpace").each(function(){
					x = $.trim($(this).text());	
					if(v == x){
						//console.log($(this))
						$(this).find("span").addClass("checked");
						$(this).find("input[type='checkbox']").prop("checked", "true");
					}
				});
				})
			var routingItemValue = $(this).parents("td").find("#routingItemValue").val();
			$(params_.updateValue1).val($(this).attr('id'));
			$(params_.updateValue2).val(routingItemValue);
				var linkValue = $.trim($(this).parents("tr").find(params_.dataValue).text());
					$(params_.selector).find("option").each(function(){	
						var optionValue = $.trim($(this).text());						
						if(linkValue==optionValue){
						$(this).prop("selected", true);
							if($(params_.selector).prop("disabled")==false){
							var val_ = $(this).text();					
							$(params_.selector).prev("span").text(val_);
						}
					}
				})
			},
			LSCA.onClickButtonEnable({target:'.editSelect', selector:'.btnSave'}),
			LSCA.onCheckButtonDisable({target:'.editSelect', selector:'.btnNew'})
			)
			})
		}
	},
	linkClickButtonSubmit : function(params_){// link and button same tr same tr
			$(params_.target).on('click', function(){
				var deleteValue1 = $(this).parents("tr").find(".selectValue1").text();
				var deleteValue2 = $(this).parents("tr").find(".selectValue2").text();
				var deleteValue3 = $(this).parents("tr").find(".selectValue3").text();
				var anwser = confirm("Are you sure want to delete record?\n["+deleteValue1+"]\n["+deleteValue2+"]\n["+deleteValue3+"]");	
				if (anwser)
				  {$(this).parents("tr").find(params_.selector).click();
				  }
				else{
				return false;}
			});
	},
	selectedRadioValue : function(params_){ //selected Radio Value
	$(params_.target).each(function(){		
			var checkStatus = ($(this).prop("checked"));
			if(checkStatus==true){
			$("#routingNewItemValue").val($(this).val());
			}
		});
	},
	emptyShoppingCart : function(params_){
		$(params_.target).on('click',function(){			
			var anwser = confirm('Are you sure want to delete your cart')			
			if (anwser)
			  {$("#emptyCartBtn").click();
			  }
			else{
			return false;}
		})
	},
	textValueButtonDisable : function(params_){ //text box value empty button disable		
			var textValue = $(params_.target).val();
			if(textValue!=""){
			
			$(params_.selector).attr('disabled', "disabled");
			if(jQuery("#saasCallInvoke").hasClass("btn-invoke")){
				$("#saasCallInvoke").removeAttr("disabled");
			}
			}			
			else{
			//$(params_.selector).removeAttr("disabled");
			}
		
	},
	spanValueButtonDisable : function(params_){ //text box value empty button disable		
			
			var ackNwlg = $(params_.target).text();
			if(ackNwlg!=""){
			//console.log(ackNwlg);
			$(params_.selector).attr('disabled', "disabled");				
			}			
			else{
			$(params_.selector).removeAttr("disabled");
			}		
	},
	onEmailCheckButton : function(params_){ //on send email Check Button selection
		var curValue=$(params_.target).val();
		if(curValue=='true'){
			$(this).val('true');
			$(params_.selector).removeClass('hide');
			$(params_.target).attr("checked","checked");
		}			
		else{
			$(this).val('false');
			$(params_.target).removeAttr("checked");
			$(params_.selector).addClass('hide');
		}
		$(params_.target).on('click',function(){
			var checkValue = ($(this).prop("checked"));
			if(checkValue==true){
				$(this).val('true');
				$(params_.selector).removeClass('hide');
			}			
			else{
				$(this).val('false');
				$(params_.selector).addClass('hide');
			}
		});
	},
	/*AP-3755 China Direct CR*/
	checkLanguage:function(params_){
		$(params_.selector).on('click',function(){
	$(params_.target).val('\u5B89\u6377\u4F26\u79D1\u6280\u5728\u7EBF\u5546\u57CE\u8D26\u53F7');
				$(params_.enlang).on('click',function(){
			$(params_.target).val('Agilent eCommerce account');
		});
		});
	},
	bulkUploadCall:function(){
		itemcount = $(".qckOrderUpload1").find('.skyblueTable tbody tr').length;		
			if(itemcount > 1){				
				$('#createSubmit').prop('disabled', false);
				$('#createSubmit').removeClass('btn-disabled-state');
			}
		LSCA.triggerRemoveAjaxCall();
	},
	triggerRemoveAjaxCall:function(){
		jQuery("a.remove").click(function() {
		$.ajax({
				type : "GET",
				url : "/store/includes/homePage/quickorder/ajaxRemoveRTUItem.jsp?part_number="+$(this).attr("part-data"),
				dataType : "json",
				targetElt: $(this),
				success : function(data) {					
					var itemcount="";	
					if(data.status =="success"){
						$(this.targetElt).parents('tr').remove();
					}
					itemcount = $(".qckOrderUpload1").find('.skyblueTable tbody tr').length;
					if(itemcount < 1){				
						$('#createSubmit').prop('disabled', true);
						$('#createSubmit').addClass('btn-disabled-state');
					}
				},
				error : function() {
					console.log('Something went wrong!')
				}
			});
		});
	}
};

//************************ DO YOUR ALL JS CALLS AND CAHNGES BELOW ************************ //
(function($){
	//LSCA.mouseInOutFormValidate({target:'#mailCC, #mailToBCC'});	
	LSCA.langShowHide.init({selector:'#langShowHide input[type="radio"]'});
	/* dsp global button click */
	LSCA.buttonClick();
	//LSCA.addRowQO.init({url:'/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp', target:'#quickorder'});
	LSCA.addRowQO.init({url:'/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp', target:'.qckOrderUpload'});
	LSCA.addRowRTU.init({url:'/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp', target:'.qckOrderUpload1'});
	LSCA.addRowQOStoreland.init({target:'#quickorder2'}); //----Storelanding add row----//
	LSCA.removeRowItem.init({pageid:'qckOrderUpload', url:'/store/includes/ajax/ajaxRemoveLineItem.jsp?part_number=', target:'#productTable'});
	LSCA.removeRowItem.init({pageid:'viewMyCatalog', url:'/store/includes/ajax/ajaxRemoveGiftListItem.jsp?giftId=', target:'#viewCatalog'});
	LSCA.removeRowItem.init({pageid:'savedCart', url:'/store/includes/ajax/ajaxRemoveSavedCart.jsp?savedOrderId=', target:'#savedCartTable', callback:LSCA.reOrderSavedCart.init});
	LSCA.removeRowItem.init({pageid:'savedCartDetail', url:'/store/includes/ajax/ajaxRemovesavedCartLineItem.jsp?', target:'.mySavedCart'});
	LSCA.viewMyCatalogAddItem.init({url : '/store/includes/ajax/ajaxAddToMyCatalog.jsp?part_number=',target : '#viewCatalog'});

	LSCA.favoriteUpdateItem.init({pageid:'cartPage', url:'/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=', url2:'/store/includes/ajax/ajaxAddToMyCatalog.jsp?part_number=',  target:'#cartTable'});
	LSCA.favoriteUpdateItem.init({pageid:'productPage', url:'/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=', url2:'/store/includes/ajax/ajaxAddToMyCatalog.jsp?part_number=',  target:'#ProductDetails'});
	
	LSCA.RadioShowHide.init({targetEl:'#no', elAttr:'checked', targetE2:'#yes', e2Attr:'checked', toggleClass:$('.taxForm'), button:$(".continue")});
	LSCA.RadioShowHide.ShowHide({selector : $('input[type="radio"]'), target : $('.taxForm'), button:$(".continue")});	
	
	LSCA.populateState.init({url:'/store/includes/ajax/ajaxStateListOnCountrySelection.jsp?countryCode=',target:'#shippingaddress'})
	LSCA.populateState.init({url:'/store/includes/ajax/ajaxStateListOnCountrySelection.jsp?countryCode=',target:'#billingaddress'})
	LSCA.copyBillAddr({target:'#billShip'});
	LSCA.selectAll({target:".selAll",parent:"div.pchbox"});
	//BCC selectAll
	LSCA.CheckUncheckAll({target:".selAllCheck",parent:".selAllWrap"});
	LSCA.CheckUnCheck({target:".column .skyblueTable"});
	//LSCA.CheckUncheckAll({target:".selectAllEMEA",parent:".SalesEMEATable"});
	//LSCA.CheckUncheckAll({target:".selectAllSAPK",parent:".SalesSAPKTable"});
	//LSCA.CheckUncheckAll({target:".selectAllAFO",parent:".SalesAFOTable"});
	//LSCA.CheckUncheckAll({target:".selectAllSalesGC",parent:".SalesGCTable"});
	//select option resets
	LSCA.selectReset.init({target:'.samForm select', formid:'samForm' });
	LSCA.submitLocale({target:'#lang-dropmenu', selector:'#languageBtn'});
	LSCA.submitLocale({target:'#countryLists .countryList', selector:'#cntrySel'});
	
	LSCA.clickShow({target:'.nAddress', selector:'.dropAddress'});
	/*for quick order iframe*/
	LSCA.qckOrderIframe.init({target: '.batchUp .btnUpload', selector: '.iframeBlock'});
	LSCA.prodFilter.init({pageId:"productListing", target:".gridWrap", url:"/store/getPageGridData.jsp"});
	//LSCA.prodFilter.init({pageId:"productListing", target:".gridWrap", url:"filterdata.json"});
	/*Saved Cart Table*/
	LSCA.filterSavedCart.init({target: '.savedCart .gobtn', selector: '.skyblueTable', pageId:"savedCart"});
	/*cart update button on change textbox value*/
	LSCA.cartShowUpdate({target: '.cartTable .textboxQnt', selector: '.cartTable .skyblueTable'});
	/* My Quote == getQuote */
    LSCA.getQuoteOrder({url:'/store/includes/ajax/ajaxDisplayQuotesDroplet.jsp', target:'.btnGo', selector:'#quoteResult', pageId:'myQuote'});
    /* Check Order Status == get order */
    LSCA.getQuoteOrder({url:'/store/includes/ajax/ajaxSapOrderHistory.jsp?', target:'.btnGo', selector:'#orderResult', pageId:'getOrder'});
    /* My Quote == Disable Director View */
    LSCA.disableDirectorView({boolVal: 'true', pageId:'myQuote'});
    /* My Quote == clear form fields */
	LSCA.clearFields({target: '#quoteForm'});
    /* Next preveious navigation */
	LSCA.prevNextPaginate.init();
	/* BCC order email group edit */
	LSCA.editField({target:'.editField', grpName:'#grpName', grpDesc:'#grpDesc', grpId:'#updateIdField'});
	/* BCC email routing manager edit */
	LSCA.editField({target:'.editField', grpEmail:'#grpEmail', grpRadio:'#radioFields', grpId:'#updateIdField'});
	/* BCC order email group delete */
	LSCA.deleteField({target:'.delField', grpId:'#deleteIdField'});
	/*sidebar*/
	//LSCA.setSidebar.init({url:'/store/includes/homePage/browseProduct.jsp', target:'#browseCategory' });
	//LSCA.getCategoryList.init({url:'/store/includes/category/categoryList.jsp?catId=', page:1, target:'#categoryList'});
	/*Product Detail Add To Cart*/
	LSCA.PrDetailAddToCart.init();
	/* promotional images storelanding */
	LSCA.promoData.init({url:'/store/includes/homePage/promoImages.jsp?dataSize=All', target:'.btnVwAll', pageId:'homePage'});
	/* check atleast once profile */
	LSCA.requiredOnce({target:'.btnContinue, .btnUpdate'});
	/*global foem submit*/
	//LSCA.submitForm({form:"#quickorder2"});
	LSCA.submitForm({form:"#addUpdate", target:"#orderStatusEmail"});
	LSCA.checkboxReset({selector:'#regSubForm,#regProfileForm'}); //----//Clear Check Box//----//
	/*email form validate*/
	LSCA.formValidate.init({selector:'.sendEmail', url:'/store/myaccount/emailShoppingCartSuccess.jsp', target:'#emailShoppingCart'});
	LSCA.formValidate.init({selector:'.sendEmailing', url:'/store/myaccount/emailOrderDetailsSuccess.jsp', target:'#emailCartform'});
	$("#emailOrderDetailsClose").click(function(){ $("#pageContentDiv").html(" ");});
	//Normal Form Validation//
	LSCA.NormalFormValidate.init({selector:'.saveCart', target:'#saveShopingCart', target2:'#saveCart'});
	//BCC order Status Tool Normal Form Validation//
	LSCA.NormalFormValidate.init({selector:'#sapUpdate', target:'#sapUpdateForm', target2:'#updateorder'});
	LSCA.NormalFormValidate.init({selector:'#noEmail', target:'#sapUpdateForm', target2:'#updateorder'});
	LSCA.NormalFormValidate.init({selector:'#emailOrder', target:'#emailOrderForm', target2:'#sendEmail'});
	LSCA.NormalFormValidate.init({selector:'#saasCallInvoke', target:'#saasForm', target2:'#updateSAAS'});
	LSCA.NormalFormValidate.init({selector:'.BCC #addUpdate .gobtn', target:'#addUpdate', target2:'#orderStatus'});
	LSCA.NormalFormValidate.init({selector:'.BCC #orderUpload .gobtn', target:'#orderUpload', target2:'#orderStatusUpld'});
	//BCC webOrderRoutes page
	LSCA.webOrderSubmit({target:'#webOrder input[type="radio"]', selector:'#webOrderSubmit'});
	LSCA.linkClickButtonSubmit({target:'.deleteRow', selector:'.delete'});
	//on Check Button Disable
	LSCA.onCheckButtonDisable({selector:'#btnTest', target:'#billShip'});
	// BCC select Option Selected
	LSCA.selectOptionSelected.init({selector:'#salesOrganization', target:'.editSelect', dataValue:'.selectValue1', updateValue1:'#routingDataValueUpdate', updateValue2:'#routingItemValueUpdate'}, LSCA.selectOptionSelected.init({selector:'#productLine', target:'.editSelect', dataValue:'.selectValue2'}),LSCA.selectOptionSelected.init({selector:'#distributionGroup', target:'.editSelect', dataValue:'.selectValue3'}));
	//BCC selected Radio Value
	LSCA.selectedRadioValue({target:'#webOrder input[type="radio"]'});
		
	//BCC text box value empty button disable
	LSCA.textValueButtonDisable({selector:'#sapUpdateForm input, #sapUpdateForm textarea, #sapUpdateForm button', target:'#sapOrder'});
	LSCA.spanValueButtonDisable({selector:'#ordAck', target:'.orderAck'});
	//empty cart link prompt dialog
	LSCA.emptyShoppingCart({target:'#emptyShoppingCart'});
	//To show email option on userDetailTool.jsp page
	LSCA.onEmailCheckButton({selector:'.sendEmailOptions', target:'#useremailChkBox'});
	/*AP-3755 China Direct CR*/
	LSCA.checkLanguage({selector:'#cnLang',target:'.emailSub',enlang:'#enLang'});
	/*this section contains uniform form and button*/
	$(".btn-blue,.btn-grey,.btnEmptyCart").corner("15px");
	$(".myAcDrdwn").corner("bottom");
	$(".Firefox .btn-blue,.Firefox .btn-grey").corner("20px");
	$(".formSales .btn-blue").corner("8px");
	$("select").uniform();
	$("input[type=checkbox]").not(".noUniform").uniform();
	/*ends here*/
	/*country List equal height begins*/
	var maxHeight = -1;
   $('.countryList > div, .placeOrderBox').each(function() {
     maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
   });
   $('.countryList > div, .placeOrderBox').each(function() {
	 $(this).height(maxHeight+10);
   });
   /*country List equal height ends*/
	$('#df,#dt,.cal').datepicker().attr('readonly', true);
	
	$(".tooltip").tooltip();
	
	// Datepicker
	$('.calender').datepicker({showOn:"button",buttonImage:"../images/icon-calender.png",buttonImageOnly:true,minDate:0}).attr('readonly', true);
	LSCA.toolTipFly.init({target:'.mainListItem', selector:'.drop_cols'});
	var configDetailCol= $(".configDetail tbody tr td").length;
	$(".configDetail thead tr th").prop("colspan",configDetailCol);
	
	/* search box integration */
	$("#searchForm").on('submit', function(e){// console.log(e);
	e.preventDefault();
	var input=$('#searchinput').val();
	window.location = "/search/?Ntt=" + input;
	});
	LSCA.bulkUploadCall();
	var $table=$('.equalizeColmn > table');
//    $table.floatThead({
//		scrollContainer: function($table){
//		 return $table.closest('.equalizeColmn');
//		}
//	});
})(jQuery)


		
function heightPanel(){
  $(".iframeBlock").addClass("adjHeight");
  $('.adjHeight').css('height','200px');
};


//Given Below Code Need to be added in above script.js file for CR--AP-2459
if($('form').attr('id') == 'logout' && navigator.appVersion.indexOf("MSIE") > -1  )
{
		$("input").keypress(function(event) {
		    if (event.which == 13) {
		        event.preventDefault();
		        $("#orderStatus").click(); 
		    }
		});
}

//Given Below Code Need to be added in above script.js file for DCCOM-8878
$("#cancelSubmit").prop('disabled',true);
$("#active").prop('disabled',true);
var $orderAll = $("input:radio[name=orderOptions]");
$orderAll.on( "change", function() { 
	var cancelvalue = $('#cancelvalue').val();
	if(cancelvalue == 'true'){
		$("#active").prop('disabled',false);
	}
	console.log($(this).val(), cancelvalue);
	if($(this).val() == 'inactive' && cancelvalue == 'true'){
		$("#cancelSubmit").prop('disabled',false);
		//console.log($(this).val(),'1', cancelvalue);
	} else {
		$("#cancelSubmit").prop('disabled',true);
	}
});
/*$("input#RTUListName").keyup(function(event) {
   $('#RTUListName1').val($(this).val());
});*/
$('#createSubmit').click(function(){
	var newText = $("#RTUListName").val().trim();
	$('#RTUListName1').val(newText);
	var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
	var validList = true;
	if (pattern.test(newText)) {
		validList = false;
	} else {
		validList = true
	}
	if($('#RTUListName').val() =='' || !validList) {
		$('#RTUListName').css('border-color','red');
		if(!validList) {
			var listtErrorMsg = "<div id='errorListName' class='alert alert-dismissable alert-danger'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>x</button>No special character allowed.</div>";
		}
		else {
			var listtErrorMsg = "<div id='errorListName' class='alert alert-dismissable alert-danger'><button aria-hidden='true' data-dismiss='alert' class='close' type='button'>x</button>Please enter list name.</div>";
		}
		$('#Listerror-messages').html('');
		$('#Listerror-messages').html(listtErrorMsg);
		$('#Listerror-messages').show();
		//$('#Listerror-messages #errorListName').show();
	}
	else {
		$('#RTUListName').css('border-color','none');
		$('#Listerror-messages').hide();
		//$('#Listerror-messages #errorListName').hide();
		$('#createGiftListLink').trigger('click');
	}
});

$("#RTUListName").on('keypress', function(e) {
	if($(this).val() == '') {
		if (e.which == 32)
		return false;
	}
	
 });
var domain = "domain=.agilent.com";
if(location.host){
	if(location.host.indexOf(".agilent.com.cn")!=-1){
		domain = "domain=.agilent.com.cn";
	}else{
		domain = "domain=.agilent.com";
	}
}

function setCookie(cname, cvalue, exdays) {
		  var d = new Date();
		  d.setTime(d.getTime() + (exdays*24*60*60*1000));
		  var expires = "expires="+ d.toUTCString();
		  document.cookie = cname + "=" + cvalue + ";" + expires + ";"+domain+";path=/";
}

 $(document).ready(function() {	 	 
	if($('div.containerPanel').hasClass('rtuContainer')){
		setCookie('agilent_locale','en_US', 90);
		setCookie('CountryCode','US', 90);
		setCookie('AG_LOCALE','USeng', 90);
		setCookie('CountryName','United States', 90);
		setCookie('isRegulatory','true', 90);		
	}
	$('#clearAll').click(function(){
		$('#clearFormData').trigger('click');
		
	});
});
 
 
 

 
function deactivateUser() {	
	$(document).on('click', '#deActivateUser', function() {
	     console.log('click');	     	    
	     setTimeout(function(){
	         console.log('beforeloading');
	         $(".loader-overlay").show(); }, 500);
	         console.log('afterloading');         
	    
	 });
	
	 $('#deActivateUser').click();
	 $("#deActiveUser").prop('disabled',true);
}


function activatingUser() {	
	$(document).on('click', '#activateUser', function() {
	     console.log('click');	     	    
	     setTimeout(function(){
	         console.log('beforeloading');
	         $(".loader-overlay").show(); }, 500);
	         console.log('afterloading');         
	    
	 });
	
	 $('#activateUser').click();
	 $("#activeUser").prop('disabled',true);
}
 /*loader gif script starts*/


