// JavaScript Document
/*
 * @Description: This is combined control script for Agilent Genomics site.
 * @Author: Abnish Singh for HCL Agilent team.
*/

//************************ DO NOT MAKE ANY CHANGES BELOW ************************ //
var LSCA = {
	globalAjax : { //----Global Ajax call----//
		doCall : function(config, callback){
			config = config || {};
			config.type = config.type || 'POST';
			config.url = config.url || {};
			config.dataType = config.dataType || 'json';
			config.context = config.context || $('this');
			config.cache = config.cache || false;
			config.data = config.data || {};
			config.target = config.target || {};
		
			if(config.url!='' && config.url!='undefined'){
				$.ajax({ type:config.type, url:config.url, dataType:config.dataType, cache:config.cache, data:config.data }).done(function(data){if

(typeof(callback)==='function' && callback!='undefined')callback({target:config.target,data:data})}).error(function( xhr,err ){ console.log( "Error:", err ); 

console.log("readyState: "+xhr.readyState+"\nstatus: "+xhr.status+"\nresponseText: "+xhr.responseText); });
			}else{
				return 'Call location not defined!'
			}
		}
	},
	GlobalValidate : {//----Global form validation for all type of forms----//
		init : function(options_){
			//$('form[name="'+options_.target+'"]').on(options_.action, function(){
				var gtg = true, 
				vclass = ['required','alpha','alphanum','chkrequired','selectone','email','confirm2']; //validation type class name
				
				//els = $('form[name="'+options_.target+'"]').map(function(){ return $.makeArray(this.elements); });
				els = $(options_.target).map(function(){ return $.makeArray(this.elements); });
				els.each(function(i){
					LSCA.GlobalValidate.hideError($(els[i]));
					for(c in vclass){
						if($(els[i]).hasClass(vclass[c])){
							gtg = LSCA.GlobalValidate.doValidate.validate(vclass[c],$(els[i]));
							if(gtg===false){ $(els[i]).focus().select(); return gtg;}
						}
					}
				});
				return gtg;			 
			//});
		},
		doValidate : {
			validate : function(casechk, element){
			var chk = false, msg = element.attr('title');
				if(casechk === 'required'){
					if(element.val()===''){
						msg = msg || 'This field is required.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'alpha'){
					if(/[^a-zA-Z]+$/.test(element.val())){
						msg = msg || 'Please enter alphabets only.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'alphanum'){
					if(/[^a-zA-Z0-9]+$/.test(element.val())){
						msg = msg || 'Please enter alphnumrics only.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'selectone'){
					if(element.val()==''||element.val()==0){
						msg = msg || 'Please select one.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'chkrequired'){
					if(!element.attr('checked')){
						msg = msg || 'This field is required.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'email'){
					if( !(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(element.val())) ){
						msg = msg || 'Please enter valid email.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}else if(casechk === 'confirm2'){
					var pass1 = element.val(), pass2 = $('.confirm1').val();
					if( pass1 != pass2 || pass1==''){
						msg = msg || 'Confirm password is not same.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}else{chk = true;}
				}
				
				if(element.attr('minchar')!='undefined' || element.attr('minchar')!=''){
					if(element.val().length < parseInt(element.attr('minchar'))){
						msg = msg || 'Please enter minimum '+element.attr('minchar')+' character.';
						LSCA.GlobalValidate.showError(element, msg);
						chk = false;
					}
				}else{ chk = true; }
				
			return chk;		
			}
		},
		showError : function(element, msg){
			msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+msg+'</div>';
			$(document).find('div.errorMessages:eq(0)').hide();
			//element.addClass('error');
			$(document).find('div.errorMessages:eq(0)').html(msgui);
			$(document).find('div.errorMessages:eq(0)').show();
		},
		hideError : function(element){
			$(document).find('div.errorMessages:eq(0)').hide();
			//element.removeClass('error');
		}
	},
	addRowQO : { //----Quick Order add row----//
		init : function(params_){
			$('#addpart').on('submit', function(e){
				e.preventDefault();
				var dovalidate = LSCA.GlobalValidate.init({target:'#addpart',action:'submit'});
				valueObj = $(this).serializeArray();
				url = params_.url+'?part_number='+valueObj[0].value+'&qty='+valueObj[1].value;
				if(dovalidate){
					if(valueObj[1].value > 0 && valueObj[1].value < 1000){
						if(LSCA.addRowQO.iteminlist({target:$(params_.target).find('tbody'),data:valueObj}))
						LSCA.globalAjax.doCall({url:url, target:params_.target}, LSCA.addRowQO.parseme);
					}else{
						LSCA.GlobalValidate.showError('', 'Please enter valid quantity.');
					}
				}
			});
		},
		parseme: function(response){
			var data = response.data; console.log(typeof(data));
			if($(document).find(response.target).length>0 && $(response.data).length>0 && data.mStatus!=500){
				if($(response.target).find('.skyblueTable').length==0){
					tblui = '<div class="errorMessages"></div><table class="skyblueTable">';
					tblui += '<thead><tr><th>Qty</th><th>Part Number</th><th>Description</th><th>List Price</th><th></th></tr></thead>';
					tblui += '<tbody></tbody>';
					tblui += '</table><div class="btnPanel text-right"><button type="button" class="btn btn-blue">Add To Cart</button></div>';
					$(response.target).html(tblui);
				}
				tblrow = '<tr id="'+data.mPartNumber+'">';
				tblrow += ' <td><input name="quantity" type="text" value="'+data.mQty+'" /><input name="skuid" type="hidden" value="'+data.mSkuid+'"/><input name="productid" type="hidden" value="'+data.mProductId+'" /></td>';
				tblrow += ' <td>'+data.mPartNumber+'</td>';
				tblrow += ' <td>'+data.mProductDescription+'</td>';
				tblrow += ' <td>'+data.mListPrice+'</td>';
				tblrow += ' <td><a href="javascript:void(0);" part-data="'+data.mPartNumber+'" class="remove"></a></td>';
				tblrow += '</tr>';
				$(response.target).find('.skyblueTable tbody').append(tblrow);
				$(response.target).show();
				
				LSCA.addRowQO.showmsg({status:data.mStatus,msg:data.mStatusMessage,target:response.target});
				LSCA.addRowQO.removeitem({target:$(response.target).find('#'+data.mPartNumber+" a"), parenttarget:response.target});
			}else if(data.mStatus===500){
				LSCA.GlobalValidate.showError('', data.mStatusMessage);
			}
			window.onbeforeunload = ($(response.target).find('.skyblueTable tbody tr').length>0)? function(){ return 'You will lose your cart data!' } : 

null;
			($(response.target).find('.skyblueTable tbody tr').length>1)? $('#productlist').hide() : $('#productlist').show();
		},
		iteminlist : function(options_){
			itemrow = $(options_.target).find('tr#'+options_.data[0].value);
			tqty = parseInt($(itemrow).find('input[name="quantity"]').val())+parseInt(options_.data[1].value);
			if(itemrow.length > 0){
				(tqty < 1000)? $(itemrow).find('input[name="quantity"]').val(tqty) : LSCA.GlobalValidate.showError('', $(itemrow).find('input[name="quantity"]').attr('title'));
				return false;
			}else{
				return true;
			}
		},
		removeitem : function(options_){
			$(options_.target).on('click', function(){ 
				$(this).parents('tr').remove();
				itemcount = $(options_.parenttarget).find('.skyblueTable tbody tr').length;
				if(itemcount < 1){$(options_.parenttarget).hide(); $('#productlist').show(); window.onbeforeunload = null}
			});
			
		},
		showmsg : function(options_){
			msgui = '<div class="alert alert-dismissable alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+options_.msg+'</div>';
			if(options_.status===300 || options_.status===500){			
				$(options_.target).find('.errorMessages').html(msgui).show();
			}else{
				$(options_.target).find('.errorMessages').hide();
			}
		}
	},
	toolTipFly : {
		init : function(params_){
			$(params_.target).hover(function(){
				$(params_.selector).hide();
				$(params_.selector,this).show();
			})
		}
	},	
	fileUploadRemoveItem :{ //File upload remove item
		init : function(params_){
			if($(document).find('#mainContainer').hasClass('qckOrderUpload')){
				$(params_.target).find("a.remove").on('click', function(){
					LSCA.globalAjax.doCall({url:params_.url+$(this).attr('prodid'), dataType:'html',target:$(this)}, 

LSCA.fileUploadRemoveItem.removeItem);
				})
			}
		},
		removeItem : function(params_){
			$(params_.target).parents('tr').remove();
		}
	},
	
	viewMyCatalogRemoveItem :{ //View My Catalog remove item
		init : function(params_){
			if($(document).find('#mainContainer').hasClass('viewMyCatalog')){
				$(params_.target).find("a.remove").on('click', function(){
					LSCA.globalAjax.doCall({url:params_.url+$(this).attr('rel'), dataType:'html',target:$(this)}, 

LSCA.viewMyCatalogRemoveItem.removeItem);
				})
			}
		},
		removeItem : function(params_){
			$(params_.target).parents('tr').remove();
		}
	},
	
	RadioShowHide : {
		init : function(params_){
			if($(params_.targetEl).attr(params_.elAttr) === 'checked'){
				params_.toggleClass.hide();
				params_.button.show();
			}
			
			if($(params_.targetE2).attr(params_.e2Attr) === 'checked'){
				params_.toggleClass.show();
				params_.button.hide();
			}
		},
		ShowHide : function(option_){
			option_ = option_ || {};
			option_.selector = option_.selector || {};
			option_.target = option_.target || {};
			option_.selector.change(function(){
				if($(this).val() === 'true'){
					option_.target.show();
					option_.button.hide();
				}else{
					option_.target.hide();
					option_.button.show();
				}
			});
		}
	},
	clickShow : function(params_){
		$(params_.target).click(function(){
			$(params_.selector).toggle();
		})
	},
	
	SameShippingAddr : function(params_){
		$(params_.target).click(function(){
				var chkVal = $(params_.target).attr('checked');
				//alert(chkVal);
				if(chkVal==undefined){
					$(params_.target).attr('checked','checked');
					if($(params_.target).attr('checked')){
						///alert("lg");
						$('#addr').val($('#address').val());
						$('#addr2').val($('#address2').val());
						$('#cty').val($('#city').val());
						$('#zp').val($('#zip').val());
						$('#state2').val($('#state').val());
						$('#state2').prev('span').text($('#state').val());
						$('#cntry').val($('#country').val());
						$('#cntry').prev('span').text($('#country').val());
					}
				}
					else{$(params_.target).attr('checked',false);
					$('#addr').val("");
					$('#addr2').val("");
					$('#cty').val("");
					$('#zp').val("");
					$('#state2').val("");
					$('#cntry').val("");
					
					}
				
		});
	},
	
	countryChange : function(params_){
		$(params_.target).change(function(){
			
		})
	},
	
	prodFilter : {
		init : function(params_){
			if($(document).find('.container').attr('id')===params_.pageId){
				LSCA.globalAjax.doCall({url:params_.url, target:params_.target},function(options_){
					LSCA.prodFilter.parseData(options_, function(){
						LSCA.prodFilter.addFilter({target:params_.target}, function(){
							LSCA.prodFilter.addAction({target:params_.target})
						});
					});
				});
			}
		},
		parseData : function(params_, callback){
			var data = params_.data, tblui='', dropval = [], dataCnt=0; for(dataObj in data) dataCnt++;
			if(dataCnt > 0){
				$.each(data, function(o,k){ 
					if(o === "headerDataVo"){tblui = '<table class="skyblueTable"><thead>'; tpart = 'h';}else{tblui += '<tbody>'; tpart = 'b';}
					$.each(k, function(i,v){
						tblui += (tpart==='h')? '<tr><th>QTY</th>':'<tr><td><input type="text" value="" name=""></td>';
						$.each(v, function(j,w){
							isdynamic = (j==='dynamicFields')? ' dynamic' : '';
							if(typeof(w)!=='object'){
								tblui += (tpart==='h')? '<th>'+w+'</th>':'<td>'+w+'</td>';
							}else{
								$.each(w, function(k,x){
									tblui += (tpart==='h')? '<th class="'+isdynamic+'"><ul><li class="dropdown"><span data-toggle="dropdown" class="dropdown-toggle">'+x+'<span class="caret"></span></span></th>' : '<td class="'+isdynamic+'">'+x+'</td>';
								});
							}
						});
						tblui += '</tr>';
					});
					tblui += (tpart==='h')? '</thead>':'</tbody></table>';
				});
				$(document).find(params_.target).html(tblui);
				if(callback && typeof(callback)=='function') callback();
			}
		},
		addFilter : function(params_,callback){
			$(params_.target).find('thead th.dynamic').each(function(i,v){
				var valarr = [], menuui = '', list = '';
				if(i!=params_.fltrindex){
					$(params_.target).find('tbody tr:visible').each(function(){
						dynel = $(this).find('td.dynamic').get(i); dynval = $.trim($(dynel).text());
						if(dynval!=''){ if($.inArray(dynval,valarr)==-1)valarr.push(dynval); }
					});
					$.each(valarr, function(j,w){list += '<li>'+w+'</li>';});
					menuui = '<ul class="dropdown-menu drFilter pull-right"><li>All</li>'+list+'</ul>';
					if($(this).find('li.dropdown > ul.dropdown-menu').length < 1){
						$(this).find('li.dropdown').append(menuui);
					}else{
						$(this).find('li.dropdown > ul.dropdown-menu').remove();
						$(this).find('li.dropdown').append(menuui);
					}
				}
			});
			if(callback && typeof(callback)=='function') callback();
		},
		
		addAction : function(params_){
			$(params_.target).find('thead th.dynamic').each(function(i,v){
				$(this).find('ul.dropdown-menu > li').on('click', function(){
					var fltrval = $(this).text();
					$(params_.target).find('tbody tr').hide();
					$(params_.target).find('tbody tr').each(function(j,w){
						el = ($(this).find('td.dynamic').get(i)); val = $.trim($(el).text());
						if(fltrval == val){
							$(this).show();
						}else if(fltrval == 'All'){
							$(params_.target).find('tbody tr').show();
						}
					});
					LSCA.prodFilter.addFilter({target:params_.target, fltrindex:i}, function(){LSCA.prodFilter.addAction({target:params_.target})})
				});
			});
		}
		
	}	
};

(function($){
	LSCA.addRowQO.init({url:'/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp', target:'#quickorder'});
	LSCA.fileUploadRemoveItem.init({url:'/store/includes/ajax/ajaxRemoveLineItem.jsp?part_number=', target:'#productTable'});
	LSCA.viewMyCatalogRemoveItem.init({url:'/store/includes/ajax/ajaxRemoveGiftListItem.jsp?giftId=', target:'#viewCatalog'});
	
	LSCA.RadioShowHide.init({targetEl:'#no', elAttr:'checked', targetE2:'#yes', e2Attr:'checked', toggleClass:$('.taxForm'), button:$(".continue")});
	LSCA.RadioShowHide.ShowHide({selector : $('input[type="radio"]'), target : $('.taxForm'), button:$(".continue")});	
	LSCA.SameShippingAddr({target:'#billShip', elAttr:'checked'});
	LSCA.countryChange({target:'#country'});
	LSCA.clickShow({target:'.nAddress', selector:'.dropAddress'});
	LSCA.prodFilter.init({pageId:"econofilters", target:".gridWrap", url:"filterdata.json"});
	/*this section contains uniform form and button*/
	$(".btn-blue,.btn-grey,.btnEmptyCart").corner("15px");
	$(".myAcDrdwn").corner("bottom");
	$(".Firefox .btn-blue,.Firefox .btn-grey").corner("20px");
	//$(".formSales .btn-blue").corner("8px");
	$("select").uniform();
	$("input[type=checkbox]").not(".noUniform").uniform();
	/*ends here*/
	/*country List equal height begins*/
	var maxHeight = -1;
   $('.countryList > div').each(function() {
     maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
   });
   $('.countryList > div').each(function() {
	 $(this).height(maxHeight+10);
   });
   /*country List equal height ends*/
	$('#df,#dt,.cal').datepicker().attr('readonly', 'readonly');
	
	$(".tooltip").tooltip();
	
	// Datepicker
	$('.calender').datepicker({showOn:"button",buttonImage:"images/icon-calender.png",buttonImageOnly:true,minDate:0}).attr('readonly', 'readonly');
	LSCA.toolTipFly.init({target:'.mainListItem', selector:'.drop_cols'});
	
	
})(jQuery)