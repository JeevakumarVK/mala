function checkEmptyField() {
	
	var myFromDate = document.getElementById('from-date');
	var myToDate = document.getElementById('to-date');
	
	if((myFromDate.value=="") && (myToDate.value==""  )) {
	alert("Required field: From date, To date");
	return false;
	}
	else if(myFromDate.value=="")
	 {
	 alert("Required field: From date");
	 return false;
	 
	}
	else if(myToDate.value=="")
	{
	alert("Required field: To date");
	return false;
	}
	}