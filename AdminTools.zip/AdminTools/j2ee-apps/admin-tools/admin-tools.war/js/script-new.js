/*
 * @Description: This is combined control script for Agilent Genomics site.
 * @Author: Abnish Singh.
*/

var genomic = {
	loadData : function(option_){
		option_ = option_ || {};
		option_.target = option_.target || {};
		option_.selector = option_.selector || {};
		option_.targetURI = option_.targetURI || {};
		option_.title = option_.title || {};
		
		console.log(option_);
		option_.target.load(option_.targetURI+' '+option_.selector, function(){
			genomic.HistoryPlugin.setURL(option_.title, option_.targetURI);	
		});
	},
	RadioShowHide : {
		init : function(params_){
			if(params_.targetClass.find(params_.targetEl).eq(params_.elIndex).attr(params_.elAttr) === 'checked')
				params_.toggleClass.show();
		},
		ShowHide : function(option_){
			option_ = option_ || {};
			option_.selector = option_.selector || {};
			option_.target = option_.target || {};
			option_.selector.change(function(){
				if($(this).val() === 'yes'){
					option_.target.show();
				}else{
					option_.target.hide();
				}
			});
		}
	},
	HistoryPlugin : {
		init : function() { 
			// if exist a hashtag, redirect the user the to correct page
			if(location.hash) {
				window.location = location.hash.replace('#', '');
			}
		}, 
		setURL : function(title,url) {
			if(history.pushState) {
				if(title)
				  document.title = title;
			      history.pushState({"id":100}, title, url);
			} else {
				if(title)
				  document.title = title;
				  // Fallback for hahstag
				  location.hash = url;
				
			}
		}
	},
	TreeNode : {
		init : function(id){ 
			$(id+" li").find('ul').hide().parent().prepend('<span>0 - </span>').addClass('node');
			
			genomic.TreeNode.ExpandColapse(id);
		},
		ExpandColapse : function(id){
			$(id+" li").on('click', 'span', function(e){
					$nodeEl = $(this).parent();
					if($nodeEl.find('ul').css('display')==='none'){
						$nodeEl.find('ul').eq(0).show(500).parent().addClass('colapse');
					}else{
						$nodeEl.find('ul').eq(0).hide(500).parent().removeClass('colapse');
					}
					e.stopPropagation();
			});
		}
	},
	QuickChangeSwitchField : {
		Switch : function(params_){			
			$(params_.target).find('button').on('click', function(){
				$(params_.selector+' div').hide();
				$(params_.selector).find('div').eq($(this).index()).show();
			});
		}
	},
	ShowHideModal : {
		init : function(selector){
			$(selector).on('click', function(){
				x = $(document).height();
				modal = $(this).attr('modal-type');
				$("#overlay").css("height",x+"px").fadeIn(1000);
				$(".popup").hide();
				$('.'+modal).show();
				
				genomic.ShowHideModal.CloseModal();				
			});
		},
		CloseModal : function(){
			$(".closewindow a, .closewindow img").on('click', function(){
				$("#overlay").fadeOut(1000);
			});
		}
	},
	ProductTab : {
		TabSwitch : function(options_){
			$(options_.anchorId).find('a').on('click', function(){
				pageTitle = $(this).attr('page-title');
				targetUrl = $(this).attr('href');		
				genomic.loadData({target : $(options_.getSetTarget), selector : options_.getSetTarget, targetURI : targetUrl, title : pageTitle});
				$(options_.anchorId).find('a').removeClass('active');
				$(this).addClass('active');
				
				return false;
			});
		}
	},
	BannerSlider : function(options_){
		// Set starting slide to 1
		var startSlide = 1;
		// Get slide number if it exists
		if (window.location.hash) {
			//startSlide = window.location.hash.replace('#','');
		}
		// Initialize Slides
		$(options_.selector).slides({
			preload: true,
			preloadImage: 'images/loading.gif',
			generatePagination: true,
			play: 5000,
			pause: 2500,
			hoverPause: true,
			// Get the starting slide
			start: startSlide,
			animationComplete: function(current){
				// Set the slide number as a hash
				//window.location.hash = '#' + current;
			}
		});
	}
};

$(function(){
	
	//initate url fix at page load	
	genomic.HistoryPlugin.init();
	
	//banner slider
	genomic.BannerSlider({selector : '#slides'});
	
	//product tab loader
	genomic.ProductTab.TabSwitch({anchorId : '#tabs', getSetTarget : '#tabCntPanel'})
	
	//start tree structure
	genomic.TreeNode.init('#tree_view');
	
	//radio show/hide toggle
	genomic.RadioShowHide.init({targetClass:$('.radios'), targetEl:'input', elIndex:'1', elAttr:'checked', toggleClass:$('.taxForm')});
	genomic.RadioShowHide.ShowHide({selector : $('input[type="radio"]'), target : $('.taxForm')});
	genomic.QuickChangeSwitchField.Switch({target:'.dnaUpload', selector:'.dnaUploadField'});
	genomic.ShowHideModal.init('.infomsg');
	
	$("#country,#cntry,#bPayMethod,#language,#unit,#unit2,#dakoCountry,#prdGrp,#aff,#countryArea,#ssdCntry,#manual,#taxECert,#language").uniform();
	$("#site1,#site2,#site3,#site4,#site5,#site6,#site7,#site8,#site9,#site10,#site11,#site12,#site13,#site14").uniform();
	
});