package com.agilent.droplets;

import static com.agilent.base.platform.Constants.FALSE;
import static com.agilent.base.platform.Constants.TRUE;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;

import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class AgilentCheckProfileRole extends DynamoServlet {
	
	@Override
	public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException {
		vlogDebug(":::::: Entering into AgilentCheckProfileRole.service :::::::");
		ParameterName USER_ROLES = ParameterName.getParameterName("userRoles");
		String userRoles = pReq.getParameter(USER_ROLES);
		boolean isRoleExist = false;
		vlogDebug("AgilentCheckProfileRole.service ::: Role Infomartion -->{0}", userRoles);
		try {
			if(StringUtils.isNotBlank(userRoles)) {
				String[] roleSplit = userRoles.split(",");
				List<String> userRoleList = Arrays.asList(roleSplit);
					if(userRoleList.contains("User_Mng_Read")) {
						setRoleParameter(pReq,pRes,"User_Mng_Read_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("Web_Operation")) {
						setRoleParameter(pReq,pRes,"Web_Operation_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("Agilent_Admin")) {
						setRoleParameter(pReq,pRes,"Agilent_Admin_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("User_Mng")) {
						setRoleParameter(pReq,pRes,"User_Mng_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("User_Mng_Admin")) {
						setRoleParameter(pReq,pRes,"User_Mng_Admin_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("Order_Status")) {
						setRoleParameter(pReq,pRes,"Order_Status_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("Order_Mng")) {
						setRoleParameter(pReq,pRes,"Order_Mng_Info");
						isRoleExist = true;
					}
					if(userRoleList.contains("ERFQ_Mng")) {
						setRoleParameter(pReq,pRes,"ERFQ_Mng_Info");
						isRoleExist = true;
					}
			}
		} catch (ArrayIndexOutOfBoundsException aie) {
			vlogError(aie, "ArrayIndexOutOfBoundsException excepton occured");
	    } catch (Exception e) {
			vlogError(e, "Exception occured");
	    }
		if (isRoleExist) {
			pReq.serviceLocalParameter(TRUE, pReq, pRes);
		} else {
			pReq.serviceLocalParameter(FALSE, pReq, pRes);
		}
		vlogDebug(":::::: Exisiting into AgilentCheckProfileRole.service :::::::");
	}
	
	/**
	 * This method will set the parameter name
	 * @param pReq
	 * @param pRes
	 * @param roles_i
	 * @throws ServletException
	 * @throws IOException
	 */
	private void setRoleParameter(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes, String roles_i) throws ServletException, IOException {
		pReq.serviceLocalParameter(roles_i, pReq, pRes);
	}
	

}
