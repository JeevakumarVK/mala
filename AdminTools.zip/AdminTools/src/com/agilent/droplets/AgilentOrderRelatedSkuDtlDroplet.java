package com.agilent.droplets;

import java.io.IOException;
import javax.servlet.ServletException;
import atg.core.util.StringUtils;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;


/**
 * @author girish-m
 *
 */
public class AgilentOrderRelatedSkuDtlDroplet extends DynamoServlet {

	public static final String OUTPUT                   = "output";

	Repository mProductCatalogRepository;

	public Repository getProductCatalogRepository() {
		return mProductCatalogRepository;
	}

	public void setProductCatalogRepository(Repository pProductCatalogRepository) {
		mProductCatalogRepository = pProductCatalogRepository;
	}

	@Override
	public void service(DynamoHttpServletRequest pReq,DynamoHttpServletResponse pRes) throws ServletException, IOException {
		try {
			vlogDebug("Entering Into Droplet AgilentOrderRelatedSkuDtlDroplet.service method...");
			String refID= pReq.getParameter("refID");
			if(!StringUtils.isBlank(refID)){
				vlogDebug("catalogRefID is : {0}", refID);
				RepositoryItem sku=getProductCatalogRepository().getItem(refID, "sku");
				String productLine=(String) sku.getPropertyValue("productLine");
				String skuID=(String) sku.getPropertyValue("catalogId");

				vlogDebug("productLine is : {0}", productLine);
				vlogDebug("skuID is : {0}", skuID);
				// Going to set productline and sku into values
				pReq.setParameter("productLine", productLine);
				pReq.setParameter("skuID", skuID);
				
			}else{
				vlogDebug("CatalogRefID is found NULL this time...");
			}

			vlogDebug("Exiting from Droplet AgilentOrderRelatedSkuDtlDroplet.service method...");
		} catch (RepositoryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pReq.serviceParameter(OUTPUT, pReq, pRes);
	}
}
