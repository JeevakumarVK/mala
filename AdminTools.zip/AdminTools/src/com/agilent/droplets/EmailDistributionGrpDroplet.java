package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;

import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class EmailDistributionGrpDroplet extends DynamoServlet  {
	
	private List<RepositoryItem> distributionGrpList;
	private Repository routingRepository;
	
	public List<RepositoryItem> getDistributionGrpList() {
		return distributionGrpList;
	}

	public void setDistributionGrpList(List<RepositoryItem> distributionGrpList) {
		this.distributionGrpList = distributionGrpList;
	}

	public Repository getRoutingRepository() {
		return routingRepository;
	}

	public void setRoutingRepository(Repository routingRepository) {
		this.routingRepository = routingRepository;
	}
	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		try {
			RqlStatement statement = RqlStatement.parseRqlStatement("ALL");
			RepositoryView view = getRoutingRepository().getView("distributionGrp");
			Object[] params = new Object[1];
			RepositoryItem[] routItems = statement.executeQuery(view, params);
			setDistributionGrpList(Arrays.asList(routItems));
		} catch (RepositoryException e) {
			vlogError("Exception caught ::{0}", e);
		}
		pRequest.setParameter("distributionGrpList", getDistributionGrpList());
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}
}
