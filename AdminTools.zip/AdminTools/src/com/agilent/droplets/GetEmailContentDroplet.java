package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.agilent.report.OrderStatusTool;

import atg.repository.Repository;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class GetEmailContentDroplet extends DynamoServlet  {
	
	
	private OrderStatusTool orderStatusTool;
	/**
	 * @return the orderStatusTool
	 */
	public OrderStatusTool getOrderStatusTool() {
		return orderStatusTool;
	}

	/**
	 * @param pOrderStatusTool the orderStatusTool to set
	 */
	public void setOrderStatusTool(OrderStatusTool pOrderStatusTool) {
		orderStatusTool = pOrderStatusTool;
	}
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		String countryCode= pRequest.getParameter("countryCode");
		String langCode=pRequest.getParameter("langCode");
		String customerName=pRequest.getParameter("customerName");
		String PO=pRequest.getParameter("PO");
		RepositoryItem repoItem = getOrderStatusTool().getEmailContent(countryCode,langCode);
		String emailGreeting=null,emailSubject=null,emailBody=null;
		if(repoItem!=null){
			 emailGreeting=(String) repoItem.getPropertyValue("greeting");
			 emailSubject=(String) repoItem.getPropertyValue("subject");
			 emailBody=(String) repoItem.getPropertyValue("body");
			 if(emailGreeting!=null && emailGreeting.contains("#CONTACTNAME#")){
                 if(customerName == null){
                	 emailGreeting=emailGreeting.replace("#CONTACTNAME#", "");
                 }else{
                	 emailGreeting=emailGreeting.replace("#CONTACTNAME#", customerName);
                 }
			 }
			 if(emailSubject!=null && emailSubject.contains("#SUBJECTPARAM#"))
				 emailSubject=emailSubject.replace("#SUBJECTPARAM#", PO);
		}
		 
		
		vlogDebug("emailGreeting is {0}", emailGreeting);
		vlogDebug("emailSubject is {0}", emailSubject);
		vlogDebug("emailBody is {0}", emailBody);
		
		
		String emailGreetingEscapeXml= StringEscapeUtils.escapeXml(emailGreeting);
		String emailSubjectEscapeXml= StringEscapeUtils.escapeXml(emailSubject);
		String emailBodyEscapeXml= StringEscapeUtils.escapeXml(emailBody);
		
		String emailGreetingEscape= StringEscapeUtils.escapeXml(emailGreetingEscapeXml);
		String emailSubjectEscape= StringEscapeUtils.escapeXml(emailSubjectEscapeXml);
		String emailBodyEscape= StringEscapeUtils.escapeXml(emailBodyEscapeXml);
 
		
		vlogDebug("After XML Encode emailGreeting is {0}", emailGreetingEscape);
		vlogDebug("After XML Encode emailSubject is {0}", emailSubjectEscape);
		vlogDebug("After XML Encode emailBody is {0}", emailBodyEscape);
		
		pRequest.setParameter("emailGreeting", emailGreetingEscape);	
		pRequest.setParameter("emailSubject", emailSubjectEscape);
		pRequest.setParameter("emailBody", emailBodyEscape);
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}	
	
}
