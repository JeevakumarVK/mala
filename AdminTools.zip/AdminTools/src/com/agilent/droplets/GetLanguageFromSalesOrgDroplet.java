package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class GetLanguageFromSalesOrgDroplet extends DynamoServlet  {
	
	private Map<String,String> countryLanguageMap;
	private Map<String,String> localeLanguageMap;
	
	/**
	 * @return the countryLanguageMap
	 */
	public Map<String, String> getCountryLanguageMap() {
		return countryLanguageMap;
	}

	/**
	 * @param pCountryLanguageMap the countryLanguageMap to set
	 */
	public void setCountryLanguageMap(Map<String, String> pCountryLanguageMap) {
		countryLanguageMap = pCountryLanguageMap;
	}

	public Map<String, String> getLocaleLanguageMap() {
		return localeLanguageMap;
	}

	public void setLocaleLanguageMap(Map<String, String> localeLanguageMap) {
		this.localeLanguageMap = localeLanguageMap;
	}
 
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		
		String countryCode=pRequest.getParameter("countryCode");
		if (countryCode==null||countryCode.equals("null")||countryCode.isEmpty())
			countryCode="US";
		String lanList= getCountryLanguageMap().get(countryCode);
		if(lanList ==null)
			lanList="English";
		String[] languages=lanList.split(":");
		Map<String, String> localeLangMap = new HashMap<String, String>();
		List<String> language=Arrays.asList(languages);
		for(String lang:language){
			String locale=getLocaleLanguageMap().get(lang);
			if(lang.contains("_"))
				lang=lang.substring(0, lang.indexOf("_"));
			if(locale==null)
				locale=getLocaleLanguageMap().get("English");
			localeLangMap.put(locale,lang);
		}
		pRequest.setParameter("localeLangMap", localeLangMap);
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}
	
}
