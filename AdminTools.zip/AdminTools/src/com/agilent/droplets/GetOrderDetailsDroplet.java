package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletException;

import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.OrderDetails;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.report.OrderStatusTool;

import atg.droplet.DropletException;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class GetOrderDetailsDroplet extends DynamoServlet  {
	
	private SapFunctions sapManager = null;
	private OrderStatusTool orderStatusTool;
	
	public OrderStatusTool getOrderStatusTool() {
		return orderStatusTool;
	}

	public void setOrderStatusTool(OrderStatusTool orderStatusTool) {
		this.orderStatusTool = orderStatusTool;
	}
	
	public SapFunctions getSapManager() {
		return sapManager;
	}

	public void setSapManager(SapFunctions pSapManager) {
		sapManager = pSapManager;
	}

	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		String orderId= pRequest.getParameter("orderId");
		/*String salesOrg=getOrderStatusTool().getSalesOrgFromSAPOrderId(orderId);
		if(salesOrg==null)
			salesOrg="04US";*/
		OrderDetails orderDetails =getSapManager().getOrderDetails(orderId, null, false, false);
//		orderDetails=getOrderStatusTool().updateTrackingDetails(orderDetails);		
		pRequest.setParameter("orderDetails", orderDetails);
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}	
	
}
