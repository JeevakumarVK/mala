package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class ProductLineDroplet extends DynamoServlet  {
	
	private List<String> productLine;

	public List<String> getProductLine() {
		return productLine;
	}

	public void setProductLine(List<String> productLine) {
		this.productLine = productLine;
	}
	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		
		pRequest.setParameter("productLine", getProductLine());
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}
	
	
}
