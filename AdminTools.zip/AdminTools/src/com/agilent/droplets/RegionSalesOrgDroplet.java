package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;
import static com.agilent.base.platform.Constants.OUTPUT_END;
import static com.agilent.base.platform.Constants.OUTPUT_START;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class RegionSalesOrgDroplet extends DynamoServlet  {
	
	private Repository siteRepository;
    private String siteId;
    private Map<String,String> countryCodeSalesOrgMap;
    private List<String> regions;
    
    public List<String> getRegions() {
		return regions;
	}

	public void setRegions(List<String> regions) {
		this.regions = regions;
	}

	public Repository getSiteRepository() {
		return siteRepository;
	}

	public void setSiteRepository(Repository siteRepository) {
		this.siteRepository = siteRepository;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	
	public Map<String, String> getCountryCodeSalesOrgMap() {
		return countryCodeSalesOrgMap;
	}

	public void setCountryCodeSalesOrgMap(Map<String, String> countryCodeSalesOrgMap) {
		this.countryCodeSalesOrgMap = countryCodeSalesOrgMap;
	}

	public Map<String,List<String>> getRegionSalesOrgMap() {
		Map<String,List<String>> regionSalesOrgMap=new HashMap<String,List<String>>();
		RepositoryItem site;
		try {
			site = getSiteRepository().getItem(getSiteId(), "siteConfiguration");
			if(site==null) 
				return regionSalesOrgMap;
	    	Set<RepositoryItem> regions=(Set<RepositoryItem>) site.getPropertyValue("regions");
	    	if(regions==null || regions.size()==0)
	    		return regionSalesOrgMap;
	    	for (RepositoryItem region:regions){
	    		if(region==null)
	    			break;
	    		//if(getRegions().contains(region.getPropertyValue("regionName"))){ 
		    		Set<RepositoryItem> countries=(Set<RepositoryItem>) region.getPropertyValue("countryList");
		    		if(countries==null || countries.size()==0){
		    			break;
		    		} 	
		    		List<String> salesOrgList=new ArrayList<String>();
		    		for(RepositoryItem country:countries){
		    			String countryCode=(String) country.getPropertyValue("countryTwoLetter");
		    			if(countryCode!=null ){
		    				String salesOrg=(String) country.getPropertyValue("salesOrg");
		    				if(salesOrg!=null && !salesOrgList.contains(salesOrg))
		    					salesOrgList.add(salesOrg);
		    			}	
		    		}
		    		if(salesOrgList==null || salesOrgList.size()==0)
		    			break;
		    		String regionName=(String) region.getPropertyValue("regionName");
		    		regionSalesOrgMap.put(regionName, salesOrgList);
	    		//}
	    	}
		} catch (RepositoryException e) {
			vlogError(e, "");
		}
    	return regionSalesOrgMap;
    } 
	public List<String> getSalesOrgList() {
		List<String> salesOrgList=new ArrayList<String>();
		RepositoryItem site;
		try {
			site = getSiteRepository().getItem(getSiteId(), "siteConfiguration");
			if(site==null) 
				return salesOrgList;
	    	Set<RepositoryItem> regions=(Set<RepositoryItem>) site.getPropertyValue("regions");
	    	if(regions==null || regions.size()==0)
	    		return salesOrgList;
	    	for (RepositoryItem region:regions){
	    		if(region==null)
	    			break;
	    		Set<RepositoryItem> countries=(Set<RepositoryItem>) region.getPropertyValue("countryList");
	    		if(countries==null || countries.size()==0){
	    			break;
	    		} 
	    		for(RepositoryItem country:countries){
	    				String salesOrg=(String) country.getPropertyValue("salesOrg");
	    				if(salesOrg!=null && !salesOrgList.contains(salesOrg))
	    					salesOrgList.add(salesOrg);
	    		}	
	    	}
		} catch (RepositoryException e) {
			vlogError(e, "");
		}
		//include INDIA
		List<String> addSalesOrg=new ArrayList<String>();
		addSalesOrg.add("04IN");
		addSalesOrg.add("04KR");
		for (String SalesOrg : addSalesOrg) {
			if(!salesOrgList.contains(SalesOrg)){
				salesOrgList.add(SalesOrg);
			}
		}
    	return salesOrgList;
    } 
	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		//pRequest.setParameter("salesOrgMap", getRegionSalesOrgMap());
		pRequest.setParameter("salesOrgList", getSalesOrgList());
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}
	
	
}
