package com.agilent.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class ResourceDetailsDroplet extends DynamoServlet  {
	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws IOException, ServletException{
		String key= pRequest.getParameter("key");
		String locale=pRequest.getParameter("locale");
		String resouceName=pRequest.getParameter("resouceName");
		String arg=pRequest.getParameter("arg");
		Locale loc = new Locale(locale);
		ResourceBundle rBundle = ResourceBundle.getBundle(resouceName, loc);
		String value = (String) rBundle.getObject(key);
		MessageFormat messageFormat = new MessageFormat(value);
		Object[] args = {arg};
		value = messageFormat.format(args);
		pRequest.setParameter("value", value);
	    pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}	
	
}
