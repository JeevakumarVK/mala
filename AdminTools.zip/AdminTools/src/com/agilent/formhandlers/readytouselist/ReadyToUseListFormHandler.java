/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.formhandlers.readytouselist;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.report.vo.Constants;
import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.platform.util.EncryptDecryptHelper;

import atg.adapter.gsa.GSARepository;
import atg.commerce.CommerceException;
import atg.commerce.gifts.GiftlistFormHandler;
import atg.commerce.gifts.GiftlistManager;
import atg.commerce.gifts.GiftlistTools;
import atg.droplet.DropletException;
import atg.multisite.SiteContextManager;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

/**
 * This class is extending ATG GiftlistFormHandler component and used for creating my lists by Marketing sales person.
 */
@SuppressWarnings(
    {"unchecked", "cast"})
public class ReadyToUseListFormHandler extends GiftlistFormHandler {

    private String mFinalReadyToUseUrl;
    private EncryptDecryptHelper mEnDecryptHelper;
    private String mReadyToUseListUrl;
    private String mRedirectUrl;
    private String mListName;
    public static final String CREATE_GIFT_LIST_LINK = "createGiftListLink";

    /**
     * This method will create gift and generates the ready to use list url based on the list name and part numbers
     * provided by Marketing sales person.
     * 
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleCreateGiftListLink(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        vlogDebug("Entering the method :: {0} in class: {1}", CREATE_GIFT_LIST_LINK, getClass().toString());
        GiftlistManager mgr = getGiftlistManager();
        String encryptedGiftListId = null;
        GiftlistTools gTools = mgr.getGiftlistTools();
        MutableRepositoryItem giftListRepositoryItem;
        MutableRepositoryItem item;
        String[] partNumberArray = pRequest.getParameterValues(Constants.LSCA_PARTNUMBER);
        if (partNumberArray != null && partNumberArray.length > 0) {
            try {
                giftListRepositoryItem = (MutableRepositoryItem) gTools.createGiftlist();
                vlogDebug("List Name :{0}", getListName());
                giftListRepositoryItem.setPropertyValue(gTools.getEventNameProperty(), getListName());
                giftListRepositoryItem.setPropertyValue(gTools.getEventTypeProperty(), Constants.READY_TO_USE_LIST);
                gTools.addItem(giftListRepositoryItem);
                setGiftlistId(giftListRepositoryItem.getRepositoryId());
                vlogDebug("GiftListId:" + getGiftlistId());

                List<String> container = Arrays.asList(partNumberArray);
                if (container != null && !container.isEmpty()) {
                    String partNumber = null;
                    String skuId = null;
                    String pSiteId = null;
                    String displayName = null;
                    String description = null;
                    Iterator<String> iterator = container.iterator();
                    while (iterator.hasNext()) {
                        partNumber = iterator.next();
                        vlogDebug("Part number :{0}", partNumber);
                        setProductId(partNumber);
                        setQuantity(1);
                        RepositoryItem sku = ((AgilentCatalogTools) getCatalogTools()).getSkuFromCatalogIdForQuickOrder(partNumber);
                        if (sku != null) {
                            skuId = sku.getRepositoryId();
                            item = gTools.createGiftlistItem();
                            item.setPropertyValue(gTools.getProductIdProperty(), partNumber);
                            item.setPropertyValue(gTools.getQuantityDesiredProperty(), getQuantity());
                            item.setPropertyValue(gTools.getCatalogRefIdProperty(), skuId);
                            RepositoryItem product = getCatalogTools().findProduct(partNumber);
                            if (product != null) {
                                partNumber = product.getRepositoryId();
                                displayName = (String) product.getPropertyValue(gTools.getDisplayNameProperty());
                                description = (String) product.getPropertyValue(gTools.getDescriptionProperty());
                            }
                            item.setPropertyValue(gTools.getDisplayNameProperty(), displayName);
                            item.setPropertyValue(gTools.getDescriptionProperty(), description);
                            pSiteId = SiteContextManager.getCurrentSiteId();
                            item.setPropertyValue(gTools.getSiteProperty(), pSiteId);
                            gTools.addItem(item);
                            vlogDebug("Gift Item :{0}", item);
                            gTools.addItemToGiftlist(giftListRepositoryItem.getRepositoryId(), item.getRepositoryId());
                        }
                    }
                }

                vlogDebug("GiftList Items are :{0}", mgr.getGiftlistItems(giftListRepositoryItem.getRepositoryId()));
                if (null != giftListRepositoryItem.getRepositoryId()) {
                    encryptedGiftListId = getEnDecryptHelper().baseEncrypt(giftListRepositoryItem.getRepositoryId());
                    setFinalReadyToUseUrl(MessageFormat.format(getReadyToUseListUrl(), encryptedGiftListId));
                    giftListRepositoryItem.setPropertyValue(Constants.RTU_CREATED_BY, Constants.MARKETING_SALES + Constants.HYPHEN + getGiftlistId());
                    giftListRepositoryItem.setPropertyValue(Constants.RTU_URL, getFinalReadyToUseUrl());
                }
                ((GSARepository) gTools.getGiftlistRepository()).updateItem(giftListRepositoryItem);

            } catch (CommerceException e) {
                vlogError("CommerceException", e);
            } catch (RepositoryException e) {
                vlogError("RepositoryException", e);
            }
        } else {
            addFormException(new DropletException("No part numbers were added to create ready to use list link."));
        }
        vlogDebug("Exiting the method :: {0} in class: {1}", CREATE_GIFT_LIST_LINK, getClass().toString());
        return checkFormRedirect(getRedirectUrl(), getRedirectUrl(), pRequest, pResponse);
    }

    /**
     * Gets the value of property mEnDecryptHelper
     * 
     * @return the value of property mEnDecryptHelper
     */
    public EncryptDecryptHelper getEnDecryptHelper() {
        return mEnDecryptHelper;
    }

    /**
     * Sets the value of property mEnDecryptHelper with value mEnDecryptHelper
     * 
     * @param mEnDecryptHelper
     *            for setting property mEnDecryptHelper
     */
    public void setEnDecryptHelper(EncryptDecryptHelper mEnDecryptHelper) {
        this.mEnDecryptHelper = mEnDecryptHelper;
    }

    /**
     * Gets the value of property mReadyToUseListUrl
     * 
     * @return the value of property mReadyToUseListUrl
     */
    public String getReadyToUseListUrl() {
        return mReadyToUseListUrl;
    }

    /**
     * Sets the value of property mReadyToUseListUrl with value mReadyToUseListUrl
     * 
     * @param mReadyToUseListUrl
     *            for setting property mReadyToUseListUrl
     */
    public void setReadyToUseListUrl(String mReadyToUseListUrl) {
        this.mReadyToUseListUrl = mReadyToUseListUrl;
    }

    /**
     * Gets the value of property mFinalReadyToUseUrl
     * 
     * @return the value of property mFinalReadyToUseUrl
     */
    public String getFinalReadyToUseUrl() {
        return mFinalReadyToUseUrl;
    }

    /**
     * Sets the value of property mFinalReadyToUseUrl with value mFinalReadyToUseUrl
     * 
     * @param mFinalReadyToUseUrl
     *            for setting property mFinalReadyToUseUrl
     */
    public void setFinalReadyToUseUrl(String mFinalReadyToUseUrl) {
        this.mFinalReadyToUseUrl = mFinalReadyToUseUrl;
    }

    /**
     * Gets the value of property mRedirectUrl
     * 
     * @return the value of property mRedirectUrl
     */
    public String getRedirectUrl() {
        return mRedirectUrl;
    }

    /**
     * Sets the value of property mRedirectUrl with value mRedirectUrl
     * 
     * @param mRedirectUrl
     *            for setting property mRedirectUrl
     */
    public void setRedirectUrl(String mRedirectUrl) {
        this.mRedirectUrl = mRedirectUrl;
    }

    /**
     * Gets the value of property listName
     * 
     * @return the value of property listName
     */
    public String getListName() {
        return mListName;
    }

    /**
     * Sets the value of property listName with value pListName
     * 
     * @param pListName
     *            for setting property listName
     */
    public void setListName(String pListName) {
        mListName = pListName;
    }
}
