package com.agilent.report;

import static com.agilent.base.platform.Constants.EMPTY;
import static com.agilent.base.platform.Constants.OUTPUT;
import static com.agilent.base.platform.Constants.OUTPUT_END;
import static com.agilent.base.platform.Constants.OUTPUT_START;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import com.agilent.base.common.services.OrderDetails;
import com.agilent.base.common.services.QuoteDetails;
import com.agilent.base.common.services.SAPUser;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.base.common.services.SapManager;
import com.agilent.base.platform.sap.client.BAPI_CUSTOMER_GETCONTACTLIST.BAPICONTACTADDRESSDATA;

import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class GetOrderDetailDroplet extends DynamoServlet {

	private SapFunctions sapManager = null;

	public SapFunctions getSapManager() {
		return sapManager;
	}

	public void setSapManager(SapFunctions pSapManager) {
		sapManager = pSapManager;
	}
	
	public String getOrderId(String orderId) {
		String orderCalId=orderId.trim();
		if(orderCalId.length() < 5)
		{
			orderCalId ="000000" + orderCalId;
		}else{
			while (orderCalId.length() < 10) {
				orderCalId = "0" + orderCalId;
	        }
		}	
		return orderCalId;
	}

	@Override
	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		Set<String> ordeIdSet = (Set<String>) pRequest.getObjectParameter(ParameterName.getParameterName("orderIdSet"));
		String ordeId = (String) pRequest.getObjectParameter(ParameterName.getParameterName("orderId"));
		if (ordeIdSet == null && ordeId != null) {
			ordeIdSet = new HashSet<String>();
			ordeIdSet.add(ordeId);
		}
		Map<String,OrderStatusSapContactVO> contactMap = null;
		if (ordeIdSet != null && !ordeIdSet.isEmpty()) {
			contactMap = new HashMap<String, OrderStatusSapContactVO>();
			for (String ordrid : ordeIdSet) {
				ordrid=getOrderId(ordrid);
				OrderDetails orderDetails = getSapManager().getOrderDetails(ordrid, null, false, false);
				if(orderDetails!=null){
					BAPICONTACTADDRESSDATA contact = getSapManager().getContactList(orderDetails.getOrderSoldToNumber(), orderDetails.getOrderContactNum());
					OrderStatusSapContactVO orderStatusSapContactVO = new OrderStatusSapContactVO();
					orderStatusSapContactVO.setContact(contact);
					orderStatusSapContactVO.setSalesOrg(orderDetails.getSalesOrg());
					
					if(contact!=null){
					contactMap.put(ordrid, orderStatusSapContactVO);
				}
				}
			}
		}
	    String elementName = pRequest.getParameter("elementName") != null ? pRequest.getParameter("elementName") : "element";
		if (contactMap != null && contactMap.size() > 0) {
			pRequest.setParameter(elementName, contactMap);
			pRequest.serviceLocalParameter(OUTPUT_START, pRequest,pResponse);
			pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
			pRequest.serviceLocalParameter(OUTPUT_END, pRequest,pResponse);
		} else {
			pRequest.serviceLocalParameter(EMPTY, pRequest, pResponse);
		 }
	}

}
