package com.agilent.report;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;

import javax.servlet.ServletException;

import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class GetOrderMailDroplet extends DynamoServlet{
private OrderStatusTool ordStatus=null;
	
public OrderStatusTool getOrdStatus() {
	return ordStatus;
}
public void setOrdStatus(OrderStatusTool ordStatus) {
	this.ordStatus = ordStatus;
}
	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String ordeId = (String) pRequest.getObjectParameter(ParameterName.getParameterName("orderId"));
	String message="Not Yet Sent";
		if(ordeId!=null){
			message= getOrdStatus().getTimeStampForOrderId(ordeId);
		}
		String elementName = pRequest.getParameter("elementName") != null ? pRequest.getParameter("elementName") : "element";
		pRequest.setParameter(elementName, message);
		pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
	}
}