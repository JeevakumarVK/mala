/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.report;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;

import javax.servlet.ServletException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import atg.core.util.StringUtils;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This droplet reads all info for promotion(s) applied to items in order.
 */
@SuppressWarnings("unchecked")
public class GetPromotionInfoDroplet extends DynamoServlet {

    /**
     * This method reads all info for promotion(s) applied to items in order.
     */
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        RepositoryItem comItem = (RepositoryItem) pRequest.getObjectParameter("commerceItem");
        RepositoryItem priceInfo = (RepositoryItem) comItem.getPropertyValue("priceInfo");

        if (priceInfo == null) {
            pRequest.serviceParameter("default", pRequest, pResponse);
            return;
        }

        Boolean discounted = (Boolean) priceInfo.getPropertyValue("discounted");
        List<RepositoryItem> promoitems = (List<RepositoryItem>) priceInfo.getPropertyValue("adjustments");
        if (promoitems != null && discounted) {
            String condType = "";
            double condValue = 0.0;
            String promoCode = "";
            for (RepositoryItem promo : promoitems) {
                if (promo.getPropertyValue("pricingModel") != null) {
                    RepositoryItem promotion = (RepositoryItem) promo.getPropertyValue("pricingModel");
                    RepositoryItem coupon = (RepositoryItem) promo.getPropertyValue("coupon");
                    condType = (String) promotion.getPropertyValue("promoConditionType");
                    if (coupon != null) {
                        promoCode = (String) coupon.getPropertyValue("id");
                    }
                    if ((Integer) promotion.getPropertyValue("type") == 0) {
                        String rule = (String) promotion.getPropertyValue("pmdlRule");
                        if (!StringUtils.isEmpty(rule)) {
                            try {
                                InputSource is = new InputSource();
                                is.setCharacterStream(new StringReader(rule));
                                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                                DocumentBuilder dBuilder;
                                dBuilder = dbFactory.newDocumentBuilder();
                                Document doc = dBuilder.parse(is);
                                doc.getDocumentElement().normalize();
                                NodeList nodes = doc.getElementsByTagName("discount-structure");

                                if (nodes != null) {
                                    Node node = nodes.item(0);
                                    NamedNodeMap attribs = node.getAttributes();
                                    Node adjuster = attribs.getNamedItem("adjuster");
                                    String value = adjuster.getNodeValue();
                                    if (!StringUtils.isEmpty(value)) {
                                        condValue = Double.parseDouble(value);
                                    }
                                }
                                break;
                            } catch (Exception exception) {
                                vlogError("Exception Caught :: {0}", exception);
                            }
                        }
                    }
                }
            }
            pRequest.setParameter("condType", condType);
            pRequest.setParameter("condValue", condValue);
            pRequest.setParameter("promoCode", promoCode);
            pRequest.serviceParameter("output", pRequest, pResponse);
        } else {
            pRequest.serviceParameter("default", pRequest, pResponse);
        }
    }
}
