/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.transaction.TransactionManager;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.AgilentOrderTools;
import com.agilent.base.mya.weborder.MyAOrderStatusUpdater;
import com.agilent.base.platform.SystemException;
import com.agilent.base.platform.errorhandler.IErrorHandler;
import com.agilent.base.platform.validator.IValidator;
import com.agilent.base.rest.integration.jitterbit.JitterbitIntegrationService;
import com.agilent.report.ReportsTool.ReportType;
import com.agilent.report.vo.OrderManagementVO;

import atg.commerce.CommerceException;
import atg.commerce.order.OrderManager;
import atg.commerce.order.OrderTools;
import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.userprofiling.email.MessageContentProcessor;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;
import atg.userprofiling.Profile;

/**
 * This Form Handler handles order report in admin tools.
 */
@SuppressWarnings({"unchecked", "cast"})
public class OrderManagementToolFormHandler extends GenericFormHandler {

    private Date mStartDate;
    private Date mEndDate;
    private ReportsTool mReportsTool;
    private String mSuccussUrl;
    protected static final String REPORT_TYPE = "reporttype";
    private List<RepositoryItem> mResultList;
    private String mWebOrders;
    private String mSapOrders;

    private OrderTools mOrderTools;
    private OrderManager mOrderManager;
    private String mOrderItemDescriptorName;
    private String mOrderProcessedBy;
    private String mSapOrderId;
    private String mDefaultFlag;
    private String[] mSalesOrg;
    private String[] site;
    private String punchout;
    private List<OrderManagementVO> resultListVo;
    private int orderCount;
    private Integer orderStatus;
    private String comments;
    private TransactionManager transactionManager;
    private String orderAcknowledged;
    private Map<Integer, String> orderStatusMap;
    private String email;
    private String cc;
    private String bcc;
    private TemplateEmailSender emailSender;
    private MessageContentProcessor contentProcessor;
    private String emailTemplateURL;
    private String messageFrom;
    private IValidator validator;
    private IErrorHandler mExceptionHandler;
    private Repository profileRepository;
    private String states;
    private String sendEmail;
    private String addBcc;
    private String locale;
    /* Changes start for the jaguar project */
    private boolean amazonOrder;
    private boolean mCheckFirstOrder;
    private String xmlPath;
    private String fileName;
    private String cancelReason;
    //DCCOM-22800 - for integration with jitterbit for eMethod products
    private JitterbitIntegrationService mJitterbitIntgnService ;
    private MyAOrderStatusUpdater orderStatusUpdater;
    
    //DCCOM-22966 - for SAP order when AWS call fails
    private AgilentOrder mAgilentOrder;
    protected static final String SAAS_UPDATE_SUCCESS_URL = "/admin/ordermngr/orderStatusTool.jsp?orderId=";
    
	/**
	 * @return the agilentOrder
	 */
	public AgilentOrder getAgilentOrder() {
		return mAgilentOrder;
	}

	/**
	 * @param agilentOrder the agilentOrder to set
	 */
	public void setAgilentOrder(AgilentOrder agilentOrder) {
		this.mAgilentOrder = agilentOrder;
	}
    
	/**
	 * @return the mJitterbitIntgnService
	 */
	public JitterbitIntegrationService getJitterbitIntgnService() {
		return mJitterbitIntgnService;
	}

	/**
	 * @param mJitterbitIntgnService the mJitterbitIntgnService to set
	 */
	public void setJitterbitIntgnService(JitterbitIntegrationService mJitterbitIntgnService) {
		this.mJitterbitIntgnService = mJitterbitIntgnService;
	}
    


    /**
     * 
     * @return isCheckFirstOrder
     */
    public boolean isCheckFirstOrder() {
        return mCheckFirstOrder;
    }

    /**
     * 
     * @param pCheckFirstOrder
     */

    public void setCheckFirstOrder(boolean pCheckFirstOrder) {
        mCheckFirstOrder = pCheckFirstOrder;
    }

    /**
     * 
     * @return isAmazonOrder
     */
    public boolean isAmazonOrder() {
        return amazonOrder;
    }

    /**
     * 
     * @param amazonOrder
     */
    public void setAmazonOrder(boolean amazonOrder) {
        this.amazonOrder = amazonOrder;
    }
    /* Changes end for the jaguar project */

    /**
     * @return the addBcc
     */
    public String getAddBcc() {
        return addBcc;
    }

    /**
     * @param pAddBcc
     *            the addBcc to set
     */
    public void setAddBcc(String pAddBcc) {
        addBcc = pAddBcc;
    }

    public String getLocale() {
        return locale;
    }

    public void setLocale(String locale) {
        this.locale = locale;
    }

    /**
     * @return the sendEmail
     */
    public String getSendEmail() {
        return sendEmail;
    }

    /**
     * @param pSendEmail
     *            the sendEmail to set
     */
    public void setSendEmail(String pSendEmail) {
        sendEmail = pSendEmail;
    }

    /**
     * @return the states
     */
    public String getStates() {
        return states;
    }

    /**
     * @param pStates
     *            the states to set
     */
    public void setStates(String pStates) {
        states = pStates;
    }

    public Repository getProfileRepository() {
        return profileRepository;
    }

    public void setProfileRepository(Repository profileRepository) {
        this.profileRepository = profileRepository;
    }

    public IErrorHandler getExceptionHandler() {
        return mExceptionHandler;
    }

    public void setExceptionHandler(IErrorHandler pExceptionHandler) {
        this.mExceptionHandler = pExceptionHandler;
    }

    public IValidator getValidator() {
        return validator;
    }

    public void setValidator(IValidator validator) {
        this.validator = validator;
    }

    public String getMessageFrom() {
        return messageFrom;
    }

    public void setMessageFrom(String messageFrom) {
        this.messageFrom = messageFrom;
    }

    public String getEmailTemplateURL() {
        return emailTemplateURL;
    }

    public void setEmailTemplateURL(String emailTemplateURL) {
        this.emailTemplateURL = emailTemplateURL;
    }

    public MessageContentProcessor getContentProcessor() {
        return contentProcessor;
    }

    public void setContentProcessor(MessageContentProcessor contentProcessor) {
        this.contentProcessor = contentProcessor;
    }

    public TemplateEmailSender getEmailSender() {
        return emailSender;
    }

    public void setEmailSender(TemplateEmailSender emailSender) {
        this.emailSender = emailSender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getBcc() {
        return bcc;
    }

    public void setBcc(String bcc) {
        this.bcc = bcc;
    }

    public Map<Integer, String> getOrderStatusMap() {
        return orderStatusMap;
    }

    public void setOrderStatusMap(Map<Integer, String> orderStatusMap) {
        this.orderStatusMap = orderStatusMap;
    }

    public Integer getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(Integer orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderAcknowledged() {
        return orderAcknowledged;
    }

    public void setOrderAcknowledged(String orderAcknowledged) {
        this.orderAcknowledged = orderAcknowledged;
    }

    public TransactionManager getTransactionManager() {
        return transactionManager;
    }

    public void setTransactionManager(TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public List<OrderManagementVO> getResultListVo() {
        return resultListVo;
    }

    public void setResultListVo(List<OrderManagementVO> resultVo) {
        this.resultListVo = resultVo;
    }

    public String getPunchout() {
        return punchout;
    }

    public void setPunchout(String punchout) {
        this.punchout = punchout;
    }

    public String[] getSite() {
        return site;
    }

    public void setSite(String[] site) {
        this.site = site;
    }

    private boolean mHasSearched = false;

    /**
     * Gets the value of salesOrg
     * 
     * @return returns the property salesOrg
     */
    public String[] getSalesOrg() {
        return mSalesOrg;
    }

    /**
     * Sets the value of property salesOrg with value pSalesOrg
     * 
     * @param pSalesOrg
     *            the salesOrg to set
     */
    public void setSalesOrg(String[] pSalesOrg) {
        mSalesOrg = pSalesOrg;
    }

    /**
     * Gets the value of defaultFlag
     * 
     * @return returns the property defaultFlag
     */
    public String getDefaultFlag() {
        return mDefaultFlag;
    }

    /**
     * Sets the value of property defaultFlag with value pDefaultFlag
     * 
     * @param pDefaultFlag
     *            the defaultFlag to set
     */
    public void setDefaultFlag(String pDefaultFlag) {
        mDefaultFlag = pDefaultFlag;
    }

    /**
     * Gets the value of orderProcessedBy
     * 
     * @return returns the property orderProcessedBy
     */
    public String getOrderProcessedBy() {
        return mOrderProcessedBy;
    }

    /**
     * Sets the value of property orderProcessedBy with value pOrderProcessedBy
     * 
     * @param pOrderProcessedBy
     *            the orderProcessedBy to set
     */
    public void setOrderProcessedBy(String pOrderProcessedBy) {
        mOrderProcessedBy = pOrderProcessedBy;
    }

    /**
     * Gets the value of sapOrderId
     * 
     * @return returns the property sapOrderId
     */
    public String getSapOrderId() {
        return mSapOrderId;
    }

    /**
     * Sets the value of property sapOrderId with value pSapOrderId
     * 
     * @param pSapOrderId
     *            the sapOrderId to set
     */
    public void setSapOrderId(String pSapOrderId) {
        mSapOrderId = pSapOrderId;
    }

    /**
     * Gets the value of orderItemDescriptorName
     * 
     * @return returns the property orderItemDescriptorName
     */
    public String getOrderItemDescriptorName() {
        return mOrderItemDescriptorName;
    }

    /**
     * Sets the value of property orderItemDescriptorName with value pOrderItemDescriptorName
     * 
     * @param pOrderItemDescriptorName
     *            the orderItemDescriptorName to set
     */
    public void setOrderItemDescriptorName(String pOrderItemDescriptorName) {
        mOrderItemDescriptorName = pOrderItemDescriptorName;
    }

    /**
     * Gets the value of orderManager
     * 
     * @return returns the property orderManager
     */
    public OrderManager getOrderManager() {
        return mOrderManager;
    }

    /**
     * Sets the value of property orderManager with value pOrderManager
     * 
     * @param pOrderManager
     *            the orderManager to set
     */
    public void setOrderManager(OrderManager pOrderManager) {
        mOrderManager = pOrderManager;
    }

    /**
     * Gets the value of orderTools
     * 
     * @return returns the property orderTools
     */
    public OrderTools getOrderTools() {
        return mOrderTools;
    }

    /**
     * Sets the value of property orderTools with value pOrderTools
     * 
     * @param pOrderTools
     *            the orderTools to set
     */
    public void setOrderTools(OrderTools pOrderTools) {
        mOrderTools = pOrderTools;
    }

    /**
     * Gets the value of resultOrderItem
     * 
     * @return returns the property resultOrderItem
     */
    public List<RepositoryItem> getResultOrderItem() {
        return mResultOrderItem;
    }

    /**
     * Sets the value of property resultOrderItem with value pResultOrderItem
     * 
     * @param pResultOrderItem
     *            the resultOrderItem to set
     */
    public void setResultOrderItem(List<RepositoryItem> pResultOrderItem) {
        mResultOrderItem = pResultOrderItem;
    }

    private String mErrorUrl;
    private String mOrderId;
    private String[] mOrderType;
    private String mResultOrder;
    private List<RepositoryItem> mResultOrderItem;
    private String mUpdateOrderSuccessUrl;
    private String mUpdateOrderErrorUrl;
    private String mOrderTrack;
    private String mOrderQuoteRenewed;
    /* Changes Start for the jaguar project */
    private String mPartnerName;
    private String mPartnerOrderNumber;
    private String mContractQuoteNumber;
    private String productLine;
   /**
     * @return the mPartnerName
     */
    public String getPartnerName() {
        return mPartnerName;
    }

    /**
     * @param mPartnerName
     *            the mPartnerName to set
     */
    public void setPartnerName(String pPartnerName) {
        mPartnerName = pPartnerName;
    }

    /**
     * @return the mPartnerOrderNumber
     */
    public String getPartnerOrderNumber() {
        return mPartnerOrderNumber;
    }

    /**
     * @param mPartnerOrderNumber
     *            the mPartnerOrderNumber to set
     */
    public void setPartnerOrderNumber(String pPartnerOrderNumber) {
        mPartnerOrderNumber = pPartnerOrderNumber;
    }

    /**
     * @return the mContractQuoteNumber
     */
    public String getContractQuoteNumber() {
        return mContractQuoteNumber;
    }

    /**
     * @param mPartnerOrderNumber
     *            the mPartnerOrderNumber to set
     */
    public void setContractQuoteNumber(String pContractQuoteNumber) {
        mContractQuoteNumber = pContractQuoteNumber;
    }

    /* Changes end for the jaguar project */

    /**
     * @return the mResultOrder
     */
    public String getUpdateOrderErrorUrl() {
        return mUpdateOrderErrorUrl;
    }

    /**
     * @param mResultOrder
     *            the mResultOrder to set
     */
    public void setUpdateOrderErrorUrl(String pUpdateOrderErrorUrl) {
        mUpdateOrderErrorUrl = pUpdateOrderErrorUrl;
    }

    /**
     * @return the mOrderTrack
     */
    public String getOrderTrack() {
        return mOrderTrack;
    }

    /**
     * @param mOrderTrack
     *            the mOrderTrack to set
     */
    public void setOrderTrack(String pOrderTrack) {
        this.mOrderTrack = pOrderTrack;
    }

    /**
     * @return the mOrderQuoteRenewed
     */
    public String getOrderQuoteRenewed() {
        return mOrderQuoteRenewed;
    }

    /**
     * @param mOrderTrack
     *            the mOrderQuoteRenewed to set
     */
    public void setOrderQuoteRenewed(String orderQuoteRenewed) {
        this.mOrderQuoteRenewed = orderQuoteRenewed;
    }

    /**
     * @return the mResultOrder
     */
    public String getUpdateOrderSuccessUrl() {
        return mUpdateOrderSuccessUrl;
    }

    /**
     * @param mResultOrder
     *            the mResultOrder to set
     */
    public void setUpdateOrderSuccessUrl(String pUpdateOrderSuccessUrl) {
        mUpdateOrderSuccessUrl = pUpdateOrderSuccessUrl;
    }

    /**
     * @return the mResultOrder
     */
    public String getResultOrder() {
        return mResultOrder;
    }

    /**
     * @param mResultOrder
     *            the mResultOrder to set
     */
    public void setResultOrder(String pResultOrder) {
        mResultOrder = pResultOrder;
    }

    /**
     * @return the mOrderType
     */
    public String[] getOrderType() {
        return mOrderType;
    }

    /**
     * @param mOrderType
     *            the mOrderType to set
     */
    public void setOrderType(String[] pOrderType) {
        this.mOrderType = pOrderType;
    }

    /**
     * Gets the value of orderId
     * 
     * @return returns the property orderId
     */
    public String getOrderId() {
        return mOrderId;
    }

    /**
     * Sets the value of property orderId with value pOrderId
     * 
     * @param pOrderId
     *            the orderId to set
     */
    public void setOrderId(String pOrderId) {
        if (pOrderId != null && !pOrderId.isEmpty()) {
            pOrderId.trim();
        }
        mOrderId = pOrderId;
    }

    public Date getStartDate() {
        return mStartDate;
    }

    public void setStartDate(Date pStartDate) {
        mStartDate = pStartDate;
    }

    public Date getEndDate() {
        return mEndDate;
    }

    public void setEndDate(Date pEndDate) {
        mEndDate = pEndDate;
    }

    public ReportsTool getReportsTool() {
        return mReportsTool;
    }

    public void setReportsTool(ReportsTool pReportsTool) {
        mReportsTool = pReportsTool;
    }

    public String getSuccussUrl() {
        return mSuccussUrl;
    }

    public void setSuccussUrl(String pSuccussUrl) {
        mSuccussUrl = pSuccussUrl;
    }

    public String getErrorUrl() {
        return mErrorUrl;
    }

    public void setErrorUrl(String pErrorUrl) {
        mErrorUrl = pErrorUrl;
    }

    /**
     * Gets the value of webOrders
     * 
     * @return returns the property webOrders
     */
    public String getWebOrders() {
        return mWebOrders;
    }

    /**
     * Sets the value of property webOrders with value webOrders
     * 
     * @param webOrders
     *            the webOrders to set
     */
    public void setWebOrders(String webOrders) {
        mWebOrders = webOrders;
    }

    /**
     * Gets the value of sapOrders
     * 
     * @return returns the property sapOrders
     */
    public String getSapOrders() {
        return mSapOrders;
    }

    /**
     * Sets the value of property sapOrders with value sapOrders
     * 
     * @param sapOrders
     *            the sapOrders to set
     */
    public void setSapOrders(String sapOrders) {
        mSapOrders = sapOrders;
    }

    /**
     * Gets the value of resultList
     * 
     * @return returns the property resultList
     */
    public List<RepositoryItem> getResultList() {
        return mResultList;
    }

    /**
     * Sets the value of property resultList with value resultList
     * 
     * @param resultList
     *            the resultList to set
     */
    public void setResultList(List<RepositoryItem> pResultList) {
        mResultList = pResultList;
    }
   

	private Profile profile=null;
	public Profile getProfile() {
        return profile;
	}

  public void setProfile(Profile pProfile) {
         profile = pProfile;
  }


    
    /**
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleParseOrder(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        ReportType reporttype = ReportsTool.ReportType.ORDERMANAGMENTREPORT;
        setResultOrderItem(getReportsTool().orderTool(reporttype, getResultOrder()));
        /* Changes start for the jaguar project */
        Boolean[] amazonCheckConditions = new Boolean[2];
        amazonCheckConditions = getReportsTool().isAmazonFirstOrderCheck(getResultOrder(), amazonCheckConditions);
        setCheckFirstOrder(amazonCheckConditions[0]);
        setAmazonOrder(amazonCheckConditions[1]);
        
        String orderProcessedBy=null;
		if (getResultOrderItem() != null && getResultOrderItem().size() > 0) {
			setSapOrderId((String) getResultOrderItem().get(0).getPropertyValue("sapOrderId"));
			setEmail((String) getResultOrderItem().get(0).getPropertyValue("orderProcessedBy"));
			orderProcessedBy=((String) getResultOrderItem().get(0).getPropertyValue("orderProcessedBy"));
			if ( orderProcessedBy==null || orderProcessedBy.isEmpty())
			{
				String email = (String) getProfile().getPropertyValue("email");
				vlogInfo("New EMAIL--->{0}", email);
				if (email!=null)
				{
					setEmail(email);
				}
			}
		}

        
        /* Changes end for the jaguar project */
        if (getResultOrderItem() != null && getResultOrderItem().size() > 0) {
            setSapOrderId((String) getResultOrderItem().get(0).getPropertyValue("sapOrderId"));
            //setEmail((String) getResultOrderItem().get(0).getPropertyValue("orderProcessedBy"));
            List<RepositoryItem> orderHistory = (List<RepositoryItem>) getResultOrderItem().get(0).getPropertyValue("orderHistory");
            if (orderHistory != null && orderHistory.size() > 0) {
                Integer status = (Integer) orderHistory.get(orderHistory.size() - 1).getPropertyValue("orderStatus");
                setOrderStatus(status);
                vlogInfo("Order Status from Order History IF Block --->{0}", getOrderStatusMap().get(getOrderStatus().toString()));
            } else {
            	//Start - AMS-963 OrderManagement tool - Incorrect status showing for Success Orders
            	 if(null != getSapOrderId() && ((String)getResultOrderItem().get(0).getPropertyValue("orderType")).equalsIgnoreCase("SAP")) {
                 	vlogInfo("SAP Order ID --->{0}", getSapOrderId());
                 	setOrderStatus(5);
                 	vlogInfo("SAP Order Type IF Block --->{0}", ((String)getResultOrderItem().get(0).getPropertyValue("orderType")));
                 } else {
                	 setOrderStatus(0);
                	 vlogInfo("SAP Order Type ELSE Block--->{0}", ((String)getResultOrderItem().get(0).getPropertyValue("orderType")));
                 }//End - AMS-963 OrderManagement tool - Incorrect status showing for Success Orders
            }
        }
        return true;
    }

    public boolean handleParsePunchoutOrder(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        ReportType reporttype = ReportsTool.ReportType.PUNCHOUT;
        setResultOrderItem(getReportsTool().getPunchoutOrder(reporttype, getResultOrder()));
        return true;
    }

    /**
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleUpdateOrder(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        String orderId = getOrderId();

        MutableRepository mutRep = (MutableRepository) getOrderTools().getOrderRepository();

        try {
            MutableRepositoryItem orderItem = mutRep.getItemForUpdate(orderId, getOrderItemDescriptorName());
            orderItem.setPropertyValue("orderProcessedBy", getOrderProcessedBy());
            orderItem.setPropertyValue("sapOrderId", getSapOrderId());
            orderItem.setPropertyValue("orderType", "SAP");
            mutRep.updateItem(orderItem);
        } catch (RepositoryException e) {
            vlogError("RepositoryException Thrown :: {0}", e);
            return checkFormRedirect("null", getUpdateOrderErrorUrl() + "?orderId=" + orderId, pRequest, pResponse);
        }
        return checkFormRedirect(getUpdateOrderSuccessUrl() + "?orderId=" + orderId, "null", pRequest, pResponse);
    }

    public boolean handleUpdateOrderLsca(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        String orderId = getOrderId();
        
        boolean flag = validate();
        String emailsent = "";
        AgilentOrder agilentOrder = null;
        String sapOrderId = ""  ;
		if (flag) {
            try {
            	agilentOrder = (AgilentOrder) getOrderManager().loadOrder(getOrderId());
    			//DCCOM-22800 integration with jitterbit for eMethod products
            	
                String profileId = (String) agilentOrder.getPropertyValue("profileId");
                RepositoryItem user = getProfileRepository().getItem(profileId, "user");
    			 String digitalCartType = ((AgilentOrderTools) getOrderTools()).checkOrderContainDigitalItems(agilentOrder);
    	            if(StringUtils.isNotBlank(digitalCartType) && getOrderStatus() != null && getOrderStatus().equals(5)) {
    	            	if(StringUtils.isNotBlank(getSapOrderId()) ) {
    	            		sapOrderId = getSapOrderId();
    	            	}
    	            	boolean saasCallStatus = getJitterbitIntgnService().constructOrderDetailsForSAAS(agilentOrder.getId(), user, sapOrderId);
    	            	if(saasCallStatus) {
    	            		emailsent = updatingOrderItem(agilentOrder, user);
    	            	}
    	            	else {
    	            		
    	            		addFormException(new DropletException("Unable to make SAAS call. Hence, updation of the order with sap order id is stopped."));
    	            	}
    	            }
    	            else {
    	            	emailsent = updatingOrderItem(agilentOrder, user);
    	            }
               
            } catch (RepositoryException e) {
                vlogError(e, "");
                return checkFormRedirect("/admin/ordermngr/orderStatusTool.jsp" + "?orderId=" + orderId, "/admin/ordermngr/orderStatusTool.jsp" + "?orderId=" + orderId, pRequest,
                        pResponse);
            } catch (CommerceException e1) {
                vlogError(e1, "");
            } catch (Exception e) {
    			// TODO Auto-generated catch block
            	vlogError(e, "");
    		}
            
            finally {
                // td.end(rollback);
            }
        }
        return checkFormRedirect("/admin/ordermngr/orderStatusTool.jsp" + "?orderId=" + orderId + emailsent, "/admin/ordermngr/orderStatusTool.jsp" + "?orderId=" + orderId,
                pRequest, pResponse);
    }
    
    public String updatingOrderItem(AgilentOrder agilentOrder, RepositoryItem user) {

        String orderId = getOrderId();
        MutableRepository mutRep = (MutableRepository) getOrderTools().getOrderRepository();
        
        String emailsent = "";
       
		try {
            	
                vlogDebug("Get MutableRepositoryItem for Id {0}", orderId);
                MutableRepositoryItem orderItem = mutRep.getItemForUpdate(orderId, getOrderItemDescriptorName());
                vlogDebug("Get MutableRepositoryItem for {0}", orderItem);
                Calendar cal = Calendar.getInstance();
                if (getOrderStatus() != null) {
                    MutableRepositoryItem orderHistoryInfo = mutRep.createItem("orderHistoryInfo");
                    orderHistoryInfo.setPropertyValue("comments", getComments());
                    orderHistoryInfo.setPropertyValue("orderStatus", getOrderStatus());
                    orderHistoryInfo.setPropertyValue("history", getOrderStatusMap().get(getOrderStatus().toString()) + ":" + cal.getTime());
                    mutRep.addItem(orderHistoryInfo);
                    List<RepositoryItem> orderHistoryList = (List<RepositoryItem>) orderItem.getPropertyValue("orderHistory");
                    if (orderHistoryList == null) {
                        orderHistoryList = new ArrayList<RepositoryItem>();
                    }
                    orderHistoryList.add(orderHistoryInfo);
                    orderItem.setPropertyValue("orderHistory", orderHistoryList);
                    if (getOrderStatus().equals(6)) {
                        try {
                            // For all orders
                            orderItem.setPropertyValue("orderTrack", "CANCELLED");
                            setSapOrderId("CANCELLED");

                            // For amazon orders only
                            
                            if (null != agilentOrder.getPartnerName() && agilentOrder.getPartnerName().equalsIgnoreCase("AMAZON")) {
                                processAmazonCancelOrder(agilentOrder.getPartnerOrderNumber());
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            addFormException(new DropletException("Unable to create cancel order XML"));
                        }
                    }
                }
                if (orderItem.getPropertyValue("OrderAcknowledgedTime") == null && getOrderAcknowledged() != null) {
                    orderItem.setPropertyValue("OrderAcknowledgedTime", cal.getTime());
                    orderItem.setPropertyValue("isAcknowledged", true);
                }
                if (!getSapOrderId().isEmpty() && !getEmail().isEmpty()) {
                    orderItem.setPropertyValue("orderProcessedBy", getEmail());
                    orderItem.setPropertyValue("sapOrderId", getSapOrderId());
                    orderItem.setPropertyValue("orderType", "SAP");
                }
                mutRep.updateItem(orderItem);
                
                if (!getSapOrderId().isEmpty() && !getEmail().isEmpty() && !StringUtils.isEmpty(getSendEmail()) && "true".equals(getSendEmail()) && user != null) {
    
                    String email = (String) user.getPropertyValue("email");
                    sendEmailForOrderCovertedToSAP(orderItem, email);
                    emailsent = "&emailsent=true";
                }
                //Sending web order update to MyAgilent 
                getOrderStatusUpdater().sendStausUpdateToMyA(agilentOrder, true);
                
            } catch (RepositoryException e) {
                vlogError(e, "");
                
            }catch (Exception e) {
    			// TODO Auto-generated catch block
            	vlogError(e, "");
    		}
            
           
        
        return emailsent;
    }

    public void sendEmailForOrderCovertedToSAP(RepositoryItem order, String email) {
        TemplateEmailInfoImpl emailInfo = new TemplateEmailInfoImpl();
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("order", order);
        params.put("requestLocale", getLocale());
        emailInfo.setContentProcessor(getContentProcessor());
        if (!getLocale().isEmpty() && getLocale().contains("zh")) {
            emailInfo.setMessageSubject("\u60A8\u7684\u8BA2\u5355\u5DF2\u751F\u6210\uFF0C\u6B63\u5F0F\u8BA2\u5355\u53F7\uFF1A " + order.getPropertyValue("sapOrderId"));
        } else {
            emailInfo.setMessageSubject("Your Order has been Placed : Order Number  " + order.getPropertyValue("sapOrderId"));
        }
        emailInfo.setMessageFrom(getMessageFrom());
        emailInfo.setMessageTo(email);
        emailInfo.setMessageCc(getCc());
        if (!StringUtils.isEmpty(getAddBcc())) {
            if (!StringUtils.isEmpty(getBcc()))
                setBcc(getBcc() + "," + getAddBcc());
            else
                setBcc(getAddBcc());
        }
        vlogDebug("BCC emails:" + getBcc());
        emailInfo.setMessageBcc(getBcc());
        emailInfo.setTemplateURL(getEmailTemplateURL());
        emailInfo.setTemplateParameters(params);
        List<String> recipents = new ArrayList<String>();
        recipents.add(getEmail());
        try {
            getEmailSender().sendEmailMessage(emailInfo, recipents);
        } catch (TemplateEmailException e) {
            vlogError(e, "exception found while sending Email Error:{0}", e);
        }
    }

    public void beforeGet(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
        PerformanceMonitor.startOperation("OrderManagementRecord", "LastThreeDaysRecords");
        setBcc(null);
        setCc(null);
        setComments(null);
        setOrderAcknowledged("");
        if ("true".equals(pRequest.getLocalParameter("clear"))) {
            getFormExceptions().removeAllElements();
        }
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.ORDERMANAGMENTREPORT);
        try {
            if (!isHasSearched() && (getResultList() == null || getResultList().isEmpty()) && (getResultListVo() == null || getResultListVo().isEmpty())) {
                Date currentDate = new Date();
                Calendar cacl = new GregorianCalendar();
                cacl.setTime(currentDate);
                cacl.add(Calendar.DAY_OF_MONTH, -3);
                Date lastThreeDays = cacl.getTime();
                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                setResultListVo(getReportsTool().orderToolLsca(reporttype, getOrderCount(), currentDate, lastThreeDays));
                PerformanceMonitor.endOperation("OrderManagementRecord", "LastThreeDaysRecords");
                if (getResultListVo() == null || getResultListVo().size() <= 0) {
                    addFormException(new DropletException("No data found for last three days"));
                }
                setStartDate(lastThreeDays);
                setEndDate(currentDate);
            }
        } catch (Exception e) {
            vlogError(e, "exception found while access the data Error:{0}", e);
        }
    }

    public boolean handleOrderTool(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        List<RepositoryItem> resultItem = Collections.EMPTY_LIST;
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.ORDERMANAGMENTREPORT);
        try {
            Date startDate = getStartDate();
            Date endDate = getEndDate();
            String[] orderType = getOrderType();
            String orderId = getOrderId().trim();
            String salesOrg = getSalesOrg()[0];
            vlogDebug("Given from date: {0}", startDate);
            if (!orderId.isEmpty()) {
                if (!orderId.startsWith("atg-Mig-") && !orderId.startsWith("o")&&!orderId.startsWith("w")) {
                    orderId = "atg-Mig-" + orderId;
                }
                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                resultItem = getReportsTool().orderTool(reporttype, orderId);
            } else {
                Calendar cal = Calendar.getInstance();
                cal.setTime(endDate);
                cal.add(Calendar.HOUR, 24);
                endDate = cal.getTime();
                vlogDebug("Given to date: {0}", endDate);
                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                resultItem = getReportsTool().orderToolBySalesOrg(reporttype, startDate, endDate, salesOrg, orderType);
                setHasSearched(true);
            }

            if (!resultItem.isEmpty()) {
                setResultList(resultItem);
            } else {
                setResultList(resultItem);
                addFormException(new DropletException("No data found"));
            }

        } catch (Exception e) {
            vlogError(e, "exception found while access the data Error:{0}", e);
        }

        return checkFormRedirect("", "", pRequest, pResponse);
    }

    public boolean handleOrderToolLsca(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.ORDERMANAGMENTREPORT);
        PerformanceMonitor.startOperation("OrderManagementTool", "SearchOperation");
        try {
            String partnerName = null;
            Date startDate = getStartDate();
            Date endDate = getEndDate();
            String[] orderType = getOrderType();
            String orderId = getOrderId().trim();
            String[] salesOrg = getSalesOrg();
            String[] site = getSite();
            String orderTrack = getOrderTrack();
            String orderQuoteRenewed = getOrderQuoteRenewed();
            if (null != getPartnerName())
                partnerName = getPartnerName().toUpperCase();
            String partnerOrder = getPartnerOrderNumber();
            String contractQuoteNumber = getContractQuoteNumber();
            RepositoryItem[] resultItems = null;
            RepositoryItem orderItem = null;
            vlogDebug("Given from date: {0}", startDate);

            if (!orderId.isEmpty()) {
                if (!orderId.startsWith("atg-Mig-") && !orderId.startsWith("o") && !orderId.startsWith("w")) {
                    orderId = "atg-Mig-" + orderId;
                }
                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                List<OrderManagementVO> resultList = new ArrayList<OrderManagementVO>();
                resultItems = getReportsTool().orderToolLsca(reporttype, orderId);
                if (resultItems != null && resultItems.length > 0) {
                    resultList.add(getReportsTool().populateOrderManagementVo(resultItems[0], false, null, null));
                }
                setResultListVo(resultList);
                setHasSearched(true);

            } else {
                Calendar cal = Calendar.getInstance();
                cal.setTime(endDate);
                cal.add(Calendar.HOUR, 24);
                endDate = cal.getTime();
                List<OrderManagementVO> resultList = new ArrayList<OrderManagementVO>();
                vlogDebug("Given to date: {0}", endDate);

                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                if (getPunchout().equals("Punchout")) {
                    List<RepositoryItem> punchoutList = getReportsTool().punchoutOrders(startDate, endDate, salesOrg);
                    for (RepositoryItem punchoutItem : punchoutList) {
                        orderItem = (RepositoryItem) punchoutItem.getPropertyValue("basketItem");
                        if (orderItem != null) {
                            OrderManagementVO OrderMgmtVo = getReportsTool().populateOrderManagementVo(orderItem, true, punchoutItem, null);
                            resultList.add(OrderMgmtVo);
                        }
                    }
                } else {
                    resultItems = getReportsTool().orderToolBySalesOrg(reporttype, startDate, endDate, salesOrg, site, orderType, orderTrack, partnerName, partnerOrder,
                            orderQuoteRenewed, contractQuoteNumber);
                    if (resultItems != null && resultItems.length > 0) {
                        PerformanceMonitor.startOperation("OrderManagement", "PopulateVO");
                        for (RepositoryItem item : resultItems) {
                        	if(getProductLine() != null) {
                        		OrderManagementVO OrderMgmtVo = getReportsTool().populateOrderManagementVo(item, false, null, getProductLine());
                        		if(OrderMgmtVo.getProductLine() != null) {
                        			resultList.add(OrderMgmtVo);
                        		}
                        	} 
                        	else {
	                            OrderManagementVO OrderMgmtVo = getReportsTool().populateOrderManagementVo(item, false, null, null);
	                            resultList.add(OrderMgmtVo);
                        	}
                        }
                        PerformanceMonitor.endOperation("OrderManagement", "PopulateVO");
                    }
                }

                setResultListVo(resultList);
                setHasSearched(true);
            }
            PerformanceMonitor.endOperation("OrderManagementTool", "SearchOperation");
            if ((getResultListVo() == null) || getResultListVo().size() == 0) {
                addFormException(new DropletException("No data found"));
            }

        } catch (Exception e) {
            vlogError(e, "exception found while access the data Error:{0}", e);
        }

        return checkFormRedirect("/admin/ordermngr/orderManagementTool.jsp", "/admin/ordermngr/orderManagementTool.jsp", pRequest, pResponse);

    }

    public boolean handleOrdertoExcel(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.ORDERMANAGMENTREPORT);
        ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);

        pResponse.getResponse().setHeader("Content-disposition", "attachment;filename=OrderReport.xls");
        pResponse.getResponse().setContentType("application/vnd.ms-excel");
        getReportsTool().exportLSCAService(getResultListVo(), reporttype, pResponse.getOutputStream());
        return false;
    }

    /**
     * Gets the value of hasSearched
     * 
     * @return returns the property hasSearched
     */
    public boolean isHasSearched() {
        return mHasSearched;
    }

    /**
     * Sets the value of property hasSearched with value hasSearched
     * 
     * @param hasSearched
     *            the hasSearched to set
     */
    public void setHasSearched(boolean hasSearched) {
        mHasSearched = hasSearched;
    }

    public boolean validate() {
        if (!getOrderAcknowledged().equals("orderAcknowledged")) {
            getExceptionHandler().handleSystemException(new SystemException("order_acknowledged", new Object[]
                {}), "routing", this);
            return false;
        }
		//AMS-968 - Issues with Order Manager Tool
        if ((getSapOrderId().isEmpty()) && (!getEmail().isEmpty()) && !getOrderStatus().equals(0) && !getOrderStatus().equals(1) && !getOrderStatus().equals(2) && !getOrderStatus().equals(3) && !getOrderStatus().equals(4) && !getOrderStatus().equals(6)) {
            getExceptionHandler().handleSystemException(new SystemException("sap_order_mandatory", new Object[]
                {}), "routing", this);
            return false;
        }
        if ((!getSapOrderId().isEmpty()) && getEmail().isEmpty() && !getOrderStatus().equals(6)) {
            getExceptionHandler().handleSystemException(new SystemException("email_order_mandatory", new Object[]
                {}), "routing", this);
            return false;
        }
        return true;
    }

    /**
     * This method will create the cancel order XML
     * 
     * @param partnerOrderNumber
     * @param pComments
     * @throws IOException
     */
    private void processAmazonCancelOrder(String partnerOrderNumber) throws IOException {
        vlogDebug("Entering the processAmazonCancelOrder method");
        BufferedWriter bufferReader = null;
        try {
            StringBuffer responseBuffer = new StringBuffer();
            responseBuffer.append("<?xml version='1.0' encoding='utf-8'?>");
            responseBuffer.append("<ORDER_ACKNOWLEDGEMENT>");
            responseBuffer.append("<PARTNER_ORDER_NUMBER>").append(partnerOrderNumber).append("</PARTNER_ORDER_NUMBER>");
            responseBuffer.append("<STATUS_CODE>Failure</STATUS_CODE>").append("<CANCEL_REASON>").append(getCancelReason()).append("</CANCEL_REASON>")
                    .append("</ORDER_ACKNOWLEDGEMENT>");

            bufferReader = new BufferedWriter(new java.io.FileWriter(new File(getXmlPath() + getFileName() + partnerOrderNumber + ".xml")));
            bufferReader.write(responseBuffer.toString());

        } catch (Exception e) {
            addFormException(new DropletException(e.getMessage() + "Unable to create cancel order XML"));
        } finally {
            if (bufferReader != null) {
                bufferReader.flush();
                bufferReader.close();
            }

        }
        vlogDebug("Exiting the processAmazonCancelOrder method");
    }
    /**
     * This method will update the saasCallStatus for SAP order with eMethod products
     * 
     * @param OrderId
     * @throws IOException
     */
	public boolean handleUpdateSAASCallStatus(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
			throws ServletException, IOException {

		String orderId = getOrderId();
		vlogDebug("Entering handle update saas call method{0}", orderId);

		String emailsent = "";
		AgilentOrder agilentOrder = null;

		try {
			agilentOrder = getAgilentOrder();
			vlogDebug("agilentOrder: {0}", agilentOrder);
			if (agilentOrder != null) {
				String profileId = (String) agilentOrder.getPropertyValue("profileId");
				RepositoryItem user = getProfileRepository().getItem(profileId, "user");
				boolean saasCall = (Boolean) agilentOrder.getPropertyValue("saasCallSucess");

				String digitalCartType = ((AgilentOrderTools) getOrderTools())
						.checkOrderContainDigitalItems(agilentOrder);
				if (StringUtils.isNotBlank(digitalCartType) && !saasCall) {

					boolean saasCallStatus = getJitterbitIntgnService()
							.constructOrderDetailsForSAAS(agilentOrder.getId(), user, null);
					vlogDebug("saasCallStatus from ordermanagement form handler: {0}", saasCallStatus);
					if (!saasCallStatus) {
						vlogDebug("SAAS call was unsuccessful");
						addFormException(new DropletException("Unable to make SAAS call. Please try again."));
					}

				} else {
					addFormException(new DropletException("This order does not contain eDelivery Parts"));
				}
			} else {
				addFormException(new DropletException("This order does not exist"));
			}
			setAgilentOrder(null);

		} catch (RepositoryException e) {
			vlogError(e, "RepositoryException exception is thrown");
			return checkFormRedirect(SAAS_UPDATE_SUCCESS_URL + orderId, SAAS_UPDATE_SUCCESS_URL + orderId, pRequest, pResponse);
		
		}catch (Exception e) {
			// TODO Auto-generated catch block
			vlogError(e, "Exception is thrown");
		}

		
		return checkFormRedirect(SAAS_UPDATE_SUCCESS_URL + orderId + emailsent, SAAS_UPDATE_SUCCESS_URL + orderId, pRequest, pResponse);
	}

    /**
     * @return the xmlPath
     */
    public String getXmlPath() {
        return xmlPath;
    }

    /**
     * @param xmlPath
     *            the xmlPath to set
     */
    public void setXmlPath(String xmlPath) {
        this.xmlPath = xmlPath;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName
     *            the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the cancelReason
     */
    public String getCancelReason() {
        return cancelReason;
    }

    /**
     * @param cancelReason
     *            the cancelReason to set
     */
    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

	
	public String getProductLine() {
		return productLine;
	}

	
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

    /**
     * @return the orderStatusUpdater
     */
    public MyAOrderStatusUpdater getOrderStatusUpdater() {
        return orderStatusUpdater;
    }

    /**
     * @param orderStatusUpdater the orderStatusUpdater to set
     */
    public void setOrderStatusUpdater(MyAOrderStatusUpdater orderStatusUpdater) {
        this.orderStatusUpdater = orderStatusUpdater;
    }
}
