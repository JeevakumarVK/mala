package com.agilent.report;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.poi.util.IOUtils;

import com.agilent.base.commerce.order.AgilentCommerceItem;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.OrderDetails;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.sap.client.BAPI_CUSTOMER_GETCONTACTLIST.BAPICONTACTADDRESSDATA;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.report.vo.OrderUploadVO;

import atg.commerce.CommerceException;
import atg.commerce.order.CommerceItem;
import atg.commerce.order.OrderManager;
import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.repository.Repository;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.UploadedFile;
import atg.userprofiling.Profile;
import atg.userprofiling.email.MessageContentProcessor;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;

public class OrderStatusFormHandler extends GenericFormHandler{
	
	private String orderId;
	private SapFunctions mSapManager;
	private OrderDetails orderDetails;
	private String orderStatusSuccessUrl;
	private String orderStatusErrorUrl;
	private OrderStatusTool orderStatusTool;
	private String salesOrg;
	private String csrName;
	private String recipientEmail;
	private String copyEmail;
	private String bccEmail;
	private String[] orderIdList;
	private String[] sapSaleOrgList;
	private Map<String,OrderStatusSapContactVO> contactMap ;
	private boolean mSearched = false;
	private String[] emailLang;
	private String[] mOrderList;
	private String[] mCustName;
	private String mCustomerName;
	private Object mAttachment;
	private String mEmailBody="";
	private String mStoreURL;
	private String addbccEmail;
	private EncryptDecryptHelper encryptDecryptHelper;
	private OrderManager mOrderManager;
	
	public OrderManager getOrderManager() {
		return mOrderManager;
	}

	public void setOrderManager(OrderManager mOrderManager) {
		this.mOrderManager = mOrderManager;
	}

	/**
	 * @return the encryptDecryptHelper
	 */
	public EncryptDecryptHelper getEncryptDecryptHelper() {
		return encryptDecryptHelper;
	}

	/**
	 * @param pEncryptDecryptHelper the encryptDecryptHelper to set
	 */
	public void setEncryptDecryptHelper(EncryptDecryptHelper pEncryptDecryptHelper) {
		encryptDecryptHelper = pEncryptDecryptHelper;
	}

	/**
	 * @return the addbccEmail
	 */
	public String getAddbccEmail() {
		return addbccEmail;
	}

	/**
	 * @param pAddbccEmail the addbccEmail to set
	 */
	public void setAddbccEmail(String pAddbccEmail) {
		addbccEmail = pAddbccEmail;
	}

	/**
	 * @return the storeURL
	 */
	public String getStoreURL() {
		return mStoreURL;
	}

	/**
	 * @param pStoreURL the storeURL to set
	 */
	public void setStoreURL(String pStoreURL) {
		mStoreURL = pStoreURL;
	}

	/**
	 * @return the emailBody
	 */
	public String getEmailBody() {
		return mEmailBody;
	}

	/**
	 * @param pEmailBody the emailBody to set
	 */
	public void setEmailBody(String pEmailBody) {
		mEmailBody = pEmailBody;
	}

	/**
	 * @return the attachment
	 */
	public Object getAttachment() {
		return mAttachment;
	}

	/**
	 * @param pAttachment the attachment to set
	 */
	public void setAttachment(Object pAttachment) {
		mAttachment = pAttachment;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return mCustomerName;
	}

	/**
	 * @param pCustomerName the customerName to set
	 */
	public void setCustomerName(String pCustomerName) {
		mCustomerName = pCustomerName;
	}

	/**
	 * @return the custName
	 */
	public String[] getCustName() {
		return mCustName;
	}

	/**
	 * @param pCustName the custName to set
	 */
	public void setCustName(String[] pCustName) {
		mCustName = pCustName;
	}

	/**
	 * @return the orderList
	 */
	public String[] getOrderList() {
		return mOrderList;
	}

	/**
	 * @param pOrderList the orderList to set
	 */
	public void setOrderList(String[] pOrderList) {
		mOrderList = pOrderList;
	}

	/**
	 * @return the emailLang
	 */
	public String[] getEmailLang() {
		return emailLang;
	}

	/**
	 * @param pEmailLang the emailLang to set
	 */
	public void setEmailLang(String[] pEmailLang) {
		emailLang = pEmailLang;
	}

	/**
	 * @return the searched
	 */
	public boolean isSearched() {
		return mSearched;
	}

	/**
	 * @param pSearched the searched to set
	 */
	public void setSearched(boolean pSearched) {
		mSearched = pSearched;
	}

	public Map<String, OrderStatusSapContactVO> getContactMap() {
		return contactMap;
	}

	public void setContactMap(Map<String, OrderStatusSapContactVO> pContactMap) {
		contactMap = pContactMap;
	}

	public String[] getSapSaleOrgList() {
		return sapSaleOrgList;
	}

	public void setSapSaleOrgList(String[] pSapSaleOrgList) {
		sapSaleOrgList = pSapSaleOrgList;
	}

	private String emailBulkTemplateURL;
	private Repository orderRepository;
	
	private Profile profile=null;
	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile pProfile) {
		profile = pProfile;
	}

	public Repository getOrderRepository() {
		return orderRepository;
	}

	public void setOrderRepository(Repository pOrderRepository) {
		orderRepository = pOrderRepository;
	}

	public String[] getOrderIdList() {
		return orderIdList;
	}

	public void setOrderIdList(String[] pOrderIdList) {
		orderIdList = pOrderIdList;
	}

	private String[] emailToList;
	public String[] getEmailToList() {
		return emailToList;
	}

	public void setEmailToList(String[] pEmailToList) {
		emailToList = pEmailToList;
	}

	private String language;
	private String emailGreeting;
	private String emailSubject;
	private TemplateEmailSender emailSender;
    private MessageContentProcessor contentProcessor;
    private String emailTemplateURL;
    private String messageFrom;
    private String localeString;
    private String defaultLocale;
    private Locale locale;
    private Object orderCsv;
    private Set<String> orderUpldSet=null;
    private String mDefaultConditionType;
    
   	public String getDefaultConditionType() {
		return mDefaultConditionType;
	}

	public void setDefaultConditionType(String pDefaultConditionType) {
		mDefaultConditionType = pDefaultConditionType;
	}

	public Set<String> getOrderUpldSet() {
		return orderUpldSet;
	}

	public void setOrderUpldSet(Set<String> pOrderUpldSet) {
		orderUpldSet = pOrderUpldSet;
	}

	public Object getOrderCsv() {
   		return orderCsv;
   	}

   	public void setOrderCsv(Object pOrderCsv) {
   		orderCsv = pOrderCsv;
   	}
    public String getLocaleString() {
		return localeString;
	}

	public void setLocaleString(String localeString) {
		this.localeString = localeString;
	}

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}
	
	public String getDefaultLocale() {
		return defaultLocale;
	}

	public void setDefaultLocale(String defaultLocale) {
		this.defaultLocale = defaultLocale;
	}

	public String getMessageFrom() {
		return messageFrom;
	}

	public void setMessageFrom(String messageFrom) {
		this.messageFrom = messageFrom;
	}

	public String getEmailTemplateURL() {
		return emailTemplateURL;
	}

	public void setEmailTemplateURL(String emailTemplateURL) {
		this.emailTemplateURL = emailTemplateURL;
	}

	public MessageContentProcessor getContentProcessor() {
		return contentProcessor;
	}

	public void setContentProcessor(MessageContentProcessor contentProcessor) {
		this.contentProcessor = contentProcessor;
	}

	public TemplateEmailSender getEmailSender() {
		return emailSender;
	}

	public void setEmailSender(TemplateEmailSender emailSender) {
		this.emailSender = emailSender;
	}
	
	
	public String getEmailGreeting() {
		return emailGreeting;
	}

	public void setEmailGreeting(String emailGreeting) {
		this.emailGreeting = emailGreeting;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public SapFunctions getmSapManager() {
		return mSapManager;
	}

	public void setmSapManager(SapFunctions mSapManager) {
		this.mSapManager = mSapManager;
	}

	public String getCsrName() {
		return csrName;
	}

	public void setCsrName(String csrName) {
		this.csrName = csrName;
	}

	public String getRecipientEmail() {
		return recipientEmail;
	}

	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}

	public String getCopyEmail() {
		return copyEmail;
	}

	public void setCopyEmail(String copyEmail) {
		this.copyEmail = copyEmail;
	}

	public String getBccEmail() {
		return bccEmail;
	}

	public void setBccEmail(String bccEmail) {
		this.bccEmail = bccEmail;
	}

	public String getSalesOrg() {
		return salesOrg;
	}

	public void setSalesOrg(String salesOrg) {
		this.salesOrg = salesOrg;
	}

	public OrderStatusTool getOrderStatusTool() {
		return orderStatusTool;
	}

	public void setOrderStatusTool(OrderStatusTool orderStatusTool) {
		this.orderStatusTool = orderStatusTool;
	}

	public String getOrderStatusSuccessUrl() {
		return orderStatusSuccessUrl;
	}

	public void setOrderStatusSuccessUrl(String orderStatusSuccessUrl) {
		this.orderStatusSuccessUrl = orderStatusSuccessUrl;
	}

	public String getOrderStatusErrorUrl() {
		return orderStatusErrorUrl;
	}

	public void setOrderStatusErrorUrl(String orderStatusErrorUrl) {
		this.orderStatusErrorUrl = orderStatusErrorUrl;
	}

	public OrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public SapFunctions getSapManager() {
	    return mSapManager;
	}
	
	public void setSapManager( SapFunctions sapManager) {
	    mSapManager = sapManager;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		orderId=orderId.trim();
		if(orderId.length() < 5)
		{
			orderId ="000000" + orderId;
		}else{
			while (orderId.length() < 10) {
				orderId = "0" + orderId;
	        }
		}	
		this.orderId = orderId;
	}
	
	public String getEmailBulkTemplateURL() {
		return emailBulkTemplateURL;
	}

	public void setEmailBulkTemplateURL(String pEmailBulkTemplateURL) {
		emailBulkTemplateURL = pEmailBulkTemplateURL;
	}
	
	

	public boolean handleOrderStatus( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
		vlogDebug("handleOrderStatus ::: Call handleOrderStatus for Order Status Tool ");
		if (getSapManager().IsSAPAvailable()) {
			try {
				getSAPOrderDetails();
			} catch (Exception exception) {
				getFormExceptions().removeAllElements();
				addFormException(new DropletException("Backend error, please try again after some time."));
				vlogError(exception, "");
			}
		}else{
			getFormExceptions().removeAllElements();
			addFormException(new DropletException("Not able to search due to SAP Service down, please try again after some time."));
			vlogDebug("SAP down");
		}
		return checkFormRedirect(getOrderStatusSuccessUrl()+"?clear=true" , getOrderStatusSuccessUrl(), pRequest, pResponse);
	}
	
	/**
	 * Get the Order details from SAP
	 */
	public void getSAPOrderDetails()
	{
		vlogDebug("Order Status Tool :: SAPOrderDetails" + getOrderId());
		setCsrName((String) getProfile().getPropertyValue("email"));
		/*String salesOrg=getOrderStatusTool().getSalesOrgFromSAPOrderId(getOrderId());
		if(salesOrg==null)
			salesOrg="04US";
		setSalesOrg(salesOrg);*/
		vlogDebug("getSAPOrderDetails Get SAP order ID :: " + getOrderId());
		OrderDetails orderDetail =getSapManager().getOrderDetails(getOrderId(), null, false, false);
		if (orderDetail!=null){
			setSalesOrg(orderDetail.getSalesOrg());
			
			vlogDebug(getOrderId() + "orderDetail.getItems().size() " + orderDetail.getItems().size());
		}else{
			vlogDebug("orderDetail is null for Order ID:"+getOrderId());
		}
		
		
		if (orderDetail!= null && orderDetail.getItems().size()>0){
			BAPICONTACTADDRESSDATA contact = getSapManager().getContactList(orderDetail.getOrderSoldToNumber(), orderDetail.getOrderContactNum());
			/**
			 *  Incident ID IM13395976
			 *  Added null check for contact object attributes like email , firstname and lastname
			 *  Author -- Rohit/Mohan July 02 2014
			 *  
			 */
			
			RepositoryItem order = getOrderStatusTool().getSAPOrderFromId(getOrderId());
			try {
				if(null != order){
				AgilentOrder agilentOrder = (AgilentOrder) getOrderManager().loadOrder(order.getRepositoryId());
				if(null != agilentOrder && agilentOrder.isPpsOrder() ){
					vlogInfo("Inside PPS Order section");
					List<CommerceItem> commerceItems =agilentOrder.getCommerceItems();
					List<LineItem> items = orderDetail.getItems();
					for (LineItem item:items ){
						String catId = item.getCatId();
						vlogInfo("Category Id from Status call {0}",catId);
						for(CommerceItem commerceItem : commerceItems){
							if (commerceItem instanceof AgilentCommerceItem) {
								String catalogId = ((AgilentCommerceItem) commerceItem).getAuxiliaryData().getProductId();
								vlogInfo("Catalog Id of product {0}",catalogId);
								if(null != catalogId && catalogId.equalsIgnoreCase(catId)){
		                        String ppsClipFlag = ((AgilentCommerceItem) commerceItem).getPpsClip();
		                        item.setClipValue(ppsClipFlag);
		                        vlogInfo("ppsClipFlag {0}",ppsClipFlag);
		                        break;
								}
		                    }
						}
					}
					
				}
			} 
			}catch (CommerceException e) {
				vlogError("CommerceException",e);
			}
             
			
			if(contact != null)
			{
				if(contact.getEMAIL() != null)
				{
					 vlogDebug("contact.getEMAIL() "+ contact.getEMAIL());
					 setRecipientEmail(contact.getEMAIL());
				}
				if(contact.getFIRSTNAME() != null || contact.getLASTNAME()!=null)
				{
					vlogDebug("contact.getFIRSTNAME() "+ contact.getFIRSTNAME() + "  contact.getLASTNAME() "+contact.getLASTNAME());
					setCustomerName((contact.getFIRSTNAME()+" "+contact.getLASTNAME()).trim());
				}
			}
			
			
			/**
			 *  code ends here
			 *  Author -- Rohit/Mohan July 02 2014
			 *  
			 */
			if(orderDetail.getBillingAddress().size()>0)
			{
				vlogDebug(getOrderId() + "Biiling address ---- " + orderDetail.getBillingAddress().get(0).getCompanyName() + orderDetail.getBillingAddress().get(0).getAddress3() + 
			    		orderDetail.getBillingAddress().get(0).getLand1() + orderDetail.getBillingAddress().get(0).getAddress1() + orderDetail.getBillingAddress().get(0).getAddress2() + orderDetail.getBillingAddress().get(0).getCity() + orderDetail.getBillingAddress().get(0).getState() + 
			    		orderDetail.getBillingAddress().get(0).getPostalCode() + orderDetail.getBillingAddress().get(0).getCountry());
			}
			if(orderDetail.getShippingAddress().size()>0)
			{
						vlogDebug(getOrderId() + "Shipping address ---- " + orderDetail.getShippingAddress().get(0).getCompanyName() + orderDetail.getShippingAddress().get(0).getAddress3() + 
			    		orderDetail.getShippingAddress().get(0).getLand1() + orderDetail.getShippingAddress().get(0).getAddress1() + orderDetail.getShippingAddress().get(0).getAddress2() + orderDetail.getShippingAddress().get(0).getCity() + orderDetail.getShippingAddress().get(0).getState() + 
			    		orderDetail.getShippingAddress().get(0).getPostalCode() + orderDetail.getShippingAddress().get(0).getCountry());
			}		
			    setOrderDetails(orderDetail);
				getOrderStatusTool().insertAccessHistory(getOrderId());
			}
		
		else{
			getFormExceptions().removeAllElements();
			addFormException(new DropletException("This Sales Order is either invalid or may have been cancelled. If you have any questions, please contact Agilent via e-mail by clicking on the <a href='http://www.chem.agilent.com/en-US/Contact-US/Pages/ContactUs.aspx'> Contact Us</a> link."));
		}
	
	}
	
	
	public boolean handleOrderStatusUpload(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
		
		Object orderCsvData = getOrderCsv();
		Set<String> orderSet=null; 
		if (orderCsvData != null) {
			UploadedFile  uploadedCsv=(UploadedFile) orderCsvData;
			if(uploadedCsv.getFileSize() > 0){
				setOrderList(null);
				setEmailToList(null);
				setEmailLang(null);
				setSapSaleOrgList(null);
				setOrderIdList(null);
			    byte[] byteArray = uploadedCsv.toByteArray();
			    String readFileString = new String(byteArray);
				String[] split = readFileString.replaceAll("\\r","").split("\\n");
				if (split != null && split.length > 0) {
					orderSet = new HashSet<String>(Arrays.asList(split));
				}
			}else{
				addFormException(new DropletException("Please select a file to upload."));
			}
		}
		if (orderSet != null) {
			setOrderUpldSet(orderSet);
		}
		
		return checkFormRedirect(getOrderStatusSuccessUrl(), getOrderStatusErrorUrl(), pRequest, pResponse);

	}
	public boolean handleSendBulkMail( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
		if(getOrderIdList()!=null&&getOrderIdList().length>0 ){
			TemplateEmailInfoImpl emailInfo = new TemplateEmailInfoImpl();
			HashMap<String,Object> params = new HashMap<String,Object>();
			String requester=(String) getProfile().getPropertyValue("email");
			emailInfo.setContentProcessor(getContentProcessor());
			emailInfo.setMessageFrom(getMessageFrom());
			emailInfo.setMessageCc(getCopyEmail());
			if(!StringUtils.isEmpty(getAddbccEmail())){
				if(!StringUtils.isEmpty(getBccEmail()))
					setBccEmail(getBccEmail()+","+getAddbccEmail());
				else
					setBccEmail(getAddbccEmail());
			}
			emailInfo.setMessageBcc(getBccEmail());
			emailInfo.setTemplateURL(getEmailBulkTemplateURL());
			boolean isException=false;
			int pos=0;
			List <OrderUploadVO> orderUploadList=new ArrayList<OrderUploadVO>();
			if(getOrderIdList()!=null&& getOrderList()!=null){
				for (String string : getOrderList()) {
					for (String orderId : getOrderIdList()) {
						if(orderId.equalsIgnoreCase(string)){
							if(getEmailToList()[pos].isEmpty()){
								isException=true;
								addFormException(new DropletException("Please Enter Valid MailTo Email ID"));
								break;
							}
							OrderUploadVO orderUploadVO = new OrderUploadVO();
							orderUploadVO.setOrderId(orderId);
							orderUploadVO.setEmail(getEmailToList()[pos]);
							orderUploadVO.setLanguage(getEmailLang()[pos]);
							orderUploadVO.setSalesOrg(getSapSaleOrgList()[pos]);
							orderUploadVO.setCustName(getCustName()[pos]);
							orderUploadList.add(orderUploadVO);
							break;
						}
					}
					pos++;
				}	
			}
			if(!isException){
				for (OrderUploadVO orderUploadVO : orderUploadList) {
					
					emailInfo.setMessageTo(orderUploadVO.getEmail());
					List<String> recipents = new ArrayList<String>();
					recipents.add(orderUploadVO.getEmail());
					try {
					OrderDetails orderDetail =getSapManager().getOrderDetails(orderUploadVO.getOrderId(), orderUploadVO.getSalesOrg(),false,false);
					params.put("orderId", orderUploadVO.getOrderId());
					params.put("emailLang", orderUploadVO.getLanguage());
					String po="",status="",date="",subject="";
					if(orderDetail.getItems().size()>0){
						BAPICONTACTADDRESSDATA contact = getSapManager().getContactList(orderDetail.getOrderSoldToNumber(), orderDetail.getOrderContactNum());
						setCustomerName(contact.getFIRSTNAME()+" "+contact.getLASTNAME());
						po=orderDetail.getItems().get(0).getPurchaseOrder();
						status=orderDetail.getItems().get(0).getDeliveryStatus();
						date=orderDetail.getItems().get(0).getDocumentDate();
						subject="Your Order Number is: "+orderDetail.getItems().get(0).getPurchaseOrder();
					}	
					params.put("name", getCustomerName());
					params.put("PO",po);
					params.put("status",status );
					params.put("date", date);
					params.put("netAmount", orderDetail.getSubTotal());
					emailInfo.setTemplateParameters(params);
					emailInfo.setMessageSubject(subject);
					if(!StringUtils.isEmpty(getAddbccEmail())){
				      if(!StringUtils.isEmpty(getBccEmail()))
							setBccEmail(getBccEmail()+","+getAddbccEmail());
						else
							setBccEmail(getAddbccEmail());
					}		
					emailInfo.setMessageBcc(getBccEmail());
					getEmailSender().sendEmailMessage(emailInfo, recipents) ;
					getOrderStatusTool().insertMailHistory(orderUploadVO.getOrderId(),orderUploadVO.getEmail(), requester,orderUploadVO.getSalesOrg());
					} catch (TemplateEmailException e) {
						vlogError(e, "exception found while sending Email Error:{0}", e);
					} 
				}
			}
		}else{
			addFormException(new DropletException("You have not selected any of the sales orders to send mails to the customer.<br/> Please select the sales order numbers to send mails to the customers."));
		}
		return checkFormRedirect(getOrderStatusSuccessUrl(), getOrderStatusErrorUrl(), pRequest, pResponse);

	}
	
	public boolean handleSendEmail( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
		//String requester=(String) getProfile().getPropertyValue("firstName");
		Object attachment=getAttachment();
	       File file=null;
		TemplateEmailInfoImpl emailInfo = new TemplateEmailInfoImpl();
    	HashMap<String,Object> params = new HashMap<String,Object>();
		params.put("orderId", getOrderId());
		String emailBodyEncoded=getEmailBody();
		String emailBody=StringEscapeUtils.unescapeHtml4(emailBodyEncoded);
		vlogDebug("email after Decode {0}", emailBody);
		String encryptOrderId=null;
		try {
			encryptOrderId=getEncryptDecryptHelper().encrypt(getOrderId());
		} catch (ApplicationException e1) {
			vlogDebug("Encryption FAILED :", e1);
		}
		if(emailBody!=null && emailBody.contains("#ORDERURL#"))
			emailBody=emailBody.replace("#ORDERURL#", "<a href='"+getStoreURL()+"/myaccount/sapOrderDetails.jsp?src=hl&orderId="+encryptOrderId+"'>"+getOrderId()+"</a>");
		if(emailBody!=null && emailBody.contains("#EMAILGREETING#")){
			emailBody=emailBody.replace("#EMAILGREETING#",getEmailGreeting());
			params.put("greetings","");
		}else{
			params.put("greetings",getEmailGreeting());
		}
		params.put("body", emailBody);
		if (getLocale()==null)
			setLocale( new Locale(getLanguage()));
		params.put("locale",getLocale());
		params.put("status",pRequest.getParameter("status"));
		params.put("PO",pRequest.getParameter("PO"));
		params.put("date",pRequest.getParameter("date"));
		params.put("netAmount",pRequest.getParameter("netAmount"));
		emailInfo.setContentProcessor(getContentProcessor());
		emailInfo.setMessageSubject(getEmailSubject());
		emailInfo.setMessageFrom(getMessageFrom());
		emailInfo.setMessageTo(getRecipientEmail());
		emailInfo.setMessageCc(getCopyEmail());
		if(!StringUtils.isEmpty(getAddbccEmail())){
			if(!StringUtils.isEmpty(getBccEmail()))
				setBccEmail(getBccEmail()+","+getAddbccEmail());
			else
				setBccEmail(getAddbccEmail());
		}
		emailInfo.setMessageBcc(getBccEmail());
		 emailInfo.setTemplateURL(getEmailTemplateURL());
		emailInfo.setTemplateParameters(params);
		if (attachment!=null && attachment instanceof UploadedFile){
			UploadedFile attachedUploadFile=(UploadedFile) attachment;
			if(attachedUploadFile.getFileSize()>0){
	            String fName = attachedUploadFile.getFilename();
	            String fileName=null;
	            if(fName.contains("\\")){
					fileName= new String(fName.substring(fName.lastIndexOf('\\')+1, fName.length()));
				}else{
					fileName=fName;
				}
	            file = new File(fileName);
	            FileOutputStream output = openOutputStream(file);
	            InputStream inputStream = attachedUploadFile.getInputStream();
				IOUtils.copy(inputStream, output);
				inputStream.close();
	            output.close();
	            File[] attachments={file};
	         
	            emailInfo.setMessageAttachments(attachments);
			}
	}
		
		List<String> recipents = new ArrayList<String>();
		recipents.add(getRecipientEmail());
		try {
			getEmailSender().sendEmailMessage(emailInfo, recipents) ;
			getOrderStatusTool().insertMailHistory(getOrderId(),getRecipientEmail(), getCsrName(),getSalesOrg());
		} catch (TemplateEmailException e) {
			vlogError(e, "exception found while sending Email Error:{0}", e);
		}finally{
			if(file!=null){
				file.delete();
	
			}
		}
		
		return checkFormRedirect( "/admin/orderstatus/emailStatus.jsp?success=true" , "/admin/orderstatus/emailOrderInfo.jsp?orderId=" + getOrderId(), pRequest, pResponse);
	}
	
	
	 public static FileOutputStream openOutputStream(File file) throws IOException {
	        if (file.exists()) {
	            if (file.isDirectory()) {
	                throw new IOException("File '" + file + "' exists but is a directory");
	            }
	            if (file.canWrite() == false) {
	                throw new IOException("File '" + file + "' cannot be written to");
	            }
	        } else {
	            File parent = file.getParentFile();
	            if (parent != null && parent.exists() == false) {
	                if (parent.mkdirs() == false) {
	                    throw new IOException("File '" + file + "' could not be created");
	                }
	            }
	        }
	        return new FileOutputStream(file);
	    }

	public boolean handleChangeLanguage( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
        Locale loc = new Locale(getLocaleString());
        setLocale(loc);
        vlogDebug("handleChangeLanguage Get SAP order ID :: " + getOrderId());
        
        if(getOrderDetails() == null)
        {
            vlogDebug("Order details information is null");
	        if (getSapManager().IsSAPAvailable()) {
				getSAPOrderDetails();
			}else{
				addFormException(new DropletException("Backend error, please try again after some time."));
				 vlogDebug("SAP down");
			}
		}
		return checkFormRedirect(getOrderStatusSuccessUrl(), getOrderStatusSuccessUrl(), pRequest, pResponse);
	}
	
	 public void beforeGet( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
		 setLanguage(null);
		 setBccEmail(null);
		 setCopyEmail(null);
		 if (getLocale() == null) {
            setLocaleString(getDefaultLocale());
            Locale loc = new Locale(getLocaleString());
            setLocale(loc);
	     }
		 if (getConditionType() == null || getConditionType().isEmpty() ) {
	         setConditionType(getDefaultConditionType());
	     }
		 if(!isSearched() &&  ( getResultList()== null || getResultList().isEmpty())){
			 setResultList(getOrderStatusTool().getLastFiveHundredOrder(getDefaultOrderRange()));
		 }
		 if("true".equals(pRequest.getLocalParameter("clear"))){
			 getFormExceptions().removeAllElements();
		 }
	 }
	 
	 
	 private String mConditionType;
	 private Date 	mFromDate;
	 private Date 	mToDate;
	 private String mOrderOrEmail;
	 private List<RepositoryItem> mResultList;
	 private int	mDefaultOrderRange;
	 

	public int getDefaultOrderRange() {
		return mDefaultOrderRange;
	}

	public void setDefaultOrderRange(int pDefaultOrderRange) {
		mDefaultOrderRange = pDefaultOrderRange;
	}

	public String getConditionType() {
		return mConditionType;
	}

	public void setConditionType(String pConditionType) {
		mConditionType = pConditionType;
	}

	public Date getFromDate() {
		return mFromDate;
	}

	public void setFromDate(Date pFromDate) {
		mFromDate = pFromDate;
	}

	public Date getToDate() {
		return mToDate;
	}

	public void setToDate(Date pToDate) {
		mToDate = pToDate;
	}

	public String getOrderOrEmail() {
		return mOrderOrEmail;
	}

	public void setOrderOrEmail(String pOrderOrEmail) {
		mOrderOrEmail = pOrderOrEmail;
	}

	public List<RepositoryItem> getResultList() {
		return mResultList;
	}

	public void setResultList(List<RepositoryItem> pResultList) {
		mResultList = pResultList;
	}

	public boolean handleOrderHistory( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException{
		List<RepositoryItem> resultList =new ArrayList<RepositoryItem>();
		if (getConditionType().equals("list500")){
			resultList=getOrderStatusTool().getLastFiveHundredOrder(getDefaultOrderRange());
			setResultList(resultList);
			setOrderOrEmail(null);
			setSearched(true);
		}else if (getConditionType().equals("processedRange")){
			resultList=getOrderStatusTool().getResultsForRange(getFromDate(),getToDate());
			setResultList(resultList);
			setOrderOrEmail(null);
			setSearched(true);
		}else if (getConditionType().equals("orderOrEmail")){
			resultList=getOrderStatusTool().getResultsForOrderOrEmail(getOrderOrEmail());
			setResultList(null);
			setResultList(resultList);
			setSearched(true);
		}else if (getConditionType().equals("emailTo")){
			resultList=getOrderStatusTool().getResultsForEmailOrRequestor(getOrderOrEmail(),null);
			setResultList(null);
			setConditionType("orderOrEmail");
			setResultList(resultList);
			setSearched(true);
		}else if (getConditionType().equals("requestor")){
			resultList=getOrderStatusTool().getResultsForEmailOrRequestor(null, getOrderOrEmail());
			setResultList(null);
			setResultList(resultList);
			setConditionType("orderOrEmail");
			setSearched(true);
		}else if (getConditionType().equals("bulkEmail")){
			setOrderOrEmail(null);
			//setConditionType(getDefaultConditionType());
			if(	getContactMap()!=null){
				for (String orderId :getOrderIdList()) {
					RepositoryItem result=getOrderStatusTool().getResultsForOrderId(orderId);
					resultList.add(result);
				}
				setResultList(resultList);
			}
			setSearched(true);
		}else if(getConditionType().equals("queryResult")){
			pResponse.getResponse().setHeader("Content-disposition", "attachment;filename=WebOrderList.xls");
	        pResponse.getResponse().setContentType("application/vnd.ms-excel");
	        getOrderStatusTool().exportService(getResultList(), pResponse.getOutputStream());
	        return false;
		}
		return checkFormRedirect( "/admin/orderstatus/orderEmailCust.jsp", "/admin/orderstatus/orderEmailCust.jsp", pRequest, pResponse);
	 }	  
}
