package com.agilent.report;

import com.agilent.base.platform.sap.client.BAPI_CUSTOMER_GETCONTACTLIST.BAPICONTACTADDRESSDATA;

public class OrderStatusSapContactVO {
private String salesOrg;
private BAPICONTACTADDRESSDATA contact;
public String getSalesOrg() {
	return salesOrg;
}
public void setSalesOrg(String pSalesOrg) {
	salesOrg = pSalesOrg;
}
public BAPICONTACTADDRESSDATA getContact() {
	return contact;
}
public void setContact(BAPICONTACTADDRESSDATA pContact) {
	contact = pContact;
}
}
