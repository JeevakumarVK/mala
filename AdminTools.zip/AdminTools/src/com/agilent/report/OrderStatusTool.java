package com.agilent.report;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.transaction.TransactionManager;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import atg.dtm.TransactionDemarcation;
import atg.dtm.TransactionDemarcationException;
import atg.nucleus.GenericService;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;

import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.OrderDetails;

public class OrderStatusTool extends GenericService{
	
	private Repository orderRepository;
	private String sapOrderRQL;
	private TransactionManager mTransactionMgr = null;
	private RqlStatement emailToRQLQuery;
	private RqlStatement requestorRQLQuery;
	
	/**
	 * @return the emailToRQLQuery
	 */
	public RqlStatement getEmailToRQLQuery() {
		return emailToRQLQuery;
	}

	/**
	 * @param pEmailToRQLQuery the emailToRQLQuery to set
	 */
	public void setEmailToRQLQuery(RqlStatement pEmailToRQLQuery) {
		emailToRQLQuery = pEmailToRQLQuery;
	}

	/**
	 * @return the requestorRQLQuery
	 */
	public RqlStatement getRequestorRQLQuery() {
		return requestorRQLQuery;
	}

	/**
	 * @param pRequestorRQLQuery the requestorRQLQuery to set
	 */
	public void setRequestorRQLQuery(RqlStatement pRequestorRQLQuery) {
		requestorRQLQuery = pRequestorRQLQuery;
	}

	public TransactionManager getTransactionMgr() {
		return mTransactionMgr;
	}

	public void setTransactionMgr(TransactionManager pTransactionMgr) {
		mTransactionMgr = pTransactionMgr;
	}

	public String getSapOrderRQL() {
		return sapOrderRQL;
	}

	public void setSapOrderRQL(String sapOrderRQL) {
		this.sapOrderRQL = sapOrderRQL;
	}

	public Repository getOrderRepository() {
		return orderRepository;
	}

	public void setOrderRepository(Repository orderRepository) {
		this.orderRepository = orderRepository;
	}

	public String getSalesOrgFromSAPOrderId(String SAPOrderId) {
		RepositoryItem sapOrder=getSAPOrderFromId(SAPOrderId);
		if(sapOrder!=null){
			return (String) sapOrder.getPropertyValue("salesOrg");
		}
        return null;
    }
	
	public RepositoryItem  getSAPOrderFromId(String SAPOrderId) {
		RepositoryItem[] sapOrder=null;
		try {
			RepositoryView view = getOrderRepository().getView("order");
	         Object[] params = new Object[2];
	         params[0] = SAPOrderId;
	         RqlStatement statement = RqlStatement.parseRqlStatement(getSapOrderRQL());
	         sapOrder = statement.executeQuery(view, params);
	         if(sapOrder!=null)
	        	 	return sapOrder[0];
		} catch (RepositoryException e) {
				vlogError("OrderStatusTool class -Repository Exception Thrown ::{0}",e);
		}
       return null;
	}
	public void insertMailHistory(String ordId,String mailTo,String requester,String salesOrg){
		try {
			TransactionDemarcation td = new TransactionDemarcation();
			TransactionManager tm = getTransactionMgr();

			if (tm == null) {
				vlogError("Transaction manager is null ");
				return;
			}
			try {
				td.begin(tm, TransactionDemarcation.REQUIRES_NEW);
				MutableRepository mutableOrdRepository = (MutableRepository)getOrderRepository();
				MutableRepositoryItem mailHisItem = mutableOrdRepository.createItem("orderMailList");
				mailHisItem.setPropertyValue("sapOrderId", ordId);
				mailHisItem.setPropertyValue("emailTo", mailTo);
				mailHisItem.setPropertyValue("requestor", requester);
				mailHisItem.setPropertyValue("salesOrg", salesOrg);
				mailHisItem.setPropertyValue("sentMail", true);
				mutableOrdRepository.addItem(mailHisItem);
			}  catch (RepositoryException e) {
				// TODO Auto-generated catch block
				logDebug("Repository exception in data insertion OrderStausFormhandler"+e);
			} finally {

				td.end();

			}
		} catch (TransactionDemarcationException tde) {
			logDebug("TransactionDemarcationException " + tde);
		}		
	}
	
	
	private RqlStatement LastFiveHundredRQLQuery;
	private RqlStatement mDateRangeRQLQuery;
	private RqlStatement mOrderOrEmailRQLQuery;
	private RqlStatement mOrderRQLQuery;
	private String mReportColumns;
	private RqlStatement mOrderMailDateRQLQuery;
	
	public RqlStatement getOrderMailDateRQLQuery() {
		return mOrderMailDateRQLQuery;
	}

	public void setOrderMailDateRQLQuery(RqlStatement mOrderMailDateRQLQuery) {
		this.mOrderMailDateRQLQuery = mOrderMailDateRQLQuery;
	}

	public RqlStatement getOrderOrEmailRQLQuery() {
		return mOrderOrEmailRQLQuery;
	}

	public void setOrderOrEmailRQLQuery(RqlStatement pOrderOrEmailRQLQuery) {
		mOrderOrEmailRQLQuery = pOrderOrEmailRQLQuery;
	}

	
	public String getReportColumns() {
		return mReportColumns;
	}

	public void setReportColumns(String pReportColumns) {
		mReportColumns = pReportColumns;
	}

	public RqlStatement getOrderRQLQuery() {
		return mOrderRQLQuery;
	}

	public void setOrderRQLQuery(RqlStatement pOrderRQLQuery) {
		mOrderRQLQuery = pOrderRQLQuery;
	}

	public RqlStatement getDateRangeRQLQuery() {
		return mDateRangeRQLQuery;
	}

	public void setDateRangeRQLQuery(RqlStatement pDateRangeRQLQuery) {
		mDateRangeRQLQuery = pDateRangeRQLQuery;
	}

	public RqlStatement getLastFiveHundredRQLQuery() {
		return LastFiveHundredRQLQuery;
	}

	public void setLastFiveHundredRQLQuery(RqlStatement pLastFiveHundredRQLQuery) {
		LastFiveHundredRQLQuery = pLastFiveHundredRQLQuery;
	}

	public List<RepositoryItem> getLastFiveHundredOrder(int range) {
		try {
			List<RepositoryItem> resultList=Collections.emptyList();
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement = getLastFiveHundredRQLQuery();
            Object[] params = new Object[2];
            params[0] = range;
            
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
            	resultList=Arrays.asList(results);
                return resultList;
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return Collections.emptyList();
	}

	public List<RepositoryItem> getResultsForRange(Date pFromDate, Date pToDate) {
		try {
			List<RepositoryItem> resultList=Collections.emptyList();
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement = getDateRangeRQLQuery();
            Object[] params = new Object[2];
            params[0] = pFromDate;
            params[1] = pToDate;
            
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
            	resultList=Arrays.asList(results);
                return resultList;
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return Collections.emptyList();
	}

	public RepositoryItem getResultsForOrderId(String pOrder) {
		try {
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement = getOrderRQLQuery();
            Object[] params = new Object[2];
            params[0] = pOrder;
            
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
                return results[0];
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return null;
	}
	
	  public void exportService( List<RepositoryItem> resultItems,  OutputStream pOutput) {

	        if (resultItems != null && resultItems.size() > 0) {
	            try {

	                HSSFWorkbook wb = new HSSFWorkbook();
	                HSSFSheet sheet = wb.createSheet("Export Worksheet");

	                HSSFRow row = sheet.createRow(0);
	                List<String> cols = Arrays.asList(getReportColumns().split(":"));
	                for ( int i = 0; i < cols.size(); i++) {
	                    String cellValue = cols.get(i);
	                    row.createCell(i).setCellValue(cellValue);

	                }

	                populateXL(resultItems, sheet);

	                wb.write(pOutput);
	                pOutput.flush();

	            } catch (FileNotFoundException e) {
	                vlogError(e, "printing the Excel sheet error{0}", e);
	            } catch (IOException e) {
	                vlogError(e, "IO exception error:{0}", e);
	            }
	        } else {
	            vlogDebug("No results returned");
	            return;
	        }
	    }
	  protected HSSFSheet populateXL(List<RepositoryItem> repositoryItems, HSSFSheet sheet) {

	        int rownum = 1;
	            	try{
	            	 if (repositoryItems != null) {
	                     for ( RepositoryItem repositoryItem : repositoryItems) {
	                          HSSFRow newRow = sheet.createRow(rownum);
	                          newRow.createCell(0).setCellValue(rownum);
	                          newRow.createCell(1).setCellValue(repositoryItem.getPropertyValue("sapOrderId") == null ? "-" : (String) repositoryItem.getPropertyValue("sapOrderId"));
	                          newRow.createCell(2).setCellValue(repositoryItem.getPropertyValue("salesOrg") == null ? "-" : (String) repositoryItem.getPropertyValue("salesOrg"));
	                          List<RepositoryItem> accessHistoryList = (List<RepositoryItem>) repositoryItem.getPropertyValue("accessHistoryList") ;
	                          newRow.createCell(3).setCellValue(Integer.toString(accessHistoryList.size()));//access count
	                          newRow.createCell(4).setCellValue(repositoryItem.getPropertyValue("sentMailDate") == null ? "-" : ((Date)  repositoryItem.getPropertyValue("sentMailDate")).toString());
	                          newRow.createCell(5).setCellValue(repositoryItem.getPropertyValue("emailTo") == null ? "-" : (String) repositoryItem.getPropertyValue("emailTo"));
	                          newRow.createCell(6).setCellValue(repositoryItem.getPropertyValue("requestor") == null ? "-" : (String) repositoryItem.getPropertyValue("requestor"));
	                          newRow.createCell(7).setCellValue(repositoryItem.getPropertyValue("sentMail") == null ? "NO" : (Boolean) repositoryItem.getPropertyValue("sentMail") ? "YES" : "NO");
	                          rownum++;
	                     }
	            	 }else{
	            		 vlogDebug("No data found");
	            	 }
	            	} catch (Exception e) {
	                    vlogError(e, "report error{0}", e);
	                }
	            	 
	        return sheet;
	    }

	public List<RepositoryItem> getResultsForOrderOrEmail(String pOrderOrEmail) {
		try {
			List<RepositoryItem> resultList=Collections.emptyList();
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement = getOrderOrEmailRQLQuery();
            Object[] params = new Object[2];
            params[0] = pOrderOrEmail;
            
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
            	resultList=Arrays.asList(results);
                return resultList;
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return Collections.emptyList();
	}
	
	public List<RepositoryItem> getResultsForEmailOrRequestor(String email,String requestor) {
		try {
			List<RepositoryItem> resultList=Collections.emptyList();
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement=null; 
			Object[] params = new Object[2];
			if (email!= null){
				 statement = getEmailToRQLQuery();
				 params[0] = email;
			}else{
				statement = getRequestorRQLQuery();
				params[0] = requestor;
			}
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
            	resultList=Arrays.asList(results);
                return resultList;
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return Collections.emptyList();
	}
	
	public String getTimeStampForOrderId(String pOrderId) {
		  String msg="Not Yet Sent";
		try {
			RepositoryView view = getOrderRepository().getView("orderMailList");
			RqlStatement statement = getOrderMailDateRQLQuery();
            Object[] params = new Object[1];
            params[0] = pOrderId;
          
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
            return  results[0].getPropertyValue("sentMailDate").toString();
            }else{
            	return msg;
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return msg;
	}
	public void insertAccessHistory(String pOrderId){
		try {
			TransactionDemarcation td = new TransactionDemarcation();
			TransactionManager tm = getTransactionMgr();

			if (tm == null) {
				vlogError("Transaction manager is null ");
				return;
			}
			try {
				td.begin(tm, TransactionDemarcation.REQUIRES_NEW);
				MutableRepository mutableOrdRepository = (MutableRepository)getOrderRepository();
				MutableRepositoryItem accessHisItem = mutableOrdRepository.createItem("orderAccessHistory");
				accessHisItem.setPropertyValue("sapOrderId", pOrderId);
				mutableOrdRepository.addItem(accessHisItem);
			}  catch (RepositoryException e) {
				// TODO Auto-generated catch block
				logDebug("Repository exception in data insertion OrderStausFormhandler"+e);
			} finally {
				td.end();
			}
		} catch (TransactionDemarcationException tde) {
			logDebug("TransactionDemarcationException " + tde);
		}		
	}
	
	private Repository siteRepository;
	private RqlStatement emailRQLQuery;
	/**
	 * @return the emailRQLQuery
	 */
	public RqlStatement getEmailRQLQuery() {
		return emailRQLQuery;
	}

	/**
	 * @param pEmailRQLQuery the emailRQLQuery to set
	 */
	public void setEmailRQLQuery(RqlStatement pEmailRQLQuery) {
		emailRQLQuery = pEmailRQLQuery;
	}

	/**
	 * @return the siteRepository
	 */
	public Repository getSiteRepository() {
		return siteRepository;
	}

	/**
	 * 
	 * @param pSiteRepository the siteRepository to set
	 */
	public void setSiteRepository(Repository pSiteRepository) {
		siteRepository = pSiteRepository;
	}
	public RepositoryItem getEmailContent(String pCountryCode, String pLangCode) {
		try {
			RepositoryView view = getSiteRepository().getView("emailContent");
			RqlStatement statement = getEmailRQLQuery();
            Object[] params = new Object[3];
            params[0] = pCountryCode;
            params[1] = pLangCode;
            
            RepositoryItem[] results;
            results = statement.executeQuery(view, params);
            if (results != null && results.length > 0) {
                return results[0];
            }
		} catch (RepositoryException e) {
			 vlogError(e, "exception found while access the data Error:{0}", e);
		}
		return null;
	}
	
	
//	public OrderDetails updateTrackingDetails(OrderDetails orderDetails)
//	{
//		for(LineItem lineItem:orderDetails.getItems()){
//        	
//	       	 /**calculating  the trackNo based on shipper codes **/
//	       	
//	       	if(lineItem.getOrderTrackDetail()!=null){
//	           String shipperCode=lineItem.getOrderTrackDetail().getShipperCode();
//	           String trackNo=lineItem.getOrderTrackDetail().getTrackNo();
//	           String trackUrl=lineItem.getOrderTrackDetail().getTrackUrl();
//	           String Dvbeln=lineItem.getOrderTrackDetail().getDvbeln();
//	           
//	           if(shipperCode != null && (shipperCode.equalsIgnoreCase("AFD") ||shipperCode.equalsIgnoreCase("SAT"))){
//		           	if(shipperCode.length()>4 && (shipperCode.substring(0, 5)).equalsIgnoreCase("AFDEM")){
//		           		 trackNo = lineItem.getOrderTrackDetail().getTrackNo();
//		           	}else if(trackNo != null && trackNo.length()>11){
//		           		 trackNo = trackNo.substring(0, 12);
//		           	}else{
//		           		trackNo = lineItem.getOrderTrackDetail().getTrackNo();
//		           	}
//					vlogDebug(" trackUrl = "+trackUrl);
//					if(trackUrl != null && trackUrl.indexOf("Ecom")>-1)	{
//					   	trackUrl = trackUrl.replace("Ecom", trackNo);
//					}
//					else {
//						trackUrl = "";
//					}
//	           }else if(Dvbeln!=null && shipperCode!= null && shipperCode.equalsIgnoreCase("AUP")){
//	        	   trackNo = Dvbeln;
//	        	   vlogDebug(" trackUrl = "+trackUrl);
//	        	   if(trackUrl != null && trackUrl.indexOf("Ecom")>-1) {
//				   	trackUrl = trackUrl.replace("Ecom", trackNo);
//	        	   }
//	        	   else	{
//					trackUrl = "";
//	        	   }
//	           }else if(Dvbeln!=null){
//	        	   trackNo = lineItem.getOrderTrackDetail().getTrackNo();
//	           }
//	           
//	           vlogDebug(" trackUrl = "+trackUrl);
//	           if(trackUrl != null && trackUrl.indexOf("%26")>-1){
//	        	   trackUrl = trackUrl.replace("%26", trackNo);
//	           }
//	           else	{
//	        	   trackUrl = "";
//	           }
//	           
//	       	lineItem.getOrderTrackDetail().setTrackNo(trackNo);
//	       	lineItem.getOrderTrackDetail().setTrackUrl(trackUrl);
//	       }
//	       
//	    }
//		return orderDetails;
//	}
}
