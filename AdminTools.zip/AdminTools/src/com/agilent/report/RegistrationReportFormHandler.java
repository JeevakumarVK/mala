package com.agilent.report;

/** @author
 * goutam
 */

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.ServletException;
import com.agilent.report.ReportsTool.ReportType;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

public class RegistrationReportFormHandler extends ReportGenarateFormHandler {

	int ecommEnabled;
	// RBE APP 4484 START
	String [] sapSalesOrg;
	// RBE APP 4484 END
	int userType;

	public int getEcommEnabled() {
		return ecommEnabled;
	}
	public void setEcommEnabled(int ecommEnabled) {
		this.ecommEnabled = ecommEnabled;
	}
	
	public int getUserType() {
		return userType;
	}
	public void setUserType(int userType) {
		this.userType = userType;
	}
	// RBE APP 4484 START
	public String[] getSapSalesOrg() {
		return sapSalesOrg;
	}
	public void setSapSalesOrg(String[] sapSalesOrg) {
		this.sapSalesOrg = sapSalesOrg;
	}
	// RBE APP 4484 END
	public boolean handleSubmit(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		pRequest.setParameter(REPORT_TYPE,
				ReportsTool.ReportType.REGISTRATIONREPORT);
		pRequest.setParameter("ecommerceEnabled", getEcommEnabled());
		pRequest.setParameter("sapSalesOrg", getSapSalesOrg());
		pRequest.setParameter("userType", getUserType());
		return super.handleSubmit(pRequest, pResponse);
	}
	// RBE APP 4484 START
	public boolean handleExportRegisterSubmit(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
	
			Date startDate = getStartDate();
			Date endDate = getEndDate();
			
			vlogDebug("Given from date: {0}", startDate);

			Calendar cal = Calendar.getInstance();
			cal.setTime(endDate);
			cal.add(Calendar.HOUR, 24);
			endDate = cal.getTime();

			vlogDebug("Given to date: {0}", endDate);

			ReportType reporttype = ReportsTool.ReportType.REGISTRATIONREPORT;
			
			
			int ecomenablement = getEcommEnabled();
			String[] sapSalesorg = getSapSalesOrg();
			int userType =getUserType();
			
          pResponse.getResponse().setHeader("Content-disposition", "attachment;filename=ReportTool.xls");
          pResponse.getResponse().setContentType("application/vnd.ms-excel");
          getReportsTool().exportProfileService(reporttype, startDate, endDate,ecomenablement, sapSalesorg, userType, pResponse.getOutputStream());

      

      return false;
  }
	// RBE APP 4484 END
	
}