package com.agilent.report;

import java.io.IOException;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.servlet.ServletException;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import com.agilent.report.ReportsTool.ReportType;

/**
 * <p>
 * Base formhandler for report generation.
 * </p>
 * 
 * @authorGoutam.h
 * @project Agilent.BCCMerch
 */

public abstract class ReportGenarateFormHandler extends GenericFormHandler {

	protected static final String REPORT_TYPE = "reporttype";

	private Date mStartDate;
	private Date mEndDate;
	private List<RepositoryItem> mResultList;
	private ReportsTool mReportsTool;
	private String mSuccussUrl;
	private String mErrorUrl;
	// RBE APP 4484 START
	private boolean               isSearched = false;

	/**
	 * @return the isSearched
	 */
	public boolean isSearched() {
		return isSearched;
	}
	/**
	 * @param isSearched the isSearched to set
	 */
	public void setSearched(boolean isSearched) {
		this.isSearched = isSearched;
	}
	// RBE APP 4484 END

		// RBE APP 4483 ERFQ TOOL Start
    private String[] mCountry;
    public String[] getCountry() {
        return mCountry;
    }

    public void setCountry( String[] pCountry) {
        mCountry = pCountry;
    }
	
	// RBE APP 4483 ERFQ TOOL End

	/**
	 * @return the succussUrl
	 */
	public String getSuccussUrl() {
		return mSuccussUrl;
	}

	/**
	 * @return the errorUrl
	 */
	public String getErrorUrl() {
		return mErrorUrl;
	}

	/**
	 * @param pSuccussUrl
	 *            the succussUrl to set
	 */
	public void setSuccussUrl(String pSuccussUrl) {
		mSuccussUrl = pSuccussUrl;
	}

	/**
	 * @param pErrorUrl
	 *            the errorUrl to set
	 */
	public void setErrorUrl(String pErrorUrl) {
		mErrorUrl = pErrorUrl;
	}

	public List<RepositoryItem> getResultList() {
		return mResultList;
	}

	public void setResultList(List<RepositoryItem> pResultList) {
		mResultList = pResultList;
	}

	/**
	 * @return the mReportsTool
	 */
	public ReportsTool getReportsTool() {
		return mReportsTool;
	}

	/**
	 * @param mReportsTool
	 *            the mReportsTool to set
	 */
	public void setReportsTool(ReportsTool pReportsTool) {
		this.mReportsTool = pReportsTool;
	}

	/**
	 * @return the mStartDate
	 */
	public Date getStartDate() {
		return mStartDate;
	}

	/**
	 * @param mStartDate
	 *            the mStartDate to set
	 */
	public void setStartDate(Date pStartDate) {
		this.mStartDate = pStartDate;
	}

	/**
	 * @return the mEndDate
	 */
	public Date getEndDate() {
		return mEndDate;
	}

	/**
	 * @param mEndDate
	 *            the mEndDate to set
	 */
	public void setEndDate(Date pEndDate) {
		this.mEndDate = pEndDate;
	}
	// RBE APP 4484 START
	public void beforeGet( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
   		
      
       pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.ORDERMANAGMENTREPORT);
      /* String reporttype = (String) pRequest.getObjectParameter(REPORT_TYPE);*/

       try {

           if (!isSearched()&&(getResultList() == null || getResultList().isEmpty()) &&
           		(getResultList()==null) ){

               Date currentDate = new Date();
               Calendar cacl = new GregorianCalendar();
               cacl.setTime(currentDate);
               cacl.add(Calendar.DAY_OF_MONTH, -3);
               Date lastThreeDays = cacl.getTime();
               setStartDate(lastThreeDays);
               setEndDate(currentDate);
           }
       } catch (Exception e) {
           vlogError(e, "exception found while access the data Error:{0}", e);
       }

   }
	// RBE APP 4484 END

	public boolean handleSubmit(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {

		List<RepositoryItem> result = Collections.EMPTY_LIST;
		try {

			Date startDate = getStartDate();
			Date endDate = getEndDate();
			// RBE APP 4484 START
			vlogInfo("Given from date: {0}", startDate);
			vlogInfo("Given from date: {0}", endDate);

			Calendar cal = Calendar.getInstance();
			if(null!=endDate){
			cal.setTime(endDate);
			}
			// RBE APP 4484 END
			cal.add(Calendar.HOUR, 24);
			endDate = cal.getTime();

			vlogDebug("Given to date: {0}", endDate);

			ReportType reporttype = (ReportType) pRequest
					.getObjectParameter(REPORT_TYPE);
			
			
			
			if(reporttype == ReportsTool.ReportType.REGISTRATIONREPORT)
			{
				int ecomenablement = (Integer)pRequest.getObjectParameter("ecommerceEnabled");
				// RBE APP 4484 START
				String[] sapSalesorg = (String[])pRequest.getObjectParameter("sapSalesOrg");
				// RBE APP 4484 END
				int userType = (Integer)pRequest.getObjectParameter("userType");
				vlogDebug("InSide if for the Registration Report");
				vlogDebug("Report Type {0}", reporttype);
				
				result = getReportsTool().browseProfileService(reporttype,startDate, endDate, ecomenablement, sapSalesorg , userType);
			}
			else{
				vlogDebug("Inside else for the other reports");
				vlogDebug("Report Type {0}", reporttype);
				//RBE 4483 ERFQ TOOL	
				String[] country = getCountry();
				result = getReportsTool().browseServiceWithCountries(reporttype, startDate, endDate, country);	
				//result = getReportsTool().browseService(reporttype, startDate, endDate);
			
			
			}
			// RBE APP 4484 START
			if (null!=result && !result.isEmpty()) {
				setResultList(result);
				setSearched(true);
				
			} else {
				 setResultList(result);
				// RBE APP 4484 END
				addFormException(new DropletException(
						"No data found for requested date"));
				
			}
			
		} catch (Exception e) {
			vlogError(e, "exception found while access the data Error:{0}", e);
		}

		return checkFormRedirect("", "", pRequest, pResponse);

	}

}
