package com.agilent.report;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.transaction.TransactionManager;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.joda.time.DateTime;
import org.joda.time.Days;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.CyberSourcePaymentGroup;
import com.agilent.base.commerce.order.PurchaseOrderPaymentGroup;
import com.agilent.base.commerce.payment.CyberSourcePaymentStatusImpl;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.util.AgilentUtil;
import com.agilent.report.vo.Constants;
import com.agilent.report.vo.OrderManagementVO;
import com.agilent.report.vo.SubscriptionReportVO;

import atg.commerce.CommerceException;
import atg.commerce.order.OrderManager;
import atg.commerce.order.PaymentGroup;
import atg.core.util.StringUtils;
import atg.dtm.TransactionDemarcation;
import atg.dtm.TransactionDemarcationException;
import atg.nucleus.GenericService;
import atg.nucleus.ServiceMap;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.Query;
import atg.repository.QueryBuilder;
import atg.repository.QueryExpression;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.SortDirective;
import atg.repository.SortDirectives;
import atg.repository.rql.RqlStatement;

public class ReportsTool extends GenericService {

	SimpleDateFormat dtFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
    private String ecommEnabledBoth;
    private String memberTypeBoth;
    private String ecommEnabledMemberTypeBoth;
    private OrderManager mOrderManager;


	private static final int QCPD_Customer_Email = 0;
	private static final int QCPD_First_Name = 1;
	private static final int QCPD_Last_Name = 2;
	private static final int QCPD_Org = 3;
	private static final int QCPD_Address1 = 4;
	private static final int QCPD_Address2 = 5;
	private static final int QCPD_City = 6;
	private static final int QCPD_State = 7;
	private static final int QCPD_Zip = 8;
	private static final int QCPD_Country = 9;
	private static final int QCPD_Phone = 10;
	private static final int QCPD_Date_Account_Added = 11;
	private static final int QCPD_Click_Date = 12;

	private static final int ORDER_Order_Id = 0;
	private static final int ORDER_Customer_Email = 1;
	private static final int ORDER_Country_ID = 2;
	private static final int ORDER_Grand_Total = 3;
	private static final int ORDER_Date_and_Time = 4;
	private static final int ORDER_SAP_ORDER_ID = 5;
	private static final int ORDER_Order_Type = 6;

	private String convertBoleanToString = "No";
	private String vendorName;

	private static final int SUREFISH_vendor_id = 0;
	private static final int SUREFISH_vendor_name = 1;
	private static final int SUREFISH_url_referrer = 2;
	private static final int SUREFISH_landed = 3;
	private static final int SUREFISH_date_landed = 4;
	private static final int SUREFISH_checkout = 5;
	private static final int SUREFISH_dateCheckout = 6;
	private static final int SUREFISH_orderSubmitted = 7;
	private static final int SUREFISH_dateOrderSubmitted = 8;
	private static final int SUREFISH_rfq = 9;
	private static final int SUREFISH_dateRFQSubmitted = 10;
	private static final int SUREFISH_status = 11;
	private static final int REQUESTQUOTE_lastName = 2;
	private static final int REQUESTQUOTE_country = 3;
	private static final int REQUESTQUOTE_jobTitle = 4;
	private static final int REQUESTQUOTE_dept = 5;
	private static final int REQUESTQUOTE_org = 6;
	private static final int REQUESTQUOTE_address = 7;
	private static final int REQUESTQUOTE_address1 = 8;
	private static final int REQUESTQUOTE_city = 9;
	private static final int REQUESTQUOTE_state = 10;
	private static final int REQUESTQUOTE_zip = 11;
	private static final int REQUESTQUOTE_phone = 12;
	private static final int REQUESTQUOTE_email = 13;
	private static final int REQUESTQUOTE_primJobFuncs = 14;
	private static final int REQUESTQUOTE_erfqId = 15;
	private static final int REQUESTQUOTE_catId = 16;
	private static final int REQUESTQUOTE_productName = 17;
	private static final int REQUESTQUOTE_quantity = 18;
	private static final int REQUESTQUOTE_prodAreas = 19;
	private static final int REQUESTQUOTE_indAreas = 20;
	private static final int REQUESTQUOTE_comments = 21;
	private static final int REQUESTQUOTE_alternatePhone = 22;
	private static final int REQUESTQUOTE_bestTimeToCall = 23;
	private static final int REQUESTQUOTE_modelNumber = 24;
	private static final int REQUESTQUOTE_serialNumber = 25;
	private static final int REQUESTQUOTE_recieveEmailUpdates = 26;
	private static final int REQUESTQUOTE_dateCreated = 27;
	private static final int REQUESTQUOTE_source = 28;
	private static final int REQUESTQUOTE_contactMethod = 29;
	private static final int REQUESTQUOTE_referrerLink = 30;
	private static final int REQUESTQUOTE_erfqIdUpdateDetails = 31;
	private static final int REQUESTQUOTE_crmComments = 32;
	/*private static final int REQUESTQUOTE_nonActionable = 28;
	private static final int REQUESTQUOTE_reason = 29;*/
	/*private static final int REQUESTQUOTE_crmId = 30;*/
	private AgilentProfileTools profileTools;
	

	public enum ReportType {
		ORDERMANAGMENTREPORT, SALESREPORT, REGISTRATIONREPORT, QCPDREPORT, SUREFISHREPORT, ADMIN, REQUESTQUOTE, PUNCHOUT, SUBSCRIPTIONREPORT
	}

	private ServiceMap mRepository;
	private Map<String, String> mViewName;
	private Map<String, String> mFetchRql;
	private Map<String, String> mOrderRql;

	private Map<String, String> mOrderTypeRql;
	private Map<String, String> mReportColumns;
	private Map<String, List<String>> mReportColumnsList;
	private Map<String, String> mLastThreeDaysOrderRql;
	private Map<String, String> mSaleOrgOrderRql;
	private CountryUtils mCountryUtils;
	private Map<String, String> mLastTwoHundredOrderRql;
	private Map<String, String> mPunchoutRql;
	private Map<String, String> mCurrencyCodeToLocaleMap;
	private Repository mCountryRepository;
	/*Changes Start for the jaguar project*/
    private String mCheckAmazonOrderQuery;
	/*Changes end for the jaguar project*/

    private boolean createSubscription;
    private String defaultEndDate;
    private String defaultSubscriptionName;
    private String defaultSchedule;
    private TransactionManager mTransactionManager;
    
    /*AMS-532 Changes*/
    private List <String> descriptionList;

    /**
     * Gets the value of descriptionList
     * 
     * @return the property descriptionList
     */
	public List<String> getDescriptionList() {
		return descriptionList;
	}

	 /**
     * Sets the value of property descriptionList with value descriptionList
     * 
     * @param descriptionList
     *            the descriptionList to set
     */
	public void setDescriptionList(List<String> descriptionList) {
		this.descriptionList = descriptionList;
	}
    /**
     * @return the transactionManager
     */
    public TransactionManager getTransactionManager() {
        return mTransactionManager;
    }

    /**
     * @param pTransactionManager
     *            the transactionManager to set
     */
    public void setTransactionManager(final TransactionManager pTransactionManager) {
        mTransactionManager = pTransactionManager;
    }
    

    /**
     * Gets the value of property defaultEndDate
     *
     * @return the value of property defaultEndDate
     */
    public String getDefaultEndDate() {
        return defaultEndDate;
    }
    /**
     * Sets the value of property defaultEndDate with value defaultEndDate
     *
     * @param defaultEndDate
     *            for setting property defaultEndDate
     */
    public void setDefaultEndDate(String defaultEndDate) {
        this.defaultEndDate = defaultEndDate;
    }
    /**
     * Gets the value of property defaultSubscriptionName
     *
     * @return the value of property defaultSubscriptionName
     */
    public String getDefaultSubscriptionName() {
        return defaultSubscriptionName;
    }
    /**
     * Sets the value of property defaultSubscriptionName with value defaultSubscriptionName
     *
     * @param defaultSubscriptionName
     *            for setting property defaultSubscriptionName
     */
    public void setDefaultSubscriptionName(String defaultSubscriptionName) {
        this.defaultSubscriptionName = defaultSubscriptionName;
    }
    /**
     * Gets the value of property defaultSchedule
     *
     * @return the value of property defaultSchedule
     */
    public String getDefaultSchedule() {
        return defaultSchedule;
    }
    /**
     * Sets the value of property defaultSchedule with value defaultSchedule
     *
     * @param defaultSchedule
     *            for setting property defaultSchedule
     */
    public void setDefaultSchedule(String defaultSchedule) {
        this.defaultSchedule = defaultSchedule;
    }
    /**
     * Gets the value of property createSubscription
     *
     * @return the value of property createSubscription
     */
    public boolean isCreateSubscription() {
        return createSubscription;
    }
    /**
     * Sets the value of property createSubscription with value createSubscription
     *
     * @param createSubscription
     *            for setting property createSubscription
     */
    public void setCreateSubscription(boolean createSubscription) {
        this.createSubscription = createSubscription;
    }
    /*Changes Start for the jaguar project*/
    /**
     * 
     * @return CheckAmazonOrderQuery
     */
    public String getCheckAmazonOrderQuery() {
		return mCheckAmazonOrderQuery;
	}
    /**
     * 
     * @param pCheckAmazonOrderQuery
     */
	public void setCheckAmazonOrderQuery(String pCheckAmazonOrderQuery) {
		mCheckAmazonOrderQuery = pCheckAmazonOrderQuery;
	}
/*Changes end for the jaguar project*/
	/**
     * Gets the value of orderManager
     * 
     * @return returns the property orderManager
     */
    public OrderManager getOrderManager() {
        return mOrderManager;
    }

    /**
     * Sets the value of property orderManager with value pOrderManager
     * 
     * @param pOrderManager
     *            the orderManager to set
     */
    public void setOrderManager(OrderManager pOrderManager) {
        mOrderManager = pOrderManager;
    }
	public String getEcommEnabledBoth() {
		return ecommEnabledBoth;
	}

	public void setEcommEnabledBoth(String ecommEnabledBoth) {
		this.ecommEnabledBoth = ecommEnabledBoth;
	}

	public String getMemberTypeBoth() {
		return memberTypeBoth;
	}

	public void setMemberTypeBoth(String memberTypeBoth) {
		this.memberTypeBoth = memberTypeBoth;
	}

	public String getEcommEnabledMemberTypeBoth() {
		return ecommEnabledMemberTypeBoth;
	}

	public void setEcommEnabledMemberTypeBoth(String ecommEnabledMemberTypeBoth) {
		this.ecommEnabledMemberTypeBoth = ecommEnabledMemberTypeBoth;
	}

	public Repository getCountryRepository() {
		return mCountryRepository;
	}

	public void setCountryRepository(Repository pCountryRepository) {
		mCountryRepository = pCountryRepository;
	}

	public Map<String, String> getCurrencyCodeToLocaleMap() {
		return mCurrencyCodeToLocaleMap;
	}

	public void setCurrencyCodeToLocaleMap(
			Map<String, String> currencyCodeToLocaleMap) {
		mCurrencyCodeToLocaleMap = currencyCodeToLocaleMap;
	}

	public Map<String, String> getPunchoutRql() {
		return mPunchoutRql;
	}

	public void setPunchoutRql(Map<String, String> pPunchoutRql) {
		mPunchoutRql = pPunchoutRql;
	}

	public Map<String, String> getLastTwoHundredOrderRql() {
		return mLastTwoHundredOrderRql;
	}

	public void setLastTwoHundredOrderRql(
			Map<String, String> mLastTwoHundredOrderRql) {
		this.mLastTwoHundredOrderRql = mLastTwoHundredOrderRql;
	}

	public CountryUtils getCountryUtils() {
		return mCountryUtils;
	}

	public void setCountryUtils(CountryUtils pCountryUtils) {
		mCountryUtils = pCountryUtils;
	}

	/**
	 * Gets the value of orderTypeRql
	 * 
	 * @return returns the property orderTypeRql
	 */
	public Map<String, String> getOrderTypeRql() {
		return mOrderTypeRql;
	}

	/**
	 * Sets the value of property orderTypeRql with value pOrderTypeRql
	 * 
	 * @param pOrderTypeRql
	 *            the orderTypeRql to set
	 */
	public void setOrderTypeRql(Map<String, String> pOrderTypeRql) {
		mOrderTypeRql = pOrderTypeRql;
	}

	/**
	 * Gets the value of saleOrgOrderRql
	 * 
	 * @return returns the property saleOrgOrderRql
	 */
	public Map<String, String> getSaleOrgOrderRql() {
		return mSaleOrgOrderRql;
	}

	/**
	 * Sets the value of property saleOrgOrderRql with value pSaleOrgOrderRql
	 * 
	 * @param pSaleOrgOrderRql
	 *            the saleOrgOrderRql to set
	 */
	public void setSaleOrgOrderRql(Map<String, String> pSaleOrgOrderRql) {
		mSaleOrgOrderRql = pSaleOrgOrderRql;
	}

	/**
	 * Gets the value of lastThreeDaysOrderRql
	 * 
	 * @return returns the property lastThreeDaysOrderRql
	 */
	public Map<String, String> getLastThreeDaysOrderRql() {
		return mLastThreeDaysOrderRql;
	}

	/**
	 * Sets the value of property lastThreeDaysOrderRql with value
	 * pLastThreeDaysOrderRql
	 * 
	 * @param pLastThreeDaysOrderRql
	 *            the lastThreeDaysOrderRql to set
	 */
	public void setLastThreeDaysOrderRql(
			Map<String, String> pLastThreeDaysOrderRql) {
		mLastThreeDaysOrderRql = pLastThreeDaysOrderRql;
	}

	/**
	 * @return the mOrderRql
	 */
	public Map<String, String> getOrderRql() {
		return mOrderRql;
	}

	/**
	 * @param mOrderRql
	 *            the mOrderRql to set
	 */
	public void setOrderRql(Map<String, String> pOrderRql) {
		this.mOrderRql = pOrderRql;
	}

	/**
	 * @return the mRepository
	 */
	public ServiceMap getRepository() {
		return mRepository;
	}

	/**
	 * @param pRepository
	 *            the mRepository to set
	 */
	public void setRepository(ServiceMap pRepository) {
		this.mRepository = pRepository;
	}

	/**
	 * @return the mViewName
	 */
	public Map<String, String> getViewName() {
		return mViewName;
	}

	/**
	 * @param mViewName
	 *            the mViewName to set
	 */
	public void setViewName(Map<String, String> pViewName) {
		this.mViewName = pViewName;
	}

	/**
	 * @return the mReportColumns
	 */
	public Map<String, String> getReportColumns() {
		return mReportColumns;
	}

	/**
	 * @param pReportColumns
	 *            the mReportColumns to set
	 */
	public void setReportColumns(Map<String, String> pReportColumns) {
		this.mReportColumns = pReportColumns;
	}

	/**
	 * @return the mFetchRql
	 */
	public Map<String, String> getFetchRql() {
		return mFetchRql;
	}

	/**
	 * @param pFetchRql
	 *            the mFetchRql to set
	 */
	public void setFetchRql(Map<String, String> pFetchRql) {
		this.mFetchRql = pFetchRql;
	}

	private Map<String, List<String>> getColumnsAsMapOfList() {
		if (mReportColumnsList == null) {
			Map<String, String> cols = getReportColumns();
			if (cols != null) {
				mReportColumnsList = new HashMap<String, List<String>>();
				for (java.util.Map.Entry<String, String> entry : cols
						.entrySet()) {
					String[] listCols = entry.getValue().split(":");
					mReportColumnsList.put(entry.getKey(),
							Arrays.asList(listCols));
				}
			}

		}
		return mReportColumnsList;
	}

	protected HSSFSheet populateXL( ReportType pReportType, List<RepositoryItem> repositoryItems, HSSFSheet sheet) {

        int rownum = 1;

        switch (pReportType) {
            case REGISTRATIONREPORT:
                try {
                	// RBE APP 4484 START
                    int i=0;
                    if (repositoryItems != null) {
                        for ( RepositoryItem repositoryItem : repositoryItems) {
                        	                   i++;
                        	                     vlogDebug("Counter Increased by" + i);
                        
                            HSSFRow newRow = sheet.createRow(rownum);
                            newRow.createCell(0).setCellValue(repositoryItem.getPropertyValue("adLoginName") == null ? "-" : (String) repositoryItem.getPropertyValue("adLoginName"));
                            newRow.createCell(1).setCellValue(dtFormat.format(((Date) repositoryItem.getPropertyValue("registrationDate"))));
                            newRow.createCell(2).setCellValue(repositoryItem.getPropertyValue("firstName")== null ? "-" :(String)repositoryItem.getPropertyValue("firstName"));                            
                            newRow.createCell(3).setCellValue(repositoryItem.getPropertyValue("lastName") == null ? "-" : (String)repositoryItem.getPropertyValue("lastName") );                           
                            newRow.createCell(4).setCellValue(repositoryItem.getPropertyValue("memberType") == null ? "-" : (String) repositoryItem.getPropertyValue("memberType"));
                            newRow.createCell(5).setCellValue(repositoryItem.getPropertyValue("email") == null ? "-" : (String) repositoryItem.getPropertyValue("email"));
                            newRow.createCell(6).setCellValue(repositoryItem.getPropertyValue("company") == null ? "-" : (String) repositoryItem.getPropertyValue("company"));
                            newRow.createCell(7).setCellValue(repositoryItem.getPropertyValue("address1") == null ? "-" : (String) repositoryItem.getPropertyValue("address1"));
                            newRow.createCell(8).setCellValue(repositoryItem.getPropertyValue("userCountry") == null ? "-" : (String)repositoryItem.getPropertyValue("userCountry"));                            
                            newRow.createCell(9).setCellValue(repositoryItem.getPropertyValue("sapSalesOrg") == null ? "-" : (String)repositoryItem.getPropertyValue("sapSalesOrg"));                           
                            newRow.createCell(10).setCellValue(repositoryItem.getPropertyValue("eCommStatus") == null ? "-" : (String)repositoryItem.getPropertyValue("eCommStatus"));                                                    
                            newRow.createCell(11).setCellValue(repositoryItem.getPropertyValue("sapContactNumber") == null ? "-" : (String)repositoryItem.getPropertyValue("sapContactNumber"));
                            //PresentnewRow.createCell(12).setCellValue(dtFormat.format(((Date) repositoryItem.getPropertyValue("lastPasswordUpdate"))));
                            //newRow.createCell(12).setCellValue(repositoryItem.getPropertyValue("lastPasswordUpdate") == null ? "-" : (String)repositoryItem.getPropertyValue("lastPasswordUpdate"));
                            newRow.createCell(12).setCellValue(repositoryItem.getPropertyValue("email") == null ? "-" : (String)repositoryItem.getPropertyValue("email"));
                            //PresentnewRow.createCell(14).setCellValue(dtFormat.format(((Date) repositoryItem.getPropertyValue("passChngReqDate"))));
                            //newRow.createCell(14).setCellValue(repositoryItem.getPropertyValue("passChngReqDate") == null ? "-" : (String)repositoryItem.getPropertyValue("passChngReqDate"));                          
                            //newRow.createCell(13).setCellValue(((Boolean)repositoryItem.getPropertyValue("isPunchoutUser"))); 
                            //AMS-65 and AMS-238
                            //newRow.createCell(13).setCellValue(repositoryItem.getPropertyValue("isPunchoutUser") == null ? "-" : (Boolean)repositoryItem.getPropertyValue("isPunchoutUser"));
                            //RepositoryItem checkIsPunchoutUser = (RepositoryItem) repositoryItem.getPropertyValue("isPunchoutUser");
                            if((Boolean) repositoryItem.getPropertyValue("isPunchoutUser")== null) {
                            newRow.createCell(13).setCellValue("-");
                            } else {
                            newRow.createCell(13).setCellValue(((Boolean)repositoryItem.getPropertyValue("isPunchoutUser"))); 
                            }
                            newRow.createCell(14).setCellValue(repositoryItem.getPropertyValue("punchoutMember") == null ? "-" : (String)repositoryItem.getPropertyValue("punchoutMember")); 
                            //newRow.createCell(15).setCellValue(repositoryItem.getPropertyValue("dropShipment") == null ? "-" : (Boolean)repositoryItem.getPropertyValue("dropShipment")); 
                            // RepositoryItem checkDropShipment = (RepositoryItem) repositoryItem.getPropertyValue("dropShipment");
                            if((Boolean) repositoryItem.getPropertyValue("dropShipment")== null) {
                            newRow.createCell(15).setCellValue("-");
                            } else {
                            newRow.createCell(15).setCellValue(((Boolean)repositoryItem.getPropertyValue("dropShipment"))); 
                            }
                            newRow.createCell(16).setCellValue(repositoryItem.getPropertyValue("emailStatus") == null ? "-" : (String)repositoryItem.getPropertyValue("emailStatus"));
                            //PresentnewRow.createCell(19).setCellValue(dtFormat.format(((Date) repositoryItem.getPropertyValue("lastEmailed"))));
                            //newRow.createCell(19).setCellValue(repositoryItem.getPropertyValue("lastEmailed") == null ? "-" : (String)repositoryItem.getPropertyValue("lastEmailed"));
                                         
                            rownum++;
                        }
                    } 
                        else {

                        vlogDebug("No data found");

                    }
                 // RBE APP 4484 END
                	
                } catch (Exception e) {
                    vlogError(e, "Registration report error{0}", e);
                }
                break;

            case SALESREPORT:
                try {
                    for ( RepositoryItem repositoryItem : repositoryItems) {
                        HSSFRow newRow = sheet.createRow(rownum);
                        newRow.createCell(ORDER_Order_Id).setCellValue(
                                repositoryItem.getPropertyValue("id") == null ? "-" : (String) repositoryItem.getPropertyValue("id"));

                        List<RepositoryItem> shippinggroup = (List<RepositoryItem>) repositoryItem.getPropertyValue("shippingGroups");

                        if (shippinggroup.isEmpty()) {

                            newRow.createCell(ORDER_Customer_Email).setCellValue("-");
                            newRow.createCell(ORDER_Country_ID).setCellValue("-");
                        }

                        else {
                            newRow.createCell(ORDER_Customer_Email).setCellValue(
                                    shippinggroup.get(0).getPropertyValue("email") != null ? ((String) shippinggroup.get(0).getPropertyValue("email")) : "-");
                            newRow.createCell(ORDER_Country_ID).setCellValue(
                                    shippinggroup.get(0).getPropertyValue("country") != null ? ((String) shippinggroup.get(0).getPropertyValue("country"))
                                            : "-");
                        }
                        RepositoryItem cpriceInfo = (RepositoryItem) repositoryItem.getPropertyValue("priceInfo");

                        if (cpriceInfo == null) {

                            newRow.createCell(ORDER_Grand_Total).setCellValue("-");
                        } else {
                            double gTotal = cpriceInfo.getPropertyValue("amount") != null ? (Double) cpriceInfo.getPropertyValue("amount") : 0.0d;
                            gTotal += cpriceInfo.getPropertyValue("tax") != null ? (Double) cpriceInfo.getPropertyValue("tax") : 0.0d;
                            gTotal += cpriceInfo.getPropertyValue("shipping") != null ? (Double) cpriceInfo.getPropertyValue("shipping") : 0.0d;
                            newRow.createCell(ORDER_Grand_Total).setCellValue(gTotal);
                        }
                        newRow.createCell(ORDER_Date_and_Time).setCellValue(
                                repositoryItem.getPropertyValue("submittedDate") != null ? dtFormat.format((Date) repositoryItem
                                        .getPropertyValue("submittedDate")) : "-");
                        newRow.createCell(ORDER_SAP_ORDER_ID).setCellValue(
                                repositoryItem.getPropertyValue("sapOrderId") != null ? (String) repositoryItem.getPropertyValue("sapOrderId") : "-");
                        if ((repositoryItem.getPropertyValue("sapOrderId") == "") || (repositoryItem.getPropertyValue("sapOrderId") == null)) {
                            newRow.createCell(ORDER_Order_Type).setCellValue("WEB");
                        } else {
                            newRow.createCell(ORDER_Order_Type).setCellValue("SAP");
                        }

                        rownum++;
                    }
                } catch (Exception e) {
                    vlogError(e, "order report error{0}", e);
                }
                break;

            case QCPDREPORT:
                try {

                    for ( RepositoryItem repositoryItem : repositoryItems) {

                        Set<Date> check = (Set<Date>) repositoryItem.getPropertyValue("clickDate");

                        if (!check.isEmpty()) {

                            Iterator<Date> iterator;

                            iterator = check.iterator();
                            while (iterator.hasNext()) {

                                HSSFRow newRow = sheet.createRow(rownum);

                                newRow.createCell(QCPD_Customer_Email).setCellValue(
                                        repositoryItem.getPropertyValue("email") != null ? ((String) repositoryItem.getPropertyValue("email")) : "-");
                                newRow.createCell(QCPD_First_Name).setCellValue(
                                        repositoryItem.getPropertyValue("firstName") != null ? ((String) repositoryItem.getPropertyValue("firstName")) : "-");
                                newRow.createCell(QCPD_Last_Name).setCellValue(
                                        repositoryItem.getPropertyValue("lastName") != null ? ((String) repositoryItem.getPropertyValue("lastName")) : "-");

                                RepositoryItem billingadd = (RepositoryItem) repositoryItem.getPropertyValue("billingaddress");

                                if (billingadd == null) {

                                    newRow.createCell(QCPD_Org).setCellValue("-");
                                    newRow.createCell(QCPD_Address1).setCellValue("-");
                                    newRow.createCell(QCPD_Address2).setCellValue("-");
                                    newRow.createCell(QCPD_City).setCellValue("-");
                                    newRow.createCell(QCPD_State).setCellValue("-");
                                    newRow.createCell(QCPD_Zip).setCellValue("-");
                                    newRow.createCell(QCPD_Country).setCellValue("-");
                                    newRow.createCell(QCPD_Phone).setCellValue("-");

                                }

                                else {

                                    newRow.createCell(QCPD_Org).setCellValue(
                                            billingadd.getPropertyValue("companyName") != null ? ((String) billingadd.getPropertyValue("companyName")) : "-");
                                    newRow.createCell(QCPD_Address1).setCellValue(
                                            billingadd.getPropertyValue("address1") != null ? ((String) billingadd.getPropertyValue("address1")) : "-");
                                    newRow.createCell(QCPD_Address2).setCellValue(
                                            billingadd.getPropertyValue("address2") != null ? ((String) billingadd.getPropertyValue("address2")) : "-");
                                    newRow.createCell(QCPD_City).setCellValue(
                                            billingadd.getPropertyValue("city") != null ? ((String) billingadd.getPropertyValue("city")) : "-");
                                    newRow.createCell(QCPD_State).setCellValue(
                                            billingadd.getPropertyValue("state") != null ? ((String) billingadd.getPropertyValue("state")) : "-");
                                    newRow.createCell(QCPD_Zip).setCellValue(
                                            billingadd.getPropertyValue("postalCode") != null ? ((String) billingadd.getPropertyValue("postalCode")) : "-");
                                    newRow.createCell(QCPD_Country).setCellValue(
                                            billingadd.getPropertyValue("country") != null ? ((String) billingadd.getPropertyValue("country")) : "-");
                                    newRow.createCell(QCPD_Phone).setCellValue(
                                            billingadd.getPropertyValue("phoneNumber") != null ? ((String) billingadd.getPropertyValue("phoneNumber")) : "-");
                                }
                                newRow.createCell(QCPD_Date_Account_Added).setCellValue(
                                        dtFormat.format((Date) repositoryItem.getPropertyValue("registrationDate")));

                                newRow.createCell(QCPD_Click_Date).setCellValue(dtFormat.format(iterator.next()));

                                rownum++;
                            }

                        }

                    }
                } catch (Exception e) {

                    vlogError(e, "Qcpd report error{0}", e);
                }
                break;

            case SUREFISHREPORT:
                try {
                    for ( RepositoryItem repositoryItem : repositoryItems) {
                        HSSFRow newRow = sheet.createRow(rownum);

                        newRow.createCell(SUREFISH_vendor_id).setCellValue((String) repositoryItem.getPropertyValue("vendor_id"));

                        Repository rep = (Repository) getRepository().get("ADMIN");

                        RepositoryView view = rep.getView(getViewName().get("ADMIN"));
                        Object params[] = new Object[4];
                        params[0] = repositoryItem.getPropertyValue("vendor_id");

                        List<RepositoryItem> repositoryItem1 = getResults(

                        RqlStatement.parseRqlStatement(getFetchRql().get("ADMIN")), view, params);

                        RepositoryItem repItem = null;

                        if (repositoryItem1.isEmpty()) {
                            newRow.createCell(SUREFISH_vendor_name).setCellValue("-");
                            newRow.createCell(SUREFISH_status).setCellValue("-");
                        } else {

                            repItem = repositoryItem1.get(0);

                            if (repItem != null) {

                                vendorName = (String) repItem.getPropertyValue("vendorName");
                                newRow.createCell(SUREFISH_vendor_name).setCellValue(vendorName);

                                convertBoleanToString = (repItem.getPropertyValue("isActive").toString());
                                if (convertBoleanToString.contentEquals("true"))
                                    newRow.createCell(SUREFISH_status).setCellValue("Active");
                                else
                                    newRow.createCell(SUREFISH_status).setCellValue("In Active");
                            }
                        }

                        newRow.createCell(SUREFISH_url_referrer).setCellValue((String) repositoryItem.getPropertyValue("urlReferrer"));

                        convertBoleanToString = repositoryItem.getPropertyValue("landed") == null ? "NO"
                                : (Boolean) repositoryItem.getPropertyValue("landed") ? "Yes" : "No";
                        if (convertBoleanToString.contentEquals("Yes")) {
                            newRow.createCell(SUREFISH_landed).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_date_landed).setCellValue(dtFormat.format((Date) repositoryItem.getPropertyValue("dateLanded")));
                        } else {
                            newRow.createCell(SUREFISH_landed).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_date_landed).setCellValue("-");
                        }

                        convertBoleanToString = repositoryItem.getPropertyValue("checkout") == null ? "NO" : (Boolean) repositoryItem
                                .getPropertyValue("checkout") ? "Yes" : "No";
                        if (convertBoleanToString.contentEquals("Yes")) {
                            newRow.createCell(SUREFISH_checkout).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateCheckout).setCellValue(dtFormat.format((Date) repositoryItem.getPropertyValue("dateCheckout")));
                        } else {
                            newRow.createCell(SUREFISH_checkout).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateCheckout).setCellValue("-");
                        }

                        convertBoleanToString = repositoryItem.getPropertyValue("orderSubmitted") == null ? "-" : (String) repositoryItem
                                .getPropertyValue("orderSubmitted");
                        if (convertBoleanToString.contentEquals("-")) {
                            newRow.createCell(SUREFISH_orderSubmitted).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateOrderSubmitted).setCellValue(convertBoleanToString);
                        } else {
                            newRow.createCell(SUREFISH_orderSubmitted).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateOrderSubmitted).setCellValue(
                                    dtFormat.format((Date) repositoryItem.getPropertyValue("dateOrderSubmitted")));
                        }

                        convertBoleanToString = repositoryItem.getPropertyValue("rfq") == null ? "NO"
                                : (Boolean) repositoryItem.getPropertyValue("rfq") ? "Yes" : "No";
                        if (convertBoleanToString.contentEquals("Yes")) {
                            newRow.createCell(SUREFISH_rfq).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateRFQSubmitted).setCellValue(
                                    dtFormat.format((Date) repositoryItem.getPropertyValue("dateRFQSubmitted")));
                        } else {
                            newRow.createCell(SUREFISH_rfq).setCellValue(convertBoleanToString);
                            newRow.createCell(SUREFISH_dateRFQSubmitted).setCellValue("-");
                        }

                        rownum++;
                    }
                   
                    
                } catch (Exception e) {
                    vlogError(e, "surefish report error{0}", e);
                }
                break;

            case REQUESTQUOTE:
                try {

                    if (repositoryItems != null) {
                        for ( RepositoryItem repositoryItem : repositoryItems) {
                            HSSFRow newRow = sheet.createRow(rownum);
                            newRow.createCell(0).setCellValue(repositoryItem.getPropertyValue("titleDefault") == null ? "-" : (String) repositoryItem.getPropertyValue("titleDefault"));
                            newRow.createCell(1).setCellValue(repositoryItem.getPropertyValue("firstName") == null ? "-" : (String) repositoryItem.getPropertyValue("firstName"));
                            newRow.createCell(REQUESTQUOTE_lastName).setCellValue(
                                    repositoryItem.getPropertyValue("lastName") == null ? "-" : (String) repositoryItem.getPropertyValue("lastName"));
                            newRow.createCell(REQUESTQUOTE_country).setCellValue(
                                    repositoryItem.getPropertyValue("country") == null ? "-" : (String) repositoryItem.getPropertyValue("country"));
                            newRow.createCell(REQUESTQUOTE_jobTitle).setCellValue(
                                    repositoryItem.getPropertyValue("jobTitle") == null ? "-" : (String) repositoryItem.getPropertyValue("jobTitle"));
                            newRow.createCell(REQUESTQUOTE_dept).setCellValue(
                                    repositoryItem.getPropertyValue("dept") == null ? "-" : (String) repositoryItem.getPropertyValue("dept"));
                            newRow.createCell(REQUESTQUOTE_org).setCellValue(
                                    repositoryItem.getPropertyValue("org") == null ? "-" : (String) repositoryItem.getPropertyValue("org"));
                            newRow.createCell(REQUESTQUOTE_address).setCellValue(
                                    repositoryItem.getPropertyValue("address") == null ? "-" : (String) repositoryItem.getPropertyValue("address"));
                            newRow.createCell(REQUESTQUOTE_address1).setCellValue(
                                    repositoryItem.getPropertyValue("address1") == null ? "-" : (String) repositoryItem.getPropertyValue("address1"));
                            newRow.createCell(REQUESTQUOTE_city).setCellValue(
                                    repositoryItem.getPropertyValue("city") == null ? "-" : (String) repositoryItem.getPropertyValue("city"));
                            newRow.createCell(REQUESTQUOTE_state).setCellValue(
                                    repositoryItem.getPropertyValue("state") == null ? "-" : (String) repositoryItem.getPropertyValue("state"));
                            newRow.createCell(REQUESTQUOTE_zip).setCellValue(
                                    repositoryItem.getPropertyValue("zip") == null ? "-" : (String) repositoryItem.getPropertyValue("zip"));
                            newRow.createCell(REQUESTQUOTE_phone).setCellValue(
                                    repositoryItem.getPropertyValue("phone") == null ? "-" : (String) repositoryItem.getPropertyValue("phone"));
                            newRow.createCell(REQUESTQUOTE_email).setCellValue(
                                    repositoryItem.getPropertyValue("email") == null ? "-" : (String) repositoryItem.getPropertyValue("email"));
                            newRow.createCell(REQUESTQUOTE_primJobFuncs).setCellValue(
                                    repositoryItem.getPropertyValue("primJobFuncs") == null ? "-" : (String) repositoryItem.getPropertyValue("primJobFuncs"));
                            newRow.createCell(REQUESTQUOTE_erfqId).setCellValue(
                                    repositoryItem.getPropertyValue("erfqId") == null ? "-" : (String) repositoryItem.getPropertyValue("erfqId"));
                          
                            Set<RepositoryItem> partNumsItem = new java.util.HashSet<RepositoryItem>();
                            partNumsItem = (Set<RepositoryItem>) repositoryItem.getPropertyValue("partNums");
                            String catalogId = "";
                            Number zero = 0;
                            Long quantity = zero.longValue();
                            String quant = "";
                            String productName = "";
                            int count = 0;

                            for ( RepositoryItem partItems : partNumsItem) {
                                if (count >= 1) {
                                    catalogId = catalogId + "," + (String) partItems.getPropertyValue("catId");

                                    quantity = (Long) partItems.getPropertyValue("quantity");
                                    if (quantity != null) {
                                        quant = quant + "," + quantity.toString();
                                    }
                                    productName = productName + "," + (String) partItems.getPropertyValue("productName");
                                    count++;
                                } else {
                                    catalogId = (String) partItems.getPropertyValue("catId");
                                    quantity = (Long) partItems.getPropertyValue("quantity");
                                    if (quantity != null) {
                                        quant = quantity.toString();
                                    }
                                    productName = (String) partItems.getPropertyValue("productName");
                                    count++;
                                }
                            }

                            newRow.createCell(REQUESTQUOTE_catId).setCellValue(catalogId);

                            newRow.createCell(REQUESTQUOTE_productName).setCellValue(productName);

                            newRow.createCell(REQUESTQUOTE_quantity).setCellValue(quant);

                            List<String> ProductionArea = (List<String>) repositoryItem.getPropertyValue("prodAreas");
                            int j = 0;
                            String areaProd = "";
                            while (j < ProductionArea.size()) {
                                if (j >= 1) {
                                    areaProd = areaProd + "," + ProductionArea.get(j);
                                    j++;
                                } else {
                                    areaProd = ProductionArea.get(j);
                                    j++;
                                }
                            }

                            newRow.createCell(REQUESTQUOTE_prodAreas).setCellValue(areaProd);
                            List<String> indAreas = (List<String>) repositoryItem.getPropertyValue("indAreas");

                            int i = 0;
                            String areaInd = "";
                            while (i < indAreas.size()) {
                                if (i >= 1) {
                                    areaInd = areaInd + "," + indAreas.get(i);
                                    i++;
                                } else {
                                    areaInd = indAreas.get(i);
                                    i++;
                                }
                            }
                            newRow.createCell(REQUESTQUOTE_indAreas).setCellValue(areaInd);
                            newRow.createCell(REQUESTQUOTE_comments).setCellValue(
                                    repositoryItem.getPropertyValue("comments") == null ? "-" : (String) repositoryItem.getPropertyValue("comments"));
                            newRow.createCell(REQUESTQUOTE_alternatePhone).setCellValue(
                                    repositoryItem.getPropertyValue("alternatePhone") == null ? "-" : (String) repositoryItem.getPropertyValue("alternatePhone"));
                            newRow.createCell(REQUESTQUOTE_bestTimeToCall).setCellValue(
                                    repositoryItem.getPropertyValue("bestTimeToCall") == null ? "-" : (String) repositoryItem.getPropertyValue("bestTimeToCall"));
                            newRow.createCell(REQUESTQUOTE_modelNumber).setCellValue(
                                    repositoryItem.getPropertyValue("modelNumber") == null ? "-" : (String) repositoryItem.getPropertyValue("modelNumber"));
                            newRow.createCell(REQUESTQUOTE_serialNumber).setCellValue(
                                    repositoryItem.getPropertyValue("serialNumber") == null ? "-" : (String) repositoryItem.getPropertyValue("serialNumber"));
                            newRow.createCell(REQUESTQUOTE_recieveEmailUpdates).setCellValue(
                                    repositoryItem.getPropertyValue("recieveEmailUpdates") == null ? "-" : (String) repositoryItem.getPropertyValue("recieveEmailUpdates"));
                            newRow.createCell(REQUESTQUOTE_dateCreated).setCellValue(
                                    repositoryItem.getPropertyValue("dateCreated") == null ? "-" : dtFormat.format((Date) repositoryItem
                                            .getPropertyValue("dateCreated")));
                            newRow.createCell(REQUESTQUOTE_source).setCellValue(
                                    repositoryItem.getPropertyValue("source") == null ? "-" : (String) repositoryItem.getPropertyValue("source"));
                            newRow.createCell(REQUESTQUOTE_contactMethod).setCellValue(
                                    repositoryItem.getPropertyValue("contactMethod") == null ? "-" : (String) repositoryItem.getPropertyValue("contactMethod"));
                            newRow.createCell(REQUESTQUOTE_referrerLink).setCellValue(
                                    repositoryItem.getPropertyValue("requestReferrer") == null ? "-" : (String) repositoryItem.getPropertyValue("requestReferrer"));
                            newRow.createCell(REQUESTQUOTE_erfqIdUpdateDetails).setCellValue(
                                    repositoryItem.getPropertyValue("erfqId") == null ? "-" : (String) repositoryItem.getPropertyValue("erfqId"));
                            newRow.createCell(REQUESTQUOTE_crmComments).setCellValue(
                                    repositoryItem.getPropertyValue("crmComments") == null ? "-" : (String) repositoryItem.getPropertyValue("crmComments"));
                          /*  newRow.createCell(REQUESTQUOTE_nonActionable).setCellValue(
                                    repositoryItem.getPropertyValue("nonActionable") == null ? "-" : (String) repositoryItem.getPropertyValue("nonActionable"));
                            newRow.createCell(REQUESTQUOTE_reason).setCellValue(
                                    repositoryItem.getPropertyValue("reason") == null ? "-" : (String) repositoryItem.getPropertyValue("reason"));*/
                           /* newRow.createCell(REQUESTQUOTE_crmId).setCellValue(
                                    repositoryItem.getPropertyValue("crmId") == null ? "-" : (String) repositoryItem.getPropertyValue("crmId"));*/
                  
                            rownum++;
                        }
                    } else {

                        vlogDebug("No data found");

                    }
                } catch (Exception e) {
                    vlogError(e, "Request quote report error{0}", e);
                }
                break;

            default:
                break;
        }
        return sheet;
    }
    // 4483 ERFQ RBE Updated the below method
	public void exportService(ReportType pReportType, Date pStartDate,
			Date pEndDate, String[] country, OutputStream pOutput) {

		List<RepositoryItem> resultItems = browseServiceWithCountries(pReportType,
				pStartDate, pEndDate, country);

		if (resultItems != null && resultItems.size() > 0) {
			try {

				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Export Worksheet");

				HSSFRow row = sheet.createRow(0);
				List<String> cols = getColumnsAsMapOfList().get(
						pReportType.name());
				for (int i = 0; i < cols.size(); i++) {
					String cellValue = cols.get(i);
					row.createCell(i).setCellValue(cellValue);

				}

				populateXL(pReportType, resultItems, sheet);

				wb.write(pOutput);
				pOutput.flush();

			} catch (FileNotFoundException e) {
				vlogError(e, "printing the Excel sheet error{0}", e);
			} catch (IOException e) {
				vlogError(e, "IO exception error:{0}", e);
			}
		} else {
			vlogDebug("No results returned");
			return;
		}
	}

	
	// RBE APP 4484 START
	public void exportProfileService(ReportType pReportType, Date pStartDate,Date pEndDate, int ecommenabled, String[] sapSalesOrg, int userType, OutputStream pOutput) {

		
		//List<RepositoryItem> resultItems = browseProfileService(pReportType, pStartDate, pEndDate, int ecommenabled, String sapSalesOrg, int userType) 
 List<RepositoryItem> resultItems = browseProfileService(pReportType, pStartDate, pEndDate, ecommenabled, sapSalesOrg, userType); 
		if (resultItems != null && resultItems.size() > 0) {
			try {

				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Export Worksheet");

				HSSFRow row = sheet.createRow(0); 
				// RBE APP 4484 END
				List<String> cols = getColumnsAsMapOfList().get(
						pReportType.name());
				vlogDebug("Debug {0}", cols.size());
				for (int i = 0; i < cols.size(); i++) {
					String cellValue = cols.get(i);
					vlogDebug("Cell Value{0}", cellValue);
					row.createCell(i).setCellValue(cellValue);

				}

				populateXL(pReportType, resultItems, sheet);

				wb.write(pOutput);
				pOutput.flush();

			} catch (FileNotFoundException e) {
				vlogError(e, "printing the Excel sheet error{0}", e);
			} catch (IOException e) {
				vlogError(e, "IO exception error:{0}", e);
			}
		} else {
			vlogDebug("No results returned");
			return;
		}
	}

	
	
	
	
	public void exportLSCAService(List<OrderManagementVO> pList,
			ReportType pReportType, OutputStream pOutput) {

		// List<RepositoryItem> resultItems = browseService(pReportType,
		// pStartDate, pEndDate);

		if (pList != null && pList.size() > 0) {
			try {

				HSSFWorkbook wb = new HSSFWorkbook();
				HSSFSheet sheet = wb.createSheet("Export Worksheet");

				HSSFRow row = sheet.createRow(0);
				List<String> cols = getColumnsAsMapOfList().get(
						pReportType.name());
				for (int i = 0; i < cols.size(); i++) {
					String cellValue = cols.get(i);
					row.createCell(i).setCellValue(cellValue);

				}

				populateOrderXL(pReportType, pList, sheet);

				wb.write(pOutput);
				pOutput.flush();

			} catch (FileNotFoundException e) {
				vlogError(e, "printing the Excel sheet error{0}", e);
			} catch (IOException e) {
				vlogError(e, "IO exception error:{0}", e);
			}
		} else {
			vlogDebug("No results returned");
			return;
		}
	}
    // 4483 ERFQ RBE Updated the below method
	public List<RepositoryItem> browseService(ReportType pReportType,
			Date pStartDate, Date pEndDate, String[] country) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];

			params[0] = pStartDate;

			vlogDebug("From date {0}", params[0]);

			params[1] = pEndDate;

			vlogDebug("From date {0}", params[1]);
			
			params[2] = country;

			vlogDebug("country {0}", params[2]);
			
			return getResults(
					RqlStatement.parseRqlStatement(getFetchRql().get(
							pReportType.name())), view, params);
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.EMPTY_LIST;
	}


	//APP 4483 RBE ERFQ TOOL Start
	public List<RepositoryItem> browseServiceWithCountries(
			ReportType pReportType, Date pStartDate, Date pEndDate,
			String[] country) {

	
		String[] countryCode=null;
			try {
				Repository rep = (Repository) getRepository().get(pReportType.name()); 
				RepositoryView repositoryView = rep.getView(getViewName().get(pReportType.name())); 
				Query queryStartDate;
				Query queryEndDate;
				Query queryFinal;
				Query countryQuery = null;
				if(repositoryView != null){
				                    QueryBuilder queryBuilder = repositoryView.getQueryBuilder();
					                     if(queryBuilder != null){
					                                  QueryExpression dateCreated = queryBuilder.createPropertyQueryExpression("dateCreated");
					                                  QueryExpression startDate = queryBuilder.createConstantQueryExpression(pStartDate);
					                                  QueryExpression endDate = queryBuilder.createConstantQueryExpression(pEndDate);
					                                  queryStartDate = queryBuilder.createComparisonQuery(dateCreated, startDate, QueryBuilder.GREATER_THAN_OR_EQUALS);
					                                  queryEndDate = queryBuilder.createComparisonQuery(dateCreated, endDate, QueryBuilder.LESS_THAN_OR_EQUALS);			       
							                      			if (country != null && country.length > 0) {
							                    				List<Query> query = new ArrayList<Query>();
							                    				for (int i = 0; i < country.length; i++) {
							                    					List<Query> salesQuery = new ArrayList<Query>();
							                    					countryCode = country[i].split("-");
							                    					QueryExpression countryExp = queryBuilder
							                    							.createPropertyQueryExpression("country");
							                    					QueryExpression countryvalue = queryBuilder
							                    							.createConstantQueryExpression(countryCode[0]);
							                    					countryQuery = queryBuilder.createComparisonQuery(
							                    							countryExp, countryvalue, QueryBuilder.EQUALS);
							                    					if (countryQuery != null)
							                    						query.add(countryQuery);
							                    				}
							                    				countryQuery = queryBuilder.createOrQuery((Query[]) query
							                    						.toArray(new Query[query.size()]));
							                    				}
					                                    queryFinal = queryBuilder.createAndQuery(new Query[]{queryStartDate, queryEndDate, countryQuery});
					                                    SortDirectives sortDirectives = new SortDirectives(); 
					                                    sortDirectives.addDirective(new SortDirective("dateCreated", 1));
					                                    RepositoryItem[] result = repositoryView.executeQuery(queryFinal,sortDirectives);
					                                    List<RepositoryItem> items = Collections.emptyList();
					                        			if (result != null && result.length > 0) {
					                        				items = Arrays.asList(result);
					                        			}
					                        			return items; 
					                                  }
				                           }
					
			}
		catch (RepositoryException e) {
			vlogError(e, "Repository exception error :{0}", e);
		}
		return Collections.emptyList();
	}
	//APP 4483 RBE ERFQ TOOL End
	
/*	public List<RepositoryItem> browseProfileService(ReportType pReportType,
			Date pStartDate, Date pEndDate, int ecommenabled,
			String sapSalesOrg, int userType) {
		RepositoryItem[] resultItems = null;
		List<RepositoryItem> resultList = null;
		Set<RepositoryItem> resultSet = null;

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			vlogDebug("View Name {0}", view);
			vlogDebug("Rql Statement {0}: ", getFetchRql().get(pReportType.name()));
			if(ecommenabled==0)
			{
				Object params[] = new Object[4];
				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);
								
				params[2] = sapSalesOrg;

				vlogDebug("User Sales Org {0}", params[3]);

				params[3] = userType;

				RqlStatement stmt = RqlStatement.parseRqlStatement(getEcommEnabledBoth());
				vlogDebug("Statement {0}", stmt);
				resultItems = stmt.executeQuery(view, params);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			else
			if(userType==0)
			{
				Object params[] = new Object[4];
				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);

				params[2] =ecommenabled;

				vlogDebug("Palce Online Order{0} ", params[2]);

				params[3] = sapSalesOrg;

				vlogDebug("Sap Sales Org{0} ", params[3]);
				RqlStatement stmt = RqlStatement.parseRqlStatement(getMemberTypeBoth());
				vlogDebug("Statement {0}", stmt);
				resultItems = stmt.executeQuery(view, params);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
				
			}
			else
			if(ecommenabled==0 & userType==0)
			{
				Object params[] = new Object[3];
				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);

				
				params[2] = sapSalesOrg;
				
				vlogDebug("Sap Sales Org{0}", params[2]);
				
				RqlStatement stmt = RqlStatement.parseRqlStatement(getEcommEnabledMemberTypeBoth());
				vlogDebug("Statement {0}", stmt);
				resultItems = stmt.executeQuery(view, params);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			else
			{
			Object params[] = new Object[5];

			params[0] = pStartDate;

			vlogDebug("From date {0}", params[0]);

			params[1] = pEndDate;

			vlogDebug("From date {0}", params[1]);

			params[2] =ecommenabled;

			vlogDebug("Palce Online Order{0} ", params[2]);

			params[3] = sapSalesOrg;

			vlogDebug("User Sales Org {0}", params[3]);

			params[4] = userType;

			vlogDebug("UgetResultsser Type {0}", params[4]);
			
			RqlStatement stmt = RqlStatement.parseRqlStatement(getFetchRql().get(pReportType.name()));
			
			vlogDebug("Statement {0}", stmt);
			resultItems = stmt.executeQuery(view, params);
			vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			if(resultItems != null && resultItems.length > 0)
			{
				resultSet = new HashSet<RepositoryItem>();
				for(RepositoryItem item : resultItems)
				{
					resultSet.add(item);
					vlogDebug("Item Added {0}: ", item);
				}
				resultList = new ArrayList<RepositoryItem>(resultSet);
				vlogDebug("ResultLis +++++ {0} : ", resultList);
				
			}
			
			return getResults(

					RqlStatement.parseRqlStatement(getFetchRql().get(
							pReportType.name())), view, params);
			
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
			return Collections.EMPTY_LIST;
			}
		
		return resultList;
	}*/

	//RBE APP 4484 START
	public List<RepositoryItem> browseProfileService(ReportType pReportType,
			Date pStartDate, Date pEndDate, int ecommenabled,
			String [] sapSalesOrg, int userType) {
		RepositoryItem[] resultItems = null;
		List<RepositoryItem> resultList = null;
		Set<RepositoryItem> resultSet = null;

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			vlogDebug("View Name {0}", view);
			vlogDebug("Rql Statement {0}: ", getFetchRql().get(pReportType.name()));
		    if(ecommenabled==0 && userType!= 0)
			{QueryBuilder builder = view.getQueryBuilder();
			QueryExpression starDateExp = builder
					.createPropertyQueryExpression("registrationDate");
			QueryExpression startDateValue = builder
					.createConstantQueryExpression(pStartDate);
			Query startDateQuery = builder.createComparisonQuery(starDateExp,
					startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
			QueryExpression endDateValue = builder
					.createConstantQueryExpression(pEndDate);
			Query endDateQuery = builder.createComparisonQuery(starDateExp,
					endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

			ArrayList<Query> queries = new ArrayList<Query>();
			queries.add(startDateQuery);
			queries.add(endDateQuery);
			if (sapSalesOrg != null && sapSalesOrg.length > 0) {
				List<Query> query = new ArrayList<Query>();
				for (int i = 0; i < sapSalesOrg.length; i++) {
					String[] salesOrgCode = sapSalesOrg[i].split(":");
					QueryExpression salesOrgExp = builder
							.createPropertyQueryExpression("sapSalesOrg");
					QueryExpression salesOrgvalue = builder
							.createConstantQueryExpression(salesOrgCode[0]);
					Query registerSalesOrgQuery = builder.createComparisonQuery(
							salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
					
					if (registerSalesOrgQuery != null)
						query.add(registerSalesOrgQuery);
				}
				Query salesOrgQuerytool = builder.createOrQuery((Query[]) query
						.toArray(new Query[query.size()]));
				queries.add(salesOrgQuerytool);
			}
					QueryExpression userTypeExp = builder
							.createPropertyQueryExpression("memberType");
					QueryExpression userTypeExpvalue = builder
							.createConstantQueryExpression(userType);
					queries.add(builder.createComparisonQuery(userTypeExp,
							userTypeExpvalue, QueryBuilder.EQUALS));
					
			Query startAndendDateQuery = builder
					.createAndQuery((Query[]) queries.toArray(new Query[queries
							.size()]));

			SortDirectives sortDirectives = new SortDirectives();
			sortDirectives.addDirective(new SortDirective("registrationDate",
					SortDirective.DIR_DESCENDING));
			vlogInfo("{0}", startAndendDateQuery);
			resultItems = view.executeQuery(startAndendDateQuery, sortDirectives);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			else
			if(userType==0 && ecommenabled!=0)
			{
				QueryBuilder builder = view.getQueryBuilder();
				QueryExpression starDateExp = builder
						.createPropertyQueryExpression("registrationDate");
				QueryExpression startDateValue = builder
						.createConstantQueryExpression(pStartDate);
				Query startDateQuery = builder.createComparisonQuery(starDateExp,
						startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
				QueryExpression endDateValue = builder
						.createConstantQueryExpression(pEndDate);
				Query endDateQuery = builder.createComparisonQuery(starDateExp,
						endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

				ArrayList<Query> queries = new ArrayList<Query>();
				queries.add(startDateQuery);
				queries.add(endDateQuery);
				if (sapSalesOrg != null && sapSalesOrg.length > 0) {
					List<Query> query = new ArrayList<Query>();
					for (int i = 0; i < sapSalesOrg.length; i++) {
						String[] salesOrgCode = sapSalesOrg[i].split(":");
						QueryExpression salesOrgExp = builder
								.createPropertyQueryExpression("sapSalesOrg");
						QueryExpression salesOrgvalue = builder
								.createConstantQueryExpression(salesOrgCode[0]);
						Query registerSalesOrgQuery = builder.createComparisonQuery(
								salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
						
						if (registerSalesOrgQuery != null)
							query.add(registerSalesOrgQuery);
					}
					Query salesOrgQuerytool = builder.createOrQuery((Query[]) query
							.toArray(new Query[query.size()]));
					queries.add(salesOrgQuerytool);
				}
				
				QueryExpression ecommenabledExp = builder
						.createPropertyQueryExpression("eCommStatus");
				QueryExpression ecommenabledExpvalue = builder
						.createConstantQueryExpression(ecommenabled);
				queries.add(builder.createComparisonQuery(ecommenabledExp,
						ecommenabledExpvalue, QueryBuilder.EQUALS));
				Query startAndendDateQuery = builder
						.createAndQuery((Query[]) queries.toArray(new Query[queries
								.size()]));

				SortDirectives sortDirectives = new SortDirectives();
				sortDirectives.addDirective(new SortDirective("registrationDate",
						SortDirective.DIR_DESCENDING));
				vlogInfo("{0}", startAndendDateQuery);
				resultItems = view.executeQuery(startAndendDateQuery, sortDirectives);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			else
			if(ecommenabled==0 & userType==0)
			{
				QueryBuilder builder = view.getQueryBuilder();
				QueryExpression starDateExp = builder
						.createPropertyQueryExpression("registrationDate");
				QueryExpression startDateValue = builder
						.createConstantQueryExpression(pStartDate);
				Query startDateQuery = builder.createComparisonQuery(starDateExp,
						startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
				QueryExpression endDateValue = builder
						.createConstantQueryExpression(pEndDate);
				Query endDateQuery = builder.createComparisonQuery(starDateExp,
						endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

				ArrayList<Query> queries = new ArrayList<Query>();
				queries.add(startDateQuery);
				queries.add(endDateQuery);
				if (sapSalesOrg != null && sapSalesOrg.length > 0) {
					List<Query> query = new ArrayList<Query>();
					for (int i = 0; i < sapSalesOrg.length; i++) {
						String[] salesOrgCode = sapSalesOrg[i].split(":");
						QueryExpression salesOrgExp = builder
								.createPropertyQueryExpression("sapSalesOrg");
						QueryExpression salesOrgvalue = builder
								.createConstantQueryExpression(salesOrgCode[0]);
						Query registerSalesOrgQuery = builder.createComparisonQuery(
								salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
						
						if (registerSalesOrgQuery != null)
							query.add(registerSalesOrgQuery);
					}
					Query salesOrgQuerytool = builder.createOrQuery((Query[]) query
							.toArray(new Query[query.size()]));
					queries.add(salesOrgQuerytool);
				}
				Query startAndendDateQuery = builder
						.createAndQuery((Query[]) queries.toArray(new Query[queries
								.size()]));

				SortDirectives sortDirectives = new SortDirectives();
				sortDirectives.addDirective(new SortDirective("registrationDate",
						SortDirective.DIR_DESCENDING));
				vlogInfo("{0}", startAndendDateQuery);
				resultItems = view.executeQuery(startAndendDateQuery, sortDirectives);
				vlogDebug("Query Executed Itwm Returned {0}  :", resultItems);
			}
			else
			{
					QueryBuilder builder = view.getQueryBuilder();
					QueryExpression starDateExp = builder
							.createPropertyQueryExpression("registrationDate");
					QueryExpression startDateValue = builder
							.createConstantQueryExpression(pStartDate);
					Query startDateQuery = builder.createComparisonQuery(starDateExp,
							startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
					QueryExpression endDateValue = builder
							.createConstantQueryExpression(pEndDate);
					Query endDateQuery = builder.createComparisonQuery(starDateExp,
							endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

					ArrayList<Query> queries = new ArrayList<Query>();
					queries.add(startDateQuery);
					queries.add(endDateQuery);
					if (sapSalesOrg != null && sapSalesOrg.length > 0) {
						List<Query> query = new ArrayList<Query>();
						for (int i = 0; i < sapSalesOrg.length; i++) {
							String[] salesOrgCode = sapSalesOrg[i].split(":");
							QueryExpression salesOrgExp = builder
									.createPropertyQueryExpression("sapSalesOrg");
							QueryExpression salesOrgvalue = builder
									.createConstantQueryExpression(salesOrgCode[0]);
							Query registerSalesOrgQuery = builder.createComparisonQuery(
									salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
							
							if (registerSalesOrgQuery != null)
								query.add(registerSalesOrgQuery);
						}
						Query salesOrgQuerytool = builder.createOrQuery((Query[]) query
								.toArray(new Query[query.size()]));
						queries.add(salesOrgQuerytool);
					}
							QueryExpression ecommenabledExp = builder
									.createPropertyQueryExpression("eCommStatus");
							QueryExpression ecommenabledExpvalue = builder
									.createConstantQueryExpression(ecommenabled);
							queries.add(builder.createComparisonQuery(ecommenabledExp,
									ecommenabledExpvalue, QueryBuilder.EQUALS));
							QueryExpression userTypeExp = builder
									.createPropertyQueryExpression("memberType");
							QueryExpression userTypeExpvalue = builder
									.createConstantQueryExpression(userType);
							queries.add(builder.createComparisonQuery(userTypeExp,
									userTypeExpvalue, QueryBuilder.EQUALS));
							
					Query startAndendDateQuery = builder
							.createAndQuery((Query[]) queries.toArray(new Query[queries
									.size()]));

					SortDirectives sortDirectives = new SortDirectives();
					sortDirectives.addDirective(new SortDirective("registrationDate",
							SortDirective.DIR_DESCENDING));
					vlogInfo("{0}", startAndendDateQuery);
					resultItems = view.executeQuery(startAndendDateQuery, sortDirectives);
			}
			if(resultItems != null && resultItems.length > 0)
			{
				resultSet = new HashSet<RepositoryItem>();
				for(RepositoryItem item : resultItems)
				{
					resultSet.add(item);
					vlogDebug("Item Added {0}: ", item);
				}
				resultList = new ArrayList<RepositoryItem>(resultSet);
				vlogDebug("ResultLis +++++ {0} : ", resultList);
				}
		}		
		 catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
			return Collections.EMPTY_LIST;
		}
			
			return resultList;
		
		
	}

	// RBE APP 4484 END
	
	public List<RepositoryItem> orderTool(ReportType pReportType,
			Date pLastThreeDays, Date pCurrentDate) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];
			params[0] = pLastThreeDays;

			vlogDebug("From date {0}", params[0]);

			params[1] = pCurrentDate;

			vlogDebug("From date {0}", params[1]);

			return getResults(
					RqlStatement.parseRqlStatement(getLastThreeDaysOrderRql()
							.get(pReportType.name())), view, params);

		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.EMPTY_LIST;

	}

	public List<OrderManagementVO> orderToolLsca(ReportType pReportType,
			int pOrderCount, Date pLastThreeDays, Date pCurrentDate) {
		try {
			List<OrderManagementVO> resultList = new ArrayList<OrderManagementVO>();
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];
			params[0] = pCurrentDate;
			params[1] = pLastThreeDays;
			params[2] = pOrderCount;

			vlogDebug("Order Count {0}", params[0]);

			RepositoryItem[] results = getResultsForOrder(
					RqlStatement.parseRqlStatement(getLastTwoHundredOrderRql()
							.get(pReportType.name())), view, params);

			if (results != null && results.length > 0) {
				/*
				 * vlogInfo("No: Of Orders fetched for last three Days {0}",results
				 * .length);
				 */
				for (RepositoryItem item : results) {
					resultList
							.add(populateOrderManagementVo(item, false, null, null));
				}
				return resultList;

			}
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.emptyList();

	}

	public RepositoryItem[] orderToolLsca(ReportType pReportType, String orderId) {
		RepositoryItem[] result = null;
		 List<RepositoryItem> resultList = new ArrayList<RepositoryItem>();
         List<RepositoryItem> validList = new ArrayList<RepositoryItem>();
		try {
			// List<OrderManagementVO> resultList=new
			// ArrayList<OrderManagementVO>();
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];

			params[0] = orderId;

			vlogDebug("Order ID {0}", params[0]);

			result = getResultsForOrder(
					RqlStatement.parseRqlStatement(getOrderRql().get(
							pReportType.name())), view, params);
			// resultList.add(populateOrderManagementVo(result.get(0)));
			//AMS-498 and AMS-532 Changes
            if (result != null && result.length > 0) {
	               resultList = Arrays.asList(result);
	               vlogDebug("Description List Size is : " +getDescriptionList().size());
                   vlogDebug("Description List Items are : " +getDescriptionList().toString());
	  			   vlogDebug("Repository Item Count before filtering Dummy Subscription Orders and Large File Orders is : " +resultList.size());
	               for (RepositoryItem item : resultList) {
	                  if (item != null) {
	                     String description = (String) item.getPropertyValue("description");
	                     String createdByOrder = (String) item.getPropertyValue("createdByOrderId");
	                     if (!((description.equalsIgnoreCase("SUBSCRIPTION_ORDER") && createdByOrder == null) || (getDescriptionList().contains(description)))) {    
	                    	 validList.add(item);
	                     }
	                  }
	               }
	 			 vlogDebug("Repository Item Count after filtering Dummy Subscription Orders and Large File Orders is : " +validList.size());
	 			 if( validList.isEmpty()) {
	 	            result = null;
	 			 }
	 			 else {
	                 result = validList.toArray(new RepositoryItem[validList.size()]);  
	 			 }
	           }
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return result;

	}

	public List<RepositoryItem> orderTool(ReportType pReportType, String orderId) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];

			params[0] = orderId;

			vlogDebug("Order ID {0}", params[0]);

			return getResults(
					RqlStatement.parseRqlStatement(getOrderRql().get(
							pReportType.name())), view, params);

		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.EMPTY_LIST;

	}

	public List<RepositoryItem> getPunchoutOrder(ReportType pReportType,
			String orderId) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];

			params[0] = orderId;

			vlogDebug("Order ID {0}", params[0]);

			return getResults(
					RqlStatement.parseRqlStatement(getPunchoutRql().get(
							pReportType.name())), view, params);

		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.EMPTY_LIST;

	}

	public List<RepositoryItem> orderToolBySalesOrg(ReportType pReportType,
			Date pStartDate, Date pEndDate, String salesOrg, String[] pOrderType) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));

			QueryBuilder builder = view.getQueryBuilder();
			QueryExpression starDateExp = builder
					.createPropertyQueryExpression("submittedDate");
			QueryExpression startDateValue = builder
					.createConstantQueryExpression(pStartDate);
			Query startDateQuery = builder.createComparisonQuery(starDateExp,
					startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
			QueryExpression endDateValue = builder
					.createConstantQueryExpression(pEndDate);
			Query endDateQuery = builder.createComparisonQuery(starDateExp,
					endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

			ArrayList queries = new ArrayList();
			queries.add(startDateQuery);
			queries.add(endDateQuery);
			if (!StringUtils.isEmpty(salesOrg)) {
				QueryExpression salesOrgExp = builder
						.createPropertyQueryExpression("salesOrg");
				QueryExpression salesOrgvalue = builder
						.createConstantQueryExpression(salesOrg.toUpperCase());
				queries.add(builder.createComparisonQuery(salesOrgExp,
						salesOrgvalue, QueryBuilder.EQUALS));
			}

			if (pOrderType != null && pOrderType.length == 1) {
				QueryExpression ordertypeExp = builder
						.createPropertyQueryExpression("orderType");
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression(pOrderType[0]);
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.EQUALS));
			}

			Query startAndendDateQuery = builder
					.createAndQuery((Query[]) queries.toArray(new Query[queries
							.size()]));

			SortDirectives sortDirectives = new SortDirectives();
			sortDirectives.addDirective(new SortDirective("submittedDate",
					SortDirective.DIR_DESCENDING));
			RepositoryItem[] result = view.executeQuery(startAndendDateQuery,
					sortDirectives);
			List<RepositoryItem> items = Collections.emptyList();
			if (result != null && result.length > 0) {
				items = Arrays.asList(result);
			}
			return items;

		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.emptyList();

	}

	public List<RepositoryItem> orderTool(ReportType pReportType,
			Date pStartDate, Date pEndDate, String[] pOrderType) {

		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));
			Object params[] = new Object[4];
			if (pOrderType.length >= 2 && pOrderType[0].equals("WEB")
					&& pOrderType[1].equals("SAP")) {

				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);

				params[2] = pOrderType;

				vlogDebug("From date {0}", params[2]);
				return getResults(

						RqlStatement.parseRqlStatement(getFetchRql().get(
								pReportType.name())), view, params);

			} else if (pOrderType.length >= 1) {
				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);
				params[2] = pOrderType;

				vlogDebug("From date {0}", params[2]);

				return getResults(

						RqlStatement.parseRqlStatement(getOrderTypeRql().get(
								pReportType.name())), view, params);
			} else {
				params[0] = pStartDate;

				vlogDebug("From date {0}", params[0]);

				params[1] = pEndDate;

				vlogDebug("From date {0}", params[1]);
				
				
				
				
				return getResults(

						RqlStatement.parseRqlStatement(getFetchRql().get(
								pReportType.name())), view, params);
			}
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}

		return Collections.EMPTY_LIST;
	}

	/**
	 * @param pRep
	 */
	private List<RepositoryItem> getResults(RqlStatement pStat,
			RepositoryView pView, Object[] params) {

		RepositoryItem[] resultItems = null;
		List<RepositoryItem> resultList = null;
		Set<RepositoryItem> resultSet = null;
		try {
			resultItems = pStat.executeQuery(pView, params);
		} catch (RepositoryException e) {
			vlogError(e, "RepositoryException error :{0}", e);
		}

		if (resultItems != null && resultItems.length > 0) {
			resultSet = new HashSet<RepositoryItem>();
			for (RepositoryItem item : resultItems) {
				resultSet.add(item);
				//vlogDebug("SOmething Addedd", item.getPropertyValue("email"));
			}
			resultList = new ArrayList<RepositoryItem>(resultSet);
			return resultList;
		}

		return Collections.EMPTY_LIST;
	}

	private RepositoryItem[] getResultsForOrder(RqlStatement pStat,
			RepositoryView pView, Object[] params) {

		RepositoryItem[] resultItems = null;

		try {
			resultItems = pStat.executeQuery(pView, params);
		} catch (RepositoryException e) {
			vlogError(e, "RepositoryException error :{0}", e);
		}

		return resultItems;
	}

	/*Changes Start for the jaguar project*/
	public RepositoryItem[] orderToolBySalesOrg(ReportType pReportType,
			Date pStartDate, Date pEndDate, String[] salesOrg, String[] site,
			String[] pOrderType, String orderTrack, String partnerName, String partnerNumber,String orderQuoteRenewed, String contractQuoteNumber) {
/*Changes end for the jaguar project*/
		// List<OrderManagementVO> resultList=new
		// ArrayList<OrderManagementVO>();
		RepositoryItem[] result = null;
		try {

			/*Changes Start for the jaguar project*/
			result = generateOrderManagementQuery(pReportType, pStartDate,
					pEndDate, salesOrg, site, pOrderType, orderTrack,partnerName,partnerNumber,orderQuoteRenewed,contractQuoteNumber);
			
/*Changes end for the jaguar project*/	
			/*
			 * items = Collections.emptyList(); if (result != null &&
			 * result.length > 0) { items = Arrays.asList(result); }
			 */

			/*
			 * for(RepositoryItem item:items){ OrderManagementVO OrderMgmtVo=
			 * populateOrderManagementVo(item); resultList.add(OrderMgmtVo); }
			 */

		} catch (Exception e) {
			vlogError(e, "exception error :{0}", e);
		}

		return result;
	}

	public RepositoryItem[] generateOrderManagementQuery(
			ReportType pReportType, Date pStartDate, Date pEndDate,
			String[] salesOrg, String[] site, String[] pOrderType,
			String orderTrack, String pPartnerName, String pPartnerNumber,String orderQuoteRenewed, String contractQuoteNumber) {
		RepositoryItem[] result = null;
        List<RepositoryItem> resultList = new ArrayList<RepositoryItem>();
        List<RepositoryItem> validList = new ArrayList<RepositoryItem>();
		try {
			Repository rep = (Repository) getRepository().get(
					pReportType.name());
			RepositoryView view = rep.getView(getViewName().get(
					pReportType.name()));

			QueryBuilder builder = view.getQueryBuilder();
			QueryExpression starDateExp = builder
					.createPropertyQueryExpression("submittedDate");
			QueryExpression startDateValue = builder
					.createConstantQueryExpression(pStartDate);
			Query startDateQuery = builder.createComparisonQuery(starDateExp,
					startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
			QueryExpression endDateValue = builder
					.createConstantQueryExpression(pEndDate);
			Query endDateQuery = builder.createComparisonQuery(starDateExp,
					endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

			ArrayList<Query> queries = new ArrayList<Query>();
			queries.add(startDateQuery);
			queries.add(endDateQuery);
			if (salesOrg != null && salesOrg.length > 0) {
				List<Query> query = new ArrayList<Query>();
				for (int i = 0; i < salesOrg.length; i++) {
					List<Query> salesQuery = new ArrayList<Query>();
					String[] salesOrgCode = salesOrg[i].split(":");
					QueryExpression salesOrgExp = builder
							.createPropertyQueryExpression("salesOrg");
					QueryExpression salesOrgvalue = builder
							.createConstantQueryExpression(salesOrgCode[0]);
					Query salesOrgQuery = builder.createComparisonQuery(
							salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
					/*
					 * salesQuery.add(builder.createComparisonQuery(salesOrgExp,
					 * salesOrgvalue, QueryBuilder.EQUALS)); QueryExpression
					 * MemTypeOrgExp =
					 * builder.createPropertyQueryExpression("placedByMemType");
					 * QueryExpression MemTypevalue =
					 * builder.createConstantQueryExpression(salesOrgCode[1]);
					 * salesQuery
					 * .add(builder.createComparisonQuery(MemTypeOrgExp,
					 * MemTypevalue, QueryBuilder.EQUALS)); Query
					 * salesOrgMemTypeQuery =builder.createAndQuery((Query[])
					 * salesQuery.toArray(new Query[salesQuery.size()]));
					 */
					if (salesOrgQuery != null)
						query.add(salesOrgQuery);
				}
				Query salesOrgQuery = builder.createOrQuery((Query[]) query
						.toArray(new Query[query.size()]));
				queries.add(salesOrgQuery);
			}

			if (site != null && site.length > 0) {
				List<Query> query = new ArrayList<Query>();
				for (int i = 0; i < site.length; i++) {
					QueryExpression ordertypeExp = builder
							.createPropertyQueryExpression("siteId");
					QueryExpression ordertypevalue = builder
							.createConstantQueryExpression(site[i]);
					query.add(builder.createComparisonQuery(ordertypeExp,
							ordertypevalue, QueryBuilder.EQUALS));
				}
				Query siteQuery = builder.createOrQuery((Query[]) query
						.toArray(new Query[query.size()]));
				queries.add(siteQuery);
			}

			if (pOrderType != null && pOrderType.length >= 1) {
				QueryExpression ordertypeExp = builder
						.createPropertyQueryExpression("orderType");
				if (pOrderType != null && pOrderType.length == 1) {
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression(pOrderType[0]);
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.EQUALS));
				}
				else {
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression("NULL");
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.NOT_EQUALS));
				}
				QueryExpression ordertrackExp = builder
						.createPropertyQueryExpression("orderTrack");
				QueryExpression ordertrackvalue = builder
						.createConstantQueryExpression("CANCELLED");
				queries.add(builder.createComparisonQuery(ordertrackExp,
						ordertrackvalue, QueryBuilder.NOT_EQUALS));
				
				QueryExpression stateExp = builder
						.createPropertyQueryExpression("State");
				QueryExpression incompletestatevalue = builder
						.createConstantQueryExpression("INCOMPLETE");
				queries.add(builder.createComparisonQuery(stateExp,
						incompletestatevalue, QueryBuilder.NOT_EQUALS));

				QueryExpression quotedstatevalue = builder
						.createConstantQueryExpression("QUOTED");
				queries.add(builder.createComparisonQuery(stateExp,
						quotedstatevalue, QueryBuilder.NOT_EQUALS));
				
				
				}
			
			/* added orderTrack for CR AP-2979 */
			if ("CANCELLED".equalsIgnoreCase(orderTrack)) {
				QueryExpression ordertypeExp = builder
						.createPropertyQueryExpression("orderTrack");
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression("CANCELLED");
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.EQUALS));
			}
			// LYNX
			if ("RENEWED".equalsIgnoreCase(orderQuoteRenewed)) {
				QueryExpression ordertypeExp = builder
						.createPropertyQueryExpression("orderType");
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression("SAPCRM_ORDER");
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.EQUALS));
			}
			else if (StringUtils.isBlank(contractQuoteNumber))
			{
				QueryExpression ordertypeExp = builder
						.createPropertyQueryExpression("orderType");
				QueryExpression ordertypevalue = builder
						.createConstantQueryExpression("SAPCRM_ORDER");
				queries.add(builder.createComparisonQuery(ordertypeExp,
						ordertypevalue, QueryBuilder.NOT_EQUALS));
			}
			
			/*Changes Start for the jaguar project*/		
			if (!StringUtils.isBlank(pPartnerName))
				{
				QueryExpression partnerValue = builder
						.createPropertyQueryExpression("partnerName");
				QueryExpression partnerValueConst = builder
						.createConstantQueryExpression(pPartnerName);
				queries.add(builder.createComparisonQuery(partnerValue,
						partnerValueConst, QueryBuilder.EQUALS));
			}


			if (!StringUtils.isBlank(pPartnerNumber)){
				QueryExpression partnerId = builder
						.createPropertyQueryExpression("partnerOrderNumber");
				QueryExpression partnerIdConst = builder
						.createConstantQueryExpression(pPartnerNumber);
				queries.add(builder.createComparisonQuery(partnerId,
						partnerIdConst, QueryBuilder.EQUALS));
			}	
			// LYNX
			if (!StringUtils.isBlank(contractQuoteNumber)){
				QueryExpression quoteId = builder
						.createPropertyQueryExpression("quoteId");
				QueryExpression quoteIdConst = builder
						.createConstantQueryExpression(contractQuoteNumber);
				Query quoteQuery =
						builder.createComparisonQuery(quoteId, quoteIdConst, QueryBuilder.EQUALS);
				
				QueryExpression contractId = builder
						.createPropertyQueryExpression("contractId");
				QueryExpression contractIdConst = builder
						.createConstantQueryExpression(contractQuoteNumber);
				Query contractQuery =
						builder.createComparisonQuery(contractId, contractIdConst, QueryBuilder.EQUALS);
				 Query[] pieces = { quoteQuery, contractQuery };
				    Query andQuery = builder.createOrQuery(pieces);
				
				
				queries.add(andQuery);
			}	
	/*Changes end for the jaguar project*/


			Query startAndendDateQuery = builder
					.createAndQuery((Query[]) queries.toArray(new Query[queries
							.size()]));

			SortDirectives sortDirectives = new SortDirectives();
			sortDirectives.addDirective(new SortDirective("submittedDate",
					SortDirective.DIR_DESCENDING));
			vlogInfo("{0}", startAndendDateQuery);
			result = view.executeQuery(startAndendDateQuery, sortDirectives);
			/* Added changes for AMS-498 and AMS-532 */
            if (result != null && result.length > 0) {
                resultList = Arrays.asList(result);
                vlogDebug("Description List Size is : " +getDescriptionList().size());
                vlogDebug("Description List Items are : " +getDescriptionList().toString());
	  			vlogDebug("Repository Item Count before filtering Dummy Subscription Orders and Large File Orders is : " +resultList.size());
                for (RepositoryItem item : resultList) {
                    if (item != null) {
                        String description = (String) item.getPropertyValue("description");
                        String createdByOrder = (String) item.getPropertyValue("createdByOrderId");
                        if (!((description.equalsIgnoreCase("SUBSCRIPTION_ORDER") && createdByOrder == null) || (getDescriptionList().contains(description)))) {
                        	validList.add(item);                        
                        }
                    }
                }
  	 			vlogDebug("Repository Item Count after filtering Dummy Subscription Orders and Large File Orders is : " +validList.size());
                result = validList.toArray(new RepositoryItem[validList.size()]);  
            }
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}
		return result;
	}


	public OrderManagementVO populateOrderManagementVo(RepositoryItem item,
			boolean isPunchout, RepositoryItem pPunchoutItem, String filterProductLine) {
		OrderManagementVO OrderMgmtVo = new OrderManagementVO();
		try {
			String productLine = "";
			int count = 1;
			List<RepositoryItem> commerceItems = (List<RepositoryItem>) item
					.getPropertyValue("commerceItems");
			for (RepositoryItem commerceItem : commerceItems) {
				String skuId = (String) commerceItem
						.getPropertyValue("catalogRefId");
				Repository repo = (Repository) getRepository().get(
						"PRODUCTCATALOG");
				if (skuId == null)
					break;
				RepositoryItem sku = repo.getItem(skuId, "sku");
				if (sku == null)
					break;
				String productLines = (String) sku
						.getPropertyValue("productLine");
				if (productLines != null
						&& !productLines.isEmpty()
						&& !productLine.toUpperCase().contains(
								productLines.toUpperCase())) {
					productLine += productLines;
					if (count != commerceItems.size()) {
						productLine += (",");
					}

				}
				count++;
			}
			
			if(filterProductLine != null && !filterProductLine.isEmpty()) {
				if(productLine.isEmpty()) {
    		 		OrderMgmtVo.setProductLine(null);
					return OrderMgmtVo;
    		 	}
				boolean plFlag = false;
				filterProductLine = filterProductLine.trim();
				if(productLine.contains(",")){
					String[] plElement = productLine.split(",");
					for (String element : plElement) {
						if(filterProductLine.toUpperCase().contains(element.toUpperCase())) {
							plFlag = true;
						}
					}
				} 
				else {
					if(filterProductLine.toUpperCase().contains(productLine.toUpperCase())) {
						plFlag = true;
					}
				}
				if(!plFlag) {
					OrderMgmtVo.setProductLine(null);
					return OrderMgmtVo;
				} 
			}
			
			if (productLine.length() > 0
					&& productLine.charAt(productLine.length() - 1) == ',')
				productLine = productLine
						.substring(0, productLine.length() - 1);
			 Float amazonAmount=(Float) item.getPropertyValue("orderAmt");

			String profileId = (String) item.getPropertyValue("profileId");
			Repository repo = (Repository) getRepository().get(
					"REGISTRATIONREPORT");
			RepositoryItem profile = null;
			if (!StringUtils.isEmpty(profileId)) {
				profile = repo.getItem(profileId, "user");
			}
			Date lastUpdateTime = null;
			StringBuffer history = new StringBuffer();
			StringBuffer comments = new StringBuffer();
			Integer orderStatus = null;
			List<RepositoryItem> orderHistory = (List<RepositoryItem>) item
					.getPropertyValue("orderHistory");
			if (orderHistory != null && orderHistory.size() > 0) {
				for (RepositoryItem orderHistoryInfo : orderHistory) {
					history.append((String) orderHistoryInfo
							.getPropertyValue("history"));
					history.append(" \n");
					if (orderHistoryInfo.getPropertyValue("comments") != null)
						comments.append((String) orderHistoryInfo
								.getPropertyValue("comments"));
					comments.append(" \n");
					/* added orderStatus for CR AP-2979 */
					orderStatus = (Integer) orderHistoryInfo
							.getPropertyValue("orderStatus");
					lastUpdateTime = (Date) orderHistoryInfo
							.getPropertyValue("updateDateTime");
				}
			}

			StringBuffer totalTimeTaken = new StringBuffer();
			Date submittedDate = (Date) item.getPropertyValue("submittedDate");
			if (lastUpdateTime == null)
				lastUpdateTime = (Date) item
						.getPropertyValue("OrderAcknowledgedTime");

			if (submittedDate != null && lastUpdateTime != null) {
				DateTime dt1 = new DateTime(submittedDate);
				DateTime dt2 = new DateTime(lastUpdateTime);
				int days = Days.daysBetween(dt1, dt2).getDays();
				totalTimeTaken.append(Integer.toString(days)); 
			}
			/*Changes Start for the jaguar project*/	
			String partnerName= (String) item.getPropertyValue("partnerName");
			if(partnerName!=null && item !=null)
			{
				OrderMgmtVo.setPartnerName(partnerName);
			}
			String partnerId= (String) item.getPropertyValue("partnerOrderNumber");
			if(partnerId!=null && item !=null)
			{
				OrderMgmtVo.setPartnerId(partnerId);
			}
	     /*Changes end for the jaguar project*/		
			OrderMgmtVo.setOrder(item);
			OrderMgmtVo.setAmazonAmount(amazonAmount);
			OrderMgmtVo.setProfile(profile);
			OrderMgmtVo.setTotalTimeTaken(totalTimeTaken.toString());
			OrderMgmtVo.setProductLine(productLine);
			OrderMgmtVo.setHistory(history.toString());
			OrderMgmtVo.setComments(comments.toString());
			/* added orderStatus for CR AP-2979 */
			OrderMgmtVo.setOrderStatus(orderStatus);
			OrderMgmtVo.setPunchOut(isPunchout);
			OrderMgmtVo.setPunchoutItem(pPunchoutItem);
			String currencyCode = findCurrency(item);
			OrderMgmtVo.setCurrencyCode(currencyCode);
			OrderMgmtVo.setCurrencylocale(getCurrencyCodeToLocaleMap().get(
					currencyCode));
			OrderMgmtVo.setShipMethod(getShipMethodName(item));
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}
		return OrderMgmtVo;
	}

	public String findCurrency(RepositoryItem item) {
		String currencyCode = "USD";
		try {
			if (item != null) {
				String salesOrg = (String) item.getPropertyValue("salesOrg");
				if (StringUtils.isEmpty(salesOrg)) {
					List<RepositoryItem> shippingGrp = (List<RepositoryItem>) item
							.getPropertyValue("shippingGroups");
					if (shippingGrp != null) {
						String country = (String) shippingGrp.get(0)
								.getPropertyValue("country");
						if (country != null)
							salesOrg = getCountryUtils().getSalesOrgForCountry(
									country);
					}
				}
				currencyCode = getCountryUtils().getSalesOrgCurrencyCodeMap()
						.get(salesOrg);
			}
		} catch (RepositoryException exception) {
			vlogError(exception, "");
		}

		return currencyCode;
	}

	public String getShipMethodName(RepositoryItem item) {
		Repository supportingRepo = getCountryRepository();
		RepositoryView repoView;
		String shipMethodName = "";
		try {
			if (item != null) {
				List<RepositoryItem> shippingGrp = (List<RepositoryItem>) item
						.getPropertyValue("shippingGroups");
				if (shippingGrp != null) {
					String shippingMethod = (String) shippingGrp.get(0)
							.getPropertyValue("shippingMethod");
					if (shippingMethod != null) {
						repoView = getCountryRepository().getView(
								"SiteShipPayOption");
						RqlStatement rqlStatement = RqlStatement
								.parseRqlStatement("optionid  = ?0");
						Object params[] = new Object[1];
						params[0] = shippingMethod;
						RepositoryItem[] items = rqlStatement.executeQuery(
								repoView, params);
						if (items != null && items.length > 0) {
							RepositoryItem ritem = items[0];
							shipMethodName = (String) ritem
									.getPropertyValue("name");

						}
					}
				}
			}

		} catch (RepositoryException e) {
			/*add fix for sonar issue*/ 
			vlogError(e, "RepositoryException Error");
			e.printStackTrace();
		}

		return shipMethodName;
	}

	public List<RepositoryItem> punchoutOrders(Date pStartDate, Date pEndDate,
			String[] salesOrg) {
		RepositoryItem[] punchoutList = null;
		try {
			Repository rep = (Repository) getRepository().get("PUNCHOUT");
			RepositoryView view = rep.getView("punchOut");

			QueryBuilder builder = view.getQueryBuilder();
			QueryExpression starDateExp = builder
					.createPropertyQueryExpression("loginTime");
			QueryExpression startDateValue = builder
					.createConstantQueryExpression(pStartDate);
			Query startDateQuery = builder.createComparisonQuery(starDateExp,
					startDateValue, QueryBuilder.GREATER_THAN_OR_EQUALS);
			QueryExpression endDateValue = builder
					.createConstantQueryExpression(pEndDate);
			Query endDateQuery = builder.createComparisonQuery(starDateExp,
					endDateValue, QueryBuilder.LESS_THAN_OR_EQUALS);

			List<Query> queries = new ArrayList<Query>();
			queries.add(startDateQuery);
			queries.add(endDateQuery);

			if (salesOrg != null && salesOrg.length > 0) {
				List<Query> query = new ArrayList<Query>();
				for (int i = 0; i < salesOrg.length; i++) {
					List<Query> salesQuery = new ArrayList<Query>();
					String[] salesOrgCode = salesOrg[i].split(":");
					QueryExpression salesOrgExp = builder
							.createPropertyQueryExpression("salesOrg");
					QueryExpression salesOrgvalue = builder
							.createConstantQueryExpression(salesOrgCode[0]);
					Query salesOrgQuery = builder.createComparisonQuery(
							salesOrgExp, salesOrgvalue, QueryBuilder.EQUALS);
					/*
					 * salesQuery.add(builder.createComparisonQuery(salesOrgExp,
					 * salesOrgvalue, QueryBuilder.EQUALS));
					 * 
					 * QueryExpression MemTypeOrgExp =
					 * builder.createPropertyQueryExpression
					 * ("basketItem.placedByMemType"); QueryExpression
					 * MemTypevalue =
					 * builder.createConstantQueryExpression(salesOrgCode[1]);
					 * salesQuery
					 * .add(builder.createComparisonQuery(MemTypeOrgExp,
					 * MemTypevalue, QueryBuilder.EQUALS)); Query
					 * salesOrgMemTypeQuery =builder.createAndQuery((Query[])
					 * salesQuery.toArray(new Query[salesQuery.size()]));
					 */
					if (salesOrgQuery != null)
						query.add(salesOrgQuery);
				}

				Query salesOrgQuery = builder.createOrQuery(query
						.toArray(new Query[query.size()]));
				queries.add(salesOrgQuery);
			}

			QueryExpression state = builder
					.createPropertyQueryExpression("basketItem.state");
			QueryExpression stateValue = builder
					.createConstantQueryExpression("PUNCHOUT_SUBMITTED");
			Query stateQuery = builder.createComparisonQuery(state, stateValue,
					QueryBuilder.EQUALS);

			queries.add(stateQuery);

			Query startAndendDateQuery = builder
					.createAndQuery((Query[]) queries.toArray(new Query[queries
							.size()]));

			SortDirectives sortDirectives = new SortDirectives();
			sortDirectives.addDirective(new SortDirective("loginTime",
					SortDirective.DIR_DESCENDING));
			punchoutList = view.executeQuery(startAndendDateQuery,
					sortDirectives);
			if (punchoutList != null && punchoutList.length > 0)
				return Arrays.asList(punchoutList);
		} catch (RepositoryException e) {
			vlogError(e, "repository exception error :{0}", e);
		}
		return Collections.emptyList();
	}

	private HSSFSheet populateOrderXL(ReportType pReportType,
			List<OrderManagementVO> pList, HSSFSheet sheet) {
		int rownum = 1;
		try {
			if (pList != null && pList.size() > 0) {
				for (OrderManagementVO orderVo : pList) {
					HSSFRow newRow = sheet.createRow(rownum);
					newRow.createCell(0).setCellValue(
							orderVo.getOrder().getRepositoryId() == null ? "-"
									: (String) orderVo.getOrder()
											.getRepositoryId());
					newRow.createCell(1).setCellValue(orderVo.getOrder().getPropertyValue("quoteId") == null ? "-" : (String) orderVo.getOrder().getPropertyValue("quoteId"));
					
					newRow.createCell(2).setCellValue(orderVo.getOrder().getPropertyValue("partnerName") == null ? "-" : (String) orderVo.getOrder().getPropertyValue("partnerName"));
					newRow.createCell(3).setCellValue(
							orderVo.getProductLine() == null ? "-" : orderVo
									.getProductLine());
					newRow.createCell(4)
							.setCellValue(
									orderVo.getOrder().getPropertyValue(
											"sapOrderId") == null ? "-"
											: (String) orderVo.getOrder()
													.getPropertyValue(
															"sapOrderId"));
					 newRow.createCell(5).setCellValue(
                   		  orderVo.getOrder().getPropertyValue("partnerOrderNumber") == null ? "-" : (String) orderVo.getOrder().getPropertyValue("partnerOrderNumber"));
					newRow.createCell(6)
							.setCellValue(
									orderVo.getOrder().getPropertyValue(
											"salesOrg") == null ? "-"
											: (String) orderVo.getOrder()
													.getPropertyValue(
															"salesOrg"));
					newRow.createCell(7).setCellValue(
							orderVo.getOrder().getPropertyValue(
									"sapContactNumber") == null ? "-"
									: (String) orderVo.getOrder()
											.getPropertyValue(
													"sapContactNumber"));
					if (orderVo.getOrder().getPropertyValue("shippingGroups") != null)
						newRow.createCell(8)
								.setCellValue(
										((List<RepositoryItem>) orderVo
												.getOrder().getPropertyValue(
														"shippingGroups")).get(
												0).getPropertyValue(
												"shippingMethod") == null ? "-"
												: (String) ((List<RepositoryItem>) orderVo
														.getOrder()
														.getPropertyValue(
																"shippingGroups"))
														.get(0)
														.getPropertyValue(
																"shippingMethod"));
					
					
					if(orderVo.getPartnerName()!=null && orderVo.getPartnerName().equalsIgnoreCase("AMAZON"))
                    {
                  	  newRow.createCell(9).setCellValue(
                      		   (orderVo.getOrder().getPropertyValue("orderAmt") == null ? "-" : ((Float) orderVo.getOrder().getPropertyValue("orderAmt")).toString()));	                          }
                    else if(orderVo.isPunchOut())
                    {
                  	 
                      	  if(orderVo.getPunchoutItem()!=null){
                      		  newRow.createCell(9).setCellValue(
  	                        		  (orderVo.getPunchoutItem().getPropertyValue("total") == null ? "-" : ((Double)  orderVo.getPunchoutItem().getPropertyValue("total")).toString()));
                      	  }
                     }
                  	  
                   else{
                      	  if(orderVo.getOrder().getPropertyValue("priceInfo")!=null)
                      	  {
                      		  newRow.createCell(9).setCellValue(
                      				  ((RepositoryItem)  orderVo.getOrder().getPropertyValue("priceInfo")).getPropertyValue("amount") == null ? "-" : ((Double)  ((RepositoryItem)  orderVo.getOrder().getPropertyValue("priceInfo")).getPropertyValue("amount")).toString());
                      	  }
                       }
                  	  
					
					
					
					/*if(orderVo.getPartnerName().equalsIgnoreCase("AMAZON"))
					{
						newRow.createCell(8).setCellValue(orderVo.getAmazonAmount());
		                   		  
					}
					else
					{

					if (orderVo.isPunchOut()) {
						if (orderVo.getPunchoutItem() != null) {
							newRow.createCell(8)
									.setCellValue(
											(orderVo.getPunchoutItem()
													.getPropertyValue("total") == null ? "-"
													: ((Double) orderVo
															.getPunchoutItem()
															.getPropertyValue(
																	"total"))
															.toString()));
						}
					} else {
						if (orderVo.getOrder().getPropertyValue("priceInfo") != null)
							newRow.createCell(8)
									.setCellValue(
											((RepositoryItem) orderVo
													.getOrder()
													.getPropertyValue(
															"priceInfo"))
													.getPropertyValue("amount") == null ? "-"
													: ((Double) ((RepositoryItem) orderVo
															.getOrder()
															.getPropertyValue(
																	"priceInfo"))
															.getPropertyValue("amount"))
															.toString());
					  }
					}*/
					if (orderVo.getOrder().getPropertyValue("shippingGroups") != null) {
						String country = (String) ((List<RepositoryItem>) orderVo
								.getOrder().getPropertyValue("shippingGroups"))
								.get(0).getPropertyValue("country");
						String salesOrg = getCountryUtils()
								.getSalesOrgForCountry(country);
						String currencyCode = getCountryUtils()
								.getSalesOrgCurrencyCodeMap().get(salesOrg);
						newRow.createCell(10).setCellValue(
								currencyCode == null ? "-" : currencyCode);
					}
					if (orderVo.getProfile() != null) {
						newRow.createCell(11)
								.setCellValue(
										orderVo.getProfile().getPropertyValue(
												"login") == null ? "-"
												: (String) orderVo.getProfile()
														.getPropertyValue(
																"login"));
						newRow.createCell(12).setCellValue(
								orderVo.getProfile().getPropertyValue(
										"firstName") == null ? "-"
										: (String) orderVo.getProfile()
												.getPropertyValue("firstName"));
					}
					newRow.createCell(13)
							.setCellValue(
									orderVo.getOrder().getPropertyValue(
											"placedByMemType") == null ? "-"
											: (String) orderVo.getOrder()
													.getPropertyValue(
															"placedByMemType"));

					if (orderVo.isPunchOut()) {
						if (orderVo.getPunchoutItem() != null)
							newRow.createCell(14).setCellValue(
									orderVo.getPunchoutItem().getPropertyValue(
											"loginTime") == null ? "-"
											: ((Date) orderVo.getPunchoutItem()
													.getPropertyValue(
															"loginTime"))
													.toString());
					} else {
						newRow.createCell(14).setCellValue(
								orderVo.getOrder().getPropertyValue(
										"submittedDate") == null ? "-"
										: ((Date) orderVo.getOrder()
												.getPropertyValue(
														"submittedDate"))
												.toString());
					}
					newRow.createCell(15).setCellValue(
							orderVo.getOrder().getPropertyValue(
									"OrderAcknowledgedTime") == null ? "-"
									: ((Date) orderVo.getOrder()
											.getPropertyValue(
													"OrderAcknowledgedTime"))
											.toString());

					/* added orderTrack for CR AP-2979 */
					if (orderVo.getOrder().getPropertyValue("orderTrack") != null
							&& orderVo.getOrder()
									.getPropertyValue("orderTrack")
									.equals("CANCELLED")) {
						newRow.createCell(16)
								.setCellValue(
										orderVo.getOrder().getPropertyValue(
												"orderTrack") == null ? "-"
												: (String) orderVo.getOrder()
														.getPropertyValue(
																"orderTrack"));
					} else {
						newRow.createCell(16)
								.setCellValue(
										orderVo.getOrder().getPropertyValue(
												"state") == null ? "-"
												: (String) orderVo.getOrder()
														.getPropertyValue(
																"state"));
					}
					newRow.createCell(17).setCellValue(
							orderVo.getTotalTimeTaken());

					newRow.createCell(18).setCellValue(
							orderVo.getHistory() == null ? "-"
									: (String) orderVo.getHistory());
					newRow.createCell(19).setCellValue(
							orderVo.getComments() == null ? "-"
									: (String) orderVo.getComments());
					newRow.createCell(20).setCellValue(
							orderVo.getOrder().getPropertyValue(
									"orderProcessedBy") == null ? "-"
									: (String) orderVo.getOrder()
											.getPropertyValue(
													"orderProcessedBy"));
					// RBE APP APP-6730 START
					newRow.createCell(21).setCellValue(
							orderVo.getOrder().getPropertyValue(
									"soldToName") == null ? "-"
									: (String) orderVo.getOrder()
											.getPropertyValue(
													"soldToName"));
					// RBE APP APP-6730 END
					//DCCOM-4329 Starts
					newRow.createCell(22).setCellValue(
							orderVo.getOrder().getPropertyValue(
									"invoiceType") == null ? "-"
									: (String) orderVo.getOrder()
											.getPropertyValue(
													"invoiceType"));
					//DCCOM-4329 Ends
					//DCCOM-3095 Starts
					if (orderVo.getOrder().getPropertyValue("paymentGroups") != null){
						String PaymentMethod = (String)((List<RepositoryItem>) orderVo.getOrder().getPropertyValue("paymentGroups")).get(0).getPropertyValue("paymentMethod");
						if (PaymentMethod.equalsIgnoreCase("purchaseOrderPaymentGroup"))
						{
							newRow.createCell(23).setCellValue("PurchaseOrder"); }
						else if(PaymentMethod.equalsIgnoreCase("cybersourcePaymentGroup")){
							newRow.createCell(23).setCellValue("CreditCard");
						}else if(PaymentMethod.equalsIgnoreCase("flexibleSpendPlanPaymentGroup")){
							newRow.createCell(23).setCellValue("Flexible Spend Plan");
						}
								
					}
					//DCCOM-3095 Ends
					rownum++;
				}
			} else {
				vlogDebug("No data found");
			}
		} catch (Exception e) {
			vlogError(e, "Request quote report error{0}", e);
		}

		return sheet;
	}
	 /** Changes start for the jaguar project
	  * This method will check whether the order belongs to Amazon and First Time Amazon order
	  * @param pOrderId Order Id
	  * @param condns The boolean array
	  * @return The Boolean Array
	  */
		public Boolean[] isAmazonFirstOrderCheck(String pOrderId,Boolean[] condns){
			vlogDebug("Inside AmazonFirstOrderCheck method", pOrderId,condns);
			boolean isAmazonOrder=Boolean.FALSE;
			boolean isFirstOrder=Boolean.FALSE;
			String partnerName=null;
			
			if(!StringUtils.isEmpty(pOrderId)){
				Repository orderRep = (Repository) getRepository().get("ORDERMANAGMENTREPORT");
		        RepositoryView view;
				try{
					view = orderRep.getView(getViewName().get("ORDERMANAGMENTREPORT"));
					RqlStatement rqlStatement = RqlStatement.parseRqlStatement(getCheckAmazonOrderQuery());
			        Object queryParams[] = new Object[1];
			         queryParams[0] = pOrderId;
			         RepositoryItem[] items = rqlStatement.executeQuery(view, queryParams);
			         if(null != items && items.length>0){
			        	RepositoryItem orderItem=items[0];
			        	
			        	partnerName=(String) orderItem.getPropertyValue("partnerName");
			        	if(!StringUtils.isEmpty(partnerName) && partnerName.equalsIgnoreCase("AMAZON")){
			        		isAmazonOrder=Boolean.TRUE;
			        	}
			        	String profileId=(String) orderItem.getPropertyValue("profileId");
			    		Repository profileRep = (Repository) getRepository().get("REGISTRATIONREPORT");
			            RepositoryView view1;
			    		view1 =  profileRep.getView(getViewName().get("REGISTRATIONREPORT"));
			    				RqlStatement rqlStatement1 = RqlStatement.parseRqlStatement(getCheckAmazonOrderQuery());
			    		        Object queryParams1[] = new Object[1];
			    		         queryParams1[0] = profileId;
			    		         RepositoryItem[] items1 = rqlStatement1.executeQuery(view1, queryParams1);
			    		         if(null != items1 && items1.length>0){
			    		        	RepositoryItem profileItem=items1[0];
			    		        	String eCommStatus=(String) profileItem.getPropertyValue("eCommStatus");
			    		        	if(!StringUtils.isEmpty(eCommStatus) && eCommStatus.equalsIgnoreCase("WEB")){
			    		        	
			    		        			isFirstOrder=Boolean.TRUE;
			    		        	}
			    		         }
			         }
				} catch (RepositoryException e) {
					 vlogError(e, "repository exception error :{0}", e);
				}
		        
			}
				condns[0]=isFirstOrder && isAmazonOrder;
				condns[1]=isAmazonOrder;
		return condns;
		}
	/*Changes end  for the jaguar project*/	
		
	
		  
	    /**
	     * @param pReportType
	     * @param pOrderCount
	     * @param pLastThreeDays
	     * @param pCurrentDate
	     * @return
	     */
	    public List<SubscriptionReportVO> subscriptionListPopulation(ReportType pReportType,
	            int pOrderCount, Date startDate, Date endDate) {
	        try {
            List<SubscriptionReportVO> resultList = new ArrayList<SubscriptionReportVO>();
            Repository rep = (Repository) getRepository().get(pReportType.name());
            RepositoryView view = rep.getView(getViewName().get(pReportType.name()));
            Object params[] = new Object[Constants.PARAM_FOUR];
            params[0] = startDate;
            params[1] = endDate;
            params[2] = Constants.SUBSCRIPTION_STATE;
            params[3] = pOrderCount;
            RepositoryItem[] results = getResultsForOrder(RqlStatement.parseRqlStatement(getFetchRql().get(pReportType.name())), view, params);
            if (results != null && results.length > 0) {

                vlogInfo("No: Of Subscripton orders fetched for last three Days {0}", results.length);

                for (RepositoryItem item : results) {
                    resultList.add(populateSubscriptionManagementVO(item, pReportType));
                }
                return resultList;

            }
        } catch (RepositoryException e) {
            vlogError(e, "repository exception error :{0}", e);
        }

        return Collections.emptyList();

	    }
	    

	    /**
	     * @param pReportType
	     * @param pOrderCount
	     * @param startDate
	     * @param endDate
	     * @param profileName
	     * @param salesOrg
	     * @return
	     */
	    public List<SubscriptionReportVO> subscriptionListBySearchCriteria(ReportType pReportType,
	            int pOrderCount, Date pStartDate, Date pEndDate , String pProfileName , String[] pSalesOrg) {
	        
        Repository rep = (Repository) getRepository().get(pReportType.name());
        RepositoryView view;
        RepositoryItem[] results = null;
        try {
            view = rep.getView(getViewName().get(pReportType.name()));
            List<SubscriptionReportVO> resultList = new ArrayList<SubscriptionReportVO>();
            if (StringUtils.isBlank(pProfileName)) {
                Object params[] = new Object[Constants.PARAM_FOUR];
                params[Constants.PARAM_ZERO] = pStartDate;
                params[Constants.PARAM_ONE] = pEndDate;
                params[Constants.PARAM_TWO] = Constants.SUBSCRIPTION_STATE;
                params[Constants.PARAM_THREE] = pOrderCount;
                results = getResultsForOrder(RqlStatement.parseRqlStatement(getFetchRql().get(pReportType.name())), view, params);
            } else {
                results = getProfileBasedSubscriptions(pStartDate, pEndDate, pProfileName, view);
            }
            if (pSalesOrg != null && pSalesOrg.length > 0 && null != results) {
                results = getSalesOrgBasedSubscriptions(results, rep, pSalesOrg);
            }

            if (results != null && results.length > 0) {
                vlogInfo("No: Of Subscription orders fetched for the given date {0}", results.length);
                for (RepositoryItem item : results) {
                    resultList.add(populateSubscriptionManagementVO(item, pReportType));
                }
                return resultList;

            }
        } catch (RepositoryException e) {
            vlogError("RepositoryException in subscriptionListBySearchCriteria",e);
        }

	        return Collections.emptyList();

	    }
	    
	    /**
         * @param startDate
         * @param endDate
         * @param profileName
         * @param orderRepoView
         * @return
         */
    private RepositoryItem[] getProfileBasedSubscriptions(Date pStartDate, Date pEndDate, String pProfileName, RepositoryView orderRepoView) {
        Query queryStartDate;
        Query queryEndDate;
        Query profileQuery;
        Query queryFinal;
        Query stateQuery;
        Object params[] = new Object[Constants.PARAM_ONE];
        params[Constants.PARAM_ZERO] = pProfileName;
        String profileIdRepo = null;
        RepositoryItem[] result = null;
        Repository profileRep = (Repository) getRepository().get(Constants.PROFILE_REPORT);
        RepositoryView view;

        try {
            view = profileRep.getView(Constants.USER);
            RepositoryItem[] profileItem = getResultsForOrder(RqlStatement.parseRqlStatement(getFetchRql().get(Constants.PROFILE_REPORT)), view, params);
            if (null != profileItem) {
                QueryBuilder queryBuilder = orderRepoView.getQueryBuilder();
                profileIdRepo = (String) profileItem[Constants.PARAM_ZERO].getPropertyValue(Constants.ID);
                if (null != queryBuilder) {
                    QueryExpression startDateProperty = queryBuilder.createPropertyQueryExpression(Constants.START_DATE);
                    QueryExpression startDateConstant = queryBuilder.createConstantQueryExpression(pStartDate);
                    QueryExpression endDateProperty = queryBuilder.createPropertyQueryExpression(Constants.END_DATE);
                    QueryExpression endDateConstant = queryBuilder.createConstantQueryExpression(pEndDate);
                    QueryExpression stateProperty = queryBuilder.createPropertyQueryExpression(Constants.STATE);
                    QueryExpression stateConstant = queryBuilder.createConstantQueryExpression(Constants.SUBSCRIPTION_STATE);
                    stateQuery = queryBuilder.createComparisonQuery(stateProperty, stateConstant, QueryBuilder.EQUALS);
                    queryStartDate = queryBuilder.createComparisonQuery(startDateProperty, startDateConstant, QueryBuilder.GREATER_THAN_OR_EQUALS);
                    queryEndDate = queryBuilder.createComparisonQuery(endDateProperty, endDateConstant, QueryBuilder.LESS_THAN_OR_EQUALS);
                    QueryExpression profileIdExp = queryBuilder.createPropertyQueryExpression(Constants.PROFILE_ID);
                    QueryExpression profileValue = queryBuilder.createConstantQueryExpression(profileIdRepo);
                    profileQuery = queryBuilder.createComparisonQuery(profileIdExp, profileValue, QueryBuilder.EQUALS);
                    queryFinal = queryBuilder.createAndQuery(new Query[]
                        {queryStartDate, queryEndDate, profileQuery, stateQuery});
                    SortDirectives sortDirectives = new SortDirectives();
                    sortDirectives.addDirective(new SortDirective(Constants.CREATE_DATE, Constants.PARAM_ONE));
                    result = orderRepoView.executeQuery(queryFinal, sortDirectives);

                }
            }
        } catch (RepositoryException e) {
            vlogError("RepositoryException in getProfileBasedSubscriptions" + e);
        }
        vlogDebug("Valid Profile Based Subscriptions {0}" + result);
        return result;
    }
        
        
        
        
        /**
         * @param results
         * @param rep
         * @param salesOrg
         * @return
         */
        private RepositoryItem[] getSalesOrgBasedSubscriptions(RepositoryItem[] results,Repository rep,String[] salesOrg){
        RepositoryItem parentOrderItem = null;
        List<RepositoryItem> salesOrgBasedSubscriptions = new ArrayList<RepositoryItem>();
        RepositoryItem[] validSalesOrgBasedSubscriptions = null;
        String salesOrgFromOrder;
        for (RepositoryItem orderItem:results) {
            if (null != orderItem.getPropertyValue(Constants.SUBSCRIPTION_ORDER_ID)) {
                String templateOrderId = (String) orderItem.getPropertyValue(Constants.SUBSCRIPTION_ORDER_ID);
                try {
                    parentOrderItem = rep.getItem(templateOrderId, Constants.ORDER);
                    if (null != parentOrderItem) {
                        salesOrgFromOrder = (String) parentOrderItem.getPropertyValue(Constants.SALES_ORG);
                        for (String salesOrgItem:salesOrg) {
                            String[] salesOrgCode = salesOrgItem.split(Constants.FULL_COLUMN);
                            if (StringUtils.isNotBlank(salesOrgFromOrder) && salesOrgFromOrder.equalsIgnoreCase(salesOrgCode[0])) {
                                salesOrgBasedSubscriptions.add(orderItem);
                                break;
                            }
                        }
                    }
                } catch (RepositoryException e) {
                    vlogError("RepositoryException in getSalesOrgBasedSubscriptions"+ e);
                }
            }
        }
        if (salesOrgBasedSubscriptions.isEmpty()) {
            results = null;
        } else {
            validSalesOrgBasedSubscriptions = new RepositoryItem[salesOrgBasedSubscriptions.size()];
            validSalesOrgBasedSubscriptions = salesOrgBasedSubscriptions.toArray(validSalesOrgBasedSubscriptions);
            results = validSalesOrgBasedSubscriptions;
        }
        
            vlogDebug("Valid SalesOrg Based Subscriptions {0}" +results);
        
        return results;
        }
        
        
        
        
		
		

	    /**
	     * @param item
	     * @param pReportType
	     * @return
	     */
    public SubscriptionReportVO populateSubscriptionManagementVO(RepositoryItem item, ReportType pReportType) {
        SubscriptionReportVO subscriptionVO = new SubscriptionReportVO();
        String profileId = null;
        String nextScheduledDate = null;
        String scheduleStartDate = null;
        String scheduleEndDate = null;
        String subscriptionNumber = null;
        String subscriptionName = null;
        String subscriptionId = null;
        String status = null;
        String subscriptionOrderId = null;
        String cardType = null;
        String purchaseOrderNo =null;
        Repository profileRep = (Repository) getRepository().get(Constants.PROFILE_REPORT);
        RepositoryItem profile = null;
        RepositoryItem orderItem = null;
        String firstName = null;
        String salesOrg = null;
        double priceTotal = 0;
        String currencyCode = Constants.DEFAULT_CURRENCY_CODE;
        CyberSourcePaymentStatusImpl cyberPaymentStatus=null;
        String userFirstName = null;
        String userLastName = null;
        AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        
        DateFormat outputFormatter = new SimpleDateFormat(Constants.DATE_FORMAT,Locale.ENGLISH);
        if (null != item.getPropertyValue(Constants.SUBSCRIPTION_ID)) {
            subscriptionId = (String) item.getPropertyValue(Constants.SUBSCRIPTION_ID);
        }
        if (null != item.getPropertyValue(Constants.SUBSCRIPTION_ORDER_ID)) {
            subscriptionNumber = (String) item.getPropertyValue(Constants.SUBSCRIPTION_ORDER_ID);
        }
        if (null != item.getPropertyValue(Constants.SUBSCRIPTION_NAME)) {
            subscriptionName = (String) item.getPropertyValue(Constants.SUBSCRIPTION_NAME);
        }
        if (null != item.getPropertyValue(Constants.PROFILE_ID)) {
            profileId = (String) item.getPropertyValue(Constants.PROFILE_ID);
        }
        if (null != item.getPropertyValue(Constants.NEXT_SCHEDULED_RUN)) {
            Timestamp nextScheduledRun = (Timestamp) item.getPropertyValue(Constants.NEXT_SCHEDULED_RUN);
            Date date = new Date(nextScheduledRun.getTime());
            nextScheduledDate = outputFormatter.format(date);
        }
        if (null != item.getPropertyValue(Constants.START_DATE)) {
            Timestamp startDate = (Timestamp) item.getPropertyValue(Constants.START_DATE);
            Date date = new Date(startDate.getTime());
            scheduleStartDate = outputFormatter.format(date);
        }
        if (null != item.getPropertyValue(Constants.END_DATE)) {
            Timestamp endDate = (Timestamp) item.getPropertyValue(Constants.END_DATE);
            Date date = new Date(endDate.getTime());
            scheduleEndDate = outputFormatter.format(date);

        }
        if (null != item.getPropertyValue(Constants.STATE)) {
            status = (String) item.getPropertyValue(Constants.STATE);
        }
        if (null != item.getPropertyValue(Constants.TEMPLATE_ORDER_ID)) {
            subscriptionOrderId = (String) item.getPropertyValue(Constants.TEMPLATE_ORDER_ID);
        }
        try {
            if (!StringUtils.isEmpty(profileId)) {
                profile = profileRep.getItem(profileId, Constants.USER);
                if (null != profile) {
                    firstName = (String) profile.getPropertyValue(Constants.LOGIN_NAME);
                    salesOrg = (String) profile.getPropertyValue(Constants.SAP_SALESORG);
                    // Start AMS-53
                    userFirstName = (String)profile.getPropertyValue(propertyManager.getFirstNamePropertyName());
                    userLastName = (String)profile.getPropertyValue(propertyManager.getLastNamePropertyName());
                    // End AMS-53
                }
            }
            if (!StringUtils.isEmpty(subscriptionNumber)) {
                Repository rep = (Repository) getRepository().get(pReportType.name());
                orderItem = rep.getItem(subscriptionNumber, Constants.ORDER);
                if (null != orderItem) {
                    currencyCode = findCurrency(orderItem);
                    if (null != currencyCode) {
                        subscriptionVO.setCurrencyLocale(getCurrencyCodeToLocaleMap().get(currencyCode));
                    }
                    try {
                        AgilentOrder agilentOrder = (AgilentOrder) getOrderManager().loadOrder(subscriptionOrderId);
                        if (null != agilentOrder) {
                            PaymentGroup payGroup = (PaymentGroup) agilentOrder.getPaymentGroups().get(0);
                            if (payGroup instanceof PurchaseOrderPaymentGroup) {
                             PurchaseOrderPaymentGroup poPG = (PurchaseOrderPaymentGroup) payGroup;
                             purchaseOrderNo= poPG.getPurchaseOrderNumber();
                            }
                            else if (payGroup instanceof CyberSourcePaymentGroup){
                                CyberSourcePaymentGroup coCG = (CyberSourcePaymentGroup) payGroup;
                                cyberPaymentStatus = (CyberSourcePaymentStatusImpl) coCG.getAuthorizationStatus().get(0);
                                cardType = cyberPaymentStatus.getCardType();
                            }
                            if (null != agilentOrder.getPriceInfo()) {
                                priceTotal = agilentOrder.getPriceInfo().getTotal();
                            }
                        }
                        vlogDebug("priceTotal--> {0}", priceTotal);
                    } catch (CommerceException e) {
                        vlogError(e, "Error getting while populating Subscription Commerce ListItem");
                    }
                }
            }
        } catch (RepositoryException e) {
            logError(e);
        }

        subscriptionVO.setSubscriptionNumber(subscriptionId);
        subscriptionVO.setSubscriptionId(subscriptionNumber);
        subscriptionVO.setCustomerName(firstName);
        subscriptionVO.setStartDate(scheduleStartDate);
        subscriptionVO.setEndDate(scheduleEndDate);
        subscriptionVO.setNextScheduledRun(nextScheduledDate);
        subscriptionVO.setState(status);
        subscriptionVO.setProfile(profileId);
        subscriptionVO.setSubscriptionName(subscriptionName);
        subscriptionVO.setOrderAmount(priceTotal);
        subscriptionVO.setCurrencyCode(currencyCode);
        subscriptionVO.setPurchaseOrderNo(purchaseOrderNo);
        subscriptionVO.setCardType(cardType);
        subscriptionVO.setSalesOrg(salesOrg);
        subscriptionVO.setFirstName(userFirstName);
        subscriptionVO.setLastName(userLastName);
        return subscriptionVO;
    }
   
    
    /**
     * This method is for creating subscription in dbcpp_sched_order table when Create Subscription button is clicked
     * from OrderStatusTool Page
     * 
     * @param orderId
     * @param mutRep
     * @return
     */
    public boolean createScheduledSubscription(String orderId, MutableRepository mutRep) {
        String profileId = null;
        Calendar cal = new GregorianCalendar();
        cal = AgilentUtil.calendarWithoutTime(cal);
        TransactionDemarcation td = new TransactionDemarcation();
        TransactionManager tm = getTransactionManager();
        boolean shouldRollback = Constants.BOOLEAN_TRUE;
        Timestamp defaultEndDate = AgilentUtil.dateToTimeStamp(getDefaultEndDate());
        try {
            td.begin(tm, TransactionDemarcation.REQUIRED);
            try {
                RepositoryItem orderItem = mutRep.getItem(orderId, Constants.ORDER);
                if (null != orderItem) {
                    profileId = (String) orderItem.getPropertyValue(Constants.PROFILE_ID);
                }
                MutableRepositoryItem subscriptionItem = mutRep.createItem(Constants.SCHEDULED_ORDER);
                subscriptionItem.setPropertyValue(Constants.SUBSCRIPTION_NAME, getDefaultSubscriptionName());
                subscriptionItem.setPropertyValue(Constants.SCHEDULE, getDefaultSchedule());
                subscriptionItem.setPropertyValue(Constants.SUBSCRIPTION_ORDER_ID, orderId);
                subscriptionItem.setPropertyValue(Constants.CREATE_DATE, cal.getTime());
                subscriptionItem.setPropertyValue(Constants.START_DATE, cal.getTime());
                subscriptionItem.setPropertyValue(Constants.END_DATE, defaultEndDate);
                subscriptionItem.setPropertyValue(Constants.NEXT_SCHEDULED_RUN, cal.getTime());
                subscriptionItem.setPropertyValue(Constants.STATE, Constants.ACTIVE);
                subscriptionItem.setPropertyValue(Constants.PROFILE_ID, profileId);
                mutRep.addItem(subscriptionItem);
                shouldRollback = Constants.BOOLEAN_FALSE;

            } catch (RepositoryException e) {
                vlogError("RepositoryException occured while creating Subscription", e);
            } finally {
                td.end(shouldRollback);
            }

        } catch (TransactionDemarcationException tde) {
            vlogError("TransactionDemarcationException ", tde);

        }
        return !shouldRollback;
    }
    
    public AgilentProfileTools getProfileTools() {
		return profileTools;
	}

	public void setProfileTools(AgilentProfileTools profileTools) {
		this.profileTools = profileTools;
	}

}
