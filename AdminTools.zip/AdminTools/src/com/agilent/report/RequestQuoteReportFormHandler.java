
package com.agilent.report;

/**
 * @author amogh.k
 * 
 */

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

import com.agilent.report.ReportsTool.ReportType;

public class RequestQuoteReportFormHandler extends ReportGenarateFormHandler {

    public boolean handleSubmit( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.REQUESTQUOTE);
        return super.handleSubmit(pRequest, pResponse);
    }
    
    public boolean handleExportRequestToolReport(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
	
			Date startDate = getStartDate();
			Date endDate = getEndDate();
			
			vlogDebug("Given from date: {0}", startDate);

			Calendar cal = Calendar.getInstance();
			cal.setTime(endDate);
			cal.add(Calendar.HOUR, 24);
			endDate = cal.getTime();

			vlogDebug("Given to date: {0}", endDate);

			ReportType reporttype = ReportsTool.ReportType.REQUESTQUOTE;
			//4483 ERFQ RBE
			String[] country = getCountry();
			vlogDebug("country: {0}", country);
		  pResponse.getResponse().setHeader("Content-disposition", "attachment;filename=RequestQuoteReportTool.xls");
          pResponse.getResponse().setContentType("application/vnd.ms-excel");
          getReportsTool().exportService(reporttype, startDate, endDate, country, pResponse.getOutputStream());

    return false;
    }
}