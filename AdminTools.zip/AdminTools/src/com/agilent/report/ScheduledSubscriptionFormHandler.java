/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.report;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.base.util.AgilentUtil;
import com.agilent.report.ReportsTool.ReportType;
import com.agilent.report.vo.Constants;

import atg.droplet.DropletException;
import atg.repository.MutableRepository;
import atg.repository.RepositoryItem;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

/**
 * This extended formhandler handles the scheduled subscription onload functionality and
 *  create scheduled subscriptions in admin tools 
 */
@SuppressWarnings("cast")
public class ScheduledSubscriptionFormHandler extends SubscriptionManagementFormHandler {

    private int mInitialLoadDaysGap;
    private boolean mSubscriptionCreated;
    private String mSubscriptionCreateSuccessURL;
    private String mSubscriptionCreateErrorURL;
    private String mSubscriptionErrorMessage;
    private String mResultOrder;
    private List<RepositoryItem> mResultOrderItem;

    /*
     * (non-Javadoc)
     * 
     * @see atg.droplet.EmptyFormHandler#beforeGet(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse) This method is overriden to fetch the scheduled orders for 3 days gap
     * during the initial load of the page
     */
    public void beforeGet(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
        PerformanceMonitor.startOperation("SubscriptionManagementRecord", "LastThreeDaysRecords");
        if (Constants.TRUE.equals(pRequest.getLocalParameter(Constants.CLEAR))) {
            getFormExceptions().removeAllElements();
        } else {
            setSubscriptionCreated(Constants.BOOLEAN_FALSE);
            setCancelledSubscription(Constants.BOOLEAN_FALSE);
            setSubscriptionErrorMessage(null);
        }

        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.SUBSCRIPTIONREPORT);

        try {
            if (!isHasSearched() && (getResultList() == null || getResultList().isEmpty()) && (getResultListVo() == null || getResultListVo().isEmpty())) {
                Calendar cacl = new GregorianCalendar();
                cacl = AgilentUtil.calendarWithoutTime(cacl);
                Date todayDate = cacl.getTime();
                cacl.add(Calendar.DAY_OF_MONTH, getInitialLoadDaysGap());
                Date lastThreeDays = cacl.getTime();
                ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
                setResultListVo(getReportsTool().subscriptionListPopulation(reporttype, getOrderCount(), lastThreeDays, todayDate));
                PerformanceMonitor.endOperation("SubscriptionManagementRecord", "LastThreeDaysRecords");
                if (getResultListVo() == null || getResultListVo().isEmpty()) {
                    addFormException(new DropletException("No data found for last three days"));
                }
                setStartDate(lastThreeDays);
                setEndDate(todayDate);
            }
        } catch (Exception e) {
            vlogError(e, "exception found while access the data Error:{0}", e);
        }
    }

    /**
     * This method will create the subscription out of the existing orders in OM tool
     * 
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleCreateSubscription(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        String orderId = getOrderId();
        MutableRepository mutRep = (MutableRepository) getOrderTools().getOrderRepository();
        if (getReportsTool().createScheduledSubscription(orderId, mutRep)) {
            setSubscriptionCreated(Constants.BOOLEAN_TRUE);

        } else {
            setSubscriptionErrorMessage(Constants.ERROR_MESSAGE);
        }
        String successUrl = getSubscriptionCreateSuccessURL() + orderId + Constants.PARAM_CLEAR + Constants.TRUE;
        String errorUrl = getSubscriptionCreateErrorURL() + orderId;
        return checkFormRedirect(successUrl, errorUrl, pRequest, pResponse);
    }

    /**
     * Gets the value of property initialLoadDaysGap
     *
     * @return the value of property initialLoadDaysGap
     */
    public int getInitialLoadDaysGap() {
        return mInitialLoadDaysGap;
    }
    /**
     * Sets the value of property initialLoadDaysGap with value pInitialLoadDaysGap
     *
     * @param pInitialLoadDaysGap
     *            for setting property initialLoadDaysGap
     */
    public void setInitialLoadDaysGap(int pInitialLoadDaysGap) {
        mInitialLoadDaysGap = pInitialLoadDaysGap;
    }

    /**
     * Gets the value of property subscriptionCreated
     *
     * @return the value of property subscriptionCreated
     */
    public boolean isSubscriptionCreated() {
        return mSubscriptionCreated;
    }
    /**
     * Sets the value of property subscriptionCreated with value pSubscriptionCreated
     *
     * @param pSubscriptionCreated
     *            for setting property subscriptionCreated
     */
    public void setSubscriptionCreated(boolean pSubscriptionCreated) {
        mSubscriptionCreated = pSubscriptionCreated;
    }

    /**
     * Gets the value of property subscriptionCreateSuccessURL
     *
     * @return the value of property subscriptionCreateSuccessURL
     */
    public String getSubscriptionCreateSuccessURL() {
        return mSubscriptionCreateSuccessURL;
    }
    /**
     * Sets the value of property subscriptionCreateSuccessURL with value pSubscriptionCreateSuccessURL
     *
     * @param pSubscriptionCreateSuccessURL
     *            for setting property subscriptionCreateSuccessURL
     */
    public void setSubscriptionCreateSuccessURL(String pSubscriptionCreateSuccessURL) {
        mSubscriptionCreateSuccessURL = pSubscriptionCreateSuccessURL;
    }

    /**
     * Gets the value of property subscriptionCreateErrorURL
     *
     * @return the value of property subscriptionCreateErrorURL
     */
    public String getSubscriptionCreateErrorURL() {
        return mSubscriptionCreateErrorURL;
    }
    /**
     * Sets the value of property subscriptionCreateErrorURL with value pSubscriptionCreateErrorURL
     *
     * @param pSubscriptionCreateErrorURL
     *            for setting property subscriptionCreateErrorURL
     */
    public void setSubscriptionCreateErrorURL(String pSubscriptionCreateErrorURL) {
        mSubscriptionCreateErrorURL = pSubscriptionCreateErrorURL;
    }

    /**
     * Gets the value of property subscriptionErrorMessage
     *
     * @return the value of property subscriptionErrorMessage
     */
    public String getSubscriptionErrorMessage() {
        return mSubscriptionErrorMessage;
    }
    /**
     * Sets the value of property subscriptionErrorMessage with value pSubscriptionErrorMessage
     *
     * @param pSubscriptionErrorMessage
     *            for setting property subscriptionErrorMessage
     */
    public void setSubscriptionErrorMessage(String pSubscriptionErrorMessage) {
        mSubscriptionErrorMessage = pSubscriptionErrorMessage;
    }

    /**
     * Gets the value of property resultOrder
     *
     * @return the value of property resultOrder
     */
    public String getResultOrder() {
        return mResultOrder;
    }
    /**
     * Sets the value of property resultOrder with value pResultOrder
     *
     * @param pResultOrder
     *            for setting property resultOrder
     */
    public void setResultOrder(String pResultOrder) {
        mResultOrder = pResultOrder;
    }

    /**
     * Gets the value of property resultOrderItem
     *
     * @return the value of property resultOrderItem
     */
    public List<RepositoryItem> getResultOrderItem() {
        return mResultOrderItem;
    }
    /**
     * Sets the value of property resultOrderItem with value pResultOrderItem
     *
     * @param pResultOrderItem
     *            for setting property resultOrderItem
     */
    public void setResultOrderItem(List<RepositoryItem> pResultOrderItem) {
        mResultOrderItem = pResultOrderItem;
    }
}
