/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.report;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.base.subscription.AgilentSubscriptionTools;
import com.agilent.report.ReportsTool.ReportType;
import com.agilent.report.vo.Constants;
import com.agilent.report.vo.SubscriptionReportVO;

import atg.commerce.order.OrderTools;
import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

/**
 * This Form Handler handles scheduled subscriptions in admin tools
 */
@SuppressWarnings("cast")
public class SubscriptionManagementFormHandler extends GenericFormHandler {

    protected static final String REPORT_TYPE = "reporttype";

    private int mOrderCount;
    private boolean mCancelledSubscription;
    private boolean mHasSearched = false;
    private Date mStartDate;
    private Date mEndDate;
    private String mComments;
    private String mProfileName;
    private String mOrderId;
    private String mOrderCancel;
    private String mResultOrder;
    private String mSearchUrlRedirect;
    private String mSubscriptionId;
    private String mSubscriptionName;
    private String mScheduledOrderItemDescriptorName;
    private String mSubscriptionCancelSuccessURL;
    private String mSubscriptionCancelErrorURL;
    private String[] mSalesOrg;
    private List<RepositoryItem> mResultList;
    private List<RepositoryItem> mResultOrderItem;
    private List<SubscriptionReportVO> mResultListVo;
    private AgilentSubscriptionTools mSubscriptionTools;
    private OrderTools mOrderTools;
    private ReportsTool mReportsTool;

    /**
     * This method will take the inputs like date and profile name provided in scheduled subscriptions and search will
     * be done based on that
     * 
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleSubscriptionSearch(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.SUBSCRIPTIONREPORT);
        PerformanceMonitor.startOperation(Constants.SubscriptionManagementRecord, "SearchOperation");
        vlogDebug("Given from date: {0}", getEndDate());
        ReportType reporttype = (ReportType) pRequest.getObjectParameter(REPORT_TYPE);
        setResultListVo(getReportsTool().subscriptionListBySearchCriteria(reporttype, getOrderCount(), getStartDate(), getEndDate(), getProfileName(), getSalesOrg()));
        if (getResultListVo() == null || getResultListVo().isEmpty()) {
            addFormException(new DropletException("No data found for the selected search criteria"));
        }
        setHasSearched(true);

        return checkFormRedirect(getSearchUrlRedirect(), getSearchUrlRedirect(), pRequest, pResponse);

    }

    /**
     * This method is for canceling the subscription in Scheduled Subscription View page of OM tool
     * 
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     * @throws RepositoryException
     */
    public boolean handleSubscriptionCancel(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        getFormExceptions().removeAllElements();
        pRequest.setParameter(REPORT_TYPE, ReportsTool.ReportType.SUBSCRIPTIONREPORT);
        PerformanceMonitor.startOperation(Constants.SubscriptionManagementRecord, Constants.CancelOperation);
        String orderId = getOrderId();
        String cancelorder = getOrderCancel();
        vlogDebug("subscriptionId: {0} ", getSubscriptionId());
        vlogDebug("orderId: {0}", orderId);
        if (StringUtils.isNotBlank(getSubscriptionId())) {
            try {
                getSubscriptionTools().subscriptionCancel(getSubscriptionId(), cancelorder);
            } catch (RepositoryException e) {
                vlogError(e, "exception found while access the data Error:{0}", e);
                addFormException(new DropletException("Unable to Cancel the Subscription"));
            }
        }
        setCancelledSubscription(Constants.BOOLEAN_TRUE);
        String successUrl = getSubscriptionCancelSuccessURL() + orderId + Constants.PARAM_NAME + getSubscriptionName() + Constants.PARAM_CLEAR + Constants.TRUE;
        String errorUrl = getSubscriptionCancelErrorURL() + orderId + Constants.PARAM_NAME + getSubscriptionName();
        return checkFormRedirect(successUrl, errorUrl, pRequest, pResponse);
    }

    /**
     * This method will fetch the details of the scheduled subscriptions in detail on click of the order number in
     * Scheduled Subscriptions Page of Order Management tool
     * 
     * @param pRequest
     * @param pResponse
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleParseSubscription(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        ReportType reporttype = ReportsTool.ReportType.ORDERMANAGMENTREPORT;
        setResultOrderItem(getReportsTool().orderTool(reporttype, getResultOrder()));
        return true;
    }

    /**
     * Gets the value of property orderCount
     *
     * @return the value of property orderCount
     */
    public int getOrderCount() {
        return mOrderCount;
    }
    /**
     * Sets the value of property orderCount with value pOrderCount
     *
     * @param pOrderCount
     *            for setting property orderCount
     */
    public void setOrderCount(int pOrderCount) {
        mOrderCount = pOrderCount;
    }

    /**
     * Gets the value of property cancelledSubscription
     *
     * @return the value of property cancelledSubscription
     */
    public boolean isCancelledSubscription() {
        return mCancelledSubscription;
    }
    /**
     * Sets the value of property cancelledSubscription with value pCancelledSubscription
     *
     * @param pCancelledSubscription
     *            for setting property cancelledSubscription
     */
    public void setCancelledSubscription(boolean pCancelledSubscription) {
        mCancelledSubscription = pCancelledSubscription;
    }

    /**
     * Gets the value of property hasSearched
     *
     * @return the value of property hasSearched
     */
    public boolean isHasSearched() {
        return mHasSearched;
    }
    /**
     * Sets the value of property hasSearched with value pHasSearched
     *
     * @param pHasSearched
     *            for setting property hasSearched
     */
    public void setHasSearched(boolean pHasSearched) {
        mHasSearched = pHasSearched;
    }

    /**
     * Gets the value of property startDate
     *
     * @return the value of property startDate
     */
    public Date getStartDate() {
        return mStartDate;
    }
    /**
     * Sets the value of property startDate with value pStartDate
     *
     * @param pStartDate
     *            for setting property startDate
     */
    public void setStartDate(Date pStartDate) {
        mStartDate = pStartDate;
    }

    /**
     * Gets the value of property endDate
     *
     * @return the value of property endDate
     */
    public Date getEndDate() {
        return mEndDate;
    }
    /**
     * Sets the value of property endDate with value pEndDate
     *
     * @param pEndDate
     *            for setting property endDate
     */
    public void setEndDate(Date pEndDate) {
        mEndDate = pEndDate;
    }

    /**
     * Gets the value of property comments
     *
     * @return the value of property comments
     */
    public String getComments() {
        return mComments;
    }
    /**
     * Sets the value of property comments with value pComments
     *
     * @param pComments
     *            for setting property comments
     */
    public void setComments(String pComments) {
        mComments = pComments;
    }

    /**
     * Gets the value of property profileName
     *
     * @return the value of property profileName
     */
    public String getProfileName() {
        return mProfileName;
    }
    /**
     * Sets the value of property profileName with value pProfileName
     *
     * @param pProfileName
     *            for setting property profileName
     */
    public void setProfileName(String pProfileName) {
        mProfileName = pProfileName;
    }

    /**
     * Gets the value of property orderId
     *
     * @return the value of property orderId
     */
    public String getOrderId() {
        return mOrderId;
    }
    /**
     * Sets the value of property orderId with value pOrderId
     *
     * @param pOrderId
     *            for setting property orderId
     */
    public void setOrderId(String pOrderId) {
        mOrderId = pOrderId;
    }

    /**
     * Gets the value of property orderCancel
     *
     * @return the value of property orderCancel
     */
    public String getOrderCancel() {
        return mOrderCancel;
    }
    /**
     * Sets the value of property orderCancel with value pOrderCancel
     *
     * @param pOrderCancel
     *            for setting property orderCancel
     */
    public void setOrderCancel(String pOrderCancel) {
        mOrderCancel = pOrderCancel;
    }

    /**
     * Gets the value of property resultOrder
     *
     * @return the value of property resultOrder
     */
    public String getResultOrder() {
        return mResultOrder;
    }
    /**
     * Sets the value of property resultOrder with value pResultOrder
     *
     * @param pResultOrder
     *            for setting property resultOrder
     */
    public void setResultOrder(String pResultOrder) {
        mResultOrder = pResultOrder;
    }

    /**
     * Gets the value of property searchUrlRedirect
     *
     * @return the value of property searchUrlRedirect
     */
    public String getSearchUrlRedirect() {
        return mSearchUrlRedirect;
    }
    /**
     * Sets the value of property searchUrlRedirect with value pSearchUrlRedirect
     *
     * @param pSearchUrlRedirect
     *            for setting property searchUrlRedirect
     */
    public void setSearchUrlRedirect(String pSearchUrlRedirect) {
        mSearchUrlRedirect = pSearchUrlRedirect;
    }

    /**
     * Gets the value of property subscriptionId
     *
     * @return the value of property subscriptionId
     */
    public String getSubscriptionId() {
        return mSubscriptionId;
    }
    /**
     * Sets the value of property subscriptionId with value pSubscriptionId
     *
     * @param pSubscriptionId
     *            for setting property subscriptionId
     */
    public void setSubscriptionId(String pSubscriptionId) {
        mSubscriptionId = pSubscriptionId;
    }

    /**
     * Gets the value of property subscriptionName
     *
     * @return the value of property subscriptionName
     */
    public String getSubscriptionName() {
        return mSubscriptionName;
    }
    /**
     * Sets the value of property subscriptionName with value pSubscriptionName
     *
     * @param pSubscriptionName
     *            for setting property subscriptionName
     */
    public void setSubscriptionName(String pSubscriptionName) {
        mSubscriptionName = pSubscriptionName;
    }

    /**
     * Gets the value of property scheduledOrderItemDescriptorName
     *
     * @return the value of property scheduledOrderItemDescriptorName
     */
    public String getScheduledOrderItemDescriptorName() {
        return mScheduledOrderItemDescriptorName;
    }
    /**
     * Sets the value of property scheduledOrderItemDescriptorName with value pScheduledOrderItemDescriptorName
     *
     * @param pScheduledOrderItemDescriptorName
     *            for setting property scheduledOrderItemDescriptorName
     */
    public void setScheduledOrderItemDescriptorName(String pScheduledOrderItemDescriptorName) {
        mScheduledOrderItemDescriptorName = pScheduledOrderItemDescriptorName;
    }

    /**
     * Gets the value of property subscriptionCancelSuccessURL
     *
     * @return the value of property subscriptionCancelSuccessURL
     */
    public String getSubscriptionCancelSuccessURL() {
        return mSubscriptionCancelSuccessURL;
    }
    /**
     * Sets the value of property subscriptionCancelSuccessURL with value pSubscriptionCancelSuccessURL
     *
     * @param pSubscriptionCancelSuccessURL
     *            for setting property subscriptionCancelSuccessURL
     */
    public void setSubscriptionCancelSuccessURL(String pSubscriptionCancelSuccessURL) {
        mSubscriptionCancelSuccessURL = pSubscriptionCancelSuccessURL;
    }

    /**
     * Gets the value of property subscriptionCancelErrorURL
     *
     * @return the value of property subscriptionCancelErrorURL
     */
    public String getSubscriptionCancelErrorURL() {
        return mSubscriptionCancelErrorURL;
    }
    /**
     * Sets the value of property subscriptionCancelErrorURL with value pSubscriptionCancelErrorURL
     *
     * @param pSubscriptionCancelErrorURL
     *            for setting property subscriptionCancelErrorURL
     */
    public void setSubscriptionCancelErrorURL(String pSubscriptionCancelErrorURL) {
        mSubscriptionCancelErrorURL = pSubscriptionCancelErrorURL;
    }

    /**
     * Gets the value of property salesOrg
     *
     * @return the value of property salesOrg
     */
    public String[] getSalesOrg() {
        return mSalesOrg;
    }
    /**
     * Sets the value of property salesOrg with value pSalesOrg
     *
     * @param pSalesOrg
     *            for setting property salesOrg
     */
    public void setSalesOrg(String[] pSalesOrg) {
        mSalesOrg = pSalesOrg;
    }

    /**
     * Gets the value of property resultList
     *
     * @return the value of property resultList
     */
    public List<RepositoryItem> getResultList() {
        return mResultList;
    }
    /**
     * Sets the value of property resultList with value pResultList
     *
     * @param pResultList
     *            for setting property resultList
     */
    public void setResultList(List<RepositoryItem> pResultList) {
        mResultList = pResultList;
    }

    /**
     * Gets the value of property resultOrderItem
     *
     * @return the value of property resultOrderItem
     */
    public List<RepositoryItem> getResultOrderItem() {
        return mResultOrderItem;
    }
    /**
     * Sets the value of property resultOrderItem with value pResultOrderItem
     *
     * @param pResultOrderItem
     *            for setting property resultOrderItem
     */
    public void setResultOrderItem(List<RepositoryItem> pResultOrderItem) {
        mResultOrderItem = pResultOrderItem;
    }

    /**
     * Gets the value of property resultListVo
     *
     * @return the value of property resultListVo
     */
    public List<SubscriptionReportVO> getResultListVo() {
        return mResultListVo;
    }
    /**
     * Sets the value of property resultListVo with value pResultListVo
     *
     * @param pResultListVo
     *            for setting property resultListVo
     */
    public void setResultListVo(List<SubscriptionReportVO> pResultListVo) {
        mResultListVo = pResultListVo;
    }

    /**
     * Gets the value of property subscriptionTools
     *
     * @return the value of property subscriptionTools
     */
    public AgilentSubscriptionTools getSubscriptionTools() {
        return mSubscriptionTools;
    }
    /**
     * Sets the value of property subscriptionTools with value pSubscriptionTools
     *
     * @param pSubscriptionTools
     *            for setting property subscriptionTools
     */
    public void setSubscriptionTools(AgilentSubscriptionTools pSubscriptionTools) {
        mSubscriptionTools = pSubscriptionTools;
    }

    /**
     * Gets the value of property orderTools
     *
     * @return the value of property orderTools
     */
    public OrderTools getOrderTools() {
        return mOrderTools;
    }
    /**
     * Sets the value of property orderTools with value pOrderTools
     *
     * @param pOrderTools
     *            for setting property orderTools
     */
    public void setOrderTools(OrderTools pOrderTools) {
        mOrderTools = pOrderTools;
    }

    /**
     * Gets the value of property reportsTool
     *
     * @return the value of property reportsTool
     */
    public ReportsTool getReportsTool() {
        return mReportsTool;
    }
    /**
     * Sets the value of property reportsTool with value pReportsTool
     *
     * @param pReportsTool
     *            for setting property reportsTool
     */
    public void setReportsTool(ReportsTool pReportsTool) {
        mReportsTool = pReportsTool;
    }
}
