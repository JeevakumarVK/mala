/*
package com.agilent.report.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.servlet.ServletException;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import com.agilent.report.ReportsTool;
import com.agilent.report.ReportsTool.ReportType;

public class GenerateReportServlet extends DynamoServlet {

    private String      START_DATE  = "startDate";
    private String      END_DATE    = "endDate";
    private String      REPORT_TYPE = "reporttype";
    private ReportsTool mReportsTool;

    *//**
     * @return the mReportsTool
     *//*
    public ReportsTool getReportsTool() {
        return mReportsTool;
    }

    *//**
     * @param mReportsTool
     *            the mReportsTool to set
     *//*
    public void setReportsTool( ReportsTool pReportsTool) {
        this.mReportsTool = pReportsTool;
    }

    public void service( DynamoHttpServletRequest req, DynamoHttpServletResponse res) throws ServletException, IOException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat dateFormatExcelName = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
        Calendar cal =Calendar.getInstance();
        String filNameDate = dateFormatExcelName.format(cal.getTime());
        
        try {
            Date startDate = dateFormat.parse(req.getParameter(START_DATE));
            vlogDebug("Given Start Date: {0}", startDate);
            
            Date endDate = dateFormat.parse(req.getParameter(END_DATE));
            Calendar calIncrese =Calendar.getInstance();
            calIncrese.setTime(endDate);
            calIncrese.add(Calendar.HOUR, 24);
            endDate=calIncrese.getTime();           
            
            vlogDebug("Given to date: {0}", endDate);
            	           
            
            String report_type = req.getParameter(REPORT_TYPE);
            vlogDebug("Type of the report: {0}", report_type);	
            
            
            ReportType reporttype = ReportType.valueOf(report_type);
            vlogDebug("Getting the report type: {0}", reporttype);
            
            int userType = Integer.parseInt((String) req.getObjectParameter("userType"));
            String sapSalesOrg = req.getParameter("sapSalesOrg");
            int ecommenabled = Integer.parseInt((String) req.getObjectParameter("ecommenabled"));
            res.getResponse().setHeader("Content-disposition", "attachment;filename=" + report_type + filNameDate + ".xls");
            res.getResponse().setContentType("application/vnd.ms-excel");
            getReportsTool().exportProfileService(reporttype, startDate, endDate,ecommenabled, sapSalesOrg, userType, res.getOutputStream());

        } catch (Exception e) {
            vlogError(e, "Error while generating the report{0}",e);

        }
    }

}
*/