/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.report.vo;

/**
 * This is com.agilent.report.vo.Constants public static final interface.
 */
public class Constants {

    public static final String SUBSCRIPTION_ID="id";
    public static final String PROFILE_ID="profileId";
    public static final String SUBSCRIPTION_ORDER_ID="templateOrderId";
    public static final String NEXT_SCHEDULED_RUN="nextScheduledRun";
    public static final String STATE="state";
    public static final String START_DATE="startDate";
    public static final String END_DATE="endDate";
    public static final int SUBSCRIPTION_STATE=0;
    public static final String SUBSCRIPTION_NAME="name"; 
    public static final String PARAM_NAME="&name=";
    public static final String CUSTOMER_NAME="firstName";
    public static final String USER="user";
    public static final String ORDER="order";
    public static final String SUBSCRIPTION_AMOUNT="amount";
    public static final String PRICEINFO="priceInfo";
    public static final String SUBSCRIPTION_SEARCH="SUBSCRIPTIONSEARCH";
    public static final String SALES_ORG="salesOrg";
    public static final String LOGIN_NAME="adLoginName";
    public static final String SUBSCRIPTION_TAX="tax";
    public static final String SUBSCRIPTION_SHIPPING="shipping";
    public static final String PROFILE_REPORT="PROFILEREPORT";
    public static final String DATE_FORMAT="MM/dd/yyyy";
    public static final String DEFAULT_CURRENCY_CODE="USD";
    public static final String CREATE_DATE="createDate";
    public static final String ID="ID";
    public static final String SubscriptionManagementRecord="SubscriptionManagementRecord";
    public static final String CancelOperation="CancelOperation";
    public static final String TRUE="true";
    public static final String CLEAR="clear";
    public static final int PARAM_ZERO=0;
    public static final int PARAM_FOUR=4;
    public static final int PARAM_ONE=1;
    public static final int PARAM_TWO=2;
    public static final int PARAM_THREE=3;
    public static final String FULL_COLUMN=":";
    public static final String SCHEDULED_ORDER="scheduledOrder";
    public static final String SCHEDULE="schedule";
    public static final String ACTIVE="active";
    public static final boolean BOOLEAN_TRUE=true;
    public static final String ERROR_MESSAGE="Error in creating subscription";
    public static final boolean BOOLEAN_FALSE=false;
    public static final String PARAM_CLEAR="&clear=";
    public static final String SAP_SALESORG="sapSalesOrg";
    public static final String TEMPLATE_ORDER_ID="templateOrderId";
    public static final String RTU_CREATED_BY="createdBy";
    public static final String RTU_URL="readyToUseListURL";
    public static final String LSCA_PARTNUMBER = "partNumber";
    public static final String MARKETING_SALES = "marketingsales";
    public static final String HYPHEN = "-";
    public static final String READY_TO_USE_LIST = "readyToUseList";
    public static final String BLANK ="";
}
