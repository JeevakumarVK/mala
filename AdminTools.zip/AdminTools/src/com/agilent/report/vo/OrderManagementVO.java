package com.agilent.report.vo;

import atg.repository.RepositoryItem;

public class OrderManagementVO {
	
	private RepositoryItem order;
	private	RepositoryItem profile;
	private String totalTimeTaken;
	private String productLine;
	private String history;
	private String comments;
	private boolean punchOut=false;
	private RepositoryItem punchoutItem;
	private String currencyCode;
	private String currencylocale;
	private String shipMethod;
	private Integer orderStatus;
    private  Float amazonAmount=0.0f;
	
    public Float getAmazonAmount() {
		return amazonAmount;
	}
    public void setAmazonAmount(Float amazonAmount) {
		this.amazonAmount = amazonAmount;
	}
/*Changes start for the jaguar project*/
	
	private String partnerName;
	private String partnerId;
	
	
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String pPartnerName) {
		partnerName = pPartnerName;
	}
	public String getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(String pPartnerId) {
		partnerId = pPartnerId;
	}
/*Changes end for the jaguar project*/
	/**
	 * @return the orderStatus
	 * Added for ticket AP-2979 Nov RBE
	 */
	public Integer getOrderStatus() {
		return orderStatus;
	}
	/**
	 * @param orderStatus the orderStatus to set
	 */
	public void setOrderStatus(Integer orderStatus) {
		this.orderStatus = orderStatus;
	}
	public RepositoryItem getPunchoutItem() {
		return punchoutItem;
	}
	public void setPunchoutItem(RepositoryItem pPunchoutItem) {
		punchoutItem = pPunchoutItem;
	}
	public boolean isPunchOut() {
		return punchOut;
	}
	public void setPunchOut(boolean pPunchOut) {
		punchOut = pPunchOut;
	}
	public RepositoryItem getOrder() {
		return order;
	}
	public void setOrder(RepositoryItem order) {
		this.order = order;
	}
	public RepositoryItem getProfile() {
		return profile;
	}
	public void setProfile(RepositoryItem profile) {
		this.profile = profile;
	}
	public String getTotalTimeTaken() {
		return totalTimeTaken;
	}
	public void setTotalTimeTaken(String totalTimeTaken) {
		this.totalTimeTaken = totalTimeTaken;
	}
	public String getProductLine() {
		return productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}
	public String getHistory() {
		return history;
	}
	public void setHistory(String history) {
		this.history = history;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	public String getCurrencylocale() {
		return currencylocale;
	}
	public void setCurrencylocale(String currencylocale) {
		this.currencylocale = currencylocale;
	}
	public String getShipMethod() {
		return shipMethod;
	}
	public void setShipMethod(String shipMethod) {
		this.shipMethod = shipMethod;
	}
}
