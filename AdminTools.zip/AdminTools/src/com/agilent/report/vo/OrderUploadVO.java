package com.agilent.report.vo;

public class OrderUploadVO {
private String orderId;
private String email;
private String language;
private String salesOrg;
private String mCustName;

/**
 * @return the custName
 */
public String getCustName() {
	return mCustName;
}
/**
 * @param pCustName the custName to set
 */
public void setCustName(String pCustName) {
	mCustName = pCustName;
}
/**
 * @return the salesOrg
 */
public String getSalesOrg() {
	return salesOrg;
}
/**
 * @param pSalesOrg the salesOrg to set
 */
public void setSalesOrg(String pSalesOrg) {
	salesOrg = pSalesOrg;
}
/**
 * @return the orderId
 */
public String getOrderId() {
	return orderId;
}
/**
 * @param pOrderId the orderId to set
 */
public void setOrderId(String pOrderId) {
	orderId = pOrderId;
}
/**
 * @return the email
 */
public String getEmail() {
	return email;
}
/**
 * @param pEmail the email to set
 */
public void setEmail(String pEmail) {
	email = pEmail;
}
/**
 * @return the language
 */
public String getLanguage() {
	return language;
}
/**
 * @param pLanguage the language to set
 */
public void setLanguage(String pLanguage) {
	language = pLanguage;
}
}
