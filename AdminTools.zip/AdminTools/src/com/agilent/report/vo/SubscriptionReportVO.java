package com.agilent.report.vo;




public class SubscriptionReportVO {
	
	private String subscriptionId;
	private String state;
	private String profile;
	private String startDate;
	private String endDate;
	private String nextScheduledRun;
	private String subscriptionName;
	private String customerName;
	private double orderAmount;
	private String currencyCode;
	private String currencyLocale;
	private String subscriptionNumber;
	private String purchaseOrderNo;
    private String cardType;
    private String salesOrg;
    // Start AMS-53
    private String firstName;
    private String lastName;
    // End AMS-53
    
    /**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
    /**
     * @return the salesOrg
     */
    public String getSalesOrg() {
        return salesOrg;
    }
    /**
     * @param salesOrg the salesOrg to set
     */
    public void setSalesOrg(String salesOrg) {
        this.salesOrg = salesOrg;
    }
    /**
     * @return the purchaseOrderNo
     */
    public String getPurchaseOrderNo() {
        return purchaseOrderNo;
    }
    /**
     * @param purchaseOrderNo the purchaseOrderNo to set
     */
    public void setPurchaseOrderNo(String purchaseOrderNo) {
        this.purchaseOrderNo = purchaseOrderNo;
    }
    /**
     * @return the cardType
     */
    public String getCardType() {
        return cardType;
    }
    /**
     * @param cardType the cardType to set
     */
    public void setCardType(String cardType) {
        this.cardType = cardType;
    }
    public String getSubscriptionNumber() {
        return subscriptionNumber;
    }
    public void setSubscriptionNumber(String subscriptionNumber) {
        this.subscriptionNumber = subscriptionNumber;
    }
    /**
     * Gets the value of property startDate
     *
     * @return the value of property startDate
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * Sets the value of property startDate with value startDate
     *
     * @param startDate
     *            for setting property startDate
     */
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }
    /**
     * Gets the value of property endDate
     *
     * @return the value of property endDate
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * Sets the value of property endDate with value endDate
     *
     * @param endDate
     *            for setting property endDate
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }
    /**
     * Gets the value of property nextScheduledRun
     *
     * @return the value of property nextScheduledRun
     */
    public String getNextScheduledRun() {
        return nextScheduledRun;
    }
    /**
     * Sets the value of property nextScheduledRun with value nextScheduledRun
     *
     * @param nextScheduledRun
     *            for setting property nextScheduledRun
     */
    public void setNextScheduledRun(String nextScheduledRun) {
        this.nextScheduledRun = nextScheduledRun;
    }
    /**
     * Gets the value of property currencyLocale
     *
     * @return the value of property currencyLocale
     */
    public String getCurrencyLocale() {
        return currencyLocale;
    }
    /**
     * Sets the value of property currencyLocale with value currencyLocale
     *
     * @param currencyLocale
     *            for setting property currencyLocale
     */
    public void setCurrencyLocale(String currencyLocale) {
        this.currencyLocale = currencyLocale;
    }
    /**
     * Gets the value of property currencyCode
     *
     * @return the value of property currencyCode
     */
    public String getCurrencyCode() {
        return currencyCode;
    }
    /**
     * Sets the value of property currencyCode with value currencyCode
     *
     * @param currencyCode
     *            for setting property currencyCode
     */
    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }
    /**
     * Gets the value of property orderAmount
     *
     * @return the value of property orderAmount
     */
    public double getOrderAmount() {
        return orderAmount;
    }
    /**
     * Sets the value of property orderAmount with value orderAmount
     *
     * @param orderAmount
     *            for setting property orderAmount
     */
    public void setOrderAmount(double orderAmount) {
        this.orderAmount = orderAmount;
    }
    /**
     * Gets the value of property customerName
     *
     * @return the value of property customerName
     */
    public String getCustomerName() {
        return customerName;
    }
    /**
     * Sets the value of property customerName with value customerName
     *
     * @param customerName
     *            for setting property customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    /**
     * Gets the value of property subscriptionName
     *
     * @return the value of property subscriptionName
     */
    public String getSubscriptionName() {
        return subscriptionName;
    }
    /**
     * Sets the value of property subscriptionName with value subscriptionName
     *
     * @param subscriptionName
     *            for setting property subscriptionName
     */
    public void setSubscriptionName(String subscriptionName) {
        this.subscriptionName = subscriptionName;
    }
    /**
     * Gets the value of property subscriptionId
     *
     * @return the value of property subscriptionId
     */
    public String getSubscriptionId() {
        return subscriptionId;
    }
    /**
     * Sets the value of property subscriptionId with value subscriptionId
     *
     * @param subscriptionId
     *            for setting property subscriptionId
     */
    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }
    /**
     * Gets the value of property state
     *
     * @return the value of property state
     */
    public String getState() {
        return state;
    }
    /**
     * Sets the value of property state with value state
     *
     * @param state
     *            for setting property state
     */
    public void setState(String state) {
        this.state = state;
    }
    /**
     * Gets the value of property profile
     *
     * @return the value of property profile
     */
    public String getProfile() {
        return profile;
    }
    /**
     * Sets the value of property profile with value profile
     *
     * @param profile
     *            for setting property profile
     */
    public void setProfile(String profile) {
        this.profile = profile;
    }
  
}
