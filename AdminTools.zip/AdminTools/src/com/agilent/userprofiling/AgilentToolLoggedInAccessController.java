package com.agilent.userprofiling;

import atg.servlet.DynamoHttpServletRequest;
import atg.userprofiling.Profile;
import atg.userprofiling.RuleAccessController;

public class AgilentToolLoggedInAccessController extends RuleAccessController{
	private String mStoreLogin=null;
	private String deniedURl=null;
	

	@Override
	public boolean allowAccess(Profile pProfile, DynamoHttpServletRequest pRequest) {
		boolean allowAccess = super.allowAccess(pProfile, pRequest);
		if(!allowAccess&&pProfile.isTransient()){
		setDeniedAccessURL(getStoreLogin()+"?ReturnURL="+pRequest.getRequestURI()+"?"+(pRequest.getQueryString()==null?"":pRequest.getQueryString()));
		}
		return allowAccess;
	}


	public String getStoreLogin() {
		return mStoreLogin;
	}


	public void setStoreLogin(String pStoreLogin) {
		mStoreLogin = pStoreLogin;
	}
}
