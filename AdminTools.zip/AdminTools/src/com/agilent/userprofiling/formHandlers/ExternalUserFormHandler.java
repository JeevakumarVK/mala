package com.agilent.userprofiling.formHandlers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.platform.errorhandler.IErrorHandler;
import com.agilent.base.platform.validator.IValidator;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.rest.okta.IntegrateOktaConnectionManager;
import com.agilent.base.rest.okta.vo.OktaProfile;
import com.agilent.base.rest.okta.vo.OktaUser;
import com.agilent.base.util.AgilentUtil;
//import com.agilent.profile.okta.rest.services.bean.OKTAUserOutputBean;
import com.agilent.userprofiling.helper.ChangeHistoryVO;
import com.agilent.userprofiling.helper.ExternalUserHelper;
import com.agilent.userprofiling.helper.ExternalUserVO;

import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.userprofiling.Profile;
import atg.userprofiling.email.MessageContentProcessor;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;



public class ExternalUserFormHandler extends GenericFormHandler {
	
	private List<ExternalUserVO> 	  resultListVo;
	private ExternalUserHelper externalUserHelper;
	private String searchProperty;
	private String searchText;
	private String searchBooleanProperty;
	private boolean searchBooleanValue;
	private int itemCount;
	private String searchSuccessURL;
	private String searchErrorURL;
	private List<String> searchPropertyList;
	private AgilentProfileTools profileTools;
	private Profile profile=null;
	private String saveUserSuccessURL;
	private String saveUserErrorURL;
	
	//User properties
	private String userId;
	private String login;
	private String Email;
	private String adLoginName;
	private String eCommStatus;
	private String SAPContactNumber;
	private String sapSalesOrg;
	private String MemberType;
	private String userCountry;
	private boolean sapMasterAccount;
	private String punchoutMember;
	private boolean includePunchoutShipping;
	private boolean includePunchoutTaxes;
	private String FEDEXUPSCollectNumber;
	private String UPSCollectNumber;
	private String defaultShippingMethod;
	private String defaultPaymentMethod;
	private boolean taxExempted;
	private String taxExempteNumber;
	private String taxExemptCertificatePath;
	private boolean placeOnlineOrders;
	private boolean accessLibrayOptIn;
	private boolean newsOptIn;
	private String downloadOptIn;
	private boolean scheduleOnlineHWServiceRequestOptIn;
	private String emailFormat;
	private boolean isMossDownWhenRegister;
	private String defaultSAPShipToAddress;
	private String defaultSAPBillToAddress;
	private String shippAddType;
	private Date passChngReqDate;
	private boolean testAccount;
	private String previousPass;
	private boolean directorAccount;
	private boolean dropShipment;
	private boolean showDutyFreePrice;
	private String payerInvoiceEmail;
	private boolean isAddFileUploaded;
	private boolean advShpDisable;
	private List<ChangeHistoryVO> changeHistory;
	private String userStatus;
	private int 	  defaultItemCount;
	
	//Email components
	private boolean sendMail=false;
	private String emailTo;
	private String emailCC;
	private String emailBCC;
	private String emailFrom;
	private String emailTemplateURL;
	private TemplateEmailSender emailSender;
    private MessageContentProcessor contentProcessor;
    private String emailSubject;
    private String locale;
    private AgilentConfiguration configuration;
    private String bccEmail;
	private IValidator validator;
	private IErrorHandler errorHandler;
	//Jaguar changes- start
	private String partnerName;
	private String partnerIdentifier;
	//Jaguar changes- end

	
	
	private String firstName;
	private String lastName;
	private String region;
	private Boolean sapDirectorAccount;
	private String b2bGroupId;
	private String telephoneNumber;
	private String invShipCustomerName;
	private String invAddress;
	private String invBankAccount;
	private String invBankName;
	private String invCity;
	private String invContactPerson;
	private String invCustomerName;
	private String invPhoneNumber;
	private String invPostalCode;
	private String invShipAddress;
	private String invTaxCode;
	private Boolean b2bUser;
	private String department;
	private String title;
	private String crmContactId;
    private String secondaryEccId;
    private String multipleSoldTo;
    private IntegrateOktaConnectionManager integrateOktaConnManager;
    private static final String OKTA_PROFILE_STATUS = "oktaProfileStatus";
    private static final String DEACTIVE="DEACTIVE";
    private static final String ACTIVE="ACTIVE";
    private static final String INTERMEDIATE="INTERMEDIATE";
    private static final String DEPROVISIONED="DEPROVISIONED";
    private static final String ACTIVATE_SUCESS_PARAM="&activated=true";
    private static final String DEACTIVATE_SUCESS_PARAM="&deactivated=true";
    private static final String DEACTIVATED="Deactivated";
    private static final String ACTIVATED="Activated";
    private String mStatusUpdateSuccessURL;
    private String mStatusUpdateErrorURL;
    private boolean userAvailableInOkta;
    private boolean actionDriven;

	public void beforeGet( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
		String userId=(String)pRequest.getLocalParameter("customerId");
    	List<ExternalUserVO> userVO;
    	OktaUser lOktaUser = null;
    	RepositoryItem profileItem = null;
    	MutableRepositoryItem oktaProfileItem = null;
    	setUserAvailableInOkta(Boolean.TRUE);
    	  try {
    	if(!getFormError() && !StringUtils.isBlank(userId)){
    		 vlogInfo("beforeGet method is called with user ID {0}:: ", userId);
    		 profileItem = getExternalUserHelper().findUserItem(userId);
    		 oktaProfileItem = getProfileTools().getProfileRepository().getItemForUpdate(userId, "user");
			 if(null == profileItem || null == oktaProfileItem) {
				 setUserAvailableInOkta(Boolean.FALSE);
				 addFormException(new DropletException("No record found in Down stream System"));
			 }else {
				 String email = (String) profileItem.getPropertyValue("email");
				 if(StringUtils.isNotBlank(email)) {
					 lOktaUser = getIntegrateOktaConnManager().findUserDetailsUsingEmail(email);
					 if(null == lOktaUser) {
						 setUserAvailableInOkta(Boolean.FALSE);
						 addFormException(new DropletException("No record found in Upstream System"));
					 }else {
						 userVO= getExternalUserHelper().searchUserByCustomerId("ID", userId, getItemCount(),lOktaUser);
						 if(null == userVO || userVO.isEmpty()){
							 addFormException(new DropletException("No record found with given user ID"));
			    		 }else{
			    			 copyVOproperty(userVO.get(0),oktaProfileItem);
			    		 }
					 } 
				 }else {
					 addFormException(new DropletException("Email is blank for this user"));
				 }
			 }
		 }
    	  }  catch (RepositoryException repoException) {
				vlogError(repoException, "RepositoryException occured ");
			} catch (Exception e) {
              vlogError("Error occured while updating  the user profile from ATG");
          }
         try {
        	 String initializeVar = pRequest.getParameter("initialize");
        	 if(StringUtils.isNotBlank(initializeVar)&& initializeVar.equalsIgnoreCase("true")){
        		 if(!getFormError()){
        			 String pageName = "searchPage";
        			 resultListVo= getExternalUserHelper().listRecentUsers(getDefaultItemCount(),pageName);
        	     }
        		 if(null == resultListVo || resultListVo.isEmpty()){
        			 addFormException(new DropletException("No records found"));
        		 }
        	 }
        	 }catch (Exception e) {
             vlogError(e, "exception found while access the data Error:{0}", e);
         }
        

    }
	
	 public boolean handleSearchUser( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		 
		 if((getSearchProperty()==null || StringUtils.isBlank(getSearchText())) && getSearchBooleanProperty() ==null){
			 addFormException(new DropletException("Invalid Search Parameters"));
			 
			 return checkFormRedirect(getSearchSuccessURL(),getSearchErrorURL(), pRequest, pResponse);
		 }
		 if(!getFormError()){
			 resultListVo= getExternalUserHelper().searchUser(getSearchProperty(), getSearchText(), getItemCount());
		 }
		 if(null == resultListVo || resultListVo.isEmpty()){
			 addFormException(new DropletException("No records found with given search criteria"));
		 }
		 
		 return checkFormRedirect(getSearchSuccessURL(),getSearchErrorURL(), pRequest, pResponse);
	 }
	
	/**
	* This method validates the admin form fields
	* @param pRequest
	* @param pResponse
	* @throws ServletException
	* @throws IOException
	*/
	protected void preSaveUser( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException { 
		vlogDebug("Entering the method: {0} in class: {1}","preSaveUser",getClass().toString());
		 AgilentPropertyManager propManager = (AgilentPropertyManager) getProfile().getProfileTools().getPropertyManager();
		if (StringUtils.isNotEmpty(getEmail()) && !getEmail().equalsIgnoreCase("null")) {
            if (!AgilentUtil.isValidEmail(getEmail())) {
                addFormException(new DropletException("Invalid email address"));
            }
        }
        if (StringUtils.isNotEmpty(getPayerInvoiceEmail()) && !getPayerInvoiceEmail().equalsIgnoreCase("null")) {
            if (!AgilentUtil.isValidEmail(getPayerInvoiceEmail())) {
                addFormException(new DropletException("Invalid Payer Invoice email address"));
            }
        }
        if (StringUtils.isNotEmpty(getUserId()) && !getUserId().equalsIgnoreCase("null") && geteCommStatus().equals("SAP")) {
            RepositoryItem userItem = getExternalUserHelper().findUserItem(getUserId());
            if(null == userItem) {
            	addFormException(new DropletException("User Not found in the Down Stream system"));
            }else {
            	String eCommStatusFromDB = (String) userItem.getPropertyValue(propManager.getEcomStatusPropertyName());
            	String sapContactNo = StringUtils.isBlank(getSAPContactNumber()) ? "Nill" : getSAPContactNumber();
            	String crmContactNo = StringUtils.isBlank(getCrmContactId()) ? "Nill" : getCrmContactId();
            	if(!eCommStatusFromDB.equals(geteCommStatus())) {
    				if("Nill".equals(sapContactNo)) {
    					addFormException(new DropletException("ECC Contact Id is Blank"));
    				}
    				if("Nill".equals(crmContactNo)) {
    					addFormException(new DropletException("CRM Contact Id is Blank"));
    				}
    			}
            }
        }
        vlogDebug("Exiting from the method: {0} in class: {1}","preSaveUser",getClass().toString());
	 }
	/**
	 * This method is used for updating an user under user management tools 
	 * @param pRequest
	 * @param pResponse
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
    public boolean handleSaveUser(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
    	vlogDebug(":: Entering the method: {0} in class: {1}","handleSaveUser",getClass().toString());
    	boolean isProfileUpdatedInOkta = false;
        boolean isProfileUpdatedInATG = false;
        String businessUserEmail = null;
        Map<String, Object> propMap = null;
    	try {
    		preSaveUser(pRequest, pResponse);
    		if(getFormError()) {
        		return checkFormRedirect(getSaveUserSuccessURL(), getSaveUserErrorURL(), pRequest, pResponse);
        	}
        	isProfileUpdatedInOkta = isProfileUpdateInOktaSystem(getEmail());
            if (null != getUserId() && isProfileUpdatedInOkta) {
            	propMap = new HashMap<String, Object>();
                propMap = prepareForUpdate();
                if (null != getProfile()) {
                	businessUserEmail = (String) getProfile().getPropertyValue("email");
                }
                isProfileUpdatedInATG =  getExternalUserHelper().updateExternalUser(propMap, getUserId(), businessUserEmail, null);
                List<ExternalUserVO> userList = getExternalUserHelper().findUser(getUserId());
                if (null != userList && !userList.isEmpty()) {
                    setChangeHistory(userList.get(0).getChangeHistory());
                }
            }
            vlogInfo("isProfileUpdatedInOkta--> {0} ::::: isProfileUpdatedInATG ---> {1}",isProfileUpdatedInOkta,isProfileUpdatedInATG);
            if(!isProfileUpdatedInOkta){
            	vlogDebug("Exception occured Profile not updated in Destination system");
                addFormException(new DropletException("Exception Occurred at Destination System"));
                return checkFormRedirect(getSaveUserSuccessURL(), getSaveUserErrorURL(), pRequest, pResponse);
            }
            if(!isProfileUpdatedInATG) {
            	vlogDebug("Exception occured Profile not updated in Source system");
            	addFormException(new DropletException("Exception Occurred at Source System"));
                return checkFormRedirect(getSaveUserSuccessURL(), getSaveUserErrorURL(), pRequest, pResponse);
            }
            if (!getFormError()) {
                postSaveUser(pRequest, pResponse);
            }
    	} catch (Exception e) {
    		addFormException(new DropletException("Exception occured"));
    		vlogError(e, "Exception occured");
            return checkFormRedirect(getSaveUserSuccessURL(), getSaveUserErrorURL(), pRequest, pResponse);
	    }
        vlogDebug("Exisiting from the method: {0} in class: {1}","handleSaveUser",getClass().toString());
        return checkFormRedirect(getSaveUserSuccessURL(), getSaveUserErrorURL(), pRequest, pResponse);
    }
	 
	/**
	 * This method validates the profile Update status in OKTA System
	 * @param pEmail
	 * @return
	 */
    private boolean isProfileUpdateInOktaSystem(String pEmail) {
    	 vlogDebug("Entering the method: {0} in class: {1}","handleSaveUser",getClass().toString());
		 boolean isSuccess = false;
		 OktaProfile oktaProfile =  prepareProfileDataForOkta();
		 OktaUser lOktaUser = getIntegrateOktaConnManager().findUserDetailsUsingEmail(pEmail);
		 boolean isChanged = getExternalUserHelper().isDataChanged(oktaProfile, pEmail,lOktaUser);
		 vlogInfo("ExternalUserFormHandler.isProfileUpdateInOktaSystem ::: isChanged-->{0}", isChanged);
		 if(isChanged) {
			 isSuccess = getIntegrateOktaConnManager().updateProfileDataInvokeInOkta(oktaProfile, pEmail);
		 }else {
			 isSuccess = true;
		 }
		 vlogInfo("ExternalUserFormHandler.isProfileUpdateInOktaSystem ::: isSuccess-->{0}",isSuccess);
		 vlogDebug("Exisiting from the method: {0} in class: {1}","handleSaveUser",getClass().toString());
		 return isSuccess;
	}

	/**
      * To set profile details from ATG Admin to OKTA variable
      * 
      * @param profileDetails
      * @return profileDetails
      */
    private OktaProfile prepareProfileDataForOkta() {
        vlogDebug("setProfileDetails initiated");
        
        OktaProfile profileDetails = new OktaProfile();
        
        if (StringUtils.isEmpty(geteCommStatus()) || null == geteCommStatus()) {
        	profileDetails.setUSR_UDF_ECOMMERCESTATUS(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_ECOMMERCESTATUS(geteCommStatus());
        }
        
        if (StringUtils.isEmpty(getSAPContactNumber()) || null == getSAPContactNumber()) {
        	profileDetails.setUSR_UDF_SAPCUSTOMERID(Constants.BLANK);
        }else {
        	 profileDetails.setUSR_UDF_SAPCUSTOMERID(getSAPContactNumber());
        }
        
        if (StringUtils.isEmpty(getSapSalesOrg()) || null == getSapSalesOrg()) {
        	profileDetails.setUSR_UDF_SAPSALESORG(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_SAPSALESORG(getSapSalesOrg());
        }
        
        if (StringUtils.isEmpty(getMemberType()) || null == getMemberType()) {
        	profileDetails.setUSR_UDF_MEMBERTYPE(Constants.BLANK); 
        }else {
        	profileDetails.setUSR_UDF_MEMBERTYPE(getMemberType());
        }
        
        if (StringUtils.isEmpty(getUserCountry()) || null == getUserCountry()) {
        	profileDetails.setUSR_COUNTRY(Constants.BLANK);
        }else {
        	profileDetails.setUSR_COUNTRY(getUserCountry());
        }
        
        if (StringUtils.isEmpty(getPayerInvoiceEmail()) || null == getPayerInvoiceEmail()) {
        	profileDetails.setUSR_UDF_PAYERINVOICEEMAIL(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_PAYERINVOICEEMAIL(getPayerInvoiceEmail());
        }
        
        if (StringUtils.isEmpty(getFirstName()) || null == getFirstName()) {
        	profileDetails.setFirstName(Constants.BLANK);
        }else {
        	profileDetails.setFirstName(getFirstName());
        }
        
        
        if (StringUtils.isEmpty(getLastName()) || null == getLastName()) {
        	profileDetails.setLastName(Constants.BLANK);
        }else {
        	profileDetails.setLastName(getLastName());
        }
        
        if (StringUtils.isEmpty(getInvShipCustomerName()) || null == getInvShipCustomerName()) {
        	profileDetails.setUSR_UDF_CUSTOMERNAME(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_CUSTOMERNAME(getInvShipCustomerName());
        }
        
        if (StringUtils.isEmpty(getInvAddress()) || null == getInvAddress()) {
        	profileDetails.setUSR_UDF_INVOICEADDRESS(Constants.BLANK); 
        }else {
        	profileDetails.setUSR_UDF_INVOICEADDRESS(getInvAddress());
        	
        }
        if (StringUtils.isEmpty(getInvBankAccount()) || null == getInvBankAccount()) {
        	 profileDetails.setUSR_UDF_INVOICEBANKACCOUNT(Constants.BLANK);
        }else {
        	 profileDetails.setUSR_UDF_INVOICEBANKACCOUNT(getInvBankAccount());
        }
        
        if (StringUtils.isEmpty(getInvBankName()) || null == getInvBankName()) {
        	profileDetails.setUSR_UDF_INVOICEBANKNAME(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICEBANKNAME(getInvBankName());
        }
        
        if (StringUtils.isEmpty(getInvCity()) || null == getInvCity()) {
        	profileDetails.setUSR_UDF_INVOICECITY(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICECITY(getInvCity());
        }
        
        if (StringUtils.isEmpty(getInvContactPerson()) || null == getInvContactPerson()) {
        	profileDetails.setUSR_UDF_INVOICECONTACTPERSON(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICECONTACTPERSON(getInvContactPerson());
        }
        
        if (StringUtils.isEmpty(getInvCustomerName()) || null == getInvCustomerName()) {
        	profileDetails.setUSR_UDF_INVOICECUSTOMERNAME(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICECUSTOMERNAME(getInvCustomerName());
        }
        
        if (StringUtils.isEmpty(getInvPhoneNumber()) || null == getInvPhoneNumber()) {
        	profileDetails.setUSR_UDF_INVOICEPHONENUMBER(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICEPHONENUMBER(getInvPhoneNumber());
        }
        
        if (StringUtils.isEmpty(getInvPostalCode()) || null == getInvPostalCode()) {
        	 profileDetails.setUSR_UDF_INVOICEPOSTCODE(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICEPOSTCODE(getInvPostalCode());
        }
        
        if (StringUtils.isEmpty(getInvShipAddress()) || null == getInvShipAddress()) {
        	profileDetails.setUSR_UDF_INVOICESHIPADDRESS(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICESHIPADDRESS(getInvShipAddress());
        }
        
        if (StringUtils.isEmpty(getInvTaxCode()) || null == getInvTaxCode()) {
        	profileDetails.setUSR_UDF_INVOICETAXCODE(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_INVOICETAXCODE(getInvTaxCode());
        }
        
        if (StringUtils.isEmpty(getDepartment()) || null == getDepartment()) {
        	profileDetails.setUSR_DEPT_NO(Constants.BLANK);
        }else {
        	profileDetails.setUSR_DEPT_NO(getDepartment());
        }
        
        if (StringUtils.isEmpty(getTitle()) || null == getTitle()) {
            profileDetails.setTitle(getTitle());
        }else {
        	profileDetails.setTitle(Constants.BLANK);
        }
        
        if (StringUtils.isEmpty(getCrmContactId()) || null == getCrmContactId()) {
        	profileDetails.setUSR_UDF_CRMCONTACTNUMBER(Constants.BLANK);
        }else {
        	profileDetails.setUSR_UDF_CRMCONTACTNUMBER(getCrmContactId());
        }
        
        profileDetails.setUSR_UDF_PLACEONLINEORDERS(isPlaceOnlineOrders());
        profileDetails.setUSR_UDF_SAPMASTERACCOUNT(isSapMasterAccount());
        profileDetails.setUSR_UDF_TESTACCOUNT(isTestAccount());
        String secEccId = getSecondaryEccId();
        if(StringUtils.isNotBlank(secEccId)) {
        	profileDetails.setSecondaryECCContact_ID(Arrays.asList(secEccId.split(",")));
        }else {
        	profileDetails.setSecondaryECCContact_ID(Arrays.asList(Constants.BLANK));
        }
        String mulSoldId = getMultipleSoldTo();
        if(StringUtils.isNotBlank(mulSoldId)) {
        	profileDetails.setMultipleSoldTo(Arrays.asList(mulSoldId.split(",")));
        }else {
        	profileDetails.setMultipleSoldTo(Arrays.asList(Constants.BLANK));
        }
        return profileDetails;
    }
	 
	 
	 protected void postSaveUser(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
		        throws ServletException, IOException{
		 
			vlogDebug("**Start postUpdateItem**");
			boolean isSendEmail =isSendMail();
			if (isSendEmail){
				String TO,CC,BCC;
				TO =  getEmailTo();
				CC = getEmailCC();
				BCC = getEmailBCC();
				String Subject =getEmailSubject();
				String sapContactNum=getSAPContactNumber();
				
				if(Subject==null){
					Subject="Your Profile Updated"; 
				}
				 
				if(StringUtils.isBlank(TO)){
					TO =getEmail();
				}
				if(!StringUtils.isEmpty(TO)&&!TO.equals("null") ){ 
					if(!AgilentUtil.isValidEmail(TO)){
						addFormException(new DropletException("Invalid To email address")); 
					}
				}
				if(!StringUtils.isEmpty(BCC)&&!BCC.equals("null") ){ 
					if(!AgilentUtil.isValidEmail(BCC)){
						addFormException(new DropletException("Invalid bcc email address")); 
					}
				}
				
				if(!StringUtils.isEmpty(CC)&&!CC.equals("null")){ 
					if(!AgilentUtil.isValidEmail(CC)){
						addFormException(new DropletException("Invalid cc email address"));   
					}		
				}
				
				if(StringUtils.isEmpty(Subject)){
						addFormException(new DropletException("Subject field cannot be empty"));   
				}
				if(StringUtils.isEmpty(geteCommStatus()) || geteCommStatus().equals("WEB")){ 
					addFormException(new DropletException("eCommerce Status is WEB"));
				}
				if(StringUtils.isEmpty(sapContactNum) || "null".equals(sapContactNum)){ 
					addFormException(new DropletException("ECC Contact Id is Blank"));
				}
				if(StringUtils.isEmpty(getCrmContactId()) || "null".equals(getCrmContactId())){ 
					addFormException(new DropletException("CRM Contact Id is Blank"));
				}
				
			if(!getFormError() && getConfiguration().isSendEcomEnableMail()){
				if (!StringUtils.isEmpty(BCC)){
					BCC=BCC+","+getBccEmail();
				}
				else{
					BCC=getBccEmail();
				}
				sendEmail(TO,CC,BCC,Subject,getAdLoginName()); 
								 
			}
				
			}
			vlogDebug("**End postUpdateItem**");
			
	 }
	
	 
	 public Map<String, Object> prepareForUpdate(){
		 Map <String,Object> propMap= new HashMap<String,Object>();
		 AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		propMap.put(propertyManager.getLoginPropertyName(), getLogin());
		propMap.put(propertyManager.getEmailAddressPropertyName(), getEmail());
		propMap.put(propertyManager.getAdLoginNamePropertyName(), getAdLoginName());
		propMap.put(propertyManager.getEcomStatusPropertyName(), geteCommStatus());
		propMap.put(propertyManager.getSapContactNumberPropertyName(), getSAPContactNumber());
		propMap.put(propertyManager.getSapSalesOrgPropertyName(), getSapSalesOrg());
		propMap.put(propertyManager.getMemberTypePropertyName(), getMemberType());
		propMap.put(propertyManager.getUserCountryPropertyName(), getUserCountry());
		propMap.put(propertyManager.getSapMasterAccountPropertyName(), isSapMasterAccount());
		propMap.put(propertyManager.getPunchoutMemberPropertyName(), getPunchoutMember());
		propMap.put(propertyManager.getIncludePunchoutShippingPropertyName(), isIncludePunchoutShipping());
		propMap.put(propertyManager.getIncludePunchoutTaxesPropertyName(), isIncludePunchoutTaxes());
		propMap.put(propertyManager.getFedexUpsCollectNumber(),getFEDEXUPSCollectNumber());
		propMap.put("UPSCollectNumber", getUPSCollectNumber());
		propMap.put(propertyManager.getDefaultShippingMethodPropertyName(), getDefaultShippingMethod());
		propMap.put(propertyManager.getDefaultPaymentMethodPropertyName(), getDefaultPaymentMethod());
		propMap.put(propertyManager.getTaxExemptedPropertyName(), isTaxExempted());
		propMap.put(propertyManager.getTaxExemptedNumPropertyName(), getTaxExempteNumber());
		propMap.put(propertyManager.getTaxExemptCertPropertyName(), getTaxExemptCertificatePath());
		propMap.put(propertyManager.getPlaceOnlineOrdersPropertyName(), isPlaceOnlineOrders());
		propMap.put(propertyManager.getAccessLibrayOptInPropertyName(), isAccessLibrayOptIn());
		propMap.put(propertyManager.getNewsOptInPropertyName(), isNewsOptIn());
		propMap.put(propertyManager.getDownloadOptInPropertyName(), getDownloadOptIn());
		propMap.put(propertyManager.getScheduleOptInPropertyName(), isScheduleOnlineHWServiceRequestOptIn());
		propMap.put(propertyManager.getEmailFormatPropertyName(), getEmailFormat());
		propMap.put(propertyManager.getMossDownWhenRegisterPropertyName(),isMossDownWhenRegister());
		propMap.put(propertyManager.getDefaultSAPShipToAddressPropertyName(), getDefaultSAPShipToAddress());
		propMap.put(propertyManager.getDefaultSAPBillToAddressPropertyName(), getDefaultSAPBillToAddress());
		propMap.put(propertyManager.getShippAddTypeProppertyName(), getShippAddType());
		//propMap.put(propertyManager.getPassChngReqDatePropertyName(), getPassChngReqDate());
		propMap.put(propertyManager.getTestAccountPropertyName(), isTestAccount());
		propMap.put(propertyManager.getPreviousPassPropertyName(), getPreviousPass());
		propMap.put("directorAccount", isDirectorAccount());
		propMap.put(propertyManager.getDropShipmentPropertyName(), isDropShipment());
		propMap.put("showDutyFreePrice", isShowDutyFreePrice());
		propMap.put("payerInvoiceEmail", getPayerInvoiceEmail());
		propMap.put("isAddFileUploaded", isAddFileUploaded());
		propMap.put("advShpDisable", isAdvShpDisable());
		//Jaguar changes- start
		propMap.put(propertyManager.getPartnerNamePropertyName(), getPartnerName());
		propMap.put(propertyManager.getPartnerIdentifierrPropertyName(), getPartnerIdentifier());
		//Jaguar changes- end		
		
		
		propMap.put(propertyManager.getFirstNamePropertyName(), getFirstName());
		propMap.put(propertyManager.getLastNamePropertyName(), getLastName());
		propMap.put(propertyManager.getRegion(), getRegion());
		propMap.put(propertyManager.getSapDirectorAccountPropertyName(), getSapDirectorAccount());
		propMap.put("GroupId", getB2bGroupId());
		//propMap.put(propertyManager.getPartnerNamePropertyName(), getTelephoneNumber());
		propMap.put("customerName1", getInvShipCustomerName());
		propMap.put("address1", getInvAddress());
		propMap.put("bankAccount1", getInvBankAccount());
		propMap.put("bankName1", getInvBankName());
		propMap.put("city2", getInvCity());
		propMap.put("contactorName2", getInvContactPerson());
		propMap.put("customerName2", getInvCustomerName());
		propMap.put("contactorPhNum2", getInvPhoneNumber());
		propMap.put("postCode2", getInvPostalCode());
		propMap.put("shippingAdrress2", getInvShipAddress());
		propMap.put("companyTaxCode1", getInvTaxCode());
		propMap.put("b2bUser", getB2bUser());
		propMap.put("department", getDepartment());
		propMap.put("title", getTitle());
		propMap.put("crmContactId", getCrmContactId());
        propMap.put("secondaryEccId", getSecondaryEccId());
        propMap.put("multipleSoldTo", getMultipleSoldTo());
		
		 return propMap;
	 }
	 
	 public void copyVOproperty(ExternalUserVO user,MutableRepositoryItem pOktaProfileItem){
		 if(null !=user){
				
			 setUserId(user.getUserId());
			 setLogin(user.getLoginName());
			 setEmail(user.getEmail());
			 setAdLoginName(user.getAdLoginName());
			 seteCommStatus(user.geteCommStatus());
			 setSAPContactNumber(user.getSAPContactNumber());
			 setSapSalesOrg(user.getSapSalesOrg());
			 setMemberType(user.getMemberType());
			 setUserCountry(user.getUserCountry());
			 setSapMasterAccount(user.isSapMasterAcount());
			 setPunchoutMember(user.getPunchoutMember());
			 setIncludePunchoutShipping(user.isIncludePunchoutShipping());
			 setIncludePunchoutTaxes(user.isIncludePunchoutTaxes());
			 setFEDEXUPSCollectNumber(user.getFEDEXUPSCollectNumber());
			 setUPSCollectNumber(user.getUPSCollectNumber());
			 setDefaultShippingMethod(user.getDefaultShippingMethod());
			 setDefaultPaymentMethod(user.getDefaultPaymentMethod());
			 setTaxExempted(user.isTaxExempted());
			 setTaxExempteNumber(user.getTaxExempteNumber());
			 setTaxExemptCertificatePath(user.getTaxExemptCertificatePath());
			 setPlaceOnlineOrders(user.isPlaceOnlineOrders());
			 setAccessLibrayOptIn(user.isAccessLibrayOptIn());
			 setNewsOptIn(user.isNewsOptIn());
			 setDownloadOptIn(user.getDownloadOptIn());
			 setScheduleOnlineHWServiceRequestOptIn(user.getScheduleOnlineHWServiceRequestOptIn());
			 setEmailFormat(user.getEmailFormat());
			 setMossDownWhenRegister(user.isMossDownWhenRegister());
			 setDefaultSAPShipToAddress(user.getDefaultSAPShipToAddress());
			 setDefaultSAPBillToAddress(user.getDefaultSAPBillToAddress());
			 setShippAddType(user.getShippAddType());
			 setPassChngReqDate(null);
			 setTestAccount(user.isTestAccount());
			 setPreviousPass(user.getPreviousPass());
			 setDirectorAccount(user.isDirectorAccount());
			 setDropShipment(user.isDropShipment());
			 setShowDutyFreePrice(user.isShowDutyFreePrice());
			 setPayerInvoiceEmail(user.getPayerInvoiceEmail());
			 setAddFileUploaded(user.isAddFileUploaded());
			 setAdvShpDisable(user.isAdvShpDisable());
			 setChangeHistory(user.getChangeHistory());
			 setUserStatus(user.getUserStatus());
				if (user.getUserStatus().equalsIgnoreCase(ACTIVE)) {
					pOktaProfileItem.setPropertyValue("oktaProfileStatus", ACTIVE);
					vlogInfo(":::: ExternalUserFormHandler.copyVOproperty ::: Status value updated as ACTIVE for ATG ID --->  {0} ::::",pOktaProfileItem.getRepositoryId());
				} else if (user.getUserStatus().equalsIgnoreCase(DEPROVISIONED)) {
					pOktaProfileItem.setPropertyValue("oktaProfileStatus", DEACTIVE);
					vlogInfo(":::: ExternalUserFormHandler.copyVOproperty ::: Status value updated as DEACTIVE for ATG ID --->  {0} ::::",pOktaProfileItem.getRepositoryId());
				} else {
					pOktaProfileItem.setPropertyValue("oktaProfileStatus", INTERMEDIATE);
					vlogInfo(":::: ExternalUserFormHandler.copyVOproperty ::: Status value  updated as INTERMEDIATE for  ATG ID ---> {0} ::::",pOktaProfileItem.getRepositoryId());
				}
				try {
					getProfileTools().getProfileRepository().updateItem(pOktaProfileItem);
				} catch (RepositoryException repoException) {
					vlogError(repoException, "RepositoryException while updating the profile item");
				} catch (Exception e) {
					vlogError("Error occured while updating  the user profile from ATG");
				}
			 setPartnerName(user.getPartnerName());
			 setPartnerIdentifier(user.getPartnerIdentifier());
			 setFirstName(user.getFirstName());
			 setLastName(user.getLastName());
			 setRegion(user.getRegion());
			 setSapDirectorAccount(user.getSapDirectorAccount());
			 setB2bGroupId(user.getB2bGroupId());
			 setInvShipCustomerName(user.getInvShipCustomerName());
			 setInvAddress(user.getInvAddress());
			 setInvBankAccount(user.getInvBankAccount());
			 setInvBankName(user.getInvBankName());
		     setInvCity(user.getInvCity());
			 setInvContactPerson(user.getInvContactPerson());
			 setInvCustomerName(user.getInvCustomerName());
			 setInvPhoneNumber(user.getInvPhoneNumber());
			 setInvPostalCode(user.getInvPostalCode());
			 setInvShipAddress(user.getInvShipAddress());
			 setInvTaxCode(user.getInvTaxCode());
			 setB2bUser(user.getB2bUser());
			 setDepartment(user.getDepartment());
			 setTitle(user.getTitle());
             setCrmContactId(user.getCrmContactId());
             StringBuilder builder = new StringBuilder();
             if (null != user.getSecondaryEccId()) {
                for (String secECCId :  user.getSecondaryEccId()) {
                	builder = builder.append(secECCId);
                	builder.append(",");
                }
                String secId = builder.toString();
                if (!StringUtils.isEmpty(secId)) {
                	secId = secId.substring(0, secId.length() - 1);
                    setSecondaryEccId(secId);
                }
            }
            StringBuilder soldtoBuild = new StringBuilder();
            if (null != user.getMultipleSoldTo()) {
                for (String mulId :  user.getMultipleSoldTo()) {
                	soldtoBuild = soldtoBuild.append(mulId);
                	soldtoBuild.append(",");
                }
                String mId = soldtoBuild.toString();
                if (!StringUtils.isEmpty(mId)) {
                	mId = mId.substring(0, mId.length() - 1);
                    setMultipleSoldTo(mId);
                }
            }
		 }
	 }
	 
	 /**
	  * To send mail to given recipient after profile update
	  * 
	  * @param pTO
	  * @param pCC
	  * @param pBCC
	  * @param pSubject
	  * @param adLoginName - adLoginName of User
	  */
	 private void sendEmail(String pTO, String pCC, String pBCC, String pSubject, String adLoginName) {
		 
			vlogInfo("**Start sendEmail**\n TO:{0} \n CC:{1} \n BCC:{2}",pTO,pCC,pBCC);
			TemplateEmailInfoImpl emailInfo = new TemplateEmailInfoImpl();
	    	HashMap<String,Object> params = new HashMap<String,Object>();
	    	params.put("loginName", adLoginName);
	    	params.put("requestLocale", getLocale());
	    	emailInfo.setContentProcessor(getContentProcessor());
			emailInfo.setMessageSubject(pSubject);
			emailInfo.setMessageFrom(getEmailFrom());
			emailInfo.setMessageTo(pTO);
			emailInfo.setMessageCc(pCC);
			emailInfo.setMessageBcc(pBCC);
			emailInfo.setTemplateURL(getEmailTemplateURL());
			emailInfo.setTemplateParameters(params);
			List<String> recipents = new ArrayList<String>();
			recipents.add(pTO);
			try {
				vlogDebug("**Sending Email**");
				getEmailSender().sendEmailMessage(emailInfo, recipents) ;
			} catch (TemplateEmailException e) {
				vlogError(e, "exception found while sending Email Error:{0}", e);
			} 
			vlogDebug("**END sendEmail**");
		}
	 
	 
	 
     /**
        * This method is used for deactivating the user in OKTA using user management in Admin Tools 
        * @param pRequest
        * @param pResponse
        * @return
        * @throws ServletException
        * @throws IOException
        */
   public boolean handleDeActivateUser(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
       vlogDebug(":: Entering the method: {0} in class: {1}", "handleDeActivateUser", getClass().toString());
       boolean deActivatedUser = false;
       deActivatedUser = updateUserStatusInOkta(getEmail(), ACTIVE);
       if (deActivatedUser) {
    	   getExternalUserHelper().saveAuditChangesForOKTAStatus(getUserId(), DEACTIVATED);
       } else {
           addFormException(new DropletException("User Deactivation not successful in OKTA.Please contact support team"));
       }
       setActionDriven(Boolean.TRUE);
       vlogDebug("Exisiting from the method: {0} in class: {1}", "handleDeActivateUser", getClass().toString());
       return checkFormRedirect(getStatusUpdateSuccessURL()+ DEACTIVATE_SUCESS_PARAM, getStatusUpdateErrorURL(), pRequest, pResponse);
   }
    
   
   /**
    * This method is used for activating the user in OKTA using user management in Admin Tools 
    * @param pRequest
    * @param pResponse
    * @return
    * @throws ServletException
    * @throws IOException
    */
public boolean handleActivateUser(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
   vlogDebug(":: Entering the method: {0} in class: {1}", "handleActivateUser", getClass().toString());
   boolean activateUser = false;
   activateUser = updateUserStatusInOkta(getEmail(), DEACTIVE);
   if (activateUser) {
	   getExternalUserHelper().saveAuditChangesForOKTAStatus(getUserId(), ACTIVATED);
   } else {
       addFormException(new DropletException("User Activation not successful in OKTA.Please contact support team"));
   }
   setActionDriven(Boolean.TRUE);
   vlogDebug("Exisiting from the method: {0} in class: {1}", "handleActivateUser", getClass().toString());
   return checkFormRedirect(getStatusUpdateSuccessURL()+ ACTIVATE_SUCESS_PARAM, getStatusUpdateErrorURL(), pRequest, pResponse);
}


/**
 * This method validates the profile's activate/deactivate Update status in OKTA System
 * 
 * @param pEmail
 * @return
 */
private boolean updateUserStatusInOkta(String pEmail, String status) {
    vlogDebug("Entering the method: {0} in class: {1}", "updateUserStatusInOkta", getClass().toString());
    boolean updateStatus = false;
    if (StringUtils.isNotBlank(status) && status.equalsIgnoreCase(ACTIVE)) {
        updateStatus = getIntegrateOktaConnManager().deActivateUserInOkta(pEmail);
    }
    else if (StringUtils.isNotBlank(status) && status.equalsIgnoreCase(DEACTIVE)) {
        updateStatus = getIntegrateOktaConnManager().activateUserInOkta(pEmail);
    }
    if (!updateStatus && status.equalsIgnoreCase(ACTIVE)) {
        vlogError("ExternalUserFormHandler.updateUserStatusInOkta ::: deActivated-->{0}", updateStatus);
    } else if (!updateStatus && status.equalsIgnoreCase("DEACTIVE")) {
        vlogError("ExternalUserFormHandler.updateUserStatusInOkta ::: Activated-->{0}", updateStatus);
    }
    vlogDebug("Exisiting from the method: {0} in class: {1}", "updateUserStatusInOkta", getClass().toString());
    return updateStatus;
}
	 
	public String getSearchProperty() {
		return searchProperty;
	}

	public void setSearchProperty(String searchProperty) {
		this.searchProperty = searchProperty;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public String getSearchBooleanProperty() {
		return searchBooleanProperty;
	}


	public void setSearchBooleanProperty(String searchBooleanProperty) {
		this.searchBooleanProperty = searchBooleanProperty;
	}


	public boolean isSearchBooleanValue() {
		return searchBooleanValue;
	}


	public void setSearchBooleanValue(boolean searchBooleanValue) {
		this.searchBooleanValue = searchBooleanValue;
	}


	public List<ExternalUserVO> getResultListVo() {
		return resultListVo;
	}

	public void setResultListVo(List<ExternalUserVO> resultListVo) {
		this.resultListVo = resultListVo;
	}

	public ExternalUserHelper getExternalUserHelper() {
		return externalUserHelper;
	}

	public void setExternalUserHelper(ExternalUserHelper externalUserHelper) {
		this.externalUserHelper = externalUserHelper;
	}

	public int getItemCount() {
		return itemCount;
	}

	public void setItemCount(int itemCount) {
		this.itemCount = itemCount;
	}

	public String getSearchSuccessURL() {
		return searchSuccessURL;
	}

	public void setSearchSuccessURL(String searchSuccessURL) {
		this.searchSuccessURL = searchSuccessURL;
	}

	public String getSearchErrorURL() {
		return searchErrorURL;
	}

	public void setSearchErrorURL(String searchErrorURL) {
		this.searchErrorURL = searchErrorURL;
	}

	public List<String> getSearchPropertyList() {
		return searchPropertyList;
	}

	public void setSearchPropertyList(List<String> searchPropertyList) {
		this.searchPropertyList = searchPropertyList;
	}

	public AgilentProfileTools getProfileTools() {
		return profileTools;
	}

	public void setProfileTools(AgilentProfileTools profileTools) {
		this.profileTools = profileTools;
	}
	
	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public String getSaveUserSuccessURL() {
		return saveUserSuccessURL;
	}

	public void setSaveUserSuccessURL(String saveUserSuccessURL) {
		this.saveUserSuccessURL = saveUserSuccessURL;
	}

	public String getSaveUserErrorURL() {
		return saveUserErrorURL;
	}


	public void setSaveUserErrorURL(String saveUserErrorURL) {
		this.saveUserErrorURL = saveUserErrorURL;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getAdLoginName() {
		return adLoginName;
	}

	public void setAdLoginName(String adLoginName) {
		this.adLoginName = adLoginName;
	}

	public String geteCommStatus() {
		return eCommStatus;
	}

	public void seteCommStatus(String eCommStatus) {
		this.eCommStatus = eCommStatus;
	}

	public String getSAPContactNumber() {
		return SAPContactNumber;
	}

	public void setSAPContactNumber(String sAPContactNumber) {
		SAPContactNumber = sAPContactNumber;
	}

	public String getSapSalesOrg() {
		return sapSalesOrg;
	}

	public void setSapSalesOrg(String sapSalesOrg) {
		this.sapSalesOrg = sapSalesOrg;
	}

	public String getMemberType() {
		return MemberType;
	}

	public void setMemberType(String memberType) {
		MemberType = memberType;
	}

	public String getUserCountry() {
		return userCountry;
	}

	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}

	public boolean isSapMasterAccount() {
		return sapMasterAccount;
	}

	public void setSapMasterAccount(boolean sapMasterAccount) {
		this.sapMasterAccount = sapMasterAccount;
	}

	public String getPunchoutMember() {
		return punchoutMember;
	}

	public void setPunchoutMember(String punchoutMember) {
		this.punchoutMember = punchoutMember;
	}

	public boolean isIncludePunchoutShipping() {
		return includePunchoutShipping;
	}

	public void setIncludePunchoutShipping(boolean includePunchoutShipping) {
		this.includePunchoutShipping = includePunchoutShipping;
	}

	public boolean isIncludePunchoutTaxes() {
		return includePunchoutTaxes;
	}

	public void setIncludePunchoutTaxes(boolean includePunchoutTaxes) {
		this.includePunchoutTaxes = includePunchoutTaxes;
	}

	public String getFEDEXUPSCollectNumber() {
		return FEDEXUPSCollectNumber;
	}

	public void setFEDEXUPSCollectNumber(String fEDEXUPSCollectNumber) {
		FEDEXUPSCollectNumber = fEDEXUPSCollectNumber;
	}

	public String getUPSCollectNumber() {
		return UPSCollectNumber;
	}

	public void setUPSCollectNumber(String uPSCollectNumber) {
		UPSCollectNumber = uPSCollectNumber;
	}

	public String getDefaultShippingMethod() {
		return defaultShippingMethod;
	}

	public void setDefaultShippingMethod(String defaultShippingMethod) {
		this.defaultShippingMethod = defaultShippingMethod;
	}

	public String getDefaultPaymentMethod() {
		return defaultPaymentMethod;
	}

	public void setDefaultPaymentMethod(String defaultPaymentMethod) {
		this.defaultPaymentMethod = defaultPaymentMethod;
	}

	public boolean isTaxExempted() {
		return taxExempted;
	}

	public void setTaxExempted(boolean taxExempted) {
		this.taxExempted = taxExempted;
	}

	public String getTaxExempteNumber() {
		return taxExempteNumber;
	}

	public void setTaxExempteNumber(String taxExempteNumber) {
		this.taxExempteNumber = taxExempteNumber;
	}

	public String getTaxExemptCertificatePath() {
		return taxExemptCertificatePath;
	}

	public void setTaxExemptCertificatePath(String taxExemptCertificatePath) {
		this.taxExemptCertificatePath = taxExemptCertificatePath;
	}

	public boolean isPlaceOnlineOrders() {
		return placeOnlineOrders;
	}

	public void setPlaceOnlineOrders(boolean placeOnlineOrders) {
		this.placeOnlineOrders = placeOnlineOrders;
	}

	public boolean isAccessLibrayOptIn() {
		return accessLibrayOptIn;
	}

	public void setAccessLibrayOptIn(boolean accessLibrayOptIn) {
		this.accessLibrayOptIn = accessLibrayOptIn;
	}

	public boolean isNewsOptIn() {
		return newsOptIn;
	}

	public void setNewsOptIn(boolean newsOptIn) {
		this.newsOptIn = newsOptIn;
	}

	public String getDownloadOptIn() {
		return downloadOptIn;
	}

	public void setDownloadOptIn(String downloadOptIn) {
		this.downloadOptIn = downloadOptIn;
	}

	public boolean isScheduleOnlineHWServiceRequestOptIn() {
		return scheduleOnlineHWServiceRequestOptIn;
	}

	public void setScheduleOnlineHWServiceRequestOptIn(
			boolean scheduleOnlineHWServiceRequestOptIn) {
		this.scheduleOnlineHWServiceRequestOptIn = scheduleOnlineHWServiceRequestOptIn;
	}

	public String getEmailFormat() {
		return emailFormat;
	}

	public void setEmailFormat(String emailFormat) {
		this.emailFormat = emailFormat;
	}

	public boolean isMossDownWhenRegister() {
		return isMossDownWhenRegister;
	}

	public void setMossDownWhenRegister(boolean isMossDownWhenRegister) {
		this.isMossDownWhenRegister = isMossDownWhenRegister;
	}

	public String getDefaultSAPShipToAddress() {
		return defaultSAPShipToAddress;
	}

	public void setDefaultSAPShipToAddress(String defaultSAPShipToAddress) {
		this.defaultSAPShipToAddress = defaultSAPShipToAddress;
	}

	public String getDefaultSAPBillToAddress() {
		return defaultSAPBillToAddress;
	}

	public void setDefaultSAPBillToAddress(String defaultSAPBillToAddress) {
		this.defaultSAPBillToAddress = defaultSAPBillToAddress;
	}

	public String getShippAddType() {
		return shippAddType;
	}

	public void setShippAddType(String shippAddType) {
		this.shippAddType = shippAddType;
	}

	public Date getPassChngReqDate() {
		return passChngReqDate;
	}

	public void setPassChngReqDate(Date passChngReqDate) {
		this.passChngReqDate = passChngReqDate;
	}

	public boolean isTestAccount() {
		return testAccount;
	}

	public void setTestAccount(boolean testAccount) {
		this.testAccount = testAccount;
	}

	public String getPreviousPass() {
		return previousPass;
	}

	public void setPreviousPass(String previousPass) {
		this.previousPass = previousPass;
	}

	public boolean isDirectorAccount() {
		return directorAccount;
	}

	public void setDirectorAccount(boolean directorAccount) {
		this.directorAccount = directorAccount;
	}

	public boolean isDropShipment() {
		return dropShipment;
	}

	public void setDropShipment(boolean dropShipment) {
		this.dropShipment = dropShipment;
	}

	public boolean isShowDutyFreePrice() {
		return showDutyFreePrice;
	}

	public void setShowDutyFreePrice(boolean showDutyFreePrice) {
		this.showDutyFreePrice = showDutyFreePrice;
	}

	public String getPayerInvoiceEmail() {
		return payerInvoiceEmail;
	}

	public void setPayerInvoiceEmail(String payerInvoiceEmail) {
		this.payerInvoiceEmail = payerInvoiceEmail;
	}

	public boolean isAddFileUploaded() {
		return isAddFileUploaded;
	}

	public void setAddFileUploaded(boolean isAddFileUploaded) {
		this.isAddFileUploaded = isAddFileUploaded;
	}

	public boolean isAdvShpDisable() {
		return advShpDisable;
	}

	public void setAdvShpDisable(boolean advShpDisable) {
		this.advShpDisable = advShpDisable;
	}
	
	public List<ChangeHistoryVO> getChangeHistory() {
		return changeHistory;
	}

	public void setChangeHistory(List<ChangeHistoryVO> changeHistory) {
		this.changeHistory = changeHistory;
	}

	public boolean isSendMail() {
		return sendMail;
	}

	public void setSendMail(boolean sendMail) {
		this.sendMail = sendMail;
	}

	public String getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	public String getEmailCC() {
		return emailCC;
	}

	public void setEmailCC(String emailCC) {
		this.emailCC = emailCC;
	}

	public String getEmailBCC() {
		return emailBCC;
	}

	public void setEmailBCC(String emailBCC) {
		this.emailBCC = emailBCC;
	}

	public String getEmailFrom() {
		return emailFrom;
	}

	public void setEmailFrom(String emailFrom) {
		this.emailFrom = emailFrom;
	}

	public String getEmailTemplateURL() {
		return emailTemplateURL;
	}

	public void setEmailTemplateURL(String emailTemplateURL) {
		this.emailTemplateURL = emailTemplateURL;
	}

	public TemplateEmailSender getEmailSender() {
		return emailSender;
	}

	public void setEmailSender(TemplateEmailSender emailSender) {
		this.emailSender = emailSender;
	}

	public MessageContentProcessor getContentProcessor() {
		return contentProcessor;
	}

	public void setContentProcessor(MessageContentProcessor contentProcessor) {
		this.contentProcessor = contentProcessor;
	}

	public String getEmailSubject() {
		return emailSubject;
	}

	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	
	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public AgilentConfiguration getConfiguration() {
		return configuration;
	}

	public void setConfiguration(AgilentConfiguration configuration) {
		this.configuration = configuration;
	}

	public String getBccEmail() {
		return bccEmail;
	}

	public void setBccEmail(String bccEmail) {
		this.bccEmail = bccEmail;
	}

	/**
	 * @return the defaultItemCount
	 */
	public int getDefaultItemCount() {
		return defaultItemCount;
	}

	/**
	 * @param defaultItemCount the defaultItemCount to set
	 */
	public void setDefaultItemCount(int defaultItemCount) {
		this.defaultItemCount = defaultItemCount;
	}
	/**
	 * @return the partnerName
	 */
	public String getPartnerName() {
		return partnerName;
	}

	/**
	 * @param partnerName the partnerName to set
	 */
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	/**
	 * @return the partnerIdentifier
	 */
	public String getPartnerIdentifier() {
		return partnerIdentifier;
	}

	/**
	 * @param partnerIdentifier the partnerIdentifier to set
	 */
	public void setPartnerIdentifier(String partnerIdentifier) {
		this.partnerIdentifier = partnerIdentifier;
	}

	

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}

	/**
	 * @return the sapDirectorAccount
	 */
	public Boolean getSapDirectorAccount() {
		return sapDirectorAccount;
	}

	/**
	 * @return the b2bGroupId
	 */
	public String getB2bGroupId() {
		return b2bGroupId;
	}

	/**
	 * @return the telephoneNumber
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}

	/**
	 * @return the invShipCustomerName
	 */
	public String getInvShipCustomerName() {
		return invShipCustomerName;
	}

	/**
	 * @return the invAddress
	 */
	public String getInvAddress() {
		return invAddress;
	}

	/**
	 * @return the invBankAccount
	 */
	public String getInvBankAccount() {
		return invBankAccount;
	}

	/**
	 * @return the invBankName
	 */
	public String getInvBankName() {
		return invBankName;
	}

	/**
	 * @return the invCity
	 */
	public String getInvCity() {
		return invCity;
	}

	/**
	 * @return the invContactPerson
	 */
	public String getInvContactPerson() {
		return invContactPerson;
	}

	/**
	 * @return the invCustomerName
	 */
	public String getInvCustomerName() {
		return invCustomerName;
	}

	/**
	 * @return the invPhoneNumber
	 */
	public String getInvPhoneNumber() {
		return invPhoneNumber;
	}

	/**
	 * @return the invPostalCode
	 */
	public String getInvPostalCode() {
		return invPostalCode;
	}

	/**
	 * @return the invShipAddress
	 */
	public String getInvShipAddress() {
		return invShipAddress;
	}

	/**
	 * @return the invTaxCode
	 */
	public String getInvTaxCode() {
		return invTaxCode;
	}

	/**
	 * @return the b2bUser
	 */
	public Boolean getB2bUser() {
		return b2bUser;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}

	/**
	 * @param sapDirectorAccount the sapDirectorAccount to set
	 */
	public void setSapDirectorAccount(Boolean sapDirectorAccount) {
		this.sapDirectorAccount = sapDirectorAccount;
	}

	/**
	 * @param b2bGroupId the b2bGroupId to set
	 */
	public void setB2bGroupId(String b2bGroupId) {
		this.b2bGroupId = b2bGroupId;
	}

	/**
	 * @param telephoneNumber the telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	/**
	 * @param invShipCustomerName the invShipCustomerName to set
	 */
	public void setInvShipCustomerName(String invShipCustomerName) {
		this.invShipCustomerName = invShipCustomerName;
	}

	/**
	 * @param invAddress the invAddress to set
	 */
	public void setInvAddress(String invAddress) {
		this.invAddress = invAddress;
	}

	/**
	 * @param invBankAccount the invBankAccount to set
	 */
	public void setInvBankAccount(String invBankAccount) {
		this.invBankAccount = invBankAccount;
	}

	/**
	 * @param invBankName the invBankName to set
	 */
	public void setInvBankName(String invBankName) {
		this.invBankName = invBankName;
	}

	/**
	 * @param invCity the invCity to set
	 */
	public void setInvCity(String invCity) {
		this.invCity = invCity;
	}

	/**
	 * @param invContactPerson the invContactPerson to set
	 */
	public void setInvContactPerson(String invContactPerson) {
		this.invContactPerson = invContactPerson;
	}

	/**
	 * @param invCustomerName the invCustomerName to set
	 */
	public void setInvCustomerName(String invCustomerName) {
		this.invCustomerName = invCustomerName;
	}

	/**
	 * @param invPhoneNumber the invPhoneNumber to set
	 */
	public void setInvPhoneNumber(String invPhoneNumber) {
		this.invPhoneNumber = invPhoneNumber;
	}

	/**
	 * @param invPostalCode the invPostalCode to set
	 */
	public void setInvPostalCode(String invPostalCode) {
		this.invPostalCode = invPostalCode;
	}

	/**
	 * @param invShipAddress the invShipAddress to set
	 */
	public void setInvShipAddress(String invShipAddress) {
		this.invShipAddress = invShipAddress;
	}

	/**
	 * @param invTaxCode the invTaxCode to set
	 */
	public void setInvTaxCode(String invTaxCode) {
		this.invTaxCode = invTaxCode;
	}

	/**
	 * @param b2bUser the b2bUser to set
	 */
	public void setB2bUser(Boolean b2bUser) {
		this.b2bUser = b2bUser;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	public IErrorHandler getErrorHandler() {
		return errorHandler;
	}

	public void setErrorHandler(IErrorHandler errorHandler) {
		this.errorHandler = errorHandler;
	}

	public IValidator getValidator() {
		return validator;
	}

	public void setValidator(IValidator validator) {
		this.validator = validator;
	}
    /**
     * @return the crmContactId
     */
    public String getCrmContactId() {
        return crmContactId;
    }

    /**
     * @param crmContactId the crmContactId to set
     */
    public void setCrmContactId(String crmContactId) {
        this.crmContactId = crmContactId;
    }

	/**
	 * @return the integrateOktaConnManager
	 */
	public IntegrateOktaConnectionManager getIntegrateOktaConnManager() {
		return integrateOktaConnManager;
	}

	/**
	 * @param integrateOktaConnManager the integrateOktaConnManager to set
	 */
	public void setIntegrateOktaConnManager(IntegrateOktaConnectionManager integrateOktaConnManager) {
		this.integrateOktaConnManager = integrateOktaConnManager;
	}

	/**
	 * @return the secondaryEccId
	 */
	public String getSecondaryEccId() {
		return secondaryEccId;
	}

	/**
	 * @param secondaryEccId the secondaryEccId to set
	 */
	public void setSecondaryEccId(String secondaryEccId) {
		this.secondaryEccId = secondaryEccId;
	}

	/**
	 * @return the multipleSoldTo
	 */
	public String getMultipleSoldTo() {
		return multipleSoldTo;
	}

	/**
	 * @param multipleSoldTo the multipleSoldTo to set
	 */
	public void setMultipleSoldTo(String multipleSoldTo) {
		this.multipleSoldTo = multipleSoldTo;
	}

	/**
	 * @return the userStatus
	 */
	public String getUserStatus() {
		return userStatus;
	}

	/**
	 * @param userStatus the userStatus to set
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

    /**
     * Gets the value of property mStatusUpdateSuccessURL
     *
     * @return the value of property mStatusUpdateSuccessURL
     */
    public String getStatusUpdateSuccessURL() {
        return mStatusUpdateSuccessURL;
    }

    /**
     * Sets the value of property mStatusUpdateSuccessURL with value mStatusUpdateSuccessURL
     *
     * @param mStatusUpdateSuccessURL
     *            for setting property mStatusUpdateSuccessURL
     */
    public void setStatusUpdateSuccessURL(String mStatusUpdateSuccessURL) {
        this.mStatusUpdateSuccessURL = mStatusUpdateSuccessURL;
    }

    /**
     * Gets the value of property mStatusUpdateErrorURL
     *
     * @return the value of property mStatusUpdateErrorURL
     */
    public String getStatusUpdateErrorURL() {
        return mStatusUpdateErrorURL;
    }

    /**
     * Sets the value of property mStatusUpdateErrorURL with value mStatusUpdateErrorURL
     *
     * @param mStatusUpdateErrorURL
     *            for setting property mStatusUpdateErrorURL
     */
    public void setStatusUpdateErrorURL(String mStatusUpdateErrorURL) {
        this.mStatusUpdateErrorURL = mStatusUpdateErrorURL;
    }

	/**
	 * @return the userAvailableInOkta
	 */
	public boolean isUserAvailableInOkta() {
		return userAvailableInOkta;
	}

	/**
	 * @param userAvailableInOkta the userAvailableInOkta to set
	 */
	public void setUserAvailableInOkta(boolean userAvailableInOkta) {
		this.userAvailableInOkta = userAvailableInOkta;
	}

	/**
	 * @return the actionDriven
	 */
	public boolean isActionDriven() {
		return actionDriven;
	}

	/**
	 * @param actionDriven the actionDriven to set
	 */
	public void setActionDriven(boolean actionDriven) {
		this.actionDriven = actionDriven;
	}
	
}
