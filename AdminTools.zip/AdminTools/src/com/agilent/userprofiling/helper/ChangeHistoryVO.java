/**
 * 
 */
package com.agilent.userprofiling.helper;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import com.agilent.i18n.service.InternationalizationService;

import atg.core.util.ResourceUtils;
import atg.core.util.StringUtils;

/**
 * @author mankesh-k
 *
 */
public class ChangeHistoryVO {

	private String changeTime;
	private String changedBy;
	private String Changes;
	
	public String getChangeTime() {
		return changeTime;
	}
	public void setChangeTime(String changeTime) {
		this.changeTime = changeTime;
	}
	public String getChangedBy() {
		return changedBy;
	}
	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}
	public String getChanges() {
		return Changes;
	}
	public void setChanges(String changes) {
		Changes = changes;
	}
	
	/**
	 * To convert the map data into String so that it can be displayed as Single String
	 * @param changeHistory
	 * @param pKeyValueMap 
	 * @param pResourceBundle 
	 * @param pInternationalizationService 
	 */
	public String convertMapvalueToString(Map<String, String> changeHistory, Map<String, String> pKeyValueMap, ResourceBundle pResourceBundle, InternationalizationService pInternationalizationService){
		StringBuilder strBuilder = new StringBuilder();
		Map<String, Object> params = new HashMap<String,Object>();
		String keyName = null;
		String keyNameValue = null;
		if(null != changeHistory){
			for(Entry<String, String> entry : changeHistory.entrySet()){
				keyName = pKeyValueMap.get(entry.getKey());
				if(StringUtils.isNotBlank(keyName)) {
					keyNameValue = 	pInternationalizationService.getLocalizeMessage(keyName, params);
				}
				if(StringUtils.isBlank(keyNameValue) && null != keyName) {
					keyNameValue = ResourceUtils.getMsgResource(keyName, "com.agilent.web.usermanagement.WebAppResources", pResourceBundle);
				}
				if(StringUtils.isNotBlank(keyName) && StringUtils.isNotBlank(keyNameValue) && null != keyNameValue) {
					strBuilder.append(keyNameValue + "=" + entry.getValue()+"\n");
				}else {
					strBuilder.append(entry.getKey()+"="+entry.getValue()+"\n");
				}
		 	}
		}
		 return strBuilder.toString();
	}
}
