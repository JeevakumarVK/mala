package com.agilent.userprofiling.helper;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.transaction.TransactionManager;

import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.rest.okta.vo.OktaProfile;
import com.agilent.base.rest.okta.vo.OktaUser;
import com.agilent.i18n.service.InternationalizationService;

import atg.core.util.StringUtils;
import atg.dtm.TransactionDemarcation;
import atg.dtm.TransactionDemarcationException;
import atg.nucleus.GenericService;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;
import atg.userprofiling.Profile;


/**
 * This Helper class cotains the business logic to interact to ProfileAdaptor Repository
 * 
 * @author mankesh-k
 *
 */
public class ExternalUserHelper extends GenericService {


	private final String USER_ITEMDESCRIPTOR="user";
	private Repository profileRepository;
	private AgilentProfileTools profileTools;
	private Profile profile=null;
	private TransactionManager transactionManager = null;
	private InternationalizationService internationalizationService;
	private Map<String,String> keyValueMap;
	private static java.util.ResourceBundle sAResourceBundle = java.util.ResourceBundle.getBundle("com.agilent.web.usermanagement.WebAppResources",atg.service.dynamo.LangLicense.getLicensedDefault());
	private boolean enableAudit;
	
	/**
	 * This Method will search into profile repository with given field name and its value and will return the matching items
	 * @param propName
	 * @param propValue
	 * @param itemCount
	 * @return
	 */
	public List<ExternalUserVO> searchUser(String propName,String propValue,int itemCount){
		vlogInfo("searchUser Method starts with parameter values PropName ={0} and propValue={1}",propName,propValue );
		
		List<ExternalUserVO> resultList=new ArrayList<ExternalUserVO>();
		RepositoryItem[] items=null;
		Repository rep=getProfileRepository();
		HashSet<ExternalUserVO> resultSet;
		OktaUser lOktaUser =null;
		try {
			if(null != rep && StringUtils.isNotBlank(propName) && StringUtils.isNotBlank(propValue)){
			/* APP-13459 - 01/06/2017 - Incorrect USER Management tool DATA start*/
			RqlStatement statement = RqlStatement.parseRqlStatement(propName +" CONTAINS IGNORECASE ?0 ORDER BY adLoginName SORT DESC RANGE +?1");
			/* APP-13459 - 01/06/2017 - Incorrect USER Management tool DATA End*/ 
			RepositoryView view = rep.getView("user");
			Object[] params = new Object[2];
			params[0]=propValue;
			params[1]=itemCount;
			items = statement.executeQuery(view, params);
			if(null!= items){
				resultSet = new HashSet<ExternalUserVO>();
	            for ( RepositoryItem item : items) {
	                resultSet.add(populateExternalUserVO(item,lOktaUser,"searchPage"));
	            }
	            resultList = new ArrayList<ExternalUserVO>(resultSet);
	            return resultList;
	        
			}
				
			return resultList;
			
			}
			
		} catch (RepositoryException e) {
			vlogError("Repository Exception thrown with following details {0}, {1}", e,e.getMessage());
		}
		 return Collections.emptyList();
	}
	
	
	
        /**
        * This Method will search into profile repository with given field name customer ID and its value and will return the matching items
        * @param propName
        * @param propValue
        * @param itemCount
        * @param pOktaUser 
        * @return
        */
                
        public List<ExternalUserVO> searchUserByCustomerId(String propName,String propValue,int itemCount, OktaUser pOktaUser){
            vlogInfo("searchUserByCustomerId Method starts with parameter values PropName ={0} and propValue={1}",propName,propValue );
	        List<ExternalUserVO> resultList=new ArrayList<ExternalUserVO>();
	        RepositoryItem[] items=null;
	        Repository rep=getProfileRepository();
	        HashSet<ExternalUserVO> resultSet;
	        try {
	            if(null != rep && StringUtils.isNotBlank(propName) && StringUtils.isNotBlank(propValue)){
		            RqlStatement statement = RqlStatement.parseRqlStatement(propName +" EQUALS ?0 ORDER BY adLoginName SORT DESC RANGE +?1");
		            RepositoryView view = rep.getView("user");
		            Object[] params = new Object[2];
		            params[0]=propValue;
		            params[1]=itemCount;
		            items = statement.executeQuery(view, params);
		            if(null!= items){
	                    resultSet = new HashSet<ExternalUserVO>();
					    for (RepositoryItem item : items) {
					        resultSet.add(populateExternalUserVO(item,pOktaUser,null));
					    }	
					    resultList = new ArrayList<ExternalUserVO>(resultSet);
					    return resultList;
		            }
		            return resultList;
	            }
	        }catch (RepositoryException e) {
	        	vlogError("Repository Exception thrown with following details {0}, {1}", e,e.getMessage());
	        }
	        return Collections.emptyList();
        }
                

	/**
	 * This method is used to find an user item by passing an userid
	 * @param pUserId
	 * @return
	 */
    public RepositoryItem findUserItem(String pUserId) {
    	vlogDebug("Entering the method::: {0} in class: {1}","findUserItem",getClass().toString());
    	RepositoryItem profileItem = null;
    	if(StringUtils.isNotBlank(pUserId)) {
    		try {
        		profileItem = getProfileRepository().getItem(pUserId,"user");
    		} catch (RepositoryException e) {
    			vlogError("Repository Exception in findUserItem method Exception Details -> {0}, {1}", e,e.getMessage());
    		}
    	}else {
    		vlogDebug("ExternalUserHelper.findUserItem ::: UserID is empty");
    	}
    	vlogDebug("Exisiting the method: {0} in class: {1}","findUserItem",getClass().toString());
    	return profileItem;
    }
	
	/**
	 * To update the user's properties in repository
	 * @param propMap
	 * @param userId
	 * @return
	 */
	@SuppressWarnings("unused")
	public boolean updateExternalUser(Map<String, Object> propMap, String userId, String BusinessUserEmail, String[] roles){
		vlogDebug("Inside updateExternalUser method , userId ={0}", userId);
		TransactionDemarcation td = new TransactionDemarcation();
		TransactionManager tm = getTransactionManager();
		RepositoryItem[] items=null;
		boolean updatedFlag=false;
		Map <String,String> changeHistory= new HashMap<String,String>() ;
		Map <String,RepositoryItem> changeHistoryMap= new HashMap<String,RepositoryItem>() ;
		MutableRepository mutRep = (MutableRepository) getProfileRepository();
		Map <String,Object> oldValueMap = new HashMap<String,Object>();
		try {
			if (tm == null) {
				vlogError("Transaction manager is null ");
				return updatedFlag;
			}	
			td.begin(tm, TransactionDemarcation.REQUIRES_NEW);
			MutableRepositoryItem userItem = mutRep.getItemForUpdate(userId, USER_ITEMDESCRIPTOR);
			if(null !=userItem){
				 for(Entry<String, Object> entry : propMap.entrySet()){
					 if(isModifiedProperty(entry.getKey(), entry.getValue(),userItem)){
						 String tempValue=null;
						 if(null !=entry.getValue()){
							 tempValue=entry.getValue().toString();
						 }
						 changeHistory.put(entry.getKey(), tempValue);
						 oldValueMap.put(entry.getKey(), userItem.getPropertyValue(entry.getKey()));
						 vlogDebug("entry.getKey()" + entry.getKey() +  " entry.getValue()" + entry.getValue() );
						 if(entry.getKey().equals("secondaryEccId")) {
							 String[] secondaryEccId = entry.getValue().toString().split(",");
							 Set<String> sEccSet = null;
							 if(null != entry.getValue() && null != entry.getValue().toString() && entry.getValue().toString().length() == 0) {
								 sEccSet = new HashSet<String>();
							 }else {
								 sEccSet = new HashSet<String>(Arrays.asList(secondaryEccId)); 
							 }
							 userItem.setPropertyValue(entry.getKey(), sEccSet);
						 }else if(entry.getKey().equals("multipleSoldTo")) {
							 String[] multipleSoldTo = entry.getValue().toString().split(",");
							 Set<String> mSet = null;
							 if(null != entry.getValue() && null != entry.getValue().toString() && entry.getValue().toString().length() == 0) {
								 mSet = new HashSet<String>();
							 }else {
								 mSet = new HashSet<String>(Arrays.asList(multipleSoldTo)); 
							 }
							 userItem.setPropertyValue(entry.getKey(), mSet);
						 }else {
							 userItem.setPropertyValue(entry.getKey(), entry.getValue());
							 }
					 }
					
		        }
				 /*//to update the roles of user
				 if(null != roles && roles.length>0){
					//Set<RepositoryItem> roleItems = (Set<RepositoryItem>) userItem.getPropertyValue("roles");
					Set<RepositoryItem> roleItems = new HashSet<RepositoryItem>();
					RqlStatement statement = RqlStatement.parseRqlStatement(" id= ?0");
					RepositoryView view = mutRep.getView("role");
					Object[] params = new Object[1];
					for(String roleId:roles){
					params[0]=roleId;
					items = statement.executeQuery(view, params);
					if(null!= items){
						roleItems.add(items[0]);
						}
					}
					userItem.setPropertyValue("roles", roleItems);
				 }*/
				 
				 //to set the changeHistory in user item
				 if(!changeHistory.isEmpty()){
				 changeHistoryMap=saveChangeHistory(changeHistory,userItem,BusinessUserEmail,oldValueMap);
				 	if(null != changeHistoryMap && !changeHistoryMap.isEmpty()){
				 		if(changeHistoryMap.values().contains(null)) {changeHistoryMap.values().remove(null);}
				 		userItem.setPropertyValue("changeHistory",changeHistoryMap);
				 	}
				 }
				 mutRep.updateItem(userItem);
				 updatedFlag=true;
			}
		} catch (RepositoryException e) {
			vlogError("Repository Exception in updateExternalUser method Exception Details -> {0}, {1}", e,e.getMessage());
		}
		catch(Exception ex){
			vlogError("Exception thrown from updateExternalUser method ,Exception Details ->{0}",ex.getMessage());
		}
		finally {
			try {
				td.end();
			} catch (TransactionDemarcationException e) {
				vlogError("Transaction demarctaion error {0}", e);	
			}
		}
		return updatedFlag;
	}
	
	


	/**
	 * To check whether given property is modified or not for maintaining change history
	 * @param propName  Property name
	 * @param propValue property Value
	 * @param item
	 * @return true if property value is modified otherwise false
	 */
	
    public boolean isModifiedProperty(String propName, Object propValue, RepositoryItem item) {
        boolean modified = false;
        Object curValue = (Object) item.getPropertyValue(propName);
        if (curValue == null && propValue == null) {
            return false;
        } else if (propValue instanceof Boolean) {
            Boolean oldValue = checkBooleanValue(item.getPropertyValue(propName));
            Boolean newValue = (Boolean) propValue;
            if (oldValue == null && newValue != null) {
                return true;
            } else {
                return oldValue.equals(newValue) ? false : true;
            }
        } else if (propValue instanceof String) {
            if (null != propName && (propName.equals("secondaryEccId") || propName.equals("multipleSoldTo"))) {
                boolean isModified = false;
                isModified = checkSetValue(propValue, item, propName);
                return isModified;
            } else {
                String oldValue = (String) item.getPropertyValue(propName);
                String newValue = (String) propValue;
                if (StringUtils.isBlank(oldValue) && !StringUtils.isBlank(newValue)) {
                    return true;
                } else if (StringUtils.isBlank(oldValue) && StringUtils.isBlank(newValue)) {
                    return false;
                } else {
                    return oldValue.equals(newValue) ? false : true;
                }
            }
        } else if (propValue instanceof Double) {
            Double oldValue = (Double) item.getPropertyValue(propName);
            Double newValue = (Double) propValue;
            if (oldValue == null && newValue != null) {
                return true;
            } else {
                return oldValue.equals(newValue) ? false : true;
            }

        } else if (propValue instanceof Integer) {
            Integer oldValue = (Integer) item.getPropertyValue(propName);
            Integer newValue = (Integer) propValue;
            if (oldValue == null && newValue != null) {
                return true;
            } else {
                return oldValue.equals(newValue) ? false : true;
            }
        } else {
            vlogInfo("Datatype of this property= {0} is not handled, value is {1}", propName, propValue);
            return modified;
        }

    }
	
	/**
	 * Method to check Set values are empty or not
	 * @param propValue
	 * @param item
	 * @param propName
	 * @return
	 */
	private boolean checkSetValue(Object propValue, RepositoryItem item, String propName) {
		boolean isModified = false;
		if(null != propValue) {
			String[] values = ((String) propValue).split(",");
			Set<String> oldSet = (Set<String>) item.getPropertyValue(propName);
			Set<String> newSet = new HashSet<String>(Arrays.asList(values));
			if(oldSet.isEmpty() && !newSet.isEmpty() && newSet.contains("")) {
				isModified = false;	
			}else if((oldSet == null && newSet != null) || oldSet != null && newSet == null || oldSet.size() != newSet.size()){
				isModified = true;
			}else {
				isModified = oldSet.equals(newSet) ? false :true;
			}
		}
		return isModified;
	}



	/**
	 * To save the changes made in user profile in changeInfo item-Descriptor
	 * @param changeHistory
	 * @param repositoryItem
	 * @param oldValueMap 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public Map<String, RepositoryItem> saveChangeHistory(Map<String, String> changeHistory, RepositoryItem repositoryItem, String BusinessUserEmail, Map<String, Object> oldValueMap){
		Map<String,RepositoryItem> changeHistoryMapItem=null;
		MutableRepositoryItem addItem =null;
		MutableRepositoryItem changeInfo =null;
		Map<String, RepositoryItem> sortedMap=new HashMap<String, RepositoryItem>();
		try {
				changeInfo=((MutableRepository)getProfileRepository()).createItem("changeInfo");
				changeInfo.setPropertyValue("changeId",repositoryItem.getRepositoryId());
				changeInfo.setPropertyValue("changePropertyMap", changeHistory);
				changeInfo.setPropertyValue("changedBy", BusinessUserEmail); 
     			addItem = (MutableRepositoryItem) ((MutableRepository) getProfileRepository()).addItem(changeInfo);
     			saveChangesWithOldAndNewValues(changeHistory,repositoryItem,BusinessUserEmail, oldValueMap);
			} catch (RepositoryException e) {
				vlogError("Error in creting item changeInfo {0}", e); 
			} 
			if(repositoryItem.getPropertyValue("changeHistory")!=null && repositoryItem.getPropertyValue("changeHistory") instanceof Map){
			 changeHistoryMapItem= (Map<String, RepositoryItem>) repositoryItem.getPropertyValue("changeHistory");
			}else{
			changeHistoryMapItem=new HashMap<String, RepositoryItem>();
			}
			Date date= new Date();
			changeHistoryMapItem.put(new Timestamp(date.getTime()).toString(), addItem);
			
			sortedMap = sortDateMap(changeHistoryMapItem);
			changeHistoryMapItem.clear();
			 changeHistoryMapItem.putAll(sortedMap); 
			//getValue().put("CHANGEHISTORY",sortedMap);   
	
		return sortedMap;
	}
	/**
	 * This method will update new and old values in to the data base for audit purpose.
	 * @param changeHistory
	 * @param repositoryItem
	 * @param businessUserEmail
	 * @param oldValueMap
	 */
	private void saveChangesWithOldAndNewValues(Map<String, String> changeHistory, RepositoryItem repositoryItem, String businessUserEmail, Map<String, Object> oldValueMap) {
		vlogDebug(" --- Entering into ExternalUserHelper.saveChangesWithOldAndNewValues method ----");
		MutableRepositoryItem changeInfoValues =null;
		try {
			for (Map.Entry<String, String> entry : changeHistory.entrySet()) {
					changeInfoValues = ((MutableRepository)getProfileRepository()).createItem("changeInfoValues");
					changeInfoValues.setPropertyValue("userid", repositoryItem.getRepositoryId()); 
					changeInfoValues.setPropertyValue("propName", entry.getKey()); 
					Date date= new Date();
					changeInfoValues.setPropertyValue("timeChanged", new Timestamp(date.getTime()).toString());
					Object valueType =  oldValueMap.get(entry.getKey());
					if(valueType instanceof String) {
						changeInfoValues.setPropertyValue("oldValue", oldValueMap.get(entry.getKey())); 	
					}else if(valueType instanceof Boolean) {
						changeInfoValues.setPropertyValue("oldValue", oldValueMap.get(entry.getKey()).toString()); 
					}else if(valueType instanceof Set) {
						Set<String> valType = (Set<String>) valueType;
						String result = null;
						if(valType.size() > 0) {
							String separator = ",";
							int total = valType.size() * separator.length();
							for (String s : valType) {
							    total += s.length();
							}
							StringBuilder sb = new StringBuilder(total);
							for (String s : valType) {
							    sb.append(separator).append(s);
							}
							result = sb.substring(separator.length());
						}
						changeInfoValues.setPropertyValue("oldValue", result); 
					}else {
						changeInfoValues.setPropertyValue("oldValue", null); 
					}
					changeInfoValues.setPropertyValue("newValue", entry.getValue().toString()); 
					((MutableRepository) getProfileRepository()).addItem(changeInfoValues);
					vlogDebug(" --- Existing from the ExternalUserHelper.saveChangesWithOldAndNewValues method ----");
				}
			} catch (RepositoryException e) {
				 vlogError("Error occured", e.getMessage());
			} catch (Exception e) {
				 vlogError("General Error occured", e.getMessage());
			}
		}
	
	/**
	 * This method will record the audit entries for Okta Profile Status Flag
	 * @param pUserId
	 * @param pChangedBy
	 * @param pOldValue
	 * @param pNewValue
	 */
	public void saveAuditChangesForOKTAStatus(String pUserId, String pStatus) {
		vlogDebug(" --- Entering into ExternalUserHelper.saveAuditChangesForOKTAStatus method ----");
		if(isEnableAudit()) {
			Map <String,String> changeHistory = null;
	  	    Map <String,RepositoryItem> changeHistoryMap = null;
	  	    Map <String,Object> oldValueMap = null ;
	  	    MutableRepository mutRep = null;
	  	    MutableRepositoryItem userItem = null;
			try {
				if(StringUtils.isNotBlank(pUserId)) {
					changeHistory= new HashMap<String,String>() ;
					changeHistoryMap = new HashMap<String,RepositoryItem>();
					oldValueMap = new HashMap<String,Object>() ;
					mutRep = (MutableRepository) getProfileRepository();
		     	    userItem = mutRep.getItemForUpdate(pUserId, "user");
		     	    if(null == userItem || null == getProfile()) {
		     	    	vlogInfo("::: ExternalUserHelper.saveAuditChangesForOKTAStatus :: User not found / profile obj Null");
		     	    } else {
		     	    	oldValueMap.put("oktaProfileStatus", "");
			     	    changeHistory.put("oktaProfileStatus", pStatus);
			     		 if(!changeHistory.isEmpty()){
			     			 String businessUserEmail = (String) getProfile().getPropertyValue("email");
			     			 changeHistoryMap = saveChangeHistory(changeHistory,userItem,businessUserEmail,oldValueMap);
			     			 if(null != changeHistoryMap && !changeHistoryMap.isEmpty()){
			     				 if(changeHistoryMap.values().contains(null)) {changeHistoryMap.values().remove(null);}
			     				 	userItem.setPropertyValue("changeHistory",changeHistoryMap);
			     			 }
			     		 }
			     		mutRep.updateItem(userItem);
		     	    }
	     		} else {
	     			vlogInfo("::: ExternalUserHelper.saveAuditChangesForOKTAStatus :: user id is empty");
	     		}
			} catch (RepositoryException e) {
				 vlogError("Error occured in saveAuditChangesForOKTAStatus", e.getMessage());
			}
		}else {
			vlogInfo("::: ExternalUserHelper.saveAuditChangesForOKTAStatus :: isEnableAudit is -->{0}",isEnableAudit());
		}
		vlogDebug(" --- Existing from the ExternalUserHelper.saveAuditChangesForOKTAStatus method ----");
	}
	
	/**
	 * To sort the changeHistoryMap on the basis of date so that latest changes can appear at top of the table
	 * @param changeHistoryMapItem
	 * @return
	 */
	
	private  Map<String, RepositoryItem> sortDateMap(Map<String, RepositoryItem> changeHistoryMapItem) {
		Set<String> keySet = changeHistoryMapItem.keySet();
		List<Date> dateList=new ArrayList<Date>();
		DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); 
		for (String string : keySet) {
			try {
				dateList.add(formatter.parse(string));
			} catch (ParseException e) {
					vlogError("ParseException {0}", e);
				}
		}
		Collections.sort(dateList,  new Comparator<Date>() {
		    @Override
		    public int compare( Date pO1, Date pO2) {
		        if (pO2.after(pO1)) {
		            return 1;
		        }else if(pO2.before(pO1)){
		        	return -1;
		        }else{
		        	return 0;
		        }
		    }
				});	
		if(dateList.size()>5){
			dateList= dateList.subList(0, 5);   
		}
		Map<String, RepositoryItem> sortedMap= new LinkedHashMap<String, RepositoryItem>();
		for (Date date2 : dateList) {
			sortedMap.put(new Timestamp(date2.getTime()).toString(), changeHistoryMapItem.get(new Timestamp(date2.getTime()).toString()));
		}
		return sortedMap;
	}
	
	/**
	 * This method used to find the user with given user ID
	 * @param userId -id of item to be fetched
	 * @return List of Users
	 */
	
	public List<ExternalUserVO> findUser(String userId) {
		
		List<ExternalUserVO> resultList=new ArrayList<ExternalUserVO>();
		RepositoryItem[] items=null;
		Repository rep=getProfileRepository();
		OktaUser lOktUser = null;
		try{
			RqlStatement statement = RqlStatement.parseRqlStatement( " ID =?0");
			RepositoryView view = rep.getView(USER_ITEMDESCRIPTOR);
			Object[] params = new Object[1];
			params[0]=userId;
			items = statement.executeQuery(view, params);
			if(null!= items){
				List<RepositoryItem> results=Arrays.asList(items);
				for(RepositoryItem item:results){
					resultList.add(populateExternalUserVO(item,lOktUser,"listingPage"));
				}
				return resultList;
				}
			
		}
		catch (RepositoryException e) {
			vlogError("Repository Exception thrown while retriving user detail with ID {0}, with following details {1}, {2}",userId, e,e.getMessage());
		}
		 return Collections.emptyList();
	}
	
	/**
	 * This method is used to list the recently added users from repository 
	 * @param itemCount -count of items to be fetched
	 * @return List of Users
	 */
	
	
public List<ExternalUserVO> listRecentUsers(int defaultItemCount,String pPageName) {
		
		List<ExternalUserVO> resultList=new ArrayList<ExternalUserVO>();
		RepositoryItem[] items=null;
		Repository rep=getProfileRepository();
		OktaUser lOktaUser = null;
		try{
			RqlStatement statement = RqlStatement.parseRqlStatement( "ALL AND NOT registrationDate IS NULL ORDER BY registrationDate SORT DESC RANGE +?0");
			RepositoryView view = rep.getView(USER_ITEMDESCRIPTOR);
			Object[] params = new Object[1];
			params[0]=defaultItemCount;
			items = statement.executeQuery(view, params);
			if(null!= items){
				List<RepositoryItem> results=Arrays.asList(items);
				for(RepositoryItem item:results){
					resultList.add(populateExternalUserVO(item,lOktaUser,pPageName));
				}
				return resultList;
				}
			
		}
		catch (RepositoryException e) {
			vlogError("Repository Exception thrown while retriving user list, with following details {0}, {1}", e,e.getMessage());
		}
		 return Collections.emptyList();
	}
	
	
	
	/**
	 * This method will create a ExternalUserVO object with given repositoryItem
	 * @param item -contains details of an user 
	 * @param pOktaUser 
	 * @return ExternalUserVO
	 */
	public ExternalUserVO populateExternalUserVO(RepositoryItem item, OktaUser pOktaUser,String pageName){
		vlogDebug("::: Entering in to the ExternalUserHelper.populateExternalUserVO :::");
		AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		ExternalUserVO externalUservo = new ExternalUserVO();
		if(null != item){
			if(StringUtils.isNotBlank(pageName)) {
				vlogDebug("::: ExternalUserHelper.populateExternalUserVO ::: pageName -->{0}",pageName);
				externalUservo.setFirstName((String)item.getPropertyValue(propertyManager.getFirstNamePropertyName()));
				externalUservo.setLastName((String)item.getPropertyValue(propertyManager.getLastNamePropertyName()));
				externalUservo.setEmail((String)item.getPropertyValue(propertyManager.getEmailAddressPropertyName()));
				externalUservo.setAdLoginName((String)item.getPropertyValue(propertyManager.getAdLoginNamePropertyName()));
				externalUservo.seteCommStatus((String)item.getPropertyValue(propertyManager.getEcomStatusPropertyName()));
				externalUservo.setMemberType((String)item.getPropertyValue(propertyManager.getMemberTypePropertyName()));
				externalUservo.setSapSalesOrg((String)item.getPropertyValue(propertyManager.getSapSalesOrgPropertyName()));
				externalUservo.setUserCountry((String)item.getPropertyValue(propertyManager.getUserCountryPropertyName()));
				externalUservo.setSapMasterAcount(checkBooleanValue(item.getPropertyValue(propertyManager.getSapMasterAccountPropertyName())));
				externalUservo.setSAPContactNumber((String)item.getPropertyValue(propertyManager.getSapContactNumberPropertyName()));
				externalUservo.setCrmContactId((String)item.getPropertyValue("crmContactId"));
				externalUservo.setTestAccount(checkBooleanValue(item.getPropertyValue(propertyManager.getTestAccountPropertyName())));
				externalUservo.setDepartment((String)item.getPropertyValue("department"));
				externalUservo.setTitle((String)item.getPropertyValue("title"));
				Set<String> multipleSoldTo = (Set)item.getPropertyValue("multipleSoldTo");
				if(null != multipleSoldTo && !multipleSoldTo.isEmpty()) {
					externalUservo.setMultipleSoldTo(multipleSoldTo.toArray(new String[multipleSoldTo.size()]));
				}else {
					vlogDebug("::: ExternalUserHelper.populateExternalUserVO ::: multipleSoldTo is empty");
				}
				externalUservo.setInvShipCustomerName((String)item.getPropertyValue("customerName1"));
				externalUservo.setInvAddress((String)item.getPropertyValue("address1"));
				externalUservo.setInvBankAccount((String)item.getPropertyValue("bankAccount1"));
				externalUservo.setInvBankName((String)item.getPropertyValue("bankName1"));
				externalUservo.setInvCity((String)item.getPropertyValue("city2"));
				externalUservo.setInvContactPerson((String)item.getPropertyValue("contactorName2"));
				externalUservo.setInvCustomerName((String)item.getPropertyValue("customerName2"));
				externalUservo.setInvPhoneNumber((String)item.getPropertyValue("contactorPhNum2"));
				externalUservo.setInvPostalCode((String)item.getPropertyValue("postCode2"));
				externalUservo.setInvShipAddress((String)item.getPropertyValue("shippingAdrress2"));
				externalUservo.setInvTaxCode((String)item.getPropertyValue("companyTaxCode1"));
				externalUservo.setRegion((String)item.getPropertyValue(propertyManager.getRegion()));
			}else {
				vlogDebug("::: ExternalUserHelper.populateExternalUserVO :::: pageName is empty");
				externalUservo.setFirstName(pOktaUser.getProfile().getFirstName());
				externalUservo.setLastName(pOktaUser.getProfile().getLastName());
				externalUservo.setEmail(pOktaUser.getProfile().getEmail());
				externalUservo.setAdLoginName(pOktaUser.getProfile().getUSR_UDF_ADLOGINNAME());
				externalUservo.seteCommStatus(pOktaUser.getProfile().getUSR_UDF_ECOMMERCESTATUS());
				externalUservo.setMemberType(pOktaUser.getProfile().getUSR_UDF_MEMBERTYPE());
				externalUservo.setSapSalesOrg(pOktaUser.getProfile().getUSR_UDF_SAPSALESORG());
				externalUservo.setUserCountry(pOktaUser.getProfile().getUSR_COUNTRY());
				externalUservo.setSapMasterAcount(checkBooleanValue(pOktaUser.getProfile().isUSR_UDF_SAPMASTERACCOUNT()));
				externalUservo.setSAPContactNumber(pOktaUser.getProfile().getUSR_UDF_SAPCUSTOMERID());
				externalUservo.setCrmContactId(pOktaUser.getProfile().getUSR_UDF_CRMCONTACTNUMBER());
				externalUservo.setTestAccount(checkBooleanValue(pOktaUser.getProfile().isUSR_UDF_TESTACCOUNT()));
				externalUservo.setDepartment(pOktaUser.getProfile().getUSR_DEPT_NO());
				externalUservo.setTitle(pOktaUser.getProfile().getTitle());
				List<String> secondaryECCId = pOktaUser.getProfile().getSecondaryECCContact_ID();
				if(null != secondaryECCId && !secondaryECCId.isEmpty()) {
					if(secondaryECCId.contains(null)) {secondaryECCId.remove(null);}
					externalUservo.setSecondaryEccId(secondaryECCId.toArray(new String[secondaryECCId.size()]));
				}
				List<String> multipleSoldTo = pOktaUser.getProfile().getMultipleSoldTo();
				if(null != multipleSoldTo && !multipleSoldTo.isEmpty()) {
					if(multipleSoldTo.contains(null)) {multipleSoldTo.remove(null);}
					externalUservo.setMultipleSoldTo(multipleSoldTo.toArray(new String[multipleSoldTo.size()]));
				}
				externalUservo.setInvShipCustomerName(pOktaUser.getProfile().getUSR_UDF_CUSTOMERNAME());
				externalUservo.setInvAddress(pOktaUser.getProfile().getUSR_UDF_INVOICEADDRESS());
				externalUservo.setInvBankAccount(pOktaUser.getProfile().getUSR_UDF_INVOICEBANKACCOUNT());
				externalUservo.setInvBankName(pOktaUser.getProfile().getUSR_UDF_INVOICEBANKNAME());
				externalUservo.setInvCity(pOktaUser.getProfile().getUSR_UDF_INVOICECITY());
				externalUservo.setInvContactPerson(pOktaUser.getProfile().getUSR_UDF_INVOICECONTACTPERSON());
				externalUservo.setInvCustomerName(pOktaUser.getProfile().getUSR_UDF_INVOICECUSTOMERNAME());
				externalUservo.setInvPhoneNumber(pOktaUser.getProfile().getUSR_UDF_INVOICEPHONENUMBER());
				externalUservo.setInvPostalCode(pOktaUser.getProfile().getUSR_UDF_INVOICEPOSTCODE());
				externalUservo.setInvShipAddress(pOktaUser.getProfile().getUSR_UDF_INVOICESHIPADDRESS());
				externalUservo.setInvTaxCode(pOktaUser.getProfile().getUSR_UDF_INVOICETAXCODE());
				externalUservo.setRegion(pOktaUser.getProfile().getUSR_STATE());
				externalUservo.setUserStatus(pOktaUser.getStatus());
			}
			externalUservo.setUserId((String)item.getPropertyValue("ID"));
			externalUservo.setLoginName((String)item.getPropertyValue(propertyManager.getLoginPropertyName()));
			externalUservo.setPunchoutMember((String)item.getPropertyValue(propertyManager.getPunchoutMemberPropertyName()));
			externalUservo.setIncludePunchoutShipping(checkBooleanValue(item.getPropertyValue(propertyManager.getIncludePunchoutShippingPropertyName())));
			externalUservo.setIncludePunchoutTaxes(checkBooleanValue(item.getPropertyValue(propertyManager.getIncludePunchoutTaxesPropertyName())));
			externalUservo.setFEDEXUPSCollectNumber((String)item.getPropertyValue(propertyManager.getFedexUpsCollectNumber()));
			externalUservo.setUPSCollectNumber((String)item.getPropertyValue("UPSCollectNumber"));
			externalUservo.setDefaultShippingMethod((String)item.getPropertyValue(propertyManager.getDefaultShippingMethodPropertyName()));
			externalUservo.setDefaultPaymentMethod((String)item.getPropertyValue(propertyManager.getDefaultPaymentMethodPropertyName()));
			externalUservo.setTaxExempted(checkBooleanValue(item.getPropertyValue(propertyManager.getTaxExemptedPropertyName())));
			externalUservo.setTaxExempteNumber((String)item.getPropertyValue(propertyManager.getTaxExemptedNumPropertyName()));
			externalUservo.setTaxExemptCertificatePath((String)item.getPropertyValue(propertyManager.getTaxExemptCertPropertyName()));
			externalUservo.setPlaceOnlineOrders(checkBooleanValue(item.getPropertyValue(propertyManager.getPlaceOnlineOrdersPropertyName())));
			externalUservo.setAccessLibrayOptIn(checkBooleanValue(item.getPropertyValue(propertyManager.getAccessLibrayOptInPropertyName())));
			externalUservo.setDownloadOptIn((String)item.getPropertyValue(propertyManager.getDownloadOptInPropertyName()));
			externalUservo.setScheduleOnlineHWServiceRequestOptIn(checkBooleanValue(item.getPropertyValue(propertyManager.getScheduleOptInPropertyName())));
			externalUservo.setEmailFormat((String)item.getPropertyValue(propertyManager.getEmailFormatPropertyName()));
			externalUservo.setMossDownWhenRegister(checkBooleanValue(item.getPropertyValue(propertyManager.getMossDownWhenRegisterPropertyName())));
			externalUservo.setDefaultSAPShipToAddress((String)item.getPropertyValue(propertyManager.getDefaultSAPShipToAddressPropertyName()));
			externalUservo.setDefaultSAPBillToAddress((String)item.getPropertyValue(propertyManager.getDefaultSAPBillToAddressPropertyName()));
			externalUservo.setShippAddType((String)item.getPropertyValue(propertyManager.getShippAddTypeProppertyName()));
			externalUservo.setPartnerName((String)item.getPropertyValue(propertyManager.getPartnerNamePropertyName()));
			externalUservo.setPartnerIdentifier((String)item.getPropertyValue(propertyManager.getPartnerIdentifierrPropertyName()));
			Date passChngeRqDate=  (Date) item.getPropertyValue(propertyManager.getPassChngReqDatePropertyName());
			externalUservo.setPassChngReqDate(passChngeRqDate != null? passChngeRqDate.toString():null);
			externalUservo.setPreviousPass((String)item.getPropertyValue(propertyManager.getPreviousPassPropertyName()));
			externalUservo.setDirectorAccount(checkBooleanValue(item.getPropertyValue("directorAccount")));
			externalUservo.setDropShipment(checkBooleanValue(item.getPropertyValue(propertyManager.getDropShipmentPropertyName())));
			externalUservo.setShowDutyFreePrice(checkBooleanValue(item.getPropertyValue("showDutyFreePrice")));
			externalUservo.setPayerInvoiceEmail((String)item.getPropertyValue("payerInvoiceEmail"));
			externalUservo.setAddFileUploaded(checkBooleanValue(item.getPropertyValue("isAddFileUploaded")));
			externalUservo.setAdvShpDisable(checkBooleanValue(item.getPropertyValue("advShpDisable")));
			Map<String, RepositoryItem> changeHistory = (Map<String, RepositoryItem>) item.getPropertyValue("changeHistory");
			externalUservo.setChangeHistory(getUserChangeHistory(sortDateMap(changeHistory)));
			externalUservo.setSapDirectorAccount((Boolean)item.getPropertyValue(propertyManager.getSapDirectorAccountPropertyName()));
			externalUservo.setB2bGroupId((String)item.getPropertyValue("groupId"));
			externalUservo.setB2bUser((Boolean)item.getPropertyValue("b2bUser"));
		}else {
			vlogDebug("::: ExternalUserHelper.populateExternalUserVO ::: Profile item is empty");
		}
		vlogDebug("::: Exisiting from ExternalUserHelper.populateExternalUserVO :::");
		return externalUservo;
	}
	
	public String join(Set<String> set, String sep) {
	    String result = null;
	    if(set != null) {
	        StringBuilder sb = new StringBuilder();
	        Iterator<String> it = set.iterator();
	        if(it.hasNext()) {
	            sb.append(it.next());
	        }
	        while(it.hasNext()) {
	            sb.append(sep).append(it.next());
	        }
	        result = sb.toString();
	    }
	    return result;
	}

	/**
	 * To get the List of changes made by business user on the specific user profile
	 * @param changeHistory
	 * @return
	 */
	public List<ChangeHistoryVO> getUserChangeHistory(Map<String, RepositoryItem> changeHistory){
		List<ChangeHistoryVO> userChngHist=new ArrayList<ChangeHistoryVO>();
		 for(Entry<String, RepositoryItem> entry : changeHistory.entrySet()){
			 try {
					if(null != entry.getValue() ){
						ChangeHistoryVO chngHstryVO=new ChangeHistoryVO();
						chngHstryVO.setChangeTime(entry.getKey());
						chngHstryVO.setChangedBy((String)entry.getValue().getPropertyValue("changedBy"));
						@SuppressWarnings("unchecked")
						String changes=chngHstryVO.convertMapvalueToString((Map<String, String>) entry.getValue().getPropertyValue("changePropertyMap"),
								getKeyValueMap(),sAResourceBundle,getInternationalizationService());
						chngHstryVO.setChanges(changes);
						userChngHist.add(chngHstryVO);
					}
			 }
			 catch(Exception e){
				 vlogError("Exception thrown from getUserChangeHistory Method , detail -{0}",e);
			 }
		 }
		
		return userChngHist;
	}
	
	public boolean checkBooleanValue(Object obj){
		Boolean flag=false;
		if(null != obj){
			flag=(Boolean)obj;
		}
		return flag;
	}
	
	@SuppressWarnings("unused")
	public boolean isDataChanged(OktaProfile oktaProfile, String pEmail,OktaUser pOktaUser) {
		vlogDebug("Entering the method: {0} in class: {1}","isDataChanged",getClass().toString());
		if(pOktaUser != null) {
			OktaProfile loktaProfileFromDB =  pOktaUser.getProfile();
			OktaProfile oktaProfileFromBean = oktaProfile;
			if(isModifiedOKTAProperty(loktaProfileFromDB.getFirstName(), oktaProfileFromBean.getFirstName(), "firstName")) {
				vlogInfo("FirstName is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getLastName(), oktaProfileFromBean.getLastName(), "lastName")) {
				vlogInfo("LastName is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_ECOMMERCESTATUS(), oktaProfileFromBean.getUSR_UDF_ECOMMERCESTATUS(), "eCommStatus")) {
				vlogInfo("eCommStatus is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_MEMBERTYPE(), oktaProfileFromBean.getUSR_UDF_MEMBERTYPE(), "membetType")) {
				vlogInfo("membetType is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_SAPSALESORG(), oktaProfileFromBean.getUSR_UDF_SAPSALESORG(), "sapSalesOrg")) {
				vlogInfo("sapSalesOrg is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_COUNTRY(), oktaProfileFromBean.getUSR_COUNTRY(), "userCountry")) {
				vlogInfo("userCountry is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.isUSR_UDF_SAPMASTERACCOUNT(), oktaProfileFromBean.isUSR_UDF_SAPMASTERACCOUNT(), "SAPMasterAccount")) {
				vlogInfo("SAPMasterAccount is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_SAPCUSTOMERID(), oktaProfileFromBean.getUSR_UDF_SAPCUSTOMERID(), "sapCustomerNumber")) {
				vlogInfo("sapCustomerNumber is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_CRMCONTACTNUMBER(), oktaProfileFromBean.getUSR_UDF_CRMCONTACTNUMBER(), "crmContactNumber")) {
				vlogInfo("crmContactNumber is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.isUSR_UDF_TESTACCOUNT(), oktaProfileFromBean.isUSR_UDF_TESTACCOUNT(), "TestAccount")) {
				vlogInfo("TestAccount is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_DEPT_NO(), oktaProfileFromBean.getUSR_DEPT_NO(), "department")) {
				vlogInfo("department is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getTitle(), oktaProfileFromBean.getTitle(), "title")) {
				vlogInfo("title is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getSecondaryECCContact_ID(), oktaProfileFromBean.getSecondaryECCContact_ID(), "secondaryEccId")) {
				vlogInfo("secondaryEccId is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getMultipleSoldTo(), oktaProfileFromBean.getMultipleSoldTo(), "multipleSoldTo")) {
				vlogInfo("multipleSoldTo is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_CUSTOMERNAME(), oktaProfileFromBean.getUSR_UDF_CUSTOMERNAME(), "CUSTOMERNAME")) {
				vlogInfo("CUSTOMERNAME is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICEADDRESS(), oktaProfileFromBean.getUSR_UDF_INVOICEADDRESS(), "INVOICEADDRESS")) {
				vlogInfo("INVOICEADDRESS is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICEBANKACCOUNT(), oktaProfileFromBean.getUSR_UDF_INVOICEBANKACCOUNT(), "INVOICEBANKACCOUNT")) {
				vlogInfo("INVOICEBANKACCOUNT is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICEBANKNAME(), oktaProfileFromBean.getUSR_UDF_INVOICEBANKNAME(), "INVOICEBANKNAME")) {
				vlogInfo("INVOICEBANKNAME is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICECITY(), oktaProfileFromBean.getUSR_UDF_INVOICECITY(), "INVOICECITY")) {
				vlogInfo("INVOICECITY is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICECONTACTPERSON(), oktaProfileFromBean.getUSR_UDF_INVOICECONTACTPERSON(), "INVOICECONTACTPERSON")) {
				vlogInfo("INVOICECONTACTPERSON is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICECUSTOMERNAME(), oktaProfileFromBean.getUSR_UDF_INVOICECUSTOMERNAME(), "INVOICECUSTOMERNAME")) {
				vlogInfo("INVOICECUSTOMERNAME is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICEPHONENUMBER(), oktaProfileFromBean.getUSR_UDF_INVOICEPHONENUMBER(), "INVOICEPHONENUMBER")) {
				vlogInfo("INVOICEPHONENUMBER is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICEPOSTCODE(), oktaProfileFromBean.getUSR_UDF_INVOICEPOSTCODE(), "INVOICEPOSTCODE")) {
				vlogInfo("INVOICEPOSTCODE is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICESHIPADDRESS(), oktaProfileFromBean.getUSR_UDF_INVOICESHIPADDRESS(), "INVOICESHIPADDRESS")) {
				vlogInfo("INVOICESHIPADDRESS is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_UDF_INVOICETAXCODE(), oktaProfileFromBean.getUSR_UDF_INVOICETAXCODE(), "INVOICETAXCODE")) {
				vlogInfo("INVOICETAXCODE is modified and hence invoking Okta Update call");
				return true;
			}else if(isModifiedOKTAProperty(loktaProfileFromDB.getUSR_STATE(), oktaProfileFromBean.getUSR_STATE(), "USR_STATE")) {
				vlogInfo("USR_STATE is modified and hence invoking Okta Update call");
				return true;
			}
		}
		vlogDebug("Existing the method: {0} in class: {1}","isDataChanged",getClass().toString());
		return false;
	}
	
	@SuppressWarnings("unused")
	public boolean isModifiedOKTAProperty(Object pOldpropValue,Object pNewpropValue,String pPropertyName){
		vlogDebug("Entering the method: {0} in class: {1}","isModifiedOKTAProperty",getClass().toString());
		boolean modified=false;
		if(pOldpropValue == null && pNewpropValue == null){
			return false;
		}
		else if(pNewpropValue instanceof Boolean){
			Boolean oldValue = checkBooleanValue(pOldpropValue);
			Boolean newValue = checkBooleanValue(pNewpropValue);
			if(oldValue == null && newValue != null){
				return true;
			}else{
				return oldValue.equals(newValue) ? false :true;
			}
		}
		else if(pNewpropValue instanceof String){
			String oldValue=(String) pOldpropValue;
			String newValue=(String) pNewpropValue;
			if(StringUtils.isBlank(oldValue) && !StringUtils.isBlank(newValue)){
				return true;
			}else if(StringUtils.isBlank(oldValue) && StringUtils.isBlank(newValue)){
				return false;
			}else{
				return oldValue.equals(newValue)?false :true;
			}
		}
		else if(pNewpropValue instanceof Double){
			Double oldValue=(Double) pOldpropValue;
			Double newValue=(Double) pNewpropValue;
			if(oldValue ==null && newValue !=null){
				return true;
			}else{
				return oldValue.equals(newValue) ? false :true;
			}
		}
		else if(pNewpropValue instanceof Integer){
			Integer oldValue=(Integer) pOldpropValue;
			Integer newValue=(Integer) pNewpropValue;
			if(oldValue ==null && newValue !=null){
				return true;
			}else{
				return oldValue.equals(newValue) ? false :true;
			}
		}else if(pNewpropValue instanceof List){
			List oldValue=(List) pOldpropValue;
			List newValue=(List) pNewpropValue;
			if((oldValue == null && newValue != null) || oldValue != null && newValue == null || oldValue.size() != newValue.size()){
				return true;
			}else {
			    return oldValue.equals(newValue) ? false :true;
			}
		}
		else{
			vlogInfo("Datatype of this property= {0} is not handled, old value is {1} and new value is {2}" , pPropertyName,pOldpropValue,pNewpropValue);
			vlogDebug("Existing the method: {0} in class: {1}","isDataChanged",getClass().toString());
			return modified;
		}
		
	}
	
	public Repository getProfileRepository() {
		return profileRepository;
	}


	public void setProfileRepository(Repository profileRepository) {
		this.profileRepository = profileRepository;
	}

	public AgilentProfileTools getProfileTools() {
		return profileTools;
	}

	public void setProfileTools(AgilentProfileTools profileTools) {
		this.profileTools = profileTools;
	}


	public Profile getProfile() {
		return profile;
	}


	public void setProfile(Profile profile) {
		this.profile = profile;
	}


	public TransactionManager getTransactionManager() {
		return transactionManager;
	}


	public void setTransactionManager(TransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}



	/**
	 * @return the internationalizationService
	 */
	public InternationalizationService getInternationalizationService() {
		return internationalizationService;
	}



	/**
	 * @param internationalizationService the internationalizationService to set
	 */
	public void setInternationalizationService(InternationalizationService internationalizationService) {
		this.internationalizationService = internationalizationService;
	}



	/**
	 * @return the keyValueMap
	 */
	public Map<String, String> getKeyValueMap() {
		return keyValueMap;
	}



	/**
	 * @param keyValueMap the keyValueMap to set
	 */
	public void setKeyValueMap(Map<String, String> keyValueMap) {
		this.keyValueMap = keyValueMap;
	}



	/**
	 * @return the enableAudit
	 */
	public boolean isEnableAudit() {
		return enableAudit;
	}



	/**
	 * @param enableAudit the enableAudit to set
	 */
	public void setEnableAudit(boolean enableAudit) {
		this.enableAudit = enableAudit;
	}
	
	
}
