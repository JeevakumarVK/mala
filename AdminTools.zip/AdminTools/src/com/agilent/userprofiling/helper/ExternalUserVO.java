package com.agilent.userprofiling.helper;

import java.util.List;

public class ExternalUserVO {
	
	private String userId;
	private String loginName;
	private String Email;
	private String adLoginName;
	private String eCommStatus;
	private String SAPContactNumber;
	private String sapSalesOrg;
	private String MemberType;
	private String userCountry;
	private boolean sapMasterAcount;
	private String punchoutMember;
	private boolean includePunchoutShipping;
	private boolean includePunchoutTaxes;
	private String FEDEXUPSCollectNumber;
	private String UPSCollectNumber;
	private String  defaultShippingMethod;
	private String defaultPaymentMethod;
	private boolean taxExempted;
	private String taxExempteNumber;
	private String taxExemptCertificatePath;
	private boolean placeOnlineOrders;
	private boolean accessLibrayOptIn;
	private boolean newsOptIn;
	private String downloadOptIn;
	private boolean scheduleOnlineHWServiceRequestOptIn;
	private String emailFormat;
	private boolean isMossDownWhenRegister;
	private String defaultSAPShipToAddress;
	private String defaultSAPBillToAddress;
	private String shippAddType;
	private String passChngReqDate;
	private boolean testAccount;
	private String previousPass;
	private boolean directorAccount;
	private boolean dropShipment;
	private boolean showDutyFreePrice;
	private String payerInvoiceEmail;
	private boolean addFileUploaded;
	private boolean advShpDisable;
	private List<ChangeHistoryVO> changeHistory;
	private String userStatus;
	
	//Jaguar changes- start
	private String partnerName;
	private String partnerIdentifier;
   //Jaguar changes- End	
		
	/*changeHistory (Map type)
	areaOfInterests (List type)
	preferredLanguages(Set type)
	clickDate (Set type)
	savedConfiguration*/
	
	private String firstName;
	private String lastName;
	private String region;
	private Boolean sapDirectorAccount;
	private String b2bGroupId;
	private String telephoneNumber;
	private String invShipCustomerName;
	private String invAddress;
	private String invBankAccount;
	private String invBankName;
	private String invCity;
	private String invContactPerson;
	private String invCustomerName;
	private String invPhoneNumber;
	private String invPostalCode;
	private String invShipAddress;
	private String invTaxCode;
	private Boolean b2bUser;
	private String department;
	private String title;
	private String crmContactId;
	private String[] secondaryEccId;
	private String[] multipleSoldTo;
	
	
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @return the region
	 */
	public String getRegion() {
		return region;
	}
	/**
	 * @return the sapDirectorAccount
	 */
	public Boolean getSapDirectorAccount() {
		return sapDirectorAccount;
	}
	/**
	 * @return the b2bGroupId
	 */
	public String getB2bGroupId() {
		return b2bGroupId;
	}
	/**
	 * @return the telephoneNumber
	 */
	public String getTelephoneNumber() {
		return telephoneNumber;
	}
	/**
	 * @return the invShipCustomerName
	 */
	public String getInvShipCustomerName() {
		return invShipCustomerName;
	}
	/**
	 * @return the invAddress
	 */
	public String getInvAddress() {
		return invAddress;
	}
	/**
	 * @return the invBankAccount
	 */
	public String getInvBankAccount() {
		return invBankAccount;
	}
	/**
	 * @return the invBankName
	 */
	public String getInvBankName() {
		return invBankName;
	}
	/**
	 * @return the invCity
	 */
	public String getInvCity() {
		return invCity;
	}
	/**
	 * @return the invContactPerson
	 */
	public String getInvContactPerson() {
		return invContactPerson;
	}
	/**
	 * @return the invCustomerName
	 */
	public String getInvCustomerName() {
		return invCustomerName;
	}
	/**
	 * @return the invPhoneNumber
	 */
	public String getInvPhoneNumber() {
		return invPhoneNumber;
	}
	/**
	 * @return the invPostalCode
	 */
	public String getInvPostalCode() {
		return invPostalCode;
	}
	/**
	 * @return the invShipAddress
	 */
	public String getInvShipAddress() {
		return invShipAddress;
	}
	/**
	 * @return the invTaxCode
	 */
	public String getInvTaxCode() {
		return invTaxCode;
	}
	/**
	 * @return the b2bUser
	 */
	public Boolean getB2bUser() {
		return b2bUser;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @param region the region to set
	 */
	public void setRegion(String region) {
		this.region = region;
	}
	/**
	 * @param sapDirectorAccount the sapDirectorAccount to set
	 */
	public void setSapDirectorAccount(Boolean sapDirectorAccount) {
		this.sapDirectorAccount = sapDirectorAccount;
	}
	/**
	 * @param b2bGroupId the b2bGroupId to set
	 */
	public void setB2bGroupId(String b2bGroupId) {
		this.b2bGroupId = b2bGroupId;
	}
	/**
	 * @param telephoneNumber the telephoneNumber to set
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	/**
	 * @param invShipCustomerName the invShipCustomerName to set
	 */
	public void setInvShipCustomerName(String invShipCustomerName) {
		this.invShipCustomerName = invShipCustomerName;
	}
	/**
	 * @param invAddress the invAddress to set
	 */
	public void setInvAddress(String invAddress) {
		this.invAddress = invAddress;
	}
	/**
	 * @param invBankAccount the invBankAccount to set
	 */
	public void setInvBankAccount(String invBankAccount) {
		this.invBankAccount = invBankAccount;
	}
	/**
	 * @param invBankName the invBankName to set
	 */
	public void setInvBankName(String invBankName) {
		this.invBankName = invBankName;
	}
	/**
	 * @param invCity the invCity to set
	 */
	public void setInvCity(String invCity) {
		this.invCity = invCity;
	}
	/**
	 * @param invContactPerson the invContactPerson to set
	 */
	public void setInvContactPerson(String invContactPerson) {
		this.invContactPerson = invContactPerson;
	}
	/**
	 * @param invCustomerName the invCustomerName to set
	 */
	public void setInvCustomerName(String invCustomerName) {
		this.invCustomerName = invCustomerName;
	}
	/**
	 * @param invPhoneNumber the invPhoneNumber to set
	 */
	public void setInvPhoneNumber(String invPhoneNumber) {
		this.invPhoneNumber = invPhoneNumber;
	}
	/**
	 * @param invPostalCode the invPostalCode to set
	 */
	public void setInvPostalCode(String invPostalCode) {
		this.invPostalCode = invPostalCode;
	}
	/**
	 * @param invShipAddress the invShipAddress to set
	 */
	public void setInvShipAddress(String invShipAddress) {
		this.invShipAddress = invShipAddress;
	}
	/**
	 * @param invTaxCode the invTaxCode to set
	 */
	public void setInvTaxCode(String invTaxCode) {
		this.invTaxCode = invTaxCode;
	}
	/**
	 * @param b2bUser the b2bUser to set
	 */
	public void setB2bUser(Boolean b2bUser) {
		this.b2bUser = b2bUser;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	public String getLoginName() {
		return loginName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAdLoginName() {
		return adLoginName;
	}
	public void setAdLoginName(String adLoginName) {
		this.adLoginName = adLoginName;
	}
	public String geteCommStatus() {
		return eCommStatus;
	}
	public void seteCommStatus(String eCommStatus) {
		this.eCommStatus = eCommStatus;
	}
	public String getSAPContactNumber() {
		return SAPContactNumber;
	}
	public void setSAPContactNumber(String sAPContactNumber) {
		SAPContactNumber = sAPContactNumber;
	}
	public String getSapSalesOrg() {
		return sapSalesOrg;
	}
	public void setSapSalesOrg(String sapSalesOrg) {
		this.sapSalesOrg = sapSalesOrg;
	}
	public String getMemberType() {
		return MemberType;
	}
	public void setMemberType(String memberType) {
		MemberType = memberType;
	}
	public String getUserCountry() {
		return userCountry;
	}
	public void setUserCountry(String userCountry) {
		this.userCountry = userCountry;
	}
	public boolean isSapMasterAcount() {
		return sapMasterAcount;
	}
	public void setSapMasterAcount(boolean sapMasterAcount) {
		this.sapMasterAcount = sapMasterAcount;
	}
	public String getPunchoutMember() {
		return punchoutMember;
	}
	public void setPunchoutMember(String punchoutMember) {
		this.punchoutMember = punchoutMember;
	}
	public boolean isIncludePunchoutShipping() {
		return includePunchoutShipping;
	}
	public void setIncludePunchoutShipping(boolean includePunchoutShipping) {
		this.includePunchoutShipping = includePunchoutShipping;
	}
	public boolean isIncludePunchoutTaxes() {
		return includePunchoutTaxes;
	}
	public void setIncludePunchoutTaxes(boolean includePunchoutTaxes) {
		this.includePunchoutTaxes = includePunchoutTaxes;
	}
	public String getFEDEXUPSCollectNumber() {
		return FEDEXUPSCollectNumber;
	}
	public void setFEDEXUPSCollectNumber(String fEDEXUPSCollectNumber) {
		FEDEXUPSCollectNumber = fEDEXUPSCollectNumber;
	}
	public String getUPSCollectNumber() {
		return UPSCollectNumber;
	}
	public void setUPSCollectNumber(String uPSCollectNumber) {
		UPSCollectNumber = uPSCollectNumber;
	}
	public String getDefaultShippingMethod() {
		return defaultShippingMethod;
	}
	public void setDefaultShippingMethod(String defaultShippingMethod) {
		this.defaultShippingMethod = defaultShippingMethod;
	}
	public String getDefaultPaymentMethod() {
		return defaultPaymentMethod;
	}
	public void setDefaultPaymentMethod(String defaultPaymentMethod) {
		this.defaultPaymentMethod = defaultPaymentMethod;
	}
	public boolean isTaxExempted() {
		return taxExempted;
	}
	public void setTaxExempted(boolean taxExempted) {
		this.taxExempted = taxExempted;
	}
	public String getTaxExempteNumber() {
		return taxExempteNumber;
	}
	public void setTaxExempteNumber(String taxExempteNumber) {
		this.taxExempteNumber = taxExempteNumber;
	}
	public String getTaxExemptCertificatePath() {
		return taxExemptCertificatePath;
	}
	public void setTaxExemptCertificatePath(String taxExemptCertificatePath) {
		this.taxExemptCertificatePath = taxExemptCertificatePath;
	}
	public boolean isPlaceOnlineOrders() {
		return placeOnlineOrders;
	}
	public void setPlaceOnlineOrders(boolean placeOnlineOrders) {
		this.placeOnlineOrders = placeOnlineOrders;
	}
	public boolean isAccessLibrayOptIn() {
		return accessLibrayOptIn;
	}
	public void setAccessLibrayOptIn(boolean accessLibrayOptIn) {
		this.accessLibrayOptIn = accessLibrayOptIn;
	}
	public boolean isNewsOptIn() {
		return newsOptIn;
	}
	public void setNewsOptIn(boolean newsOptIn) {
		this.newsOptIn = newsOptIn;
	}
	
	public String getDownloadOptIn() {
		return downloadOptIn;
	}
	public void setDownloadOptIn(String downloadOptIn) {
		this.downloadOptIn = downloadOptIn;
	}
	public boolean getScheduleOnlineHWServiceRequestOptIn() {
		return scheduleOnlineHWServiceRequestOptIn;
	}
	public void setScheduleOnlineHWServiceRequestOptIn(
			boolean scheduleOnlineHWServiceRequestOptIn) {
		this.scheduleOnlineHWServiceRequestOptIn = scheduleOnlineHWServiceRequestOptIn;
	}
	public String getEmailFormat() {
		return emailFormat;
	}
	public void setEmailFormat(String emailFormat) {
		this.emailFormat = emailFormat;
	}
	public boolean isMossDownWhenRegister() {
		return isMossDownWhenRegister;
	}
	public void setMossDownWhenRegister(boolean isMossDownWhenRegister) {
		this.isMossDownWhenRegister = isMossDownWhenRegister;
	}
	public String getDefaultSAPShipToAddress() {
		return defaultSAPShipToAddress;
	}
	public void setDefaultSAPShipToAddress(String defaultSAPShipToAddress) {
		this.defaultSAPShipToAddress = defaultSAPShipToAddress;
	}
	public String getDefaultSAPBillToAddress() {
		return defaultSAPBillToAddress;
	}
	public void setDefaultSAPBillToAddress(String defaultSAPBillToAddress) {
		this.defaultSAPBillToAddress = defaultSAPBillToAddress;
	}
	public String getShippAddType() {
		return shippAddType;
	}
	public void setShippAddType(String shippAddType) {
		this.shippAddType = shippAddType;
	}
	public String getPassChngReqDate() {
		return passChngReqDate;
	}
	public void setPassChngReqDate(String passChngReqDate) {
		this.passChngReqDate = passChngReqDate;
	}
	public boolean isTestAccount() {
		return testAccount;
	}
	public void setTestAccount(boolean testAccount) {
		this.testAccount = testAccount;
	}
	public String getPreviousPass() {
		return previousPass;
	}
	public void setPreviousPass(String previousPass) {
		this.previousPass = previousPass;
	}
	public boolean isDirectorAccount() {
		return directorAccount;
	}
	public void setDirectorAccount(boolean directorAccount) {
		this.directorAccount = directorAccount;
	}
	public boolean isDropShipment() {
		return dropShipment;
	}
	public void setDropShipment(boolean dropShipment) {
		this.dropShipment = dropShipment;
	}
	public boolean isShowDutyFreePrice() {
		return showDutyFreePrice;
	}
	public void setShowDutyFreePrice(boolean showDutyFreePrice) {
		this.showDutyFreePrice = showDutyFreePrice;
	}
	public String getPayerInvoiceEmail() {
		return payerInvoiceEmail;
	}
	public void setPayerInvoiceEmail(String payerInvoiceEmail) {
		this.payerInvoiceEmail = payerInvoiceEmail;
	}
	public boolean isAddFileUploaded() {
		return addFileUploaded;
	}
	public void setAddFileUploaded(boolean addFileUploaded) {
		this.addFileUploaded = addFileUploaded;
	}
	public boolean isAdvShpDisable() {
		return advShpDisable;
	}
	public void setAdvShpDisable(boolean advShpDisable) {
		this.advShpDisable = advShpDisable;
	}
			
	public List<ChangeHistoryVO> getChangeHistory() {
		return changeHistory;
	}
	public void setChangeHistory(List<ChangeHistoryVO> changeHistory) {
		this.changeHistory = changeHistory;
	}
	/**
	 * @return the partnerName
	 */
	public String getPartnerName() {
		return partnerName;
	}
	/**
	 * @param partnerName the partnerName to set
	 */
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	/**
	 * @return the partnerIdentifier
	 */
	public String getPartnerIdentifier() {
		return partnerIdentifier;
	}
	/**
	 * @param partnerIdentifier the partnerIdentifier to set
	 */
	public void setPartnerIdentifier(String partnerIdentifier) {
		this.partnerIdentifier = partnerIdentifier;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ExternalUserVO [userId=" + userId + ", loginName=" + loginName
				+ ", Email=" + Email + ", adLoginName=" + adLoginName
				+ ", eCommStatus=" + eCommStatus + ", SAPContactNumber="
				+ SAPContactNumber + ", sapSalesOrg=" + sapSalesOrg
				+ ", MemberType=" + MemberType + ", userCountry=" + userCountry
				+ ", sapMasterAcount=" + sapMasterAcount + ", punchoutMember="
				+ punchoutMember + ", includePunchoutShipping="
				+ includePunchoutShipping + ", includePunchoutTaxes="
				+ includePunchoutTaxes + ", FEDEXUPSCollectNumber="
				+ FEDEXUPSCollectNumber + ", UPSCollectNumber="
				+ UPSCollectNumber + ", defaultShippingMethod="
				+ defaultShippingMethod + ", defaultPaymentMethod="
				+ defaultPaymentMethod + ", taxExempted=" + taxExempted
				+ ", taxExempteNumber=" + taxExempteNumber
				+ ", taxExemptCertificatePath=" + taxExemptCertificatePath
				+ ", placeOnlineOrders=" + placeOnlineOrders
				+ ", accessLibrayOptIn=" + accessLibrayOptIn + ", newsOptIn="
				+ newsOptIn + ", downloadOptIn=" + downloadOptIn
				+ ", scheduleOnlineHWServiceRequestOptIn="
				+ scheduleOnlineHWServiceRequestOptIn + ", emailFormat="
				+ emailFormat + ", isMossDownWhenRegister="
				+ isMossDownWhenRegister + ", defaultSAPShipToAddress="
				+ defaultSAPShipToAddress + ", defaultSAPBillToAddress="
				+ defaultSAPBillToAddress + ", shippAddType=" + shippAddType
				+ ", passChngReqDate=" + passChngReqDate + ", testAccount="
				+ testAccount + ", previousPass=" + previousPass
				+ ", directorAccount=" + directorAccount + ", dropShipment="
				+ dropShipment + ", showDutyFreePrice=" + showDutyFreePrice
				+ ", payerInvoiceEmail=" + payerInvoiceEmail
				+ ", addFileUploaded=" + addFileUploaded + ", advShpDisable="
				+ advShpDisable + ", changeHistory=" + changeHistory
				+ ", userStatus=" + userStatus + ", partnerName=" + partnerName  + ", partnerIdentifier="
				+ partnerIdentifier + "]";
	}
	/**
	 * @return the crmContactId
	 */
	public String getCrmContactId() {
		return crmContactId;
	}
	/**
	 * @param crmContactId the crmContactId to set
	 */
	public void setCrmContactId(String crmContactId) {
		this.crmContactId = crmContactId;
	}
	/**
	 * @return the secondaryEccId
	 */
	public String[] getSecondaryEccId() {
		return secondaryEccId;
	}
	/**
	 * @param secondaryEccId the secondaryEccId to set
	 */
	public void setSecondaryEccId(String[] secondaryEccId) {
		this.secondaryEccId = secondaryEccId;
	}
	/**
	 * @return the multipleSoldTo
	 */
	public String[] getMultipleSoldTo() {
		return multipleSoldTo;
	}
	/**
	 * @param multipleSoldTo the multipleSoldTo to set
	 */
	public void setMultipleSoldTo(String[] multipleSoldTo) {
		this.multipleSoldTo = multipleSoldTo;
	}
	/**
	 * @return the userStatus
	 */
	public String getUserStatus() {
		return userStatus;
	}
	/**
	 * @param userStatus the userStatus to set
	 */
	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}
	
	
}
