--- Alter the Price tables ---
-- Pub Schema
ALTER TABLE dcs_price_feed ADD (effectiveprice NUMBER(38,20), price_list VARCHAR2(40 BYTE));
ALTER TABLE dcs_price_feed MODIFY LISTPRICE NUMBER(38,20);
ALTER TABLE sapdata ADD price_list VARCHAR2(40 BYTE);
CREATE INDEX SAPDATA_IDX ON SAPDATA (PRICE_LIST);

-- Create SEQUENCE if not Exist -----
-- Pub Schema
CREATE SEQUENCE MY_NUMBER_SN MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 83198144 CACHE 20 NOORDER  NOCYCLE;

--- Create Database Link ---
--- Create database link by replacing the username,password and hostname---
--- run on cat A schema ans Cat B Schema
CREATE PUBLIC DATABASE LINK pub_link CONNECT TO username IDENTIFIED BY  password 
USING '(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = gcosfdb.cos.agilent.com)(QUEUESIZE = 20)(PORT = 1521))
(CONNECT_DATA =(SERVICE_NAME = GCOSU_PU)))';


--- Alter Feeder tables ---
-- Pub Schema
ALTER TABLE dcs_product_feed  DROP COLUMN DESCRIPTION;
ALTER TABLE dcs_product_feed ADD  DESCRIPTION varchar2(2000);

ALTER TABLE dcs_product_feed  DROP COLUMN LONG_DESCRIPTION;
ALTER TABLE dcs_product_feed ADD LONG_DESCRIPTION varchar2(4000);

ALTER TABLE AGILENT_PRD_XLATE_feed  DROP COLUMN LONG_DESCRIPTION;
ALTER TABLE AGILENT_PRD_XLATE_feed ADD  LONG_DESCRIPTION varchar2(4000);

ALTER TABLE dcs_category_feed  DROP COLUMN LONG_DESCRIPTION;
ALTER TABLE dcs_category_feed ADD  LONG_DESCRIPTION varchar2(4000);

ALTER TABLE AGILENT_cat_XLATE_feed  DROP COLUMN DESCRIPTION;
ALTER TABLE AGILENT_cat_XLATE_feed ADD  DESCRIPTION varchar2(2000);

ALTER TABLE AGILENT_cat_XLATE_feed  DROP COLUMN LONG_DESCRIPTION;
ALTER TABLE AGILENT_cat_XLATE_feed ADD  LONG_DESCRIPTION varchar2(4000);

--- Price Procedure ---

--MERGE_PRICE_PROCEDURE_PUB --
--we must run on Publishing Schema

create or replace PROCEDURE MERGE_PRICE_PROCEDURE_PUB (workspaceId IN dcs_price.workspace_id%type) AS
BEGIN
	MERGE INTO dcs_price target
	USING (
	   SELECT sd.MATERIALNUMBER,sd.COUNTRY,sd.SALESORG,sd.LISTPRICE,sd.PRICE_LIST from sapdata sd 
      where (sd.ISMODIFIED='Y' or sd.isnew='Y') and price_list is not null
	) src
	ON (target.PRICE_LIST = src.PRICE_LIST and  target.SKU_ID = 'ag-sku-'||src.MATERIALNUMBER) 
	WHEN MATCHED THEN
			update set target.LIST_PRICE = src.LISTPRICE, target.is_head=1, target.ASSET_VERSION=1
	WHEN NOT MATCHED THEN
			insert (PRICE_ID,VERSION,PRICE_LIST,SKU_ID,PRICING_SCHEME,LIST_PRICE,ASSET_VERSION,IS_HEAD,workspace_id,branch_id,version_deleted,version_editable,CHECKIN_DATE)
			values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.COUNTRY,1,src.PRICE_LIST,'ag-sku-'||src.MATERIALNUMBER,0,src.LISTPRICE,1,1,workspaceId,'10100',0,0,sysdate);

	MERGE INTO agilent_price TARGET
	USING (
	  SELECT dp.PRICE_ID,sd.MATERIALNUMBER,sd.COUNTRY,sd.SALESORG,sd.LISTPRICE,
	  sd.EFFECTIVEPRICE,to_char(sd.EFFECTIVEDATE,'dd-MON-yy') EFFECTIVEDATE
	  from sapdata sd JOIN dcs_price DP
	  ON sd.PRICE_LIST=dp.PRICE_LIST AND ('ag-sku-'||sd.MATERIALNUMBER)=dp.SKU_ID
	  where (sd.ISMODIFIED='Y' or sd.isnew='Y')
	) src
	ON (target.PRICE_ID = src.PRICE_ID)
	WHEN MATCHED THEN
			 update set target.EFFECTIVE_PRICE = src.EFFECTIVEPRICE,target.EFFECTIVE_DATE = to_date(src.EFFECTIVEDATE,'dd-MON-yy'), target.ASSET_VERSION=1
	WHEN NOT MATCHED THEN
			insert (PRICE_ID,EFFECTIVE_PRICE,EFFECTIVE_DATE,ASSET_VERSION)
			values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.COUNTRY,src.EFFECTIVEPRICE,to_date(src.EFFECTIVEDATE,'dd-MON-yy'),1);
				
   commit;
END MERGE_PRICE_PROCEDURE_PUB;

---MERGE_PRICE_PROCEDURE_CAT_A 
-- we must run on Catalog A Schema
create or replace PROCEDURE MERGE_PRICE_PROCEDURE_CAT_A AS
BEGIN       
MERGE INTO dcs_price target
USING (
    select MATERIALNUMBER, PRICE_LIST, COUNTRY,CURRENCY,
		  INCOTERM, LISTPRICE, to_char(EFFECTIVEDATE,'dd-MON-yy') EFFECTIVEDATE,SALESORG,
		  EFFECTIVEPRICE,ID from sapdata@pub_link
		where (ISMODIFIED='Y' or isnew='Y') and price_list is not null) src
ON (target.PRICE_LIST = src.PRICE_LIST and  target.SKU_ID = 'ag-sku-'||src.MATERIALNUMBER)
WHEN MATCHED THEN
  update set
            target.LIST_PRICE = src.LISTPRICE
WHEN NOT MATCHED THEN
  insert (PRICE_ID,VERSION,PRICE_LIST,SKU_ID,PRICING_SCHEME,LIST_PRICE)
          values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.
          COUNTRY,1,src.PRICE_LIST,'ag-sku-'||src.MATERIALNUMBER,0,src.LISTPRICE);

MERGE INTO agilent_price target
USING (
  SELECT dp.PRICE_ID,sd.MATERIALNUMBER,sd.COUNTRY,sd.SALESORG,sd.LISTPRICE,sd.EFFECTIVEPRICE,to_char(sd.EFFECTIVEDATE,'dd-MON-yy') EFFECTIVEDATE
  from sapdata@pub_link sd
  JOIN dcs_price dp
  ON sd.PRICE_LIST=dp.PRICE_LIST AND ('ag-sku-'||sd.MATERIALNUMBER)=dp.SKU_ID
  where (sd.ISMODIFIED='Y' or sd.isnew='Y')) src
ON (target.PRICE_ID = src.PRICE_ID)
WHEN MATCHED THEN
          update set
            target.EFFECTIVE_PRICE = src.EFFECTIVEPRICE,
            target.EFFECTIVE_DATE = to_date(src.EFFECTIVEDATE,'dd-MON-yy')
WHEN NOT MATCHED THEN
          insert (PRICE_ID,EFFECTIVE_PRICE,EFFECTIVE_DATE)
          values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.COUNTRY,src.EFFECTIVEPRICE,
          to_date(src.EFFECTIVEDATE,'dd-MON-yy')); 
		  
 commit;
END MERGE_PRICE_PROCEDURE_CAT_A;

---MERGE_PRICE_PROCEDURE_CAT_B 
-- we must run on Catalog B Schema

create or replace PROCEDURE MERGE_PRICE_PROCEDURE_CAT_B AS
BEGIN
	MERGE INTO dcs_price target
	USING (
	  select MATERIALNUMBER, PRICE_LIST, COUNTRY,CURRENCY,
		  INCOTERM, LISTPRICE, to_char(EFFECTIVEDATE,'dd-MON-yy') EFFECTIVEDATE,SALESORG,
		  EFFECTIVEPRICE,ID from sapdata@pub_link
		where (ISMODIFIED='Y' or isnew='Y') and price_list is not null) src
	ON (target.PRICE_LIST = src.PRICE_LIST and  target.SKU_ID = 'ag-sku-'||src.MATERIALNUMBER)
	WHEN MATCHED THEN
	  update set
				target.LIST_PRICE = src.LISTPRICE
	WHEN NOT MATCHED THEN
	  insert (PRICE_ID,VERSION,PRICE_LIST,SKU_ID,PRICING_SCHEME,LIST_PRICE)
			  values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.
			  COUNTRY,1,src.PRICE_LIST,'ag-sku-'||src.MATERIALNUMBER,0,src.LISTPRICE);
			    
	MERGE INTO agilent_price target
	USING (
	  SELECT dp.PRICE_ID,sd.MATERIALNUMBER,sd.COUNTRY,sd.SALESORG,sd.LISTPRICE,sd.EFFECTIVEPRICE,to_char(sd.EFFECTIVEDATE,'dd-MON-yy') EFFECTIVEDATE
	  from sapdata@pub_link sd
	  JOIN dcs_price dp
	  ON sd.PRICE_LIST=dp.PRICE_LIST AND ('ag-sku-'||sd.MATERIALNUMBER)=dp.SKU_ID
	  where (sd.ISMODIFIED='Y' or sd.isnew='Y')) src
	ON (target.PRICE_ID = src.PRICE_ID)
	WHEN MATCHED THEN
			  update set
				target.EFFECTIVE_PRICE = src.EFFECTIVEPRICE,
				target.EFFECTIVE_DATE = to_date(src.EFFECTIVEDATE,'dd-MON-yy')
	WHEN NOT MATCHED THEN
			  insert (PRICE_ID,EFFECTIVE_PRICE,EFFECTIVE_DATE)
			  values('p'||'ag-sku-'||src.MATERIALNUMBER||'-'||src.SALESORG||'-'||src.COUNTRY,src.EFFECTIVEPRICE,
			  to_date(src.EFFECTIVEDATE,'dd-MON-yy'));
 commit;
END MERGE_PRICE_PROCEDURE_CAT_B;


-- Run this on all three schema Pub,CatA and CatB--
truncate table agilent_meta_keywords;
truncate table dcs_prd_keywrds;
truncate table agilent_search_keywords;
truncate table agilent_prd_xlate_kwr;
truncate table agilent_prd_xlate_metakwr;
