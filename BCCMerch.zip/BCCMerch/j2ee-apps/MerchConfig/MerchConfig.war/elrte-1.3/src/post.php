<?php
set_magic_quotes_runtime(0);

if (isset($_GET['debug'])) {
    foreach($_POST as $key=>&$val){
        $val= htmlspecialchars($val);
    }
    print_r($_POST);
} else {
    echo stripslashes(htmlspecialchars ($_POST['editor']));
}
	