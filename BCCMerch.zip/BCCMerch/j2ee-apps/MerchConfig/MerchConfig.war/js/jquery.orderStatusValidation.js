function checkEmptyField() {

	var sapOrderId = document.getElementById('sapOrderId');
	var orderProcessedBy = document.getElementById('orderProcessedBy');
	
	if ((sapOrderId.value == "") && (orderProcessedBy.value == "")){
		alert("Required field: SAP Sales Order and Processed By");
			return false;
	}
	else if ((sapOrderId.value != "") && (orderProcessedBy.value == "")) {
		alert("Required field: Processed By");
		return false;
}
	else if ((sapOrderId.value == "") && (orderProcessedBy.value != "")) {
		alert("Required field: SAP Sales Order");
		return false;
}
}