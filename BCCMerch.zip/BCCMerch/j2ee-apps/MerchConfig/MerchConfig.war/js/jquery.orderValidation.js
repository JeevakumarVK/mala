function checkEmptyField() {

	var myFromDate = document.getElementById('from-date');
	var myToDate = document.getElementById('to-date');
	var orderId = document.getElementById('webOrdId');
	var salesOrg = document.getElementById('sales-org');

	if ((myFromDate.value == "") && (myToDate.value == "")
			&& (orderId.value == "") && (salesOrg.value == "")) {
		alert("Required field: From date, To date and Sales Org or Web Order Id");
		return false;
	} 
	if ((myFromDate.value != "") && (myToDate.value == "")) {
		alert("Required field: To date");
		return false;
	} else if ((myFromDate.value == "") && (myToDate.value != "")) {
		alert("Required field: From date");
		return false;
	} else if ((myFromDate.value != "") && (myToDate.value != "")
			&& (orderId.value == "")) {
		return true;
	}
	else if ((myFromDate.value != "") && (myToDate.value != "")
			&& (orderId.value == "") && (salesOrg.value != "")) {
		return true;
	}
	if ((myFromDate.value == "") && (myToDate.value == "")
			&& (orderId.value != "")(salesOrg.value == "")) {
		return true;
	}
	else if ((myFromDate.value == "") && (myToDate.value == "")
			&& (orderId.value == "")(salesOrg.value != "")) {
		return true;
	}
	else if ((orderId.value == "")) {
		alert("Required field: Web Order Id");
		return false;
	} 
}