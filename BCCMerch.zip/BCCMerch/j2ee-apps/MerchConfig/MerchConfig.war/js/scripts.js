// JavaScript Document
/*@written by : Abhijeet Kumar */
var jq = jQuery.noConflict();

jq(document).ready(function(){
	
	jq("#country,#cntry,#bPayMethod,#language,#unit,#unit2,#dakoCountry,#prdGrp,#aff,#countryArea,#ssdCntry,#manual,#taxECert,#language").uniform();

	jq("#site1,#site2,#site3,#site4,#site5,#site6,#site7,#site8,#site9,#site10,#site11,#site12,#site13,#site14").uniform();
	
	// Set starting slide to 1
	var startSlide = 1;
	// Get slide number if it exists
	if (window.location.hash) {
		//startSlide = window.location.hash.replace('#','');
	}
	// Initialize Slides
	jq('#slides').slides({
		preload: true,
		preloadImage: 'img/loading.gif',
		generatePagination: true,
		play: 5000,
		pause: 2500,
		hoverPause: true,
		// Get the starting slide
		start: startSlide,
		animationComplete: function(current){
			// Set the slide number as a hash
			//window.location.hash = '#' + current;
		}
	});
	
	<!--CODE FOR TABBED CONTENT ON PRODUCT PAGE BEGINS HERE-->
		jq("a.tab").click(function () {
			// switch all tabs off
				jq("#tabs .tabs .active").removeClass("active");
			// switch this tab on
				jq(this).addClass("active");
			// hide all content
				jq(".featuredContent").hide();
			// show this content
				var content_show = jq(this).attr("id");
				jq("."+content_show).show();
			// breadcrumb title replacement	on click of tabs
				/*var brdTxt = jq("span",this).text();
				jq(".breadcrumbs span span").text(brdTxt);*/
		});
	<!--CODE FOR TABBED CONTENT ON PRODUCT PAGE ENDS HERE-->
	
	<!--OPEN AND CLOSE POPUP ON LOGIN FORM-->
	jq("#whatThis").click(function(){
		var x = jq(document).height();
		jq("#overlay").css("height",x+"px");
		jq(".popup").show();
		jq(".popup2").hide();
		jq("#overlay").fadeIn(1000);	
	});
	jq(".closewindow a, .closewindow img").click(function(){
		jq("#overlay").fadeOut(1000);
	});
	jq("#moreThis").click(function(){
		var x = jq(document).height();
		jq("#overlay").css("height",x+"px");
		jq(".popup").hide();
		jq(".popup2").show();
		jq("#overlay").fadeIn(1000);	
	});
	
	<!--FAQ APPLICATION PAGE SETTINGS-->
	var i = 0;
	jq(".column:eq(0) li").each(function(){
		i = i+1;
		jq(this).addClass("link_"+i);
	});
	var j = 0;
	jq(".column:eq(1) .cell").each(function(){
		j = j+1;
		jq(this).addClass("cell_"+j);
	});
	var k = 0;
	jq(".column:eq(1) li").each(function(){
		k = k+1;
		jq(this).addClass("listitem_"+k);
	});
	var l = 0;
	jq(".cDetails").each(function(){
		l = l+1;
		jq(this).addClass("cDetails_"+l);
	});
	
	jq(".column:eq(0) li").click(function(){
		var cell = jq(this).attr("class");
		cell = cell.split("_");
		jq(".cell, .cDetails").hide();
		jq(".column:eq(1), .cell_"+cell[1]).show();
	});
	
	jq(".column:eq(1) li").click(function(){
		var itemNumber = jq(this).attr("class");
		itemNumber = itemNumber.split("_");
		jq(".cDetails").hide();
		jq(".column:eq(2), .cDetails_"+itemNumber[1]).show();
	});
	
	/*tutorials tabs*/
	jq(".tutorials .tTitle a").click(function(){
		var tId = jq(this).attr("id");
		jq(".tDesc").hide();
		jq("."+tId).show();
	});
	
	/*---global menu---
	jq('.primaryNav').dcMegaMenu({
		rowItems: '3',
		speed: 'fast',
		effect: 'slide'
	});*/
	
	jq(".selectLanguage .option").click(function(){
		jq("ul.selectLang").show();
		jq(this).addClass("hover");
	});
	jq(".selectContainer .option").click(function(){
		jq("ul.selectCont").show();
		jq(this).addClass("hover");
	});
	jq("ul.selectLang li").click(function(){
		jq(".selectLanguage .option").html(jq(this).html());
		jq(this).parent().hide();
		jq(".selectLanguage .option").removeClass("hover");
	});
	jq("ul.selectCont li").click(function(){
		jq(".selectContainer .option").html(jq(this).html());
		jq(this).parent().hide();
		jq(".selectContainer .option").removeClass("hover");
	});
	jq("html").mouseup(function(){
		jq("ul.selectLang, ul.selectCont").hide();
		jq(".option").removeClass("hover");	
	});
	
	/*quickchange primer button toggle*/
	jq(".sh").click(function(){
		var title = jq(this).attr("title");
		switch (title){
		case "Upload Now":
			jq("#uptrans").hide();
			jq("#upnow").show();
			break;
		
		case "Upload Translated":
			jq("#upnow").hide();
			jq("#uptrans").show();
			break;
		}
	});
	
});


/*========= SCRIPTS TO BE called after window load will be written below =======*/

jq(window).bind("load", function(){
	
});

