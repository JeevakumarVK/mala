
var ACS_DEFAULT_LOCALE = 'en-us';

var domain = "domain=.agilent.com";
if(location.host){
	if(location.host.indexOf(".agilent.com.cn")!=-1){
		domain = "domain=.agilent.com.cn";
	}else{
		domain = "domain=.agilent.com";
	}
}

function setCookie(cname,cvalue,exdays)
{
	var d = new Date();
	d.setTime(d.getTime()+(exdays*24*60*60*1000));
	var expires = "expires="+d.toGMTString();
	var path = "path=/";
	document.cookie = cname + "=" + cvalue + "; " + expires + "; " + path + "; " + domain;
}


function DoSurveyClick(ACS_LOCALE,ACS_SURVEY_URL)
{
	var location = String(window.location.href);
	if( ACS_LOCALE == null || ACS_LOCALE == '' )
	{
		ACS_LOCALE = ACS_DEFAULT_LOCALE;
	}
    //var sSurveyUrlFinal = 'BU=lsca&LOCALE=' + ACS_LOCALE + '&Session=' + ACS_SESSION_ID + '&REF_URL=agilent.com'; //+ escape( sTargetHref );
	var S_VI = getCookie("s_vi");
	if(S_VI == null || S_VI == '' || S_VI == '0')
	{
			setTimeout(function(){
			var S_VI=getCookie("s_vi")
			var sSurveyUrlFinal = 'BU=lsca&Locale=' + ACS_LOCALE + '&REF_URL='+ escape( location ) + '&Session=' + S_VI + '&CT=1';
		
		    
		    if( ACS_SURVEY_URL.indexOf('?') > -1 )
		    {
		        sSurveyUrlFinal = ACS_SURVEY_URL + '&' + sSurveyUrlFinal;
		    }
		    else
		    {
		        sSurveyUrlFinal = ACS_SURVEY_URL + '?' + sSurveyUrlFinal;
		    }
		    window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
		}, 2000);
	} else{
		var sSurveyUrlFinal = 'BU=lsca&Locale=' + ACS_LOCALE + '&REF_URL='+ escape( location ) + '&Session=' + S_VI + '&CT=1';
	    
	    if( ACS_SURVEY_URL.indexOf('?') > -1 )
	    {
	        sSurveyUrlFinal = ACS_SURVEY_URL + '&' + sSurveyUrlFinal;
	    }
	    else
	    {
	        sSurveyUrlFinal = ACS_SURVEY_URL + '?' + sSurveyUrlFinal;
	    }
	    window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
	}
    return true;
}

function DoSurveyClickOrderConfirm(ACS_LOCALE,ACS_SURVEY_URL)
{
	var location = String(window.location.href);
	if( ACS_LOCALE == null || ACS_LOCALE == '' )
	{
		ACS_LOCALE = ACS_DEFAULT_LOCALE;
	}
    //var sSurveyUrlFinal = 'BU=lsca&LOCALE=' + ACS_LOCALE + '&Session=' + ACS_SESSION_ID + '&REF_URL=agilent.com'; //+ escape( sTargetHref );
	var S_VI = getCookie("s_vi");
	if(S_VI == null || S_VI == '' || S_VI == '0')
	{
			setTimeout(function(){
			var S_VI=getCookie("s_vi")
			var sSurveyUrlFinal = 'BU=lsca&Locale=' + ACS_LOCALE + '&REF_URL='+ escape( location ) + '&Session=' + S_VI + '&CT=2';
		    if( ACS_SURVEY_URL.indexOf('?') > -1 )
		    {
		        sSurveyUrlFinal = ACS_SURVEY_URL + '&' + sSurveyUrlFinal;
		    }
		    else
		    {
		        sSurveyUrlFinal = ACS_SURVEY_URL + '?' + sSurveyUrlFinal;
		    }
		    window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
		}, 2000);
	} else{
		var sSurveyUrlFinal = 'BU=lsca&Locale=' + ACS_LOCALE + '&REF_URL='+ escape( location ) + '&Session=' + S_VI + '&CT=2';
	    
	    if( ACS_SURVEY_URL.indexOf('?') > -1 )
	    {
	        sSurveyUrlFinal = ACS_SURVEY_URL + '&' + sSurveyUrlFinal;
	    }
	    else
	    {
	        sSurveyUrlFinal = ACS_SURVEY_URL + '?' + sSurveyUrlFinal;
	    }
//	    setTimeout(function(){window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes')},5000);
	    
	    window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
	}

    return true;
}

function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
}
return "";
}

/*function UR_InitPartner(bIsPartner,abc,def)
{
//    alert(bIsPartner);
//    alert(abc);
//    alert(def);
    DoSurveyClick();
    //setCookie("acswebsurvey","true",365);
    
	  var location =String(window.location.hostname);
    alert(location);
    var test = location.lastIndexOf("&language=");
    if(test!=-1){
           location=location.substring(0,test);
    }
    window.location = location+"&language="+locale;
    //checkCookie();
    //ACS_SupportsCookies();
    //ActivateSurveyTriggers();
}

function ACS_SupportsCookies( )
{
    var expdate = new Date();     
    expdate.setTime( expdate.getTime() + (1000 * 60 * 1 * 1 * 1) ); 
    SetSurveyCookieValue( 'cookie_test', 'false', expdate); 
    var persistentCookieEnabled = ( GetSurveyCookieValue( 'cookie_test' ) == 'true' )? true : false;
    alert(persistentCookieEnabled);
//    ACS_DEBUG += '\nPersistant Cookies: ' + persistentCookieEnabled + '\n';
    return persistentCookieEnabled;
}


function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
}
return "";
}

function checkCookie()
{
var user=getCookie("username");
if (user!="")
  {
  alert("Welcome again " + user);
  }
else 
  {
  user = prompt("Please enter your name:","");
  if (user!="" && user!=null)
    {
    setCookie("username",user,365);
    }
  }
}
 

function ActivateSurveyTriggers( )
{
	alert("ActivateSurveyTriggers");
    for( var z=0; z < document.links.length; z++ )
    {
        var curLink = document.links[ z  ];
        
        if( curLink.onclick == null && curLink.href.length > 5 && curLink.href.substring(0,4) == 'http' )
        {
            curLink.onclick = DoSurveyClick
            alert("Inside");
        }
    }
    DoSurveyClick();
}


function DoSurveyClick()
{
	//alert("DoSurveyClick");
    if( ! ACS_IsUserElegible() )
    {
        return true;
    }
    var eventInfo = GetCrossBrowserEventInfo( evt );

    var sTargetHref = eventInfo[1].href;
    alert("sTargetHref" + sTargetHref);

    if( sTargetHref == null || sTargetHref == '' )
    {
        sTargetHref = eventInfo[1].parentNode.href;

        if( sTargetHref == null || sTargetHref == '' )
        {
            sTargetHref = eventInfo[1].parentNode.parentNode.href;

            if( sTargetHref == null || sTargetHref == '' )
            {
                return true;
            }
        }
    }
    
    eventInfo[0].cancelBubble = true;
    eventInfo[0].returnValue = false;
 
    var expirationDate = new Date();

    expirationDate.setTime( expirationDate.getTime() + 1000 * 60 * 60 * 24 * ACS_COOKIE_DAYS );

    SetSurveyCookieValue( ACS_COOKIE, '1', expirationDate );

    var sSurveyUrlFinal = 'BU=lsca&LOCALE=' + ACS_LOCALE + '&Session=' + ACS_SESSION_ID + '&REF_URL=agilent.com'; //+ escape( sTargetHref );
    //alert("sSurveyUrlFinal1" + sSurveyUrlFinal);
    
    if( ACS_SURVEY_URL.indexOf('?') > -1 )
    {
        sSurveyUrlFinal = ACS_SURVEY_URL + '&' + sSurveyUrlFinal;
    }
    else
    {
        sSurveyUrlFinal = ACS_SURVEY_URL + '?' + sSurveyUrlFinal;
    }
    
    //alert("sSurveyUrlFinal2" + sSurveyUrlFinal);
    window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
//    window.open(sSurveyUrlFinal);
    
//Add Pop-Up window for AMR#1241 by Sachin
       if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){
			window.open(sSurveyUrlFinal,'','width=750px,height=750px,scrollbars=yes');
}
	else {
		window.open(sSurveyUrlFinal);
		
	}
//    location.href = sSurveyUrlFinal;//Comment by Sachin for AMR#1241
    event.returnValue = true;   
    return true;
	//End
}


function GetCrossBrowserEventInfo( evt )
{
	// Define a variable to track the event source
    var obSource = null;

    // Handles Mozilla / Firefox eventing
    if( evt != null )
    {
        // Grab the event source
        obSource = evt.target;
    }
    else if( window.event != null )
    {
		evt = window.event;

		// Grab the event source (for IE)
        obSource = window.event.srcElement;
    }
	else
	{
		// Couldn't find an event source
		alert( 'DEBUG:  No event available' );
	}

	// Return the event and the source of the event to the caller
	return new Array( evt, obSource );
}

function SetSurveyCookieValue( name, value, expires ) 
{
    var sCookie = '';
    alert(name + " " + value + " " + expires);

    if( expires ) 
    {       
            sCookie = name + '=' + escape(value) + '; expires=' + expires.toGMTString() + '; path=/' + ACS_COOKIE_EXTRA;       
    }
    else
    { 
        sCookie = name + '=' + escape( value ) + '; path=/' + ACS_COOKIE_EXTRA;  
    }
    document.cookie = sCookie;
}
     
     
function GetSurveyCookieValue( name ) 
{
    var dcookie = document.cookie;
    alert(dcookie);
    var cname = name + '=';
    var clen = dcookie.length;        
    var cbegin = 0;
    
    while (cbegin < clen) 
    {           
        var vbegin = cbegin + cname.length;

        if (dcookie.substring(cbegin, vbegin) == cname) 
        {      
            var vend = dcookie.indexOf( ';', vbegin );           
            if (vend == -1)
                vend = clen;                        
            return unescape(dcookie.substring(vbegin, vend));   
        }                                                      
        cbegin = dcookie.indexOf(' ', cbegin) + 1;

        if (cbegin == 0)
            break;                                
    }                                                         
    return null;                                              
}
*/
