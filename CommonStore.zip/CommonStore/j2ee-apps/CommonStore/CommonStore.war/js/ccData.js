
function populateCyberSourceForm(cyberSourceInput) {
    $("#merchant_defined_data4").val(cyberSourceInput.data4);
    $("#merchant_defined_data5").val(cyberSourceInput.data5);
    $("#merchant_defined_data6").val(cyberSourceInput.data6);
    $("#merchant_defined_data7").val(cyberSourceInput.data7);
    $("#merchant_defined_data9").val(cyberSourceInput.data9);
    $("#merchant_defined_data10").val(cyberSourceInput.data10);
    $("#merchant_defined_data11").val(cyberSourceInput.data11);
    $("#merchant_defined_data12").val(cyberSourceInput.data12);
    $("#merchant_defined_data13").val(cyberSourceInput.data13);
    $("#merchant_defined_data14").val(cyberSourceInput.data14);
    $("#merchant_defined_data15").val(cyberSourceInput.data15);
    $("#merchant_defined_data16").val(cyberSourceInput.data16);
    $("#merchant_defined_data17").val(cyberSourceInput.data17);
	$("#merchant_defined_data18").val(cyberSourceInput.data18);  
	$("#merchant_defined_data19").val(cyberSourceInput.data19); 
	$("#merchant_defined_data20").val(cyberSourceInput.data20); 
	$("#merchant_defined_data21").val(cyberSourceInput.data21);
	$("#merchant_defined_data22").val(cyberSourceInput.data22);
	$("#merchant_defined_data23").val(cyberSourceInput.data23);
	$("#merchant_defined_data24").val(cyberSourceInput.data24);
	$("#merchant_defined_data25").val(cyberSourceInput.data25);
	$("#merchant_defined_data26").val(cyberSourceInput.data26);
	$("#merchant_defined_data27").val(cyberSourceInput.data27);
	$("#merchant_defined_data28").val(cyberSourceInput.data28);
	$("#merchant_defined_data29").val(cyberSourceInput.data29);
	$("#merchant_defined_data31").val(cyberSourceInput.data31);
	$("#merchant_defined_data32").val(cyberSourceInput.data32);
	$("#merchant_defined_data33").val(cyberSourceInput.data33);
	$("#merchant_defined_data34").val(cyberSourceInput.data34);
	$("#merchant_defined_data35").val(cyberSourceInput.data35);
	$("#merchant_defined_data36").val(cyberSourceInput.data36);
	$("#merchant_defined_data37").val(cyberSourceInput.data37);
	$("#merchant_defined_data38").val(cyberSourceInput.data38);
	$("#merchant_defined_data40").val(cyberSourceInput.data40);
	$("#merchant_defined_data42").val(cyberSourceInput.data42);
	$("#merchant_defined_data43").val(cyberSourceInput.data43);
	$("#merchant_defined_data44").val(cyberSourceInput.data44);
	$("#merchant_defined_data45").val(cyberSourceInput.data45);
	$("#merchant_defined_data46").val(cyberSourceInput.data46);
	$("#merchant_defined_data47").val(cyberSourceInput.data47);
	$("#merchant_defined_data48").val(cyberSourceInput.data48);
	$("#merchant_defined_data49").val(cyberSourceInput.data49);
	$("#merchant_defined_data50").val(cyberSourceInput.data50);
	$("#merchant_defined_data51").val(cyberSourceInput.data51);
}

function submitLSCAOrder() {
    var isErr = false;
    var error = "";
    var mailarr = $('#payerInvoiceEmail').val();
    var emailValidationError = $('#emailValidationError').val();
    var emailEmptyError = $('#emailEmptyError').val();
    var today = new Date();
    var mm = today.getMonth() + 1;

    if ($('#payerInvoiceEmail').hasClass("email")) {
        var re = /[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,4}/igm;
        if (mailarr == '') {
            $('#payerInvoiceEmail').attr("title", "");
            $('#payerInvoiceEmail').attr("title", emailEmptyError);
            error += $('#payerInvoiceEmail').attr("title") + "<br/>";
            isErr = true;
        } else if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mailarr))) {
            $('#payerInvoiceEmail').attr("title", "");
            $('#payerInvoiceEmail').attr("title", emailValidationError);
            error += $('#payerInvoiceEmail').attr("title") + "<br/>";
            isErr = true;
        }
    }
    var enablechangecart = jQuery("#enableChangeCart").val();
    if(enablechangecart == "true"){
    $.ajax({
        type : "GET",
        url : "/common/cartPPSStatus.jsp",
        async : false,
        cache : false
    }).done(function(data) {
		var temp = JSON.parse(data);
		if((jQuery("#isPPSOrder").val() == undefined && temp.isPPSOrderStatus == true) || ((jQuery("#isPPSOrder").val()== "true") && (temp.isPPSOrderStatus == false || temp.isPPSOrderStatus == ""))){
			isErr = true;
			window.location.href=jQuery("#ppsPortalLinklocation").val();
		}
    });
    }
    if (!isErr) {
        setCyberSourceData();
        submitForm();
    } else {
        LSCA.GlobalValidate.showError('', error);
    }
}

function submitQuoteOrder() {
    if ($('input[name="pOrder"]:checked').val() == 'creditCard') {
        setCyberSourceData();
        submitForm();
    } else {
        $('#sbmtOrder').click();
        $("#btnPOSubmitOrder").prop('disabled',true);
    }
}

function submitLynxOrder() {
    if ($('#pay').is(':checked')) {
        setCyberSourceData();
        submitForm();
    } else if ($('#fspOption').is(':checked')) {
        var flagup = validateFspOption();
        if (flagup == false) {
            $('#sbmtOrder').click();
			$("#btnPOPlaceOrder").prop('disabled',true);
        }
    } else {
        var flagup = validateInvoice();
        if (flagup == false) {
        	if($('ul#uploadedFiles li').length >= 1){
				var result1 = {};
				iterateFiles(result1);
			}else{
				$('#sbmtOrder').click();
				$("#btnPOPlaceOrder").prop('disabled',true);
			}
            
        }
    }
}

function placeOrderConfirmPopup(){
	var flagup = false;
	if($('input[name=pay]:checked').val() == 'invoice') {
		 flagup = validateInvoice();
	}
	else if($('input[name=pay]:checked').val() == 'fsp') {
		 flagup = validateFspOption();
	}
        if (flagup == false) {
	if($('#showWarnPopup').val() == 'true'){
		$('#placeOrderConfirm').modal('show'); 
		if(/^((?!chrome|android).)*safari/i.test(navigator.userAgent)){	
			setTimeout(function() {
				if (window.innerHeight > 202) {
					var parentWindowHeight = window.innerHeight - 60;
					var overLayHeight = 202;
					var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
					$("#placeOrderConfirm .agt-modal-center").css("top", calcOverlayTop + 'px');
				}
			}, 200);
		}
	}else {
		submitLynxOrder();
	}
}
}

function submitLMSOrder(){
	if ($('input[name="pLmsOrder"]:checked').val() == 'creditCard') {
		 var qtyVal = $("#lmsQty").val();
		 if (!isEmpty(qtyVal)) {
			 setCyberSourceData();
		     submitForm();
		 }
    } else {
		var flagup = validateQtyandPo();
	    var flagupAgreement = $("#lmsagreeCheckbox").is(":checked");
	    var isChina = $("#isChina").val();
		 
	     if (flagup == false && flagupAgreement ==true && isChina =='true') {
			$('#lmsSbmtOrder').click();
			$("#lmsBtnPOSubmitOrder").prop('disabled',true);
			$("#updateQuantity").prop('disabled',true);
		 }else if(flagup == false && isChina =='false' ){
			 $('#lmsSbmtOrder').click();
			 $("#lmsBtnPOSubmitOrder").prop('disabled',true);
			 $("#updateQuantity").prop('disabled',true);
		 }
    }
}

function submitErrorOrder() {
    var setVal = $("#payErrorDetails").serialize();
    $.ajax({
        type : "POST",
        url : "/common/includes/payment/ajaxCyberSourcePayment.jsp",
        async : false,
        data : setVal,
        cache : false
    }).done(function(data) {
        $("#submitCyberSourceData").html(data);
        setCyberSourceData();
        submitErrorForm();
    });
}

function submitForm() {
	setTimeout(function() {$('#submitCC').click()}, 500);    
}

function submitErrorForm() {
    $('#submitErrCC').click();
}

function validateInvoice() {
    var flag = false;
   // var msg = "Purchase Order is required";
    var msg = $("#poNumRequiredErrorMessage").val();
    
    var po = $("#po").val();
    if (isEmpty(po) && $('input[name=pay]:checked').val() == 'invoice') {
        flag = true;
        //msgui = '<div class="alert alert-dismissable alert-danger">'  + msg + '</div>';
		msgui = '<div class="message-stnd message-box-error" style="display: flex;"><i class="fal fa-exclamation-circle"></i><span>'  + msg + '</span></div>';
        $(document).find('div.errorMessages').hide();
        $(document).find('div.errorMessages').html(msgui);
        $(document).find('div.errorMessages').show();
        $(document).scrollTop($(document).find('div.errorMessages').position('top'));
    }
    return flag;
}

function validateFspOption() {
    var flag = false;
    var msg = $("#fspAccountNumberInput").attr("title");
    
    var po = $("#fspAccountNumberInput").val();
    if (isEmpty(po) && ($("#fspAccountNumberInput").prop('disabled') == false)) {
        flag = true;
        msgui = '<div class="alert alert-dismissable alert-danger">'  + msg + '</div>';
        $(document).find('div.errorMessages').hide();
        $(document).find('div.errorMessages').html(msgui);
        $(document).find('div.errorMessages').show();
        $(document).scrollTop($(document).find('div.errorMessages').position('top'));
    }
    return flag;
}

function validateQtyandPo() {
    var flag = false;
   // var msg = "Purchase Order is required";
    var msg = $("#poNumRequiredErrorMessage").val();
    var msg1 = $("#QtyRequiredErrorMessage").val();
    
    var po = $(".invoice-val").val();
    var qtyVal = $("#lmsQty").val();
	var msgui = "";
    if (isEmpty(po) || isEmpty(qtyVal)) {
        flag = true;
        if(isEmpty(po))
        	msgui += '<div class="alert alert-dismissable alert-danger po-alert"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'  + msg + '</div>';
        if(isEmpty(qtyVal))
        	msgui += '<div class="alert alert-dismissable alert-danger qty-alert"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'  + msg1 + '</div>';
        $(document).find('div.errorMessages').hide();
        $(document).find('div.errorMessages').html(msgui);
        $(document).find('div.errorMessages').show();
        $(document).scrollTop($(document).find('div.errorMessages').position('top'));
    }
    return flag;
} 
function isEmpty(inputStr) {
    var EMPTYREGEX = /^\s*$/;
    if (inputStr == null || EMPTYREGEX.test(inputStr)) {
        return true;
    } else {
        return false;
    }
}

function checkSelectMonth() {
    var flag = false;
   // var msg = "Please select Month";
    var msg = $("#selectMonthErrorMessage").val();
    var month = $("#month").val();
    if (isEmpty(month) || month == '0') {
        flag = true;
        msgui = '<div class="alert alert-dismissable alert-danger">' + msg + '</div>';
        $(document).find('div.errorMessages').hide();
        $(document).find('div.errorMessages').html(msgui);
        $(document).find('div.errorMessages').show();
        $(document).scrollTop($(document).find('div.errorMessages').position('top'));
    }
    return flag;
}
