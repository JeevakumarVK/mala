$(document).ready(function() {
	$(".custom-payment-mode li:first-child").addClass('active');
	$('.custom-payment-mode li').on('click','input[type="radio"]', function(){
		$(".custom-payment-mode li").removeClass('active');
		$(this).parent().addClass('active');
	});
	$('.custom-future-date-wrap li').on('click','input[type="radio"]', function(){
		$(".custom-future-date-wrap li").removeClass('active');
		$(this).parent().addClass('active');
	});
	$('.custom-payment-mode #fspPlan').on('click','option', function(){
		 $('#fspPlan').css({'display' : 'none'});
	});
	if($('#subFrequencyCode').val() != "0" && $('#subFrequencyCode').val() != undefined && $('#subFrequencyCode').val() != ""){
		var subToday = new Date();
		//var subDD = String(subToday.getDate()).padStart(2, '0');
		//var subMM = String(subToday.getMonth() + 1).padStart(2, '0'); //January is 0!
		var subDD = String(subToday.getDate());
		var subMM = String(subToday.getMonth() + 1); 
		var subyyyy = String(subToday.getFullYear());	
		$('body').append('<div id="pageLoader" class="loading" style=""></div>')		
		$.ajax({
			type: "POST",
			contentType: "application/json; charset=utf-8",
			url : "/rest/model/com/agilent/commerce/SubscriptionOrderService/createSubscriptionOrder?atg-rest-output=json",
			dataType: "json",
			data: JSON.stringify(
				 {
				"subscriptionStartDate": subDD,
				"subscriptionStartMonth": subMM,
				"subscriptionStartYear": subyyyy
				}
			),			
			success: function () {
				$('.customthanku-Wraper p.subscriptionTxt,.customthanku-Wraper a.custom-cont-shop-btn + a.custom-cont-shop-btn').show();
				$('.customthanku-Wraper p.order-date').addClass('subscription');
				console.log('Subscription Order created.');
				$('#pageLoader').hide();
			},
			error: function() {
				console.log('Something went wrong while creating Subscription Order!');
				$('.customthanku-Wraper p.order-date').addClass('subscription');
				$('.customthanku-Wraper a.custom-cont-shop-btn + a.custom-cont-shop-btn').show();
				$('#errorMessage').show() 
				$('#pageLoader').hide();
			}			
		});			
	}	
	$('#deliveryOptionsDiv .custom-future-date-wrap li,#deliveryOptionsDiv1 .custom-future-date-wrap li').on('click','input[type="radio"]', function(){
		$('#deliveryOptionsDiv #deliveryCalender,#deliveryOptionsDiv1 #deliveryCalender').val('');
		if($(this).attr('id') == 'DeliveryDate') {
			$('#deliveryOptionsDiv .custom-future-date,#deliveryOptionsDiv1 .custom-future-date').show();
			$('input:radio[name=recurring_delivery]').eq(1).prop('checked',true);
			var submitorder = $("#submitorder").val();
			$("#btnPlaceOrder").text(submitorder);
			$(".craditCardbtnPlaceOrder").text(submitorder);
			$('.delivery-frequency').hide();
			$("#hiddenFrequency").val($("#scheduleFrequency").val());
			$('.checkoutShippingBilling .custom-estimated-time .rq-changeLink').show();
			$('.checkoutShippingBilling span.or-seprator,#btnCreateQuote').show();	
		}
		else {
			$('#deliveryOptionsDiv .custom-future-date,#deliveryOptionsDiv1 .custom-future-date').hide();
		}
	});
	
	$('.custom-future-date-wrap li').on('click','input[type="radio"]', function(){
		$(".custom-future-date-wrap li").removeClass('active');
		$(this).parent().addClass('active');
	});
	$('#deliveryOptionsDiv input#deliveryCalender').on('change',function() {
		$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').removeClass('requiredTextBox');
		$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').next().next().next().hide();
		LSCA.loadingSpinner.showLoading();
		$.ajax({
			type : "POST",
			url : "/common/checkout/ajaxCheckoutDeliveryMethod.jsp",
			data : {
				deliveryOption : $('#deliveryOptionsDiv input[name="delivery"]:checked').val(),
				deliveryDate : $('#deliveryOptionsDiv input#deliveryCalender').val()
			},
			dataType : "html",
			cache : false,
			success: function(data) {
				console.log(data);
				stickyPriceDetails();
				if ($("#mainContainer").hasClass("checkoutShippingBilling")) {
					$(".checkoutShippingBilling .custom-estimated-time .rq-changeLink").hide();
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner").hide();
				}
			},
			error: function() {
				LSCA.loadingSpinner.hideLoading();
				console.log('error');
			}
		});
    })
    
    if($('#immediateOption').val() == 'true'){
        $('tr.custom-immediate').show();
    }
	$(".checkoutShippingBilling .custom-payment-mode .cust-paym .shipto-note").html($(".checkoutShippingBilling .paymentTermsValue").val());	
	$(".checkoutShippingBilling .custom-payment-mode .cust-paym .shipto-note").css("opacity","1");
	if($('.quoteRefSection + .checkout-item-left label').length){
	    var leftheight = $('.quoteRefSection + .checkout-item-left label').height();
	    var rightheight = $('.quoteRefSection + .checkout-item-left + .checkout-item-right label').height()
	    if(leftheight > rightheight){
	        $('.quoteRefSection + .checkout-item-left + .checkout-item-right label').height(leftheight)
	    }else{
	        $('.quoteRefSection + .checkout-item-left label').height(rightheight);
	    }
	}
	
	if($(".deliveryMessageSection .msg-stnd.msg-box-info").length == 1 && $(".deliveryMessageSection .msg-stnd.msg-box-warning").length == 1) {
	   $(".deliveryMessageSection .msg-stnd.msg-box-info").css('margin-bottom','10px');
	   $(".deliveryMessageSection .msg-stnd.msg-box-warning").css('margin-bottom','20px');
	}
	if($(".deliveryMessageSection .msg-stnd.msg-box-info").length == 1 && $(".deliveryMessageSection .msg-stnd.msg-box-warning").length == 0) {
	   $(".deliveryMessageSection .msg-stnd.msg-box-info").css('margin-bottom','20px');
	   $(".deliveryMessageSection .msg-stnd.msg-box-warning").css('margin-bottom','0px');
	}
	if($(".deliveryMessageSection .msg-stnd.msg-box-info").length == 0 && $(".deliveryMessageSection .msg-stnd.msg-box-warning").length == 1) {
	   $(".deliveryMessageSection .msg-stnd.msg-box-info").css('margin-bottom','0px');
	   $(".deliveryMessageSection .msg-stnd.msg-box-warning").css('margin-bottom','20px');
	}
	// PPSCheckout Product Expiration
	var ppscheckout = [];
	if(jQuery("#isPPSOrder").val()=== "true" && $('#chekoutItemSection .custom-item-details-wrap .skyblueTable:first-child tbody tr').length > 0) {
			$('#chekoutItemSection .custom-item-details-wrap .skyblueTable:first-child tbody tr').each(function(i, v) {
				if($(this).attr('data-partnoid') !== '' && $(this).attr('data-partnoid') !== undefined) {
					ppscheckout.push($(this).attr('data-partnoid'));
				}
			});
			var ppscheckoutList = ppscheckout.join();
			$.ajax({
                type : "POST",
                url : '/common/prdDetailSrchJSON.jsp?catalogIds='+ppscheckoutList,
                contentType : "application/json",
                dataType : "json",
                cache : false,
                beforeSend : function() {
					$('#chekoutItemSection .custom-item-details-wrap .skyblueTable:first-child tbody tr div.item-expiration').addClass('tbl-loading');
                },
				 success : function(data) {
					 var expirationDateLabel = $("#expirationDateLabel").val();
					$.each(data, function(k,v) {
					var kPartNo = k;
					if(typeof(v.expirationDate) != 'undefined' && v.expirationDate !== 'undefined' && v.expirationDate !== ""){
					$('tr[data-partnoid='+kPartNo+'] .pull-left .product-inner .item-expiration').removeClass('tbl-loading');
					$('tr[data-partnoid='+kPartNo+'] .pull-left .product-inner .item-expiration').addClass("pT2");
					$('tr[data-partnoid='+kPartNo+'] .pull-left .product-inner .item-expiration').text(expirationDateLabel +' '+v.expirationDate);
					}else{
					$('tr[data-partnoid='+kPartNo+'] .pull-left .product-inner .item-expiration').removeClass('tbl-loading');
					}
					});
					},
					error : function(x, t, m) {
					$('#chekoutItemSection .custom-item-details-wrap.custom-standard-items .skyblueTable:first-child tbody tr div.item-expiration').removeClass('tbl-loading');
                    console.log('Something went wrong!');
                }
			});
		}
        if ($.cookie("CountryCode") === 'CN') {
            $('#differentWarehouseMsg').css({ 'display': 'block' });
        } else {
            $('#differentWarehouseMsg').css({ 'display': 'none' });
        }
		
		$('.checkoutShippingBilling .subscriptionOrderWrap .recurring-delivery-radio input[type=radio]').change(function () {
			$("#scheduleFrequency").removeClass("requiredTextBox");
            $(".delivery-frequency span").hide();
			var submitsub = $("#submitsubscription").val();   
            var submitorder = $("#submitorder").val();
			if ($(this).attr('id') === 'no-thanks') {
				$('.checkoutShippingBilling .custom-estimated-time .rq-changeLink').show();
				$('.checkoutShippingBilling span.or-seprator,#btnCreateQuote').show();
				$("#btnPlaceOrder").text(submitorder);
				$(".craditCardbtnPlaceOrder").text(submitorder);
				$('.delivery-frequency').hide();
				$('.checkoutShippingBilling .subscriptionOrderWrap .left select').prop('selectedIndex', 0);
				$("#hiddenFrequency").val($("#scheduleFrequency").val());
			} else if ($(this).attr('id') === 'recurring-delivery') {
				if (checkIfSubscribeError()) {
					//$('#subscribe-err-msg').show();
					$('#subscribe-err-msg')[0].style.display = 'flex';
					window.scroll({
						top: 0,
						left: 0,
						behavior: 'smooth'
					});
					$('input:radio[name=recurring_delivery]')[1].checked = true;
				} else {
					$("#btnPlaceOrder").text(submitsub);
				    $(".craditCardbtnPlaceOrder").text(submitsub);
					LSCA.loadingSpinner.showLoading();
					urlVal = '/common/checkout/checkout-product-listing.jsp';
					$.ajax({
						type: 'POST',
						url: urlVal,
						dataType: 'html'
					})
						.done(function (msg) {
							LSCA.loadingSpinner.hideLoading();
							$('div#chekoutItemSection').html(msg);
							displayDatePickerForStdCheckout();
							checkoutIVDWidth();
							additionalReqToggle();
							hplcCheckBoxToggle();
							$('.checkoutShippingBilling .custom-estimated-time .rq-changeLink').hide();
							$('.checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText').hide();
							$('.checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner').hide();
							jQuery('.checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row').prev().addClass('remove-border');
							jQuery('.checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row').each(function () {
								var colspanVal = jQuery(this).prev().find('td').length;
								jQuery('.checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row td').attr('colspan', colspanVal);
							});
							$('.checkoutShippingBilling span.or-seprator,#btnCreateQuote').hide();
							$('.delivery-frequency').show();
							$('.checkoutShippingBilling .subscriptionOrderWrap .left select').prop('selectedIndex', 0);
							$('.checkoutShippingBilling .subscriptionOrderWrap .left select').on("change", function (e) {
								$("#hiddenFrequency").val($("#scheduleFrequency").val());
								//for disableing future date and flexible plan
								if ($("#scheduleFrequency").val() !== '0') {
									$("#DeliveryDate").prop("disabled", true);
									$("#flexibleSpendPlan").prop("disabled", true);
								}
								else {
									$("#DeliveryDate").prop("disabled", false);
									$("#flexibleSpendPlan").prop("disabled", false);
								}
							});
						}).fail(function () {
							console.log('Something went wrong!');
							LSCA.loadingSpinner.hideLoading();
						});
				}
			}
		});	
		$('.checkoutShippingBilling input[type=radio]').change(function() {
			if($(this).attr('name')!=='recurring_delivery'){
				resetSubs();
			}
		});
	$('.checkoutShippingBilling #editShippingAddr').click(function() {
		resetSubs();
	});
	$('.checkoutShippingBilling .custom-estimated-time a').click(function() {
		resetSubs();
	});
	//check for if frequency selected from cart page to checkout page
	var submitsub = $("#submitsubscription").val();   
    var submitorder = $("#submitorder").val();
	if($("#displayFreq").val()!=="" && $("#displayFreq").val()!=="0" && $("#displayFreq").val()!= undefined){
		$("#recurring-delivery").attr('checked', true).trigger('click');
		$('.delivery-frequency').show();
		$("#scheduleFrequency").val($("#displayFreq").val());
		$("#hiddenFrequency").val($("#scheduleFrequency").val());
		$("#DeliveryDate").prop("disabled", true);
		$("#flexibleSpendPlan").prop("disabled", true);
		$('.checkoutShippingBilling .custom-estimated-time .rq-changeLink').hide();
		$('.checkoutShippingBilling span.or-seprator,#btnCreateQuote').hide();
		$('.checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner').hide();
		$("#btnPlaceOrder").text(submitsub);
		$(".craditCardbtnPlaceOrder").text(submitsub);
	}
	else{
		$("#no-thanks").attr('checked', true).trigger('click');
		$('.delivery-frequency').hide();
		$('.checkoutShippingBilling .subscriptionOrderWrap .delivery-frequency select').prop('selectedIndex',0);
		$("#DeliveryDate").prop("disabled", false);
		$("#flexibleSpendPlan").prop("disabled", false);
		$("#btnPlaceOrder").text(submitorder);
		$(".craditCardbtnPlaceOrder").text(submitorder); 
	}
	$('.checkoutShippingBilling .subscriptionOrderWrap .left select').on("change", function (e) {
		$("#hiddenFrequency").val($("#scheduleFrequency").val());
	});
	var editcarturl=$('#trigger-editCart').attr("href");
	$('#trigger-editCart').removeAttr("href");
	$('#trigger-editCart').click(function(){
        var frequencyCodeJson = new Object();
        var frequencyCode = $("#hiddenFrequency").val();
        frequencyCodeJson.flow="editCart";
        frequencyCodeJson.frequencyCode=frequencyCode;
        if($("#displayFreq").val()!= $("#scheduleFrequency").val()){
                  $.ajax({    
				        type : "POST",
                        contentType: "application/json; charset=utf-8",
                        url : "/rest/model/com/agilent/commerce/SessionBeanDataSaver/getFrequencyCode",
	        			data : JSON.stringify({
	        				"frequencyCodeJson": JSON.stringify(frequencyCodeJson)}),
                        success : function(data,textStatus,jQxhr) {
                       }
                  });
        }
		setTimeout(function(){ window.location.href=editcarturl; }, 500);
        });    
});
function resetSubs(){
    if($(".subscriptionOrderWrap").length == 1){
		if($( "#subscribe-err-msg" )[0].style.display =='block' || $( "#subscribe-err-msg" )[0].style.display =='flex'){
			$("#addr-sub-err").hide();
			$('#sch-sub-err').hide();
			$('#date-sub-err').hide();
			$("#fsp-sub-err").hide();
			$("#subscribe-err-msg").hide();
			$(".sub-err").removeClass("sub-err");
			$(".sub-err-box").removeClass("sub-err-box");
			$("#flexibleSpendPlan ~ .checkmark ~.shortBillingDesc").removeClass("sub-err");
			$("#customOpt").removeClass("sub-err-box");
			$("#fspAccountNumberInput").removeClass("sub-err-box");
			$("#fspPONumberInput").removeClass("sub-err-box");		
		}
	}	
}

function checkIfSubscribeError(){
	var errFound = false;
	
	if(is_addressErr()){
		errFound = true;
	}
	/*if(is_scheduledErr()){
		errFound = true;
	}*/
	if(is_futureDateErr()){
		errFound = true;
	}
	if(is_FSPErr()){
		errFound = true;
	}
	return errFound;	
}
function is_addressErr(){
	var errFound= false;
	if($( "#addrType" ) && $( "#addrType" )[0] && $( "#addrType" )[0].value =="WEB"){ 
			errFound = true;
			$("#custom-change-shipAddress")[0].classList.add("sub-err-box");
			$( "#custom-change-shipAddress p" ).each(function( index ) {
				$( this ).addClass("sub-err");
			});
			$("#addr-sub-err,#sch-sub-err").show();
	}
	return errFound;
}
function is_FSPErr(){
	var errFound = false;
	if($('#flexibleSpendPlan').is(':checked')){
		errFound = true;
		$("#flexibleSpendPlan ~ .checkmark ~.shortBillingDesc,.checkoutShippingBilling .custom-flexi-wrap .form-group label[for=PurchaseOrder]").addClass("sub-err");
		$("#customOpt").addClass("sub-err-box");
		$("#fspAccountNumberInput").addClass("sub-err-box");
		$("ul.custom-payment-mode li .custom-flexi-wrap input#fspPONumberInput").addClass("sub-err-box");
		$("#fsp-sub-err,#sch-sub-err").show();
	}
	return errFound;
	
}
/*function is_scheduledErr(){
	var errFound = false;
	if($('.split-ship-value.showblock')  && $('.split-ship-value.showblock').length>0 ){ 
		errFound = true;
		$('#sch-sub-err').show();
	}
}*/
function is_futureDateErr(){
	var errFound = false;
	var delOption =$('#deliveryOptionsDiv input[name="delivery"]:checked').val();
	if(delOption == 'DeliveryDate'){
		errFound = true; 
		if($('#deliveryOptionsDiv li.cust-paym.active div.shortBillingDesc') 
			&& $('#deliveryOptionsDiv li.cust-paym.active div.shortBillingDesc').length>0){
				$('#deliveryOptionsDiv li.cust-paym.active div.shortBillingDesc')[0].classList.add("sub-err");
				$('.form-group.calender_control.custom-future-date div')[0].classList.add("sub-err-box");
				$('#date-sub-err,#sch-sub-err').show();
		}
	}
	return errFound;
}

//Scheduled Shipping for Checkout

function getFormatedDate(ldate){
	var tempdate = ldate.split("/");
	if(tempdate.length == 3){
	var fdate= new Date(ldate);
	var isValidDate =false;
	var fmonth= "", fyear = "",fday="";
    if (Object.prototype.toString.call(fdate) === "[object Date]"){
        if (isNaN(fdate.getTime())){
			isValidDate = false;
        }
        else {
            isValidDate = true;
        }
	}
	if(isValidDate){
		fyear=fdate.getFullYear();
		fmonth=fdate.getMonth();
		fday=fdate.getDate();
	var localeArr = ["en-IN","zh-CN","ko-KR","pt-BR","de-DE","es-ES","ja-JP","fr-FR","it-IT"];
	var cookie_locale = $.cookie("agilent_locale");
	var dateLocale = "en-IN";
	if(cookie_locale != undefined && cookie_locale !== ""){
		dateLocale = cookie_locale.replace("_","-");
		if(localeArr.indexOf(dateLocale) == -1){
			dateLocale = "en-IN";
		}
	}
	const event = new Date(fyear,fmonth, fday);
	const options = { year: 'numeric', month: 'long', day: 'numeric' };
	return event.toLocaleDateString(dateLocale,options);
	}else{
		return "";
	}
	}else{
		return "";
	}
}
function getNumberOfDays(startDate, endDate) {
	var date1 = new Date(startDate);
	var date2 = new Date(endDate);
	var oneDay = 1000 * 60 * 60 * 24;
	var diffInTime = date2.getTime() - date1.getTime();
	var diffInDays = Math.round(diffInTime / oneDay);
	return diffInDays;
}

$(window).on("load",function() {
	if ($("#mainContainer").hasClass("checkoutShippingBilling") && jQuery("#isPPSOrder").val()!= "true") {
	//var itemNo = "";
	  $(".checkoutShippingBilling #chekoutItemSection .custom-item-details-wrap tr:not(.promocode-row,.last,.grandTotal,.dgMessageSection,.custom-remaining,.custom-immediate,.chinaTC)").each(function(){
		  //itemNo = $(this).attr("data-itemno");
		  //console.info(itemNo);
			var datePickerInput="",initialrqmaxdateVal="",initialrqmindateVal="";
			datePickerInput=$(this).find(".split-shipping-inner .calendar-display input").attr("class").split(" ")[0];
			var rqDateFormatVal = "";
			var maxDistVal = $(this).find('td #maxValueForDistributor').val();
			var isIntrumentCheck = $(this).find('td #isIntrumentConfig').val(); 
			 if ($.cookie("CountryCode") === 'CN') {
				 rqDateFormatVal = "yy/mm/dd";
			 }
			 else{
				 rqDateFormatVal = "mm/dd/yy";
			 }  
			if (isIntrumentCheck == "true"){  
			 	initialrqmaxdateVal = $("#configurableMaxDate").val();
			 }
			 else{ 
					if(($('#memberTypeValue').val() === "distributor") && ( maxDistVal === "true")){
							initialrqmaxdateVal = '+6M';
					}else{
							initialrqmaxdateVal = '+12M';
					}
				}
			if($(this).find(".custom-estimated-time > p").hasClass("madeToOrder")){
				initialrqmindateVal=14;
			}
			else if(($(this).find(".custom-estimated-time > .custom-estimate > span.custom-instock > span").hasClass("inStockQtyVal")) && 
			($(this).find(".custom-estimated-time > .custom-estimate > span").hasClass("estShipDate"))) {
				if(($(this).find(".custom-estimated-time > .custom-estimate > span.custom-instock > span.inStockQtyVal").text().trim())!=0){					
					initialrqmindateVal=2;
					$(this).find("#inStockCountValue").val(parseInt($(this).find(".custom-estimated-time > .custom-estimate > span.custom-instock > span.inStockQtyVal").text().trim()));
					$(this).find("#estDateValue").val($(this).find(".custom-estimated-time > .custom-estimate #hiddenEstDate").val().trim());
				}
					
			}
			else if($(this).find(".custom-estimated-time > .custom-estimate > span").hasClass("estShipDate")) {
					todayDate = $.datepicker.formatDate('mm/dd/yy', new Date());
					//curDateVal = $(this).find(".custom-estimated-time > .custom-estimate > span.estShipDateValue").text().trim();
					curDateVal = $(this).find(".custom-estimated-time > .custom-estimate #hiddenEstDate").val().trim();
					$(this).find("#estDateValue").val(curDateVal);
					initialrqmindateVal = getNumberOfDays(todayDate,curDateVal);
			}
			else{
				initialrqmindateVal = 2;
			}
			$("."+datePickerInput).datepicker({        
				showOn : "both",
				buttonImage : "../images/A_Icon_Calendar_V2.svg",
				buttonImageOnly : true,
				dateFormat: rqDateFormatVal,
				minDate : initialrqmindateVal,
				autoClose: true,
				maxDate : initialrqmaxdateVal				
			}).attr('readonly', true);	
			$(this).find("#calendarMinInputValue").val(initialrqmindateVal);
			$(this).find("#calendarMaxInputValue").val(initialrqmaxdateVal);				
		});	
	}
});

$(window).on("load", function() {
if ($("#mainContainer").hasClass("checkoutShippingBilling") && jQuery("#isPPSOrder").val()!= "true") {	
var changeShipVal = $("#rq-change").val();
var rqSplitQuantity = $("#rq-quantity").val();
var rqSplitShippingDate = $("#rq-shippingDate").val();
var rqSplitApply = $("#rq-apply").val();
var rqScheduledShipping = $("#rq-scheduledShipping").val();
var rq_qty_val=0,partNoVal="",partNoValText="",splitship_sumqtyval=[],firstValCounterQty=0,firstRowVal=0,rqmindateVal="",rqmaxdateVal="",itemNoVal="";
$(".checkoutShippingBilling #chekoutItemSection .custom-item-details-wrap tr:not(.promocode-row,.last,.grandTotal,.dgMessageSection,.custom-remaining,.custom-immediate,.chinaTC)").each(function () {
	var cal_counter=0;
	$thisVal = $(this);
	$thisVal.find(".split-add-moreLink").click(function(){
		cal_counter++;
		partNoValText=$(this).parents("tr").attr("data-partno").trim();
		itemNoVal=$(this).parents("tr").attr("data-itemno").trim();
		var html = '',calendarval="rq-shipdatepicker"+itemNoVal+cal_counter;
		html += '<div class="split-shipping-inner empty" data-partno="'+partNoValText+'">';
		html += '<p class="split-ship-value"><span class="qty"></span>&nbsp;-&nbsp;'+rqScheduledShipping+'&nbsp;<span class="sp-date"></span><input type="hidden" id="splitShipDate"><a class="updatedChangeLink">'+changeShipVal+'</a></p><span class="qty-wrap"><p class="rq-splittxtLabel fieldLabel">'+rqSplitQuantity+'</p><input type="text" maxlength="4"></span>';
		html += '<span class="cldr-wrap form-group calender_control custom-future-date1"><p class="rq-splittxtLabel fieldLabel">'+rqSplitShippingDate+'</p><span class="calendar-display"><input placeholder="mm/dd/yyyy" value="" id="' + calendarval +'" class="' + calendarval +'" name="' + calendarval +'" type="textbox"></span></span><button class="btn-stnd-small primary-apply apply_btn" type="button">'+rqSplitApply+'</button><span class="removeLink removeMore"><i class="fal fa-minus-circle"></i></span>';
		html += '</div><div class="btn-wrap"><button class="btn-stnd-small apply_btn afterChange" id="apply_btn1" type="button" disabled>'+rqSplitApply+'</button></div>';
		$(this).siblings(".apply_btn.enableBtn").show();
		$(this).parents('#split-add-more').before(html);
		$(this).parents("tr").find(".split-shipping-inner .apply_btn.primary-apply").hide();				
		if ($.cookie("CountryCode") === 'CN') {
			$(".calendar-display input").attr("placeholder", "yyyy/mm/dd");
		}	
		rqmindateVal=$(this).parents("tr").find("#calendarMinInputValue").val();
		rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
		var rqDateFormatVal = "";
		 if ($.cookie("CountryCode") === 'CN') {
			 rqDateFormatVal = "yy/mm/dd";
		 }
		 else{
			 rqDateFormatVal = "mm/dd/yy";
		 }
		$("."+calendarval).datepicker({        
			showOn : "both",
			buttonImage : "../images/A_Icon_Calendar_V2.svg",
			buttonImageOnly : true,
			dateFormat: rqDateFormatVal,
			minDate : rqmindateVal,
			autoClose: true,
			maxDate : rqmaxdateVal
		}).attr('readonly', true);
		$(this).parents("tr").find(".custom-estimated-time .rq-changeLink").addClass("disable_a_href");
		if($(this).parents("tr").find(".split-shipping-inner").hasClass("showblock")){
			$(this).parents("#split-add-more").siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
		}
	});	
});

$(".split-shipping-inner").each(function() {
$(document).on("focus", ".calendar-display input", function() {
	var parentValue = $(this).parents("tr.changedRow").attr("data-partno");
	var rqDateFormatVal = "";
	 if ($.cookie("CountryCode") === 'CN') {
		 rqDateFormatVal = "yy/mm/dd";
	 }
	 else{
		 rqDateFormatVal = "mm/dd/yy";
	 }
	if (($(this).parents(".split-shipping-inner").attr("data-partno") == parentValue) && ($(this).parents("tr").find("#inStockCountValue").val()!="")){	
		if(Number($(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val())>Number($(this).parents("tr").find("#inStockCountValue").val())){
			todayDate = $.datepicker.formatDate('mm/dd/yy', new Date());
			rqmindateVal = getNumberOfDays(todayDate, $(this).parents("tr").find("#estDateValue").val());
			var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];
			rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
			$("."+calClassName).datepicker('destroy');
			$("."+calClassName).datepicker({        
				showOn : "both",
				buttonImage : "../images/A_Icon_Calendar_V2.svg",
				buttonImageOnly : true,
				dateFormat: rqDateFormatVal,
				autoClose: true
				}).attr('readonly', true);
			$("."+calClassName).datepicker('option', {
					minDate: rqmindateVal
			});
			$("."+calClassName).datepicker('option', {
					maxDate: rqmaxdateVal
			});
			//$("."+calClassName).datepicker("refresh");
		}
		else{				
			rqmindateVal = $(this).parents("tr").find("#calendarMinInputValue").val();
			rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
			var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];	
			$("."+calClassName).datepicker('destroy');
			$("."+calClassName).datepicker({        
				showOn : "both",
				buttonImage : "../images/A_Icon_Calendar_V2.svg",
				buttonImageOnly : true,
				dateFormat: rqDateFormatVal,
				autoClose: true
			}).attr('readonly', true);
			$("."+calClassName).datepicker('option', {
					minDate: rqmindateVal
			});	
			$("."+calClassName).datepicker('option', {
					maxDate: rqmaxdateVal
			});			
			//$("."+calClassName).datepicker("refresh");
		}
	}
});
});
}
});
var splitShipArr = [],
firstValCounter = 0,
clickFlag = false;

$(document).ready(function() {
if ($("#mainContainer").hasClass("checkoutShippingBilling") && jQuery("#isPPSOrder").val()!= "true") {
	$(".qty-wrap input").removeClass("changedQty");
	$(document).on("change", ".qty-wrap input", function() {
	firstValCounter = 0;
	$(".qty-wrap input").removeClass("changedQty");
	$(this).addClass("changedQty");
	$("#chekoutItemSection tr").removeClass("changedRow");
	$(this).parents("tr").removeClass("changedRow").addClass("changedRow");
	var parentVal = $(this).parents("tr.changedRow").attr("data-itemno");
	$(".split-shipping-inner").each(function() {	
	if ($(this).parents("tr.changedRow").attr("data-itemno") == parentVal) {
		if($(this).find(".qty-wrap input").val()!=""){
			firstValCounter = firstValCounter + Number($(this).find(".qty-wrap input").val());
		}
      $(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val(firstValCounter);
      if (firstValCounter > $(this).parents("tr").attr("data-qty")) {
          $(this).siblings("#split-add-more").find(".errMsgText .errMsgQty").text($(this).parents("tr").attr("data-qty"));
          $(this).siblings("#split-add-more").show();
          $(this).siblings("#split-add-more").find(".errMsgText").show();
          $(this).siblings("#split-add-more").find(".errMsgText").addClass("requiredMsg");
          $(this).parents("tr").find(".qty-wrap input.changedQty").addClass("requiredClass");
          $(this).parents("tr").find(".qty-wrap input.changedQty").prev(".rq-splittxtLabel").addClass("requiredMsg");
          $(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).addClass("requiredMsg");
          $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
      } else {
          if (firstValCounter == $(this).parents("tr").attr("data-qty")) {
          $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
          } else {
          $(this).siblings("#split-add-more").find(".split-add-moreLink").show();
          }
          $(this).siblings("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
          $(this).siblings("#split-add-more").find(".errMsgText").hide();
          $(this).parents("tr").find(".qty-wrap input.changedQty").removeClass("requiredClass");
          $(this).parents("tr").find(".qty-wrap input.changedQty").prev(".rq-splittxtLabel").removeClass("requiredMsg");
          $(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).removeClass("requiredMsg");
      }
  }
});
});

$(document).on("change", ".qty-wrap input", function() {
	if(Number($(this).parents("tr").find("#inStockCountValue").val())!=""){
		var instockVal = Number($(this).parents("tr").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text());
		var stockValue=  Number($(this).parents("tr.changedRow").find("#inStockCountValue").val());
		var estVal = Number($(this).parents("tr.changedRow").attr("data-qty"))-stockValue;		
		$(this).parents("tr.changedRow").attr('data-instockinfo', Number($(this).parents("tr.changedRow").find("#inStockCountValue").val()));
		$(this).parents("tr.changedRow").attr('data-eststockinfo', Number($(this).parents("tr.changedRow").attr("data-qty"))-Number($(this).parents("tr.changedRow").find("#inStockCountValue").val()));
		if(firstValCounter<stockValue){
			var totalvalue = stockValue - firstValCounter;
			if(totalvalue > 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:first-child").show();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(estVal);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();
			}
		}
		if(firstValCounter==stockValue){
			var totalvalue = stockValue - firstValCounter;
			if(totalvalue == 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:first-child").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(estVal);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();	
			}
		}
		if(firstValCounter>=stockValue){
			var totalvalue = estVal - (firstValCounter - stockValue);
			if((totalvalue > 0 && instockVal==0) ||(totalvalue > 0 && instockVal!=0)){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text("0");
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:first-child").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();	
			}
			if(totalvalue == 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text("0");
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:first-child").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time p.custom-estimate:nth-child(2)").hide();
			}
		}
	}
	else{
		if($(this).parents("tr.changedRow").find(".custom-estimated-time span").hasClass("estShipDate")){
			var totalvalue =  Number($(this).parents("tr.changedRow").attr("data-qty")) - firstValCounter;
			$(this).parents("tr.changedRow").attr('data-eststockinfo', Number($(this).parents("tr.changedRow").attr("data-qty")));
			if(totalvalue > 0){					
				$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(totalvalue);
				$(this).parents("tr.changedRow").find(".custom-estimated-time").show();
				
			}
			if(totalvalue == 0){
				$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(totalvalue);
				$(this).parents("tr.changedRow").find(".custom-estimated-time").hide();
			}
		}				
	}
});
	
	
$(document).on("keyup", ".qty-wrap input", function(e) {
$(this).val($(this).val().replace(/[^\d]|^0/g, ''));
});

$(document).on("mouseover", ".qty-wrap input,.calendar-display input", function() {
if ($(this).val() != "" && $(this).parents().siblings(".cldr-wrap,.qty-wrap").find("input").val() != "" && ($(this).closest(".split-shipping-inner").find(".split-ship-value .qty,.split-ship-value .sp-date").text().trim()!="") ) {
  $(this).closest(".split-shipping-inner").addClass('removeIcon');
}
});
$(document).on("mouseleave", ".split-shipping-inner", function() {
$(this).removeClass('removeIcon');
});
$(document).on("click", ".removeLink.removeMore", function() {
	var firstValCounter1=0;
	firstValCounter1=Number($(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val());	
  $("#split-add-more .errMsgText").removeClass("requiredMsg");
  $("#split-add-more .errMsgText").hide();
  if(Number($(this).parents("tr.changedRow").find("#inStockCountValue").val())!=""){
		var stockValue=  Number($(this).parents("tr.changedRow").find("#inStockCountValue").val());
		var removeStockVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-estimate .estShipDate").text())+Number($(this).siblings(".qty-wrap").find("input").val());
		var estVal = Number($(this).parents("tr").attr("data-qty"))-stockValue;
		if(removeStockVal<=estVal){
			$(this).parents("tr").find(".custom-estimated-time .custom-estimate .estShipDate").text(removeStockVal);
			$(this).parents("tr").find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();
		}
		if(removeStockVal>estVal){
				var resultStockVal = removeStockVal -  estVal;
				$(this).parents("tr").find(".custom-estimated-time .custom-estimate .estShipDate").text(estVal);
				var finalVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text())+resultStockVal;
				$(this).parents("tr").find(".custom-estimated-time .custom-instock span.inStockQtyVal").text(finalVal);
				$(this).parents("tr").find(".custom-estimated-time p.custom-estimate:nth-child(1)").show();
				$(this).parents("tr").find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();
		}			
	}
	else if($(this).parents("tr.changedRow").find(".custom-estimated-time span").hasClass("estShipDate")){
		var removeStockVal=Number($(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text())+Number($(this).siblings(".qty-wrap").find("input").val());
		$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-estimate .estShipDate").text(removeStockVal);
		$(this).parents("tr.changedRow").find(".custom-estimated-time").show();
	}
	if ($(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length == 1) {
      $(this).parents(".split-shipping-inner").find(".qty-wrap input").val("");
      $(this).parents(".split-shipping-inner").find(".cldr-wrap input").val("");
      $(this).parents(".split-shipping-inner").removeClass("removeIcon");
		$(this).parents(".split-shipping-inner").find(".split-ship-value .qty,.split-ship-value .sp-date").text("");
		$(this).parents(".split-shipping-inner").find(".split-ship-value").hide();
		$(this).parents(".split-shipping-inner").find(".split-ship-value").removeClass("showblock"); 
		$(this).parents(".split-shipping-inner").find("#splitShipDate").val("");
      $(this).parents(".split-shipping-inner").find(".qty-wrap input").removeClass("requiredClass");            
		$(this).parents(".split-shipping-inner").find(".apply_btn.primary-apply").show();
		$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".apply_btn.enableBtn,.split-add-moreLink").hide();
		$(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val("0");
		$(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href hoverChangeLink");
		$(this).parents(".split-shipping-inner").hide();
		$(this).parents("tr").find(".rq-changeLink").show();
  } else {
		var $this = $(this);			
		if($(this).parents(".split-shipping-inner").find(".qty-wrap input").val()!=""){
			firstValCounter1 = firstValCounter1 - Number($(this).parents(".split-shipping-inner").find(".qty-wrap input").val());
		}			
		$(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val(firstValCounter1);	
      $(this).parents(".split-shipping-inner").next(".btn-wrap").remove();
		$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").addClass("addLabel");
		if($this.parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").length == 1){
			$this.parents("#rq-schedule-shipping-wrap").find("#split-add-more .enableBtn").hide();
		}
		if (firstValCounter1 <= $(this).parents("tr").attr("data-qty")) {
			$(this).parents("tr").find(".split-add-moreLink").show();
		}
		$(this).parents(".split-shipping-inner").siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
		if($(this).parents("tr").find(".split-shipping-inner").hasClass("showblock")){$(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
		}
		$(this).parents(".split-shipping-inner").remove();
		}
		if($("#chekoutItemSection .split-shipping-inner .split-ship-value .qty,.split-ship-value .sp-date").text()==""){
			$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",false);
			$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
			if ($("#mainContainer.checkoutShippingBilling .calender_control.custom-future-date").is(':visible')) {
				$('#mainContainer.checkoutShippingBilling .calender_control.custom-future-date').show()
			}
		}
});

$(document).on("change", ".qty-wrap input,.cldr-wrap input", function() {
if($(this).parents(".split-shipping-inner:not(.showblock)").hasClass("first")){
	if ((!$(this).parents(".split-shipping-inner.first").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).parents(".split-shipping-inner.first").find(".qty-wrap input").val() != "") && ($(this).parents(".split-shipping-inner.first").find(".cldr-wrap input").val() != "")) {
	$(this).parents(".split-shipping-inner.first").find(".primary-apply").click();
	}
}
else{
	if ((!$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).parents(".split-shipping-inner").find(".qty-wrap input").val() != "") && ($(this).parents(".split-shipping-inner").find(".cldr-wrap input").val() != "")) {
		if(!$(this).parents(".split-shipping-inner").hasClass("showblock")){
			$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".enableBtn").click();
		}
		else{
			$(this).parents(".split-shipping-inner").siblings(".btn-wrap").find(".afterChange").click();
		}
	}
}
});
$(document).on("click", ".apply_btn.primary-apply", function() {
var rqDateFormatVal = "";
		 if ($.cookie("CountryCode") === 'CN') {
			 rqDateFormatVal = "yy/mm/dd";
		 }
		 else{
			 rqDateFormatVal = "mm/dd/yy";
		 }
if ((!$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).siblings(".qty-wrap").find("input").val() != "") && ($(this).siblings(".cldr-wrap").find(".calendar-display input").val() != "")){
  $(this).siblings(".split-ship-value").find(".qty").text($(this).siblings(".qty-wrap").find("input").val());
  var jsDate = new Date($(this).siblings(".cldr-wrap").find(".calendar-display input").val());
	$(this).siblings(".split-ship-value").find(".sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",jsDate)));
  $(this).siblings(".split-ship-value").find("#splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
  $(this).siblings(".split-ship-value").show();
  $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
	$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
	if ($("#mainContainer.checkoutShippingBilling .calender_control.custom-future-date").is(':visible')) {
		$('#mainContainer.checkoutShippingBilling .calender_control.custom-future-date').hide();
	}
	$(this).parents(".split-shipping-inner").removeClass("showblock").addClass("showblock");
  $(this).siblings(".split-ship-value").removeClass("showblock").addClass("showblock");
  $(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
  $(this).parents("tr.changedRow").find(".custom-estimated-time .hoverChangeLink").hide();
  $(this).parents("tr").find(".split-shipping-inner:not(.showblock,.first)").each(function() {
		if($(this).find(".qty-wrap input").val() == "" && $(this).find(".cldr-wrap .calendar-display input").val() == ""){
			$(this).next(".btn-wrap").remove();
			$(this).remove();
		}
	});
	var SSList = [];
	var checkEmptyFields=false;
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index){
	if($(this).find(".qty-wrap input").val() != "" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
			var ssqty = $(this).find(".split-ship-value .qty").text();
			var qtydisp = $(this).find(".qty-wrap").css("display");
			var spdateval ="";
			spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
		SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
	}else{
		checkEmptyFields = true;
				return;
		}
	 });
if(!checkEmptyFields){
SSList.sort(function (a, b){
	var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
	return (dateA - dateB);
});
$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
	$(this).find(".split-ship-value .qty").text(SSList[index].qty);
	$(this).find(".qty-wrap input").val(SSList[index].qty);
  $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
	$(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date(SSList[index].ssdate)));
	$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
	});
}
}
else{
	if(($(this).siblings(".cldr-wrap").find(".calendar-display input").val() == "") && ($(this).siblings(".qty-wrap").find("input").val() == "")){
	$(this).parents(".split-shipping-inner").hide();
	$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").hide();
	$(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
	}
}
});
}

});
$(window).on("load", function() {
if ($("#mainContainer").hasClass("checkoutShippingBilling") && jQuery("#isPPSOrder").val()!= "true") {
$("#chekoutItemSection tr").removeClass("changedRow");

$(document).on("click", ".rq-changeLink", function() {
$(this).parents("tr").removeClass("changedRow").addClass("changedRow");
if ($.cookie("CountryCode") === 'CN') {
	$(".calendar-display input").attr("placeholder", "yyyy/mm/dd");
}
$(this).addClass("hoverChangeLink");
if($(this).parents("tr").attr("data-qty") == 1){
	$(this).parents("tr").find("#rq-schedule-shipping-wrap #split-add-more").hide();
}else{
$(this).parents("tr").find("#rq-schedule-shipping-wrap #split-add-more").show();
}
if($(this).hasClass("hoverChangeLink")){
	$(this).parents("tr").find("#rq-schedule-shipping-wrap,.split-shipping-inner").show();
	$(this).parents("tr").find(".split-shipping-inner .qty-wrap,.split-shipping-inner .cldr-wrap").show();
	$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").show();
	$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner .rq-splittxtLabel").show();
	$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner .primary-apply").show();
	$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner").siblings("#split-add-more").find(".enableBtn").hide();
}
else{
  $(this).parents("tr").find("#rq-schedule-shipping-wrap").show();
  $(this).parents("tr").find("#rq-schedule-shipping-wrap .primary-apply").show();
  $(this).parents("tr").find("#rq-schedule-shipping-wrap .enableBtn").hide();
}
});
$(document).on("click", '.apply_btn.enableBtn:not(.afterChange)', function() {
var notEmpty=false;
var rqDateFormatVal = "";
		 if ($.cookie("CountryCode") === 'CN') {
			rqDateFormatVal = "yy/mm/dd";
		 }
		 else{
			 rqDateFormatVal = "mm/dd/yy";
		 }
$(this).parents("#split-add-more").siblings(".split-shipping-inner:not(.showblock)").each(function() {
	if($(this).parents("#split-add-more").siblings(".split-shipping-inner").length == 0){
		$(this).parents("#rq-schedule-shipping-wrap").find("#split-add-more").find(".enableBtn").hide();
		$(this).parents("#split-add-more").find(".split-add-moreLink").hide();
	}
  if ((!$(this).siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).find(".qty-wrap input").val() != "") && ($(this).find(".cldr-wrap .calendar-display input").val() != "")) {
      $(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
      var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());
      $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy", jsDate)));
      $(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
      $(this).find(".split-ship-value").show();
	  $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
		$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
		if ($("#mainContainer.checkoutShippingBilling .calender_control.custom-future-date").is(':visible')) {
			$('#mainContainer.checkoutShippingBilling .calender_control.custom-future-date').hide();
		}
		$(this).removeClass("showblock").addClass("showblock");
      $(this).find(".split-ship-value").removeClass("showblock").addClass("showblock");
      $(this).find(".qty-wrap,.cldr-wrap").hide();
      $(this).parents("tr").find(".custom-estimated-time .hoverChangeLink").hide();
  var SSList = [];
	var checkEmptyFields=false;
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
			if($(this).find(".qty-wrap input").val() !="" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
		var ssqty = $(this).find(".split-ship-value .qty").text();
			var qtydisp = $(this).find(".qty-wrap").css("display");
			var spdateval = "";
			spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
			SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
			}else{
				checkEmptyFields = true;
				return;
			}
	 });
if(!checkEmptyFields){
SSList.sort(function (a, b) {
	var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
	return (dateA - dateB);
});
$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
	$(this).find(".split-ship-value .qty").text(SSList[index].qty);
	$(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
	$(this).find(".qty-wrap input").val(SSList[index].qty);
	$(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date( SSList[index].ssdate)));
	$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
	});
}
if (($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty")) && ($(this).find(".qty-wrap input").val() != "") && ($(this).find(".cldr-wrap .calendar-display input").val() != "")) {
	$(this).siblings("#split-add-more").find(".apply_btn").hide();
	$(this).parents("tr").find(".rq-changeLink").hide();
	$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
	} else {
		$(this).parents("tr").find(".rq-changeLink").hide();
		$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
		$(this).siblings("#split-add-more").find(".apply_btn.enableBtn").hide();
		}
		} else {
      if ($(this).find(".qty-wrap input").val() == "" && $(this).find(".cldr-wrap .calendar-display input").val() == "") {
			$(this).removeClass("nonEmpty");
			if($(this).siblings(".split-shipping-inner").hasClass("showblock") || (!$(this).siblings(".split-shipping-inner").hasClass("first"))){
				$(this).siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
			}
          if ((($(this).siblings(".split-shipping-inner").length)+1) > 1) {
              $(this).next('.btn-wrap').remove();
              if (($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty"))) {
                  $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
              }
              $(this).remove();	
              $(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href hoverChangeLink");
          } else {
              $(this).next('.btn-wrap').hide();
              if($(this).length==0){
					$(this).siblings("#split-add-more").find(".enableBtn").hide();
				}
              $(this).siblings("#split-add-more").find(".split-add-moreLink").hide(); 
				$(this).hide();
              $(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
				$(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href");
          }
		} else {
			$(this).addClass("nonEmpty");
          $(this).siblings("#split-add-more").find(".enableBtn").show();
          $(this).siblings("#split-add-more").find(".split-add-moreLink").show();
			$(this).parents("tr").find(".rq-changeLink").addClass("disable_a_href");
      }
	}
});
if($(this).parents("#split-add-more").siblings(".split-shipping-inner").hasClass("nonEmpty")){
		$(this).parents("#split-add-more").find(".enableBtn").show();
		$(this).parents("#split-add-more").siblings(".split-shipping-inner").removeClass("nonEmpty");
	}
});
$(document).on("click", ".updatedChangeLink", function() {
$(this).addClass("hoverChangeLink");
$(this).parents(".split-shipping-inner").find(".removeLink").removeClass("removeMore");
if ($(this).hasClass("hoverChangeLink")) {
  $(this).parents(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").attr("disabled", true);
}
$(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.rq-splittxtLabel").show();
$(this).parent(".split-ship-value").closest(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").show();
$(this).parents(".split-shipping-inner").next(".btn-wrap").show();
$(this).parent(".split-ship-value").siblings(".removeLink").addClass("removeMore");
$(this).parents(".split-shipping-inner").find(".qty-wrap input,.cldr-wrap .calendar-display input").change(function() {
  if ($(this).parents(".split-shipping-inner").find(".qty-wrap input").val() != "" && $(this).parents(".split-shipping-inner").find(".cldr-wrap .calendar-display input").val() != "") {
      $(this).parents(".split-shipping-inner").next(".btn-wrap").find("button").attr("disabled", false);
  }
});
});
$(document).on("click", ".afterChange", function() {
var rqDateFormatVal = "";
		 if ($.cookie("CountryCode") === 'CN') {
			 rqDateFormatVal = "yy/mm/dd";
		 }
		 else{
			 rqDateFormatVal = "mm/dd/yy";
		 }
$(this).parents("#rq-schedule-shipping-wrap").removeClass("requiredMsg");
$(this).parent(".btn-wrap").prev(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function() {
	if(!$(this).siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg") && $(this).find(".qty-wrap input").val() != "" && $(this).find(".cldr-wrap .calendar-display input").val() != ""){
  $(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
  var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());
  $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy", jsDate)));
  $(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
  $(this).find(".split-ship-value a").removeClass("hoverChangeLink");
  $(this).parents("tr.changedRow").find(".custom-estimated-time .hoverChangeLink").hide();
  $(this).find(".split-ship-value").show();
  $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
	$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
	if ($("#mainContainer.checkoutShippingBilling .calender_control.custom-future-date").is(':visible')) {
		$('#mainContainer.checkoutShippingBilling .calender_control.custom-future-date').hide();
	}
	}
});
	var SSList = [];
	var checkEmptyFields=false;
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
			if($(this).find(".qty-wrap input").val() !="" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
			var ssqty = $(this).find(".split-ship-value .qty").text();
			var qtydisp = $(this).find(".qty-wrap").css("display");
			var spdateval ="";
			spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
			SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
			}else{
				checkEmptyFields = true;
				return;
			}
	 });
	 if(!checkEmptyFields){
SSList.sort(function (a, b) {
	var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
	return (dateA - dateB);
});
$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
	$(this).find(".split-ship-value .qty").text(SSList[index].qty);	
	$(this).find(".qty-wrap input").val(SSList[index].qty);
	$(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
	$(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date(SSList[index].ssdate)));
	$(this).find(".cldr-wrap .calendar-display input").val($.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
	$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
	});
	 }
	
});
}
});

$(window).on("load", function() {
	if ($("#mainContainer").hasClass("checkoutShippingBilling") && jQuery("#isPPSOrder").val()!= "true") {
		if($('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop('checked')){
			$(".checkoutShippingBilling .custom-estimated-time .rq-changeLink").hide();
			$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
			$(".checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner").hide();
		}
		$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery]').on("change", function(e) {
			if ($(this).val() != "DeliveryDate" && $('.checkoutShippingBilling input[type=radio][name=optionsRadios]:checked').val() == "partial") {
				$(".checkoutShippingBilling #chekoutItemSection .custom-item-details-wrap tr:not(.chinaTC,.promocode-row,.last,.grandTotal,.dgMessageSection,.custom-remaining,.custom-immediate)").each(function() {
					$(this).find(".rq-changeLink").show();
					$(this).find(".split-shipping-inner input").val("");
					$(this).find(".split-shipping-inner .qty-wrap .rq-splittxtLabel").removeClass("requiredMsg");
					$(this).find(".split-shipping-inner .qty-wrap input").removeClass("requiredClass");
					$(this).find(".split-shipping-inner").removeClass("requiredMsg");
					$(this).find(".split-shipping-inner.first").hide();
					if($(this).find("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length > 1){
						$(this).find(".split-shipping-inner:not(.first)").next(".btn-wrap").remove();
						$(this).find(".split-shipping-inner:not(.first)").remove();
					}
					else{
						$(this).find(".split-shipping-inner:not(.first)").next(".btn-wrap").hide();
						$(this).find(".split-shipping-inner:not(.first)").hide();
					}
					$(this).find(".custom-estimated-time .rq-changeLink").removeClass("hoverChangeLink disable_a_href");
					$(this).find(".split-shipping-inner").siblings("#split-add-more").show();
					$(this).find(".split-shipping-inner").siblings("#split-add-more").find(".enableBtn").hide();
					$(this).find(".split-shipping-inner .split-ship-value").hide();
					$(this).find(".split-shipping-inner .split-ship-value a").removeClass("hoverChangeLink");
					$(this).find(".split-shipping-inner").removeClass("showblock");
					$(this).find(".split-shipping-inner .qty-wrap,.split-shipping-inner .cldr-wrap").show();
					$(this).find(".split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").show();
					$(this).find("#split-add-more .hiddenval").val("");
					$(this).find(".split-shipping-inner .split-ship-value").removeClass("showblock");
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap").hide();
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
					$("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
				});
			} else {
				if(($('.checkoutShippingBilling input[type=radio][name=optionsRadios]:checked').val() == "consolidate") || ($(this).val() == "DeliveryDate" && $("#deliveryCalender").val()!="")){
				$(".checkoutShippingBilling .custom-estimated-time .rq-changeLink").hide();
				$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
				$(".checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner").hide();
				}
			}


		});

		$('.checkoutShippingBilling input[type=radio][name=optionsRadios]').on("change", function(e) {
			if ($(this).val() == "partial" && $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery]:checked').val() != "DeliveryDate") {
				$(".checkoutShippingBilling #chekoutItemSection .custom-item-details-wrap tr:not(.chinaTC,.promocode-row,.last,.grandTotal,.dgMessageSection,.custom-remaining,.custom-immediate)").each(function() {
					$(this).find(".rq-changeLink").show();
					$(this).find(".split-shipping-inner input").val("");
					$(this).find(".split-shipping-inner .qty-wrap .rq-splittxtLabel").removeClass("requiredMsg");
					$(this).find(".split-shipping-inner .qty-wrap input").removeClass("requiredClass");
					$(this).find(".split-shipping-inner").removeClass("requiredMsg");
					$(this).find(".split-shipping-inner.first").hide();
					if($(this).find("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length > 1){
						$(this).find(".split-shipping-inner:not(.first)").next(".btn-wrap").remove();
						$(this).find(".split-shipping-inner:not(.first)").remove();
					}
					else{
						$(this).find(".split-shipping-inner:not(.first)").next(".btn-wrap").hide();
						$(this).find(".split-shipping-inner:not(.first)").hide();
					}
					$(this).find(".custom-estimated-time .rq-changeLink").removeClass("hoverChangeLink disable_a_href");
					$(this).find(".split-shipping-inner").siblings("#split-add-more").show();
					$(this).find(".split-shipping-inner").siblings("#split-add-more").find(".enableBtn").hide();
					$(this).find(".split-shipping-inner .split-ship-value").hide();
					$(this).find(".split-shipping-inner").removeClass("showblock");
					$(this).find(".split-shipping-inner .split-ship-value a").removeClass("hoverChangeLink");
					$(this).find(".split-shipping-inner .qty-wrap,.split-shipping-inner .cldr-wrap").show();
					$(this).find(".split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").show();
					$(this).find("#split-add-more .hiddenval").val("");
					$(this).find(".split-shipping-inner .split-ship-value").removeClass("showblock");
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap").hide();
					$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
					$("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
				});
			} else {
				if(($(this).val() == "consolidate") ||($('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery]:checked').val() == "DeliveryDate" && $("#deliveryCalender").val()!="")){
				$(".checkoutShippingBilling .custom-estimated-time .rq-changeLink").hide();
				$(".checkoutShippingBilling #rq-schedule-shipping-wrap .errMsgText").hide();
				$(".checkoutShippingBilling #rq-schedule-shipping-wrap,.checkoutShippingBilling #rq-schedule-shipping-wrap .btn-wrap, .checkoutShippingBilling #rq-schedule-shipping-wrap .split-shipping-inner").hide();
				}
			}
		});
	}
});