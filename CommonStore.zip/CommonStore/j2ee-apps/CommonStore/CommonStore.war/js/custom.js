$(document).ready(function() {	
    $('.accordion-section-title').click(function() {
        var ID = $(this).attr('id')
        $(this).toggleClass("active");
        $('table#' + ID).slideToggle();
    });
	
	/*Correct Cart logic with Update button for Custom array Line Items  */
	var cartQtySpaval = '';
	$(document).on('focus', 'input.cartQtySpa', function() {
		cartQtySpaval = $(this).val();	
	});
	$(document).on('focusout', 'input.cartQtySpa', function() {
		if($(this).val() && ($(this).val() != cartQtySpaval)){
			$(this).parent().parent().find('.updateLink a').click();
		}
		if($(this).val() && $(this).prev().prev().prev().val() && ($(this).val() != cartQtySpaval)){
			$(this).parent().parent().parent().next().next().find('a').click();
		}
		cartQtySpaval = $(this).val();	
	});	
	$(document).on('focus', '.withoutDesignID input.cartQtySpa', function() {
		var $this = $(this);    
		$(this).on('keydown',function(e) {
			if(e.which == 13) {
				e.preventDefault();
					$this.next().find('a').click();
			}
		});
	});
	var cartItemDesignval = '';
	$(document).on('focus', 'input.cartItemDesign', function() {
		cartItemDesignval = $(this).val();
	});
	$(document).on('focusout', 'input.cartItemDesign', function() {
		if($(this).val() && $(this).val() != cartItemDesignval){
			$(this).parent().parent().parent().next().next().find('a').click();
		}
		cartItemDesignval = $(this).val();
	});
	$(document).on('focus', '.withdesignID input', function() {
		var $this = $(this);    
		$(this).on('keydown',function(e) {
			if(e.which == 13) {
				e.preventDefault();
				if($this.parent().parent().parent().find('.cartItemDesign').val() != '' && $this.parent().parent().parent().find('.cartQtySpa').val() != ''){
					$this.parent().parent().parent().next().next().find('a').click();
				}            
			}
		});
	});
	$(document).on('change', '.cartItemDesignSelect', function() {
		if($(this).val()){
			$(this).parent().parent().parent().next().next().find('a').click();
		}
	});

	$(document).on('focusout', 'input.cartQtySpa', function() {
		if($(this).val() && $(this).prev().prev().prev().val() && ($(this).val() != cartQtySpaval)){
			$(this).parent().parent().parent().next().next().find('a').click();
		}
		cartQtySpaval = $(this).val();	
		if($(this).parent().hasClass() == "withoutDesignID"){
			$(this).parent().parent().parent().next().next().find('a').click();
		}
	});	
    
    $(document).on("click", "#cancelRenew-Btn,#autoRenewCancel-btn", function(e) {
		setTimeout(function() {
			if(window.innerHeight > $("#cancelAutoRenewPopup .modal-content").height()) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = $("#cancelAutoRenewPopup .modal-content").height();
				var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
				$("#cancelAutoRenewPopup .modal-content").css("top",calcOverlayTop+'px');
			}
		}, 500);
    });
    if((!$('#mainContainer').is('.checkoutShippingBilling')) && (!$('#mainContainer').is('.largeCheckout'))){
    		redeemQuotePaymentSelection();
    	}
	if($('.shopping-cart-spa .widget-quote-save a').length == 2){
		$('.shopping-cart-spa .widget-quote-save a:first-child').addClass('rightBorder')
	}		
});
function myFunc() {
    setTimeout(function() {
		 if($('.ui-listview div.custom-inner-left1').is(':visible')) {
			 $('.custom-search-error').css({'display' : 'none'});
		 }
		 else { 
			 $('.custom-search-error').css({'display' : 'block'});
		 }
    }, 500);
    $(".ui-input-search a").click(function() {
        $('.custom-search-error').css({
            'display' : 'none'
        });
    });
}
function stringTruncation(myString, maxLen){
	var myString = myString.trim();
	   if(myString.length > maxLen) {
			var myTruncatedString = myString.substring(0,maxLen);
			myTruncatedString = myTruncatedString.trim() + '...';
			return myTruncatedString;
		} else {
			return myString;
		}
}

function redeemQuotePaymentSelection(){
    if ($("input[name='pOrder']:checked").val() == 'purchaseOrder') {
		$('.redeemQuoteNew .po-box').show();
		$('.redeemQuoteNew .redeemcc').hide();
		$('.redeemQuoteNew .custom-flexi-wrap,#stateDivOpt').hide();
		$('.redeemQuoteNew #fspPONumberInput').attr('disabled')
        $('#btnPOSubmitOrder').show();
        $('#btnCCSubmitOrder').hide();
		$('#btnnewCCSubmitOrder').hide();
        $('#leavingSiteMsgDiv').hide();
		$('#purchaseReq').show();  /* DCCOM 4736  */
		$('#fspAccountNoReq').hide();
		$("input#po").show();
		$("input#po").removeAttr("disabled").addClass("required");
		$("input#fspAccountNumberInput").attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
		$("input#fspPONumberInput").attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
    }
    if ($("input[name='pOrder']:checked").val() == 'creditCard') {
		$('.redeemQuoteNew .po-box').hide();
		$('.redeemQuoteNew .redeemcc').show();
		$('.redeemQuoteNew .custom-flexi-wrap,#stateDivOpt').hide();
		setTimeout(function(){ $('.redeemQuoteNew #fspPONumberInput').removeAttr('disabled style')}, 10);
        $('#btnPOSubmitOrder').hide();
        $('#btnCCSubmitOrder').show();
		$('#btnnewCCSubmitOrder').show();
        $('#leavingSiteMsgDiv').show();
		$('#purchaseReq').hide();  /* DCCOM 4736 */
		$('#fspAccountNoReq').hide();
		$("input#po").hide();
		$("input#fspAccountNumberInput").attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
		$("input#fspPONumberInput").attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
		$("input#po").attr("disabled", "disabled");
		$("input#po").removeClass("required");

    }
    if ($("input[name='pOrder']:checked").val() == 'flexibleSpendPlan') {
		$('.redeemQuoteNew .po-box').hide();
		$('.redeemQuoteNew .redeemcc').hide();
		$('.redeemQuoteNew .custom-flexi-wrap,#stateDivOpt').show();
		$('.redeemQuoteNew #fspPONumberInput').attr('disabled')
        $('#btnPOSubmitOrder').show();
        $('#btnCCSubmitOrder').hide();
		$('#btnnewCCSubmitOrder').hide();
        $('#leavingSiteMsgDiv').hide();
		$('#purchaseReq').hide();
		$('#fspAccountNoReq').show();
		$("input#po").hide();
		$("input#fspAccountNumberInput").removeAttr("disabled").addClass("required");
		$("input#fspPONumberInput").removeAttr("disabled");
		$("input#po").attr("disabled", "disabled");
		$("input#po").removeClass("required");
		$('#fspAccountNumberInput').val('');
		$('#fspPONumberInput').val('');
		$('.custom-redeemQuest').css("display","block")
		optionText = $("#fspPlan option:selected").text();
		if(optionText != "Other"){
			$('.redeemQuoteNew #fspAccountNumberInput').attr("disabled","disabled");
		}else{
			$('.redeemQuoteNew #fspAccountNumberInput').removeAttr("disabled");
		}	
		$('.redeemQuoteNew #fspAccountNumberInput,.redeemQuoteNew #fspPONumberInput').removeAttr("style");	
    } else{
		$('.custom-redeemQuest').css("display","none")
	  }           

}
/* DCCOM - 4527 */
function getUrlParam (name){
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
      hash = hashes[i].split('=');
      vars.push(hash[0]);
      vars[hash[0]] = hash[1];
    }
    return vars[name]; 
}
/* DCCOM - 4527 End */
$(function() {
    // ----- OPEN
    $('[data-popup-open]').on('click', function(e) {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
		/* DCCOM - 710  - Overlay alignment fix*/
		if(targeted_popup_class == "popup-viewExhibit" || targeted_popup_class == "popup-addContact" || targeted_popup_class ==  "popup-0"  || targeted_popup_class ==  "popup-1") {
			if(window.innerHeight > $("div[data-popup="+ targeted_popup_class + "] .popup-inner").height()) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = $("div[data-popup="+ targeted_popup_class + "] .popup-inner").height();
				var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
				$("div[data-popup="+ targeted_popup_class + "] .popup-inner").css("top",calcOverlayTop+'px');
			}
		}
		$(".custom-covered.accordion .custom-tab-data .custom-service div[data-popup]").each( function () {
            if(targeted_popup_class == $(this).attr("data-popup")) {
                if(window.innerHeight > $("div[data-popup="+ targeted_popup_class + "] .popup-inner").height()) {
	                var parentWindowHeight = window.innerHeight - 60;
	                var overLayHeight = $("div[data-popup="+ targeted_popup_class + "] .popup-inner").height();
	                var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
	                $("div[data-popup="+ targeted_popup_class + "] .popup-inner").css("top",calcOverlayTop+'px');
                }
            }
		});
		/* DCCOM - 710 */
        e.preventDefault();
    });

    // ----- CLOSE
    $('[data-popup-close]').on('click', function(e) {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);

        e.preventDefault();
    });
});
$(document).ready(function() {
        var headerHeight = $(".affix-top").height();
        $("#bin").css("padding-top", headerHeight);
		$('.Block').hide();
		$('.QuoteBlock').hide();
		$('.None').hide();
		$('.onDemandBlock,.onDemandOrderBlock,.repairQuoteBlock,.repairOrderBlock').hide();

		if(getUrlParam('repair_services') == 'true') {
			if($("#repairFilter #active").prop('checked')) {
				$('.onDemandOrderBlock').show();
			}
			if($("#repairFilter #orderschk").prop('checked')) {
				$('.onDemandBlock').show();
			}
			
			
			if($("#repairFilter #active").prop('checked') && $("#repairFilter #orderschk").prop('checked')) {
				if($(".custom-inner-left1.onDemandBlock").length <= 0 && $(".custom-inner-left1.onDemandOrderBlock").length <= 0){
					$('#serviceContractErrorMessage').css({'display' : 'block'});
				}
			}
			$('#repairQuoteLink,#repairQuotePMLink').show();
		}
		else {
			if($("#serviceFilter #active").prop('checked')) {
				$('.Block').show();
			}
			if($("#serviceFilter #quoteschk").prop('checked')) {
				$('.QuoteBlock').show();
			}
			if($("#serviceFilter #deactive").prop('checked')) {
				$('.None').show();
			}
			
			if($("#serviceFilter #active").prop('checked') && $("#serviceFilter #quoteschk").prop('checked') && $("#serviceFilter #deactive").prop('checked')) {
				if($(".custom-inner-left1.Block").length <= 0 && $(".custom-inner-left1.QuoteBlock").length <= 0 && $(".custom-inner-left1.None").length <= 0){
					$('#serviceContractErrorMessage').css({'display' : 'block'});
				}
			}
		}

		$("#serviceFilter .filterCheck").click(function(){
			if($(this).attr('id') == 'deactive') {
				if($("#serviceFilter #deactive").prop('checked')) {
					$('.None').show();
				}
				else {
					$('.None').hide();
				}
			}
			if($(this).attr('id') == 'active') {
				if($("#serviceFilter #active").prop('checked')) {
					$('.Block').show();
				}
				else {
					$('.Block').hide();
				}
			}
			if($(this).attr('id') == 'quoteschk') {
				if($("#serviceFilter #quoteschk").prop('checked')) {
					$('.QuoteBlock').show();
				}
				else {
					$('.QuoteBlock').hide();
				}
			}
			 if($('div.custom-inner-left1.Block').is(':visible') || $('div.custom-inner-left1.QuoteBlock').is(':visible')|| $('div.custom-inner-left1.None').is(':visible')) {
			 //if($('.ui-listview div.custom-inner-left1').is(':visible')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
				 $('.custom-search-error').css({'display' : 'none'});
			 }
			 else { 
				 $('#serviceContractErrorMessage').css({'display' : 'block'});
			 }
			 if(!$("#serviceFilter #quoteschk").prop('checked') && !$("#serviceFilter #active").prop('checked') && !$("#serviceFilter #deactive").prop('checked')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
		});
		$("#repairFilter .filterCheck").click(function(){
			
			if($(this).attr('id') == 'active') {
				if($("#repairFilter #active").prop('checked')) {
					$('.onDemandOrderBlock').show();
				}
				else {
					$('.onDemandOrderBlock').hide();
				}
			}
			if($(this).attr('id') == 'orderschk') {
				if($("#repairFilter #orderschk").prop('checked')) {
					$('.onDemandBlock').show();
				}
				else {
					$('.onDemandBlock').hide();
				}
			}
			 if($('div.custom-inner-left1.onDemandBlock').is(':visible') || $('div.custom-inner-left1.onDemandOrderBlock').is(':visible')) {
			 //if($('.ui-listview div.custom-inner-left1').is(':visible')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
				 $('.custom-search-error').css({'display' : 'none'});
			 }
			 else { 
				 $('#serviceContractErrorMessage').css({'display' : 'block'});
			 }
			 if(!$("#repairFilter #orderschk").prop('checked') && !$("#repairFilter #active").prop('checked') && !$("#repairFilter #deactive").prop('checked')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
		});
		/* DCCOM - 4527 */
		$("#renewService").click(function(){
			//$("#repairService").removeClass('active');
			$("#repairOrder,#repairService,#repairQuotes").removeClass('active');
			$("#renewService").addClass('active');
			//$(".showFilters,.custom-form").show();
			$('.custom-search-error').css({'display' : 'none'});
			$('#serviceFilter').show();
			$('#repairFilter').hide();
			$('.Block,.QuoteBlock,.None').removeClass('ui-screen-hidden');
			$(".custom-right-wrappping li#renewFaqLink").show();
			$('.custom-left-group div.onDemandBlock').hide();
			$('.custom-left-group div.onDemandOrderBlock').hide();
			$('#repairQuoteLink,#repairQuotePMLink').hide();
			

			 if($("#serviceFilter #active").prop('checked')) {
				$('.Block').show();
			}
			if($("#serviceFilter #quoteschk").prop('checked')) {
				$('.QuoteBlock').show();
			}
			if($("#serviceFilter #deactive").prop('checked')) {
				$('.None').show();
			}
			if($('div.custom-inner-left1.Block').is(':visible') || $('div.custom-inner-left1.QuoteBlock').is(':visible')|| $('div.custom-inner-left1.None').is(':visible')) {
			//if($('.ui-listview div.custom-inner-left1').is(':visible')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
			 else { 
				 $('#serviceContractErrorMessage').css({'display' : 'block'});
			 }
			  if(!$("#serviceFilter #quoteschk").prop('checked') && !$("#serviceFilter #active").prop('checked') && !$("#serviceFilter #deactive").prop('checked')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
			 $('#myFilter').attr('data-lastval','');
			 $('#myFilter').val('');
			 $('.ui-input-search a.ui-input-clear').addClass('ui-input-clear-hidden'); 
			$('.repairOrderBlock,.repairQuoteBlock').hide();
		});
		$("#repairService").click(function(){
			//$("#renewService").removeClass('active');
			$("#repairOrder,#renewService,#repairQuotes").removeClass('active');
			$("#repairService").addClass('active');
			$('.custom-search-error').css({'display' : 'none'});
			//$(".showFilters,.custom-form").hide();
			$('#serviceFilter').hide();
			$('#repairFilter').show();
			$(".custom-right-wrappping li#renewFaqLink").hide();
			$('.Block,.QuoteBlock,.None').hide();
			$('div.onDemandBlock,div.onDemandOrderBlock').removeClass('ui-screen-hidden');
			$('#repairQuoteLink,#repairQuotePMLink').show();
			
			 if($("#repairFilter #active").prop('checked')) {
				$('.onDemandOrderBlock').show();
			}
			if($("#repairFilter #orderschk").prop('checked')) {
				$('.onDemandBlock').show();
			}
			
			 if($('div.custom-inner-left1.onDemandBlock').is(':visible') || $('div.custom-inner-left1.onDemandOrderBlock').is(':visible')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
			 else { 
				 $('#serviceContractErrorMessage').css({'display' : 'block'});
			 }
			 if(!$("#repairFilter #orderschk").prop('checked') && !$("#repairFilter #active").prop('checked') && !$("#repairFilter #deactive").prop('checked')) {
				 $('#serviceContractErrorMessage').css({'display' : 'none'});
			 }
			$('#myFilter').attr('data-lastval','');
			$('#myFilter').val('');
			$('.ui-input-search a.ui-input-clear').addClass('ui-input-clear-hidden'); 
			$('.repairOrderBlock,.repairQuoteBlock').hide();
		});
		$("#repairOrder").click(function(){
			$("#renewService,#repairService,#repairQuotes").removeClass('active');
			$("#repairOrder").addClass('active');
			$('#serviceFilter,#repairFilter').hide();
			$('.repairQuoteBlock,.Block,.onDemandOrderBlock').hide();
			$('.repairOrderBlock').show();
			$('#serviceContractErrorMessage').hide();
		});
		$("#repairQuotes").click(function(){
			$("#renewService,#repairService,#repairOrder").removeClass('active');
			$("#repairQuotes").addClass('active');
			$('#serviceFilter,#repairFilter').hide();
			$('.repairQuoteBlock').show();
			$('.repairOrderBlock,.Block,.onDemandOrderBlock').hide();
			$('#serviceContractErrorMessage').hide();
		});
		  if(getUrlParam('repair_services') == 'true') {
              $('#repairService').trigger('click');
		  }
		/* DCCOM - 4527 END */
        $(".btn.close").click(function(e) {
            $(".custom-form-container ").hide();
            $(".custom-contact_form_cl")[0].reset();
            e.preventDefault();
        });
        $('.custom-message').click(function() {
            $('body').addClass('custom-scroll')
            $(document).find('div.errorMessages').hide();
			$('.custom-contact_form_cl').show();
			// AMS-69 start
			if(navigator.userAgent.indexOf('Mac') > 0) {
				$(".custom-form-radio").find("input:radio").addClass('mac-os');
			} 
			// AMS-69 end
        });
        $('.custom-service .btn').click(function() {
            $('body').addClass('custom-scroll')
        });
		
        $('.left-ext').click(function() {
            $('body').addClass('custom-scroll')
        });
        $('.custom-form-container .btn.btn-default.close,.custom-service .btn.btn-default.close,.custom-sucess-message .btn.btn-default.close,.custom-sucess-message .custom-close-btn,.btn.btn-default.close')
            .click(function() {
            $('.custom-sucess-message').hide();
            $('body').removeClass('custom-scroll')
        });
		
        if ($("input[name='pay']:checked").val() == 'invoice') {
       	 $('#invoiceTypeSelect').show();
       }
       if ($("input[name='pay']:checked").val() == 'paynow') {
       	 $('#invoiceTypeSelect').hide();	
       }
       
        $('.custom-payment-mode input:radio').on('change', function() {
            if ($("input[name='pay']:checked").val() == 'invoice') {
                $('.custom-display-container-fsp').hide();
                $('.custom-full-div-me').show();
                $('.custom-display-container').hide();
                $('.errorMessages ').hide();
                $('#btnPOPlaceOrder').show();
                $('#btnCCPlaceOrder').hide();
                $('#invoiceTypeSelect').show();
            }
            if ($("input[name='pay']:checked").val() == 'paynow') {
                $('.custom-display-container-fsp').hide();
                $('.custom-display-container').show();
                $('.custom-full-div-me').hide();
                $('#btnPOPlaceOrder').hide();
                $('#btnCCPlaceOrder').show();
                $('#invoiceTypeSelect').hide();
            }
            if ($("input[name='pay']:checked").val() == 'fsp') {
                $('.custom-display-container-fsp').show();
                $('.custom-display-container').hide();
                $('.custom-full-div-me').hide();
                $('.errorMessages ').hide();
                $('#btnPOPlaceOrder').show();
                $('#btnCCPlaceOrder').hide();
            }
        });
        $('#showPurchaseBlock').on('click',function() {
			$('#purchaseOrderSection').show();
			$('#purchaseChangeSection').hide();
			$('#btnPOPlaceOrder').removeClass('disabled-saveBtn');
			$('#btnPOPlaceOrder').addClass('enabled-saveBtn');
		});
		
		if($('#purchaseChangeSection').is(':visible') && !$('#purchaseOrderSection').is(':visible')) {
			console.log('btn disable');
			$('#btnPOPlaceOrder').removeClass('enabled-saveBtn');
			$('#btnPOPlaceOrder').addClass('disabled-saveBtn');
			
		}
		else {
//			console.log('btn enable');
			$('#btnPOPlaceOrder').removeClass('disabled-saveBtn');
			$('#btnPOPlaceOrder').addClass('enabled-saveBtn');
		}
		
		$('#cancelAutoRenewPopup #cancelBtn').on('click', function() {
			$("#cancelAutoRenewPopup  button.close").trigger('click');
		});
		
        var headerHeight = $(".affix-top").height();
        $("#bin").css("padding-top", headerHeight);

        $(document).on("click", "#downloadQuote", function(e) {
            $("#pdfQuoteDownloadForm").submit();
        });
        
        /*$(document).on("click", "#downloadChinaOrderPdf", function(e) {
            $("#pdfChinaOrderDownloadForm").submit();
        });*/

        $(document).on("click", "#downloadViewService", function(e) {
            $("#pdfViewServiceDownloadForm").submit();
        });

        $(".custom-cancel").click(function(e) {
            $('.custom-form-group #comments , div.selector select#Inquiry,.custom-form-group input, .custom-form-group select').removeAttr('style');
        });

        /* ajax on contact form */
        $(".custom-send").click(function(e) {
            e.preventDefault();
            var formid = $(this).closest('form').attr('id');
            $('.custom-pop-phone').show();
            $('.custom-pop-email').hide();
            if ($('#lphone').is(':checked')) {
                $('.custom-pop-phone').show();
                $('.custom-pop-email').hide();
            } else {
                $('.custom-pop-phone').hide();
                $('.custom-pop-email').show();
            }
            var dovalidate = CSCA.GlobalValidate.init({
                target : '#' + formid,
                action : 'submit'
            });
            if (dovalidate) {
                var data = $('#' + formid).serialize();
                $.ajax({
                    type : "POST",
                    url : "/common/myaccount/includes/ajax/ajaxCrmcontact.jsp",
                    dataType : "html",
                    data : data,
                    cache : false,
                    success : function(data) {
                        console.log(data);
						$(".custom-form-container ").hide();
                        $('.custom-send').click(function() {
                            $('body').addClass('custom-scroll')
                        });
                        $('.custom-sucess-message.popup').css({
                            "display" : "block"
                        });
						if ($('#lphone').is(':checked')) {
							if(window.innerHeight > $(".custom-sucess-message .custom-pop-phone.popup-inner").height()) {
								var parentWindowHeight = window.innerHeight - 60;
								var overLayHeight = $(".custom-sucess-message .custom-pop-phone.popup-inner").height();
								var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
								$(".custom-sucess-message .custom-pop-phone.popup-inner").css("top",calcOverlayTop+'px');
							}
						} else {
						   
							if(window.innerHeight > $(".custom-sucess-message .custom-pop-email.popup-inner").height()) {
								var parentWindowHeight = window.innerHeight - 60;
								var overLayHeight = $(".custom-sucess-message .custom-pop-email.popup-inner").height();
								var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
								$(".custom-sucess-message .custom-pop-email.popup-inner").css("top",calcOverlayTop+'px');
							}
						}
                        $(".custom-contact_form_cl")[0].reset();
                    },
                    error : function(x, t, m) {
                        console.log('Something went wrong!')
                    }
                });
            } else {
                $(document).find('div.errorMessages').show();
            }
        });

        // For Redeem Quote Flow
        $('.redQuote input:radio').on('change', function() {
        	if((!$('#mainContainer').is('.checkoutShippingBilling')) && (!$('#mainContainer').is('.largeCheckout'))){
        		redeemQuotePaymentSelection();
        	}
        });

        
        
		//LMS Order flow 
		$('#lms-order input:radio').on('change', function() {
			var poMsg = $("#poNumRequiredErrorMessage").val();
            if ($("input[name='pLmsOrder']:checked").val() == 'creditCard') {
                $('#invoice-order').hide();
				$('.credit-order').show();	
				$('#po').removeClass('invoice-val invalid');
				if($('.errorMessages').children().length == 1 && $('.errorMessages').children()[0].innerText == poMsg){
				  $('.errorMessages').css('display','none');	
				}
				$('.po-alert').css('display','none');
	            $('#lmsBtnPOSubmitOrder').hide();
	            $('#lmsBtnCCSubmitOrder').show();
            }
            if ($("input[name='pLmsOrder']:checked").val() == 'purchaseOrder') {
				$('.credit-order').hide();
				$('#invoice-order').show();
				$('#po').addClass('invoice-val');
	            $('#lmsBtnPOSubmitOrder').show();
	            $('#lmsBtnCCSubmitOrder').hide();
            }
        });
		
		$("#custom-popup-close").click(function(e) {
            $(".custom-form-container ").hide();
            $(".custom-contact_form_cl")[0].reset();
			$('.custom-sucess-message').hide();
            $('body').removeClass('custom-scroll')
            e.preventDefault();
        });
	    
        });
var CSCA = {
    // Global form validation for all type of forms
    GlobalValidate : {
        init : function(options_) {
            var formErrorId = options_.target;
            var gtg = true, flagArr = [], msgArr = [], alrtmsg = '', vclass = [ 'required', 'alpha', 'num', 'alphanum', 'chkrequired', 'selectone', 'email', 'confirm2' ];
            els = $(options_.target).map(function() {
                return $.makeArray(this.elements);
            });
            els.each(function(i) {
                for (c in vclass) {
                    if ($(els[i]).hasClass(vclass[c])) {
                        gtg = CSCA.GlobalValidate.doValidate.validate(vclass[c], $(els[i]));
                        $.each(gtg, function(i, v) {
                            if (i === 0)
                                msgArr.push(v);
                            if (i === 1)
                                flagArr.push(v);
                        })
                    }
                }
            });
            $.each(msgArr, function(i, v) {
                if (v != '')
                    alrtmsg += v.replace(/[<>\///';]+/g, '') + '</br>';
            });
            if (alrtmsg != '') {

                alrtmsg = '<div class="alert alert-dismissable alert-danger">' + alrtmsg + '</div>';
                $(document).find('div.errorMessages').hide();
                $(document).find('div.errorMessages').html(alrtmsg);
                $(document).find('div.errorMessages').show();
                $(document).scrollTop($(document).find('div.errorMessages').position('top'));
            }
            return ($.inArray(false, flagArr) == -1) ? true : false;
        },
        doValidate : {
            validate : function(casechk, element) {
                var chk = false, msg = element.attr('title'), rspobj = [], formval = $.trim(element.val()), msgname = element.attr('id');
                if (casechk === 'required') {
                    if ($.trim(formval) === '') {
                        msg = msg || 'This field is required.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'alpha') {
                    if (/[^a-zA-Z]+$/.test(formval)) {
                        msg = msg || 'Please enter alphabets only.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'num') {
                    if (/[^0-9]+$/.test(formval)) {
                        msg = msg || 'Please enter numeric value only.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'alphanum') {
                    if (/[^a-zA-Z0-9\._-]+$/.test(formval)) {
                        msg = msg || 'Please enter alphnumrics only.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'selectone') {
                    if (formval == '' || element.val() == 0) {
                        msg = msg || 'Please select one.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'chkrequired') {
                    if (!element.attr('checked')) {
                        msg = msg || 'This field is required.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'email') {
                    if (formval != '') {
                        var mailarr = element.val(), f = true;
                        mailarr = mailarr.split(',');
                        $.each(mailarr, function(i, v) {
                            if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
                                f = false;
                        });
                        if (!f) {
                            msg = msg || 'Email is not valid.';
                            CSCA.GlobalValidate.showError(element, '');
                            chk = false;
                            rspobj.push(msg, chk);
                        } else {
                            CSCA.GlobalValidate.hideError(element);
                            chk = true;
                            rspobj.push('', chk);
                        }
                    } else if (formval == '' || element.val() == 0) {
                        msg = 'Email address is required.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    }
                } else if (casechk === 'confirm2') {
                    var pass1 = element.val(), pass2 = $('.confirm1').val();
                    if (pass1 != pass2 || pass1 == '') {
                        msg = msg || 'Confirm password is not same.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    } else {
                        CSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                }
                if (element.attr('minchar') != 'undefined' || element.attr('minchar') != '') {
                    if (formval.length < parseInt(element.attr('minchar'))) {
                        msg = msg || 'Please enter minimum ' + element.attr('minchar') + ' character.';
                        CSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    }
                } else {
                    CSCA.GlobalValidate.hideError(element);
                    chk = true;
                    rspobj.push('', chk);
                }
                return rspobj;
            }
        },
        showError : function(element, msg) {
            msgui = '<div class="alert alert-dismissable alert-danger">' + msg + '</div>';
            $(element).css({
                "border-color" : "#e84b4c",
                "border-weight" : "1px",
                "border-style" : "solid"
            });
            if (msg != '') {
                $(document).find('div.errorMessages').hide();
                $(document).find('div.errorMessages').html(msgui);
                $(document).find('div.errorMessages').show();
                $(document).scrollTop($(document).find('div.errorMessages').position('top'));
            }
        },
        hideError : function(element) {
            $(element).css('border-color', '');
            $(document).find('div.errorMessages').hide();
        }
    }
}
$(document).ready(function() {
    $("#uniform-Inquiry option").click(function() {
        $("#uniform-Inquiry option").removeClass("active");
        $(this).addClass("active");
    });
    $(".custom-modal-top .close").click(function() {
        $(document).find('div.errorMessages:eq(0)').html('');
        $(".errorMessages").css({
            'display' : 'none'
        });
        $(".custom-contact_form_cl")[0].reset();
    });
    $("#applypromoecode").click(function(e) {
        if (validateCoupons()) {
            $('#dynamicPromoBean').val(false);
            $("#couponCodeBean").val($("#couponCodeId").val());
            $('#sbmtCoupon').click();
        }
    });
    $('#enablementanchor').on('click', function (event) {
        event.preventDefault();
        var email = $('#enablementEmailId').val();
        var subject = 'Customer Enablement Mail';
        var emailBody = '\n\n\n' + $('#enablementanchor').text() + '\n\n\n\n\n';
        window.location = 'mailto:' + encodeURIComponent(email) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(emailBody);
    });
    $('#btnConfirmationContinue').on('click', function (event) {
        var lmsReturnUrl = $.cookie('ATG_LANDING');
        if (isNotEmptyVal(lmsReturnUrl) && lmsReturnUrl != 'null' && lmsReturnUrl.indexOf('isLMSUser') != -1) {
            lmsReturnUrl = decodeURIComponent(lmsReturnUrl);
        } else if (isNotEmptyVal(lmsReturnUrl) && lmsReturnUrl != 'null' && lmsReturnUrl.indexOf('loginsso') != -1 && isNotEmptyVal($("#enableLMSFlag").val()) && $("#enableLMSFlag").val() == 'true') {
            lmsReturnUrl = $("#lmsLoginPage").val();
        } else {
            lmsReturnUrl = $("#btnConfirmationRedirectUrl").val();
        }
        $(location).attr("href", lmsReturnUrl);
    });
	
	var emailCheck = false;	
	$('#emailCheck').on('click', function () {
		if ($('#inputEmail').val() == '') {
			$('#inputEmail').addClass('requiredTextBox');
			$('#emailRequiredMsg').show();
			$('#emailNotValidMsg').hide();
			emailCheck = true;
		}
		else {
			$('#inputEmail').removeClass('requiredTextBox');
			$('#emailRequiredMsg').hide();
			emailCheck = false;
			var mailarr = $('#inputEmail').val(), f = true;
			mailarr = mailarr.split(',');
			$.each(mailarr, function(i, v) {
				//if (!(/^([a-zA-Z0-9])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/.test($.trim(v))))
				if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
					f = false;
			});
			if (!f) {
				$('#inputEmail').addClass('requiredTextBox');
				$('#emailRequiredMsg').hide();
				$('#emailNotValidMsg').show();
				emailCheck = true;
			}
			else {
				$('#inputEmail').removeClass('requiredTextBox');
				$('#emailRequiredMsg').hide();
				$('#emailNotValidMsg').hide();
				emailCheck = false;
			}
		}
		if(!emailCheck) {
			$('#emailSbmt').click();						
			$('.loading').show();
			$('.loadinggif').addClass('active');
		}
	});
	$("#inputEmail").on('keyup paste', function() {
		if($('#inputEmail').val() == "") {
			$('#emailCheck').addClass('disabled-saveBtn');
		}
		else {
			$('#emailCheck').removeClass('disabled-saveBtn');
		}
	});
	$(document).on("keypress", "#inputEmail", function(e) {
		if (e.which == 13) {
		   return false;		   
        }				
	});
});
$(window).on("load",function() {
    if ($('.popup .custom-service-pop-grp .custom-popup-bot-div').length > 0) {
        $('.custom-popup-bot-div').closest('.custom-tab-data').removeClass("custom_null");
		$('.custom-popup-bot-div').closest('.custom-tab-data').addClass("hasDesc");
    } else {
        $('.custom-service p').removeClass("custom_null");
    }
	$('.custom-covered.accordion .hasDesc p.service_plan span.serviceName').each(function() {
		var formatedText = stringTruncation($(this).text(), 19);
		$(this).text(formatedText);
	});
});

function validateCoupons() {
    var flag = true;
    var couponCodes = $("#couponCodeId").val();
    var erroMsg = checkCouponsAndReturnMsg(couponCodes);
    if (!isEmpty(erroMsg)) {
        flag = false;
        msgui = '<div class="alert alert-dismissable alert-danger">' + erroMsg + '</div>';
        $(document).find('div.alert-success').hide();
        $(document).find('div.errorMessages').hide();
        $(document).find('div.couponCodeOnClickValidationErrorMessage').hide();
        $(document).find('div.couponCodeOnClickValidationErrorMessage').html(msgui);
        $(document).find('div.couponCodeOnClickValidationErrorMessage').show();
        $(document).scrollTop($(document).find('div.couponCodeOnClickValidationErrorMessage').position('top'));
    }
    return flag;
}

function checkCouponsAndReturnMsg(couponCodes) {
    var errorMsg = "";
    var emptyCouponCodeErrMsg = $('#emptyCouponCodeError').val();
    var invalidCouponCodeErrMsg = $('#invalidCouponCodeError').val();
    var invalidCouponCodesErrMsg = $('#invalidCouponCodesError').val();
    var maxCouponCodesErrMsg = $('#maxCouponCodesError').val();
    var maxAllowedPromotions = $("#maxAllowedPromotions").val();
    var multiPromoForMembersEnabled = $("#multiPromoForMembersEnabled").val();
    var isPunchoutUser = $("#isPunchoutUser").val();
    var memberType = $("#memberType").val();
    // Trimming first and last comma if any
    var trimmedCouponCodes = couponCodes.replace(/^,|,$/g,'');
    // Trimming space
    trimmedCouponCodes = trimmedCouponCodes.replace(" ", "");
    // RgEx to be used for only alphanumeric with comma
    var couponsRegEx = /^[A-Za-z0-9]+(,[A-Za-z0-9]+)*$/;
    // Check the coupon codes count
    var couponCodesCount = checkCouponCodesCount(trimmedCouponCodes);
    if (couponCodesCount == 0) {
        errorMsg = emptyCouponCodeErrMsg;
    }
    if (isEmpty(errorMsg) && isPunchoutUser == "true" && couponCodesCount > 1) {
        errorMsg = invalidCouponCodeErrMsg;
    }
    if (isEmpty(errorMsg) && memberType == "member" && multiPromoForMembersEnabled == "false" && couponCodesCount > 1) {
        errorMsg = invalidCouponCodeErrMsg;
    }
    if(isEmpty(errorMsg) && !couponsRegEx.test(trimmedCouponCodes)) {
        if (couponCodesCount == 1) {
            errorMsg = invalidCouponCodeErrMsg;
        } else {
            errorMsg = invalidCouponCodesErrMsg;
        }
    }
    if(isEmpty(errorMsg) && couponCodesCount > maxAllowedPromotions) {
        errorMsg = maxCouponCodesErrMsg;
    }
    // Update the coupon codes after removing unwanted typo errors
    $("#couponCodeId").val(trimmedCouponCodes);
    
    return errorMsg;
}

function checkCouponCodesCount(couponCodes) {
    var count = 0;
    if (!isEmpty(couponCodes)) {
        // Splitting the comma for count
        count = couponCodes.split(",").length
    }
    return count;
}

function isEmpty(inputStr) {
    var flag = false;
    var EMPTYREGEX = /^\s*$/;
    if (inputStr == null || EMPTYREGEX.test(inputStr)) {
        flag = true;
    }
    return flag;
}

function isNotEmptyVal(obj) {
    if (obj !== undefined && obj !== null && !$.isEmptyObject(obj)) {
        return true;
    } else {
        return false;
    }
}

function checkEnablement() {
	$("#erroeMessages_outer").hide();
	$("#successMessages_outer").hide();
    $.ajax({
        type : "GET",
        url : "/common/includes/ajax/ajaxReadyToUseCart.jsp",
        dataType : "html",
        cache : false,
        success : function(data) {
            console.log(data);
            if (!isEmpty(data)) {
                // DCCOM-5884 
                $("#enablementanchor").html(data);
                $("#enablementanchor").attr("href", $("#enablementanchor").text());
                if ($('#copyBtnUrl').length == 0) {               
                	$("<button type='button' style='display:block' id='copyBtnUrl' class='copyUrl btn-stnd-medium'>Copy Url</button>").insertAfter("#enablementanchor");
                	    var copyBtn = document.querySelector('#copyBtnUrl');  
                	    copyBtn.addEventListener('click', function(event) {  
                	    var anchorLink = document.querySelector('#enablement a');  
                	    var range = document.createRange();  
                	    range.selectNode(anchorLink);  
                	    window.getSelection().addRange(range);  
                	    var successful = document.execCommand('copy');  
                	    var msg = successful ? 'successful' : 'unsuccessful';  
                	    window.getSelection().removeAllRanges();  
                	});
                	}
            } else {
                $("#enablement-messages").removeClass("alert alert-success");
                $("#enablement-messages").addClass("alert alert-dismissable alert-danger");
                $("#enablement").html($('#enablementErrMsg').val());
                $("#enablementBtn").hide();
            }
        },
        error : function() {
            console.log('Something went wrong!')
        }
    });
}



$(document).ready(function() {
	if ($("#mainContainer").hasClass('serviceContract')) {
		$('.loading').fadeOut();	
		$(document).scroll(function() {			
			$("body").trigger("click");
		});
		$("form").bind("keypress", function (e) {
			if (e.keyCode == 13) {
				if($('#requestRepairQuote').attr('aria-hidden') == 'false'){
					$("#submitRepairQuote").trigger('click');
				} else if($('#requestRepairPMQuote').attr('aria-hidden') == 'false'){
					$("#submitRepairPMQuote").trigger('click');
				} 				
				return false;
			}
		});		
	}
	$("#repairQuote #describeIssue").attr("placeholder", $('#describeIssueText').val()); 
	$("#repairPMQuote #describeIssue").attr("placeholder", $('#describeIssueText').val()); 
	/*$("#orderStartDate").datepicker({
			 minDate : '+1D',		
			 onSelect : function(selected) {
				 
			 }
	}).attr('readonly', true);

	$("#orderEndDate").datepicker({
			 minDate : '+1D',		
			 onSelect : function(selected) {
				 
			 }
	}).attr('readonly', true);*/
	
	$('#triggerOrderDate').click(function(){
		$('#orderStartDate').next().hide();
		$('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
		$('#orderStartDate').removeClass('requiredTextBox');
		$('#orderStartDate').css('border-color', '');
		$('#orderEndDate').next().hide();
		$('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
		$('#orderEndDate').removeClass('requiredTextBox');
		$('#orderEndDate').css('border-color', '');
		/*$('#startDate').next().hide();*/
		$('#startDate').prev('.fieldLabel').removeClass('requiredLabel');
		$('#startDate').removeClass('requiredTextBox');
		$('#startDate').css('border-color', '');
		/*$('#endDate').next().hide();*/
		$('#endDate').prev('.fieldLabel').removeClass('requiredLabel');
		$('#endDate').removeClass('requiredTextBox');
		$('#endDate').css('border-color', '');
		$('#orderStartDate,#orderEndDate,#startDate,#endDate').val('');
		
		setTimeout(function() {
			if (window.innerHeight > 243) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = 243;
				var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
				$("#selectOrderDate .modal-content").css("top", calcOverlayTop + 'px');
			}
		}, 200);
	});
	
	/*$(document).on('click', '#submitOrderDate', function(e) {		
        var dovalidate = LSCA.GlobalValidate.init({
            target : '#dateRange'
        });
        //console.log(dovalidate);
		
        if (dovalidate) {
			
		}else{
			 if ($('#orderStartDate').val() == "") {
                $('#orderStartDate').next().css('display', 'inline-block');
                $('#orderStartDate').prev('.fieldLabel').addClass('requiredLabel');
                $('#orderStartDate').addClass('requiredTextBox');				
            } else {
                $('#orderStartDate').next().hide();
                $('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
                $('#orderStartDate').removeClass('requiredTextBox');
            }
			if ($('#orderEndDate').val() == "") {
                $('#orderEndDate').next().css('display', 'inline-block');
                $('#orderEndDate').prev('.fieldLabel').addClass('requiredLabel');
                $('#orderEndDate').addClass('requiredTextBox');				
            } else {
                $('#orderEndDate').next().hide();
                $('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
                $('#orderEndDate').removeClass('requiredTextBox');
            }
		}
	});*/
	
	/* RRQ */
	var modelNumbers = [];
	var modelAndSerialObjects = {};
	var serialNumbers = [];
	var serialNumberss = [];
	var serialAndModalObjects = {};
	function getRepairQuoteFields(){
		var fieldArr = ['#instrumentType', '#instrumentSerialNo', '#modelNumber', '#resType', '#repairZipCode', '#repairPhoneNumber', '#repairEmail', '#describeIssue'];
		return fieldArr;
	}
	
	function getRepairQuotePMFields(){
		var fieldArr = ['#repairPMQuote #instrumentType', '#repairPMQuote #instrumentSerialNo', '#repairPMQuote #modelNumber', '#repairPMQuote #insturmentAddress', '#repairPMQuote #repairCity', '#repairPMQuote #repairState', '#repairPMQuote #repairZipCode', '#repairPMQuote #repairCountry','#repairPMQuote #repairPhoneNumber', '#repairPMQuote #repairEmail', '#repairPMQuote #describeIssue'];
		return fieldArr;
	}
	
	function clearErrorMessage(fieldArr){
		for(i=0; i < fieldArr.length; i++){
				hideErrorMessage(fieldArr[i]);
				$(fieldArr[i]).removeAttr("style");
			}
			$('#insType').removeClass('requiredTextBox');
			$('#resTime').removeClass('requiredTextBox');
	}

	function clearFields(fieldArr){
		for(i=0; i < fieldArr.length; i++){				
			if(fieldArr[i] != '#repairZipCode' && fieldArr[i] != '#repairPhoneNumber' && fieldArr[i] != '#repairEmail'){
				$(fieldArr[i]).val("");
			}
			}
		$("#instrumentType").val("").change();
		$("#resType").val("").change();
	}
	
	function isEmptyCheck(elementId){
		var fieldVal = $(elementId).val();
		if(fieldVal == "" || fieldVal === null){
			return true;
		}else {
			return false;
		}
	}
	function showErrorMessage(elementId){
		$(elementId + 'Err').css('display', 'inline-block');
		$(elementId + 'Lbl').addClass('requiredLabel');
		$(elementId).addClass('requiredTextBox');						
	}
	
	function hideErrorMessage(elementId){
		$(elementId + 'Err').hide();
		$(elementId + 'Lbl').removeClass('requiredLabel');
		$(elementId).removeClass('requiredTextBox');						
	}
	
	function prePopulateData(){
		$('#repairQuote #repairZipCode').val($('#repairQuote #repairZipCodeHidden').val());
		$('#repairQuote #repairPhoneNumber').val($('#repairQuote #repairPhoneNumberHidden').val());
		$('#repairQuote #repairEmail').val($('#repairQuote #repairEmailHidden').val());
		$('#repairPMQuote #repairZipCode').val($('#repairPMQuote #repairZipCodeHidden').val());
		$('#repairPMQuote #repairPhoneNumber').val($('#repairPMQuote #repairPhoneNumberHidden').val());
		$('#repairPMQuote #repairEmail').val($('#repairPMQuote #repairEmailHidden').val());
	}
	
	function isNotEmpty(obj) {
			if (obj !== undefined && obj !== null && !$.isEmptyObject(obj)) {
				return true;
			} else {
				return false;
			}
		}
		
	  function validateArray(dataContent){
		if(Array.isArray(dataContent) && dataContent.length === 0){
			return true;
		}
	 }
	var reducedRecords;
	$('#triggerRequestQuote').click(function(){
		$("body").addClass("repairServiceHandle");
		var repairFields = getRepairQuoteFields();
			clearErrorMessage(repairFields);
			clearFields(repairFields);
			$('#submitRepairQuote').prop('disabled', false);
			$('#submitRepairQuote').removeClass('btn-disabled-state');
		hideModelSerialErr('#repairQuote #modelNumber');
		hideModelSerialErr('#repairQuote #instrumentSerialNo');
		$('#repairZipCodeErrMsg').hide();
		$('#insType span.repairDropdown').addClass('defaultSelect');
		$('#resTime span.repairDropdown').addClass('defaultSelect');
		prePopulateData();
				
		setTimeout(function() {
			if (window.innerHeight > 830) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = 830;
				var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
				$("#requestRepairQuote .modal-content").css("top", calcOverlayTop + 'px');
			}
		}, 200);		

		function getModelAndSerial() {
			LSCA.loadingSpinner.showLoading();
			$.ajax({
				type : "GET",
				//url : "/common/js/serialmodel1.json",
				url : "/rest/model/com/agilent/commerce/FetchSerialAndModelNumService/fetchPMQuote?atg-rest-output=json&_=1585031393932",
				cache : false,
				//dataType: "json",
				success : function(resultData) {
					//console.log(resultData.fetchPMQuote.PMQuoteDetails.length);	
					constructModelSerial(resultData);
					LSCA.loadingSpinner.hideLoading();
				},
				error : function() {
					console.log('Service call failed');
					LSCA.loadingSpinner.hideLoading();
				}
			});
		}
		
		if(validateArray(serialNumbers)){
			getModelAndSerial();
		}
		
		
		
		function constructModelSerial(resultData){
			var tmpSerialNum = [];
			reducedRecords = false;
			if(isNotEmpty(resultData.fetchPMQuote.PMQuoteDetails)){
				serialAndModalObjects = resultData.fetchPMQuote.PMQuoteDetails;
				$(serialAndModalObjects).each(function(key, dataObj){		
					if(dataObj.serialNum.indexOf('ReducedRecords') != -1){
						reducedRecords = true;
						if(dataObj.serialNum.indexOf('|') != -1){
							dataObj.serialNum.split('|')[1];
							tmpSerialNum.push(dataObj.serialNum.split('|')[1]);							
						}
					}else{
						tmpSerialNum.push(dataObj.serialNum);
					}					
				});
				serialNumbers = tmpSerialNum;				
				}
			serialAutoSuggest(serialNumbers);
		}	
				
	});
	$("#repairPMQuote #instrumentType").change(function(){
		//$("#repairPMQuote #insType").removeClass('requiredTextBox');
		$("#repairPMQuote #insType #instrumentType").removeClass('requiredTextBox');
		$("#repairPMQuote #insType span.repairDropdown").removeClass('requiredTextBox');
	});
	$('#triggerRequestPMQuote').click(function(){
		$("body").addClass("repairServiceHandle");
		var repairFields = getRepairQuotePMFields();
			clearErrorMessage(repairFields);
			clearFields(repairFields);
			//$('#repairPMQuote #instrumentType, #repairPMQuote #instrumentSerialNo, #repairPMQuote #modelNumber, #repairPMQuote #insturmentAddress, #repairPMQuote #repairCity, #repairPMQuote #repairState, #repairPMQuote #repairZipCode, #repairPMQuote #repairCountry,#repairPMQuote #repairPhoneNumber, #repairPMQuote #repairEmail, #repairPMQuote #describeIssue').val('');
			//$("#repairPMQuote input").parent().prev().removeClass('requiredLabel');
			$("#repairPMQuote #instrumentType").val("").change();
			$("#repairPMQuote #resType").val("").change();
			$("#repairPMQuote #insType span.repairDropdown,#repairPMQuote #insType").removeClass('requiredTextBox');
			$('#submitRepairPMQuote').prop('disabled', false);
			$('#submitRepairPMQuote').removeClass('btn-disabled-state');
		hideModelSerialErr('#repairPMQuote #modelNumber');
		hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
		$('#repairPMQuote #repairZipCodeErrMsg').hide();
		$('#repairPMQuote #insType span.repairDropdown').addClass('defaultSelect');
		prePopulateData();
		setTimeout(function(){ 
			$("#requestRepairPMQuote .modal-dialog").css("top", '0px');
			if (window.innerHeight > $("#requestRepairPMQuote .modal-dialog").outerHeight(true)) {
				var parentWindowHeight = window.innerHeight;
				var overLayHeight = $("#requestRepairPMQuote .modal-dialog").outerHeight(true);
				var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
				console.log("parentWindowHeight : " + parentWindowHeight);
				console.log("overLayHeight : " + overLayHeight);
				console.log("calcOverlayTop : " + calcOverlayTop);
				$("#requestRepairPMQuote .modal-dialog").css("top", calcOverlayTop + 'px');
			}
		},500);
		
		function getSerialAndModal() {
			LSCA.loadingSpinner.showLoading();
			$.ajax({
				type : "GET",
				//url : "/common/js/serialmodel1.json",
				url : "/rest/model/com/agilent/commerce/FetchSerialAndModelNumService/fetchPMQuote?atg-rest-output=json&_=1585031393932",
				cache : false,
				//dataType: "json",
				success : function(resultData) {
					//console.log(resultData.fetchPMQuote.PMQuoteDetails.length);	
					constructSerialModel(resultData);
					LSCA.loadingSpinner.hideLoading();
				},
				error : function() {
					console.log('Service call failed');
					LSCA.loadingSpinner.hideLoading();
				}
			});
		}
		
		if(validateArray(serialNumberss)){
			getSerialAndModal();
		}
		
		function constructSerialModel(resultData){
			var tmpSerialNum = [];
			reducedRecords = false;
			if(isNotEmpty(resultData.fetchPMQuote.PMQuoteDetails)){
				serialAndModalObjects = resultData.fetchPMQuote.PMQuoteDetails;
				$(serialAndModalObjects).each(function(key, dataObj){
					if(dataObj.serialNum.indexOf('ReducedRecords') != -1){
						reducedRecords = true;
						if(dataObj.serialNum.indexOf('|') != -1){
							dataObj.serialNum.split('|')[1];
							tmpSerialNum.push(dataObj.serialNum.split('|')[1]);							
						}
					}else{
						tmpSerialNum.push(dataObj.serialNum);
					}						
				});
				serialNumberss = tmpSerialNum;				
				}
			serialPMAutoSuggest(serialNumberss);
		}
	});

	$('#repairCancelBtn').click(function() {
        $("#requestRepairQuote span.newCloseIcon").trigger('click');
    });	
	
	$('#repairPMCancelBtn').click(function() {
        $("#requestRepairPMQuote span.newCloseIcon").trigger('click');
    });	

	function showModelSerialErr(elementId){
		$(elementId + 'Invalid').css('display', 'inline-block');
		$(elementId + 'Lbl').addClass('requiredLabel');
		$(elementId).addClass('requiredTextBox');
	}
	
	function hideModelSerialErr(elementId){
		$(elementId + 'Invalid').hide();
		$(elementId + 'Lbl').removeClass('requiredLabel');
		$(elementId).removeClass('requiredTextBox');						
	}
	
	function validateZipCode(elementValue){
		var zipCodePattern = /^\d{5}$|^\d{5}-\d{4}$/;
		return zipCodePattern.test(elementValue);
	}
	
	function findSerial(objData, modelNumber) {
		for (var i = 0; i < objData.length; i++) {
			if (objData[i].modelNumber == modelNumber) {
				return objData[i];
			}
		}
		return {};
	}
	
	function findModalCheck(objData, serialNumber) {
		for (var i = 0; i < objData.length; i++) {
			if (objData[i].serialNum == serialNumber) {
				return objData[i];
			}
		}
		return {};
	}
	
	function findModal(objData, serialNumber) {
		for (var i = 0; i < objData.length; i++) {
			if (objData[i].serialNum == serialNumber) {
				if(isNotEmpty(objData[i].modelNo)){
					$("#repairPMQuote #modelNumber").val(objData[i].modelNo);
					//hideErrorMessage('#repairPMQuote #modelNumber'); 
					//hideModelSerialErr('#repairPMQuote #modelNumber');
					$('#repairPMQuote #modelNumber').removeAttr('style');
					$("#repairQuote #modelNumber").val(objData[i].modelNo);
					$('#repairQuote #modelNumber').removeAttr('style');						
				}
				if(isNotEmpty(objData[i].street)){
					$("#repairPMQuote #insturmentAddress").val(objData[i].street);
					//hideErrorMessage('#repairPMQuote #insturmentAddress'); 
					$('#repairPMQuote #insturmentAddress').removeAttr('style');
				}
				if(isNotEmpty(objData[i].city)){
					$("#repairPMQuote #repairCity").val(objData[i].city);
					//hideErrorMessage('#repairPMQuote #repairCity'); 
					$('#repairPMQuote #repairCity').removeAttr('style');
				}
				if(isNotEmpty(objData[i].region)){
					$("#repairPMQuote #repairState").val(objData[i].region);
					//hideErrorMessage('#repairPMQuote #repairState'); 
					$('#repairPMQuote #repairState').removeAttr('style');
				}
				if(isNotEmpty(objData[i].country)){
					$("#repairPMQuote #repairCountry").val(objData[i].country);
					//hideErrorMessage('#repairPMQuote #repairCountry'); 
					$('#repairPMQuote #repairCountry').removeAttr('style');
				}
			}
		}
	}
		
	function notValidModelSerial(serviceDatas, userSelected){
		if (serviceDatas.length > 0 && serviceDatas.indexOf(userSelected) === -1) {
			return true;
		}else{
			return false;
		}
	}
	
	function notValidSerialModel(dataObject, serNum, modNum){
		var serObj = findModalCheck(dataObject, serNum);
		if(isNotEmpty(serObj) && isNotEmpty(serObj.modelNo) && serObj.modelNo !== modNum){
			return true;
		}
		else {
			return false;
		}
	}
	
	function notValidPMSerial(serviceDatas, userSelected){
		if (serviceDatas.length > 0 && serviceDatas.indexOf(userSelected) === -1) {
			return true;
		}else{
			return false;
		}
	}
	
	function notValidSerial(serviceDatas, userSelected){
		if (serviceDatas.length > 0 && serviceDatas.indexOf(userSelected) === -1) {
			return true;
		}else{
			return false;
		}
	}
	
	$('#submitRepairQuote').click(function() {
        var dovalidate = LSCA.GlobalValidate.init({
            target : '#repairQuote'
        });
        
		
 		var modelNo = $('#repairQuote #modelNumber').val();
		var serialNo = $('#repairQuote #instrumentSerialNo').val();
		var submitForm = true;		
        if (dovalidate) {
			var fieldList = getRepairQuoteFields();
			clearErrorMessage(fieldList);		

			
			if (isEmptyCheck('#repairQuote #instrumentType')) {
                showErrorMessage('#repairQuote #instrumentType');
				$('#repairQuote #insType').addClass('requiredTextBox');	
					submitForm = false;
			}else{
				hideErrorMessage('#repairQuote #instrumentType');
				$('#repairQuote #insType').removeClass('requiredTextBox');	
				} 
			if(!reducedRecords){	
			if(notValidSerialModel(serialAndModalObjects, serialNo, modelNo)){
				showModelSerialErr('#repairQuote #modelNumber');
				submitForm = false;
			}else{
					hideModelSerialErr('#repairQuote #modelNumber');
				}
			if(notValidSerial(serialNumbers,  serialNo)){				
				showModelSerialErr('#repairQuote #instrumentSerialNo');
				submitForm = false;
			}else{
				hideModelSerialErr('#repairQuote #instrumentSerialNo');
			}
			}
			if (isEmptyCheck('#resType')) {
                showErrorMessage('#resType');
				$('#resTime').addClass('requiredTextBox');
				submitForm = false;
            } else {
                hideErrorMessage('#resType');
				$('#resTime').removeClass('requiredTextBox');
            }
			
			//if(!validateZipCode($('#repairZipCode').val())){
			if(!/^[a-z\d\-\s]+$/i.test($.trim($('#repairZipCode').val()))){		
				$('#repairZipCodeErrMsg').css('display', 'inline-block');
				$('#repairZipCodeLbl').addClass('requiredLabel');
				$('#repairZipCode').addClass('requiredTextBox');
				submitForm = false;
		}else{
				$('#repairZipCodeErrMsg').hide();
				$('#repairZipCodeLbl').removeClass('requiredLabel');
				$('#repairZipCode').removeClass('requiredTextBox');	
			}
			
			if ($('#repairEmail').val() != '') {
                var mailarr = $('#repairEmail').val(), f = true;                                
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                        f = false;                
                if (!f) {
                    $('#repairEmailErr').text($('#emailValidationMsg').val());
                    showErrorMessage('#repairEmail');
					submitForm = false;
				}else{
					 hideErrorMessage('#repairEmail');
				} 
			}												
			if (isEmptyCheck('#repairQuote #repairZipCode')) {
                showErrorMessage('#repairQuote #repairZipCode');
            } else {
                hideErrorMessage('#repairQuote #repairZipCode');
            }
				
			if (isEmptyCheck('#repairQuote #repairPhoneNumber')) {
                showErrorMessage('#repairQuote #repairPhoneNumber');
            } else {
                hideErrorMessage('#repairQuote #repairPhoneNumber');
            }
			
			if(submitForm === true){
				$("#requestRepairFormSubmit").trigger('click');
				LSCA.loadingSpinner.showLoading();
				$('#repairQuote #submitRepairQuote').prop('disabled', true);
				$('#repairQuote #submitRepairQuote').addClass('btn-disabled-state');
				//$("#requestRepairQuote span.newCloseIcon").trigger('click');	
				$('#requestRepairQuote').modal('hide');						
			}
		}else{
			if (isEmptyCheck('#instrumentType')) {
                showErrorMessage('#instrumentType');
				$('#insType').addClass('requiredTextBox');				
            } else {
                hideErrorMessage('#instrumentType');
				$('#insType').removeClass('requiredTextBox');
            }	
			if (isEmptyCheck('#instrumentSerialNo')) {
				hideModelSerialErr('#repairQuote #instrumentSerialNo');
                showErrorMessage('#instrumentSerialNo');
            } else {
                hideErrorMessage('#instrumentSerialNo');
			if(!reducedRecords){	
			if(notValidSerial(serialNumbers,  serialNo)){				
					showModelSerialErr('#repairQuote #instrumentSerialNo');
					submitForm = false;
				}else{
					hideModelSerialErr('#repairQuote #instrumentSerialNo');
				}
			}
            }					
			if (isEmptyCheck('#modelNumber')) {
				hideModelSerialErr('#repairQuote #modelNumber');
                showErrorMessage('#modelNumber');
				$('#modelNumberInvalid').hide();
            } else {
                hideErrorMessage('#modelNumber');
			if(!reducedRecords){				
            if(notValidSerialModel(serialAndModalObjects, serialNo, modelNo)){
					showModelSerialErr('#repairQuote #modelNumber');
					submitForm = false;
				 }else{
					hideModelSerialErr('#repairQuote #modelNumber');
				 }
				}				 
            }
			if (isEmptyCheck('#resType')) {
                showErrorMessage('#resType');
				$('#resTime').addClass('requiredTextBox');				
            } else {
                hideErrorMessage('#resType');
				$('#resTime').removeClass('requiredTextBox');
            }		
			if (isEmptyCheck('#repairZipCode')) {
                showErrorMessage('#repairZipCode');
            } else {
                hideErrorMessage('#repairZipCode');
            }
			if (isEmptyCheck('#repairPhoneNumber')) {
                showErrorMessage('#repairPhoneNumber');
            } else {
                hideErrorMessage('#repairPhoneNumber');
            }
			if (isEmptyCheck('#repairEmail')) {
                showErrorMessage('#repairEmail');
            } else {
                hideErrorMessage('#repairEmail');
								if ($('#repairQuote #repairEmail').val() != '') {
                var mailarr = $('#repairQuote #repairEmail').val(), f = true;                                
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                        f = false;                
                if (!f) {
                    $('#repairQuote #repairEmailErr').text($('#emailValidationMsg').val());
                    showErrorMessage('#repairQuote #repairEmail');
					submitForm = false;
				}else{
					 hideErrorMessage('#repairQuote #repairEmail');
				} 
			}
            }
		}
		$("#repairQuote .ui-select span.repairDropdown").removeClass('requiredTextBox');
	});
	
	$('#submitRepairPMQuote').click(function() {
        var dovalidate = LSCA.GlobalValidate.init({
            target : '#repairPMQuote'
        });
        
		var modelNo = $('#repairPMQuote #modelNumber').val();
		var serialNo = $('#repairPMQuote #instrumentSerialNo').val();
		var submitPMForm = true;
        if (dovalidate) {
			var fieldList = getRepairQuotePMFields();
			clearErrorMessage(fieldList);
			
			
			if (isEmptyCheck('#repairPMQuote #instrumentType')) {
                showErrorMessage('#repairPMQuote #instrumentType');
				$('#repairPMQuote #insType').addClass('requiredTextBox');	
					submitPMForm = false;
			}else{
				hideErrorMessage('#repairPMQuote #instrumentType');
				$('#repairPMQuote #insType').removeClass('requiredTextBox');	
				} 
			if(!reducedRecords){
			if(notValidSerialModel(serialAndModalObjects, serialNo, modelNo)){
				showModelSerialErr('#repairPMQuote #modelNumber');
				submitPMForm = false;
			}else{
					hideModelSerialErr('#repairPMQuote #modelNumber');
				}
			if(notValidPMSerial(serialNumberss,  serialNo)){				
				showModelSerialErr('#repairPMQuote #instrumentSerialNo');
				submitPMForm = false;
			}else{
				hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
			}
			}
			
					
			//if(!validateZipCode($('#repairZipCode').val())){
			if(!/^[a-z\d\-\s]+$/i.test($.trim($('#repairPMQuote #repairZipCode').val()))){		
				$('#repairPMQuote #repairZipCodeErrMsg').css('display', 'inline-block');
				$('#repairPMQuote #repairZipCodeLbl').addClass('requiredLabel');
				$('#repairPMQuote #repairZipCode').addClass('requiredTextBox');
				submitPMForm = false;
			}else{
					$('#repairPMQuote #repairZipCodeErrMsg').hide();
					$('#repairPMQuote #repairZipCodeLbl').removeClass('requiredLabel');
					$('#repairPMQuote #repairZipCode').removeClass('requiredTextBox');	
				}
			
			if ($('#repairPMQuote #repairEmail').val() != '') {
                var mailarr = $('#repairPMQuote #repairEmail').val(), f = true;                                
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                        f = false;                
                if (!f) {
                    $('#repairPMQuote #repairEmailErr').text($('#emailValidationMsg').val());
                    showErrorMessage('#repairPMQuote #repairEmail');
					submitPMForm = false;
				}else{
					 hideErrorMessage('#repairPMQuote #repairEmail');
				} 
			}

			if (isEmptyCheck('#repairPMQuote #instrumentType')) {
                showErrorMessage('#repairPMQuote #instrumentType');
            } else {
                hideErrorMessage('#repairPMQuote #instrumentType');
            }	
			/*if (isEmptyCheck('#repairPMQuote #instrumentSerialNo')) {
                showErrorMessage('#repairPMQuote #instrumentSerialNo');
            } else {
                hideErrorMessage('#repairPMQuote #instrumentSerialNo');
            }			
			if (isEmptyCheck('#repairPMQuote #modelNumber')) {
                showErrorMessage('#repairPMQuote #modelNumber');
            } else {
                hideErrorMessage('#repairPMQuote #modelNumber');
            }*/
				
			if (isEmptyCheck('#repairPMQuote #repairZipCode')) {
                showErrorMessage('#repairPMQuote #repairZipCode');
            } else {
                hideErrorMessage('#repairPMQuote #repairZipCode');
            }
			if (isEmptyCheck('#repairPMQuote #insturmentAddress')) {
                showErrorMessage('#repairPMQuote #insturmentAddress');
            } else {
                hideErrorMessage('#repairPMQuote #insturmentAddress');
            }
			if (isEmptyCheck('#repairPMQuote #repairCity')) {
                showErrorMessage('#repairPMQuote #repairCity');
            } else {
                hideErrorMessage('#repairPMQuote #repairCity');
            }
				
			if (isEmptyCheck('#repairPMQuote #repairState')) {
                showErrorMessage('#repairPMQuote #repairState');
            } else {
                hideErrorMessage('#repairPMQuote #repairState');
            }
			if (isEmptyCheck('#repairPMQuote #repairCountry')) {
                showErrorMessage('#repairPMQuote #repairCountry');
            } else {
                hideErrorMessage('#repairPMQuote #repairCountry');
            }
			if (isEmptyCheck('#repairPMQuote #repairPhoneNumber')) {
                showErrorMessage('#repairPMQuote #repairPhoneNumber');
            } else {
                hideErrorMessage('#repairPMQuote #repairPhoneNumber');
            }
						
			
			if(submitPMForm === true){
				$("#repairPMQuote #requestRepairFormSubmit").trigger('click');
				LSCA.loadingSpinner.showLoading();
				$('#repairPMQuote #submitRepairPMQuote').prop('disabled', true);
				$('#repairPMQuote #submitRepairPMQuote').addClass('btn-disabled-state');
				//$("#requestRepairPMQuote span.newCloseIcon").trigger('click');
				$('#requestRepairPMQuote').modal('hide');
			}
		}else{
			if (isEmptyCheck('#repairPMQuote #instrumentType')) {
                showErrorMessage('#repairPMQuote #instrumentType');
				$('#repairPMQuote #insType').addClass('requiredTextBox');	
            } else {
                hideErrorMessage('#repairPMQuote #instrumentType');
				$('#repairPMQuote #insType').removeClass('requiredTextBox');	
            }	
			if (isEmptyCheck('#repairPMQuote #instrumentSerialNo')) {
				hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
                showErrorMessage('#repairPMQuote #instrumentSerialNo');
            } else {
                hideErrorMessage('#repairPMQuote #instrumentSerialNo');
				if(!reducedRecords){
				if(notValidPMSerial(serialNumberss,  serialNo)){				
					showModelSerialErr('#repairPMQuote #instrumentSerialNo');
					submitPMForm = false;
				}else{
					hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
				}
				}
            }			
			if (isEmptyCheck('#repairPMQuote #modelNumber')) {
				hideModelSerialErr('#repairPMQuote #modelNumber');
                showErrorMessage('#repairPMQuote #modelNumber');
            } else {
                hideErrorMessage('#repairPMQuote #modelNumber');
				if(!reducedRecords){
				if(notValidSerialModel(serialAndModalObjects, serialNo, modelNo)){
					showModelSerialErr('#repairPMQuote #modelNumber');
					submitPMForm = false;
				 }else{
					hideModelSerialErr('#repairPMQuote #modelNumber');
				 }
				}
            }
				
			if (isEmptyCheck('#repairPMQuote #repairZipCode')) {
                showErrorMessage('#repairPMQuote #repairZipCode');
            } else {
                hideErrorMessage('#repairPMQuote #repairZipCode');
            }
			if (isEmptyCheck('#repairPMQuote #insturmentAddress')) {
                showErrorMessage('#repairPMQuote #insturmentAddress');
            } else {
                hideErrorMessage('#repairPMQuote #insturmentAddress');
            }
			if (isEmptyCheck('#repairPMQuote #repairCity')) {
                showErrorMessage('#repairPMQuote #repairCity');
            } else {
                hideErrorMessage('#repairPMQuote #repairCity');
            }
				
			if (isEmptyCheck('#repairPMQuote #repairState')) {
                showErrorMessage('#repairPMQuote #repairState');
            } else {
                hideErrorMessage('#repairPMQuote #repairState');
            }
			if (isEmptyCheck('#repairPMQuote #repairCountry')) {
                showErrorMessage('#repairPMQuote #repairCountry');
            } else {
                hideErrorMessage('#repairPMQuote #repairCountry');
            }
			if (isEmptyCheck('#repairPMQuote #repairPhoneNumber')) {
                showErrorMessage('#repairPMQuote #repairPhoneNumber');
            } else {
                hideErrorMessage('#repairPMQuote #repairPhoneNumber');
            }
			if (isEmptyCheck('#repairPMQuote #repairEmail')) {
                showErrorMessage('#repairPMQuote #repairEmail');
            } else {
                hideErrorMessage('#repairPMQuote #repairEmail');
				if ($('#repairPMQuote #repairEmail').val() != '') {
                var mailarr = $('#repairPMQuote #repairEmail').val(), f = true;                                
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                        f = false;                
                if (!f) {
                    $('#repairPMQuote #repairEmailErr').text($('#emailValidationMsg').val());
                    showErrorMessage('#repairPMQuote #repairEmail');
					submitPMForm = false;
				}else{
					 hideErrorMessage('#repairPMQuote #repairEmail');
				} 
			}	
            }
		}
		$("#repairPMQuote #insType span.repairDropdown").removeClass('requiredTextBox');
	});
	
	$("#repairPMQuote #instrumentSerialNo,#repairQuote #instrumentSerialNo").on('input', function() {
		$(this).val($(this).val().replace(/[^a-z0-9-]/gi,''));		
	});
	$("#repairQuote #modelNumber,#repairPMQuote #modelNumber").on('input', function() {
		$(this).val($(this).val().replace(/[^a-z0-9-]/gi,''));
	});
	$("#repairPMQuote #repairPhoneNumber,#repairQuote #repairPhoneNumber").on('input', function() {
		$(this).val($(this).val().replace(/[a-zA-Z]/gi,''));
	});
	$("#repairPMQuote #repairCity").on('input', function() {
		$(this).val($(this).val().replace(/[^a-zA-Z ]/gi,''));
	});
	$("#repairPMQuote #repairState").on('input', function() {
		$(this).val($(this).val().replace(/[^a-zA-Z ]/gi,''));
	});
	$("#repairPMQuote #repairCountry").on('input', function() {
		$(this).val($(this).val().replace(/[^a-zA-Z ]/gi,''));
	});
		
	
		function modelAutoSuggest(SerialNumber){	
			$("#repairQuote #modelNumber").autocomplete({                
				source: function(request, response) {
					var results = $.ui.autocomplete.filter(modelNumber, request.term);
					response(results.slice(0, 5));
				},
			minLength: 2
            });
		}
		
		function serialPMAutoSuggest(SerialNumber){	
			$("#repairPMQuote #instrumentSerialNo").autocomplete({                
				source: function(request, response) {
					var results = $.ui.autocomplete.filter(SerialNumber, request.term);
					response(results.slice(0, 5));
				},
				select: function (event, ui) {
					findModal(serialAndModalObjects, ui.item.value);
					//hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
					//hideErrorMessage('#repairPMQuote #instrumentSerialNo'); 
					$('#repairPMQuote #instrumentSerialNo').removeAttr('style');
				},
			minLength: 2,
			appendTo: "#repairPMQuote #instrumentSerialNoLbl + div"
            });
		}
		
		
		function serialAutoSuggest(SerialNumber){				
			$("#repairQuote #instrumentSerialNo").autocomplete({                
				source: function(request, response) {
					var results = $.ui.autocomplete.filter(SerialNumber, request.term);
					response(results.slice(0, 5));
				},
				select: function (event, ui) {
					findModal(serialAndModalObjects, ui.item.value);
					$('#repairQuote #instrumentSerialNo').removeAttr('style');
				},
			minLength: 2,
			appendTo: "#repairQuote #instrumentSerialNoLbl + div"
            });			
		}
		
	$(document).on("keyup", "#repairQuote #instrumentSerialNo", function(e) {
		var $this = $(this);
		if($this.val() == ''){
			$('#repairQuote #modelNumber').removeAttr('style');
			$("#repairQuote #modelNumber").val("");
		}
	});	
	
	$(document).on("keyup", "#repairPMQuote #instrumentSerialNo", function(e) {
		var $this = $(this);
		if($this.val() == ''){
			/*hideErrorMessage('#repairPMQuote #instrumentSerialNo'); 
			hideModelSerialErr('#repairPMQuote #instrumentSerialNo');
			hideErrorMessage('#repairPMQuote #modelNumber'); 
			hideModelSerialErr('#repairPMQuote #modelNumber');
			
			hideErrorMessage('#repairPMQuote #repairCity');
			hideErrorMessage('#repairPMQuote #repairState');
			hideErrorMessage('#repairPMQuote #repairCountry');*/
			$('#repairPMQuote #modelNumber,#repairPMQuote #instrumentSerialNo,#repairPMQuote #insturmentAddress,#repairPMQuote #repairCity,#repairPMQuote #repairState,#repairPMQuote #repairCountry').removeAttr('style');
			$("#repairPMQuote #modelNumber").val("");
			if(isNotEmpty($("#repairPMQuote #insturmentAddress").val())){
				$("#repairPMQuote #insturmentAddress").val("");
				//hideErrorMessage('#repairPMQuote #insturmentAddress');
			}
			$("#repairPMQuote #repairCity").val("");
			$("#repairPMQuote #repairState").val("");
			$("#repairPMQuote #repairCountry").val("");
		}
	});
	 
	 $("#main-wrapper-shopping-cart .cartQtySpa").on('input', function() {
		$(this).val($(this).val().replace(/[^0-9]/gi,''));
	});
	if(getUrlParam('pmodq') == "true"){		
		$("#triggerRequestPMQuote").click();
		$('.newCloseIcon').on('click', function(evt) {
			//evt.preventDefault(); 
			/*$(this).removeAttr("data-dismiss");
			if(navigator.userAgent.indexOf('MSIE')!==-1 || navigator.appVersion.indexOf('Trident/') > -1){
				console.info("IE");
				history.back();
			}
			else{
				console.info("Others");
				window.location.href=document.referrer; 
			}*/
			window.location.href=$('#mya_referer').text(); 
		});
	}
	
	if(getUrlParam('rodq') == "true"){
		$("#triggerRequestQuote").click();
		$('.newCloseIcon').on('click', function(evt) {
			//evt.preventDefault(); 
			/*$(this).removeAttr("data-dismiss");
			if(navigator.userAgent.indexOf('MSIE')!==-1 || navigator.appVersion.indexOf('Trident/') > -1){
				console.info("IE");
				history.back();
			}
			else{
				console.info("Others");
				window.location.href=document.referrer; 
			}*/
			window.location.href=$('#mya_referer').text(); 
		});
	}
	if ($('#triggerRequestPMQuote').length > 0) {
		var len = 36-$('#triggerRequestPMQuote').text().length;
		if(len > 0) {
			var lencss = 248 -(len*3);
			$(".newRepairQuote").css('left',lencss);
		}
		if(len < 0) {
			$(".newRepairQuote").css('bottom',25);
		}
		if ($('.newRepairQuote').text().length >5) {
			$(".newRepairQuote").css('width',60);
		}
		if ($('.newRepairQuote').text().length == 5) {
			$(".newRepairQuote").css('width',50);
		}	
	}
	
});
