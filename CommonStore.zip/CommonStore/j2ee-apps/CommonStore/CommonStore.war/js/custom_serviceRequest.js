$(document).ready(function(){
$(".cus-chk").hide();
$("#unknownAGL").click(function(){
if($("#unknownAGL").is(":checked")){
    $(".cus-chk").show();  // checked
	$(".custom-Instrument").hide();
	$("#custom_sr .grey-box").css({"padding-bottom": "0px"});
}
else{
    $(".cus-chk").hide();
    $(".custom-Instrument").show();
}
});

$('input:checkbox').change(function(){
    if($("#unknownAGL").is(":checked")) {
        $('.cus-chk input.form-control').addClass("required");
        $('.custom-aGLNumber input.form-control').removeClass("required");
    } else {
        $('.cus-chk input.form-control').removeClass("required");
        $('.custom-aGLNumber input.form-control').addClass("required");
    }
});
$("#custom-sr-send").click(function(e) {
    e.preventDefault();
    var dovalidate= CSCA.GlobalValidate.init({target:'#srForm' ,action:'submit'});
    if(dovalidate){
	/*var data = $('#srForm').serialize();
	 $.ajax({
         type: "POST",
         url : "",
         dataType: "html",
         data: data,
         cache: false,
         success: function(data) {
             $("#srForm")[0].reset();
         },
         error: function(x, t, m) {
				console.log('Something went wrong!')
         }
     });*/
    document.getElementById('srSubmit').click();
    }
	else{
		$(document).find('div.errorMessages').show();
	}
    });

$("#custom-sr-search").click(function(e) {
    e.preventDefault();
    var dovalidate= CSCA.GlobalValidate.init({target:'#srsearchForm, #srIdSearchForm' ,action:'submit'});
    if(dovalidate){
	/*var data = $('#srForm').serialize();
	 $.ajax({
         type: "POST",
         url : "",
         dataType: "html",
         data: data,
         cache: false,
         success: function(data) {
             $("#srForm")[0].reset();
         },
         error: function(x, t, m) {
				console.log('Something went wrong!')
         }
     });*/
    document.getElementById('srSearch').click();
    }
	else{
		$(document).find('div.errorMessages').show();
	}
    });
});	
var CSCA = {
		GlobalValidate : {//----Global form validation for all type of forms----//
		init : function(options_){
				var formErrorId=options_.target;
				var gtg=true, flagArr=[], msgArr=[], alrtmsg='',
				 vclass = ['required','alpha','num','alphanum','chkrequired','selectone','email','confirm2']; 
				 els = $(options_.target).map(function(){ return $.makeArray(this.elements); });
				els.each(function(i){
					for(c in vclass){
						if($(els[i]).hasClass(vclass[c])){
							gtg = CSCA.GlobalValidate.doValidate.validate(vclass[c],$(els[i]));
							$.each(gtg, function(i,v){if(i===0)msgArr.push(v);if(i===1)flagArr.push(v);})
						}
					}
				});
				$.each(msgArr, function(i,v){ if(v!='')alrtmsg+=v.replace(/[<>\///';]+/g,'')+'</br>'; });
				if(alrtmsg!=''){
					
					alrtmsg='<div class="alert alert-dismissable alert-danger">'+alrtmsg+'</div>';
					$(document).find('div.errorMessages').hide();
					$(document).find('div.errorMessages').html(alrtmsg);
					$(document).find('div.errorMessages').show();
					$(document).scrollTop($(document).find('div.errorMessages').position('top'));
				}
				return ($.inArray(false,flagArr)==-1)? true : false; 
		},
		doValidate : {
			validate : function(casechk, element){
			var chk = false, msg = element.attr('title'), rspobj=[], formval=$.trim(element.val()), msgname = element.attr('id');
				if(casechk === 'required'){
					if($.trim(formval)===''){
						msg = msg || 'This field is required.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'alpha'){
					if(/[^a-zA-Z]+$/.test(formval)){
						msg = msg || 'Please enter alphabets only.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'num'){
					if(/[^0-9]+$/.test(formval)){
						msg = msg || 'Please enter numeric value only.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'alphanum'){
					if(/[^a-zA-Z0-9\._-]+$/.test(formval)){
						msg = msg || 'Please enter alphnumrics only.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'selectone'){
					if(formval==''||element.val()==0){
						msg = msg || 'Please select one.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element);chk = true; rspobj.push('',chk);}
				}else if(casechk === 'chkrequired'){
					if(!element.attr('checked')){
						msg = msg || 'This field is required.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}else if(casechk === 'email'){
					if(formval!=''){
						var mailarr=element.val(), f=true; mailarr=mailarr.split(',');
						$.each(mailarr,function(i,v){if( !(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))) )f=false;});
						if(!f){
							msg = msg || 'Email is not valid.';
							CSCA.GlobalValidate.showError(element, '');
							chk = false; rspobj.push(msg,chk);
						}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
					}else if(formval==''||element.val()==0){
						msg = 'Email address is required.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}
				}else if(casechk === 'confirm2'){
					var pass1 = element.val(), pass2 = $('.confirm1').val();
					if( pass1 != pass2 || pass1==''){
						msg = msg || 'Confirm password is not same.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false; rspobj.push(msg,chk);
					}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk);}
				}				
				if(element.attr('minchar')!='undefined' || element.attr('minchar')!=''){
					if(formval.length < parseInt(element.attr('minchar'))){
						msg = msg || 'Please enter minimum '+element.attr('minchar')+' character.';
						CSCA.GlobalValidate.showError(element, '');
						chk = false;  rspobj.push(msg,chk);
					}
				}else{CSCA.GlobalValidate.hideError(element); chk = true; rspobj.push('',chk); }
			return rspobj;		
			}
		},
		showError : function(element, msg){
			msgui = '<div class="alert alert-dismissable alert-danger">'+msg+'</div>';
			$(element).css({"border-color": "#e84b4c", 
					            "border-weight":"1px", 
					            "border-style":"solid"});
			if(msg!=''){
				$(document).find('div.errorMessages').hide();
				$(document).find('div.errorMessages').html(msgui);
				$(document).find('div.errorMessages').show();
				$(document).scrollTop($(document).find('div.errorMessages').position('top'));
			}
		},
		hideError : function(element){
			$(element).css('border-color','');
			$(document).find('div.errorMessages').hide();
		}
	}
	}
	$(document).ready(function() {
		$("#uniform-Inquiry option").click(function () {
		    $("#uniform-Inquiry option").removeClass("active");
		    $(this).addClass("active");        
		});
		$(".custom-modal-top .close").click(function(){
			$(document).find('div.errorMessages:eq(0)').html('');
			$(".errorMessages").css({'display': 'none'});
			$(".custom-contact_form_cl")[0].reset();
		});
	});