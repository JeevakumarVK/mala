$(document).ready(function() {
    $('#send-emailbtn').on('click', function(e) {
		var invalidSCEmailVal,scEmailPageerror,invalidSCCEmailVal;
        var emailVal = $('#inputEmail1').val().split(';');
        for (var i = 0; i < emailVal.length; i++) {
            var mailarr = emailVal[i],
                f = true;
            if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                f = false;
            if (!f) {
                $('#inputEmail1').addClass('requiredTextBox');
                $('#invalidSCEmail').show();
                invalidSCEmailVal = false;
                break;
            } else {
                $('#inputEmail1').removeClass('requiredTextBox');
                $('#invalidSCEmail').hide();
                invalidSCEmailVal = true;
            }
        }
        if ($('#inputEmail1').val() == '' || invalidSCEmailVal == false) {
            $('#inputEmail1').addClass('requiredTextBox');
            $('#inputEmail1').prev().addClass('requiredLabel');
            if ($('#inputEmail1').val() == '') {
                $('#SCEmailRequired').show();
                $('#invalidSCEmail').hide();
            } else {
                $('#SCEmailRequired').hide();
                $('#invalidSCEmail').show();
            }
            scEmailPageerror = false;
        } else {
            $('#inputEmail1').removeClass('requiredTextBox');
            $('#inputEmail1').prev().removeClass('requiredLabel');
            $('#SCEmailRequired').hide();
            scEmailPageerror = true;
        }
        if ($('#givenName').val() != '') {
            var ccemailVal = $('#givenName').val().split(';');
            for (var i = 0; i < ccemailVal.length; i++) {
                var mailarr = ccemailVal[i],
                    f = true;
                if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                    f = false;
                if (!f) {
                    $('#givenName').addClass('requiredTextBox');
					$('#givenName').prev().addClass('requiredLabel');
                    $('#invalidSCCEmail').show();
                    invalidSCCEmailVal = false;
                    break;
                } else {
                    $('#givenName').removeClass('requiredTextBox');
					$('#givenName').prev().removeClass('requiredLabel');
                    $('#invalidSCCEmail').hide();
                    invalidSCCEmailVal = true;
                }
            }
        } else {
            $('#givenName').removeClass('requiredTextBox');
			$('#givenName').prev().removeClass('requiredLabel');
            $('#invalidSCCEmail').hide();
            invalidSCCEmailVal = true;
        }
		if ($(document).find('label.requiredLabel:eq(0)').position()) {
			$('html, body').animate({
				scrollTop : $(document).find('label.requiredLabel:eq(0)').position().top-60
			}, "linear");
		}	
		if(invalidSCEmailVal && scEmailPageerror && invalidSCCEmailVal){
			$('#send-email').trigger('click');
		}		
    })
	$('.emailCartNew .emailCartBack').on('click', function(e) {
		window.history.back();
	})	
	//$('#custom-main-wrapper-expand .emailCart + #myModal .modal-body button span span').text('Back to Cart');
});