$(document).ready(function() {
	if ($(".emailCatalogNew")[0]){
		$('div#bin').attr("style", " margin: 0 auto;  width: 100%; padding-top: 123.733px !important;");
    }else{
		$('div#bin').attr("style", "padding-top: 123.733px;");
	}
    $('.emailCatalogNew .btnWrap #send-email').on('click', function(e) {		
		$('.emailCatalogNew #error-messages').css("display","none");
		var invalidMCEmailVal,mcEmailPageerror,invalidMCCEmailVal;
        var emailVal = $('#inputEmail1').val().split(';');
        for (var i = 0; i < emailVal.length; i++) {
            var mailarr = emailVal[i],
                f = true;
            if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                f = false;
            if (!f) {
                $('#inputEmail1').addClass('requiredTextBox');
                $('#invalidMCEmail').show();
                invalidMCEmailVal = false;
                break;
            } else {
                $('#inputEmail1').removeClass('requiredTextBox');
                $('#invalidMCEmail').hide();
                invalidMCEmailVal = true;
            }
        }
        if ($('#inputEmail1').val() == '' || invalidMCEmailVal == false) {
            $('#inputEmail1').addClass('requiredTextBox');
            $("[for='inputEmail1']").addClass('requiredLabel');
            if ($('#inputEmail1').val() == '') {
                $('#MCEmailRequired').show();
                $('#invalidMCEmail').hide();
            } else {
                $('#MCEmailRequired').hide();
                $('#invalidMCEmail').show();
            }
            mcEmailPageerror = false;
        } else {
            $('#inputEmail1').removeClass('requiredTextBox');
            $("[for='inputEmail1']").removeClass('requiredLabel');
            $('#MCEmailRequired').hide();
            mcEmailPageerror = true;
        }
        if ($('#givenName').val() != '') {
            var ccemailVal = $('#givenName').val().split(';');
            for (var i = 0; i < ccemailVal.length; i++) {
                var mailarr = ccemailVal[i],
                    f = true;
                if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                    f = false;
                if (!f) {
                    $('#givenName').addClass('requiredTextBox');
					$("[for='givenName']").addClass('requiredLabel');
                    $('#invalidMCCEmail').show();
                    invalidMCCEmailVal = false;
                    break;
                } else {
                    $('#givenName').removeClass('requiredTextBox');
					$("[for='givenName']").removeClass('requiredLabel');
                    $('#invalidMCCEmail').hide();
                    invalidMCCEmailVal = true;
                }
            }
        } else {
            $('#givenName').removeClass('requiredTextBox');
			$('#givenName').prev().removeClass('requiredLabel');
            $('#invalidMCCEmail').hide();
            invalidMCCEmailVal = true;
        }
		if ($(document).find('label.requiredLabel:eq(0)').position()) {
			$('html, body').animate({
				scrollTop : $(document).find('label.requiredLabel:eq(0)').position().top-60
			}, "linear");
		}	
		if(invalidMCEmailVal && mcEmailPageerror && invalidMCCEmailVal){
			//$('#send-email').trigger('click');
		}		
    })
	$('.emailCatalogNew .emailCatalogBack').on('click', function(e) {
		window.history.back();
	})	
});