/* eucookie.js  CX1  2013-03-06  jrg */
function eucGetCookie(c_name) {
	if (document.cookie.length>0) {
		c_start=document.cookie.indexOf(c_name + "=");
		if (c_start!=-1) {
			c_start=c_start + c_name.length+1;
			c_end=document.cookie.indexOf(";",c_start);
			if (c_end==-1) c_end=document.cookie.length;
			return unescape(document.cookie.substring(c_start,c_end));
		}
	}
	return "";
}
var domain = ".agilent.com";
if(location.host){
	if(location.host.indexOf(".agilent.com.cn")!=-1){
		domain = ".agilent.com.cn";
	}else{
		domain = ".agilent.com";
	}
}
function eucSetCookie(c_name,value,expiredays) {
	var exdate=new Date();exdate.setDate(exdate.getDate()+expiredays);
	var cookieVal=c_name+ "=" +escape(value)+ ((expiredays==null) ? "" : ";expires="+exdate.toGMTString());
	if(location.hostname.match(/\.agilent\.com$/)) {
		cookieVal += ";path=/;domain="+domain;
	}
	document.cookie = cookieVal;
}
var eucTimer;
var eucCookieName = "AG_CookieNotice";
function eucDisable(hideNotice) {
	clearTimeout(eucTimer);
	eucSetCookie(eucCookieName,eucLastModified,90);
	if(hideNotice) {
		document.getElementById("eucookie").style.display = "none";
		document.body.className = document.body.className.replace(/[ ]*\beucOffset\b/g,'')
	}
}
function eucInit() {
	var cVal = eucGetCookie(eucCookieName);
	if(cVal >= eucLastModified)
		return;
	var eucWrapper = document.createElement("DIV");
	eucWrapper.id = "eucookie";
	eucWrapper.innerHTML = '<div style="text-align:left;font-style:normal;font-family: Arial, Helvetica, sans-serif;color: #444;font-size: 12px;line-height: 1.3;border-bottom: 1px solid #888;width:100%;position:fixed;top:0;left:0;z-index:1000000;background: #fbf9e0;-moz-box-shadow: 0 5px 10px #888;-webkit-box-shadow: 0 5px 10px #888;box-shadow: 0 5px 10px #888;"><div style="padding: 10px 40px 15px"><table border="0" cellpadding="0" cellspacing="0"><tr><td style="vertical-align: top"><h4 style="font-style:normal;font-weight: bold;font-size: 110%;margin: 0 0 5px">' + eucTitle + '</h4><p style="font-weight: normal;margin: 0;font-size: 100%;font-style:normal">' + eucDesc + ' <a href="' + eucPrivacyHref +'" style="color: #0085d5;display:inline-block" onclick="try {s.linkTrackVars=\'s.prop17\';EUNotice=\'Privacy\';s.tl(true,\'o\',EUNotice);} catch(e) {}">' + eucPrivacyText + '</a></p></td><td style="padding: 10px 0 0 50px; vertical-align:top"><button onclick="eucDisable(true);try {s.linkTrackVars=\'s.prop17\';EUNotice=\'Close\';s.tl(true,\'o\',EUNotice);EUNotice=\'\';} catch(e) {}">' + eucClose + '</button></td></tr></table></div></div>';
	document.body.appendChild(eucWrapper);
	//document.write('<style type="text/css">body.eucOffset { padding-top: ' + eucWrapper.getElementsByTagName('DIV')[0].offsetHeight + 'px !important;}</style>');
	document.body.className += " eucOffset";
	eucTimer = setTimeout('eucDisable()',60000);
}
if(typeof eucTitle != "undefined" && eucTitle != "" && top == self) {
	eucSetCookie("cookies","cookies");
	if(eucGetCookie("cookies") == "cookies") {
		eucSetCookie("cookies","",-1);
		eucInit();
	}
}