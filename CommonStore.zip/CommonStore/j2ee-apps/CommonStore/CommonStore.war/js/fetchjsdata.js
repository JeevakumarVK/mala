// Team 2 Script
	//jQuery(window).load(function(){
	function slideArrowCall(){
         $(window).on('scroll',function(e) {
                	var anchor = $('.scroller_anchor');
                    if(anchor.length) {
                    	var scroller_anchor = $(".scroller_anchor").offset().top -53;
                    }
                    if ($(this).scrollTop() >= scroller_anchor) {
                        $('.productsRepairQuote .adding-product-thead').addClass('fixed');
                        $('.adding-product-table-wrapper').addClass('positionFixed');
                    } else if ($(this).scrollTop() < scroller_anchor) {
                    	$('.productsRepairQuote .adding-product-thead').removeClass('fixed');
                        $('.adding-product-table-wrapper').removeClass('positionFixed');                        
                    }
                    
                    var window_top = $(this).scrollTop();
                    var div_height = $('.productsRepairQuote .adding-product-thead').height();
                    var home = $('.custom-total-group');
                    var tbodyOffset = $('.adding-product-tbody').offset().top - 20;
                    var div_heightBody =  $('.adding-product-tbody').height()
                    var totalOffset = div_heightBody + tbodyOffset;
                    var totalWindowScroll = window_top + div_height;                    
                                   
                    if (totalWindowScroll + 60 > totalOffset) {
                       $('.productsRepairQuote .adding-product-thead').removeClass('fixed').addClass('scroll-header');
                       $('.adding-product-table-wrapper').removeClass('positionFixed'); 
                       $('.scroller_anchor').remove();
                       var totalHeightThead = $('.adding-product-thead').height();
                       var totalHeightTbody = $('.adding-product-tbody').height();
                       var totalHeightCal = totalHeightTbody - totalHeightThead;
                       if($('.productsRepairQuote .adding-product-thead.scroll-header').hasClass('scroll-header')){
                    	   $('.productsRepairQuote .adding-product-thead.scroll-header').css('top', totalHeightCal - 26);
                    	   $('.productsRepairQuote a.left-slide-arrow, .productsRepairQuote a.right-slide-arrow').css('top', totalHeightCal + 42);
                       }                      
                    }else if(totalWindowScroll + 60 < totalOffset){
                    	console.log('add');
                    	if(anchor.length == false) {                    		
                        	$(".adding-product-thead").before('<div class="scroller_anchor"></div>');
                        	$('.productsRepairQuote .adding-product-thead').removeClass('scroll-header');
                        	$('.productsRepairQuote .adding-product-thead').css('top', '53px');
                        	return false;                    		
                    	}
                    }else {
                    	$('.productsRepairQuote .adding-product-thead').removeClass('scroll-header');
                    	$('.productsRepairQuote .adding-product-thead').css('top', '53px');
                    	$('.productsRepairQuote a.left-slide-arrow, .productsRepairQuote a.right-slide-arrow').css('top', '89px');                  	                    	
                    }                    
                    if(!$('.adding-product-table-wrapper').hasClass('positionFixed')) {
                    	$('.productsRepairQuote a.left-slide-arrow, .productsRepairQuote a.right-slide-arrow').css('top', '80px');
                    }else {
                    	$('.productsRepairQuote a.left-slide-arrow, .productsRepairQuote a.right-slide-arrow').css('top', '89px');
                    }
                });
                                                          
				
                var listWidth, colTotalWidth = 0,
	                i, finalColWidth;
	            listWidth = $('.productsRepairQuote .adding-product-thead .add-prod-col').map(function() {
	                return $(this).outerWidth();
	            }).get();
	
	            for (i = 0; i < listWidth.length; i += 1) {
	                colTotalWidth += listWidth[i];
	            }
	            finalColWidth = colTotalWidth - 1148;
            
                $(".adding-product-tbody").on('scroll',function() {
                    var scrollLeftVal = $(this).scrollLeft();
                    $(".productsRepairQuote .adding-product-thead .add-prod-row").css({
                        '-moz-transform': 'translateX(' + - +scrollLeftVal + 'px)',
                        '-webkit-transform': 'translateX(' + - +scrollLeftVal + 'px)',
                        '-ms-transform': 'translateX(' + - +scrollLeftVal + 'px)',
                        '-o-transform': 'translateX(' + - +scrollLeftVal + 'px)',
                        'transform': 'translateX(' + - +scrollLeftVal + 'px)'
                    });
                    
                    
                    if (scrollLeftVal === finalColWidth + 2) {
                        $('.right-slide-arrow').css({
                        	'opacity':'0',
                        	'visibility': 'hidden'
                        });
                    }else {
                    	$('.right-slide-arrow').css({
                        	'opacity':'1',
                        	'visibility': 'visible'
                        });
                    }
                    
                    if (scrollLeftVal === 0) {
                        $('.left-slide-arrow').css({
                        	'opacity':'0',
                        	'visibility': 'hidden'
                        });
                    }else {
                    	$('.left-slide-arrow').css({
                        	'opacity':'1',
                        	'visibility': 'visible'
                        });
                    }                    
                });
               

                $('.left-slide-arrow').on('click', function() {
                    event.preventDefault();
                    $('a.right-slide-arrow').css('opacity', '1');
                    $('.adding-product-tbody').animate({
                        scrollLeft: "-=190px"
                    }, "slow");
                    var scrollVal = $('.adding-product-tbody').scrollLeft();
                    if (scrollVal < 201) {
                        $(this).css({
                        	'opacity':'0',
                        	'visibility': 'hidden'
                        });
                    }
                });
                $('.right-slide-arrow').on('click', function() {
                    event.preventDefault();
                    $('a.left-slide-arrow').css('opacity', '1');
                    $('.adding-product-tbody').animate({
                        scrollLeft: "+=190px"
                    }, "slow");
                    var scrollVal = $('.adding-product-tbody').scrollLeft();
                    console.log(scrollVal, finalColWidth);
                    if (scrollVal === finalColWidth + 2) {
                        $(this).css({
                        	'opacity':'0',
                        	'visibility':'hidden'
                        });
                    }
                });

                var colLengthCount = $('.productsRepairQuote .adding-product-thead .add-prod-col').length;
                if (colLengthCount < 7) {
                    $('.left-slide-arrow, .right-slide-arrow').remove();
                } 
                if (colLengthCount == 5) {
                	console.log(5);
                    $('.productsRepairQuote .add-prod-col').css('width', '20%');
                    $('.adding-product-table-wrapper').addClass('four-tiles');
                } else if (colLengthCount == 2) {
                	console.log(2);
                    $('.productsRepairQuote .add-prod-col').css('width', '50%');
                    $('.adding-product-table-wrapper').addClass('one-tiles');  
                }else if (colLengthCount == 3) {
                	console.log(3);
                    $('.productsRepairQuote .add-prod-col').css('width', '33.33%');
                    $('.adding-product-table-wrapper').addClass('two-tiles');
                }else if (colLengthCount == 4) {
                	console.log(4);
                    $('.productsRepairQuote .add-prod-col').css('width', '25%');
                    $('.adding-product-table-wrapper').addClass('three-tiles');
                }
}		
	$('.adding-product-thead .add-prod-col').each(function(){
    	if($(this).find('.product-img-caption').children('.product-caption-inner').length > 0) {
        	$(this).find('.product-img').addClass('hasContentCon').find('.product-img-caption').addClass('hasContent');
        }else {
        	$(this).find('.product-img').removeClass('hasContentCon').find('.product-img-caption').removeClass('hasContent');
        }
    });
	
	$(function () {            		
			$( ".custom-tooltip" ).tooltip({
				position: {
               my: "center top",
               at: "center bottom+15",
               collision: "none"
            },
           tooltipClass: "addOn-Tooltip",
        });        		
			
			$( ".add-prod-col h5 span" ).tooltip({
				position: {
               my: "center bottom",
               at: "center top-15",
               collision: "none"
            },
           tooltipClass: "addOn-Tooltip top-position",
        }); 
	});
	
	//});
	var urlVal="",setUrlVal=""; 
    var quoteIdParam ="",originalQuoteIdVal="",_requestidVal="";
        if(getUrlParam('quoteId')){
            quoteIdParam = getUrlParam('quoteId');
        } 
	//urlVal = location.href; 
    //setUrlVal = urlVal.substring(urlVal.indexOf("?")+1);
	setUrlVal= location.search;
	function loadJSONData() {            
    $.ajax({

        type : "GET",

        url : '/rest/model/com/agilent/commerce/LynxServiceActor/fetchAddOnProducts?quoteId='+quoteIdParam+'&atg-rest-output=json',

        cache : false,
        dataType: "json",
		beforeSend : function() {
			LSCA.loadingSpinner.showLoading();
		},
        success: function(response) {
		if(response.fetchAddOnProductsDetails == null || response.fetchAddOnProductsDetails.length==0){
			$('.productsRepairQuote.addOnQuotePage #custom-main-wrapper').hide();
            window.location.href="/common/myaccount/quoteDetails.jsp?quoteId="+quoteIdParam;
        }
			
		if(response.fetchAddOnProductsDetails[0].productAddOns==null || response.fetchAddOnProductsDetails[0].productAddOns.length==0){
			$('.productsRepairQuote.addOnQuotePage #custom-main-wrapper').hide();
            window.location.href="/common/myaccount/renewContractPayment.jsp"+setUrlVal;
        }
        var data = response.fetchAddOnProductsDetails[0].instrumentDetails;                
        var configdata=response.fetchAddOnProductsDetails[0].instrumentDetails;
        var len = configdata.length;    
        var addOnData=response.fetchAddOnProductsDetails[0].productAddOns;  
		 
        var addOnLength=addOnData.length;		       
		var grossFormattedAmt=response.fetchAddOnProductsDetails[0].formattedGrossValue; 
        var grossAmt=response.fetchAddOnProductsDetails[0].quoteGrossValue;
		$('#contactIDValue').val(response.fetchAddOnProductsDetails[0].contactId);	
        var grossCurrencyVal="",currVal="",tblData="",tblResult="",tblData1="",tblResult1="",uniqueConfigList="",uniqueConfigLength,counter=0,targetElt,componentData,componentLength,componentDisplayHeader,componentCounter=0,tblCompData="",tblCompResultData="",accordTitle="";
		//var grossCurrencyVal="",currVal="",tblData="",tblResult="",tblData1="",tblResult1="",uniqueConfigList="",uniqueConfigLength,counter=0,targetElt,componentData,componentLength,componentDisplayHeader,componentCounter=0,tblCompData="",tblCompResultData="",accordTitle="";
        var arr = [];
        var fetchaddlen=data.length; 
		var partnerInfo=response.fetchAddOnProductsDetails[0].partnerResultSet;       
        var partnerInfoLen=partnerInfo.length;
        for (var l = 0; l < partnerInfoLen; l++) {
			if (partnerInfo[l].partnerFct == "00000014") {
				if (partnerInfo[l].name != "" || partnerInfo[l].name != null) {
					jQuery(".productsRepairQuote .custom-quote-down .partnerName").text(partnerInfo[l].name);
					jQuery(".productsRepairQuote .custom-form-head .salesNameSpan").text(partnerInfo[l].name);
				}
				if (partnerInfo[l].telephone != "") {
					jQuery(".productsRepairQuote .custom-quote-down .telnoVal").text(partnerInfo[l].telephone);
				}
				else {
					jQuery(".productsRepairQuote .custom-quote-down #custom-email .custom-phone").text("");
				}
				if (partnerInfo[l].emailId != "") {
					jQuery(".productsRepairQuote .custom-quote-down #custom-email .custom-email a").text(partnerInfo[l].emailId);
					jQuery(".productsRepairQuote .custom-quote-down #custom-email .custom-email a").attr("href", "mailto:" + partnerInfo[l].emailId);
				}
				else {
					jQuery(".productsRepairQuote .custom-quote-down #custom-email .custom-email").text("");
				}

			}
			else if (partnerInfo[l].partnerFct == "00000015") {
				if (partnerInfo[l].name != "" || partnerInfo[l].name != null) {
					jQuery(".productsRepairQuote #contactName").val(partnerInfo[l].name);
				}
				if (partnerInfo[l].emailId != "" || partnerInfo[l].emailId != null) {
					jQuery(".productsRepairQuote #contactEmail").val(partnerInfo[l].emailId);
					jQuery(".productsRepairQuote .contactEmailSpan").text(partnerInfo[l].emailId);

				}
				if (partnerInfo[l].telephone != "" || partnerInfo[l].telephone != null) {
					jQuery(".productsRepairQuote #contactPhone").val(partnerInfo[l].telephone);
					jQuery(".productsRepairQuote .contactPhoneSpan").text(partnerInfo[l].telephone);
				}
				jQuery(".productsRepairQuote #contactCountry").val(partnerInfo[l].country);

			}
			/*else{
				jQuery(".productsRepairQuote #contactName").val(partnerInfo[l].name);
				jQuery(".productsRepairQuote #contactEmail").val(partnerInfo[l].emailId);
				jQuery(".productsRepairQuote #contactPhone").val(partnerInfo[l].telephone);
				jQuery(".productsRepairQuote #contactCountry").val(partnerInfo[l].country);
				jQuery(".productsRepairQuote #quoteId").val(response.fetchAddOnProductsDetails[0].quoteId);                             
			}*/
			jQuery(".productsRepairQuote #quoteId").val(response.fetchAddOnProductsDetails[0].quoteId);
			jQuery(".productsRepairQuote .custom-form-head .quoteIdSpan").text(response.fetchAddOnProductsDetails[0].quoteId);
		}
            
        for(var i = 0; i < addOnLength ; i++){                    
                                                        
            tblData+="<div class='add-prod-col "+addOnData[i].addonType+"-config'>";

            tblData += '<div class="product-img hasContentCon"><span class="product-img-caption hasContent"><span class="product-caption-inner"></span></span>';

            tblData += '<input type="hidden" name="longDescValue" id="longDescValue" value="">'; 

			tblData += '<input type="hidden" name="largeImagePath" id="largeImagePath" value="">';				

			tblData += '<input type="hidden" name="titleValue" id="titleValue" value="">';			

            tblData+='<img id="smallImage" src=""></div>';

            tblData+='<div class="custom-checkbox"><input type="checkbox" class="custCheckedimg"></div>';

            tblData+="</div>";
            arr.push(addOnData[i].addonType); 
        }
        uniqueConfigLength = arr.length; 
        tblData+='<input type="hidden" name="configListVal" id="configListVal" value='+arr+'>';
        tblResult+= tblData;
        $('.adding-product-table .adding-product-thead .add-prod-row').html(tblResult);
        var confighiddenval = $(document).find('#configListVal').val().split(',');
        for (var i = 0; i < fetchaddlen; i++) {
            targetElt=response.fetchAddOnProductsDetails[0].instrumentDetails[i].addOnProductsSet;     
            componentData=response.fetchAddOnProductsDetails[0].instrumentDetails[i].componentSet;  
			if(componentData!=null){			
				componentLength=componentData.length;  
			}
                            
            //tblData1+="<div class='add-prod-row'>"; 
			tblData1+="<div class='add-prod-row' data-item='"+data[i].itemNo+"' data-ItemGuid='"+data[i].itemGuid+"' data-OrderedProd='"+data[i].orderedProd+"' data-SystemId='"+data[i].systemId+"'>";
                if(componentLength > 0){
                    componentCounter++;
                    if(componentLength > 1){
                        componentDisplayHeader = $('#addon_view').val() +' '+componentLength+' '+$('#addon_components').val();
                    }
                    else{
                        componentDisplayHeader = $('#addon_view').val()+' '+componentLength+' '+$('#addon_comp_small').val();
                    }
                tblData1+="<div class='add-prod-col fixed-column'><p>"+data[i].systemDesc+"</p><a class='accordion-section-title' id='"+data[i].itemNo+"' data-src='accordion-"+componentCounter+"'>"+componentDisplayHeader+" <i class='fas fa-caret-down'></i></a></div>";                                 
            } 
            else{
                tblData1+="<div class='add-prod-col fixed-column'><p>"+data[i].systemDesc+"</p></div>";
            } 

            
             var rowCounter=0;
            for(var j=0; j < uniqueConfigLength; j++){                               
            	//tblData1+='<div class="add-prod-col '+confighiddenval[j]+'-list"><div class="custom-checkbox disabled-check"><span class="custom-tooltip" data-title="'+$('#addonSysUnavailable').val()+'"><input type="checkbox" class="custChecked" readonly id='+confighiddenval[j]+'><span class="adddollr"></span></span></div></div>';
				rowCounter=rowCounter+1;
			if(confighiddenval[j] == 'EPASS') {
            	tblData1+='<div class="add-prod-col '+confighiddenval[j]+'-list"><div class="custom-checkbox disabled-check"><span class="custom-tooltip" data-title="'+$('#addonSysUnavailable').val()+'"><input type="checkbox" data-id="'+rowCounter+'" class="custChecked" readonly id='+confighiddenval[j]+'><span class="adddollr"></span></span></div><span class="active-text">'+jQuery("#epassVal").val()+'</span></div>';
            }
            else {
            	tblData1+='<div class="add-prod-col '+confighiddenval[j]+'-list"><div class="custom-checkbox disabled-check"><span class="custom-tooltip" data-title="'+$('#addonSysUnavailable').val()+'"><input type="checkbox" data-id="'+rowCounter+'" class="custChecked" readonly id='+confighiddenval[j]+'><span class="adddollr"></span></span></div></div>';
            }
            }

            var configValLength=targetElt.results.length;
            for(var k=0; k < configValLength; k++){                             
                //tblData1+='<input type="hidden" name="configColVal" id="configColVal" data-price='+targetElt.results[k].price+ ' value='+targetElt.results[k].addonType+'>';
				tblData1+='<input type="hidden" name="configColVal" id="configColVal" data-addonPrdId="'+targetElt.results[k].addonPrdId+ '" data-currency="'+targetElt.results[k].currency+ '" data-priceInt="'+targetElt.results[k].price+ '" data-price="'+targetElt.results[k].formattedPrice+ '" value="'+targetElt.results[k].addonType+'">';
            }  
                        
            tblData1+='</div>';  
                
        }
        
        tblResult1+=tblData1;                                
        $('.adding-product-tbody').html(tblResult1);   
        jQuery(".adding-product-tbody .add-prod-row:not(.accord-row)").each(function(){
            var counterVal=counter++;
        jQuery(this).attr("id","system"+counterVal);
		jQuery(this).addClass("parentrow");
		jQuery(this).addClass(jQuery(this).attr("data-item"));
        });        
        $('.adding-product-table .adding-product-thead .add-prod-row').prepend('<div class="add-prod-col fixed-column"></div>');
        
        var egsDateFlag = false;
        for (var i = 0; i < fetchaddlen; i++) {
            componentData=response.fetchAddOnProductsDetails[0].instrumentDetails[i].componentSet;   
            if(componentData!=null){	
				componentLength=componentData.length;       
			}  
            for(var k=0; k < componentLength; k++){
                var itemNo=response.fetchAddOnProductsDetails[0].instrumentDetails[i].itemNo; 
                //alert(itemNo);  
                //jQuery(".adding-product-tbody .add-prod-row.accord-row").addClass(itemNo);
                                
                if(data[i].itemNo == componentData[k].itemNo){ 
                    var egsdateData = componentData[k].egsdate;
                    if(egsdateData != "") {
                    	egsDateFlag = true;
                    }
                    tblCompData+='<div class="add-prod-row '+componentData[k].itemNo+'">';
                    tblCompData+='<div class="add-prod-col"><p>'+componentData[k].modelDesc+'</p></div>';
                    tblCompData+='<div class="add-prod-col"><p>'+componentData[k].modelNo+'</p></div>';
                    tblCompData+='<div class="add-prod-col"><p>'+componentData[k].serialNo+'</p></div>';
                    tblCompData+='<div class="add-prod-col"><p>'+componentData[k].egsdate+'</p></div>';                             
                    tblCompData+='</div>'; 
                }
            }
        }
        var egsDateComp = "";
        if(egsDateFlag) {
        	var egsDateComp = "<div class='add-prod-col'><h5>"+$('#addon_guarantee').val()+"<span data-tooltip='"+$('#addon_partsavailable').val()+"'><i aria-hidden='true' class='fa fa-question-circle'></i></span></h5></div>";
        }
        jQuery(".adding-product-tbody .add-prod-col.fixed-column").each(function(){
            if(jQuery(this).find("a").hasClass("accordion-section-title")){ 
                accordTitle=jQuery(this).find(".accordion-section-title").attr("data-src");                                
                jQuery(this).parent().after("<div class='add-prod-row accord-row'><div class='add-prod-row-inner' id='"+accordTitle+"'><div class='add-prod-row prod-row-head'><div class='add-prod-col'> <h5>"+$('#addon_component').val()+"</h5></div><div class='add-prod-col'><h5>"+$('#addon_module').val()+"</h5></div> <div class='add-prod-col'><h5>"+$('#addon_serial').val()+"</h5></div>"+egsDateComp+"</div></div></div>");                            
            }                                    
        });
        tblCompResultData+=tblCompData;
         $('.add-prod-row.accord-row .add-prod-row.prod-row-head').after(tblCompResultData);   
			$(document).on("click", '.accordion-section-title', function(e) {
            $('.accordion-section-title').removeClass('active');
             jQuery(".productsRepairQuote .accord-row .add-prod-row:not(.prod-row-head)").hide();
             var itemId= jQuery(this).attr("id");
             jQuery(this).parents(".add-prod-row").siblings(".accord-row").find(".add-prod-row."+itemId).css("display","flex");
			 var display = $(this).parents('.add-prod-row').next('.add-prod-row').find('.add-prod-row-inner').css('display');
				var data = $(this).attr('data-src');
				if (display === 'block') {
					$('#' + data).slideToggle(250);
					$(this).removeClass('active');
				} else {
					$('.add-prod-row-inner').slideUp(250);
					$('#' + data).slideDown(250);
					$(this).addClass('active');
				}
         });
		 
		var currCode="";
		//currCode=jQuery('#configColVal').attr('data-currency');
		$('input#configColVal').each(function(){
			console.log($(this).attr('data-currency'));
			if($(this).attr('data-currency') != ''){
				currCode = $(this).attr('data-currency');
			}
		}); 
		jQuery(".estimatedTotal span").text("("+ currCode+")");
		
		var addonTotalLoad="";
		var countryCode="",grossAmtToDisplay="";
		if(grossAmt !="" && grossAmt !=undefined){
           jQuery(".productsRepairQuote #custom-main-wrapper .custom-total .custom-right-ul .customOrignalPrice input").val(grossAmt);  
			//jQuery("#custom-main-wrapper .custom-total .custom-right-ul .customOrignalPrice #customOrignalPrice,#custom-main-wrapper .custom-total .custom-right-ul .customESTOTALPrice #customESTOTALPrice").text(grossAmt); 
        }  
		if($.cookie('CountryCode') != undefined) {
				   countryCode= $.cookie('CountryCode');    
		}
		grossAmtToDisplay=jQuery(".productsRepairQuote #custom-main-wrapper .custom-total .custom-right-ul .customOrignalPrice input").val();		
		if((countryCode=="US" || countryCode=="GB") && currCode!=""){
			addonTotalLoad = new Intl.NumberFormat(countryCode, { style: 'currency', currency: currCode ,currencyDisplay: 'symbol' }).format($("#customAddONPrice").text());
			jQuery("#customAddONPrice").text(addonTotalLoad);
			orgTotalLoad = new Intl.NumberFormat(countryCode, { style: 'currency', currency: currCode ,currencyDisplay: 'symbol' }).format(grossAmtToDisplay);
			jQuery("#customOrignalPrice").text(orgTotalLoad);
			estTotalLoad = new Intl.NumberFormat(countryCode, { style: 'currency', currency: currCode ,currencyDisplay: 'symbol' }).format(grossAmtToDisplay);
			jQuery("#customESTOTALPrice").text(estTotalLoad);
		}
		else if(currCode == 'EUR') {
			countryCode = 'FR';
			var addonPriceVal=$("#customAddONPrice").text();
			addonTotalLoad = new Intl.NumberFormat(countryCode,{'minimumFractionDigits': '2'}).format(addonPriceVal);
			jQuery("#customAddONPrice").text(addonTotalLoad+" "+currCode);	
			orgTotalLoad = new Intl.NumberFormat(countryCode,{'minimumFractionDigits': '2'}).format(grossAmtToDisplay);
			jQuery("#customOrignalPrice").text(orgTotalLoad+" "+currCode);
			estTotalLoad = new Intl.NumberFormat(countryCode,{'minimumFractionDigits': '2'}).format(grossAmtToDisplay);
			jQuery("#customESTOTALPrice").text(estTotalLoad+" "+currCode);
		}
		else{
			var addonPriceVal=$("#customAddONPrice").text();
			addonTotalLoad = new Intl.NumberFormat(countryCode).format(addonPriceVal);
			jQuery("#customAddONPrice").text(currCode+" "+addonTotalLoad);	
			orgTotalLoad = new Intl.NumberFormat(countryCode).format(grossAmtToDisplay);
			jQuery("#customOrignalPrice").text(currCode+" "+orgTotalLoad);
			estTotalLoad = new Intl.NumberFormat(countryCode).format(grossAmtToDisplay);
			jQuery("#customESTOTALPrice").text(currCode+" "+estTotalLoad);			
		}
		
		$(".adding-product-table-wrapper input[type=checkbox]").uniform();
		jQuery(".adding-product-tbody .add-prod-row").each(function(){                            
            var tempid = jQuery(this).attr("id");
            jQuery('#'+jQuery(this).attr("id")+' #configColVal').each(function(){
            if(jQuery(this).val()!=""&&jQuery(this).val()!="undefined"){
            var priceResult=$(this).attr("data-price");   
            var priceIntResult=$(this).attr("data-priceInt");
			var addonIdResult=$(this).attr("data-addonPrdId");
                                                        
            if(priceResult!="" && priceResult!="undefined" && priceResult!="null"){
				$('#'+tempid+' #'+jQuery(this).val()).prop("readonly",false);
				$('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").removeClass("disabled-check");
				$('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").find(".custom-tooltip").removeAttr("data-title");
				$('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").addClass("enable-checkbox");   
			}           
            if(priceIntResult!=""){
                $('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").find(".checker input").val(parseInt(priceIntResult));   
            }         
			 if(addonIdResult!=""){
				$('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").find(".checker input").attr("data-addonPrdId",addonIdResult);   
			}	
            if(priceResult!="" && priceResult!="undefined" && priceResult!="null"){
                $('#'+tempid+' #'+jQuery(this).val()).parents(".custom-checkbox").find(".checker").siblings(".adddollr").text("+"+priceResult); 
            }
            }
                                             
            });
        });
		console.log('4');
		for(var i=0; i < $(document).find('#configListVal').val().split(',').length; i++){
			if($('.adding-product-tbody .parentrow').length == $(document).find('.adding-product-tbody .parentrow .'+$(document).find('#configListVal').val().split(',')[i]+'-list .disabled-check').length) {           
				$('.adding-product-thead .'+$(document).find('#configListVal').val().split(',')[i]+'-config .custom-checkbox').addClass('disabled-check');
				$('.adding-product-thead .'+$(document).find('#configListVal').val().split(',')[i]+'-config .custom-checkbox .custCheckedimg').attr('readonly',true);
			}
		}	
		console.log('5');
		jQuery(".productsRepairQuote .add-prod-row-inner .add-prod-row .add-prod-col:last-child p").each(function(){
			var dateVal=jQuery(this).text();
			if(dateVal!="undefined" && dateVal!=""){
			var dateAr = dateVal.split('-');
			var newDate = dateAr[1] + '/' + dateAr[2] + '/' + dateAr[0];
			jQuery(this).text(newDate);
			}
		});
		slideArrowCall();
		$('.productsRepairQuote.addOnQuotePage #custom-main-wrapper').show();
		LSCA.loadingSpinner.hideLoading();
		loadConfigData();
		
        },

        error: function(data) {        
            console.log('Error'+ data);

        }

    });

}

function loadConfigData() {            
    $.ajax({
        type : "GET",
        url : '/rest/model/com/agilent/commerce/FetchOrderToolsSectionDataService/fetchDetailedMediaDetails?contentType=AddOnType&atg-rest-output=json',
		//url:'/common/js/addonConfigList.json',
        cache : false,
        dataType: "json",
        success: function(response) {                        
			var addOnListResult = response.linkDetails;
			var addOnListLength = response.linkDetails.length;
			var learnMoreLink = '<a href="javaScript:void(0);" data-addon="" class="morelist" data-toggle="modal" data-target="#add-on-Compliance">'+$('#addonLearnMore').val()+' &gt;</a>';
			var spanInner = '<span class="product-caption-inner"></span>';
			for(var i=0;i<addOnListLength;i++){
					$('.'+addOnListResult[i].addOnType+'-config .product-img-caption').text(addOnListResult[i].name);
					$('.'+addOnListResult[i].addOnType+'-config .product-img-caption').append(spanInner);
					$('.'+addOnListResult[i].addOnType+'-config #smallImage').attr('src',addOnListResult[i].largeImgURL);
					$('.'+addOnListResult[i].addOnType+'-config #largeImagePath').val(addOnListResult[i].largeImgURL);
					$('.'+addOnListResult[i].addOnType+'-config #longDescValue').val(addOnListResult[i].longDesc);
					$('.'+addOnListResult[i].addOnType+'-config #titleValue').val(addOnListResult[i].name);
					$('.'+addOnListResult[i].addOnType+'-config .product-img-caption .product-caption-inner').text(addOnListResult[i].shortDesc);
					$('.'+addOnListResult[i].addOnType+'-config .product-img-caption .product-caption-inner').append(learnMoreLink);
					$('.'+addOnListResult[i].addOnType+'-config .product-img-caption .product-caption-inner .morelist').attr('data-addon',addOnListResult[i].addOnType+'-config');
			}
			/*setTimeout(function(){
				var heights = $(".productsRepairQuote .product-img").map(function ()
				{
					return $(this).height();
				}).get();

				maxHeight = Math.max.apply(null, heights);
				$(".productsRepairQuote .product-img").css('height',maxHeight);
			}, 500);*/
        },
        error: function(data) {        
            console.log('Error'+ data);
        }
    });
}


$(window).on("load",function(){
	//setTimeout(function(){
	loadJSONData();
		/*$(document).on("click", '.accordion-section-title', function(e) {
		var display = $(this).parents('.add-prod-row').next('.add-prod-row').find('.add-prod-row-inner').css('display');
		var data = $(this).attr('data-src');
		if (display === 'block') {
			$('#' + data).slideToggle(250);
		} else {
			$('.add-prod-row-inner').slideUp(250);
			$('#' + data).slideDown(250);
		}

		});  */
		
		$(document).on("click", '.adding-product-thead .custom-checkbox input[type="checkbox"]', function(e) {
	  // $('.adding-product-thead .custom-checkbox input[type="checkbox"]').click(function() {
			var indexVal = $(this).parents('.add-prod-col').index();
            if ($(this).prop("checked") == true) {
                $('.adding-product-tbody .add-prod-row').each(function() {	                        
                    if(!$(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').hasClass('disabled-check')){
                    	$(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').next('.active-text').addClass('active');
                        $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.checker > span').addClass('checked');
                        $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.adddollr').addClass('active');
                        $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.custChecked').prop( "checked", true);
                    }	                        
                });
            } else if ($(this).prop("checked") == false) {
                $('.adding-product-tbody .add-prod-row').each(function() {
                    $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').next('.active-text').removeClass('active');
                    $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.checker > span').removeClass('checked');
                    $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.adddollr').removeClass('active');
                    $(this).find('.add-prod-col').eq(indexVal).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.custChecked').prop( "checked", false );
                    
                });
            }
	});
	   
                                                        
	jQuery(".productsRepairQuote .addOnQuote-footer .back-button-grp a").attr("href","/common/myaccount/quoteDetails.jsp"+setUrlVal);
	jQuery(".productsRepairQuote .addOnQuote-footer .back-button-grp-bottom a").attr("href","/common/myaccount/renewContractPayment.jsp"+setUrlVal); 
	
	function updateTotal(){
	 var array = [];
	 var total = 0;
	 var checkboxes = document.querySelectorAll('.checked input[type=checkbox]');

	 for (var i = 0; i < checkboxes.length; i++) {
	   array.push(checkboxes[i].value);
	   
	 }
	 
	 $.each(array,function(){
	   total += parseFloat(this) || 0;
	 });
	 //console.log(total);
	 $('#customAddONPrice').text(total);
	 var ORIPrice = $(".customOrignalPrice input").val();
	 var grandTotal = (parseFloat(ORIPrice) + parseFloat(total)).toFixed(2);
	 $("#customESTOTALPrice").text(grandTotal);
	}	
	$(document).on("change", 'input[type="checkbox"]', function(e) {
		//$('input[type="checkbox"]').change(function(){	  
		 setTimeout(function(){
			//updateTotal();
			updateTotalVal();
		 }, 500);
	});		
	function updateTotalVal(){
		var array = [];
		var total = 0;
		var checkboxes = document.querySelectorAll('.checked input[type=checkbox]');
		var currCode1="";
		//currCode1=jQuery('#configColVal').attr('data-currency');
		$('input#configColVal').each(function(){
			console.log($(this).attr('data-currency'));
			if($(this).attr('data-currency') != ''){
				currCode1 = $(this).attr('data-currency');
			}
		}); 
		for (var i = 0; i < checkboxes.length; i++) {
		array.push(checkboxes[i].value);
		
		}
		
		$.each(array,function(){
		total += parseFloat(this) || 0;
		});
		//console.log(total);
		$('#customAddONPrice').text(total);
		 $('.customAddONPrice input').val(total);
		var ORIPrice = $(".customOrignalPrice input").val();

		var grandTotal = (parseFloat(ORIPrice) + parseFloat(total)).toFixed(2);
		$("#customESTOTALPrice").text(grandTotal);
		$(".customESTOTALPrice input").val(grandTotal);
		if (window.Intl && typeof window.Intl === "object"){
			var estTotal="",addonTotal="";
            if((countryCode=="US" || countryCode=="GB") && currCode1!=""){			 
				estTotal= new Intl.NumberFormat(countryCode, { style: 'currency', currency: currCode1 ,currencyDisplay: 'symbol' }).format($(".customESTOTALPrice input").val());
				addonTotal= new Intl.NumberFormat(countryCode, { style: 'currency', currency: currCode1 ,currencyDisplay: 'symbol' }).format($(".customAddONPrice input").val());
			jQuery("#customESTOTALPrice").text(estTotal);
			jQuery("#customAddONPrice").text(addonTotal);
			}
			else if(currCode1 == 'EUR') {
				countryCode = 'FR';
				estTotal= new Intl.NumberFormat(countryCode,{'minimumFractionDigits': '2'}).format($(".customESTOTALPrice input").val());
			    addonTotal= new Intl.NumberFormat(countryCode,{'minimumFractionDigits': '2'}).format($(".customAddONPrice input").val());
				jQuery("#customESTOTALPrice").text(estTotal+" "+currCode1);
			    jQuery("#customAddONPrice").text(addonTotal+" "+currCode1);
			}
			else{
				estTotal= new Intl.NumberFormat(countryCode).format($(".customESTOTALPrice input").val());
			    addonTotal= new Intl.NumberFormat(countryCode).format($(".customAddONPrice input").val());
				jQuery("#customESTOTALPrice").text(currCode1+" "+estTotal);
			    jQuery("#customAddONPrice").text(currCode1+" "+addonTotal);

		} 
	}
	}
	$(document).on("click", '.custom-checkbox input[type="checkbox"]', function(e) {
	//$('.custom-checkbox input[type="checkbox"]').click(function() {
		if(!$(this).parents('.custom-checkbox').hasClass('disabled-check')){
        	var indexValinner = $(this).parents('.add-prod-col').index();
            if ($(this).prop("checked") == true) {
                $(this).parents('.custom-checkbox').next('.active-text').addClass('active');
                $(this).parents('.custom-checkbox').find('.adddollr').addClass('active');
            } else if ($(this).prop("checked") == false) {
            	var indexValinner = $(this).parents('.add-prod-col').index();
            	$(this).parents('.custom-checkbox').next('.active-text').removeClass('active');
                $(this).parents('.custom-checkbox').find('.adddollr').removeClass('active');
                $('.adding-product-thead .add-prod-row').each(function() {
                	 $(this).find('.add-prod-col').eq(indexValinner).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.checker > span').removeClass('checked');   
                	 $(this).find('.add-prod-col').eq(indexValinner).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.custCheckedimg').prop( "checked", false );
                });
            }
            
            var countLength = 0;
            var indexValinnerNew = $(this).parents('.add-prod-col').index();
            countLength = $('.add-prod-col').find('input[data-id=' + indexValinnerNew + ']').length;
            var countLengthDesable = $('.add-prod-col').find('input[data-id=' + indexValinnerNew + ']').parents('.disabled-check').length;
            countLengthChecked = $('.add-prod-col').find('input[data-id=' + indexValinnerNew + ']:checked').length;
            if(countLength == (countLengthChecked + countLengthDesable)) {        		                   			
            	$('.adding-product-thead .add-prod-col').eq(indexValinner).find('.custom-checkbox input[type="checkbox"]').prop( "checked", true );
            	$('.adding-product-thead .add-prod-col').eq(indexValinner).find('.custom-checkbox input[type="checkbox"]').parents('.custom-checkbox').find('.checker > span').addClass('checked');	
            }
    	}
    });

	
	
	$(document).on("click", ".morelist", function(e) {
		$('.modal-dialog .add-on-content').html('');
		$('.productsRepairQuote .add-on-modal-popup .modal-container').removeAttr('style');
		$('.modal-dialog .add-on-image #largeImage').attr('src',$('.'+$(this).attr('data-addon')+' #largeImagePath').val());
		$('.modal-dialog .modal-title').html($('.'+$(this).attr('data-addon')+' #titleValue').val());
		$('.modal-dialog .add-on-content').html($('.'+$(this).attr('data-addon')+' #longDescValue').val());
		/*setTimeout(function(){
			//console.log($('.modal-dialog .add-on-content').height());
			//console.log($('.modal-dialog .add-on-image').height());
			if($('.modal-dialog .add-on-content').height() > $('.modal-dialog .add-on-image').height()) {
				$('.productsRepairQuote .add-on-modal-popup .modal-container').css('height',$('.modal-dialog .add-on-content').height()+60+'px');
			}
			else {
				$('.productsRepairQuote .add-on-modal-popup .modal-container').css('height','380px');
			}
		}, 500);*/
	});
	
	var ItemsSet = [];
	$(document).on("click", "#requestAddonQuote", function(e) {
		ItemsSet = [];
		var checkboxFlag = false;
		$('.parentrow').each(function() {
			var settings = [];
			if($('.'+$(this).attr('data-item')+' .custChecked:checked').length > 0) {
				checkboxFlag = true;
			}
			/*else {
				checkboxFlag = false;
			}*/
			$('.'+$(this).attr('data-item')+' .custChecked:checked').each(function() {
				if($(this).attr('value') != '' && $(this).attr('value') != undefined) {
				settings.push({
						AddonType: $(this).attr('id'),
						AddonPrdId: $(this).attr('data-addonprdid')
				});
				}
			});
			ItemsSet.push({
				ItemNo: $(this).attr('data-item'),
				ItemGuid: $(this).attr('data-ItemGuid'),
				OrderedProd: $(this).attr('data-OrderedProd'),
				SystemId: $(this).attr('data-SystemId'),
				AddOnProductsSet: settings
			});
			
		});	
		var AdjustedQuoteValue = "";
		if(getUrlParam('originalQuoteId')){
			AdjustedQuoteValue = "X";
		}

		var d ={
				"d": {
			"ContactId": $('#contactIDValue').val(),
			"QuoteId": $('#quoteId').val(),
			"AdjustedQuote": AdjustedQuoteValue,
			"ItemsSet":ItemsSet

		}
		}
		//console.log(ItemSet);
		jsonString = JSON.stringify(d);
		//console.log(jsonString);
		//console.log('checkboxFlag : '+checkboxFlag);
		if(checkboxFlag){
			$('.productsRepairQuote.addOnQuotePage #custom-main-wrapper #addOnErrorMsg').hide();
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
				url : '/rest/model/com/agilent/commerce/LynxServiceActor/requestForAddOnQuote?atg-rest-output=json',
			data : jsonString,
			beforeSend : function() {
					LSCA.loadingSpinner.showLoading();
			},
			success: function(data) {
				if(data.success == true) {
						LSCA.loadingSpinner.hideLoading();
					window.location.href = "/common/myaccount/reviewQuoteThankYou.jsp?addonadjustind=true";
				}	
			},
			error: function() {
				console.log('error');
			}
		});
		}
		else {
			$('.productsRepairQuote.addOnQuotePage #custom-main-wrapper #addOnErrorMsg').show();
		}

	});


  //}, 500);
});