// Checkout file upload	
$( document ).ready(function() {	
	if($("#custom-main-wrapper" ).hasClass( "serviceAgreementNew")){
		//$(window).on('resize',uploadwidthcheck);
		/*function uploadwidthcheck(){
			var uploadwrapwidth = $('.uploadWrap').width();
			var uploadwrapwidth = Math.ceil(uploadwrapwidth - ($('.uploadWrap .uploadTagWrap + span').outerWidth()+23));
			$('.uploadWrap div.uploadTagWrap').width(uploadwrapwidth);
			$('.uploadWrap .errorWrap').width(uploadwrapwidth+2);		
		}
		$('#uploadcheckbox').change(function(e) {
			if ($(this).is(':checked')) {
				$('.uploadinputwrap').show();
				uploadwidthcheck()
			} else {
				$('.uploadinputwrap').hide();
			}
		});*/
		var uploadfilename = ['test'];
		var noOfFileoToUpload = 3;
		var maxFileSize = 1, encodedStrText="";
		var fileExtention = /\.(doc|docx|pdf|bmp|jpg|png)$/i
		$(document).on('click', '.uploadWrap .fileName ul li span + span', function() {
			$(this).parent().remove();
			uploadfilename.splice(uploadfilename.indexOf($(this).prev().text()), 1);
			$('.uploadWrap .errorWrap').hide();
			$('.uploadWrap div.uploadTagWrap').removeClass('uploaderror');
			console.log('uploadfilename: ' + uploadfilename);
			if($("#custom-main-wrapper .uploadWrap .fileName ul li").length < 1){
				$("#custom-main-wrapper.serviceAgreementNew #btnPOPlaceOrder").attr("disabled",false);
				$("#custom-main-wrapper.serviceAgreementNew #agreeCheckbox").hide().prop('checked', false); 
				$("#custom-main-wrapper.serviceAgreementNew .termsContentother").hide();
				$("#custom-main-wrapper.serviceAgreementNew .termsContentother + .termsContentother").show(); 
				//$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition").hide();
				//$("#custom-main-wrapper.serviceAgreementNew .custom-place").removeClass("tcShow");
				$("#tandcErrorMsg").hide();		
				$("#tandcErrorMsg").removeClass("tcErrHide");					
				$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition .termsContentother").removeClass("requiredTextBoxClass");
			}
		})
		$('.uploadWrap #myfile').on('change', function() {
			fileval = $(this).val();
			filesize = (this.files[0].size / 1024) / 1024;
			//alert(filesize)
			if (fileval != '') {
				fileval = fileval.match(/\\([^\\]+)$/)[1];
				$('.uploadWrap .textWrap').text(fileval);
				$('.uploadWrap .errorWrap').hide();
				$('.uploadWrap div.uploadTagWrap').removeClass('uploaderror');
				readURL(this);
			}
			if (!(fileExtention).test(fileval) && fileval != '') {
				if (uploadfilename.length < noOfFileoToUpload + 1) {
					$('.uploadWrap .errorWrap').show();
					$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
					$('.uploadWrap .errorWrap').html($('.uploadWrap #filetype').val())
					clearfilename()
				}
			}
			if (uploadfilename.length < noOfFileoToUpload + 1) {
				if (filesize >= maxFileSize) {
					$('.uploadWrap .errorWrap').show();
					$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
					$('.uploadWrap .errorWrap').html($('.uploadWrap #maxfilesize').val())
					clearfilename()
					return false;
				}
			} else {
				$('.uploadWrap .errorWrap').show();
				$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
				$('.uploadWrap .errorWrap').html($('.uploadWrap #maxfile').val())
				clearfilename()
			}
			if (fileval == '') {
				clearfilename()
			}
		})

		function clearfilename() {
			$('.uploadWrap .textWrap').text($('.uploadWrap #noFileChosen').val());
			$('.uploadWrap #myfile').val('')
			return false;
		}
		function readURL(input) {
			  if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.readAsDataURL(input.files[0]); // convert to base64 string
				reader.onload = function(e) {
				  //$('#blah').attr('src', e.target.result);
				  //console.log(e.target.result);
				  encodedStrText = e.target.result;
				}
				
			  }
		}
		$('.uploadWrap .uploadTagWrap + span').on('click', function() {
			fileval = $('.uploadWrap #myfile').val();
			
			
			if (fileval == '') {
				$('.uploadWrap .errorWrap').show();
				$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
				$('.uploadWrap .errorWrap').html($('.uploadWrap #filetype').val())
			} else {
				fileval = fileval.match(/\\([^\\]+)$/)[1];
				uploadfilenamestring = uploadfilename.toString()
				if (uploadfilenamestring.search(fileval) > 1) {
					if (uploadfilename.length < noOfFileoToUpload + 1) {
						$('.uploadWrap .errorWrap').show();
						$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
						$('.uploadWrap .errorWrap').html($('.uploadWrap #duplicatefile').val())
						return false;
					} else {
						$('.uploadWrap .errorWrap').show();
						$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
						$('.uploadWrap .errorWrap').html($('.uploadWrap #maxfile').val())
						clearfilename()
					}
				} else {
					if (uploadfilename.length < noOfFileoToUpload + 1) {
						var base64String = encodedStrText.replace('data:', '').replace(/^.+,/, '');
						var mimeType =   encodedStrText.split(';')[0].split(':')[1];
						var encodedValue = encodedStrText.split('base64,')[1];

						$('.uploadWrap .fileName ul').append('<li class="uploadedFiles-li"><span>' + fileval + '</span><span></span><input type="hidden" class="uploadedFileName" value="'+ fileval +'"/><input type="hidden" class="mimeType" value="'+ mimeType +'"/><input type="hidden" class="encodedFileText" value="'+ encodedValue +'"/></li>');
						uploadfilename.push(fileval);
						clearfilename();
						$('.uploadWrap .errorWrap').hide();
						$('.uploadWrap div.uploadTagWrap').removeClass('uploaderror');
						if(isEmpty($(".uploadWrap .fileName ul li"))){
							//$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition").hide();
							//$("#custom-main-wrapper.serviceAgreementNew .custom-place").removeClass("tcShow");
							$("#custom-main-wrapper.serviceAgreementNew #agreeCheckbox").hide();
							$("#custom-main-wrapper.serviceAgreementNew .termsContentother").hide();
							$("#custom-main-wrapper.serviceAgreementNew .termsContentother + .termsContentother").show(); 							
							$("#custom-main-wrapper.serviceAgreementNew #btnPOPlaceOrder").attr("disabled",true);
							}
						else{
							//$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition input").prop("checked",false);
							$("#custom-main-wrapper.serviceAgreementNew #btnPOPlaceOrder").attr("disabled",true);
							$("#custom-main-wrapper.serviceAgreementNew #agreeCheckbox").show();
							$("#custom-main-wrapper.serviceAgreementNew .termsContentother").show();
							$("#custom-main-wrapper.serviceAgreementNew .termsContentother + .termsContentother").hide(); 							
							//$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition").show();
							//$("#custom-main-wrapper.serviceAgreementNew .custom-place").addClass("tcShow");
							$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition .termsContentother").removeClass("requiredTextBoxClass");
						}
					} else {
						$('.uploadWrap .errorWrap').show();
						$('.uploadWrap div.uploadTagWrap').addClass('uploaderror');
						$('.uploadWrap .errorWrap').html($('.uploadWrap #maxfile').val());
						clearfilename();
					}
					//console.log('fileval: ' + fileval)
				}
				
				
				
				//console.log('uploadfilename: ' + uploadfilename)
			}
			//console.log(uploadfilename.length)
		})

	
		$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition input").on("change",function() {
			if($(this).prop("checked") == true){
				$("#custom-main-wrapper.serviceAgreementNew #btnPOPlaceOrder").attr("disabled",false);
				$("#tandcErrorMsg").hide();		
				$("#tandcErrorMsg").removeClass("tcErrHide");
				$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition .termsContentother").removeClass("requiredTextBoxClass");
			}
			else{
				$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition input").prop("checked",false);
				$("#custom-main-wrapper.serviceAgreementNew #btnPOPlaceOrder").attr("disabled",true);
				$("#tandcErrorMsg").show();
				$("#tandcErrorMsg").addClass("tcErrHide");
				$("#custom-main-wrapper.serviceAgreementNew .custom-place .terms-condition .termsContentother").addClass("requiredTextBoxClass");
			}
		});	
}
	    }); 
		
		
	function iterateFiles(result1){
		var AttachmentSet = [];
		
		//var lis = document.getElementById("ul_o").getElementsByTagName("li")
		
	$("#uploadedFiles .uploadedFiles-li").each(function() {
	var fileName=$(this).find(".uploadedFileName").val();
	var mimeType=$(this).find(".mimeType").val();
	var fileContent=$(this).find(".encodedFileText").val();
	var quoteIdFromPage = $("#quoteIdFromPage").val();
	if(fileName != undefined && fileContent != undefined){
					attachment = {
								"QuoteId" : quoteIdFromPage,
								"FileName" : fileName,
								"MimeName" : mimeType,
								"IvContent" : fileContent
							};
				AttachmentSet.push(attachment);
				result1['AttachmentSet']=AttachmentSet;
				
				console.log("value" + JSON.stringify(result1));
				//$('#finalAttachments').val(JSON.stringify(result1));
	}
});

	$.ajax({
			type : "POST",
			url : "/rest/model/com/agilent/commerce/SessionBeanDataSaver/getUploadedFileContent", 
			contentType : "application/json; charset=utf-8",
			data : JSON.stringify({
				"attachmentSetJson": JSON.stringify(result1)}),
			success : function(data,textStatus, jQxhr) {
				$('#sbmtOrder').click();
				$("#btnPOPlaceOrder").prop('disabled',true);

			},
			error : function(jqXhr,textStatus, errorThrown) {
				  console.log(errorThrown);
			}
		});

}
	