 $(document).ready(function () {
    var activedata="",expiredata="", rowActive = "",fsperror="",row="",username="",j=0;
    
    if (typeof contactno === 'undefined' || contactno === null || contactno == "") { 
        // Redirect only if enablement flow error is NOT present
        if (enableFlowErr == null || enableFlowErr == "") {
         // window.location.href ="/common/myaccount/RedirectionDummypage.jsp";
          $(location).attr('href',fspredirection); 
        }
    }
    
    /* Chinese Translation */
    var FSPCheckSession = $.cookie('agilent_locale');   
    var FSPsession = {};
    /*switch(FSPCheckSession){
        case "zh_CN":
            FSPsession.planNumber = "灵活购买计划账号";
            FSPsession.balance = "余额";
            FSPsession.planerror = "对不起，没有找到相关信息";
            break;
        
        default:*/
            FSPsession.planNumber = $("#planNumber").val();
            FSPsession.balance = $("#balanceTxt").val();
            FSPsession.planerror = $("#planErrorTxt").val();
           /* break;
    }*/
    $.ajax({
    type: 'POST',
    url: '/rest/model//com/agilent/profile/fsp/FspService/getFlexibleSpendPlanDetails?atg-rest-output=json&contactno='+contactno,
    dataType: 'json',
    success: function(data) {
        
        var activedata = $.grep(data.getBasePlanDetailsResponse.responseData, function(v) {
                    return v.Status == "Active";
                });
        var expiredata = $.grep(data.getBasePlanDetailsResponse.responseData, function(v) {
                    return v.Status == "Expired";
                });
                
                if($("#active").is(':checked'))
            {                           
                if(activedata.length == 0 && expiredata.length >= 1) 
                {
                $('#fsp-data').empty();
                fsperror = '<div class="fsp-error"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.planerror + '</p></div>';
                $('#fsp-data').html(fsperror);
                }
                else if(expiredata.length == 0 && activedata.length == 0 )
                {
                    $('#fsp-data').empty();
                    // Redirect only if enablement flow error is NOT present
                    if (enableFlowErr == null || enableFlowErr == "") {
                        //window.location.href = "/common/myaccount/RedirectionDummypage.jsp";
                        $(location).attr('href',fspredirection); 
                    }
                }
                else 
                {
                    $.each(activedata, function (j) {
                    
                    if(activedata[j].UserName != "")
                    {
                        var username = activedata[j].UserName;
                    }
                    else
                    {
                        var username = activedata[j].UserAddress1.split("|", 1);
                    }
                    
                    rowActive += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ activedata[j].PlanNumber +'">' + FSPsession.planNumber + '<span>' + activedata[j].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' +activedata[j].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + activedata[j].UserAddress2 + '</span><br/><span>' + activedata[j].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + activedata[j].BalanceFunds + '&nbsp;<span>' + activedata[j].Currency + '</span></h3></div></div></div>';
                    });
                    $('#fsp-data').empty();
                    $('#fsp-data').html(rowActive);
                    $(".mainContainer.FlexibleSpendPlan").removeAttr("style");
                    $(".mainContainer.Fspplandetails").removeAttr("style");
                    LSCA.getFooterextend();   
                }
        
            }   
            
        $(".filterCheck").on("change", function() {
        rowActive = "",fsperror="",row="",username="";
        
        if($("#active").is(':checked'))
        { 
            if(activedata.length == 0 && expiredata.length >= 1)  
            {
                $('#fsp-data').empty();
                fsperror = '<div class="fsp-error"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.planerror + '</p></div>';
                $('#fsp-data').html(fsperror);
            }
            else
            {
                $.each(activedata, function (j) {
                    
                    if(activedata[j].UserName != "")
                    {
                        var username = activedata[j].UserName;
                    }
                    else
                    {
                        var username = activedata[j].UserAddress1.split("|", 1);
                    }
                    
                    rowActive += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ activedata[j].PlanNumber +'">' + FSPsession.planNumber + '<span>' + activedata[j].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' +activedata[j].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + activedata[j].UserAddress2 + '</span><br/><span>' + activedata[j].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + activedata[j].BalanceFunds + '&nbsp;<span>' + activedata[j].Currency + '</span></h3></div></div></div>';
                });
            $('#fsp-data').empty();
            $('#fsp-data').html(rowActive);
            $(".mainContainer.FlexibleSpendPlan").removeAttr("style");
            $(".mainContainer.Fspplandetails").removeAttr("style");
            LSCA.getFooterextend(); 
            }
            
        }
        
        
        if($("#deactive").is(':checked'))
        {
            if(activedata.length >= 1 && expiredata.length == 0) 
            {
                $('#fsp-data').empty();
                fsperror = '<div class="fsp-error"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.planerror + '</p></div>';
                $('#fsp-data').html(fsperror);
            }
            
            else
            {
                $.each(expiredata, function (j) {
                    
                    if(expiredata[j].UserName != "")
                    {
                        var username = expiredata[j].UserName;
                    }
                    else
                    {
                        var username = expiredata[j].UserAddress1.split("|", 1);
                    }
                rowActive += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ expiredata[j].PlanNumber +'">' + FSPsession.planNumber + '<span>' + expiredata[j].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' +expiredata[j].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + expiredata[j].UserAddress2 + '</span><br/><span>' + expiredata[j].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + expiredata[j].BalanceFunds + '&nbsp;<span>' + expiredata[j].Currency + '</span></h3></div></div></div>';
                });
            $('#fsp-data').empty();
            $('#fsp-data').html(rowActive);
            $(".mainContainer.FlexibleSpendPlan").removeAttr("style");
            $(".mainContainer.Fspplandetails").removeAttr("style");
            LSCA.getFooterextend(); 
            }
        }
        
        
        
        if($("#deactive").is(':checked') && $("#active").is(':checked'))
        {
            rowActive="",row="",username="";
            if(expiredata.length == 0 && activedata.length >=1 )
            {
                $.each(activedata, function (j) {
                    if(activedata[j].UserName != "")
                    {
                        var username = activedata[j].UserName;
                    }
                    else
                    {
                        var username = activedata[j].UserAddress1.split("|", 1);
                    }
                    rowActive += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ activedata[j].PlanNumber +'">' + FSPsession.planNumber + '<span>' + activedata[j].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' +activedata[j].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + activedata[j].UserAddress2 + '</span><br/><span>' + activedata[j].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + activedata[j].BalanceFunds + '&nbsp;<span>' + activedata[j].Currency + '</span></h3></div></div></div>';
                });
            $('#fsp-data').empty();
            $('#fsp-data').html(rowActive);
            $(".mainContainer.FlexibleSpendPlan").removeAttr("style");
            $(".mainContainer.Fspplandetails").removeAttr("style");
            LSCA.getFooterextend(); 
            }
            if(activedata.length == 0 && expiredata.length >=1 )
            {
                $.each(expiredata, function (j) {
                    
                    if(expiredata[j].UserName != "")
                    {
                        var username = expiredata[j].UserName;
                    }
                    else
                    {
                        var username = expiredata[j].UserAddress1.split("|", 1);
                    }
                rowActive += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ expiredata[j].PlanNumber +'">' + FSPsession.planNumber + '<span>' + expiredata[j].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' +expiredata[j].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + expiredata[j].UserAddress2 + '</span><br/><span>' + expiredata[j].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + expiredata[j].BalanceFunds + '&nbsp;<span>' + expiredata[j].Currency + '</span></h3></div></div></div>';
                });
            $('#fsp-data').empty();
            $('#fsp-data').html(rowActive); 
            $(".mainContainer.FlexibleSpendPlan").removeAttr("style");
            $(".mainContainer.Fspplandetails").removeAttr("style");
            LSCA.getFooterextend(); 
            }
            if(activedata.length >= 1 && expiredata.length >=1 )
            {
                
                for(var i = 0; i < data.getBasePlanDetailsResponse.responseData.length; i++)
                {
                    
                    if(data.getBasePlanDetailsResponse.responseData[i].UserName != "")
                    {
                        var username = data.getBasePlanDetailsResponse.responseData[i].UserName;
                    }
                    else
                    {
                        var username = data.getBasePlanDetailsResponse.responseData[i].UserAddress1.split("|", 1);
                    }
                    
                row += '<div class="row plan-detail"> <div class="col-md-12 plan-info"><div class="col-md-9 info-left"><h3 class="plannum"> <a href="/common/myaccount/plan-details.jsp?&contactno='+contactno+'&PlanNumber='+ data.getBasePlanDetailsResponse.responseData[i].PlanNumber +'">' + FSPsession.planNumber + '<span>' + data.getBasePlanDetailsResponse.responseData[i].PlanNumber + '</span></a></h3><h4>' + username + '</h4><p><span>' + data.getBasePlanDetailsResponse.responseData[i].UserAddress1.replace(/[^a-zA-Z 0-9]+/g,' ') + '</span><br/><span>' + data.getBasePlanDetailsResponse.responseData[i].UserAddress2 + '</span><br/><span>' + data.getBasePlanDetailsResponse.responseData[i].UserAddress3 + '</span></p></div><div class="col-md-3 bal"><h4 class="pull-right">' + FSPsession.balance + '</h4><h3 class="pull-right append-martop-20 clearfix">' + data.getBasePlanDetailsResponse.responseData[i].BalanceFunds + '&nbsp;<span>' + data.getBasePlanDetailsResponse.responseData[i].Currency + '</span></h3></div></div></div>';
                
                }
                $('#fsp-data').empty();
                $('#fsp-data').html(row);
            }
        }
        
        if(!$("#deactive").is(':checked') && !$("#active").is(':checked')){ 
        $('#fsp-data').empty(); 
        }
        }); /* End of on change */
        },
            
    error: function(error){
        // Redirect only if enablement flow error is NOT present
        if (enableFlowErr == null || enableFlowErr == "") {
            //window.location.href = "/common/myaccount/RedirectionDummypage.jsp";
            $(location).attr('href',fspredirection); 
        }
    }       
    
        });  /* End of ajax */

 }); /* End */