/*
 * @Description: This is to overwried the Agilent header for testing as ATG2 header is not there in WCS.
 * @Author: Naveen Singh
*/

//************************ DO NOT MAKE ANY CHANGES BELOW ************************ //
// Avoid `console` errors in browsers that lack a console.
	if(location.hostname==='www.chem1.agilent.com'){
		prodCosURLDomain="www.chem1.agilent.com:7003";
	}

	if(location.hostname==='ddgdatg2.cos.agilent.com'){
		prodCosURLDomain="ddgdatg2.cos.agilent.com:8000";
	}
	if(location.hostname==='ddgdatg1.cos.agilent.com'){
		prodCosURLDomain="ddgdatg1.cos.agilent.com:8000";
	}

$(document).ready(function(){
	
	if(location.hostname==='ddgdatg2.cos.agilent.com'){
		$('a').each(function() { 
		    var $this = $(this);
		   // alert( $this.attr('href'));
		    var data=$this.attr('href')||'';
		    $this.attr('href', data.replace('stgwww.cos.agilent.com','ddgdatg2.cos.agilent.com:8000')); //set the value of an attribute 'href'
		    $this.attr('href', data.replace('www.chem.agilent.com','ddgdatg2.cos.agilent.com:8000')); //set the value of an attribute 'href'
		});	
	}
	
	if(location.hostname==='ddgdatg1.cos.agilent.com'){
		$('a').each(function() { 
		    var $this = $(this);
		   // alert( $this.attr('href'));
		    var data=$this.attr('href')||'';
		    $this.attr('href', data.replace('stgwww.cos.agilent.com','ddgdatg1.cos.agilent.com:8000')); //set the value of an attribute 'href'
		    $this.attr('href', data.replace('www.chem.agilent.com','ddgdatg1.cos.agilent.com:8000')); //set the value of an attribute 'href'
		});	
	}
	
	if(location.hostname==='www.chem1.agilent.com'){
		$('a').each(function() { 
		    var $this = $(this);
		   // alert( $this.attr('href'));
		    var data=$this.attr('href')||'';
		    $this.attr('href', data.replace('stgwww.cos.agilent.com','www.chem1.agilent.com:7003')); //set the value of an attribute 'href'
		    $this.attr('href', data.replace('www.chem.agilent.com','www.chem1.agilent.com:7003')); //set the value of an attribute 'href'
		});	
	}
	
});


