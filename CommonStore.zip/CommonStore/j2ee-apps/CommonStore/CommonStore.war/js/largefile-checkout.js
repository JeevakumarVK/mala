$(document).ready(function() {
	if($(".largeCheckout #orderSplitCount").val() > 1){		
		jQuery(".largeCheckout .showLegalEntityMsg").show();
		}
	else{
		jQuery(".largeCheckout .showLegalEntityMsg").hide();
	}
	var salesOrgArr=[];
	if($.cookie("CountryCode") === 'CN'){
		$('.largeFileCheckout #productTable > tbody >  tr:not(.last,.order-summaryrow,.dgMessageSection)').each(function(){
		salesOrgArr.push($(this).find("td.Sales-org").attr("data-salesorg"));
		});
		var uniqueSalesOrg = salesOrgArr.filter(function(item, i, salesOrgArr) {
			return i == salesOrgArr.indexOf(item);
		});
		if(uniqueSalesOrg.length  == 1 && uniqueSalesOrg.indexOf("04C9") > -1){
			jQuery(".largeCheckout .shipto-note-sub").hide();
		}else{
			jQuery(".largeCheckout .shipto-note-sub").show();
		}
	}
    $(document).on('click', '#custom-change-shipAddress #editShippingAddr', function(e) {
        $("#shipto-remove-msg1").css('display', 'none');
        $("#changeshippingAddressModal").html('');
        var checkedShippingAddressId = $("#checkedAddressId").val();
        LSCA.loadingSpinner.showLoading();
        $.ajax({
                type: "POST",
                url: "/common/checkout/largeFileChangeShippingAddressPopup.jsp?slectedShipAddressId=" + checkedShippingAddressId,
                dataType: "html"
            })
            .done(function(msg) {
                $("#changeshippingAddressModal").html(msg);
                if ($('#shippingPopUpList .shipAddressList ul li.cust-paym').length > 1) {
                    $('#changeshippingAddressModal .submitSection .set-default').show();
                } else {
                    $('#changeshippingAddressModal .submitSection .set-default').hide();
                }
                //$("#default-shipAddress").uniform();
                LSCA.loadingSpinner.hideLoading();

                setTimeout(function() {
                    var intViewportHeight = window.innerHeight;
                    var intShipToAddtHeight = $("#changeshippingAddressModal .modal-dialog").height();
                    if (intShipToAddtHeight >= intViewportHeight) {
                        $('#changeshippingAddressModal .modal-dialog').css({
                            'top': '0'
                        });
                        $('#changeshippingAddressModal .modal-dialog').css({
                            'transform': 'none'
                        });
                    } else {
                        $('#changeshippingAddressModal .modal-dialog').css({
                            'top': '50%'
                        });
                        $('#changeshippingAddressModal .modal-dialog').css({
                            'transform': '-50%'
                        });
                    }
                }, 500);

            }).fail(function() {
                console.log('Something went wrong!');
                LSCA.loadingSpinner.hideLoading();
            });
    });
    $(document).on('click', '#lcselectshipaddress', function(e) {
        var topshipaddr = "";
        var currentAddrIdVal = "";
        $(document).on('click', '#editBillingDiv .verifiedLink-checkout', function(e) {
            currentAddrIdVal = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
        });
        var selectedshipaddr = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').val();
        var selectedaddrId = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
        getValuelc4(null, selectedshipaddr, currentAddrIdVal, selectedaddrId);
        $("#changeshippingAddressModal  button.close").trigger('click');
    });

    function getValuelc4(el, val, currVal, selectedAddrVal) {
        var selectedVal;
        if (el != null) {
            selectedVal = el.val();
        } else {
            selectedVal = val;
        }
        var defaultShiptoAddr = false;
        if ($("#default-shipAddress").prop('checked')) {
            defaultShiptoAddr = true;
        }
        $("#shipAddContainer").html("");
        $("#shipAddContainer").after('<div id="editShipAdress" style="display:none;"></div>');
        $('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
        $('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();

        $.ajax({
                type: "POST",
                url: "/common/checkout/largeFileDisplayShippingAddressNewDesign.jsp?" + selectedVal + "&defaultShiptoAddrFlag=" + defaultShiptoAddr,
                dataType: "html"
            })
            .done(function(msg) {
                $('.custom-after-changeshipAddress').show();
                $("#shipAddContainer").html(msg);
                $("#editShipAdress").html(msg);


                formdata = $("#ajaxRightSideAddress").html(msg).serialize();
                var selectedShipId = selectedVal.split('&')[0].split('=')[1];               
                $('#shipAddContainerOthers #attentionLF').val($('.fullBillingAddress#' + selectedShipId).find('li#hiddenShipAttn').text());
                $('#shipAddContainerOthers #buildingRoomLF').val($('.fullBillingAddress#' + selectedShipId).find('li#hiddenbuildNo').text());
                $('#shipAddContainerOthers #phoneNumberLF').val($('.fullBillingAddress#' + selectedShipId).find('li#hiddenPhoneNo').text());
                //copyfromHidden();
                /*LSCA.loadingSpinner.showLoading();
                LSCA.globalAjax.doCall({
                                url: '/common/checkout/ajaxCheckoutShipping.jsp',
                                data: formdata,
                                context: $(this),
                               target: $(this)
                }, function (data) {
                                var msg = data.data;
                                if (msg.status == 'success') {
                                                console.log(msg.status);
                                                LSCA.loadingSpinner.hideLoading();
                                                if (currVal != selectedAddrVal) {
                                                                //stickyPriceDetails();
                                                }
                                }
                                else if (msg.status == 'failure') {
                                                LSCA.loadingSpinner.hideLoading();
                                                console.log('Something went wrong!')
                                }
                });*/
            }).fail(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }

    $(document).on('click', '#editBillingDiv #editlcBillingAddr', function(e) {
        $("#changebillingAddressModal").html('');
        var checkedBillingAddressId = $('#checkedBillingAddressId').val();
        LSCA.loadingSpinner.showLoading();
        $.ajax({
                type: "POST",
                url: "/common/checkout/largeFileChangeBillingAddressPopup.jsp?slectedBillAddressId=" + checkedBillingAddressId,
                dataType: "html"
            })
            .done(function(msg) {
                $("#changebillingAddressModal").html(msg);
                if ($('#shippingPopUpList .shipAddressList ul li.cust-paym').length > 1) {
                    $('#changebillingAddressModal .submitSection .set-default').show();
                } else {
                    $('#changebillingAddressModal .submitSection .set-default').hide();
                }
                //$("#default-shipAddress").uniform();
                LSCA.loadingSpinner.hideLoading();

                setTimeout(function() {
                    var intViewportHeight = window.innerHeight;
                    var intShipToAddtHeight = $("#changeshippingAddressModal .modal-dialog").height();
                    if (intShipToAddtHeight >= intViewportHeight) {
                        $('#changebillingAddressModal .modal-dialog').css({
                            'top': '0'
                        });
                        $('#changebillingAddressModal .modal-dialog').css({
                            'transform': 'none'
                        });
                    } else {
                        $('#changebillingAddressModal .modal-dialog').css({
                            'top': '50%'
                        });
                        $('#changebillingAddressModal .modal-dialog').css({
                            'transform': '-50%'
                        });
                    }
                }, 500);

            }).fail(function() {
                console.log('Something went wrong!');
                LSCA.loadingSpinner.hideLoading();
            });
    });

    $(document).on('click', '#lcselectbillingaddress', function(e) {
        var topshipaddr = "";
        var selectedbilladdr = $('#shippingPopUpList ul li input[name=selectBillingAddress]:checked').val();
        var selectedbillId = $('#shippingPopUpList ul li input[name=selectBillingAddress]:checked').attr('id');

        getBillAddrValue(null, selectedbilladdr);
        $("#changebillingAddressModal  button.close").trigger('click');
    });

    function getBillAddrValue(el, val) {
        var selectedVal;
        if (el != null) {
            //selectedVal=$('input[class=selectShippingAddress]:checked').val();
            selectedVal = el.val();
        } else {
            selectedVal = val;
        }
        var defaultBilltoAddr = false;
        if ($("#default-billAddress").prop('checked')) {
            defaultBilltoAddr = true;
        }
        $("#billToAddContainer").html("");
        $('.billingAddress-wrap #custom-change-BillAddress .fullBillingAddress').remove();
        $('.billingAddress-wrap .billingAddressBlock #newBillingAdd').remove();
        $.ajax({
                type: "POST",
                url: "/common/checkout/largeFileDisplayBillingAddressNewDesign.jsp?" + selectedVal + "&defaultBillAddrFlag=" + defaultBilltoAddr,
                dataType: "html"
            })
            .done(function(msg) {
                $("#billToAddContainer").html(msg);
                if($("#changeInvoiceCode1").val() != '') {
                    document.getElementById("invoiceCode1").value = $("#changeInvoiceCode1").val();
                    $('#changeInvoiceCode1').val("");
                }
                else {
                    $('#invoiceCode1').val("");
                }
                if($("#changeInvoiceCode2").val() != '') {
                    document.getElementById("invoiceCode2").value = $("#changeInvoiceCode2").val();
                    $('#changeInvoiceCode2').val("");
                }
                else {
                    $('#invoiceCode2').val("");
                }
                if($("#changeInvoiceCode3").val() != '') {
                    document.getElementById("invoiceCode3").value = $("#changeInvoiceCode3").val();
                    $('#changeInvoiceCode3').val("");
                }
                else {
                    $('#invoiceCode3').val("");
                } 
                if($("#changeInvoiceCodeOthers").val() != '') {
                    document.getElementById("invoiceCodeOthers").value = $("#changeInvoiceCodeOthers").val();
                    $('#changeInvoiceCodeOthers').val("");
                }
                else {
                    $('#invoiceCodeOthers').val("");
                }
                if($("#changeEanNumber").val() != '') {
					document.getElementById("eanNumber").value = $("#changeEanNumber").val();
					$('#changeEanNumber').val("");
				}	
				else {
					$('#eanNumber').val("");
				}
                
            })
            .fail(function() {
                console.log('Something went wrong!')
            });

    }
	lcsubmitButtonCheck();
	$(document).on('click', '.largeCheckout #shiptocustomer', function(e) {
    e.stopPropagation();
    $('#inputShipto').attr('style', '');

    $('#inputShipto').removeClass('requiredTextBox required');

    $('.shipToEntryFields .mTextlc').hide();

    $('.shipToFields > label').removeClass('lcrequiredLabel');

    $('.shipToEntryFields #errorShipLabel').html('').hide();

    $('.rightaddressDiv label').removeClass('requiredLabel');

    $('.rightaddressDiv .rightMandatoryFields input').removeClass('requiredTextBox');

    $('.rightaddressDiv .rightMandatoryFields span.mText').hide();
    formdata = $('#inputShipto').val();
    /*formdata = $('#fetchshipLargeFile').serialize();		
    var dovalidate = LSCA.GlobalValidate.init({

        target : '#inputShipto'

    });*/
    if ($('#inputShipto').val() == "") {
        $('#inputShipto').attr('style', '');
        $('#inputShipto').addClass('requiredTextBox required');
        $('.shipToEntryFields .mTextlc').show();
        $('.shipToFields > label').addClass('lcrequiredLabel');
        $('.shipToEntryFields #errorShipLabel').html('').hide();
    } else {
        //formtype = 'form#fetchship';

        LSCA.globalAjax.doCall({

            url: '/common/checkout/ajaxFetchShiptoIdAddressForLargeFile.jsp?shipToId=' + formdata,

            data: formdata,

            context: $(this),

            target: $(this)

        }, function(data) {

            var shiptocontinuemsg = data.data;

            //params_.btn = data.target;

            if (shiptocontinuemsg.status != 'success') {

                console.log('error');

                //if (shiptocontinuemsg.innerHTML.indexOf('Please enter valid ship to number.') != -1) {

                $('#inputShipto').attr('style', '');

                $('#inputShipto').addClass('requiredTextBox required');

                $('.shipToEntryFields .mTextlc').hide();

                $('.shipToFields > label').addClass('lcrequiredLabel');

                $('.shipToEntryFields #errorShipLabel').html(shiptocontinuemsg.innerHTML).show();

                // }

            } else {

                $("#custom-change-shipAddress").hide();
                $('#inputShipto').removeClass('requiredTextBox required');
                $('.shipToFields > label').removeClass('lcrequiredLabel');
                $('#shipto-Address').show();
                
                $("#shipAddContainer").html(shiptocontinuemsg.innerHTML);

                $("#shipto-Address").html(shiptocontinuemsg.innerHTML);
                $("#custom-change-shipAddress #customDropdown2").val($("#shipto-Address #customDropdown2").val());


            }
        });
    }
});

$(document).on('click', '.largeCheckout #lcshipto-address-remove', function(e) {
    e.preventDefault();
    document.getElementById("optionsRadios2").checked = false;
    $("#inputShipto").attr("disabled", "disabled");
    $("#shiptocustomer").css('display', 'none');
    $('.customDropshipWrap').css('display', 'none');
    $("#shipto-remove-msg1").css('display', 'block');
    $("#disabled-shiptocustomer").css('display', 'inline-block');
    $('#shipto-Address').hide();
    $("#shipAddContainer").html("");
    $('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
    $('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
    $.ajax({
            type: "POST",
            url: "/common/checkout/ajaxFetchDefaultShippingAddressForLargeFile.jsp",
            dataType: "html"
        })
        .done(function(msg) {
            $("#shipAddContainer").html(msg);
            $('.custom-after-changeshipAddress').show();
            $("#shipAddContainer").html(msg);
        })
    $("#custom-change-shipAddress").show();
});

var $checkboxes = $('.largeCheckout .shipToDesc #optionsRadios2');
var countUnCheckedCheckboxes = $checkboxes.filter('#optionsRadios2').length;
$checkboxes.on('change',function() {
    var countCheckedCheckboxes = $checkboxes.filter(':checked').length;
    if (countCheckedCheckboxes > 0) {
        $('.customDropshipWrap').css('display', 'block');
        $("#dropShipmentCheck").val($("#optionsRadios2").val());
        $("#shipToNumber").val($("#inputShipto").val());
        $("#shiptocustomer").show();
        $("#disabled-shiptocustomer,.shipToEntryFields .mTextlc,#shipto-remove-msg1,#errorShipLabel").hide();
        $("#inputShipto").prop("disabled", false);
        $('#inputShipto').addClass('required');

    } else {
        $('.customDropshipWrap').css('display', 'none');
        $("#shiptocustomer").hide();
        $("#disabled-shiptocustomer").css('display', 'inline-block');
        $("#inputShipto").attr("disabled", "disabled");
        $('.shipToFields > label').removeClass('lcrequiredLabel');
        $('#inputShipto').removeClass('requiredTextBox required');
    }
});
if(jQuery(".largeCheckout #dangerousGoods").val() == "true"){
	jQuery(".largeCheckout .custom-future-date-wrap #consolidateRadio1").parents("li").hide();
	jQuery(".largeCheckout .lcdangerous-msg").show();
}
if($(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").length == 1 && $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").length == 1) {
	   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").css('margin-bottom','10px');
	   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").css('margin-bottom','20px');
	}
if($(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").length == 1 && $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").length == 0) {
   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").css('margin-bottom','20px');
   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").css('margin-bottom','0px');
}
if($(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").length == 0 && $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").length == 1) {
   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-info").css('margin-bottom','0px');
   $(".largeCheckout .deliveryMethodBlock-wrap .msg-stnd.msg-box-warning").css('margin-bottom','20px');
}
});

function lcsubmitButtonCheck(){
	if(jQuery('.largeCheckout #productTable > tbody >  tr:not(.last)').length > 0){
		jQuery(".largeCheckout .order-summary-total-section #reviewOrder").prop("disabled",false)
	}
	else{
		jQuery(".largeCheckout .order-summary-total-section #reviewOrder").attr("disabled", true)
	}
}
function lcremoveLineItem(){
	  /** Remove Ajax Call*/
	jQuery('.largeCheckout').on('click','.largefile-remove a',function(e){
		jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.qty-errormsg,.largeFileCheckout #chekoutItemSection .msg-stnd.partno-errormsg").hide();
		jQuery(".largeFileCheckout #addpartlc input").removeClass("requiredTextBox");
		LSCA.loadingSpinner.showLoading();
		$.ajax({
				type : "GET",
				url : "/store/includes/ajax/ajaxRemoveLineItem.jsp?part_number="+$(this).attr("part-data"),
				dataType : "json",
				targetElt: $(this),
				success : function(data) {				
				LSCA.loadingSpinner.hideLoading();
				if(data.status =="success"){
					jQuery(this.targetElt).parents('tr').prev(".dgMessageSection").remove();					
					$(this.targetElt).parents('tr').remove();
					if($(".largeCheckout .dgMessageSection").length == 0){
						jQuery(".largeCheckout .custom-future-date-wrap #consolidateRadio1").parents("li").show();
						jQuery(".largeCheckout .lcdangerous-msg").hide();
					}
					if(jQuery('.largeCheckout #productTable > tbody >  tr:not(.last)').length > 0){
						jQuery(".largeCheckout .order-summary-total-section #reviewOrder").prop("disabled",false);
					}
					else{
						jQuery(".largeCheckout .order-summary-total-section #reviewOrder").attr("disabled", true);
					}
					if(data.containColdShipment == true){						
						$(".largeCheckout #shipAttention #attentionLF,.largeCheckout #shipBuilding #buildingRoomLF").addClass('required');
						$('#shipAttention label span,#shipBuilding label span').removeClass('hide')
					}else{
						$(".largeCheckout #shipAttention #attentionLF,.largeCheckout #shipBuilding #buildingRoomLF").removeClass('required');
						$('#shipAttention label span,#shipBuilding label span').addClass('hide');
						$('#shipAttention #attentionLF,#shipBuilding #buildingRoomLF').next().next().hide();
						$('#shipAttention #attentionLF,#shipBuilding #buildingRoomLF').prev('.f14').removeClass('requiredLabel');
						$('.shipingAddressFields input').removeClass('requiredTextBox');
						$('#shipAttention #attentionLF,#shipBuilding #buildingRoomLF').parent().parent('.formGroup').css('margin-bottom', '15px');
						$('#shipAttention #attentionLF,#shipBuilding #buildingRoomLF').css('borderColor','');
					}	
					if(data.showShipPhone != "true"){
						$(".largeCheckout #shipPhone").addClass("displayNone");
						$(".largeCheckout #shipPhone #phoneNumberLF").removeClass('required');
					}
					if(data.showShipPhoneJPnonReq == "true"){
						$(".largeCheckout #shipPhoneJPnonReq").removeClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq").addClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq #phoneNumberLF").removeClass('required');
					}
					if(data.showShipPhoneJPReq == "true"){
						$(".largeCheckout #shipPhoneJPnonReq").addClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq").removeClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq #phoneNumberLF").addClass('required');
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').next().next().hide();
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').prev('.f14').removeClass('requiredLabel');
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').css('borderColor','');
					}
					$(".largeCheckout #largeFileUploadTable #orderTotalVal .orderTotalValField").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table #subTotalVal").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table #orderTotalVal").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table .finalItemCount,.largeFileCheckout #chekoutItemSection .msg-stnd.msg-box-success span strong").text(data.finalItemCount);
					jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg span").text("");
					jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg span").text(data.statusMessage);
					jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd").hide();
					jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg").show();				
					var salesOrgArr=[];
					if($.cookie("CountryCode") === 'CN'){
						$('.largeFileCheckout #productTable > tbody >  tr:not(.last,.order-summaryrow,.dgMessageSection)').each(function(){
						salesOrgArr.push($(this).find("td.Sales-org").attr("data-salesorg"));
						});					
						var uniqueSalesOrg = salesOrgArr.filter(function(item, i, salesOrgArr) {
							return i == salesOrgArr.indexOf(item);
						});
						if(uniqueSalesOrg.length == 1 && uniqueSalesOrg.indexOf("04C9") > -1){
							jQuery(".largeCheckout .shipto-note-sub").hide();
						}else{
							jQuery(".largeCheckout .shipto-note-sub").show();
						}
					}
				}
				LSCA.globalAjax.doCall({
					url: '/store/includes/ajax/ajaxCheckShipOption.jsp'
				}, function(data) {
					var msg = data.data;
					if (msg.status == 'success') {
						$('#largeFileShipOprion').hide();
						$("#shipOptionEdited").html('');
                        $("#shipOptionEdited").html(msg.innerHTML);
                        $("#shipOptionEdited").show();
					}
				});
				
				},
				error : function() {
					console.log('Something went wrong!')
				}
			});
	});
}

jQuery(window).on("load",function(){
	lcremoveLineItem();
	 checkRadiobtn();
});

function checkRadiobtn() {
	if ($("#purchaseOrder").prop("checked")) {
		$('.custom-payment-mode li').removeClass('radioActive');
		$("#purchaseOrder").parent().addClass('radioActive');
        $('.custom-credit-wrap').hide();
        $('#lrg-cc-info').hide();
	}else if($("#creditCard").prop("checked")){
		$('.custom-payment-mode li').removeClass('radioActive');
		$("#creditCard").parent().addClass('radioActive');
		$(".custom-payment-mode li #po").removeClass("required requiredTextBox");
		$(".custom-payment-mode li #po").next().next().hide();
		$(".custom-payment-mode li #po").css("border-color","#B1B3B3");
        $('.custom-credit-wrap').show();
        $('#lrg-cc-info').show();
        
	}else{
		$('.custom-payment-mode li').removeClass('radioActive');
		$("#flexibleSpendPlan").parent().addClass('radioActive');
		$(".custom-payment-mode li #po").removeClass("required requiredTextBox");
		$(".custom-payment-mode li #po").next().next().hide();
		$(".custom-payment-mode li #po").css("border-color","#B1B3B3");
        $('.custom-credit-wrap').hide();
        $('#lrg-cc-info').hide();
	}
}
$('.cust-paym input[type=radio]:not(.shippingAddressPopup)').on('change',function() {
	checkRadiobtn();
});
/* sticky code starts*/

var widgetOffset = $(".order-summary-outer").offset();
var leftPos = '';
var widgetHt = 0;
var setCurrentPos = 0;
var cartContainer_height = '';
var window_top = 0;
var top = 0;
var cart_offset = 0;
$(window).on('scroll',function (event) {

	window_top = $(window).scrollTop();
	topspace = $('#totalPriceWidget-here').offset().top;
	cart_offset = $('.custom-master-wraper').offset().top;
	cartContainer_height = $('.custom-master-wraper').innerHeight();
	widgetHt = $('#totalOuter').innerHeight();;


	if (widgetOffset.left === 0) {
		widgetOffset = $("#totalPriceWidget-here").offset();
		leftPos = widgetOffset.left - 21 + 'px';
	}

	if (window_top > topspace) {
		if (window_top >= (cartContainer_height - widgetHt)) {
			$('.order-summary-outer').removeClass('stick').addClass('float');
			if (setCurrentPos == 0) {
				setCurrentPos = cartContainer_height - widgetHt;
				setCurrentPos = setCurrentPos + 'px';
				$('.order-summary-outer').css({ 'top': setCurrentPos });
			}
		} else {
			$('.order-summary-outer').addClass('stick').removeClass('float');
		}

	} else {
		$('.order-summary-outer').removeClass('float').removeClass('stick');
		setCurrentPos = 0;
	}
});
/* sticky code ends*/