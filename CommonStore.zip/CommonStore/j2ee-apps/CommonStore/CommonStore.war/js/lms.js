$(document).ready(function(){
$(".loader-overlay").show();
alert('lmsfunction');	
$.ajax({
    type: 'POST',
    url: '/rest/model/com/agilent/commerce/lms/LMSService/getAccessKeyValiditiy?trainingKey='+trainingKey+'&atg-rest-output=json',
    dataType: 'json',
    success: function(data) {	
	 $(".loader-overlay").hide();
		var lmsResponse=data.getAccessKeyValiditiyResponse.lmsresponseMessage;
		$('.lmsResponseMsg').html(lmsResponse);
		 },           
    error: function(error){
		alert('error in response');
		}         
});  
});