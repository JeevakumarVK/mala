function triggerSavedCartCall(saveCartId) {
	if ($("#mainContainer").hasClass('mySavedCart')) {
		LSCA.loadingSpinner.showLoading();
	}
	var urlString="";
	if(saveCartId!="" && saveCartId!= undefined){
		urlString="/rest/model/com/agilent/commerce/SavedCartDetailService/savedCartDetailService?atg-rest-output=json&savedCartId="+saveCartId+"&fromCart=true";
	}
	else{
		urlString="/rest/model/com/agilent/commerce/SavedCartDetailService/savedCartDetailService?atg-rest-output=json";
	}
    $.ajax({
            type: "GET",
            url:urlString,
            dataType: "json",
        })
        .done(function(response) { 
        	if ($("#mainContainer").hasClass('mySavedCart')) {		
				LSCA.loadingSpinner.hideLoading();		
			}
            if (response.savedCartDetailsResponse.empty_cart != "" && response.savedCartDetailsResponse.empty_cart != undefined) {
                $(".mySavedCart #emptysavedcart-err span").text(response.savedCartDetailsResponse.empty_cart);
                $(".mySavedCart #emptysavedcart-err").show();
                $("#custom-main-wrapper-expand .myOrderStatuss .favoriteList + .contentSection").hide();
            } else {
            	if(!jQuery.isEmptyObject(response.savedCartDetailsResponse)){
                $(".mySavedCart #catlogListView").children().remove();
                var data = response.savedCartDetailsResponse.savedCartList,
                    tableData;
                for (var key in data.savedCartIdList) {
                    if (key) {                        
						var liList = '<li id="' + key + '" data-scval="' + key + '" class="secondary-catalogList1">' + data.savedCartIdList[key] + '<i id="edit-' + key + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true"></i></li>';
                        $(".mySavedCart #catlogListView").append(liList);
                    }
                }
				if(saveCartId!="" && saveCartId!= undefined){
					var urlParamVal = decodeURIComponent(getUrlParam('savedCartId'));
					$('.mySavedCart #catlogListView li[data-scval="'+ urlParamVal +'"]').addClass('active');
					
				}
				else{
					 $(".mySavedCart #catlogListView li:nth-child(1)").addClass("active");
				}
                $(".mySavedCart a#emailCatalog-link").attr('href', '/common/myaccount/emailSavedCart.jsp?savedCartId=' + encodeURIComponent($(".mySavedCart #catlogListView li.active").attr('id')));
                var cartList = "",
                    setCartFlagVal = false,
                    setKeyVal = "",
                    cartItemKey = "";
                for (var itemKey in data.savedCartIdList) {
                    cartList = response.savedCartDetailsResponse.savedCartItems[itemKey];
                    for (var key in response.savedCartDetailsResponse.savedCartItems) {
                        if (itemKey === key) {
                            setCartFlagVal = true;
                            setKeyVal = key;
                        }
                    }
                }
                if (setCartFlagVal) {
                    $.each(response.savedCartDetailsResponse.savedCartItems[setKeyVal], function(i) {
                        var currentIndex = response.savedCartDetailsResponse.savedCartItems[setKeyVal][i];
                        tblrow = '<tr data-comId=' + currentIndex.commerceItem + ' id=tbl_' + currentIndex.partNumber + '>';
                        if (currentIndex.designId != "" && currentIndex.designId != undefined) {
                            if (currentIndex.guideName != "" && currentIndex.guideName != undefined) {
                                tblrow += ' <td>' + currentIndex.partNumber + " - " + currentIndex.designId + " " + currentIndex.guideName + '</td>';
                            } else {
                                if (currentIndex.designId != "emptyDes") {
                                    tblrow += ' <td>' + currentIndex.partNumber + " - " + currentIndex.designId + '</td>';
                                } else {
                                    tblrow += ' <td>' + currentIndex.partNumber + '</td>';
                                }
                            }
                        } else {
                            tblrow += ' <td>' + currentIndex.partNumber + '</td>';
                        }
                        tblrow += ' <td>' + currentIndex.description + '</td>';
                        tblrow += ' <td>' + currentIndex.listPrice + '</td>';
                        tblrow += ' <td class="yourPrice-List priceloading"><span class="tbl-loading"></span></td>';
                        if (currentIndex.designId != "" && currentIndex.designId != undefined) {
                            tblrow += ' <td class="noPrint"><input name="' + currentIndex.partNumber + ':' + currentIndex.designId + '" type="text" value="' + currentIndex.quantity + '" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + currentIndex.partNumber + ':' + currentIndex.designId + '" /></td>';
                        } else {
                            tblrow += ' <td class="noPrint"><input name="' + currentIndex.partNumber + '" type="text" value="' + currentIndex.quantity + '" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + currentIndex.partNumber + '" /></td>';
                        }
                        tblrow += ' <td class="noPrint"><a href="javascript:void(0);" part-data="' + currentIndex.partNumber + '" class="removesavedcart"><i class="fal fa-trash-alt deletePartNo"></i></a></td>';
                        tableData += tblrow;
                    });
                }

                $(".mySavedCart #quoteResult").find('.skyblueTable tbody').html('');
                $(".mySavedCart #quoteResult").find('.skyblueTable tbody').html(tableData);
				$(".mySavedCart .favListEdit1 .giftList-Heading").text($(".mySavedCart #catlogListView li.active").text());
				$(".mySavedCart .favListEdit1 i").attr("id",$('.mySavedCart #catlogListView li.active i').attr("id"));
				$(".mySavedCart .favListEdit1").attr("id",$('.mySavedCart #catlogListView li.active').attr("id"));
                getPriceList();
				/*if(saveCartId!="" && saveCartId!= undefined){
					window.location = "/common/myaccount/mySavedCartNew.jsp";
					onClickSavedCartCall(savedCartId);
					
				}*/
            }
            }
        })
        .fail(function() {
            console.log('Something went wrong!');
        });
}

function onClickSavedCartCall(savedCartId) {
    LSCA.loadingSpinner.showLoading();
    $.ajax({
            type: "GET",
           url: "/rest/model/com/agilent/commerce/SavedCartDetailService/savedCartDetailService?atg-rest-output=json&savedCartId=" + encodeURIComponent(savedCartId),
			//url:"/common/js/mockdata.json?savedCartId="+ savedCartId,
            dataType: "json",
        })
        .done(function(response) {
            LSCA.loadingSpinner.hideLoading();
            jQuery("#mycatlogList ul li").removeClass("hide-pointer");
            $(".msg-stnd,#partNo-splchar-error").hide();
			$(".favListEdit1 input").remove();
			$(".giftList-Heading").css("display", "inline-block");
			$('.catlogtext-edit').removeClass('requiredName');
			$(".favListEdit1 i").attr("id",$('#catlogListView li.active i').attr("id"));
			$(".favListEdit1").attr("id",$('#catlogListView li.active').attr("id"));
			$(".favListEdit1 i").attr("data-editval",$('#catlogListView li.active i').attr("id"));
			$(".mySavedCart a#emailCatalog-link").attr('href', '/common/myaccount/emailSavedCart.jsp?savedCartId=' + encodeURIComponent($(".mySavedCart #catlogListView li.active").attr('id')));
			if(!jQuery.isEmptyObject(response.savedCartDetailsResponse)){
            var data = response.savedCartDetailsResponse.savedCartList,
                tableData;
            var cartList = "",
                setCartFlagVal = false,
                setKeyVal = "",
                cartItemKey = "",
                itemKey = "";
            itemKey = $(".mySavedCart #catlogListView li.active").attr("data-scval");
            cartList = response.savedCartDetailsResponse.savedCartItems[itemKey];
            for (var key in response.savedCartDetailsResponse.savedCartItems) {
                if (itemKey === key) {
                    setCartFlagVal = true;
                    setKeyVal = key;
                }
            }
            if (setCartFlagVal) {
                $.each(response.savedCartDetailsResponse.savedCartItems[setKeyVal], function(i) {
                    var currentIndex = response.savedCartDetailsResponse.savedCartItems[setKeyVal][i];
                    tblrow = '<tr data-comId=' + currentIndex.commerceItem + ' id=tbl_' + currentIndex.partNumber + '>';
                    if (currentIndex.designId != "" && currentIndex.designId != undefined) {
                        if (currentIndex.guideName != "" && currentIndex.guideName != undefined) {
                            tblrow += ' <td>' + currentIndex.partNumber + " - " + currentIndex.designId + " " + currentIndex.guideName + '</td>';
                        } else {
                            if (currentIndex.designId != "emptyDes") {
                                tblrow += ' <td>' + currentIndex.partNumber + " - " + currentIndex.designId + '</td>';
                            } else {
                                tblrow += ' <td>' + currentIndex.partNumber + '</td>';
                            }
                        }
                    } else {
                        tblrow += ' <td>' + currentIndex.partNumber + '</td>';
                    }
                    tblrow += ' <td>' + currentIndex.description + '</td>';
                    tblrow += ' <td>' + currentIndex.listPrice + '</td>';
                    tblrow += ' <td class="yourPrice-List priceloading"><span class="tbl-loading"></span></td>';
                    if (currentIndex.designId != "" && currentIndex.designId != undefined) {
                        tblrow += ' <td class="noPrint"><input name="' + currentIndex.partNumber + ':' + currentIndex.designId + '" type="text" value="' + currentIndex.quantity + '" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + currentIndex.partNumber + ':' + currentIndex.designId + '" /></td>';
                    } else {
                        tblrow += ' <td class="noPrint"><input name="' + currentIndex.partNumber + '" type="text" value="' + currentIndex.quantity + '" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + currentIndex.partNumber + '" /></td>';
                    }
                    tblrow += ' <td class="noPrint"><a href="javascript:void(0);" part-data="' + currentIndex.partNumber + '" class="removesavedcart"><i class="fal fa-trash-alt deletePartNo"></i></a></td>';
                    tableData += tblrow;
                });
            }

            $(".mySavedCart #quoteResult").find('.skyblueTable tbody').html('');
            $(".mySavedCart #quoteResult").find('.skyblueTable tbody').html(tableData);
            getPriceList();
			}
        })
        .fail(function() {
            console.log('Something went wrong!');
        });
}

function getPriceList() {
    $("#print-cart").hide();
    var partNoArray = [];
    $(".mySavedCart #quoteResult .skyblueTable").find('tbody tr').each(function(i, v) {
        partNoArray.push($(this).find('td').eq(4).find('input.qtyTxtbox').attr("name").split(":")[0]);
    });
    $('.mySavedCart #partNumberList').val(partNoArray.join());
    $.ajax({
            url: '/common/getPriceForWishList.jsp?listId=' + encodeURIComponent($(".mySavedCart #catlogListView li.active").attr('id')) + '&catalogIdList=' + $('#partNumberList').val(),
            type: "POST",
            dataType: "json"
        })
        .done(function(data) {
            if (data) {
                var len = data.length;
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        $("#tbl_" + data[i].partNumber.replace('.','\\.')+ " td.yourPrice-List").html(data[i].yourprice);
                        $("#tbl_" + data[i].partNumber.replace('.','\\.') + " td.yourPrice-List").removeClass("priceloading");
                    }
                    $("#print-cart").show();
                }
            }
        })
        .fail(function() {
            console.log('Something went wrong!');
        });
}

$(document).ready(function() {
    var flagIndicator = false;
	if(getUrlParam('savedCartId')){
		triggerSavedCartCall(getUrlParam('savedCartId'));
	}
	else{
		triggerSavedCartCall();
	}
    $(document).on("click", ".mySavedCart #catlogListView li", function(e) {
        e.preventDefault();
        flagIndicator = true;
        var savedCartId = $(this).attr("id"),
            $thisVal = $(this);
        onClickSavedCartCall(savedCartId);
		jQuery(".mySavedCart .favListEdit1 i").css("display","inline-block");
		$(".mySavedCart .favListEdit1 i").attr("id",$('.mySavedCart #catlogListView li.active i').attr("id"));
		$(".mySavedCart .favListEdit1").attr("id",$('.mySavedCart #catlogListView li.active').attr("id"));	
        setTimeout(function() {
            $(".mySavedCart #catlogListView li").removeClass("active");
			$('.mySavedCart #catlogListView li[data-scval="'+ savedCartId +'"]').addClass('active');
			$(".mySavedCart .favListEdit1 .giftList-Heading").text($(".mySavedCart #catlogListView li.active").text());
        }, 500);
        $("#custom-main-wrapper-expand .mySavedCart .myOrderStatuss .prnt-header-subtitle .current-favlist").text($(".mySavedCart #catlogListView li.active").text());
});
    
$(".mySavedCart .btnSpace #btnAddToCart").on("click", function(e) {
    e.preventDefault();
    setTimeout(function() {
        $("#addToCart").trigger("click")
    }, 3000);
});
$(document).on('click', '.mySavedCart #SCAddToSubscription', function(event) {
    event.preventDefault();
    //var saveCartDetails = $('.mySavedCart #savedCart').serialize();
    //$('.mySavedCart #standingOrderProductData').val(saveCartDetails);
    //$('.mySavedCart #createSubscriptionSbmt').click();
    createSubscription($("#headBlock .favListEdit1").attr("id"));
});
function createSubscription(orderId) {
    $('#existingOrderIdBean').val(orderId);
    $('#pageIndicatorParam').val("fromSavedCartPage");
    $('#createSubscriptionSbmt').click();
}
$(".mySavedCart #print-cart span").on("click", function() {
    $("#custom-main-wrapper-expand .mySavedCart .myOrderStatuss .prnt-header-subtitle .current-favlist").text($(".mySavedCart #catlogListView li.active").text());
});
$(".mySavedCart #delete-catalog1").on('click', function(e) {
e.preventDefault();
if (confirm($('#lblConfirmDelete').val())) {
    var deleteID = $(".mySavedCart #catlogListView li.active").attr('id');
    LSCA.loadingSpinner.showLoading();
     $.ajax({
        url: '/rest/model/com/agilent/commerce/SavedCartDetailService/deleteSavedCartService?atg-rest-output=json&savedCartId=' + encodeURIComponent(deleteID),
        type: "POST",
        dataType: "json"
    })
    .done(function(response) {
        $('#error-emptyCart,#error-messages').hide();
        if (response.deleteSavedCartServiceResponse.status == "success") {
            LSCA.loadingSpinner.hideLoading();
            $("#catlogListView li.active,.myOrderStatuss .favListEdit1 input").remove();
            $(".myOrderStatuss .giftList-Heading").css("display", "inline-block");
            jQuery("#mycatlogList ul li").removeClass("hide-pointer");
            $("#catlogListView li:nth-child(1)").addClass('active');
            $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
            if ($("#catlogListView li.active").length == 0) {
                $("#empty-catalog").hide();
				$(".mySavedCart .col-lg-9.contentSection").hide();
				$("#emptysavedcart-err span").text("");
				$("#emptysavedcart-err span").text($("#empty-savedCart").val().trim());
				$("#emptysavedcart-err").show();
            }
			if ($("#catlogListView li.active").length > 0) {	
            onClickSavedCartCall($("#catlogListView li:nth-child(1)").attr("id"));
			}
        } else {
            LSCA.loadingSpinner.hideLoading();
			$("#delsavedcart-err span").text("");
			$("#delsavedcart-err span").text(response.deleteSavedCartServiceResponse.message);
            $("#delsavedcart-err").show();
        }
    });
    }
});
$(document).on("click", ".mySavedCart tr a.removesavedcart", function(e) {
    e.preventDefault();
    LSCA.loadingSpinner.showLoading();
	var $thisVal = $(this);
	if($(".mySavedCart tr a.removesavedcart").parents('tbody tr').length>1){	
    LSCA.globalAjax.doCall({
        url: '/store/includes/ajax/ajaxRemovesavedCartLineItem.jsp?commerceItemId='+ encodeURIComponent($(this).parents("tr").attr("data-comid")) + '&orderId=' + encodeURIComponent($("#catlogListView li.active").attr("id")),
        dataType: 'json',
        type:"POST",
    }, function(data) {
        LSCA.loadingSpinner.hideLoading();
        if(data.data.errorStatus == "false"){
			$thisVal.parents('tr').remove();
		}
		else{
			LSCA.loadingSpinner.hideLoading();
			$("#delsavedcart-err span").text("");
			$("#delsavedcart-err span").text(data.data.errorMessage);
            $("#delsavedcart-err").show();
		}
    });
	}
	else{
		var deleteID = $(".mySavedCart #catlogListView li.active").attr('id');
	    LSCA.loadingSpinner.showLoading();
	     $.ajax({
	        url: '/rest/model/com/agilent/commerce/SavedCartDetailService/deleteSavedCartService?atg-rest-output=json&savedCartId=' + encodeURIComponent(deleteID),
	        type: "POST",
	        dataType: "json"
	    })
	    .done(function(response) {
	        $('#error-emptyCart,#error-messages').hide();
	        if (response.deleteSavedCartServiceResponse.status == "success") {
	            LSCA.loadingSpinner.hideLoading();
	            $("#catlogListView li.active,.myOrderStatuss .favListEdit1 input").remove();
	            $(".myOrderStatuss .giftList-Heading").css("display", "inline-block");
	            jQuery("#mycatlogList ul li").removeClass("hide-pointer");
	            $("#catlogListView li:nth-child(1)").addClass('active');
	            $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
	            if ($("#catlogListView li.active").length == 0) {
	                $("#empty-catalog").hide();
					$(".mySavedCart .col-lg-9.contentSection").hide();
					$("#emptysavedcart-err span").text("");
					$("#emptysavedcart-err span").text($("#empty-savedCart").val().trim());
					$("#emptysavedcart-err").show();
	            }
				if ($("#catlogListView li.active").length > 0) {	
	            onClickSavedCartCall($("#catlogListView li:nth-child(1)").attr("id"));
				}
	        } else {
	            LSCA.loadingSpinner.hideLoading();
				$("#delsavedcart-err span").text("");
				$("#delsavedcart-err span").text(response.deleteSavedCartServiceResponse.message);
	            $("#delsavedcart-err").show();
	        }
	    });
	}
});
});

$(document).on("click", ".mySavedCart .editFavList", function(e) {
    e.preventDefault();
    var valID = $(this).attr('id');
    var splitId = valID.split('-');
    var text = $(this).parent().text();
    var editmaxlength = 30;
    var input = $('<input class="catlogtext-edit" name="catlogtext-edit" maxlength="' + editmaxlength + '" id="text-' + splitId[1] + '"  data-textval="text-' + splitId[1] + '" type="text" value="' + text + '" /><i id="edit-' + splitId[1] + '" data-editval="edit-' + splitId[1] + '" class="fal fa-pencil editFavList" aria-hidden="true" style="display:none;"></i>')
    $(this).remove();
    $(".favListEdit1 i").remove();
    input.insertAfter(jQuery(".giftList-Heading"));
    $.fn.textWidth = function(text) {
        if (!$.fn.textWidth.fakeEl) $.fn.textWidth.fakeEl = $('<span id="hiddenStrVal">').hide().appendTo(document.body);
        $.fn.textWidth.fakeEl.text(text || this.val());
        return $.fn.textWidth.fakeEl.width();
    };

    $('.catlogtext-edit').on('input', function(e) {
        var textWidthVal = $(this).textWidth() + 20 + 'px';
        $(this).css('width', textWidthVal);
    }).trigger('input');
    $('.giftList-Heading').hide();
    $('.catlogtext-edit').val($('.giftList-Heading').text().trim());
    $('.catlogtext-edit').css("display", "inline-block");
    e.preventDefault();
    //var editText = $("#text-" + splitId[1]).val().trim();
    var editText = $(".catlogtext-edit").val().trim();
    var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
    var validList = true;
    if (pattern.test(editText)) {
        validList = false;
    } else {
        validList = true;
    }
    $('.catlogtext-edit').on("click", function(event) {
        event.stopPropagation();
    });
    input.trigger("focus");
    input.on('blur keyup', function(e) {
        if (e.type == 'blur' || e.keyCode == '13') {
            if ($(".catlogtext-edit").val().trim() != '' && validList) {
                jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                var pattern1 = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                var validList1 = true;
                if (pattern1.test($(".catlogtext-edit").val().trim())) {
                    validList1 = false;
                } else {
                    validList1 = true;
                }
                if ($(".catlogtext-edit").val().trim() != '' && validList1) {
                    jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                    LSCA.loadingSpinner.showLoading();
                    $('.catlogtext-edit').removeClass('requiredName');
                    LSCA.globalAjax.doCall({
                        url: '/rest/model/com/agilent/commerce/SavedCartDetailService/renameSavedCartService?atg-rest-output=json' + '&savedCartId=' + encodeURIComponent(splitId[1]) + '&savedCartName=' + encodeURIComponent($(".catlogtext-edit").val().trim()),
                    }, function(response) {
                        var textsplitId = splitId[1];
                        if (response.data.renameSavedCartServiceResponse.status == 'success') {
                            LSCA.loadingSpinner.hideLoading();
                            jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                            var text1 = $(".catlogtext-edit").val().trim();
                            var savedtext = $('<i data-editval1="edit-' + textsplitId + '" id="edit-' + textsplitId + '" class="fal fa-pencil editFavList" aria-hidden="true"></i>');
                            $(".catlogtext-edit").siblings(".giftList-Heading").text(response.data.renameSavedCartServiceResponse.savedCartName);
                            $(".giftList-Heading").siblings("i").show();
                            $(".giftList-Heading").css("display", "inline-block");
                            $(".catlogtext-edit").remove();
                            $(".mycatlogList ul li.active").text($(".giftList-Heading").text());
                            $('.secondary-catalogList').css('height', '');
                            if ($('.edit-catlog:visible').offset() != undefined) {
                                var calcIcon = $('.edit-catlog:visible').offset().top - $('.secondary-catalogList.active').offset().top;
                                if (calcIcon > $('.secondary-catalogList.active').height()) {
                                    $('.secondary-catalogList.active').css('height', $('.secondary-catalogList.active').outerHeight() + 18 + 'px')
                                }
                            }
                        }
						else{
							LSCA.loadingSpinner.hideLoading();
							//jQuery("#mycatlogList ul li").addClass("hide-pointer");
							LSCA.GlobalValidate.showError('', response.data.renameSavedCartServiceResponse.message);
							$('#partNo-splchar-error').show();
							$('.catlogtext-edit').addClass('requiredName');
						}
                    });
                    $('#partNo-splchar-error').hide();
                    LSCA.GlobalValidate.showError('', '');
                } else {
                    jQuery("#mycatlogList ul li").addClass("hide-pointer");
                    $('.catlogtext-edit').addClass('requiredName');
                    if ($(".catlogtext-edit").val().trim() == '' && validList1) {
                        $('#partNo-splchar-error').hide();
                        $('.favListEdit1 .catlogtext-edit').remove();
                        $('.favListEdit1 .giftList-Heading').text($('.favListEdit1 .giftList-Heading').text());
                        $(".favListEdit1 .giftList-Heading").show();
                        $(".editFavList").show();
                        $(".catlogListView ul li.active").text($('.favListEdit1 .giftList-Heading').text());
                        jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                    } else if ($(".catlogtext-edit").val().trim() != '' && !validList1) {
                        LSCA.GlobalValidate.showError('', $('.splchar-error').text());
                        $('#partNo-splchar-error').show();
                    }
                }
            } else {
                $('.catlogtext-edit').addClass('requiredName');
                jQuery("#mycatlogList ul li").addClass("hide-pointer");
                if ($(".catlogtext-edit").val().trim() == '' && validList) {
                    $('#partNo-splchar-error').hide();
                    $('.favListEdit1 .catlogtext-edit').remove();
                    $('.favListEdit1 .giftList-Heading').text($('.favListEdit1 .giftList-Heading').text());
                    $(".favListEdit1 .giftList-Heading").show();
                    $(".editFavList").show();
                    $(".catlogListView ul li.active").text($('.favListEdit1 .giftList-Heading').text());
                    jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                } else if ($(".catlogtext-edit").val().trim() != '' && !validList) {
                    LSCA.GlobalValidate.showError('', $('.splchar-error').text());
                    $('#partNo-splchar-error').show();
                }
                validList = true;
            }
        }
        e.stopPropagation();
    });
    e.stopPropagation();
});



$(document).ready(function(){
	$(document).on("click", ".widget-quote-save  a", function(e) {
	    $('#savedCartName').removeClass('requiredName');
	    $('.listnameLabel').removeClass('labelrequired');
	    $('#error-msg').hide();
	    $('.nospecialLabel').show();
	    $('#savedCartName').val('');
	    if (window.innerHeight > $("#createSavedCartPopup #dropdown-wrapper").outerHeight(true) + 74) {
	        var parentWindowHeight = window.innerHeight - 60;
	        var overLayHeight = $("#createSavedCartPopup #dropdown-wrapper").outerHeight(true) + 74;
	        var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
	        $("#createSavedCartPopup .modal-content").css("top", calcOverlayTop + 'px');
	    }
	});
	$(document).on("click", "#nosavedcart-list", function(e) {
	    e.preventDefault();
	    $(".rename-msg,#nosavedcart-list,#yessavedcart-list,#error-msg > span").hide();
	    $("#mysavedcartAdd,#createsavedcart-list").show();
	    $("#savedCartName").val("");
	    $("#error-msg > span.rename-errmsg").show();
	    $("#error-msg").show();
	    $('#savedCartName').addClass('requiredName');
	    $('.listnameLabel').addClass('labelrequired');
	});
	$(document).on("click", "#createsavedcart-list", function(e) { 
		//LSCA.loadingSpinner.showLoading();                
	    e.preventDefault();
	    var newText = $("#savedCartName").val().trim();
	    var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
	    var validList = true;
	    if (pattern.test(newText)) {
	        validList = false;
	    } else {
	        validList = true
	    }
	    if (newText != '' && validList) {

	        //if (dovalidate) {
	        LSCA.globalAjax.doCall({
	                url: "/store/includes/ajax/ajaxSaveCart.jsp?description=" + newText,
					async: false
	            },
	            function(response) {
	                if (response.data.nameAllreadyExist == "true" && response.data.errorToShow == "true") {
	                    LSCA.loadingSpinner.hideLoading();
	                    var msgSave = (response.data.message);
	                    $(".rename-msg p").html("");
	                    $(".rename-msg p").html(msgSave);
	                    $(".rename-msg,#yessavedcart-list,#nosavedcart-list").show();
	                    $("#mysavedcartAdd,#createsavedcart-list").hide();
	                } else if (response.data.errorToShow == "false") {
	                    var savedCartIdVal1=response.data.savedCartId;
						window.location = "/common/myaccount/mySavedCart.jsp?savedCartId="+encodeURIComponent(savedCartIdVal1);
						
	                } else if (response.data.errorToShow == "true") {
	                	$(".rename-msg,#yessavedcart-list,#nosavedcart-list,.nospecialLabel,.emptyText-List,.splchar-error").hide();	
	                    var msgSave = (response.data.message);
	                    $(".rename-errmsg").html("");
	                    $(".rename-errmsg").html(msgSave);	
	                    $(".rename-errmsg,#error-msg").show();				
						$("#savedCartName").val("");
						$('#savedCartName').addClass('requiredName');
						$('.listnameLabel').addClass('labelrequired');
	                }
	            });
	        $('#error-msg').hide();
	        $('#savedCartName').removeClass('requiredName');
	        $('.listnameLabel').removeClass('labelrequired');
	        //To remove below line
	        LSCA.loadingSpinner.hideLoading();
	    } else {
	        $('#error-msg').show();
	        if (newText == '') {
	            $(".emptyText-List").show();
	            $(".splchar-error,.rename-errmsg").hide();
	            $(".nospecialLabel").hide();
	            $('.listnameLabel').addClass('labelrequired');
	        } else {
	            $(".splchar-error").show();
	            $(".emptyText-List,.rename-errmsg").hide();
	            $(".nospecialLabel").hide();
	            $('.listnameLabel').addClass('labelrequired');
	        }
	        $('#savedCartName').addClass('requiredName');
	    }
	});
	$("#createSavedCartPopup").find("#yessavedcart-list").on('click', function() {
		//LSCA.loadingSpinner.showLoading();
		LSCA.globalAjax.doCall({
			url: '/store/includes/ajax/ajaxMergeSavedCart.jsp?description=' + $("#savedCartName").val().trim(),
			async: false
		}, function(data) {
			LSCA.loadingSpinner.hideLoading();
			if (data.data.errorToShow == "false") {
				var savedCartIdVal=data.data.savedCartId;
				window.location = "/common/myaccount/mySavedCart.jsp?savedCartId="+encodeURIComponent(savedCartIdVal);
			}
			else if (data.data.errorToShow == "true"){
				$(".rename-msg,#yessavedcart-list,#nosavedcart-list").hide();
				$("#mysavedcartAdd,#createsavedcart-list").show();
				$("#savedCartName").val("").trigger("focus");
			}
		})
	})
	$("#createSavedCartPopup").find("#nosavedcart-list").on('click', function() {
		$(".rename-msg,#yessavedcart-list,#nosavedcart-list,.nospecialLabel").hide();
		$("#mysavedcartAdd,#createsavedcart-list").show();
		$("#savedCartName").val("").trigger("focus");
		$(".rename-errmsg").show();

	})
});
