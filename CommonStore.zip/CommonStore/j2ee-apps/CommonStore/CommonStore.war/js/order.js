$(document).ready(function () {
	var FSPCheckSession = $.cookie('agilent_locale');	
	var FSPsession = {};
	switch(FSPCheckSession){
		case "zh_CN":
			FSPsession.soltoerror = "没有找到可以使用这个计划的客户信息";
			FSPsession.errormsg_1 = "有错误发生，";
			FSPsession.errormsg_2 = "请与安捷伦联系";
			break;
		
		default:
			FSPsession.soltoerror = $("#noSoldToErr").val();
			FSPsession.errormsg_1 = "An error has occured, please";
			FSPsession.errormsg_2 = "contact Agilent.";
			break;
	}
	var orderrow="",cursorclass="",colorclass="";
	
	function getUrlVars()
	{
	    var vars = [], hash;
	    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
	    for(var i = 0; i < hashes.length; i++)
	    {
	        hash = hashes[i].split('=');
	        vars.push(hash[0]);
	        vars[hash[0]] = hash[1];
	    }
	    return vars;
	}

	var contactno= getUrlVars()["contactno"];

	var PlanNumber= getUrlVars()["PlanNumber"];
	

if(erroroccured == "true")
	{
		$('.plan-details .sub-cnt').empty();
		$('.plan-details .fsp-error').show();
	}	

$.ajax({
    type: 'POST',
    url: '/rest/model//com/agilent/profile/fsp/FspService/getFlexibleSpendPlanOrderDetails?atg-rest-output=json&contactno='+ contactno +'&PlanNumber='+PlanNumber,
    dataType: 'json',
	success: function(data) {
		if(data.getFspOrderDetailsResponse.responseStatus.responseStatusCode == "404")
				{
					$('.plan-details .sub-cnt').empty();
					$('.plan-details .fsp-error').show();
				}
		else
		{
			for(var i = 0; i < data.getFspOrderDetailsResponse.responseData.length; i++)
				{
					if(data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZFSD' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZFSC') {
				cursorclass = " nocursor";
				}
				else {
					cursorclass = "";
				}
				if(data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZTRD' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZCST' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZDRN' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'DR' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZOSO' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZOSS' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZIHO' || data.getFspOrderDetailsResponse.responseData[i].TxnType == 'ZSDS')
				{
					colorclass = "negativeVal";
				}
				else
				{
					colorclass = "";
				}
				//orderrow += '<tr class="order-data' + cursorclass + '" id='+data.getFspOrderDetailsResponse.responseData[i].TxnType+'><td class="txtno">'+ data.getFspOrderDetailsResponse.responseData[i].TxnNumber +'</td><td class="txtdesc">'+ data.getFspOrderDetailsResponse.responseData[i].TxnDescr +'</td><td class="txttype" style="display:none">'+ data.getFspOrderDetailsResponse.responseData[i].TxnType +'<input type="hidden" name="txtsource" class="txtsource" value='+ data.getFspOrderDetailsResponse.responseData[i].TxnSource +' /></td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnDate +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToName +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr1 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr2 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr3 +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToName +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr1 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr2 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr3 +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnStatus +'</td><td class="' + colorclass + '">'+ data.getFspOrderDetailsResponse.responseData[i].TxnValue + '&nbsp;<span>'+ data.getFspOrderDetailsResponse.responseData[i].Currency +'</span></td></tr>';
				orderrow += '<tr class="order-data' + cursorclass + '" id='+data.getFspOrderDetailsResponse.responseData[i].TxnType+'><td class="txtno">'+ data.getFspOrderDetailsResponse.responseData[i].TxnNumber +'</td><td class="txtdesc">'+ data.getFspOrderDetailsResponse.responseData[i].TxnDescr +'</td><td class="txttype" style="display:none">'+ data.getFspOrderDetailsResponse.responseData[i].TxnType +'<input type="hidden" name="txtsource" class="txtsource" value='+ data.getFspOrderDetailsResponse.responseData[i].TxnSource +' /></td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnDate +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToName +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr1 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr2 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnSoldToAddr3 +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToName +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr1 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr2 +'<br/>'+ data.getFspOrderDetailsResponse.responseData[i].TxnShipToAddr3 +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].Custpo +'</td><td>'+ data.getFspOrderDetailsResponse.responseData[i].TxnStatus +'</td><td class="' + colorclass + '">'+ data.getFspOrderDetailsResponse.responseData[i].TxnValue + '&nbsp;<span>'+ data.getFspOrderDetailsResponse.responseData[i].Currency +'</span></td></tr>';
				}
		}	
		$('#order-info').empty();
		$('#order-info').html(orderrow);
		$(".mainContainer.FlexibleSpendPlan").removeAttr("style");
		$(".mainContainer.Fspplandetails").removeAttr("style");
		LSCA.getFooterextend();  
	},
	
	error: function(error){
	
		$('.plan-details .sub-cnt').empty();
		$('.plan-details .fsp-error').show();
   
	}	
	
	});  /* End of ajax */
/* Authorized sold to list*/
$('#au-btn').on('click', function(){
	var partner="",j=0;
	if(partnerdetails.length != 0)
	{
		for (j in partnerdetails) {	
			
			partner += '<tr><td>' + partnerdetails[j].partnerName  + '</td></tr>';	
					
		}
		$("#soldto .modal-body").empty();
		$("#soldto .modal-body").html('<table class="table au-sold-to"><thead class="thead-default"><tr><th>Customer Name</th></tr></thead><tbody class="partnerrow">' + partner + '</tbody></table>');
		$('#soldto').modal('show'); 
	}
	else
	{
		$("#soldto .modal-body").empty();
		$("#soldto .modal-body").html('<div id="error-ajax"><div class="msg-stnd msg-box-error"><i class="fal fa-exclamation-circle"></i><span>'+FSPsession.soltoerror+'</span></div></div>');
		$('#soldto').modal('show'); 
	}
});

/* Order Info Popup */
$("tbody#order-info").on("click", "tr", function(e){
	/*alert($(this).attr('id'));*/
	var SelectedId = $(this).attr('id');
	var actId =$(this).find(".txtno").text();
	var TxnSourceType = $(this).find(".txtsource").val();
	var tablerow="",fsperror="";
	var OrderHeading = $(this).find(".txtdesc").text()+" - "+$(this).find(".txtno").text();
	var validId = ['ZTRD','ZREC','ZSCS','ZDRN','ZCRN','CR','DR','ZOSO','ZOSS','ZIHO','ZCST','ZCLR','ZSDS','ZDSO'];
	if(jQuery.inArray(SelectedId,validId) != -1) {
		if((SelectedId == 'ZTRD' || SelectedId == 'ZREC' || SelectedId == 'ZSCS' || SelectedId == 'ZDRN' || SelectedId == 'ZCRN' || SelectedId == 'CR' || SelectedId == 'DR') && TxnSourceType == 'ECC') {
			$.ajax({
				type: 'POST',
				url: '/rest/model/com/agilent/profile/fsp/FspService/getFlexibleSpendPlanActivityDetails?contactno='+ contactno +'&PlanNumber='+ PlanNumber +'&ActivityId=' + actId +'&atg-rest-output=json',
				dataType: 'json',
				success: function(data) {
					if(data.getFspActivityDetailsResponse.responseStatus.responseStatusCode == '404') {
						fsperror = '<div class="fsp-error popup-info"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.errormsg_1 + '<a href="' + contactus + '">' + " " + FSPsession.errormsg_2 +'</a></p></div>';
						$('#error-Model .order-popup').empty();
						$('#error-Model .order-popup').html(fsperror);
						$('#error-Model').modal('show'); 
					}
					else{
					for(var i = 0; i < data.getFspActivityDetailsResponse.responseData.ECC_Data.length; i++)
					{
						if(SelectedId == 'ZTRD') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].POSNR +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].MATNR +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].ARKTX +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].STATUS +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].KWMENG +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].BOOKED_DATE+'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].PO_NUMBER+'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].NETWR+ '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].CURR +'</span></td></tr>';
						}
						if(SelectedId == 'ZREC') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].POSNR +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].MATNR +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].ARKTX +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].STATUS +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].KWMENG +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].BOOKED_DATE+'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].NETWR+ '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].CURR +'</span></td></tr>';
						}
						if(SelectedId == 'ZDRN' || SelectedId == 'ZCRN' || SelectedId == 'CR' || SelectedId == 'DR') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].POSNR +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].KWMENG +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].NETWR + '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.ECC_Data[i].CURR +'</span></td></tr>';
						}	
					}
					
					if(SelectedId == 'ZTRD') {
						$('#ZTRD-Model #myModalLabel').html(OrderHeading);
						$('#ZTRD-Model tbody').empty();
						$('#ZTRD-Model tbody').html(tablerow);
						$('#ZTRD-Model').modal('show'); 
					}
					if(SelectedId == 'ZREC') {
						$('#ZREC-Model #myModalLabel').html(OrderHeading);
						$('#ZREC-Model tbody').empty();
						$('#ZREC-Model tbody').html(tablerow);
						$('#ZREC-Model').modal('show'); 
					}
					if(SelectedId == 'ZDRN' || SelectedId == 'ZCRN' || SelectedId == 'CR' || SelectedId == 'DR') {
						$('#ZDRN-Model #myModalLabel').html(OrderHeading);
						$('#ZDRN-Model tbody').empty();
						$('#ZDRN-Model tbody').html(tablerow);
						$('#ZDRN-Model').modal('show');  
					}
				}
					
				},
				error: function(error){
					$(".order-popup").empty();
					fsperror = '<div class="fsp-error popup-info"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.errormsg_1 + '<a href="' + contactus + '">' + " " + FSPsession.errormsg_2 + '</a></p></div>';
					$('.order-popup').html(fsperror);
					$('.order-popup').modal('show');
				}	
			
			}); 
		}
		if((SelectedId == 'ZOSO' || SelectedId == 'ZOSS' || SelectedId == 'ZIHO' || SelectedId == 'ZCST' || SelectedId == 'ZCLR' || SelectedId == 'ZSCS' || SelectedId == 'ZSDS' || SelectedId == 'ZDSO')  && TxnSourceType == 'CRM') {
			$.ajax({
				type: 'POST',
				url: '/rest/model/com/agilent/profile/fsp/FspService/getFlexibleSpendPlanActivityDetails?contactno='+ contactno +'&PlanNumber='+ PlanNumber +'&ActivityId=' + actId +'&atg-rest-output=json',
				dataType: 'json',
				success: function(data) {
					if(data.getFspActivityDetailsResponse.responseStatus.responseStatusCode == '404') {
						fsperror = '<div class="fsp-error popup-info"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.errormsg_1 + '<a href="' + contactus + '">' + " " + FSPsession.errormsg_2 +'</a></p></div>';
						$('#error-Model .order-popup').empty();
						$('#error-Model .order-popup').html(fsperror);
						$('#error-Model').modal('show'); 
					}
					else{
						for(var i = 0; i < data.getFspActivityDetailsResponse.responseData.CRM_Data.length; i++)
					{
					
						if(SelectedId == 'ZOSO' || SelectedId == 'ZOSS' || SelectedId == 'ZDSO') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].OrderNumber +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Product +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ProductDescr +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemQuantity +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemLabourTime +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemTravelTime+'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].NetValue+ '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Currency +'</span></td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].SERIAL_NUM +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ModelNo +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].INSTRUMENT_ID +'</td></tr>';
						}
						if(SelectedId == 'ZIHO') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].OrderNumber +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Product +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ProductDescr +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemQuantity +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].NetValue+ '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Currency +'</span></td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].SERIAL_NUM +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ModelNo +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].INSTRUMENT_ID +'</td></tr>';
						}	
						if(SelectedId == 'ZCST' || SelectedId == 'ZCLR') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].OrderNumber +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Product +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ProductDescr +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ServiceSystem +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ServiceSystemDescr+'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemQuantity +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].NetValue+ '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Currency +'</span></td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].SERIAL_NUM +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ModelNo +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].INSTRUMENT_ID +'</td></tr>';
						}
						if(SelectedId == 'ZSCS' || SelectedId == 'ZSDS') {
							tablerow += '<tr><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].OrderItem +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].ItemQuantity +'</td><td>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].NetValue + '&nbsp;<span>'+ data.getFspActivityDetailsResponse.responseData.CRM_Data[i].Currency +'</span></td></tr>';
						}					
						
					}
					
					if(SelectedId == 'ZOSO' || SelectedId == 'ZOSS' || SelectedId == 'ZDSO') {
						$('#ZOSO-Model #myModalLabel').html(OrderHeading);
						$('#ZOSO-Model tbody').empty();
						$('#ZOSO-Model tbody').html(tablerow);
						$('#ZOSO-Model').modal('show'); 
					}
					if(SelectedId == 'ZIHO') {
						$('#ZIHO-Model #myModalLabel').html(OrderHeading);
						$('#ZIHO-Model tbody').empty();
						$('#ZIHO-Model tbody').html(tablerow);
						$('#ZIHO-Model').modal('show');  
					}
					if(SelectedId == 'ZCST' || SelectedId == 'ZCLR') {
						$('#ZCST-Model #myModalLabel').html(OrderHeading);
						$('#ZCST-Model tbody').empty();
						$('#ZCST-Model tbody').html(tablerow);
						$('#ZCST-Model').modal('show');  
					}
					if(SelectedId == 'ZSCS' || SelectedId == 'ZSDS') {
						$('#ZSCS-Model #myModalLabel').html(OrderHeading);
						$('#ZSCS-Model tbody').empty();
						$('#ZSCS-Model tbody').html(tablerow);
						$('#ZSCS-Model').modal('show');  
					}	
				}
					
					
				},
				error: function(error){
					fsperror = '<div class="fsp-error popup-info"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.errormsg_1 + '<a href="' + contactus + '">' + " " + FSPsession.errormsg_2 +'</a></p></div>';
					$('#error-Model .order-popup').empty();
					$('#error-Model .order-popup').html(fsperror);
					$('#error-Model').modal('show'); 
				}
			
			}); 
		}
	}
	else if(SelectedId != 'ZFSD' && SelectedId != 'ZFSC') {
		fsperror = '<div class="fsp-error popup-info"><i class="fa fa-exclamation-circle" aria-hidden="true"></i><p>' + FSPsession.errormsg_1 + '<a href="' + contactus + '">' + " " + FSPsession.errormsg_2 +'</a></p></div>';
		$('#error-Model .order-popup').empty();
		$('#error-Model .order-popup').html(fsperror);
		$('#error-Model').modal('show'); 
	}
});
});
