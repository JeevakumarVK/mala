$(document).ready(function() {
	/* sticky code start*/
	var widgetOffset = $(".order-summary-outer").offset();
	var leftPos = '';
	var widgetHt = 0;
	var setCurrentPos = 0;
	var cartContainer_height = '';
	var window_top = 0;
	var top = 0;
	var cart_offset = 0;
	$(window).scroll(function(event) {

		window_top = $(window).scrollTop();
		topspace = $('#totalPriceWidget-here').offset().top;
		cart_offset = $('.custom-master-wraper').offset().top;
		cartContainer_height = $('.custom-master-wraper').innerHeight();
		widgetHt = $('#totalOuter').innerHeight();;


		if (widgetOffset.left === 0) {
			widgetOffset = $("#totalPriceWidget-here").offset();
			leftPos = widgetOffset.left - 21 + 'px';
		}

		if (window_top > topspace) {
			if (window_top >= (cartContainer_height - widgetHt)) {
				$('.order-summary-outer').removeClass('stick').addClass('float');
				if (setCurrentPos == 0) {
					setCurrentPos = cartContainer_height - widgetHt;
					setCurrentPos = setCurrentPos + 'px';
					$('.order-summary-outer').css({
						'top': setCurrentPos
					});
				}
			} else {
				$('.order-summary-outer').addClass('stick').removeClass('float');
			}

		} else {
			$('.order-summary-outer').removeClass('float').removeClass('stick');
			setCurrentPos = 0;
		}
	});

	//Print Today date on punchout quote page
	const d = new Date()
	const year = d.getFullYear()
	var date = d.getDate()
	date.toString().length == 1 ? date = '0' + date : date
	const months = {
		0: 'Jan',
		1: 'Feb',
		2: 'Mar',
		3: 'Apr',
		4: 'May',
		5: 'Jun',
		6: 'Jul',
		7: 'Aug',
		8: 'Sep',
		9: 'Oct',
		10: 'Nov',
		11: 'Dec'
	}
	const monthIndex = d.getMonth()
	const monthName = months[monthIndex]	
	var month = d.getMonth() + 1
	month.toString().length == 1 ? month = '0' + month : month
	$('.punchoutQuote .pay-date-stamp.date .pay-gen-date').text(year + "/" + month + "/" + date)

	//Show placeholder image if img src is not valid	
	$(".punchoutQuote .checkoutShippingBilling .custom-item-details-wrap table tr td img").each(function(i,ele){
        $("<img/>").attr("src",$(ele).attr("src")).on('error', function() {             
            $(ele).attr( "src", "../images/Agilent-Spark-Placeholder-120x120.png" );
         })
     });	
	//Edit punchout quote
	var pqarrVal = [],
		pqeditableFlagVal = false,
		pqLength = "";
	$(".punchoutQuote .rq-qtytxt").each(function() {
		pqarrVal.push($(this).val());
	});
	$(document).on("keyup", ".punchoutQuote .rq-qtytxt", function(e) {
		var $this = $(this);
		pqLength = jQuery(".punchoutQuote .rq-qtytxt").length;
		if (pqLength == 1) {
			$this.val($this.val().replace(/[^\d]|^0/g, ''));
		}
		if ($this.val()) {
			$this.css('border-color', '#0085d5');
			$(this).prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$(this).next().removeClass("requiredLabel");
			$(this).removeClass("requiredTextBox");
			$(this).next().hide();
		} else {
			$this.css('border-color', '#D6001C');
			$(this).prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$(this).next().addClass("requiredLabel");
			$(this).addClass("requiredTextBox");
			$(this).next().show();
		}
		$(this).focus(function() {
			$(this).css("border", "1px solid #0085d5");
		}).on('blur', function() {
			$(this).css("border", "1px solid #b1b3b3");
			var $tr = $(this).parents('tr');
			if ($tr.length > 0) {
				$tr.find('input.rq-qtytxt').val($(this).val());
			}
			pqarrVal = [];
			$(".rq-qtytxt").each(function() {
				pqarrVal.push($(this).val());
			});
		});
	});
	$(".punchoutQuote .rq-qtytxt").on('blur', function() {
		pqeditableFlagVal = false;
		pqarrVal = [];
		var $thisVal = $(this);
		$(".rq-qtytxt").each(function() {
			pqarrVal.push($(this).val());
		});
		for (var i = 0; i < pqarrVal.length; i++) {
			if (pqarrVal[i] > 0) {
				pqeditableFlagVal = true;
			}
		}
		$(document).on("keyup", ".punchoutQuote .rq-qtytxt", function(e) {
			var $thisVal = $(this);
			if (!pqeditableFlagVal) {
				$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
				$thisVal.css('border-color', '#D6001C');
				$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
				$thisVal.next().addClass("requiredLabel");
				$thisVal.addClass("requiredTextBox");
				$thisVal.next().show();
			} else {
				$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
				$thisVal.css('border-color', '#0085d5');
				$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
				$thisVal.next().removeClass("requiredLabel");
				$thisVal.removeClass("requiredTextBox");
				$thisVal.next().hide();
			}
		});
		if ((!pqeditableFlagVal) || ($thisVal.val() == "")) {
			$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
			$thisVal.css('border-color', '#D6001C');
			$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$thisVal.next().addClass("requiredLabel");
			$thisVal.addClass("requiredTextBox");
			$thisVal.next().show();
		} else {
			$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
			if ($thisVal.val() == "0") {
				$thisVal.parents("tr").addClass("zeroRow");
			}
			$thisVal.css('border-color', '#b1b3b3');
			$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$thisVal.next().removeClass("requiredLabel");
			$thisVal.removeClass("requiredTextBox");
			$thisVal.next().hide();
		}
	});
	$(".punchoutQuote .rq-qtytxt").on("keydown change", function(e) {
		var $thisrqVal = $(this);
		setTimeout(function() {
			if (e.type == 'change' || e.keyCode == '13') {
				if (e.keyCode == '13') {
					e.preventDefault();
					$thisrqVal.trigger("blur");
				}
				editQuoteAjaxCall();
			}
		}, 500);
	});
	$(".punchoutQuote .rq-qtytxt").on("change", function(e) {
		$(".punchoutQuote #chekoutItemSection tr").removeClass("changedRow");
		$(this).parents("tr").removeClass("changedRow").addClass("changedRow");
	});
	$('.punchoutQuote .transferTocartBtn').on('click', function() {
		setTimeout(function() {
			if($('#pageLoader').css('display') == 'none'){
				if ($(".punchoutQuote input").hasClass("requiredTextBox")) {
					$('html, body').animate({
						scrollTop: $(".requiredTextBox").offset().top - 50
					}, 500);
					return false
				} else {
					//alert('hi')
					$('#punchoutTransfer').trigger('click');
				}					
			}	
		}, 800);
	});
	function editQuoteAjaxCall() {
		var rqpartNoList = "",
			editQuoteDetails = "",
			ajaxcallFlag = false;
		var eqarrval = [];
		$(".punchoutQuote .rq-qtytxt").each(function() {
			if ($(this).hasClass("requiredTextBox")) {
				ajaxcallFlag = true;
			}
			var rq_qtyVal = $(this).val();
			var rq_partNoVal = $(this).parents('tr').attr("data-editquote").trim();
			rqpartNoList += rq_partNoVal + ":" + rq_qtyVal + ",";
			eqarrval.push($(this).parents('tr').attr("data-editquote").trim());
			LSCA.loadingSpinner.showLoading();
		});
		if (!ajaxcallFlag) {
			var editAjaxUrl, editAjaxData;
			editAjaxUrl = "/rest/model/com/agilent/commerce/EditRedeemQuantity?atg-rest-output=json";
			editAjaxData = JSON.stringify({
				"editRedeemQty": {
					"shipPartNo": $(".punchoutQuote #shipAddrId").val(),
					"quoteNumber": $(".punchoutQuote #quoteNumber").val(),
					"Items": rqpartNoList
				}
			})
			$.ajax({
				type: "POST",
				contentType: "application/json; charset=utf-8",
				url: editAjaxUrl,
				data: editAjaxData,
				dataType: "json",
				success: function(responsedata) {
					var rq_partNoVal1 = "",
						keyLength = 0;
					LSCA.loadingSpinner.hideLoading();
					var EditRedeemQtyDataString = "",
						erqcount = 0;
					var quoteNumVal = $(".punchoutQuote #quoteNumber").val();
					$.each(responsedata.fetchEditRedeemQtyDataResponse.lineItems, function(key, value) {
						for (var i = 0; i < eqarrval.length; i++) {
							if (eqarrval[i] == key) {
								jQuery('tr[data-editquote="' + eqarrval[i] + '"] .customYrprice span').text(value.listPrice);
								jQuery('tr[data-editquote="' + eqarrval[i] + '"] .customListprice span').text(value.yourPrice);
								jQuery('tr[data-editquote="' + eqarrval[i] + '"] .totalPrice > span').text(value.total);
								if ((value.ya9DiscountMsg != "") && (value.ya9DiscountMsg != null)) {
									jQuery('tr[data-editquote="' + eqarrval[i] + '"] .promocode-row .customPromo span').text(value.ya9DiscountMsg);
								}
								$('tr[data-editquote="' + eqarrval[i] + '"]').attr("data-qty", $('tr[data-editquote="' + key + '"] .rq-qtytxt').val());
							}
						}
						if ($('tr[data-editquote="' + key + '"] .rq-qtytxt').val() != "0" && $('tr[data-editquote="' + key + '"] .rq-qtytxt').val() != "") {
							$('tr[data-editquote="' + key + '"]').removeClass("zeroRow");
						}
						var data_partno_itemid = [];
						if (key !== "undefined") {
							data_partno_itemid = key.split("#");
							data_partno_item = quoteNumVal + "_" + data_partno_itemid[1];
							if (erqcount >= 1) {
								EditRedeemQtyDataString = EditRedeemQtyDataString + "&&" + data_partno_item;
							} else {
								EditRedeemQtyDataString = EditRedeemQtyDataString + data_partno_item;
							}
							if ($('tr[data-editquote="' + key + '"] .rq-qtytxt').val() != "" && $('tr[data-editquote="' + key + '"] .rq-qtytxt').val() != "undefined")
								EditRedeemQtyDataString = EditRedeemQtyDataString + "#" + $('tr[data-editquote="' + key + '"] .rq-qtytxt').val();
							if (value.lPrice != "undefined" && value.lPrice != "") {
								EditRedeemQtyDataString = EditRedeemQtyDataString + "##" + value.lPrice;
							}
							if (value.yPrice != "undefined" && value.yPrice != "") {
								EditRedeemQtyDataString = EditRedeemQtyDataString + "###" + value.yPrice;
							}
							if (value.lTotal != "undefined" && value.lTotal != "") {
								EditRedeemQtyDataString = EditRedeemQtyDataString + "$$" + value.lTotal;
							}
						}
						erqcount++;
					});
					$("#editedItemNumbersString").val(EditRedeemQtyDataString);
					$('#quotationSubtotal').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationSubtotal);
					$('#totalTaxValue').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTax);
					$(".punchoutQuote #order-summary-table #subTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.subtotal);
					$(".punchoutQuote #order-summary-table #shippingVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.shippingCharges);
					$(".punchoutQuote #order-summary-table #taxVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.tax);
					$(".punchoutQuote .cart-subTotal-section span.subTotal-price").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.subtotal);
					$(".punchoutQuote #order-summary-table #orderTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.total);					
					$('#quotationSubtotalValEQ').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationSubtotal);
					$("#quotationTaxValEQ").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTax);
					$('#quotationTotalValEQ').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTotal);
					$("#shipTotalValEQ").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.shipTotal);
					$("#editQuoteTotalListPrice").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.totalEditQuoteListPrice);	
				},
				error : function() {
					LSCA.loadingSpinner.hideLoading();
					console.log('Something went wrong!')
				}
			});
		} else {
			LSCA.loadingSpinner.hideLoading();
		}
	}	
});