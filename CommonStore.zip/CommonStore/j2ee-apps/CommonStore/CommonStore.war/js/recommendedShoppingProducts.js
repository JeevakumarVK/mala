$(document).ready(

    getRcommendedProduct = function (orderDetailJson) {

        // Load Recommended Products
        loadRecommendedProducts();

        // Declare global variables
        var recommHtmlBind = "";
        var recommPDPImpressions = "";
        var recommProdImpressionArray = [];
        var cvRecommendationsJson = [];
        var partnoListVal;
        var partnoList = [];
        var recommProdPrice = [];
        var cv_slider;
        var pageLable = '';
        var countryCurrencyCode = '';
        var dlScrollFlag = true;

        function constructRecomHTML(dataRecomm) {
            for (var pdt = 0; pdt < dataRecomm.length; pdt++) {
                var produrl = "#";
                var recommDescription = "";
                if (dataRecomm[pdt].url != undefined && dataRecomm[pdt].url != "") {
                    produrl = dataRecomm[pdt].url;
                } else {
                    produrl = "/store/" + $.cookie('agilent_locale') + "/Prod-" + dataRecomm[pdt].id + "/" + dataRecomm[pdt].id;
                }
                if (dataRecomm[pdt].description != undefined && dataRecomm[pdt].description != "") {
                    recommDescription = dataRecomm[pdt].description;
                }
                recommHtmlBind += ' <div class="cust-bought-prod-card" data-partId=' + dataRecomm[pdt].id + ' id="partNo_' + dataRecomm[pdt].id + '"><div class="cust-bought-prod-imgsec"><a href="' +
                    produrl + '">';
                if (dataRecomm[pdt].image != undefined && dataRecomm[pdt].image != "") {
                    recommHtmlBind += '<img src="' + dataRecomm[pdt].image + '"/>';
                } else {
                    recommHtmlBind += '<img src="/common/images/Agilent-Spark-Placeholder-120x120.png"/>';
                }
                recommHtmlBind += '</a></div><div class="cust-bought-prod-detail"><div class="cb-prod-desc-id"><h4 class="cust-bought-prod-desc">';
                if (dataRecomm[pdt].title != undefined) {
                    recommHtmlBind += '<a class="' + dataRecomm[pdt].id + '" href="' + produrl + '">' + dataRecomm[pdt].title + '</a>';
                }
                recommHtmlBind += '</h4>';
                if (dataRecomm[pdt].id != undefined) {
                    recommHtmlBind += '<h5 class="cust-bought-prod-part-num ">' + dataRecomm[pdt].id + '</h5></div>';
                }
                recommHtmlBind += '<div class="prod-price-section"><h5 class="cust-prod-price "><span class="cust-prod-price-title "></span><span class="list-price-val "></span></h5></div>';
                recommHtmlBind += '</div>';
                recommHtmlBind += '<div class="cust-bought-prod-ctasec "><input type="hidden" value=' + dataRecomm[pdt].id + ' name="partNumber" class="recom_partnum"/><input type="hidden" value="' +
                    recommDescription + '" name="partNumberDesc" class="recom_Desc"/><input type="text" class="qty cart-hide"   placeholder=' + recomQtyLabel +
                    ' maxlength="4" value="" onfocus="this.placeholder=\'\'" onblur="this.placeholder=\'' + recomQtyLabel + '\'">';
                recommHtmlBind += '<a class="btn-stnd-medium recommAddtoCartNew cart-hide" href="javascript:void(0);">' + recomAddToCartLabel +
                    '</a><a class="btn-stnd-medium recommRequestQuote cart-hide" href="javascript:void(0);">' + recomReqQuote + '</a></div>';
                recommHtmlBind += '<div class="recommresult-product-validation"><span class="gn-success-msg"></span><span class="gn-error-msg errorColor">' + recomEnterQtyLabel +
                    '</span><span class="gn-error-msg successColor">' + recomAddSuccessLabel + '</span><span class="gn-error-msg failureColor">' + recomFailAddToCartLabel + '</span></div>';
                recommHtmlBind += '</div>';
                var recommProdImpression = {};
                recommProdImpression.name = dataRecomm[pdt].title;
                recommProdImpression.id = dataRecomm[pdt].id;
                recommProdImpression.position = pdt + 1;
                recommProdImpressionArray.push(recommProdImpression);
            }
            if ($('.bx-wrapper').length > 0) {
                $('.bx-wrapper').remove();
                $("<div class='cust-viewed-slider'></div>").insertAfter(".cust-view-head");
            }
            $('.cust-viewed-slider').html(recommHtmlBind)
        }

        function getPriceList() {
            $('.cust-bought-prod-card').each(function () {
                if ($(this).attr('data-partid') != '') {
                    partnoList.push($(this).attr('data-partid'));
                }
            });
            var partnoListVal = partnoList.join();
            partnoListVal = partnoListVal.replace(/,/g, ",");
            $.ajax({
                type: "GET",
                url: '/common/prdDetailSrchJSON.jsp?catalogIds=' + partnoListVal,
                dataType: "json",
                success: function (data) {
                    var responseData = data;
                    for (var i in responseData) {
                        var listPrice = responseData[i].listPrice;
                        var yourPrice = responseData[i].yourPrice;
                        var priceDetail = {};
                        var tempListPrice = (isNaN(parseFloat(listPrice.replace(/[^0-9^.]+/g, '')))) ? 0 : parseFloat(listPrice.replace(/[^0-9^.]+/g, ''));
                        var tempYourPrice = (isNaN(parseFloat(yourPrice.replace(/[^0-9^.]+/g, '')))) ? 0 : parseFloat(yourPrice.replace(/[^0-9^.]+/g, ''));
                        var showRequestQuote = false;
                        if ($("#loginStatus").val() == "true") {
                            if (tempListPrice != 0 && tempListPrice != null && tempListPrice != '') {
                                $('#partNo_' + i + ' .list-price-val').text(responseData[i].listPrice);
                                $('#partNo_' + i + ' .cust-prod-price-title').text(recomListPriceLabel);
                                showRequestQuote = true;
                                priceDetail = {
                                    'id': i,
                                    'price': listPrice
                                };
                                addPriceToProducts(i, listPrice);
                            }
                        }
                        if ($("#loginStatus").val() == "false") {
                            if (tempYourPrice != 0 && tempYourPrice != null && tempYourPrice != '') {
                                $('#partNo_' + i + ' .list-price-val').text(responseData[i].yourPrice);
                                $('#partNo_' + i + ' .cust-prod-price-title').text(recomYourPriceLabel);
                                showRequestQuote = true;
                                priceDetail = {
                                    'id': i,
                                    'price': yourPrice
                                };
                                addPriceToProducts(i, yourPrice);
                            }
                        }
                        $('.cust-bought-prod-card').find('.qty').removeClass('cart-hide');
                        $('.cust-bought-prod-card').find('.recommAddtoCartNew').removeClass('cart-hide');
                        $('.cust-bought-prod-card').find('.recommRequestQuote').removeClass('cart-hide');
                        if (!showRequestQuote) {
                            $('body.es_ES #bin #partNo_' + i + ' .prod-price-section').hide();
                            $('body.es_ES #bin #partNo_' + i + ' .cust-bought-prod-part-num').css('padding-bottom', '5px');
                            $('body.es_ES #bin #partNo_' + i + ' .cb-prod-desc-id').css('min-height', '84px');
                            $('#partNo_' + i + ' .recommAddtoCartNew').remove();
                            $('#partNo_' + i + ' .recommRequestQuote').css('display', 'inline-block');
                        }
                        if ($("#loginStatus").val() == "false") {
                            if (tempListPrice > 0 && tempYourPrice > 0) {
                                if (tempYourPrice != 0 && tempYourPrice != null && tempYourPrice != '') {
                                    if (tempYourPrice < tempListPrice) {
                                        $('#partNo_' + i + ' .cust-prod-price').addClass('removeBtm');
                                        var strikePrice = '<span class="strikeprice">' + responseData[i].listPrice + '</span>';
										if($('#partNo_' + i + ' .cust-prod-price + span.strikeprice').length < 1) {
											$('#partNo_' + i + ' .cust-prod-price').after(strikePrice);
										}	
                                        $('#partNo_' + i + ' .prod-price-section .strikeprice').css('margin-left', $('#partNo_' + i + ' .cust-prod-price-title').outerWidth() + 1 + 'px');
                                        $('#partNo_' + i + ' .cb-prod-desc-id').css('min-height', '79px');
                                        $('#partNo_' + i + ' .cust-bought-prod-part-num ').css('padding-bottom', '0px');
                                    } else {
                                        $('#partNo_' + i + ' .cust-prod-price').removeClass('removeBtm');
                                    }
                                }
                            }
                        }
                        if (isNotEmpty(priceDetail)) {
                            recommProdPrice.push(priceDetail);
                        }
                        $("div.bx-controls.bx-has-controls-direction:not(:first)").remove();
                    }
                },
                error: function () {
                    console.log('Some error occured in get price!');
                }
            });
        }

        function loadRecommendedProducts() {
            var tablePartNo = [];
            if (orderDetailJson.lineItems != null || orderDetailJson.lineItems != undefined) {
                if (tablePartNo.length == 0) {
                    for (n = 0; n < (Object.keys(orderDetailJson.lineItems)).length; n++) {
                        tablePartNo.push(Object.keys(orderDetailJson.lineItems)[n]);
                    }
                }
            }
            if (tablePartNo.length == 0) {
                return;
            }

            recomCartProductsReqLimit = parseInt(recomCartProductsReqLimit);

            if (tablePartNo.length > recomCartProductsReqLimit) {
                tablePartNo = tablePartNo.slice(0, recomCartProductsReqLimit);
            }
            var tablePartNoVal = tablePartNo.join();
            tablePartNoVal = tablePartNoVal.replace(/,/g, ",");

            if ($(document).find('div#Pnp-recommProducts').length > 0) {
                tablePartNoVal = $('table#ProductDetails').find('div.partNo').text();
                if (tablePartNoVal == '') {
                    tablePartNoVal = $('div.partNo').text();
                }
            }

            var makePriceCall = false;
            $.ajax({
                type: "GET",
                url: recommendationURL + tablePartNoVal,
                dataType: "json",
                headers: {
                    "browsercook": document.cookie
                },
                success: function (cbrecommendationsData) {
                    if (typeof cbrecommendationsData.Recommendations != 'undefined') {
                        for (var i = 0;
                            (i < cbrecommendationsData.Recommendations.length && cvRecommendationsJson.length < recomProductsLimit); i++) {
                            for (var j = 0, k = 0;
                                (j < cbrecommendationsData.Recommendations[i].Recommendations.Products.length && cvRecommendationsJson.length < recomProductsLimit); j++) {
                                cvRecommendationsJson.push(cbrecommendationsData.Recommendations[i].Recommendations.Products[j]);
                            }
                        }
                        if (cvRecommendationsJson.length > 0) {
                            constructRecomHTML(cvRecommendationsJson);
                            $('#recommendedproducts').show();
                            $('.bx-loading').remove();
                            makePriceCall = true;
                        } else {
                            $('#recommendedproducts').hide();
                        }
                    }

                    function cvSettings() {
                        var set_cvmargin = 30;
                        var init_cv = {
                            auto: false,
                            autoControls: false,
                            slideSelector: 'div.cust-bought-prod-card',
                            pagerCustom: '#bx-pager',
                            touchEnabled: false,
                            mode: 'horizontal',
                            infiniteLoop: false,
                            maxSlides: 3,
                            moveSlides: 3,
                            slideWidth: 265,
                            hideControlOnEnd: true,
                            slideMargin: set_cvmargin,
                            autoControlsCombine: false,
                            onSliderLoad: function (slideEl, oldSlide, newSlide) {
                                setTimeout(function () {
                                    $('.cust-bought-prod-desc a').each(function () {
                                        var origContent = $(this).html();
                                        while ($(this).height() > 68) {
                                            origContent = trimFromLast(origContent);
                                            var content = origContent;
                                            $(this).html(content + "...");
                                        }
                                    });
                                }, 100);
                            }
                        }
                        return init_cv;
                    }

                    setTimeout(function () {
                        cv_slider = $('.cust-viewed-slider').bxSlider(cvSettings());
                    }, 100);
                    $("div.bx-controls.bx-has-controls-direction:not(:first)").remove();
                    $("#recommendedproducts img").each(function () {
                        $(this).attr("onerror", "this.src='/common/images/Agilent-Spark-Placeholder-120x120.png'");
                    });

                    if (makePriceCall) {
                        getPriceList();
                    }

                    /* Google Analytics - Start*/
                    if ($(document).find('div#cart-recommProducts').length > 0) {
                        pageLable = 'Customers Also Bought These Products - Cart';
                    } else if ($(document).find('div#Pnp-recommProducts').length > 0) {
                        pageLable = 'Customers Also Bought These Products - PNP';
                    }
                    /* Google Analytics - End*/

                    /* Google Analytics - Start Left Arrow Click */
                    $(document).on("click", ".cust-also-viewed .cust-view-content a.bx-prev", function (e) {
                        var recommProdImpressionArrayVP = [];
                        var currentSlide = "";
                        var startTile = "";
                        var endTile = "";
                        var partNumList = "";
                        if (isNotEmpty(cv_slider)) {
                            currentSlide = cv_slider.getCurrentSlide();
                            startTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (currentSlide * 3) : recommProdImpressionArray.length - (recommProdImpressionArray.length % 3) - 1;
                            endTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (startTile + 3) : (recommProdImpressionArray.length);
                            recommProdImpressionArrayVP = recommProdImpressionArray.slice(startTile, endTile);
                            partNumList = getProductPartNum(recommProdImpressionArrayVP);
                            partNumList = partNumList.join(',');
                            recommAddedInfo(partNumList, 'arrow_Click', recommProdImpressionArrayVP);
                            arrowClickstoDataLayer('Left');
                        }
                    });
                    /* Google Analytics - End Left Arrow Click */

                    /* Google Analytics - Start Right Arrow Click */
                    $(document).on("click", ".cust-also-viewed .cust-view-content a.bx-next", function (e) {
                        var recommProdImpressionArrayVP = [];
                        var currentSlide = "";
                        var startTile = "";
                        var endTile = "";
                        if (isNotEmpty(cv_slider)) {
                            currentSlide = cv_slider.getCurrentSlide();
                            startTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (currentSlide * 3) : recommProdImpressionArray.length - (recommProdImpressionArray.length % 3) - 1;
                            endTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (startTile + 3) : (recommProdImpressionArray.length);
                            if (currentSlide > 0) {
                                recommProdImpressionArrayVP = recommProdImpressionArray.slice(startTile, endTile);
                                var partNumList = getProductPartNum(recommProdImpressionArrayVP);
                                partNumList = partNumList.join(',');
                            }
                            recommAddedInfo(partNumList, 'arrow_Click', recommProdImpressionArrayVP);
                            arrowClickstoDataLayer('Right');
                        }
                    });
                    /* Google Analytics - End Right Arrow Click */

                    /* Google Analytics - Start Product Tile Click */
                    function tileClick(tilePartNum,url) {
                        var tilePrice = '';
                        var tileCurrency = '';
                        var indexPositon = findProducts(cvRecommendationsJson, tilePartNum);
                        var selectedTileProduct = cvRecommendationsJson[indexPositon];
                        var tileProdPrice = findPrice(recommProdPrice, tilePartNum);
                        if (isNotEmpty(tileProdPrice)) {
                            tilePrice = readPriceValue(tileProdPrice.price);
                            tileCurrency = readCurrencyValue(tileProdPrice.price);
                        }
                        var variantList = getVariant();
                        var productTileObj = {
                            'partNumList': '[' + variantList + ']',
                            'tileProduct': selectedTileProduct,
                            'cartRecomTileSection': pageLable,
                            'tilePrice': tilePrice,
                            'tileCurrency': tileCurrency

                        };
                        recommAddedInfo(tilePartNum, 'tile', productTileObj);
                    }

                    $(document).on("click", ".cust-bought-prod-card .cust-bought-prod-imgsec a img", function (e) {
                        event.preventDefault()
                        var $this = $(this);
                        var tilePartNum = $this.closest('.cust-bought-prod-card').find('.recom_partnum').val();
                        tileClick(tilePartNum,$this.attr('href'));
					    LSCA.loadingSpinner.showLoading();
                    });
                    $(document).on("click", ".cust-bought-prod-card .cust-bought-prod-detail .cb-prod-desc-id h4 a", function (e) {
                        event.preventDefault()
                        var $this = $(this);
                        var tilePartNum = $this.closest('.cust-bought-prod-card').find('.recom_partnum').val();
                        tileClick(tilePartNum,$this.attr('href'));
					    LSCA.loadingSpinner.showLoading();
                    });
                    $(document).on("click", ".cust-bought-prod-card .cust-bought-prod-detail .cb-prod-desc-id h5", function () {
                        var $this = $(this);
                        var tilePartNum = $this.closest('.cust-bought-prod-card').find('.recom_partnum').val();
                        tileClick(tilePartNum);
                    });
                    /* Google Analytics - End Product Tile Click */

                    /* Google Analytics - Start Window Scroll */
                    $(window).on("scroll",function () {
                        var hT = $('#customersalsoviewed').offset().top,
                            hH = $('#customersalsoviewed').outerHeight(),
                            wH = $(window).height(),
                            wS = $(this).scrollTop();
                        var recommProdImpressionArrayVP = [];
                        var currentSlide = "";
                        var startTile = "";
                        var endTile = "";
                        if (isNotEmpty(cv_slider)) {
                            currentSlide = cv_slider.getCurrentSlide();
                            if (wS > (hT + hH - wH)) {
                                if (dlScrollFlag) {
                                    startTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (currentSlide * 3) : recommProdImpressionArray.length - (recommProdImpressionArray.length % 3) - 1;
                                    endTile = (recommProdImpressionArray.length - (currentSlide * 3)) > 3 ? (startTile + 3) : (recommProdImpressionArray.length);
                                    recommProdImpressionArrayVP = recommProdImpressionArray.slice(startTile, endTile);
                                    var partNumList = getProductPartNum(recommProdImpressionArrayVP);
                                    partNumList = partNumList.join(',');
                                    recommAddedInfo(partNumList, 'scroll', recommProdImpressionArrayVP);
                                    dlScrollFlag = false;
                                }
                            } else {
                                dlScrollFlag = true;
                            }
                        }
                    });
                    /* Google Analytics - End of Window Scroll */
                },
                error: function () {
                    $('#recommendedproducts').hide();
                    console.log('Some error occured in cv!');
                }
            });
        }

        function doRecommededFailure(currentElement, resultData) {
            currentElement.parent().next('.recommresult-product-validation').children('.successColor,.errorColor').hide();
            currentElement.parent().next().children('.gn-success-msg').hide();
            currentElement.parent().next('.recommresult-product-validation').children('.failureColor').text(recomFailAddToCartLabel);
            currentElement.parent().next('.recommresult-product-validation').children('.failureColor').show().delay(6000).fadeOut();
        }

        function doRecommededSuccess(currentElement, resultData) {
            currentElement.prev('.qty').removeClass('emptyError');
            currentElement.parent().next('.recommresult-product-validation').children('.errorColor,.failureColor').hide();
            currentElement.parent().next('.recommresult-product-validation').children('.successColor').show().delay(6000).fadeOut();
            currentElement.parent().next().children('.gn-success-msg').css('display', 'inline-block').delay(6000).fadeOut();

            if ($(document).find('div#cart-recommProducts').length > 0) {
                var currentUrl = '';
                var queryString = '';
                queryString = window.location.href.split('?')[1];
                if (queryString !== undefined && queryString != '' && queryString.indexOf('removalformId') !== -1) {
                    currentUrl = window.location.href.split('?')[0];
                } else {
                    currentUrl = window.location.href;
                }
                $(document).find(".cartNum").html(resultData.cartCountToUpdate);
                setTimeout(function () {
                    sessionStorage.setItem("scrollRecommProduct", 1);
                    window.location.href = currentUrl;
                }, 6000);
            } else if ($(document).find('div#Pnp-recommProducts').length > 0) {
                $(document).find(".cartNum").html(resultData.cartCountToUpdate);
            }
        }

        function addProductToCart(recom_reqURL, currentElement) {
            $.ajax({
                type: "GET",
                url: "/store/includes/ajax/ajaxAddToCart.jsp?" + recom_reqURL,
                cache: false,
                success: function (data) {
                    var resultData = JSON.parse(data);
                    if ((resultData.hasOwnProperty('obj2')) && (resultData.obj2.status == 'failure')) {
                        doRecommededFailure(currentElement, resultData);
                    } else if (resultData.obj1.status == 'success') {
                        doRecommededSuccess(currentElement, resultData);
                    }
                },
                error: function () {
                    doRecommededFailure(currentElement, {});
                }
            });
        }

        function trimFromLast(input) {
            var delimFound = false;
            for (var i = input.length - 1; i >= 0; i--) {
                if (input[i] == ' ' || input[i] == '\uFF0C' || input[i] == '\u3002' || input[i] == '\u002D' || input[i] == '\u2014' || input[i] == ',' || input[i] == '\u3001' ||
                    input[i] == '\u002C' || input[i] == '\u4E00' || input[i] == '\u2009') {
                    delimFound = true;
                } else if (delimFound) {
                    var str2 = input.substring(0, i + 1);
                    return input.substring(0, i + 1);
                }
            }
            return "";
        }

        $(document).on("click", ".recommRequestQuote", function (e) {
            if (($(this).prev().val() == '' || $(this).prev().val() == 0) && $(this).prev().attr('placeholder') == recomQtyLabel) {
                $(this).parent().next('.recommresult-product-validation').children('.successColor,.failureColor').hide();
                $(this).parent().next().children('.gn-success-msg').hide();
                $(this).parent().next('.recommresult-product-validation').children('.errorColor').show().delay(6000).fadeOut();
                $(this).prev('.qty').addClass('emptyError');
                $(this).prev('.qty').addClass('emptyError').delay(6000).queue(function (next) {
                    $(this).removeClass('emptyError');
                    next();
                });
            } else {
                var recom_query_param = '';
                recom_prodQty = $(this).prev().val();
                recom_prodPartNo = $(this).parent().find('.recom_partnum').val();
                recom_prodDesc = $(this).parent().prev().find('a').text();
				recom_prodDescEncode = encodeURIComponent(recom_prodDesc)
				dataLayer.push({  'event': 'request_quote',  'product_name': recom_prodDesc,'request_quote_location':'cart:customers also bought',});
				dataLayer.push({  'event': 'product_rec_quote',  'product_id': recom_prodPartNo,  'product_name':recom_prodDesc,  'location_product_rec':'cart'});				
                var postData = "partNumber=" + recom_prodPartNo + "&" + recom_prodPartNo + "Qty=" + recom_prodQty + "&" + recom_prodPartNo + "Desc=" + recom_prodDescEncode;
                if ((recom_prodQty != "") && (recom_prodPartNo != "")) {
                    $(this).prev('.qty').removeClass('emptyError');
                    $(this).parent().next('.recommresult-product-validation').children('.errorColor,.failureColor').hide();
                    var formData = postData.split('&');
                    var formUrl = '/common/requestQuote.jsp';
                    if (formData !== null && formData.length > 0) {
                        var form = document.createElement("form");
                        form.method = "POST";
                        form.action = formUrl;

                        for (var i = 0; i < formData.length; i++) {
                            var formDataValue = formData[i].split('=');
                            if (formDataValue != null && formDataValue.length == 2) {
                                var element1 = document.createElement("input");
                                element1.value = formDataValue[1];
                                element1.name = formDataValue[0];
                                form.appendChild(element1);
                            }
                        }
                        document.body.appendChild(form);
                        setTimeout(function(){ form.submit()},500);
                    }
                }
            }
            $(this).prev().val('');
            e.stopImmediatePropagation();
        });
        //New recommended add to cart Angular functanality start
        $(document).on("click", ".recommAddtoCartNew", function (e) {
            if (($(this).prev().val() == '' || $(this).prev().val() == 0) && $(this).prev().attr('placeholder') == recomQtyLabel) {
                $(this).parent().next('.recommresult-product-validation').children('.successColor,.failureColor').hide();
                $(this).parent().next().children('.gn-success-msg').hide();
                $(this).parent().next('.recommresult-product-validation').children('.errorColor').show().delay(6000).fadeOut();
                $(this).prev('.qty').addClass('emptyError');
                $(this).prev('.qty').addClass('emptyError').delay(6000).queue(function (next) {
                    $(this).removeClass('emptyError');
                    next();
                });
            } else {

                recom_prodQty = $(this).prev().val();
                recom_prodPartNo = $(this).parent().find('.recom_partnum').val();

                if ((recom_prodQty != "") && (recom_prodPartNo != "")) {
                    $(this).prev('.qty').removeClass('emptyError');
                    $(this).parent().next('.recommresult-product-validation').children('.errorColor,.failureColor').hide();
                    angular.element(document.getElementById('shoppingCartApp')).scope().recommendedAddCart(recom_prodQty, recom_prodPartNo);
                }
            }
            $(this).prev().val('');
            e.stopImmediatePropagation();
        });
        $(document).on("click", ".recommAddtoCart", function (e) {
            if (($(this).prev().val() == '' || $(this).prev().val() == 0) && $(this).prev().attr('placeholder') == recomQtyLabel) {
                $(this).parent().next('.recommresult-product-validation').children('.successColor,.failureColor').hide();
                $(this).parent().next().children('.gn-success-msg').hide();
                $(this).parent().next('.recommresult-product-validation').children('.errorColor').show().delay(6000).fadeOut();
                $(this).prev('.qty').addClass('emptyError');
                $(this).prev('.qty').addClass('emptyError').delay(6000).queue(function (next) {
                    $(this).removeClass('emptyError');
                    next();
                });
                recommGAAddT0Cart($(this));
            } else {
                var recom_query_param = '';
                recom_prodQty = $(this).prev().val();
                recom_prodPartNo = $(this).parent().find('.recom_partnum').val();
                recom_query_param += "partNumber=" + recom_prodPartNo + "&" + recom_prodPartNo + "=" + recom_prodQty;
                if ((recom_prodQty != "") && (recom_prodPartNo != "")) {
                    $(this).prev('.qty').removeClass('emptyError');
                    $(this).parent().next('.recommresult-product-validation').children('.errorColor,.failureColor').hide();
                    addProductToCart(recom_query_param, $(this));
                }
                recommGAAddT0Cart($(this));
            }
            $(this).prev().val('');
            e.stopImmediatePropagation();
        });

        $(document).on("keydown", ".cust-also-viewed .cust-bought-prod-ctasec input.qty", function (e) {
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 || (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
                if (e.keyCode === 13) {
                    e.preventDefault();
                } else {
                    return;
                }
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        });
        if (sessionStorage.getItem("scrollRecommProduct") == 1) {
            $(document).scrollTop($(document).find('div#cart-recommProducts').position().top - 50);
            sessionStorage.setItem("scrollRecommProduct", 0);
        }
        /* customer recommended products for cart & PNP */

        /* Google Analytics - Recommended Addtocart Button click */
        function recommGAAddT0Cart(selectedElement) {
            var prodPrice = '';
            var recommCurrency = '';
            recom_prodPartNo = selectedElement.parent().find('.recom_partnum').val();
            recom_prodQty = selectedElement.prev().val();
            var indexPositon = findProducts(cvRecommendationsJson, recom_prodPartNo);
            var selectedProduct = cvRecommendationsJson[indexPositon];
            var productPrice = findPrice(recommProdPrice, recom_prodPartNo);
            if (isNotEmpty(productPrice)) {
                prodPrice = readPriceValue(productPrice.price);
                recommCurrency = readCurrencyValue(productPrice.price);
            }
            var productPosition = indexPositon + 1;
            var $cartbtn = $(this).closest(".cust-bought-prod-card");
            var cartbtn_pdpTitle = "cart-page";
            var variantList = getVariant();
            var productDetailObj = {
                'productQty': recom_prodQty,
                'partNumList': '[' + variantList + ']',
                'selectedProd': selectedProduct,
                'cartRecomSection': pageLable,
                'productPosition': productPosition,
                'prodPrice': prodPrice,
                'recommCurrency': recommCurrency
            };
            recommAddedInfo(recom_prodPartNo, 'cart_btn', productDetailObj);
        }

        function sendATCtoDataLayer(productDetailObj, recommInfo) {
            dataLayer.push({
                'event': 'eventTracker',
                'eventCat': 'eCommerce',
                'eventAct': 'Add to Cart',
                'eventLbl': productDetailObj.cartRecomSection,
                'eventVal': 0,
                'ecommerce': {
                    'currencyCode': productDetailObj.recommCurrency,
                    'add': {
                        'products': [{
                            'name': productDetailObj.selectedProd.title,
                            'id': productDetailObj.selectedProd.id,
                            'price': productDetailObj.prodPrice,
                            'category': recommInfo.category,
                            'quantity': productDetailObj.productQty,
                            'variant': productDetailObj.partNumList,
                            'dimension14': recommInfo.dimension14
                        }]
                    }
                },
                'eventCallback': function () {
                    dataLayer.push({
                        'ecommerce': undefined
                    });
                }
            });
            
        }
        /* Google Analytics - End of Recommended Addtocart Button click */

        /* Google Analytics - Recommended Product Tile click */
        function sendClicksToDataLayer(productTileObj, recommInfo) {
            var currencycart = $("#currency").val();
            dataLayer.push({
                "event": "eventTracker",
                "eventCat": "eCommerce",
                "eventAct": "Product Clicks",
                "eventLbl": productTileObj.cartRecomTileSection,
                "eventVal": 0,
                "ecommerce": {
                    "currencyCode": currencycart,
                    "click": {
                        "actionField": {
                            "list": recommInfo.list,
                            "action": "click"
                        },
                        "products": [{
                            'name': productTileObj.tileProduct.title,
                            'id': productTileObj.tileProduct.id,
                            'price': productTileObj.tilePrice,
                            'category': recommInfo.category,
                            'variant': productTileObj.partNumList,
                            'dimension14': recommInfo.dimension14
                        }]
                    }
                },
                "eventCallback": function () {
                    dataLayer.push({
                        "ecommerce": undefined
                    });
                }
            });
            dataLayer.push({
                'event': 'select_item',
                'ecommerce': {
              'item_location_product_rec':'cart',
                  'currency':productTileObj.tileCurrency,
                  'value':productTileObj.tilePrice,
                  'items': [
                  {
                    'item_id': productTileObj.tileProduct.id,
                    'item_name': productTileObj.tileProduct.title,
                    'coupon': '',
                    'discount': '',
                    'index':'0',
                    'item_brand': '',
                    'item_category': recommInfo.category,
                    'item_list_name': recommInfo.list,
                    'item_variant': productTileObj.partNumList,
                    'price':productTileObj.tilePrice,
                    'quantity':''
                  },
                ]
              } 
              });
        }
        /* Google Analytics - End of Recommended product tile click */

        /* Google Analytics - Start of arrow click */
        function arrowClickstoDataLayer(arrow_click) {
            dataLayer.push({
                'event': 'eventTracker',
                'eventCat': 'Arrow Clicks',
                'eventAct': arrow_click,
                'eventLbl': pageLable,
                'eventVal': 0
            });
        }
        /* Google Analytics - End of arrow click */

        /* Google Analytics - Start of Recommended section scroll */
        function sendToDataLayer(recommProdImpressionJSONData) {
            dataLayer.push(recommProdImpressionJSONData);
        }
        /* Google Analytics - End of Recommended section scroll */

        /* Google Analytics - Start */
        function recommAddedInfo(productPartNumber, action, productObj,url) {
            $.ajax({
                type: "GET",
                url: "/common/includes/ajax/ajaxRecommendationDetails.jsp?recomPartNumber=" + productPartNumber,
                cache: false,
                success: function (data) {
                    var recommAddedData = JSON.parse(data);
                    recommDetailedInfo(recommAddedData, action, productObj);
                    if(url != null){
                        window.location.href = url;
                    }
                },
                error: function () {
                    console.log('Service call failed');
                    if(url != null){
                        window.location.href = url;
                    }
                }
            });
        }

        function recommDetailedInfo(recommAddedData, action, productObj) {
            if (recommAddedData.RecommendedProductDetails !== undefined && recommAddedData.RecommendedProductDetails.length > 0) {
                if (action == 'scroll') {
                    var recommDetailedResult = recommAddedData.RecommendedProductDetails;
                    recommProdImpressionJSONDataPush(productObj, action, recommDetailedResult);
                } else if (action == 'arrow_Click') {
                    var recommDetailedResult = recommAddedData.RecommendedProductDetails;
                    recommProdImpressionJSONDataPush(productObj, action, recommDetailedResult);
                } else if (action == 'cart_btn') {
                    var recommDetailedResult = recommAddedData.RecommendedProductDetails[0];
                    sendATCtoDataLayer(productObj, recommDetailedResult);
                } else {
                    var recommDetailedResult = recommAddedData.RecommendedProductDetails[0];
                    sendClicksToDataLayer(productObj, recommDetailedResult);
                }
            }
        }

        function recommProdImpressionJSONDataPush(recommProdImpressionArrayVP, action, recomAddedInfo) {
            var recommProdImpressionJSONData = {};
            recommProdImpressionJSONData.event = 'eventTracker';
            recommProdImpressionJSONData.eventCat = 'eCommerce';
            recommProdImpressionJSONData.eventAct = 'Product Impressions';
            recommProdImpressionJSONData.eventLbl = pageLable;
            recommProdImpressionJSONData.eventVal = 0;
            recommProdImpressionJSONData.ecommerce = {};
            recommProdImpressionJSONData.ecommerce.currencyCode = countryCurrencyCode;
            var variantList = getVariant();
            recomAddedInfo.forEach(function (item, i) {
                var inx = findProducts(recommProdImpressionArrayVP, item.productId);
                recommProdImpressionArrayVP[inx].dimension14 = item.dimension14;
                recommProdImpressionArrayVP[inx].category = item.category;
                recommProdImpressionArrayVP[inx].list = item.list;
                recommProdImpressionArrayVP[inx].variant = '[' + variantList + ']';
            });
            if (typeof recommProdImpressionArrayVP !== undefined) {
                recommProdImpressionJSONData.ecommerce.impressions = recommProdImpressionArrayVP;
            }
            sendToDataLayer(recommProdImpressionJSONData);

            // view_item_list ga4
            var currencycart = $("#currency").val();
        var recommProdImpressionListDataGa4 = []
        var recommProdImpressionJSONDataGa4 = {};
        recommProdImpressionJSONDataGa4.event = 'view_item_list';
        recommProdImpressionJSONDataGa4.item_location_product_rec = 'cart';
        recommProdImpressionJSONDataGa4.ecommerce = {};
        recommProdImpressionJSONDataGa4.ecommerce.currencyCode = currencycart;
        if (typeof recommProdImpressionArrayVP !== undefined) {
            recommProdImpressionArrayVP.forEach(function(item, inx) {
            //var inx = findProducts(recommProdImpressionArrayVP, item.productId);
            var eachRecommProdImpressionDataGa4= {
                'item_id': recommProdImpressionArrayVP[inx].id, 
                'item_name': recommProdImpressionArrayVP[inx].name, 
                'affiliation':'0',
                'coupon': '',
                'discount': '',
                'index':recommProdImpressionArrayVP[inx].position-1,
                'item_brand': '',
                'item_category': item.category,
                'item_list_name':item.list, 
                'item_variant':'[' + variantList + ']',
                'price':recommProdImpressionArrayVP[inx].price,
                'quantity':''
            }
         recommProdImpressionListDataGa4.push(eachRecommProdImpressionDataGa4)
        } )// for loop

        recommProdImpressionListDataGa4.sort(function(itemprevindex, itemnextindex){
            return itemprevindex.index - itemnextindex.index;
        });
        recommProdImpressionJSONDataGa4.ecommerce.item  = recommProdImpressionListDataGa4
        }
        sendToDataLayer(recommProdImpressionJSONDataGa4);
        }

        function findProducts(products, partNumber) {
            for (var i = 0; i < products.length; i++) {
                if (products[i].id == partNumber) {
                    return i;
                }
            }
            return {};
        }

        function findPrice(products, partNumber) {
            for (var j = 0; j < products.length; j++) {
                if (products[j].id == partNumber) {
                    return products[j];
                }
            }
            return {};
        }

        function getVariant() {

            var tablePartNo = [];
            if (orderDetailJson.lineItems != null || orderDetailJson.lineItems != undefined) {
                if (tablePartNo.length == 0) {
                    for (n = 0; n < (Object.keys(orderDetailJson.lineItems)).length; n++) {
                        tablePartNo.push(Object.keys(orderDetailJson.lineItems)[n]);
                    }
                }
            }

            var variantPartNumList = tablePartNo.join("|");
            if ($(document).find('div#Pnp-recommProducts').length > 0) {
                variantPartNumList = $('table#ProductDetails').find('div.partNo').text();
            }
            return variantPartNumList;
        }

        function getProductPartNum(recommProds) {
            var partNums = [];
            recommProds.forEach(function (item, i) {
                partNums.push(item.id);
            });
            return partNums;
        }

        function addPriceToProducts(pid, price) {
            var indexPositon = findProducts(recommProdImpressionArray, pid);
            var selectedProduct = recommProdImpressionArray[indexPositon];
            selectedProduct.price = readPriceValue(price);
            countryCurrencyCode = readCurrencyValue(price);
        }

        function readPriceValue(price) {
            var priceValue = "";
            var priceValueWithComma = "";
            var priceValueWithDot = "";
            if (isNotEmpty(price)) {
                var priceWithoutSpace = price.replace(/ /g, "");
                priceValue = priceWithoutSpace.replace(/[^0-9]+/g, "");
                priceValueWithComma = priceWithoutSpace.replace(/[^0-9,]+/g, "");
                priceValueWithDot = priceWithoutSpace.replace(/[^0-9.]+/g, "");
            }
            if (priceValueWithComma != "" && priceValueWithDot != "" && priceValue != "" && priceValue > 0) {
                var commaIndex = reverseString(priceValueWithComma).indexOf(",");
                var dotIndex = priceValueWithDot.indexOf(".");
                if (commaIndex != 3 && dotIndex < 0) {
                    var lastCommaIndex = priceValueWithComma.lastIndexOf(",");
                    priceValue = replaceAt(priceValueWithComma, lastCommaIndex, ".");
                    priceValue = priceValue.replace(/[^0-9.]+/g, "");
                    priceValue = parseFloat(priceValue).toFixed(2);
                } else {
                    if (dotIndex > 0) {
                        priceValue = priceValueWithDot;
                    }
                    priceValue = parseFloat(priceValue).toFixed(2);
                }
            }
            return priceValue;
        }

        function readCurrencyValue(price) {
            var currencyValue = "";
            if (isNotEmpty(price)) {
                currencyValue = price.replace(/[^A-Za-z]+/g, "");
            }
            return currencyValue;
        }

        function reverseString(strVal) {
            return strVal.split("").reverse().join("");
        }

        function isNotEmpty(obj) {
            if (obj !== undefined && obj !== null && !$.isEmptyObject(obj)) {
                return true;
            } else {
                return false;
            }
        }

        function replaceAt(string, index, replace) {
            return string.substring(0, index) + replace + string.substring(index + 1);
        }
        /* Google Analytics - End */
    });