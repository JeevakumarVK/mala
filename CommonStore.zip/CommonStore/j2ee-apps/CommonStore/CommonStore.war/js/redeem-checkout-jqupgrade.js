var changeAddrFlag=false;
var shiptocustomerdval = false;
$(document).ready(function() {
	//on clicking Change Shipping Addresses use this address button	
      $(document).on('click', '#rcselectshipaddress', function(e) {
		changeAddrFlag=true;
        selectedshipaddr = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
        getshippAddress(selectedshipaddr);
        $("#changeshippingAddressModal  button.close").trigger('click');
    }); 
    function getshippAddress(currVal) {
		changeshipaddress = true;
		var quoteIdval = $("#quoteNumber").val();
		LSCA.loadingSpinner.showLoading();
		$('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
		$("#shipAddContainer").html("");
		var shippingAddrChargeurl;
		if($('#mainContainer .checkoutShippingBilling').hasClass('cpq')){
			shippingAddrChargeurl = '/common/myaccount/redeemQuoteCPQShipAddrChangeSubmit.jsp?addressId='
		}else{
			shippingAddrChargeurl = '/common/myaccount/redeemQuoteShipAddrChangeSubmit.jsp?addressId='
		}		
        $.ajax({
                type: "POST",
                url: shippingAddrChargeurl + currVal+"&quoteId="+quoteIdval,
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changeshipAddress').show();
                $("#shipAddContainer").html(msg);
                $('#shipAddrId').val(currVal);
				$('#shipAddContainerOthers #attentionSP').val("");
                $('#shipAddContainerOthers #buildingRoomSP').val("");
                $('#shipAddContainerOthers #telephoneSP').val("");
                $('#shipAddContainerOthers #attentionSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenShipAttn').text());
                $('#shipAddContainerOthers #buildingRoomSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenbuildNo').text());
                $('#shipAddContainerOthers #telephoneSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenPhoneNo').text());
                $(".fullBillingAddressHidden").html(msg);
                jQuery(".shipingAddressBlock-warrper .fullBillingAddressHidden").hide();
				getOrderSummaryDetails(changeshipaddress,null)	
            }).fail(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }
	function getOrderSummaryDetails(cShipAddress,shiptoid){
		quoteId = $("#quoteNumber").val();
		deliveryOption = $('input[name="delivery"]:checked').val();
		upsCheck = ($("#UpsCheck").val()) ? $("#UpsCheck").val() : false;
		upsNumber = ($("#RedeemQuoteupsNumber").val()) ? $("#RedeemQuoteupsNumber").val() : "";
		fedExCheck = ($("#fedExCheck").val()) ? $("#fedExCheck").val() : false;	 
		fedExNumber = ($("#RedeemQuotefedExnumber").val()) ? $("#RedeemQuotefedExnumber").val() : "";
		quoteTotal = $("#quotationSubtotal").val();
		totalTax = $("#totalTaxValue").val();
		currencyLocale = $("#currencyLocale").val();
		shippingCheck = cShipAddress;		
		makeShippingZero = $("#makeShippingZero").val();
		if(shiptoid == null){
		selectedAddressId = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
		vatCheck = ($("#vatCheck").prop('checked')) ? $("#vatCheck").prop('checked') : false;
		}else{
			selectedAddressId = shiptoid;	
		}
		var fetchShippingChargeurl;
		if($('#mainContainer .checkoutShippingBilling').hasClass('cpq')){
			fetchShippingChargeurl = '/rest/model/com/agilent/commerce/EditCPQRedeemQuantity?atg-rest-output=json';
				fetchShippingAjaxData = JSON.stringify({
						"editRedeemQty":{
							"selectedAddressId": selectedAddressId,
							"quoteNumber": $(".redeemQuoteNew #quoteId").val(),
							"pricingDocId": $(".redeemQuoteNew #pricingDocId").val(),
							"land":($("#land").val()) ? $("#land").val() : ""
							}})
				$.ajax({
					url : fetchShippingChargeurl,
					data : fetchShippingAjaxData,
					dataType : 'JSON',
					type: "POST",
					contentType: "application/json; charset=utf-8",
					success: function (responsedata) {	
						if (!isEmpty(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo)) {
							$('#updatedQuote').val('true');
							$(".redeemQuoteNew #order-summary-table #orderTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.total);	
							$(".redeemQuoteNew #order-summary-table #taxVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.tax);	
							$(".redeemQuoteNew #order-summary-table #shippingVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.shippingCharges);		
							$(".redeemQuoteNew #order-summary-table #subTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.subtotal);
							
							$('#quotationSubtotalValEQ').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationSubtotal);
							$("#quotationTaxValEQ").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTax);
							$('#quotationTotalValEQ').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTotal);
							$("#shipTotalValEQ").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.shipTotal);
							$('#quotationSubtotal').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationSubtotal);
							$('#totalTaxValue').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTax);
							$(".redeemQuoteNew #redeemQuoteOrderForm #quoteTotalAmountVal").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTotal);
							$(".redeemQuoteNew #redeemQuoteOrderForm #editQuoteTotalListPrice").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.totalEditQuoteListPrice);
						}
						LSCA.loadingSpinner.hideLoading();
					},
					error: function() {
						LSCA.loadingSpinner.hideLoading();
						console.log('Something went wrong!');
					}
				});			
		}else{
			fetchShippingChargeurl = '/common/myaccount/fetchShippingCharge.jsp?quoteId='
			$.ajax({
                type: "POST",
                url:fetchShippingChargeurl+quoteId+"&deliveryOption="+deliveryOption+"&upsCheck="+upsCheck+"&upsNumber="+upsNumber+"&fedExCheck="+fedExCheck+"&fedExNumber="+fedExNumber+"&quoteTotal="+quoteTotal+"&totalTax="+totalTax+"&currencyLocale="+currencyLocale+"&shippingCheck="+shippingCheck+"&makeShippingZero="+makeShippingZero+"&selectedAddressId="+selectedAddressId+"&vatCheck="+vatCheck,
                dataType: "json"
            })
            .done(function(data) {
				$('#shippingVal').text(data.shippingHandlingCharge);
				$('#taxVal').text(data.redeemQuoteTaxAmount);
				$('.quoteTotalAmount').text(data.quoteTotal);
				$('#TotalTax').val(data.doubleRedeemQuoteTaxAmount);
				$('#QuotationTotal').val(data.doubleQuoteTotal);
				$('#TotalShippingCharge').val(data.doubleRedeemQuoteshippingHandlingCharge);
				LSCA.loadingSpinner.hideLoading();
            }).fail(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
		}	
	}
	$(document).on('click', '#rcselectbilladdress', function(e) {
        selectedbilladdr = $('#shippingPopUpList ul li input[name=selectBillingAddress]:checked').attr('id');
        getbillAddress(selectedbilladdr);
        $("#changeshippingAddressModal  button.close").trigger('click');
    }); 
    function getbillAddress(currVal) {
    	var quoteIdValue = $("#quoteNumber").val();
		LSCA.loadingSpinner.showLoading();
		$('.billingAddress-wrap #custom-change-BillAddress #fullBillingAddress').remove();
		$("#billAddContainer").html("");	
		var billAddrChargeurl;
		if($('#mainContainer .checkoutShippingBilling').hasClass('cpq')){
			billAddrChargeurl = '/common/myaccount/redeemQuoteCPQBillAddrChangeSubmit.jsp?addressId='
		}else{
			billAddrChargeurl = '/common/myaccount/redeemQuoteBillAddrChangeSubmit.jsp?addressId='
		}			
        $.ajax({
                type: "POST",
                url: billAddrChargeurl + currVal+"&quoteId="+quoteIdValue,
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changebillAddress').show();
                $("#billAddContainer").html(msg);
                $('#billAddrId').val(currVal);
                if($("#changeInvoiceCode1").val() != '') {
					document.getElementById("invoiceCode1").value = $("#changeInvoiceCode1").val();
					$('#changeInvoiceCode1').val("");
				}
				else {
					$('#invoiceCode1').val("");
				}
				if($("#changeInvoiceCode2").val() != '') {
					document.getElementById("invoiceCode2").value = $("#changeInvoiceCode2").val();
					$('#changeInvoiceCode2').val("");
				}
				else {
					$('#invoiceCode2').val("");
				}
				if($("#changeInvoiceCode3").val() != '') {
					document.getElementById("invoiceCode3").value = $("#changeInvoiceCode3").val();
					$('#changeInvoiceCode3').val("");
				}
				else {
					$('#invoiceCode3').val("");
				}
				if($("#changeInvoiceCodeOthers").val() != '') {
					document.getElementById("invoiceCodeOthers").value = $("#changeInvoiceCodeOthers").val();
					$('#changeInvoiceCodeOthers').val("");
				}
				else {
					$('#invoiceCodeOthers').val("");
				}
				if($("#changeEanNumber").val() != '') {
					document.getElementById("eanNumber").value = $("#changeEanNumber").val();
					$('#changeEanNumber').val("");
				}	
				else {
					$('#eanNumber').val("");
				}
                LSCA.loadingSpinner.hideLoading();
            }).fail(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }
    
    $(document).on('click', '#saveBillingAddr', function(e) {
    	var dovalidate = true;
        if ($('#addBillingAddr #fname').is(':visible')) {
            if ($('#addBillingAddr #fname').val() == "") {
                $('#addBillingAddr #fname').next().next().css('display', 'inline-block');
                $('#addBillingAddr #fname').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #fname').addClass('requiredTextBox');
                $('#addBillingAddr #fname').parent().parent('.formGroup').css('margin-bottom', '10px');
                dovalidate = false;
            } else {
                $('#addBillingAddr #fname').next().next().hide();
                $('#addBillingAddr #fname').prev('.fieldLabel').removeClass('requiredLabel');
                $('#addBillingAddr #fname').removeClass('requiredTextBox');
                $('#addBillingAddr #fname').parent().parent('.formGroup').css('margin-bottom', '15px');
            }
        }
        if ($('#addBillingAddr #lname').is(':visible')) {
            if ($('#addBillingAddr #lname').val() == "") {
                $('#addBillingAddr #lname').next().next().css('display', 'inline-block');
                $('#addBillingAddr #lname').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #lname').addClass('requiredTextBox');
                $('#addBillingAddr #lname').parent().parent('.formGroup').css('margin-bottom', '10px');
                dovalidate = false;
            } else {
                $('#addBillingAddr #lname').next().next().hide();
                $('#addBillingAddr #lname').prev('.fieldLabel').removeClass('requiredLabel');
                $('#addBillingAddr #lname').removeClass('requiredTextBox');
                $('#addBillingAddr #lname').parent().parent('.formGroup').css('margin-bottom', '15px');
            }
        }
        if ($('#addBillingAddr #cname').val() == "") {
            $('#addBillingAddr #cname').next().next().css('display', 'inline-block');
            $('#addBillingAddr #cname').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #cname').addClass('requiredTextBox');
            $('#addBillingAddr #cname').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #cname').next().next().hide();
            $('#addBillingAddr #cname').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #cname').removeClass('requiredTextBox');
            $('#addBillingAddr #cname').parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #stAddr').val() == "") {
            $('#addBillingAddr #stAddr').next().next().css('display', 'inline-block');
            $('#addBillingAddr #stAddr').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #stAddr').addClass('requiredTextBox');
            $('#addBillingAddr #stAddr').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #stAddr').next().next().hide();
            $('#addBillingAddr #stAddr').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #stAddr').removeClass('requiredTextBox');
            $('#addBillingAddr #stAddr').parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #city').val() == "") {
            $('#addBillingAddr #city').next().next().css('display', 'inline-block');
            $('#addBillingAddr #city').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #city').addClass('requiredTextBox');
            $('#addBillingAddr #city').parent().parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #city').next().next().hide();
            $('#addBillingAddr #city').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #city').removeClass('requiredTextBox');
            $('#addBillingAddr #city').parent().parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #zip').val() == "") {
            $('#addBillingAddr #zip').next().next().css('display', 'inline-block');
            $('#addBillingAddr #zip').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #zip').addClass('requiredTextBox');
            $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #zip').next().next().hide();
            $('#addBillingAddr #zip').next().next().next().hide();
            $('#addBillingAddr #zip').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #zip').removeClass('requiredTextBox');
            $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #countrypopup').val() == "") {
            $('#addBillingAddr #countrypopup').next().next().css('display', 'inline-block');
            $('#addBillingAddr #countrypopup').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #countrypopup').addClass('requiredTextBox');
            $('#addBillingAddr #countrypopup').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #countrypopup').next().next().hide();
            $('#addBillingAddr #countrypopup').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #countrypopup').removeClass('requiredTextBox');
            $('#addBillingAddr #countrypopup').parent('.formGroup').css('margin-bottom', '15px');
        }
        if (dovalidate) {
        formdata = $('#addBillingAddr').serialize();
        formAttrURL=$('#addBillingAddr').attr('action');
        LSCA.globalAjax.doCall({
            url : formAttrURL,
            data : formdata,
            context : $(this),
            target : $(this)
        }, function(data) {
        	var msg = data.data;
            if (msg.status == 'success') {
            $("#change-edit-shiping-modal  button.close").trigger('click');
        	$('.billingAddress-wrap #custom-change-BillAddress #fullBillingAddress').remove();
    		$("#billAddContainer").html("");
    		$.ajax({
                type: "POST",
                url: "/common/myaccount/redeemQuoteNewBillAddr.jsp",
                dataType: "html"
            })
            .done(function(msg) {
    			$('.custom-after-changebillAddress').show();
                $("#billAddContainer").html(msg);
    				$('#invoiceCode1').val("");
    				$('#invoiceCode2').val("");
    				$('#invoiceCode3').val("");
    				$('#invoiceCodeOthers').val("");
    				$('#eanNumber').val("");
    				if (!$('#addBillingAddr #billAttNew').val() == "") {
    					document.getElementById("billAttnno").value = $('#addBillingAddr #billAttNew').val();
    				}
    				if (!$('#addBillingAddr #buildRoom').val() == "") {
    					document.getElementById("billPhoneNo").value = $('#addBillingAddr #buildRoom').val();
    				}
            }).fail(function() {
                console.log('Something went wrong!')
            });
        }
            else {
                $('#addBillingAddr #zip').next().next().next().css('display', 'inline-block');
                $('#addBillingAddr #zip').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #zip').addClass('requiredTextBox');
                $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
            }
        });
        }
    });
    function savebillAddress() {
        $.ajax({
                type: "POST",
                url: "/common/myaccount/ajaxAddBiliing.jsp",
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changebillAddress').show();
				LSCA.loadingSpinner.hideLoading();
            }).fail(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }

/* Drop shipment script */
var $checkboxes = $('.redeemQuoteNew #optionsRadios1');
var countUnCheckedCheckboxes = $checkboxes.filter('#optionsRadios1').length;
$checkboxes.on('change',function() {
    var countCheckedCheckboxes = $checkboxes.filter(':checked').length;
    if (countCheckedCheckboxes > 0) {
        $('.customDropshipWrap').css('display', 'block');
        $("#shipToNumber").val($("#inputShipto").val());
        $("#shiptocustomer1").show();
        $("#disabled-shiptocustomer,.shipToEntryFields .mText,#shipto-remove-msg1,#errorShipLabel").hide();
        $("#inputShipto").removeAttr("disabled", "disabled");
        $('#inputShipto').addClass('required');
    } else {
        $('.customDropshipWrap').css('display', 'none');
        $("#shiptocustomer").hide();
        $("#disabled-shiptocustomer").css('display', 'inline-block');
        $("#inputShipto").attr("disabled", "disabled");
        $('.shipToFields > label').removeClass('requiredLabel');
        $('#inputShipto').removeClass('requiredTextBox required');
    }
});
$(document).on('click', '.redeemQuoteNew #shiptocustomer1', function(e) {
    e.stopPropagation();
    $('#inputShipto').attr('style', '');
    $('#inputShipto').removeClass('requiredTextBox required');
    $('.shipToEntryFields .mText').hide();
    $('.shipToFields > label').removeClass('requiredLabel');
    $('.shipToEntryFields #errorShipLabel').html('').hide();
    $('.rightaddressDiv label').removeClass('requiredLabel');
    $('.rightaddressDiv .rightMandatoryFields input').removeClass('requiredTextBox');
    $('.rightaddressDiv .rightMandatoryFields span.mText').hide();
    formdata = $('#inputShipto').val();
    if ($('#inputShipto').val() == "") {
        $('#inputShipto').attr('style', '');
        $('#inputShipto').addClass('requiredTextBox required');
        $('.shipToEntryFields .mText').show();
        $('.shipToFields > label').addClass('requiredLabel');
        $('.shipToEntryFields #errorShipLabel').html('').hide();
    } else {
        LSCA.globalAjax.doCall({
            url: '/common/checkout/ajaxFetchShiptoIdAddressForRedeemQuote.jsp?shipToId=' + formdata,
            data: formdata,
            context: $(this),
            target: $(this)
        }, function(data) {
            var shiptocontinuemsg = data.data;
            if (shiptocontinuemsg.status != 'success') {
                console.log('error');
                $('#inputShipto').attr('style', '');
                $('#inputShipto').addClass('requiredTextBox required');
                $('.shipToEntryFields .mText').hide();
                $('.shipToFields > label').addClass('requiredLabel');
                $('.shipToEntryFields #errorShipLabel').html(shiptocontinuemsg.innerHTML).show();
            } else {
            	shiptocustomerdval = true;
                $("#custom-change-shipAddress").hide();
                $('#inputShipto').removeClass('requiredTextBox required');
                $('.shipToFields > label').removeClass('requiredLabel');
                $('#shipto-Address').show();
				$("#shipAddContainer").html(shiptocontinuemsg.innerHTML);
                $("#shipto-Address").html(shiptocontinuemsg.innerHTML);
                $("#custom-change-shipAddress #customDropdown2").val($("#shipto-Address #customDropdown2").val());
                jQuery("#attentionSP").val(jQuery("#shipAttention").val());
                jQuery("#buildingRoomSP").val(jQuery("#shipBuildingNum").val());
                jQuery("#telephoneSP").val(jQuery("#contactNumber").val());
                changeshipaddress = true;
                shiptovalue = $('#inputShipto').val();
                while (shiptovalue.length < 10) {
                	shiptovalue = "0" + shiptovalue;
					length++;
				}
                getOrderSummaryDetails(changeshipaddress,shiptovalue); 
				LSCA.loadingSpinner.showLoading();
            }
        });
    }
});
$(document).on('click', '.redeemQuoteNew #lcshipto-address-remove', function(e) {
    e.preventDefault();
    shiptocustomerdval = false;
    document.getElementById("optionsRadios1").checked = false;
    $("#inputShipto").attr("disabled", "disabled");
    $("#shiptocustomer").css('display', 'none');
    $('.customDropshipWrap').css('display', 'none');
    $("#shipto-remove-msg1").css('display', 'block');
    $("#disabled-shiptocustomer").css('display', 'inline-block');
    $('#shipto-Address').hide();
    $("#shipAddContainer").html("");
    $('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
    $('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
	$("#custom-change-shipAddress,#custom-change-shipAddress .fullBillingAddressHidden").show();
    if(changeAddrFlag){
		$('#shipAddContainerOthers #attentionSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenShipAttn').text());
		$('#shipAddContainerOthers #buildingRoomSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenbuildNo').text());
		$('#shipAddContainerOthers #telephoneSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenPhoneNo').text());
	}
	else{
		$('#shipAddContainerOthers #attentionSP').val($('#hiddenShipAttnVal').val());
		$('#shipAddContainerOthers #buildingRoomSP').val($('#hiddenbuildNoVal').val());
		$('#shipAddContainerOthers #telephoneSP').val($('#hiddenPhoneNoVal').val());
	}
    changeshipaddress = true;
    getOrderSummaryDetails(changeshipaddress,$('#shipAddrId').val()); 
	LSCA.loadingSpinner.showLoading();
});  
var rqarrVal=[],editableFlagVal = false,rqLength="";
$(".rq-qtytxt").each(function(){
	rqarrVal.push($(this).val());
});
$(document).on('keyup', '.rq-qtytxt', function(e) {
	var $this = $(this);
	if($this.parents("tr").find(".product-inner #isMTO").val() == "true"){
		$this.val($this.val().replace(/[^\d]|^0/g, ''));
		if (!$this.val()) {
			$(this).next(".rq-qtyErrLabel").text($("#cannotRemoveLbl").val());
			$(this).next(".rq-qtyErrLabel").css({'position':'absolute','transform':'translateX(-50%)','-webkit-transform':'translateX(-50%)','width':'300px'});
		}
	}
});
$(document).on("keyup", ".redeemQuoteNew .rq-qtytxt", function(e) {
	var $this = $(this);
	rqLength=jQuery(".redeemQuoteNew .rq-qtytxt").length;
	if(rqLength == 1){
		$this.val($this.val().replace(/[^\d]|^0/g, ''));
	}
	if ($this.val()) {
		$this.css('border-color', '#0085d5');
		$(this).prev(".rq-qtytxtLabel").removeClass("requiredLabel");
		$(this).next().removeClass("requiredLabel");
		$(this).removeClass("requiredTextBox");
		$(this).next().hide();
	} else {
		$this.css('border-color', '#D6001C');
		$(this).prev(".rq-qtytxtLabel").addClass("requiredLabel");
		$(this).next().addClass("requiredLabel");
		$(this).addClass("requiredTextBox");
		$(this).next().show();
	}
	$(this).focus(function () {
		$(this).css("border","1px solid #0085d5");
		}).on('blur',function () {
		$(this).css("border","1px solid #b1b3b3");
		var $tr = $(this).parents('tr');
		if ($tr.length > 0) {                    
			$tr.find('input.rq-qtytxt').val($(this).val());
		}	
		rqarrVal=[];
		$(".rq-qtytxt").each(function(){
			rqarrVal.push($(this).val());
		});	
	});
});
$(document).on("keydown", ".redeemQuoteNew .rq-qtytxt", function(e) {
	var keycode = (e.keyCode ? e.keyCode : e.which);
		if (keycode == '13') {
			e.preventDefault();
			return false;
		}
});
$(".redeemQuoteNew .rq-qtytxt").on('blur',function () {
	editableFlagVal=false;
	rqarrVal=[];
	var $thisVal = $(this);
	$(".rq-qtytxt").each(function(){
		rqarrVal.push($(this).val());
	});
	for(var i=0;i<rqarrVal.length;i++){		
		if(rqarrVal[i] > 0){			
			editableFlagVal=true;
		}
	}
	$(document).on("keyup", ".rq-qtytxt", function(e) {
		var $thisVal = $(this);
		if(!editableFlagVal){		
			$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
			$thisVal.css('border-color', '#D6001C');
			$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$thisVal.next().addClass("requiredLabel");
			$thisVal.addClass("requiredTextBox");
			$thisVal.next().show();
		}
		else{
			$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
			$thisVal.css('border-color', '#0085d5');
			$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$thisVal.next().removeClass("requiredLabel");
			$thisVal.removeClass("requiredTextBox");
			$thisVal.next().hide();
		}
	});
		if((!editableFlagVal) || ($thisVal.val()=="")){		
			$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
			$thisVal.css('border-color', '#D6001C');
			$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$thisVal.next().addClass("requiredLabel");
			$thisVal.addClass("requiredTextBox");
			$thisVal.next().show();
		}
		else{
			$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
			if($thisVal.val() == "0"){
				$thisVal.parents("tr").addClass("zeroRow");
			}
			$thisVal.css('border-color', '#b1b3b3');
			$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$thisVal.next().removeClass("requiredLabel");
			$thisVal.removeClass("requiredTextBox");
			$thisVal.next().hide();
		}
});
});
var changeShipVal = $("#rq-change").val();
var rqSplitQuantity = $("#rq-quantity").val();
var rqSplitShippingDate = $("#rq-shippingDate").val();
var rqSplitApply = $("#rq-apply").val();
var rqScheduledShipping = $("#rq-scheduledShipping").val();
$(window).on("load", function() {
	var rq_qty_val=0,partNoVal="",partNoValText="",splitship_sumqtyval=[],firstValCounterQty=0,firstRowVal=0,rqmindateVal="";
	$("#chekoutItemSection .custom-item-details-wrap table tr").each(function () {
		var cal_counter=0;
		$thisVal = $(this);
		$thisVal.find(".split-add-moreLink").click(function(){
			cal_counter++;
			partNoValText=$(this).parents("tr").attr("data-partno").trim();
			var html = '',calendarval="rq-shipdatepicker"+cal_counter;
			html += '<div class="split-shipping-inner empty" data-partno="'+partNoValText+'">';
			html += '<p class="split-ship-value"><span class="qty"></span>&nbsp;-&nbsp;'+rqScheduledShipping+'&nbsp;<span class="sp-date"></span><input type="hidden" id="splitShipDate"><a class="updatedChangeLink">'+changeShipVal+'</a></p><span class="qty-wrap"><p class="rq-splittxtLabel fieldLabel">'+rqSplitQuantity+'</p><input type="text" maxlength="4"></span>';
			html += '<span class="cldr-wrap form-group calender_control custom-future-date1"><p class="rq-splittxtLabel fieldLabel">'+rqSplitShippingDate+'</p><span class="calendar-display"><input placeholder="mm/dd/yyyy" value="" class="' + calendarval +'" name="' + calendarval +'" type="textbox"></span></span><button class="btn-stnd-small primary-apply apply_btn" type="button">'+rqSplitApply+'</button><span class="removeLink removeMore"><i class="fal fa-minus-circle"></i></span>';
			html += '</div><div class="btn-wrap"><button class="btn-stnd-small apply_btn afterChange" id="apply_btn1" type="button" disabled>'+rqSplitApply+'</button></div>';
			$(this).siblings(".apply_btn.enableBtn").show();
			$(this).parents('#split-add-more').before(html);
			$(this).parents("tr").find(".split-shipping-inner .apply_btn.primary-apply").hide();				
			if ($.cookie("CountryCode") === 'CN') {
				$(".calendar-display input").attr("placeholder", "yyyy/mm/dd");
			}	
			rqmindateVal=$(this).parents("tr").find("#calendarMinInputValue").val();
			rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
			var rqDateFormatVal = "";
			 if ($.cookie("CountryCode") === 'CN') {
				 rqDateFormatVal = "yy/mm/dd";
			 }
			 else{
				 rqDateFormatVal = "mm/dd/yy";
			 }
			$("."+calendarval).datepicker({        
				showOn : "both",
				buttonImage : "../images/A_Icon_Calendar_V2.svg",
				buttonImageOnly : true,
				dateFormat: rqDateFormatVal,
				minDate : rqmindateVal,
				autoClose: true,
				maxDate : rqmaxdateVal
			}).attr('readonly', true);
			$(this).parents("tr").find(".custom-estimated-time .rq-changeLink").addClass("disable_a_href");
			if($(this).parents("tr").find(".split-shipping-inner").hasClass("showblock")){
				$(this).parents("#split-add-more").siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
			}
		});	
	});
});
function getNumberOfDays(startDate, endDate) {
	var date1 = new Date(startDate);
	var date2 = new Date(endDate);
	var oneDay = 1000 * 60 * 60 * 24;
	var diffInTime = date2.getTime() - date1.getTime();
	var diffInDays = Math.round(diffInTime / oneDay);
	return diffInDays;
}
var splitShipArr = [],
firstValCounter = 0,
clickFlag = false;

$(document).ready(function() {
$(".qty-wrap input").removeClass("changedQty");
$(document).on("change", ".qty-wrap input", function() {
    firstValCounter = 0;
    $(".qty-wrap input").removeClass("changedQty");
    $(this).addClass("changedQty");
    $(".redeemQuoteNew #chekoutItemSection tr").removeClass("changedRow");
    $(this).parents("tr").removeClass("changedRow").addClass("changedRow");
    var parentVal = $(this).parents("tr.changedRow").attr("data-itemno");
    $(".split-shipping-inner").each(function() {	
    	if ($(this).parents("tr.changedRow").attr("data-itemno") == parentVal) {
    		if($(this).find(".qty-wrap input").val()!=""){
				firstValCounter = firstValCounter + Number($(this).find(".qty-wrap input").val());
    		}
    		//else{
    			//firstValCounter = firstValCounter + Number($(this).find(".split-ship-value .qty").text().trim());
    		//}
            $(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val(firstValCounter);
            if (firstValCounter > $(this).parents("tr").attr("data-qty")) {
                $(this).siblings("#split-add-more").find(".errMsgText .errMsgQty").text($(this).parents("tr").attr("data-qty"));
                $(this).siblings("#split-add-more").show();
                $(this).siblings("#split-add-more").find(".errMsgText").show();
                $(this).siblings("#split-add-more").find(".errMsgText").addClass("requiredMsg");
                $(this).parents("tr").find(".qty-wrap input.changedQty").addClass("requiredClass");
                $(this).parents("tr").find(".qty-wrap input.changedQty").prev(".rq-splittxtLabel").addClass("requiredMsg");
                $(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).addClass("requiredMsg");
                $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
            } else {
                if (firstValCounter == $(this).parents("tr").attr("data-qty")) {
                $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
                } else {
                $(this).siblings("#split-add-more").find(".split-add-moreLink").show();
                }
                $(this).siblings("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
                $(this).siblings("#split-add-more").find(".errMsgText").hide();
                $(this).parents("tr").find(".qty-wrap input.changedQty").removeClass("requiredClass");
                $(this).parents("tr").find(".qty-wrap input.changedQty").prev(".rq-splittxtLabel").removeClass("requiredMsg");
                $(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).removeClass("requiredMsg");
            }
        }
    });
});
$(".split-shipping-inner").each(function() {	
	$(document).on("blur", ".qty-wrap input", function() {
		var parentValue = $(this).parents("tr.changedRow").attr("data-partno");
		if (($(this).parents(".split-shipping-inner").attr("data-partno") == parentValue) && ($(this).parents("tr").find("#inStockCountValue").val()!="")){	
			if(Number($(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val())>Number($(this).parents("tr").find("#inStockCountValue").val())){
				todayDate = $.datepicker.formatDate('mm/dd/yy', new Date());
				rqmindateVal = getNumberOfDays(todayDate, $(this).parents("tr").find("#estDateValue").val());
				var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];
				$("."+calClassName).datepicker('option', {
						minDate: rqmindateVal
				});
					
			}
			else{
				rqmindateVal = $(this).parents("tr").find("#calendarMinInputValue").val();
				var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];
				$("."+calClassName).datepicker('option', {
						minDate: rqmindateVal
				});
			}
		}
	});
});
$(document).on("change", ".qty-wrap input", function() {
	if(Number($(this).parents("tr").find("#inStockCountValue").val())!=""){
		var instockVal = Number($(this).parents("tr").find(".custom-estimated-time .custom-instock span .mixedStock").text());
		var stockValue=  Number($(this).parents("tr.changedRow").find("#inStockCountValue").val());
		var estVal = Number($(this).parents("tr.changedRow").attr("data-qty"))-stockValue;
		if(firstValCounter<stockValue){
			var totalvalue = stockValue - firstValCounter;
			if(totalvalue > 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.stockMsgResponse .mixedStock").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock > span.stockMsgResponse").show();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(estVal);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse").show();
			//$(this).parents("tr.changedRow").find(".custom-estimated-time .rq-changeLink").show();	
			}
		}
		if(firstValCounter==stockValue){
			var totalvalue = stockValue - firstValCounter;
			if(totalvalue == 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.stockMsgResponse .mixedStock").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock > span.stockMsgResponse").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(estVal);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse").show();
			//$(this).parents("tr.changedRow").find(".custom-estimated-time .rq-changeLink").show();	
			}
		}
		if(firstValCounter>=stockValue){
			var totalvalue = estVal - (firstValCounter - stockValue);
			if((totalvalue > 0 && instockVal==0) ||(totalvalue > 0 && instockVal!=0)){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.stockMsgResponse .mixedStock").text("0");
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock > span.stockMsgResponse").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse").show();
			//$(this).parents("tr.changedRow").find(".custom-estimated-time .rq-changeLink").show();	
			}
			if(totalvalue == 0){
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock span.stockMsgResponse .mixedStock").text("0");
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock > span.stockMsgResponse").hide();
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(totalvalue);
			$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse").hide();
			//$(this).parents("tr.changedRow").find(".custom-estimated-time .rq-changeLink").hide();	
			}
		}
	}
	else{
		if($(this).parents("tr.changedRow").find(".custom-estimated-time span").hasClass("estimatedStock")){
			var totalvalue =  Number($(this).parents("tr.changedRow").attr("data-qty")) - firstValCounter;
			
			if(totalvalue > 0){					
				$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock .estimatedStock").text(totalvalue);
				$(this).parents("tr.changedRow").find(".custom-estimated-time").show();
				
			}
			if(totalvalue == 0){
				$(this).parents("tr.changedRow").find(".custom-estimated-time .custom-instock .estimatedStock").text(totalvalue);
				$(this).parents("tr.changedRow").find(".custom-estimated-time").hide();
			}
		}				
	}
});
$(document).on("keyup", ".qty-wrap input", function(e) {
    $(this).val($(this).val().replace(/[^\d]|^0/g, ''));
});

$(document).on("mouseover", ".qty-wrap input,.calendar-display input", function() {
	if ($(this).val() != "" && $(this).parents().siblings(".cldr-wrap,.qty-wrap").find("input").val() != "" && ($(this).closest(".split-shipping-inner").find(".split-ship-value .qty,.split-ship-value .sp-date").text().trim()!="") ) {
        $(this).closest(".split-shipping-inner").addClass('removeIcon');
    }
});
$(document).on("mouseleave", ".split-shipping-inner", function() {
    $(this).removeClass('removeIcon');
});
$(document).on("click", ".removeLink.removeMore", function() {
		var firstValCounter1=0;
		firstValCounter1=Number($(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val());	
        $("#split-add-more .errMsgText").removeClass("requiredMsg");
        $("#split-add-more .errMsgText").hide();
        if($(this).parents("tr").find(".custom-estimated-time span").hasClass("estimatedStock")){
			var removeStockVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-instock .estimatedStock").text())+Number($(this).siblings(".qty-wrap").find("input").val());
			$(this).parents("tr").find(".custom-estimated-time .custom-instock .estimatedStock").text(removeStockVal);
			$(this).parents("tr").find(".custom-estimated-time").show();
		}
		else if($(this).parents("tr").find(".custom-estimated-time span.stockMsgResponse .stockInfoResponse span").hasClass("mixedStock")){
			var stockValue=  Number($(this).parents("tr").find("#inStockCountValue").val());
			//var removeStockVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-instock > span.stockMsgResponse .stockInfoResponse span").text())+Number($(this).siblings(".qty-wrap").find("input").val());
			var removeStockVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text())+Number($(this).siblings(".qty-wrap").find("input").val());
			var estVal = Number($(this).parents("tr").attr("data-qty"))-stockValue;
			if(removeStockVal<=estVal){
				$(this).parents("tr").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(removeStockVal);
				$(this).parents("tr").find(".custom-estimated-time .custom-instock  b.stockMsgSubResponse").show();
			}
			if(removeStockVal>estVal){
					var resultStockVal = removeStockVal -  estVal;
					$(this).parents("tr").find(".custom-estimated-time .custom-instock b.stockMsgSubResponse span").text(estVal);
					var finalVal=Number($(this).parents("tr").find(".custom-estimated-time .custom-instock > span.stockMsgResponse .stockInfoResponse span").text())+resultStockVal;
					$(this).parents("tr").find(".custom-estimated-time .custom-instock > span.stockMsgResponse .stockInfoResponse span").text(finalVal);
					$(this).parents("tr").find(".custom-estimated-time .custom-instock > span.stockMsgResponse").show();
					$(this).parents("tr").find(".custom-estimated-time .custom-instock  b.stockMsgSubResponse").show();
			}			
		}
		if ($(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length == 1) {
            $(this).parents(".split-shipping-inner").find(".qty-wrap input").val("");
            $(this).parents(".split-shipping-inner").find(".cldr-wrap input").val("");
            $(this).parents(".split-shipping-inner").removeClass("removeIcon");
			$(this).parents(".split-shipping-inner").find(".split-ship-value .qty,.split-ship-value .sp-date").text("");
			$(this).parents(".split-shipping-inner").find(".split-ship-value").hide();
			$(this).parents(".split-shipping-inner").find(".split-ship-value").removeClass("showblock"); 
			$(this).parents(".split-shipping-inner").find("#splitShipDate").val("");
            $(this).parents(".split-shipping-inner").find(".qty-wrap input").removeClass("requiredClass");            
			$(this).parents(".split-shipping-inner").find(".apply_btn.primary-apply").show();
			$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".apply_btn.enableBtn,.split-add-moreLink").hide();
			$(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val("0");
			$(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href hoverChangeLink");
			$(this).parents(".split-shipping-inner").hide();
			$(this).parents("tr").find(".rq-changeLink").show();
        } else {
			var $this = $(this);			
			if($(this).parents(".split-shipping-inner").find(".qty-wrap input").val()!=""){
				firstValCounter1 = firstValCounter1 - Number($(this).parents(".split-shipping-inner").find(".qty-wrap input").val());
			}			
			$(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val(firstValCounter1);	
            $(this).parents(".split-shipping-inner").next(".btn-wrap").remove();
			$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").addClass("addLabel");
			if($this.parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").length == 1){
				$this.parents("#rq-schedule-shipping-wrap").find("#split-add-more .enableBtn").hide();
			}
			if (firstValCounter1 <= $(this).parents("tr").attr("data-qty")) {
				$(this).parents("tr").find(".split-add-moreLink").show();
			}
			$(this).parents(".split-shipping-inner").siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
			if($(this).parents("tr").find(".split-shipping-inner").hasClass("showblock")){$(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
			}
			$(this).parents(".split-shipping-inner").remove();
			}
			if($("#chekoutItemSection .split-shipping-inner .split-ship-value .qty,.split-ship-value .sp-date").text()==""){
				$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",false);
				$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
				if ($("#mainContainer.redeemQuoteNew .calender_control.custom-future-date").is(':visible')) {
					$('#mainContainer.redeemQuoteNew .calender_control.custom-future-date').show();
				}
			}
});
$(".split-shipping-inner").each(function() {
	$(document).on("focus", ".calendar-display input", function() {
		var parentValue = $(this).parents("tr.changedRow").attr("data-partno");
		var rqDateFormatVal = "";
		 if ($.cookie("CountryCode") === 'CN') {
			 rqDateFormatVal = "yy/mm/dd";
		 }
		 else{
			 rqDateFormatVal = "mm/dd/yy";
		 }
		if (($(this).parents(".split-shipping-inner").attr("data-partno") == parentValue) && ($(this).parents("tr").find("#inStockCountValue").val()!="")){	
			if(Number($(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val())>Number($(this).parents("tr").find("#inStockCountValue").val())){
				todayDate = $.datepicker.formatDate('mm/dd/yy', new Date());
				rqmindateVal = getNumberOfDays(todayDate, $(this).parents("tr").find("#estDateValue").val());
				var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];				
				rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
				$("."+calClassName).datepicker('destroy');
				$("."+calClassName).datepicker({        
					showOn : "both",
					buttonImage : "../images/A_Icon_Calendar_V2.svg",
					buttonImageOnly : true,
					dateFormat: rqDateFormatVal,
					autoClose: true
					}).attr('readonly', true);
				$("."+calClassName).datepicker('option', {
						minDate: rqmindateVal
				});
				$("."+calClassName).datepicker('option', {
						maxDate: rqmaxdateVal
				});
			}
			else{				
				rqmindateVal = $(this).parents("tr").find("#calendarMinInputValue").val();
				rqmaxdateVal=$(this).parents("tr").find("#calendarMaxInputValue").val();
				var calClassName=$(this).parents(".split-shipping-inner").find(".calendar-display input").attr("class").split(" ")[0];	
				$("."+calClassName).datepicker('destroy');
				$("."+calClassName).datepicker({        
					showOn : "both",
					buttonImage : "../images/A_Icon_Calendar_V2.svg",
					buttonImageOnly : true,
					dateFormat: rqDateFormatVal,
					autoClose: true
				}).attr('readonly', true);
				$("."+calClassName).datepicker('option', {
						minDate: rqmindateVal
				});	
				$("."+calClassName).datepicker('option', {
						maxDate: rqmaxdateVal
				});	
			}
		}
	});
	
});
$(document).on("change", ".qty-wrap input,.cldr-wrap input", function() {
	if($(this).parents(".split-shipping-inner:not(.showblock)").hasClass("first")){
		if ((!$(this).parents(".split-shipping-inner.first").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).parents(".split-shipping-inner.first").find(".qty-wrap input").val() != "") && ($(this).parents(".split-shipping-inner.first").find(".cldr-wrap input").val() != "")) {
		$(this).parents(".split-shipping-inner.first").find(".primary-apply").click();
		}
	}
	else{
		if ((!$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).parents(".split-shipping-inner").find(".qty-wrap input").val() != "") && ($(this).parents(".split-shipping-inner").find(".cldr-wrap input").val() != "")) {
			if(!$(this).parents(".split-shipping-inner").hasClass("showblock")){
				$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".enableBtn").click();
			}
			else{
				$(this).parents(".split-shipping-inner").siblings(".btn-wrap").find(".afterChange").click();
			}
		}
	}
});
$(document).on("click", ".apply_btn.primary-apply", function() {
	var rqDateFormatVal = "";
			 if ($.cookie("CountryCode") === 'CN') {
				 rqDateFormatVal = "yy/mm/dd";
			 }
			 else{
				 rqDateFormatVal = "mm/dd/yy";
			 }
    if ((!$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).siblings(".qty-wrap").find("input").val() != "") && ($(this).siblings(".cldr-wrap").find(".calendar-display input").val() != "")){
        $(this).siblings(".split-ship-value").find(".qty").text($(this).siblings(".qty-wrap").find("input").val());
        var jsDate = new Date($(this).siblings(".cldr-wrap").find(".calendar-display input").val());
		$(this).siblings(".split-ship-value").find(".sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",jsDate)));
        $(this).siblings(".split-ship-value").find("#splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
        $(this).siblings(".split-ship-value").show();
        $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
    	$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);	
    	if ($("#mainContainer.redeemQuoteNew .calender_control.custom-future-date").is(':visible')) {
    		$('#mainContainer.redeemQuoteNew .calender_control.custom-future-date').hide();
    	}
		$(this).parents(".split-shipping-inner").removeClass("showblock").addClass("showblock");
        $(this).siblings(".split-ship-value").removeClass("showblock").addClass("showblock");
        $(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
        $(this).parents("tr.changedRow").find(".custom-estimated-time .hoverChangeLink").hide();
        $(this).parents("tr").find(".split-shipping-inner:not(.showblock,.first)").each(function() {
    		if($(this).find(".qty-wrap input").val() == "" && $(this).find(".cldr-wrap .calendar-display input").val() == ""){
    			$(this).next(".btn-wrap").remove();
    			$(this).remove();
    		}
    	});
		var SSList = [];
		var checkEmptyFields=false;
		$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index){
		if($(this).find(".qty-wrap input").val() != "" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
				var ssqty = $(this).find(".split-ship-value .qty").text();
				var qtydisp = $(this).find(".qty-wrap").css("display");
				var spdateval ="";
				spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
			SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
		}else{
			checkEmptyFields = true;
					return;
			}
		 });
	if(!checkEmptyFields){
	SSList.sort(function (a, b){
		var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
		return (dateA - dateB);
	});
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
		$(this).find(".split-ship-value .qty").text(SSList[index].qty);
		$(this).find(".qty-wrap input").val(SSList[index].qty);
	    $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
		/*
		$(this).find(".qty-wrap").css('display',SSList[index].qtydisp);
		$(this).find(".cldr-wrap").css("display",SSList[index].qtydisp);
		if(SSList[index].qtydisp === "block" || SSList[index].qtydisp === "inline-block"){
		$(this).find(".updatedChangeLink").addClass("hoverChangeLink");
		}else{
			$(this).find(".updatedChangeLink").removeClass("hoverChangeLink");
			}*/
		$(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date(SSList[index].ssdate)));
		$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
		});
	}
    }
    else{
		if(($(this).siblings(".cldr-wrap").find(".calendar-display input").val() == "") && ($(this).siblings(".qty-wrap").find("input").val() == "")){
		$(this).parents(".split-shipping-inner").hide();
		$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").hide();
		$(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
		}
	}
});
});
$(window).on("load", function() {
$(document).on("click", ".rq-changeLink", function() {
	if ($.cookie("CountryCode") === 'CN') {
		$(".calendar-display input").attr("placeholder", "yyyy/mm/dd");
	}
	$(this).addClass("hoverChangeLink");
	if($(this).parents("tr").attr("data-qty") == 1){
		$(this).parents("tr").find("#rq-schedule-shipping-wrap #split-add-more").hide();
	}else{
	$(this).parents("tr").find("#rq-schedule-shipping-wrap #split-add-more").show();
	}
	if($(this).hasClass("hoverChangeLink")){
		/*if($(this).parents("tr").attr("data-qty") == 1){
			$(this).parents("tr").find("#rq-schedule-shipping-wrap,.split-shipping-inner").show();
		}else{*/
		$(this).parents("tr").find("#rq-schedule-shipping-wrap,.split-shipping-inner").show();
		$(this).parents("tr").find(".split-shipping-inner .qty-wrap,.split-shipping-inner .cldr-wrap").show();
		$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner").siblings("#split-add-more").find(".split-add-moreLink").show();
		$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner .rq-splittxtLabel").show();
		$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner .primary-apply").show();
		$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner").siblings("#split-add-more").find(".enableBtn").hide();
		//}
	}
	else{
        $(this).parents("tr").find("#rq-schedule-shipping-wrap").show();
        $(this).parents("tr").find("#rq-schedule-shipping-wrap .primary-apply").show();
        $(this).parents("tr").find("#rq-schedule-shipping-wrap .enableBtn").hide();
	}
});
$(document).on("click", '.apply_btn.enableBtn:not(.afterChange)', function() {
	var notEmpty=false;
	var rqDateFormatVal = "";
			 if ($.cookie("CountryCode") === 'CN') {
				rqDateFormatVal = "yy/mm/dd";
			 }
			 else{
				 rqDateFormatVal = "mm/dd/yy";
			 }
    $(this).parents("#split-add-more").siblings(".split-shipping-inner:not(.showblock)").each(function() {
		if($(this).parents("#split-add-more").siblings(".split-shipping-inner").length == 0){
			$(this).parents("#rq-schedule-shipping-wrap").find("#split-add-more").find(".enableBtn").hide();
			$(this).parents("#split-add-more").find(".split-add-moreLink").hide();
		}
        if ((!$(this).siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).find(".qty-wrap input").val() != "") && ($(this).find(".cldr-wrap .calendar-display input").val() != "")) {
            $(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
            var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());
            $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy", jsDate)));
            $(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
            $(this).find(".split-ship-value").show();
			$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
			$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
			if ($("#mainContainer.redeemQuoteNew .calender_control.custom-future-date").is(':visible')) {
				$('#mainContainer.redeemQuoteNew .calender_control.custom-future-date').hide();
			}
			$(this).removeClass("showblock").addClass("showblock");
            $(this).find(".split-ship-value").removeClass("showblock").addClass("showblock");
            $(this).find(".qty-wrap,.cldr-wrap").hide();
            $(this).parents("tr").find(".custom-estimated-time .hoverChangeLink").hide();
        var SSList = [];
		var checkEmptyFields=false;
		$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
				if($(this).find(".qty-wrap input").val() !="" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
			var ssqty = $(this).find(".split-ship-value .qty").text();
				var qtydisp = $(this).find(".qty-wrap").css("display");
				var spdateval = "";
				spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
				SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
				}else{
					checkEmptyFields = true;
					return;
				}
		 });
	if(!checkEmptyFields){
	SSList.sort(function (a, b) {
		var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
		return (dateA - dateB);
	});
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
		$(this).find(".split-ship-value .qty").text(SSList[index].qty);
		$(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
		/*	$(this).find(".qty-wrap").css('display',SSList[index].qtydisp);
		$(this).find(".cldr-wrap").css("display",SSList[index].qtydisp);
		if(SSList[index].qtydisp == "block" || SSList[index].qtydisp === "inline-block" ){$(this).find(".updatedChangeLink").addClass("hoverChangeLink");
		}else{
			$(this).find(".updatedChangeLink").removeClass("hoverChangeLink");
			}*/
		$(this).find(".qty-wrap input").val(SSList[index].qty);
		$(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date( SSList[index].ssdate)));
		$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
		});
	}
	if (($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty")) && ($(this).find(".qty-wrap input").val() != "") && ($(this).find(".cldr-wrap .calendar-display input").val() != "")) {
		$(this).siblings("#split-add-more").find(".apply_btn").hide();
		$(this).parents("tr").find(".rq-changeLink").hide();
		$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
		} else {
			$(this).parents("tr").find(".rq-changeLink").hide();
			$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
			$(this).siblings("#split-add-more").find(".apply_btn.enableBtn").hide();
			}
			} else {
            if ($(this).find(".qty-wrap input").val() == "" && $(this).find(".cldr-wrap .calendar-display input").val() == "") {
				$(this).removeClass("nonEmpty");
				if($(this).siblings(".split-shipping-inner").hasClass("showblock") || (!$(this).siblings(".split-shipping-inner").hasClass("first"))){
					$(this).siblings(".split-shipping-inner:not(.showblock)").eq(0).find(".qty-wrap .rq-splittxtLabel,.cldr-wrap .rq-splittxtLabel").show(); 
				}
                if ((($(this).siblings(".split-shipping-inner").length)+1) > 1) {
                    $(this).next('.btn-wrap').remove();
                    if (($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty"))) {
                        $(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
                    }
                    $(this).remove();	
                    $(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href hoverChangeLink");
                } else {
                    $(this).next('.btn-wrap').hide();
                    if($(this).length==0){
						$(this).siblings("#split-add-more").find(".enableBtn").hide();
					}
                    $(this).siblings("#split-add-more").find(".split-add-moreLink").hide(); 
					$(this).hide();
                    $(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
					$(this).parents("tr").find(".rq-changeLink").removeClass("disable_a_href");
                }
			} else {
				$(this).addClass("nonEmpty");
                $(this).siblings("#split-add-more").find(".enableBtn").show();
                $(this).siblings("#split-add-more").find(".split-add-moreLink").show();
				$(this).parents("tr").find(".rq-changeLink").addClass("disable_a_href");
            }
		}
	});
	if($(this).parents("#split-add-more").siblings(".split-shipping-inner").hasClass("nonEmpty")){
			$(this).parents("#split-add-more").find(".enableBtn").show();
			$(this).parents("#split-add-more").siblings(".split-shipping-inner").removeClass("nonEmpty");
		}
});
$(document).on("click", ".updatedChangeLink", function() {
    $(this).addClass("hoverChangeLink");
    $(this).parents(".split-shipping-inner").find(".removeLink").removeClass("removeMore");
    if ($(this).hasClass("hoverChangeLink")) {
        $(this).parents(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").attr("disabled", true);
    }
    $(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.rq-splittxtLabel").show();
    $(this).parent(".split-ship-value").closest(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").show();
    $(this).parents(".split-shipping-inner").next(".btn-wrap").show();
    $(this).parent(".split-ship-value").siblings(".removeLink").addClass("removeMore");
    $(this).parents(".split-shipping-inner").find(".qty-wrap input,.cldr-wrap .calendar-display input").change(function() {
        if ($(this).parents(".split-shipping-inner").find(".qty-wrap input").val() != "" && $(this).parents(".split-shipping-inner").find(".cldr-wrap .calendar-display input").val() != "") {
            $(this).parents(".split-shipping-inner").next(".btn-wrap").find("button").attr("disabled", false);
        }
    });
});
/*$(document).on("click", ".removeLink.removeMore", function() {
    if ($(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length == 1) {
        $(this).prev(".primary-apply.apply_btn").hide();
    }
    $(this).parents(".split-shipping-inner").find(".qty-wrap input,.cldr-wrap input").val("");
    $(this).parents(".split-shipping-inner").removeClass("removeIcon");
    $(this).parents(".split-shipping-inner").find(".qty-wrap input").removeClass("requiredClass");
    $(this).parents(".split-shipping-inner").next(".btn-wrap").find(".apply_btn").show();
    $(this).parents(".split-shipping-inner").find(".apply_btn.enableBtn").hide();
});*/
$(document).on("click", ".afterChange", function() {
	var rqDateFormatVal = "";
			 if ($.cookie("CountryCode") === 'CN') {
				 rqDateFormatVal = "yy/mm/dd";
			 }
			 else{
				 rqDateFormatVal = "mm/dd/yy";
			 }
	$(this).parents("#rq-schedule-shipping-wrap").removeClass("requiredMsg");
	$(this).parent(".btn-wrap").prev(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function() {
    	if(!$(this).siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg") && $(this).find(".qty-wrap input").val() != "" && $(this).find(".cldr-wrap .calendar-display input").val() != ""){
        $(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
        var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());
        $(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy", jsDate)));
        $(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", jsDate));
        $(this).find(".split-ship-value a").removeClass("hoverChangeLink");
        $(this).parents("tr.changedRow").find(".custom-estimated-time .hoverChangeLink").hide();
        $(this).find(".split-ship-value").show();
        $('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("disabled",true);
		$('.checkoutShippingBilling .custom-future-date-wrap input[type=radio][name=delivery][id=DeliveryDate]').prop("checked",false);
		if ($("#mainContainer.redeemQuoteNew .calender_control.custom-future-date").is(':visible')) {
			$('#mainContainer.redeemQuoteNew .calender_control.custom-future-date').hide();
		}
    	}
    });
		var SSList = [];
		var checkEmptyFields=false;
		$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
				if($(this).find(".qty-wrap input").val() !="" && $(this).find(".cldr-wrap .calendar-display input").val() != "" && !checkEmptyFields ){
				var ssqty = $(this).find(".split-ship-value .qty").text();
				var qtydisp = $(this).find(".qty-wrap").css("display");
				var spdateval ="";
				spdateval =	 new Date($(this).find(".split-ship-value #splitShipDate").val());
				SSList.push({"qty":ssqty, "ssdate":spdateval,"qtydisp" : qtydisp  });
				}else{
					checkEmptyFields = true;
					return;
				}
		 });
		 if(!checkEmptyFields){
	SSList.sort(function (a, b) {
		var dateA = new Date(a.ssdate), dateB = new Date(b.ssdate);
		return (dateA - dateB);
	});
	$(this).parents("#rq-schedule-shipping-wrap").find(".split-shipping-inner").each(function(index) {
		$(this).find(".split-ship-value .qty").text(SSList[index].qty);	
		$(this).find(".qty-wrap input").val(SSList[index].qty);
		/*$(this).find(".qty-wrap").css('display',SSList[index].qtydisp);
		$(this).find(".cldr-wrap").css("display",SSList[index].qtydisp);
		if(SSList[index].qtydisp == "block" || SSList[index].qtydisp === "inline-block" ){$(this).find(".updatedChangeLink").addClass("hoverChangeLink");
		}else{
			$(this).find(".updatedChangeLink").removeClass("hoverChangeLink"); 	
		}*/
		$(this).find(".split-ship-value .sp-date").text(getFormatedDate($.datepicker.formatDate("mm/dd/yy",SSList[index].ssdate)));
	    $(this).find(".split-ship-value #splitShipDate").val($.datepicker.formatDate("d M yy", new Date(SSList[index].ssdate)));
		$(this).find(".cldr-wrap .calendar-display input").val($.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
		$(this).find(".cldr-wrap .calendar-display input").datepicker("setDate", $.datepicker.formatDate(rqDateFormatVal, new Date(SSList[index].ssdate)));
		});
		 }
		
});
});