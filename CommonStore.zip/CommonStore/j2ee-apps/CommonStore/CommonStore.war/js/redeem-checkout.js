var changeAddrFlag=false;
var shiptocustomerdval = false;
$(document).ready(function() {
	//on clicking Change Shipping Addresses use this address button	
      $(document).on('click', '#rcselectshipaddress', function(e) {
		changeAddrFlag=true;
        selectedshipaddr = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
        getshippAddress(selectedshipaddr);
        $("#changeshippingAddressModal  button.close").trigger('click');
    }); 
    function getshippAddress(currVal) {
		changeshipaddress = true;
		var quoteIdval = $("#quoteNumber").val();
		LSCA.loadingSpinner.showLoading();
		$('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
		$("#shipAddContainer").html("");		 
        $.ajax({
                type: "POST",
                url: "/common/myaccount/redeemQuoteShipAddrChangeSubmit.jsp?addressId=" + currVal+"&quoteId="+quoteIdval,
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changeshipAddress').show();
                $("#shipAddContainer").html(msg);
                $('#shipAddrId').val(currVal);
				$('#shipAddContainerOthers #attentionSP').val("");
                $('#shipAddContainerOthers #buildingRoomSP').val("");
                $('#shipAddContainerOthers #telephoneSP').val("");
                $('#shipAddContainerOthers #attentionSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenShipAttn').text());
                $('#shipAddContainerOthers #buildingRoomSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenbuildNo').text());
                $('#shipAddContainerOthers #telephoneSP').val($('#shipAddContainer .fullBillingAddress').find('li#hiddenPhoneNo').text());
                $(".fullBillingAddressHidden").html(msg);
                jQuery(".shipingAddressBlock-warrper .fullBillingAddressHidden").hide();
				getOrderSummaryDetails(changeshipaddress,null)	
            }).error(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }
	function getOrderSummaryDetails(cShipAddress,shiptoid){
		quoteId = $("#quoteNumber").val();
		deliveryOption = $('input[name="delivery"]:checked').val();
		upsCheck = ($("#UpsCheck").val()) ? $("#UpsCheck").val() : false;
		upsNumber = ($("#RedeemQuoteupsNumber").val()) ? $("#RedeemQuoteupsNumber").val() : "";
		fedExCheck = ($("#fedExCheck").val()) ? $("#fedExCheck").val() : false;	 
		fedExNumber = ($("#RedeemQuotefedExnumber").val()) ? $("#RedeemQuotefedExnumber").val() : "";
		quoteTotal = $("#quotationSubtotal").val();
		totalTax = $("#totalTaxValue").val();
		currencyLocale = $("#currencyLocale").val();
		shippingCheck = cShipAddress;		
		makeShippingZero = $("#makeShippingZero").val();
		if(shiptoid == null){
		selectedAddressId = $('#shippingPopUpList ul li input[name=selectShippingAddress]:checked').attr('id');
		vatCheck = ($("#vatCheck").prop('checked')) ? $("#vatCheck").prop('checked') : false;
		}else{
			selectedAddressId = shiptoid;	
		}
        $.ajax({
                type: "POST",
                url:"/common/myaccount/fetchShippingCharge.jsp?quoteId="+quoteId+"&deliveryOption="+deliveryOption+"&upsCheck="+upsCheck+"&upsNumber="+upsNumber+"&fedExCheck="+fedExCheck+"&fedExNumber="+fedExNumber+"&quoteTotal="+quoteTotal+"&totalTax="+totalTax+"&currencyLocale="+currencyLocale+"&shippingCheck="+shippingCheck+"&makeShippingZero="+makeShippingZero+"&selectedAddressId="+selectedAddressId+"&vatCheck="+vatCheck,
                dataType: "json"
            })
            .done(function(data) {
				$('#shippingVal').text(data.shippingHandlingCharge);
				$('#taxVal').text(data.redeemQuoteTaxAmount);
				$('.quoteTotalAmount').text(data.quoteTotal);
				$('#TotalTax').val(data.doubleRedeemQuoteTaxAmount);
				$('#QuotationTotal').val(data.doubleQuoteTotal);
				$('#TotalShippingCharge').val(data.doubleRedeemQuoteshippingHandlingCharge);
				LSCA.loadingSpinner.hideLoading();
            }).error(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });	
	}
	$(document).on('click', '#rcselectbilladdress', function(e) {
        selectedbilladdr = $('#shippingPopUpList ul li input[name=selectBillingAddress]:checked').attr('id');
        getbillAddress(selectedbilladdr);
        $("#changeshippingAddressModal  button.close").trigger('click');
    }); 
    function getbillAddress(currVal) {
    	var quoteIdValue = $("#quoteNumber").val();
		LSCA.loadingSpinner.showLoading();
		$('.billingAddress-wrap #custom-change-BillAddress #fullBillingAddress').remove();
		$("#billAddContainer").html("");		 
        $.ajax({
                type: "POST",
                url: "/common/myaccount/redeemQuoteBillAddrChangeSubmit.jsp?addressId=" + currVal+"&quoteId="+quoteIdValue,
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changebillAddress').show();
                $("#billAddContainer").html(msg);
                $('#billAddrId').val(currVal);
                if($("#changeInvoiceCode1").val() != '') {
					document.getElementById("invoiceCode1").value = $("#changeInvoiceCode1").val();
					$('#changeInvoiceCode1').val("");
				}
				else {
					$('#invoiceCode1').val("");
				}
				if($("#changeInvoiceCode2").val() != '') {
					document.getElementById("invoiceCode2").value = $("#changeInvoiceCode2").val();
					$('#changeInvoiceCode2').val("");
				}
				else {
					$('#invoiceCode2').val("");
				}
				if($("#changeInvoiceCode3").val() != '') {
					document.getElementById("invoiceCode3").value = $("#changeInvoiceCode3").val();
					$('#changeInvoiceCode3').val("");
				}
				else {
					$('#invoiceCode3').val("");
				}
				if($("#changeInvoiceCodeOthers").val() != '') {
					document.getElementById("invoiceCodeOthers").value = $("#changeInvoiceCodeOthers").val();
					$('#changeInvoiceCodeOthers').val("");
				}
				else {
					$('#invoiceCodeOthers').val("");
				}
				if($("#changeEanNumber").val() != '') {
					document.getElementById("eanNumber").value = $("#changeEanNumber").val();
					$('#changeEanNumber').val("");
				}	
				else {
					$('#eanNumber').val("");
				}
                LSCA.loadingSpinner.hideLoading();
            }).error(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }
    
    $(document).on('click', '#saveBillingAddr', function(e) {
    	var dovalidate = true;
        if ($('#addBillingAddr #fname').is(':visible')) {
            if ($('#addBillingAddr #fname').val() == "") {
                $('#addBillingAddr #fname').next().next().css('display', 'inline-block');
                $('#addBillingAddr #fname').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #fname').addClass('requiredTextBox');
                $('#addBillingAddr #fname').parent().parent('.formGroup').css('margin-bottom', '10px');
                dovalidate = false;
            } else {
                $('#addBillingAddr #fname').next().next().hide();
                $('#addBillingAddr #fname').prev('.fieldLabel').removeClass('requiredLabel');
                $('#addBillingAddr #fname').removeClass('requiredTextBox');
                $('#addBillingAddr #fname').parent().parent('.formGroup').css('margin-bottom', '15px');
            }
        }
        if ($('#addBillingAddr #lname').is(':visible')) {
            if ($('#addBillingAddr #lname').val() == "") {
                $('#addBillingAddr #lname').next().next().css('display', 'inline-block');
                $('#addBillingAddr #lname').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #lname').addClass('requiredTextBox');
                $('#addBillingAddr #lname').parent().parent('.formGroup').css('margin-bottom', '10px');
                dovalidate = false;
            } else {
                $('#addBillingAddr #lname').next().next().hide();
                $('#addBillingAddr #lname').prev('.fieldLabel').removeClass('requiredLabel');
                $('#addBillingAddr #lname').removeClass('requiredTextBox');
                $('#addBillingAddr #lname').parent().parent('.formGroup').css('margin-bottom', '15px');
            }
        }
        if ($('#addBillingAddr #cname').val() == "") {
            $('#addBillingAddr #cname').next().next().css('display', 'inline-block');
            $('#addBillingAddr #cname').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #cname').addClass('requiredTextBox');
            $('#addBillingAddr #cname').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #cname').next().next().hide();
            $('#addBillingAddr #cname').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #cname').removeClass('requiredTextBox');
            $('#addBillingAddr #cname').parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #stAddr').val() == "") {
            $('#addBillingAddr #stAddr').next().next().css('display', 'inline-block');
            $('#addBillingAddr #stAddr').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #stAddr').addClass('requiredTextBox');
            $('#addBillingAddr #stAddr').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #stAddr').next().next().hide();
            $('#addBillingAddr #stAddr').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #stAddr').removeClass('requiredTextBox');
            $('#addBillingAddr #stAddr').parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #city').val() == "") {
            $('#addBillingAddr #city').next().next().css('display', 'inline-block');
            $('#addBillingAddr #city').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #city').addClass('requiredTextBox');
            $('#addBillingAddr #city').parent().parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #city').next().next().hide();
            $('#addBillingAddr #city').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #city').removeClass('requiredTextBox');
            $('#addBillingAddr #city').parent().parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #zip').val() == "") {
            $('#addBillingAddr #zip').next().next().css('display', 'inline-block');
            $('#addBillingAddr #zip').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #zip').addClass('requiredTextBox');
            $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #zip').next().next().hide();
            $('#addBillingAddr #zip').next().next().next().hide();
            $('#addBillingAddr #zip').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #zip').removeClass('requiredTextBox');
            $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '15px');
        }
        if ($('#addBillingAddr #countrypopup').val() == "") {
            $('#addBillingAddr #countrypopup').next().next().css('display', 'inline-block');
            $('#addBillingAddr #countrypopup').prev('.fieldLabel').addClass('requiredLabel');
            $('#addBillingAddr #countrypopup').addClass('requiredTextBox');
            $('#addBillingAddr #countrypopup').parent('.formGroup').css('margin-bottom', '10px');
            dovalidate = false;
        } else {
            $('#addBillingAddr #countrypopup').next().next().hide();
            $('#addBillingAddr #countrypopup').prev('.fieldLabel').removeClass('requiredLabel');
            $('#addBillingAddr #countrypopup').removeClass('requiredTextBox');
            $('#addBillingAddr #countrypopup').parent('.formGroup').css('margin-bottom', '15px');
        }
        if (dovalidate) {
        formdata = $('#addBillingAddr').serialize();
        formAttrURL=$('#addBillingAddr').attr('action');
        LSCA.globalAjax.doCall({
            url : formAttrURL,
            data : formdata,
            context : $(this),
            target : $(this)
        }, function(data) {
        	var msg = data.data;
            if (msg.status == 'success') {
            $("#change-edit-shiping-modal  button.close").trigger('click');
        	$('.billingAddress-wrap #custom-change-BillAddress #fullBillingAddress').remove();
    		$("#billAddContainer").html("");
    		$.ajax({
                type: "POST",
                url: "/common/myaccount/redeemQuoteNewBillAddr.jsp",
                dataType: "html"
            })
            .done(function(msg) {
    			$('.custom-after-changebillAddress').show();
                $("#billAddContainer").html(msg);
    				$('#invoiceCode1').val("");
    				$('#invoiceCode2').val("");
    				$('#invoiceCode3').val("");
    				$('#invoiceCodeOthers').val("");
    				$('#eanNumber').val("");
    				if (!$('#addBillingAddr #billAttNew').val() == "") {
    					document.getElementById("billAttnno").value = $('#addBillingAddr #billAttNew').val();
    				}
    				if (!$('#addBillingAddr #buildRoom').val() == "") {
    					document.getElementById("billPhoneNo").value = $('#addBillingAddr #buildRoom').val();
    				}
            }).error(function() {
                console.log('Something went wrong!')
            });
        }
            else {

                $('#addBillingAddr #zip').next().next().next().css('display', 'inline-block');
                $('#addBillingAddr #zip').prev('.fieldLabel').addClass('requiredLabel');
                $('#addBillingAddr #zip').addClass('requiredTextBox');
                $('#addBillingAddr #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
            }
        });
        }
    });
    function savebillAddress() {
		
		/*$('.billingAddress-wrap #custom-change-BillAddress #fullBillingAddress').remove();
		$("#billAddContainer").html("");*/		 
        $.ajax({
                type: "POST",
                url: "/common/myaccount/ajaxAddBiliing.jsp",
                dataType: "html"
            })
            .done(function(msg) {
				$('.custom-after-changebillAddress').show();
                /*$("#billAddContainer").html(msg);
                $('#billAddrId').val(currVal);
                if($("#changeInvoiceCode1").val() != '') {
					document.getElementById("invoiceCode1").value = $("#changeInvoiceCode1").val();
					$('#changeInvoiceCode1').val("");
				}
				else {
					$('#invoiceCode1').val("");
				}
				if($("#changeInvoiceCode2").val() != '') {
					document.getElementById("invoiceCode2").value = $("#changeInvoiceCode2").val();
					$('#changeInvoiceCode2').val("");
				}
				else {
					$('#invoiceCode2').val("");
				}
				if($("#changeInvoiceCode3").val() != '') {
					document.getElementById("invoiceCode3").value = $("#changeInvoiceCode3").val();
					$('#changeInvoiceCode3').val("");
				}
				else {
					$('#invoiceCode3').val("");
				}
				if($("#changeInvoiceCodeOthers").val() != '') {
					document.getElementById("invoiceCodeOthers").value = $("#changeInvoiceCodeOthers").val();
					$('#changeInvoiceCodeOthers').val("");
				}
				else {
					$('#invoiceCodeOthers').val("");
				}
				if($("#changeEanNumber").val() != '') {
					document.getElementById("eanNumber").value = $("#changeEanNumber").val();
					$('#changeEanNumber').val("");
				}	
				else {
					$('#eanNumber').val("");
				}
*/                LSCA.loadingSpinner.hideLoading();
            }).error(function() {
                LSCA.loadingSpinner.hideLoading();
                console.log('Something went wrong!')
            });
    }

/* Drop shipment script */
var $checkboxes = $('.redeemQuoteNew #optionsRadios1');
var countUnCheckedCheckboxes = $checkboxes.filter('#optionsRadios1').length;
$checkboxes.change(function() {
    var countCheckedCheckboxes = $checkboxes.filter(':checked').length;
    if (countCheckedCheckboxes > 0) {
        $('.customDropshipWrap').css('display', 'block');
        //$("#dropShipmentCheck").val($("#optionsRadios1").val());
        $("#shipToNumber").val($("#inputShipto").val());
        $("#shiptocustomer1").show();
        $("#disabled-shiptocustomer,.shipToEntryFields .mText,#shipto-remove-msg1,#errorShipLabel").hide();
        $("#inputShipto").removeAttr("disabled", "disabled");
        $('#inputShipto').addClass('required');

    } else {
        $('.customDropshipWrap').css('display', 'none');
        $("#shiptocustomer").hide();
        $("#disabled-shiptocustomer").css('display', 'inline-block');
        $("#inputShipto").attr("disabled", "disabled");
        $('.shipToFields > label').removeClass('requiredLabel');
        $('#inputShipto').removeClass('requiredTextBox required');
    }
});           
             
$(document).on('click', '.redeemQuoteNew #shiptocustomer1', function(e) {
    e.stopPropagation();
    $('#inputShipto').attr('style', '');
    $('#inputShipto').removeClass('requiredTextBox required');
    $('.shipToEntryFields .mText').hide();
    $('.shipToFields > label').removeClass('requiredLabel');
    $('.shipToEntryFields #errorShipLabel').html('').hide();
    $('.rightaddressDiv label').removeClass('requiredLabel');
    $('.rightaddressDiv .rightMandatoryFields input').removeClass('requiredTextBox');
    $('.rightaddressDiv .rightMandatoryFields span.mText').hide();
    formdata = $('#inputShipto').val();
    /*formdata = $('#fetchshipLargeFile').serialize();                           
    var dovalidate = LSCA.GlobalValidate.init({
        target : '#inputShipto'
    });*/
    if ($('#inputShipto').val() == "") {
        $('#inputShipto').attr('style', '');
        $('#inputShipto').addClass('requiredTextBox required');
        $('.shipToEntryFields .mText').show();
        $('.shipToFields > label').addClass('requiredLabel');
        $('.shipToEntryFields #errorShipLabel').html('').hide();
    } else {
        //formtype = 'form#fetchship';
        LSCA.globalAjax.doCall({
            url: '/common/checkout/ajaxFetchShiptoIdAddressForRedeemQuote.jsp?shipToId=' + formdata,
            data: formdata,
            context: $(this),
            target: $(this)
        }, function(data) {
            var shiptocontinuemsg = data.data;
            //params_.btn = data.target;
            if (shiptocontinuemsg.status != 'success') {
                console.log('error');
                //if (shiptocontinuemsg.innerHTML.indexOf('Please enter valid ship to number.') != -1) {
                $('#inputShipto').attr('style', '');
                $('#inputShipto').addClass('requiredTextBox required');
                $('.shipToEntryFields .mText').hide();
                $('.shipToFields > label').addClass('requiredLabel');
                $('.shipToEntryFields #errorShipLabel').html(shiptocontinuemsg.innerHTML).show();
                // }
            } else {
            	shiptocustomerdval = true;
                $("#custom-change-shipAddress").hide();
                $('#inputShipto').removeClass('requiredTextBox required');
                $('.shipToFields > label').removeClass('requiredLabel');
                $('#shipto-Address').show();
                
                $("#shipAddContainer").html(shiptocontinuemsg.innerHTML);
                $("#shipto-Address").html(shiptocontinuemsg.innerHTML);
                $("#custom-change-shipAddress #customDropdown2").val($("#shipto-Address #customDropdown2").val());
                jQuery("#attentionSP").val(jQuery("#shipAttention").val());
                jQuery("#buildingRoomSP").val(jQuery("#shipBuildingNum").val());
                jQuery("#telephoneSP").val(jQuery("#contactNumber").val());
                changeshipaddress = true;
                shiptovalue = $('#inputShipto').val();
                while (shiptovalue.length < 10) {
                	shiptovalue = "0" + shiptovalue;
					length++;
				}
                getOrderSummaryDetails(changeshipaddress,shiptovalue); 
				LSCA.loadingSpinner.showLoading();
            }
        });
    }
});
$(document).on('click', '.redeemQuoteNew #lcshipto-address-remove', function(e) {
    e.preventDefault();
    shiptocustomerdval = false;
    document.getElementById("optionsRadios1").checked = false;
    $("#inputShipto").attr("disabled", "disabled");
    $("#shiptocustomer").css('display', 'none');
    $('.customDropshipWrap').css('display', 'none');
    $("#shipto-remove-msg1").css('display', 'block');
    $("#disabled-shiptocustomer").css('display', 'inline-block');
    $('#shipto-Address').hide();
    $("#shipAddContainer").html("");
    $('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
    $('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
    /*$.ajax({
            type: "POST",
            url: "/common/checkout/ajaxFetchDefaultShippingAddressForLargeFile.jsp",
            dataType: "html"
        })
        .done(function(msg) {
            $("#shipAddContainer").html(msg);
            $('.custom-after-changeshipAddress').show();
            $("#shipAddContainer").html(msg);
        })*/
	$("#custom-change-shipAddress,#custom-change-shipAddress .fullBillingAddressHidden").show();
    if(changeAddrFlag){
		$('#shipAddContainerOthers #attentionSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenShipAttn').text());
		$('#shipAddContainerOthers #buildingRoomSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenbuildNo').text());
		$('#shipAddContainerOthers #telephoneSP').val($('.fullBillingAddressHidden .fullBillingAddress').find('li#hiddenPhoneNo').text());
	}
	else{
		$('#shipAddContainerOthers #attentionSP').val($('#hiddenShipAttnVal').val());
		$('#shipAddContainerOthers #buildingRoomSP').val($('#hiddenbuildNoVal').val());
		$('#shipAddContainerOthers #telephoneSP').val($('#hiddenPhoneNoVal').val());
	}
    changeshipaddress = true;
    getOrderSummaryDetails(changeshipaddress,$('#shipAddrId').val()); 
	LSCA.loadingSpinner.showLoading();
});  
var rqarrVal=[],editableFlagVal = false,rqLength="";
$(".rq-qtytxt").each(function(){
	rqarrVal.push($(this).val());
});
$(document).on("keyup", ".redeemQuoteNew .rq-qtytxt", function(e) {
	var $this = $(this);
	//$this.val($this.val().replace(/[^\d]|^/g, ''));
	rqLength=jQuery(".redeemQuoteNew .rq-qtytxt").length;
	if(rqLength == 1){
		$this.val($this.val().replace(/[^\d]|^0/g, ''));
	}
	if ($this.val()) {
		$this.css('border-color', '#0085d5');
		$(this).prev(".rq-qtytxtLabel").removeClass("requiredLabel");
		$(this).next().removeClass("requiredLabel");
		$(this).removeClass("requiredTextBox");
		$(this).next().hide();
	} else {
		$this.css('border-color', '#D6001C');
		$(this).prev(".rq-qtytxtLabel").addClass("requiredLabel");
		$(this).next().addClass("requiredLabel");
		$(this).addClass("requiredTextBox");
		$(this).next().show();
	}
	$(this).focus(function () {
		$(this).css("border","1px solid #0085d5");
		}).blur(function () {
		$(this).css("border","1px solid #b1b3b3");
		var $tr = $(this).parents('tr');
		if ($tr.length > 0) {                    
			$tr.find('input.rq-qtytxt').val($(this).val());
		}	
		rqarrVal=[];
		$(".rq-qtytxt").each(function(){
			rqarrVal.push($(this).val());
		});	
	});
});
$(document).on("keydown", ".redeemQuoteNew .rq-qtytxt", function(e) {
	var keycode = (e.keyCode ? e.keyCode : e.which);
		if (keycode == '13') {
			e.preventDefault();
			return false;
		}
});
$(".redeemQuoteNew .rq-qtytxt").blur(function () {
	editableFlagVal=false;
	rqarrVal=[];
	var $thisVal = $(this);
	$(".rq-qtytxt").each(function(){
		rqarrVal.push($(this).val());
	});
	for(var i=0;i<rqarrVal.length;i++){		
		if(rqarrVal[i] > 0){			
			editableFlagVal=true;
		}
	}
	$(document).on("keyup", ".rq-qtytxt", function(e) {
		var $thisVal = $(this);
		if(!editableFlagVal){		
			$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
			$thisVal.css('border-color', '#D6001C');
			$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$thisVal.next().addClass("requiredLabel");
			$thisVal.addClass("requiredTextBox");
			$thisVal.next().show();
		}
		else{
			$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
			$thisVal.css('border-color', '#0085d5');
			$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$thisVal.next().removeClass("requiredLabel");
			$thisVal.removeClass("requiredTextBox");
			$thisVal.next().hide();
		}
	});
		if((!editableFlagVal) || ($thisVal.val()=="")){		
			$thisVal.val($thisVal.val().replace(/[^\d]|^0/g, ''));
			$thisVal.css('border-color', '#D6001C');
			$thisVal.prev(".rq-qtytxtLabel").addClass("requiredLabel");
			$thisVal.next().addClass("requiredLabel");
			$thisVal.addClass("requiredTextBox");
			$thisVal.next().show();
		}
		else{
			$thisVal.val($thisVal.val().replace(/[^\d]|^/g, ''));
			if($thisVal.val() == "0"){
				$thisVal.parents("tr").addClass("zeroRow");
			}
			$thisVal.css('border-color', '#b1b3b3');
			$thisVal.prev(".rq-qtytxtLabel").removeClass("requiredLabel");
			$thisVal.next().removeClass("requiredLabel");
			$thisVal.removeClass("requiredTextBox");
			$thisVal.next().hide();
		}
});

$(".rq-shipdatepicker,.rq-shipdatepickerv1,.rq-shipdatepickerv2").datepicker({        
	showOn : "button",
	buttonImage : "../images/A_Icon_Calendar_V2.svg",
	buttonImageOnly : true,
	minDate : 2,
	maxDate : '+12M'
}).attr('readonly', true);
	var rq_qty_val=0,partNoVal="",partNoValText="",splitship_sumqtyval=[];			;
	$("#chekoutItemSection .custom-item-details-wrap table tr").each(function () {
		var cal_counter=0;
		$(this).find(".split-add-moreLink").click(function(){
			cal_counter++;
			partNoValText=$(this).parents("tr").find(".product-inner .partNo").text().trim();
			var html = '',calendarval="rq-shipdatepicker"+cal_counter;
			html += '<div class="split-shipping-inner empty" data-partNo="'+partNoValText+'">';
			html += '<p class="split-ship-value"><span class="qty"></span>&nbsp;- Scheduled shipping&nbsp;<span class="sp-date"></span><a class="updatedChangeLink">Change</a></p><span class="qty-wrap"><p class="rq-splittxtLabel fieldLabel">Quantity </p><input type="text" maxlength="4"></span>';
			html += '<span class="cldr-wrap form-group calender_control custom-future-date1"><p class="rq-splittxtLabel fieldLabel">Shipping date</p><span class="calendar-display"><input placeholder="mm/dd/yyyy" value="" class="' + calendarval +'" name="' + calendarval +'" type="textbox"></span></span><span class="removeLink"><i class="far fa-minus-circle"></i></span>';
			html += '</div><div class="btn-wrap"><button class="btn-stnd-small apply_btn afterChange" id="apply_btn1" type="button" disabled>Apply</button></div>';
			$(".apply_btn.primary-apply").hide();
			$(this).siblings(".apply_btn.enableBtn").show();
			$(this).parents('#split-add-more').before(html);			
				$("."+calendarval).datepicker({        
					showOn : "button",
					buttonImage : "../images/A_Icon_Calendar_V2.svg",
					buttonImageOnly : true,
					minDate : 2,
					maxDate : '+12M'
				}).attr('readonly', true);
				
		});	
	});
});
var splitShipArr=[],firstValCounter=0,clickFlag=false;
$(document).ready(function(){
	$(".qty-wrap input").removeClass("changedQty");
	$(document).on("change",".qty-wrap input",function(){	
			firstValCounter=0;
			$(".qty-wrap input").removeClass("changedQty");
			$(this).addClass("changedQty");
			$(this).parents("tr").removeClass("changedRow").addClass("changedRow");
			var parentVal = $(this).parents("tr.changedRow").attr("data-partno");
			$(".split-shipping-inner").each(function(){
				if($(this).attr("data-partno") == parentVal){
					firstValCounter = firstValCounter + Number($(this).find(".qty-wrap input").val());
					$(this).parents("#rq-schedule-shipping-wrap").find(".hiddenval").val(firstValCounter);
					if(firstValCounter > $(this).parents("tr").attr("data-qty")){
						$(this).siblings("#split-add-more").find(".errMsgText .errMsgQty").text($(this).parents("tr").attr("data-qty"));
						$(this).siblings("#split-add-more").find(".errMsgText").show();
						$(this).siblings("#split-add-more").find(".errMsgText").addClass("requiredMsg");
						$(this).parents("tr").find(".qty-wrap input.changedQty").addClass("requiredClass");
						$(this).find(".qty-wrap .rq-splittxtLabel").addClass("requiredMsg");
						$(".split-shipping-inner.first").find(".qty-wrap .rq-splittxtLabel").addClass("requiredMsg");
					}
					else{
						if(firstValCounter == $(this).parents("tr").attr("data-qty")){
							$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
						}
						else{
							$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
						}
						$(this).siblings("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
						$(this).siblings("#split-add-more").find(".errMsgText").hide();
						$(this).parents("tr").find(".qty-wrap input.changedQty").removeClass("requiredClass");	
						$(this).find(".qty-wrap .rq-splittxtLabel").removeClass("requiredMsg");	
						$(".split-shipping-inner.first").find(".qty-wrap .rq-splittxtLabel").removeClass("requiredMsg");
					}
				}				
			});
		});
		$(".rq-changeLink:not(.hoverChangeLink)").each(function(){
			$(this).click(function(){
				$(this).addClass("hoverChangeLink");
				$(this).parents("tr").find("#rq-schedule-shipping-wrap").show();
				$(this).parents("tr").find("#rq-schedule-shipping-wrap .primary-apply").show();
				$(this).parents("tr").find("#rq-schedule-shipping-wrap .enableBtn").hide();
				
			});
		});
		$(document).on("keyup", ".qty-wrap input", function(e) {		
			$(this).val($(this).val().replace(/[^\d]|^/g, ''));
		});
		
		$(document).on("mouseover",".qty-wrap input,.calendar-display input",function(){				
			 if($(this).val()!="" && $(this).parents().siblings(".cldr-wrap").find("input").val()!=""){
				$(this).closest(".split-shipping-inner").addClass('removeIcon');
			}	
		});
		$(document).on("mouseleave",".split-shipping-inner",function(){
			$(this).removeClass('removeIcon');
		});	
		$(document).on("click",".removeLink",function(){
			if(!$(this).hasClass("removeMore")){
			$("#split-add-more").find(".errMsgText").removeClass("requiredMsg");
			$("#split-add-more").find(".errMsgText").hide();
			if($(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length == 1){
				$(this).parents(".split-shipping-inner").find(".qty-wrap input").val("");
				$(this).parents(".split-shipping-inner").find(".cldr-wrap input").val("");
				$(this).parents(".split-shipping-inner").removeClass("removeIcon");
				$(this).parents(".split-shipping-inner").find(".qty-wrap input").removeClass("requiredClass");
				$(this).parents(".split-shipping-inner").find(".apply_btn.primary-apply").show();
				$(this).parents(".split-shipping-inner").find(".apply_btn.enableBtn").hide();
			}
			else{
				$(this).parents(".split-shipping-inner").next(".btn-wrap").remove();
				$(this).parents(".split-shipping-inner").remove();
				
			}
			}
		});
		$(document).on("click",".apply_btn.primary-apply",function(){
			if((!$(this).parents(".split-shipping-inner").siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg")) && ($(this).siblings(".qty-wrap").find("input").val()!="") && ($(this).siblings(".cldr-wrap").find(".calendar-display input").val()!="")){
			$(this).siblings(".split-ship-value").find(".qty").text($(this).siblings(".qty-wrap").find("input").val());			
			var jsDate = new Date($(this).siblings(".cldr-wrap").find(".calendar-display input").val());		
			$(this).siblings(".split-ship-value").find(".sp-date").text(jsDate.getDate()+" "+$.datepicker.formatDate("MM", jsDate));
			$(this).siblings(".split-ship-value").show();
			$(this).siblings(".split-ship-value").removeClass("show").addClass("show");
			$(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
			$(".hoverChangeLink").hide();
			}
		});
	});
	$(window).on("load",function() {
			//$(".rq-changeLink.hoverChangeLink").each(function(){
			$(document).on("click",".rq-changeLink.hoverChangeLink",function(){
				$(this).addClass("hoverChangeLink");
				$(this).parents("tr").find("#rq-schedule-shipping-wrap,.split-shipping-inner.first").show();
                //$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner.first").siblings("#split-add-more").find(".enableBtn").show();
				//$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner.first").siblings("#split-add-more").find(".enableBtn").show();
				$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner.first").siblings("#split-add-more").find(".split-add-moreLink").show();								
				$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner.first .primary-apply").show();
				$(this).parents("tr").find("#rq-schedule-shipping-wrap .split-shipping-inner.first .enableBtn").hide();
				
			});
		//});
			$(document).on("click", '.apply_btn.enableBtn', function() {
				$(this).parents("#split-add-more").siblings(".split-shipping-inner").each(function(){
					if((!$(this).siblings("#split-add-more").find(".errMsgText").hasClass("requiredMsg"))&& ($(this).find(".qty-wrap input").val()!="") && ($(this).find(".cldr-wrap .calendar-display input").val()!="")){
				$(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
				var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());		
				$(this).find(".split-ship-value .sp-date").text(jsDate.getDate()+" "+$.datepicker.formatDate("MM", jsDate));
				$(this).find(".split-ship-value").show();
				$(this).find(".split-ship-value").removeClass("show").addClass("show");
				//$(this).find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
				$(this).find(".qty-wrap,.cldr-wrap").hide();
				$(".hoverChangeLink").hide();
				//$(this).siblings("#split-add-more").find(".apply_btn").hide();
				if(($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty")) && ($(this).find(".qty-wrap input").val()!="") && ($(this).find(".cldr-wrap .calendar-display input").val()!="")){
					$(this).siblings("#split-add-more").find(".apply_btn").hide();
					$(this).parents("tr").find(".rq-changeLink").hide();
					$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
					}
					else{
						$(this).parents("tr").find(".rq-changeLink").hide();
						$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
						$(this).siblings("#split-add-more").find(".apply_btn.enableBtn").hide();
					}
					}
					else{
						if($(this).find(".qty-wrap input").val()=="" && $(this).find(".cldr-wrap .calendar-display input").val()==""){							
							if(!$(this).hasClass("first")){
								$(this).next('.btn-wrap').remove();
								//$(this).siblings("#split-add-more").find(".enableBtn").hide();
								if(($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty"))){
									$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
								}					
								$(this).remove();
								$(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
							}
							else{
								$(this).next('.btn-wrap').hide();
								$(this).siblings("#split-add-more").find(".enableBtn").hide();
								//if(($(this).siblings("#split-add-more").find(".hiddenval").val() == $(this).parents("tr").attr("data-qty"))){
									$(this).siblings("#split-add-more").find(".split-add-moreLink").hide();
								//}
								//else{
									//$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
								//}
								$(this).hide();	
								$(this).parents("tr").find(".rq-changeLink").removeClass("hoverChangeLink");
							}							
						}
						else{
							$(this).siblings("#split-add-more").find(".enableBtn").show();
							$(this).siblings("#split-add-more").find(".split-add-moreLink").show();
						}
					}
				 });
				 
			});
			$(document).on("click",".updatedChangeLink",function(){
				$(this).addClass("hoverChangeLink");
				$(".removeLink").removeClass("removeMore");
				if($(this).hasClass("hoverChangeLink")){
					$(this).parents(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").attr("disabled",true);
				}
				$(this).parents(".split-shipping-inner").find(".qty-wrap,.cldr-wrap,.rq-splittxtLabel").show();
				$(this).parent(".split-ship-value").closest(".split-shipping-inner").next(".btn-wrap").find(".apply_btn.afterChange").show();
				$(this).parents(".split-shipping-inner").next(".btn-wrap").show();
				$(this).parent(".split-ship-value").siblings(".removeLink").addClass("removeMore");
				$(this).parents(".split-shipping-inner").find(".qty-wrap input,.cldr-wrap .calendar-display input").change(function() {
					if($(this).parents(".split-shipping-inner").find(".qty-wrap input").val()!="" && $(this).parents(".split-shipping-inner").find(".cldr-wrap .calendar-display input").val()!=""){
						$(this).parents(".split-shipping-inner").next(".btn-wrap").find("button").attr("disabled",false);
					}
				});
			});
				$(document).on("click",".removeLink.removeMore",function(){
					if($(this).parents("#rq-schedule-shipping-wrap").children(".split-shipping-inner").length == 1){
						$(this).prev(".primary-apply.apply_btn").hide();
					}
					$(this).parents(".split-shipping-inner").find(".qty-wrap input,.cldr-wrap input").val("");
					//$(this).parents(".split-shipping-inner").find(".cldr-wrap input").val("");
					$(this).parents(".split-shipping-inner").removeClass("removeIcon");
					$(this).parents(".split-shipping-inner").find(".qty-wrap input").removeClass("requiredClass");
					$(this).parents(".split-shipping-inner").next(".btn-wrap").find(".apply_btn").show();
					$(this).parents(".split-shipping-inner").find(".apply_btn.enableBtn").hide();
			});
			$(document).on("click",".afterChange",function(){				
				$(this).parent(".btn-wrap").prev(".split-shipping-inner").each(function(){
				$(this).find(".split-ship-value .qty").text($(this).find(".qty-wrap input").val());
				var jsDate = new Date($(this).find(".cldr-wrap .calendar-display input").val());		
				$(this).find(".split-ship-value .sp-date").text(jsDate.getDate()+" "+$.datepicker.formatDate("MM", jsDate));
				$(this).find(".split-ship-value a").removeClass("hoverChangeLink");
				$(this).find(".split-ship-value").show();
				$(this).find(".qty-wrap,.cldr-wrap,.apply_btn").hide();
				$(this).next(".btn-wrap").hide();
			});
			});
		});