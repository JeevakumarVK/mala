/*
 * @Description: This is combined control script for Agilent LCSA site.
 * @Author: Abnish Singh for HCL Agilent team.
 */
 
//************************ DO NOT MAKE ANY CHANGES BELOW ************************ //
// Avoid `console` errors in browsers that lack a console.
var maxQuantity = 999999;
var creditCardFlagVal=false,changedQtyFlagcheck=false;
(function() {
    var method;
    var noop = function noop() {
    };
    var methods = [ 'assert', 'clear', 'count', 'debug', 'dir', 'dirxml', 'error', 'exception', 'group', 'groupCollapsed', 'groupEnd', 'info', 'log', 'markTimeline', 'profile', 'profileEnd', 'table', 'time',
            'timeEnd', 'timeStamp', 'trace', 'warn' ];
    var length = methods.length;
    var console = (window.console = window.console || {});

    while (length--) {
        method = methods[length];
        // Only stub undefined methods.
        if (!console[method]) {
            console[method] = noop;
        }
    }
}());
// jQuery.noConflict();
var LSCA = {
    globalAjax : {
        // ----Global Ajax call----//
        doCall : function(config, callback) {
            config = config || {};
            config.type = config.type || 'POST';
            config.url = config.url || {};
            config.dataType = config.dataType || 'json';
            config.context = config.context || this;
            config.cache = config.cache || false;
            config.data = config.data || {};
            config.target = config.target || {};
            config.jsonpCallback = config.jsonpCallback || {};
            var configObj = {
                type : config.type,
                url : config.url,
                dataType : config.dataType,
                cache : config.cache,
                data : config.data
            };
            if (config.dataType === 'jsonp' && config.jsonpCallback != undefined) {
                configObj.jsonpCallback = config.jsonpCallback
            } else {
                config.dataType === 'json'
            }
            ;
            if (config.url != '' && config.url != 'undefined') {
                $.ajax(configObj).done(function(data) {
                    if (typeof (callback) === 'function' && callback != 'undefined')
                        callback({
                            target : config.target,
                            data : data
                        })
                }).error(function(xhr, err) {
                    console.log("Error:", err);
                    console.log("readyState: " + xhr.readyState + "\nstatus: " + xhr.status + "\nresponseText: " + xhr.responseText);
                    LSCA.loadingSpinner.hideLoading();
                });
            } else {
                return 'Call location not defined!'
            }
        }
    },
    GlobalValidate : {
        // ----Global form validation for all type of forms----//
        init : function(options_) {
            var gtg = true, flagArr = [], msgArr = [], alrtmsg = '', vclass = [ 'required', 'alpha', 'num', 'alphanum', 'chkrequired', 'selectone', 'email', 'confirm2' ];
            els = $(options_.target).map(function() {
                return $.makeArray(this.elements);
            });
            els.each(function(i) {
                for (c in vclass) {
                    if ($(els[i]).hasClass(vclass[c])) {
                        gtg = LSCA.GlobalValidate.doValidate.validate(vclass[c], $(els[i]));
                        $.each(gtg, function(i, v) {
                            if (i === 0)
                                msgArr.push(v);
                            if (i === 1)
                                flagArr.push(v);
                        })
                    }
                }
            });
            $.each(msgArr, function(i, v) {
                if (v != '')
                    alrtmsg += v.replace(/[<>\///']+/g, '') + '</br>';
            });
            if (alrtmsg != '') {
                alrtmsg = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + alrtmsg + '</div>';
                $(document).find('div.errorMessages:eq(0)').hide();
                $(document).find('div.errorMessages:eq(0)').html(alrtmsg);
                $(document).find('div.errorMessages:eq(0)').show();
                if ($(document).find('div.errorMessages:eq(0)').position()) {
                    $(document).scrollTop($(document).find('div.errorMessages:eq(0)').position().top);
                }
            }
            return ($.inArray(false, flagArr) == -1) ? true : false;
        },
        doValidate : {
            validate : function(casechk, element) {
                var chk = false, msg = element.attr('title'), rspobj = [], formval = $.trim(element.val()), label = element.attr('id');
                if (casechk === 'required') {
                    if ($.trim(formval) === '') {
                        msg = msg || 'This field is required.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        // Added for Google Analytics
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'alpha') {
                    if (/[^a-zA-Z]+$/.test(formval)) {
                        msg = msg || 'Please enter alphabets only.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'num') {
                    if (/[^0-9]+$/.test(formval)) {
                        msg = msg || 'Please enter numeric value only.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'alphanum') {
                    if (/[^a-zA-Z0-9\._-]+$/.test(formval)) {
                        msg = msg || 'Please enter alphnumrics only.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'selectone') {
                    if (formval == '' || element.val() == 0) {
                        msg = msg || 'Please select one.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'chkrequired') {
                    if (!element.attr('checked')) {
                        msg = msg || 'This field is required.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                } else if (casechk === 'email' && element.attr('id') != 'payerInvoiceEmail') {
                	if (formval != '') {
                		var mailarr = element.val(), f = true;
                		mailarr = mailarr.split(',');
                		$.each(mailarr, function(i, v) {
                			if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
                				f = false;
                		});
                		if (!f) {
                			msg = msg || 'Please enter valid email.';
                			LSCA.GlobalValidate.showError(element, '');
                			chk = false;
                			rspobj.push(msg, chk);
                			datalayerpush(label);
                		} else {
                			LSCA.GlobalValidate.hideError(element);
                			chk = true;
                			rspobj.push('', chk);
                		}
                	} else if (formval == '' || element.val() == 0) {
                		msg = 'Please enter email.';
                		LSCA.GlobalValidate.showError(element, '');
                		chk = false;
                		rspobj.push(msg, chk);
                	}
                }  else if (casechk === 'email' && element.attr('id') == 'payerInvoiceEmail') {
                	if (formval != '') {
                		var mailarr = element.val(), f = true;
                		mailarr = mailarr.split(';');
                		$.each(mailarr, function(i, v) {
                			if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
                				f = false;
                		});
                		if (!f) {
                			msg = msg || 'Please enter valid email.';
                			LSCA.GlobalValidate.showError(element, '');
                			chk = false;
                			rspobj.push(msg, chk);
                			datalayerpush(label);
                		} else {
                			LSCA.GlobalValidate.hideError(element);
                			chk = true;
                			rspobj.push('', chk);
                		}
                	} else if (formval == '' || element.val() == 0) {
                        msg = 'Please enter email.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                    }
                } else if (casechk === 'confirm2') {
                    var pass1 = element.val(), pass2 = $('.confirm1').val();
                    if (pass1 != pass2 || pass1 == '') {
                        msg = msg || 'Confirm password is not same.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    } else {
                        LSCA.GlobalValidate.hideError(element);
                        chk = true;
                        rspobj.push('', chk);
                    }
                }
                if (element.attr('minchar') != 'undefined' || element.attr('minchar') != '') {
                    if (formval.length < parseInt(element.attr('minchar'))) {
                        msg = msg || 'Please enter minimum ' + element.attr('minchar') + ' character.';
                        LSCA.GlobalValidate.showError(element, '');
                        chk = false;
                        rspobj.push(msg, chk);
                        datalayerpush(label);
                    }
                } else {
                    LSCA.GlobalValidate.hideError(element);
                    chk = true;
                    rspobj.push('', chk);
                }
                return rspobj;
            }
        },
        showErrorLMS : function(element, msg) {
            msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' + msg + '</div>';
            $(element).css('border-color', 'red');
            if (msg != '') {
                $(document).find('div.errorMessages:eq(0)').hide();
                $(document).find('div.errorMessages:eq(0)').html(msgui);
                $(document).find('div.errorMessages:eq(0)').show();
                $(document).scrollTop($(document).find('div.errorMessages:eq(0)').position('top'));
            }
        },
        showError : function(element, msg) {
            msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + msg + '</div>';
            $(element).css('border-color', '#D6001C');
            if (msg != '') {
                $(document).find('div.errorMessages:eq(0)').hide();
                $(document).find('div.errorMessages:eq(0)').html(msgui);
                $(document).find('div.errorMessages:eq(0)').show();
                $(document).scrollTop($(document).find('div.errorMessages:eq(0)').position('top'));
            }
        },
        showErrorScroll : function(element, msg, scroll) {
            msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + msg + '</div>';
            $(element).css('border-color', 'red');
            if (msg != '') {
                $(document).find('div.errorMessages:eq(0)').hide();
                $(document).find('div.errorMessages:eq(0)').html(msgui);
                $(document).find('div.errorMessages:eq(0)').show();
                if (scroll != '') {
                    $(document).scrollTop($(document).find('div.errorMessages:eq(0)').position(scroll));
                }
            }
        },
        hideError : function(element) {
            $(element).css('border-color', '');
            $(document).find('div.errorMessages:eq(0)').hide();
        }
    },
    getUrlParam : function(name) {
        var vars = [], hash;
        var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            vars.push(hash[0]);
            vars[hash[0]] = hash[1];
        }
        return vars[name];
    },
    getQueryParam : function(name) {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regexS = "[\\?&]" + name + "=([^&#]*)";
        var regex = new RegExp(regexS);
        var results = regex.exec(window.location.search);
        if (results == null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    },
    updateQueryStringParameter: function(uri, key, value) {
        var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
        var separator = uri.indexOf('?') !== -1 ? "&" : "?";
        if (uri.match(re)) {
            return uri.replace(re, '$1' + key + "=" + value + '$2');
        }
        else {
            return uri + separator + key + "=" + value;
        }
    },
    countObjArr : function(data) {
        return $.map(data, function(n, i) {
            return i;
        }).length;
    },
    showMsg : {
        init : function(params_, fn) {
            params_ = params_ || {};
            params_.key = params_.key || 'Pass message key!';
            var key = params_.key;

            if (key || key != '') {
                LSCA.globalAjax.doCall({
                    url : '/store/globalUIMessageUsingKey.jsp?messagekey=' + params_.key,
                    target : params_.target,
                    dataType : 'html'
                }, function(data) {
                    fn(data.data)
                });
            }
        }
    },
    lcaddRowQO : {
        init : function(params_) {
			$(document).on("keyup", "#addpartlc .qtyText", function(e) {
	                var $this = $(this);
	                $this.val($this.val().replace(/[^\d]|^0/g, ''));
	                if ($this.val()) {
	                    $this.css('border-color', '#B1B3B3');
	                } else {
	                    $this.css('border-color', '#D6001C');
	                }
            });
			$(document).on("keyup", "#addpartlc .partNoText", function(e) {
	                var $this = $(this);
	                $this.val($this.val().replace(/[^a-zA-Z0-9-]+/g, ''));
	                if ($this.val()) {
	                    $this.css('border-color', '#B1B3B3');
	                } else {
	                    $this.css('border-color', '#D6001C');
	                }
            });
			$(document).on("keyup", ".largefileQty", function(e) {
	                var $this = $(this);
	                $this.val($this.val().replace(/[^\d]|^0/g, ''));
	                if ($this.val()) {
	                    $this.css('border-color', '#B1B3B3');
						$(this).prev(".largefileqtyText").removeClass("requiredLabel");
						$(this).next().removeClass("requiredLabel");
						$(this).removeClass("requiredTextBox");
						$(this).next().hide();
	                } else {
	                    $this.css('border-color', '#D6001C');
						$(this).prev(".largefileqtyText").addClass("requiredLabel");
						$(this).next().addClass("requiredLabel");
						$(this).addClass("requiredTextBox");
						$(this).next().show();
	                }
            });		
            $('#addpartlc').on('submit', function(e) {
                e.preventDefault();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#addpartlc',
                    action : 'submit'
                });
				var validateFlag = true;
				jQuery(this).find(".partNoText,.qtyText").removeClass("requiredTextBox");
				if((jQuery(this).find(".partNoText").val()=="")||(jQuery(this).find(".qtyText").val()=="")){			
					if(jQuery(this).find(".partNoText").val()==""){
						jQuery(".largeFileCheckout #chekoutItemSection .errStnd.qty-errormsg").hide();
						jQuery(".largeFileCheckout #chekoutItemSection .errStnd.partno-errormsg").show();
						jQuery(this).find(".partNoText").addClass("requiredTextBox");
						jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.partno-errormsg span").text(jQuery("#addpartlc .partNoText").attr("title"));					
					}
					if(jQuery(this).find(".qtyText").val()==""){
						jQuery(".largeFileCheckout #chekoutItemSection .errStnd.partno-errormsg").hide();
						jQuery(".largeFileCheckout #chekoutItemSection .errStnd.qty-errormsg").show();
						jQuery(this).find(".qtyText").addClass("requiredTextBox");
						jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text(jQuery("#addpartlc .qtyText").attr("title"));	
					}
					if((jQuery(this).find(".partNoText").val()=="") && (jQuery(this).find(".qtyText").val()=="")){
						jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.partno-errormsg,.largeFileCheckout #chekoutItemSection  .msg-stnd.errStnd.qty-errormsg").show();
					}
					validateFlag = false;
				}
				
                valueObj = $(this).serializeArray();
                var isLargeFileUploaded = "no";
                var largeFilemaxQty = 9999;
                if (valueObj[4].value == 'hiddenLargeFileUpload') {
                    url = params_.url + '?part_number=' + (valueObj[2].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[3].value + '&isLargeFileUpload=true';
                    isLargeFileUploaded = "yes";
                } else if (valueObj[4].value == 'hiddenfileUpload') {
                    url = params_.url + '?part_number=' + (valueObj[2].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[3].value + '&isFileUpload=' + valueObj[4].value;
                } else {
                    url = params_.url + '?part_number=' + (valueObj[2].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[3].value;
                }
                if (dovalidate && isLargeFileUploaded == "no" && validateFlag) {
					LSCA.loadingSpinner.showLoading();
                    if (valueObj[3].value > 0 && valueObj[3].value < maxQuantity) {
                        if (LSCA.lcaddRowQO.iteminlist({
                            target : $(params_.target).find('tbody'),
                            data : valueObj
                        }))
                            LSCA.globalAjax.doCall({
                                url : url,
                                target : params_.target
                            }, LSCA.lcaddRowQO.parseme);
                    } else {
                        LSCA.showMsg.init({
                            key : 'validquantity'
                        }, function(data) {
                            jQuery("#addpartlc .qtyText").addClass("requiredTextBox");
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text("");
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg").show();
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text(data);
                        });
                        $(".newError").hide();
                    }
                } else if (dovalidate && isLargeFileUploaded == "yes" && validateFlag) {
					LSCA.loadingSpinner.showLoading();
                    var pPartNumber = valueObj[2].value.toUpperCase();
                    var oldQty = $('#' + pPartNumber + "-qty").val();
                    var newQty = "";
                    if (oldQty != null && oldQty > 0 && valueObj[3].value != null) {
                        var a = parseInt(oldQty);
                        var b = parseInt(valueObj[3].value);
                        newQty = a + b;
                    } else {
                        newQty = valueObj[3].value;
                    }
                    if (valueObj[3].value > 0 && newQty <= largeFilemaxQty) {
                        LSCA.globalAjax.doCall({
                            url : url,
                            target : params_.target
                        }, LSCA.lcaddRowQO.parseme);
                    } else {
                        LSCA.showMsg.init({
                            key : 'validquantity'
                        }, function(data) {
                            //LSCA.GlobalValidate.showError('', data);
							jQuery("#addpartlc .qtyText").addClass("requiredTextBox");
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text("");
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg").show();
							jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text(data);
                        });
                        $(".newError").hide();
                    }
                }
            });
        },
        parseme : function(response) {
            var data = response.data;
            var tdId = null;
            var isLargeFileUpload = $('#uploadFileButton').val();
            var qtyRow = null;
			var totalPriceLabelVal = jQuery("#totalPriceLabel").val();
			var listPriceLabelVal = jQuery("#listPriceLabel").val();
			var qtyLabelVal = jQuery("#qtyLabel").val();
			var removeLabelVal = jQuery("#removeLabel").val();
			var lcrequiredLabelVal = jQuery("#requiredLabel").val();
            if ($(document).find(response.target).length > 0 && $(response.data).length > 0 && data.status.mStatus != 500) {
                if (data.rows) {
					LSCA.loadingSpinner.hideLoading();
					jQuery(".largeCheckout .order-summary-total-section #reviewOrder").removeAttr("disabled");
					if(data.containColdShipment == true){						
						$(".largeCheckout #shipAttention #attentionLF,.largeCheckout #shipBuilding #buildingRoomLF").addClass('required');
						$('#shipAttention label span,#shipBuilding label span').removeClass('hide');
					}else{
						$(".largeCheckout #shipAttention #attentionLF,.largeCheckout #shipBuilding #buildingRoomLF").removeClass('required');
						$('#shipAttention label span,#shipBuilding label span').addClass('hide');
					}					
					if(data.showShipPhone == "true"){
						$(".largeCheckout #shipPhone").removeClass("displayNone")
						$(".largeCheckout #shipPhone #phoneNumberLF").addClass('required');
						$('.largeCheckout #shipPhone #phoneNumberLF').next().next().hide();
						$('.largeCheckout #shipPhone #phoneNumberLF').prev('.f14').removeClass('requiredLabel');
						$('.largeCheckout #shipPhone #phoneNumberLF').css('borderColor','');						
					}
					if(data.showShipPhoneJPnonReq == "true"){
						$(".largeCheckout #shipPhoneJPnonReq").removeClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq").addClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq #phoneNumberLF").removeClass('required');
					}
					if(data.showShipPhoneJPReq == "true"){
						$(".largeCheckout #shipPhoneJPnonReq").addClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq").removeClass("displayNone");
						$(".largeCheckout #shipPhoneJPReq #phoneNumberLF").addClass('required');
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').next().next().hide();
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').prev('.f14').removeClass('requiredLabel');
						$('.largeCheckout #shipPhoneJPReq #phoneNumberLF').css('borderColor','');
					}
					$(".largeCheckout #largeFileUploadTable #orderTotalVal .orderTotalValField").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table #subTotalVal").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table #orderTotalVal").text(data.updatedTotal);
					$(".largeCheckout #order-summary-table .finalItemCount").text(data.finalItemCount);
                    tdData = data.rows.mPartNumber;
                    tblrow = '<tr id="' + data.rows.mPartNumber + '">';
					tblrow += '<td><span class="largeSlno"></span><div class="pull-left"><div class="partNodetail"><a href="#">'+data.rows.mProductDescription+'</a></div><div class="partNo"><p>'+data.rows.mPartNumber+'<input type="hidden" value="'+data.rows.mPartNumber+'" name="partNumber"></p></div></div><div class="largefile-remove"><a rownumber="#" part-data="'+data.rows.mPartNumber+'">'+removeLabelVal+'</a></div></td>';
                    if (isLargeFileUpload == "hiddenLargeFileUpload") {
                        $.each(data.rows, function(i, v) {
							v = $('<div />').html(v).text();
                            if (i === 'mQty') {                            	
                                qtyRow = '<td class="text-center qty-box"><p class="largefileqtyText">'+qtyLabelVal+'</p><input type="text" class="large-file-qty largefileQty" maxlength="4" id="' + data.rows.mPartNumber + '-qty" name="'
                                        + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + v + '" /><span class="qtyErrLabel requiredText requiredLabel" style="display:none;">'+lcrequiredLabelVal+'</span></td>';
                            } 
                        });
                        if (qtyRow) {
                            tblrow += qtyRow;
                        }
                    } else if ($('#readyToUse').val() == "hiddenReadyToUse") {
						tblrow += '<td><input type="text" name="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + data.rows.mQty
                                    + '" /></td><td>'+ data.rows.mPartNumber +'</td>';
					} else {
                        $.each(data.rows, function(i, v) {
							v = $('<div />').html(v).text();
                            tblrow += (i === 'mQty') ? '<td><input type="text" name="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + v
                                    + '" /></td>' : '<td>' + v + '</td>';
							
                        });
                    }
					 tblrow += ' <td class="text-right"><div class="remFav"><span class="customListprice">'+listPriceLabelVal+'&nbsp;<span>'+data.rows.mListPrice+'</span></span><span class="totalPrice">'+totalPriceLabelVal+'&nbsp;'+data.rows.mLineItemTotal+'</span></div></td>';
					 tblrow += '</tr>';
                }
				if(data.rows.mDangerousGoodsMsg){
					jQuery(".largeCheckout .custom-future-date-wrap #consolidateRadio1").parents("li").hide();
					jQuery(".largeCheckout .lcdangerous-msg").show();
				}
                if (isLargeFileUpload == "hiddenLargeFileUpload" && $(response.target).find('#' + tdData).text() != "") {
                    $(response.target).find('#' + tdData).replaceWith(tblrow);
                } else {
					dgrow = '<tr class="dgMessageSection"><td colspan="3"><div class="msg-stnd msg-box-warning" style="align-items: center;"><i class="fal fa-exclamation-triangle"></i><span>'+data.rows.mDangerousGoodsMsg+'</span></div></td></tr>';
					$(tblrow).insertBefore("#productTable.skyblueTable tbody tr.last");
					if(data.rows.mDangerousGoodsMsg){
						$(dgrow).insertBefore($(response.target).find('#' + tdData));
					}
                }
                setTimeout(function() {
                    LSCA.doButtonRound()
                }, 200);
                $(response.target).show();
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg,.largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.partno-errormsg").hide();				
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.msg-box-success span strong").text(data.finalItemCount);
				jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg span").text(data.status.mStatusMessage);
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd,.largeFileCheckout #chekoutItemSection .msg-stnd.msg-box-success").hide();
				jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg").show();
				
				LSCA.globalAjax.doCall({
					url: '/store/includes/ajax/ajaxCheckShipOption.jsp'
				}, function(data) {
					var msg = data.data;
					if (msg.status == 'success') {
						$('#largeFileShipOprion').hide();
						$("#shipOptionEdited").html('');
                        $("#shipOptionEdited").html(msg.innerHTML);
                        $("#shipOptionEdited").show();
					}
				});
                
            } else if (data.status.mStatus === 500) {
				LSCA.loadingSpinner.hideLoading();
				jQuery(".largeFileCheckout #chekoutItemSection .addremvpart-msg").hide();
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.partno-errormsg,.largeFileCheckout #chekoutItemSection .msg-stnd.disclaimer-text,.largeFileCheckout #chekoutItemSection .msg-stnd.errStnd").hide();
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg").show();	
				jQuery(".largeFileCheckout #chekoutItemSection .msg-stnd.errStnd.qty-errormsg span").text(data.status.mStatusMessage)	
            }
             if ($(response.target).find('.skyblueTable tbody tr').length > 0) {
                LSCA.showMsg.init({
                    key : 'datalostqo'
                }, function(data) {
                    window.onbeforeunload = function() {
                        $.trim(data)
                    }
                });
            } else {
                window.onbeforeunload = null;
            }
            $('#addpartlc .partNoText').val("");
			$('#addpartlc .qtyText').val("1");
            LSCA.setPlaceHolder.init();
            ($(response.target).find('.skyblueTable tbody tr').length > 0) ? $('#promoImages').hide() : $('#promoImages').show();
        },
        iteminlist : function(options_) {
            itemrow = $(options_.target).find('tr#' + $.trim(options_.data[0].value).replace(/[<>\s()\.\///'";]+/g, ''));
            tqty = parseInt($(itemrow).find('input[type="text"]').val()) + parseInt(options_.data[1].value);
            if (itemrow.length > 0) {
                (tqty < maxQuantity) ? $(itemrow).find('input[type="text"]').val(tqty) : $(".newError").show();
                return false;
            } else {
                $(".newError").hide();
                return true;
            }
        }     
    },
    addRowQO : {
        init : function(params_) {
            $('#addpart').on('submit', function(e) {
                e.preventDefault();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#addpart',
                    action : 'submit'
                });
                valueObj = $(this).serializeArray();
                var isLargeFileUploaded = "no";
                var largeFilemaxQty = 9999;
                if (valueObj[2].value == 'hiddenLargeFileUpload') {
                    url = params_.url + '?part_number=' + (valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[1].value + '&isLargeFileUpload=true';
                    isLargeFileUploaded = "yes";
                } else if (valueObj[2].value == 'hiddenfileUpload') {
                    url = params_.url + '?part_number=' + (valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[1].value + '&isFileUpload=' + valueObj[2].value;
                } else {
                    url = params_.url + '?part_number=' + (valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '') + '&qty=' + valueObj[1].value;
                }
                if (dovalidate && isLargeFileUploaded == "no") {
                    if (valueObj[1].value > 0 && valueObj[1].value < maxQuantity) {
                        if (LSCA.addRowQO.iteminlist({
                            target : $(params_.target).find('tbody'),
                            data : valueObj
                        }))
                            LSCA.globalAjax.doCall({
                                url : url,
                                target : params_.target
                            }, LSCA.addRowQO.parseme);
                    } else {
                        LSCA.showMsg.init({
                            key : 'validquantity'
                        }, function(data) {
                            LSCA.GlobalValidate.showError('', data)
                        });
                        $(".newError").hide();
                    }
                } else if (dovalidate && isLargeFileUploaded == "yes") {
                    var pPartNumber = valueObj[0].value.toUpperCase();
                    var oldQty = $('#' + pPartNumber + "-qty").val();
                    var newQty = "";
                    if (oldQty != null && oldQty > 0 && valueObj[1].value != null) {
                        var a = parseInt(oldQty);
                        var b = parseInt(valueObj[1].value);
                        newQty = a + b;
                    } else {
                        newQty = valueObj[1].value;
                    }
                    if (valueObj[1].value > 0 && newQty <= largeFilemaxQty) {
                        LSCA.globalAjax.doCall({
                            url : url,
                            target : params_.target
                        }, LSCA.addRowQO.parseme);
                    } else {
                        LSCA.showMsg.init({
                            key : 'validquantity'
                        }, function(data) {
                            LSCA.GlobalValidate.showError('', data)
                        });
                        $(".newError").hide();
                    }
                }
            });
        },
        parseme : function(response) {
            var data = response.data;
            var tdId = null;
            var isLargeFileUpload = $('#uploadFileButton').val();
            var qtyRow = null;
            if ($(document).find(response.target).length > 0 && $(response.data).length > 0 && data.status.mStatus != 500) {
                if (data.header) {
                    if ($(response.target).find('.skyblueTable').length == 0) {
                        tblui = '<div class="errorMessages"></div><table class="skyblueTable"><thead><tr>';
                        $.each(data.header, function(i, v) {
                            tblui += '<th>' + v.replace(/[<>\s()\.\///'";]+/g, '') + '</th>';
                        });
                        tblui += '<th></th></tr></thead><tbody></tbody>';
                        tblui += '</table><div class="btnPanel text-right"><button type="submit" class="btn btn-blue">Add To Cart</button></div>';
                        $(response.target).html(tblui);
                    }
                }
                if (data.rows) {
                    tdData = data.rows.mPartNumber;
                    tblrow = '<tr id="' + data.rows.mPartNumber + '">';
                    if (isLargeFileUpload == "hiddenLargeFileUpload") {
                        $.each(data.rows, function(i, v) {
							v = $('<div />').html(v).text();
                            if (i === 'mQty') {
                            	tblrow += '<td></td>';
                                qtyRow = '<td class="qty-box"><input type="text" class="large-file-qty" maxlength="4" id="' + data.rows.mPartNumber + '-qty" name="'
                                        + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + v + '" /><input type="hidden" name="partNumber" value="' + data.rows.mPartNumber
                                        + '" /></td>';
                            } else {
                                tblrow += '<td>' + v + '</td>';
                            }
                        });
                        if (qtyRow) {
                            tblrow += qtyRow;
                        }
                    } else if ($('#readyToUse').val() == "hiddenReadyToUse") {
						tblrow += '<td><input type="text" name="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + data.rows.mQty
                                    + '" /><input type="hidden" name="partNumber" value="' + data.rows.mPartNumber + '" /></td><td>'+ data.rows.mPartNumber +'</td>';
					} else {
                        $.each(data.rows, function(i, v) {
							v = $('<div />').html(v).text();
                            tblrow += (i === 'mQty') ? '<td><input type="text" name="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" value="' + v
                                    + '" /><input type="hidden" name="partNumber" value="' + data.rows.mPartNumber + '" /></td>' : '<td>' + v + '</td>';
							
                        });
                    }
                    tblrow += ' <td><a href="javascript:void(0);" part-data="' + (data.rows.mPartNumber).replace(/[<>\s()\.\///'";]+/g, '') + '" class="remove"></a></td>';
                    tblrow += '</tr>';
                }
				
                if (isLargeFileUpload == "hiddenLargeFileUpload" && $(response.target).find('#' + tdData).text() != "") {
                    $(response.target).find('#' + tdData).replaceWith(tblrow);
                } else {
                    $(response.target).find('.skyblueTable tbody').append(tblrow);
                }
                setTimeout(function() {
                    LSCA.doButtonRound()
                }, 200);
                $(response.target).show();

                LSCA.addRowQO.showmsg({
                    status : data.status.mStatus,
                    msg : data.status.mStatusMessage,
                    target : response.target
                });
                LSCA.addRowQO.removeitem({
                    target : $(response.target).find('#' + $.trim(data.rows.mPartNumber) + " a"),
                    parenttarget : response.target
                });
            } else if (data.status.mStatus === 500) {
                LSCA.GlobalValidate.showError('', data.status.mStatusMessage);
            }
            if ($(response.target).find('.skyblueTable tbody tr').length > 0) {
                LSCA.showMsg.init({
                    key : 'datalostqo'
                }, function(data) {
                    window.onbeforeunload = function() {
                        $.trim(data)
                    }
                });
            } else {
                window.onbeforeunload = null;
            }
            $('#addpart').find("input[type=text]").val("");
            LSCA.setPlaceHolder.init();
            ($(response.target).find('.skyblueTable tbody tr').length > 0) ? $('#promoImages').hide() : $('#promoImages').show();
        },
        iteminlist : function(options_) {
            itemrow = $(options_.target).find('tr#' + $.trim(options_.data[0].value).replace(/[<>\s()\.\///'";]+/g, ''));
            tqty = parseInt($(itemrow).find('input[type="text"]').val()) + parseInt(options_.data[1].value);
            if (itemrow.length > 0) {
                (tqty < maxQuantity) ? $(itemrow).find('input[type="text"]').val(tqty) : $(".newError").show();
                return false;
            } else {
                $(".newError").hide();
                return true;
            }
        },
        removeitem : function(options_) {
            $(options_.target).on('click', function() {
                $(this).parents('tr').remove();
                itemcount = $(options_.parenttarget).find('.skyblueTable tbody tr').length;
                if (itemcount < 1) {
                    $(options_.parenttarget).hide();
                    $('#promoImages').show();
                    window.onbeforeunload = null
                }
            });
        },
        showmsg : function(options_) {
            msgui = '<div class="alert alert-dismissable alert-warning"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + options_.msg + '</div>';
            if (options_.status === 300 || options_.status === 500) {
                $(options_.target).find('.errorMessages').html(msgui).show();
            } else {
                $(options_.target).find('.errorMessages').hide();
            }
        }
    },
    toolTipFly : {
        init : function(params_) {
            $(params_.target).hover(function() {
                $(params_.selector).hide();
                $(params_.selector, this).show();
            })
        }
    },
    showMyCatalogList : {
        init : function(params_) {
            if ($(document).find('#mainContainer').hasClass(params_.pageid)) {
                $(params_.target).find("button.custom-addcontactcancel").on('click', function(e) {
                    e.preventDefault();
                    LSCA.globalAjax.doCall({
                        url : params_.url + $(this).attr('list-id'),
                        dataType : 'html',
                        target : $(this)
                    }, function(data) {
                        LSCA.showMyCatalogList.showList(data, function() {
                            LSCA.globalPaginate.init({
                                prevnext : true
                            });
                            if (params_.callback && typeof (params_.callback) === 'function')
                                params_.callback(params_);
                        });
                    });
                });
            }
        },
        showList : function(params_, callback) {
            // Implement right column ajax view
        }
    },
    removeMyCatalogList : {
        init : function(params_) {
            $("#delete-catalog").on('click', function(e) {
                e.preventDefault();
                if (confirm($('#lblConfirmDelete').val())) {
                    var deleteID = $("#catlogListView .secondary-catalogList.active").attr('id');
                    LSCA.loadingSpinner.showLoading();
                    LSCA.globalAjax.doCall({
                        url : params_.url + deleteID,
                        target : params_.target
                    }, function(response) {
                        LSCA.removeMyCatalogList.removeList(response, function() {
                            if (params_.callback && typeof (params_.callback) === 'function')
                                params_.callback(params_);
                        });
                    });
                }
            });
        },
        removeList : function(response, callback) {
            $('#error-emptyCart,#error-messages').hide();
            if (response.data.status == 'success') {
                LSCA.loadingSpinner.hideLoading();
                $("#catlogListView .secondary-catalogList.active,.myOrderStatuss .favListEdit1 input").remove();
                $(".myOrderStatuss .giftList-Heading").css("display","inline-block");
				jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                $("#catlogListView .default-Catlog").addClass('active');
                $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
                if ($("#catlogListView .secondary-catalogList.active").length == 0) {
                    $("#empty-catalog").hide();
                }
                LSCA.catalogListTable.init({
                    pageid : 'viewMyCatalog',
                    url : '/common/myaccount/getCatalogListItems.jsp?listId=' + $("#default-favorites").val(),
                    target : '#viewCatalog'
                });
            } else {
                LSCA.loadingSpinner.hideLoading();
                LSCA.GlobalValidate.showError('', data.message);
            }
        }
    },
    // Remove item row
    removeRowItem : {
        init : function(params_) {
            if ($(document).find('#mainContainer').hasClass(params_.pageid)) {
                $(document).on("click", "a.remove", function(e) {
                    e.preventDefault();
                    LSCA.loadingSpinner.showLoading();
                    LSCA.globalAjax.doCall({
                        url : params_.url + $(this).attr('part-data') + '&giftlistId=' + $("#catlogListView li.active").attr('id'),
                        dataType : 'html',
                        target : $(this)
                    }, function(data) {
                        LSCA.removeRowItem.removeItem(data, function() {
                            LSCA.mycatalogaddPaging.makePageNav(params_, function(params_) {
                                LSCA.mycatalogaddPaging.pageData(params_)
                            });
                            if ($(document).find('#mainContainer').hasClass(params_.pageid) != "viewMyCatalog") {
                                // Do Nothing
                            }
                            if (params_.callback && typeof (params_.callback) === 'function')
                                params_.callback(params_);
                        });
                    });
                });
            }
        },
        removeItem : function(params_, callback) {
            LSCA.loadingSpinner.hideLoading();
            $(params_.target).parents('tr').remove();
            if ($(params_.target)[0].className == 'remove') {
                if ($('#viewCatalog table tbody tr').length > 5) {
                    if ($('#viewCatalog table tbody tr:visible').length == 0) {
                        $('a.prev').trigger('click');
                    }
                } else {
                    $('#viewCatalog table').attr('data-pagenum', '1');
                    $('#viewCatalog table tbody tr').show();
                }
            }
            if ($('#viewCatalog table tbody tr').length == 0) {
                $('.errorText').text($('#lblEmptyCatalog').val());
                $('#error-emptyCart').show();
                $('.emailBlk,.printBlk').hide();
            } else {
                $('.emailBlk').show();
            }
            if (callback && typeof (callback) === 'function')
                callback();
        }
    },
    globalPaginate : {
        init : function(params_) {
            params_ = params_ || [];
            $(".global-paginate").each(function() {
                params_.context = $(this);
                LSCA.globalPaginate.addaction.call(this, params_);
            })
        },
        addaction : function(params_) {
            var $this = $(this), $table = $this.find('.pageme'), limit = parseInt($table.attr('data-limit')) || 10, trow = $table.find('tbody:eq(0) > tr'), prevnext = params_.prevnext || false, nums = '', pagecnt = Math
                    .ceil(trow.length / limit), currpage = parseInt($table.attr('data-pagenum')) || 1;
            if (lableObject != undefined) {
                var prev = lableObject['prev'], next = lableObject['next'];
            }
            if ($table.attr('data-pagenum') == undefined) {
                $table.attr('data-pagenum', 1)
            }
            var hrefValue = $table[0].id ? "#" + $table[0].id : "#";
            if (pagecnt > 1) {
                if (currpage !== 1) {
                    if ($table.find('tbody > tr:visible').length < 1) {
                        findex = (currpage * limit) - (limit * 2), lindex = findex + limit - 1;
                        if (currpage > 1) {
                            $table.attr('data-pagenum', currpage - 1);
                            LSCA.globalPaginate.paginate($table, trow, findex, lindex, currpage - 1);
                        }
                    }
                } else {
                    trow.hide();
                    trow.each(function(i, v) {
                        $(this).show();
                        if (i == limit - 1)
                            return false;
                    });
                }
                if (!prevnext) {
                    for (i = 0; i < pagecnt; i++) {
                        nums += (currpage === i + 1) ? '<li><span class="gray">' + (i + 1) + '</span></li>' : '<li><a href="#">' + (i + 1) + '</a></li>';
                    }
                } else {
                    nums += '<li><a class="rScr" href="' + hrefValue + '">' + next + ' &gt;</a></li><li><a class="lScr" href="' + hrefValue + '">&lt; ' + prev + '</a></li>';
                }
            } else {
                $table.attr('data-pagenum', pagecnt);
                trow.show();
                if (!prevnext)
                    nums += '<li><span class="gray">' + (i + 1) + '</span></li>';
            }
            $this.find('ul.lrScr').html(nums);

            setTimeout(function() {
                $this.find('ul.lrScr > li a').on('click', function(e) {
                    var findex = 0, lindex = 0;
                    e.preventDefault();
                    currpage = parseInt($table.attr('data-pagenum'));
                    var scrollVal, target = $($(this).attr('href'));
                    if (target.length) {
                        scrollVal = target.offset().top - 100;
                        if (scrollVal && scrollVal > 0) {
                            $('html, body').animate({
                                scrollTop : scrollVal
                            }, "linear");
                        }
                    }
                    if ($(this).hasClass('rScr') || parseInt($(this).text()) > currpage) {
                        findex = currpage * limit, lindex = (findex + limit) - 1, pageindex = currpage + 1;
                        if (currpage < pagecnt) {
                            LSCA.globalPaginate.paginate($table, trow, findex, lindex, pageindex);
                        }
                    } else {
                        findex = (currpage * limit) - (limit * 2), lindex = findex + limit - 1, pageindex = currpage - 1;
                        if (currpage > 1) {
                            LSCA.globalPaginate.paginate($table, trow, findex, lindex, pageindex);
                        }
                    }
                })
            }, 50);
        },
        paginate : function($table, data, fIndex, lIndex, pageindex) {
            data.hide();
            $table.attr('data-pagenum', pageindex);
            data.each(function(i, v) {
                if (i >= fIndex)
                    $(this).show();
                if (i == lIndex)
                    return false;
            });
        }
    },
    globalPaginateWithYourPrice : {
        init : function(params_) {
            params_ = params_ || [];
            $(".global-paginate-your-price").each(function() {
                params_.context = $(this);
                LSCA.globalPaginateWithYourPrice.addaction.call(this, params_);
            })
        },
        addaction : function(params_) {
            var $this = $(this), $table = $this.find('.pageme'), limit = parseInt($table.attr('data-limit')) || 10, trow = $table.find('tbody:eq(0) > tr'), prevnext = params_.prevnext || false, nums = '', pagecnt = Math
                    .ceil(trow.length / limit), currpage = parseInt($table.attr('data-pagenum')) || 1;
            if (lableObject != undefined) {
                var prev = lableObject['prev'], next = lableObject['next'];
            }
            if ($table.attr('data-pagenum') == undefined) {
                $table.attr('data-pagenum', 1)
            }
            var hrefValue = $table[0].id ? "#" + $table[0].id : "#";
            if (pagecnt > 1) {
                if (currpage !== 1) {
                    if ($table.find('tbody > tr:visible').length < 1) {
                        findex = (currpage * limit) - (limit * 2), lindex = findex + limit - 1;
                        if (currpage > 1) {
                            $table.attr('data-pagenum', currpage - 1);
                            LSCA.globalPaginateWithYourPrice.paginate($table, trow, findex, lindex, currpage - 1);
                        }
                    }
                } else {
                    trow.hide();
                    trow.each(function(i, v) {
                        $(this).show();
                        if (i == limit - 1)
                            return false;
                    });
                    LSCA.globalPaginateWithYourPrice.callYourPrice(params_, trow, 0, limit - 1);
                }
                if (!prevnext) {
                    for (i = 0; i < pagecnt; i++) {
                        nums += (currpage === i + 1) ? '<li><span class="gray">' + (i + 1) + '</span></li>' : '<li><a href="#">' + (i + 1) + '</a></li>';
                    }
                } else {
                    nums += '<li><a class="rScr" href="' + hrefValue + '">' + next + ' &gt;</a></li><li><a class="lScr" href="' + hrefValue + '">&lt; ' + prev + '</a></li>';
                }
            } else {
                $table.attr('data-pagenum', pagecnt);
                trow.show();
                LSCA.globalPaginateWithYourPrice.callYourPrice(params_, trow, 0, trow.length - 1);
                if (!prevnext)
                    nums += '<li><span class="gray">' + (i + 1) + '</span></li>';
            }
            $this.find('ul.lrScr').html(nums);
            setTimeout(function() {
                $this.find('ul.lrScr > li a').on('click', function(e) {
                    var findex = 0, lindex = 0;
                    e.preventDefault();
                    currpage = parseInt($table.attr('data-pagenum'));
                    var scrollVal, target = $($(this).attr('href'));
                    if (target.length) {
                        scrollVal = target.offset().top - 100;
                        if (scrollVal && scrollVal > 0) {
                            $('html, body').animate({
                                scrollTop : scrollVal
                            }, "linear");
                        }
                    }
                    if ($(this).hasClass('rScr') || parseInt($(this).text()) > currpage) {
                        findex = currpage * limit, lindex = (findex + limit) - 1, pageindex = currpage + 1;
                        if (currpage < pagecnt) {
                            LSCA.globalPaginateWithYourPrice.paginate($table, trow, findex, lindex, pageindex);
                            LSCA.globalPaginateWithYourPrice.callYourPrice(params_, trow, findex, lindex);
                        }
                    } else {
                        findex = (currpage * limit) - (limit * 2), lindex = findex + limit - 1, pageindex = currpage - 1;
                        if (currpage > 1) {
                            LSCA.globalPaginateWithYourPrice.paginate($table, trow, findex, lindex, pageindex);
                            LSCA.globalPaginateWithYourPrice.callYourPrice(params_, trow, findex, lindex);
                        }
                    }
                })
            }, 50);
        },
        paginate : function($table, data, fIndex, lIndex, pageindex) {
            data.hide();
            $table.attr('data-pagenum', pageindex);
            data.each(function(i, v) {
                if (i >= fIndex)
                    $(this).show();
                if (i == lIndex)
                    return false;
            });
        },
        callYourPrice : function(params, data, fIndex, lIndex) {
            var partNoArray = [];
            data.each(function(i, v) {
            	if (i >= fIndex && $(this).find('#partNumberRef').val()) {
                    partNoArray.push($(this).find('#partNumberRef').val());
                }
                if (i == lIndex)
                    return false;
            });
            if (partNoArray && partNoArray.length > 0) {
                LSCA.displayYourPriceList.init({
                    pageid : params.pageid,
                    url : params.url + partNoArray.join(),
                    target : params.target
                });
            }
        }
    },
    changeCatalogAddItem : {
        init : function(params_) {
            $(document).on("click","li.giftListItem",function(e) {
                e.preventDefault();
                LSCA.loadingSpinner.showLoading();
				var designIdArrVal=[];
				jQuery(this).parents(".cartItem-section").find(".cartItemDesign").each(function(){
					if(jQuery(this).hasClass("cartItemDesignSelect")){						
						if(jQuery(this).val() != "" && jQuery(this).val() != undefined){
						designIdArrVal.push(jQuery(this).val().split(":")[1]);
						}
					}
					else{						
						if(jQuery(this).val() != "" && jQuery(this).val() != undefined){
							designIdArrVal.push(jQuery(this).val().split(" ")[0]);
						}
					}					
				});
                $(".giftListView li").removeClass('active');
                $(this).addClass('active');
                $('#tooltip_' + $(this).parent().attr('part-data')).hide();
				if($('#mainContainer > .container').hasClass('myOrderStatuss')){
                $('#success_' + $(this).parent().attr('part-data') + ' .giftListText').html('<a class=mycatalogLink href=/common/myaccount/viewMyCatalog.jsp?listId=' + $(this).attr('id') + '>' + $(this).text() + '</a>');					
				}else{
                $('#success_' + $(this).parent().attr('part-data') + ' .giftListText').html('<a class=mycatalogLink href=/common/myaccount/viewMyCatalog.jsp?listId=' + $(this).attr('id') + '>' + $(this).text() + '</a>');					
				}

                $('#list_' + $("#selected_partNo").val() + ' .upArrow').hide();
                $('#list_' + $("#selected_partNo").val() + ' .downArrow').show();
                $(".giftListView li").removeClass('active');
                if (designIdArrVal && designIdArrVal.length > 0) {					
					LSCA.globalAjax.doCall({
						url : params_.url + 'giftlistId=' + $(this).attr('id') + '&part_number=' + $("#selected_partNo").val() + '&designIds=' + designIdArrVal.join(),
						target : params_.target                
					}, function(response) {
                    LSCA.changeCatalogAddItem.parseme(response, function() {
                        LSCA.globalPaginate.init({
                            prevnext : false
                        });
                    });
                });
				designIdArrVal="";
				}
				else{	
					var selectedpartNo = '';
					if(($("#selected_partNo").val()).substring(1,0) == 's'){
						selectedpartNo = ($("#selected_partNo").val()).substring(4)
					}else{
						selectedpartNo = $("#selected_partNo").val()
					}					
					designIdArrVal="";
					LSCA.globalAjax.doCall({					
                    url : params_.url + 'giftlistId=' + $(this).attr('id') + '&part_number=' + selectedpartNo,
					target : params_.target                
					}, function(response) {
						LSCA.changeCatalogAddItem.parseme(response, function() {
							LSCA.globalPaginate.init({
								prevnext : false
							});
						});
					});
				}
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data.errorMessage != '') {
                LSCA.loadingSpinner.hideLoading();
				$('#success_' + $("#selected_partNo").val()).removeClass('successCatalogTooltip');
				$('#success_' + $("#selected_partNo").val()).addClass('errorCatalogTooltip');
                $('#success_' + $("#selected_partNo").val() + ' .successText').addClass('serviceErrorMsg');
				$('#success_' + $("#selected_partNo").val() + ' .successText i').removeClass('fa-check-circle');
				$('#success_' + $("#selected_partNo").val() + ' .successText i').addClass('fa-exclamation-circle');
                $('#success_' + $("#selected_partNo").val() + ' .successText span').html(data.errorMessage);
                //$('#success_' + $("#selected_partNo").val()).show();
				$('#success_' + $("#selected_partNo").val()).css('display','flex');
                setTimeout(function() {
                    $('#success_' + $("#selected_partNo").val()).hide();
                }, 7000);
            } else if (data.showSuccessMessage) {
                LSCA.loadingSpinner.hideLoading();
                $('#greyStar_' + $("#selected_partNo").val()).hide();
                $('#ylwStar_' + $("#selected_partNo").val()).show();
                setTimeout(function() {
                    $("#myCatalogModal button.close").trigger('click');
                    $("#myCatalogModalCart .close").trigger('click');
                }, 0);
                $('#success_' + $("#selected_partNo").val() + ' .successText').removeClass('serviceErrorMsg');
                /*$('body').append('<style>.successCatalogTooltip::after{top:-38%;}</style>');
                if ($('#success_' + $("#selected_partNo").val()).outerHeight() > 50) {
                    $('body').append('<style>.successCatalogTooltip::after{top:-28%;}</style>');
                }*/
               // $('#success_' + $("#selected_partNo").val()).show();
				$('#success_' + $("#selected_partNo").val()).css('display','flex');
                setTimeout(function() {
                    $('#success_' + $("#selected_partNo").val()).hide();
                }, 7000);
            }
        }
    },
    favoriteUpdateItem : {
        init : function(params_) {
            if ($(document).find('#mainContainer').hasClass(params_.pageid)) {
                $(params_.target).find(".addtoFavDiv").on("click", function() {
                    if ($("#loginStatus").val() == "false") {
                        if ($('.successCatalogTooltip').is(':visible')) {
                            $('.successCatalogTooltip').hide();
                        }
                        var Selected_partNumber = $(this).attr('part-data');
                        $("#selected_partNo").val(Selected_partNumber);
                        $('div.catalogTooltip:not(#tooltip_' + Selected_partNumber + ')').hide();
                        $('div.addtoFavDiv:not(#list_' + Selected_partNumber + ')').find(".upArrow").hide();
                        $('div.addtoFavDiv:not(#list_' + Selected_partNumber + ')').find(".downArrow").show();
                        $('#tooltip_' + $("#selected_partNo").val() + ' ul.giftListView').html('<li class="tbl-loading"></li>');
                        $('#tooltip_' + Selected_partNumber).toggle();
                        $('#list_' + Selected_partNumber).find(".upArrow, .downArrow").toggle();
                        LSCA.viewDropdownCatalogList.init({
                            pageid : 'cartPage',
                            url : '/common/myaccount/getMyCatalogLists.jsp',
                            target : '#giftListView'
                        });
                    }
                    if ($("#loginStatus").val() == "true") {
                        //$(".newAlert").show();
						var Selected_partNumber = params_.partData;
                        $("#selected_partNo").val(Selected_partNumber);
						$('.errorCatalogTooltip.loginError').hide();
						//$('#loginError_' + $("#selected_partNo").val()).show();
						$('#loginError_' + $("#selected_partNo").val()).css('display','flex');
						setTimeout(function() {
							$('#loginError_'+ $("#selected_partNo").val()).hide();
						}, 7000);
                    }
                });
            }
        }
    },favoriteShoppingUpdateItem : {
        init : function(params_) {
            if ($(document).find('#mainContainer').hasClass(params_.pageid)) {
            	
                    if ($("#loginStatus").val() == "false") {
                        if ($('.successCatalogTooltip').is(':visible')) {
                            $('.successCatalogTooltip').hide();
                        }
						console.log($(".newAlert").attr('id'));
						
                        var Selected_partNumber = params_.partData;
                        $("#selected_partNo").val(Selected_partNumber);
                        $('div.catalogTooltip:not(#tooltip_' + Selected_partNumber + ')').hide();
                        $('div.addtoFavDiv:not(#list_' + Selected_partNumber + ')').find(".upArrow").hide();
                        $('div.addtoFavDiv:not(#list_' + Selected_partNumber + ')').find(".downArrow").show();
                        $('#tooltip_' + $("#selected_partNo").val() + ' ul.giftListView').html('<li class="tbl-loading"></li>');
                        $('#tooltip_' + Selected_partNumber).toggle();
                        $(".addtoFavDiv").removeClass("custlogerror");
                        $('#list_' + Selected_partNumber).find(".upArrow, .downArrow").toggle();
                        LSCA.viewDropdownCatalogList.init({
                            pageid : 'cartPage',
                            url : '/common/myaccount/getMyCatalogLists.jsp',
                            target : '#giftListView'
                        });
                    }
                    if ($("#loginStatus").val() == "true") {
                    	$(".addtoFavDiv").addClass("custlogerror");
						/*$(".newAlert").parent().removeClass('ng-hide');
                        $(".newAlert").show();*/
						var Selected_partNumber = params_.partData;
                        $("#selected_partNo").val(Selected_partNumber);
						$('.errorCatalogTooltip.loginError').hide();
						//$('#loginError_' + $("#selected_partNo").val()).show();
						$('#loginError_' + $("#selected_partNo").val()).css('display','flex');
						setTimeout(function() {
							$('#loginError_'+ $("#selected_partNo").val()).hide();
						}, 7000);
                    }
            	
            }
        }
    },
    changeBillingAddress : {
        init : function(params_) {
            $(document).on("change", "#customDropdown1", function(e) {
                e.preventDefault();
                LSCA.loadingSpinner.showLoading();
                LSCA.globalAjax.doCall({
                    url : params_.url + $('#customDropdown1').val() + '&contactIdMismtach=' + $('#contactIdMismtach').val(),
                    target : params_.target
                }, function(response) {
                    LSCA.changeBillingAddress.parseme(response, function() {
                        if (params_.callback && typeof (params_.callback) === 'function')
                            params_.callback(params_);
                    });
                });
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data) {
                LSCA.loadingSpinner.hideLoading();
                $('#billingAddressSection').html(data.innerHTML);
                $('#cyberSourcePaymentForm').html(data.cyberSourceForm);
                $('#invoiceCode1').val(data.invoiceCode1);
                $('#invoiceCode2').val(data.invoiceCode2);
                $('#invoiceCode3').val(data.invoiceCode3);
                $('#invoiceCodeOthers').val(data.invoiceCodeOthers);
                $('#billingAddressSection').show();
                $('#editBillingAddressLink').show();
                $('#editBillAddressSec').hide();
            }
        }
    },
    changeShippingAddress : {
        init : function(params_) {
            $(document).on("change", "#customDropdown2", function(e) {
                e.preventDefault();
                LSCA.loadingSpinner.showLoading();
                LSCA.globalAjax.doCall({
                    url : params_.url + $('#customDropdown2').val() + '&contactIdMismtach=' + $('#contactIdMismtach').val(),
                    target : params_.target
                }, function(response) {
                    LSCA.changeShippingAddress.parseme(response, function() {
                        LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
                    });
                });
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data) {
                LSCA.loadingSpinner.hideLoading();
                $('#shippingAddressSection').html(data.innerHTML);
                $('#buildingRoomLF,#buildingRoomSP').val(data.buildroomno);
                $('#attentionLF,#attentionSP').val(data.attention);
                $('#phoneNumberLF,#telephoneSP').val(data.phonenumber);
                $('#shippingAddressSection').show();
                $('#editShippingAddressLink').show();
                $('#editShipAddressSec').hide();
                callback();
            }
        }
    },
    RadioShowHide : {
        init : function(params_) {
            if ($(params_.targetEl).attr(params_.elAttr) === 'checked') {
                params_.toggleClass.hide();
                params_.button.show();
            }
            if ($(params_.targetE2).attr(params_.e2Attr) === 'checked') {
                params_.toggleClass.show();
                params_.button.hide();
            }
        },
        ShowHide : function(option_) {
            option_ = option_ || {};
            option_.selector = option_.selector || {};
            option_.target = option_.target || {};
            option_.selector.change(function() {
                if ($(this).val() === 'true') {
                    option_.target.show();
                    option_.button.hide();
                } else {
                    option_.target.hide();
                    option_.button.show();
                }
            });
        }
    },
    viewCatalogList : {
        init : function(params_) {
            if ($(document).find('.mainContainer').hasClass(params_.pageid)) {
                LSCA.loadingSpinner.showLoading();
                var addtocartUrl = window.location.href;
                var addtocartListIndex = addtocartUrl.indexOf('listId');
                var addtocartGiftId = LSCA.getUrlParam('listId');
                LSCA.globalAjax.doCall({
                    url : params_.url,
                    target : params_.target
                }, function(response) {
                    LSCA.viewCatalogList.showCatalogList(response, function() {
                        if (addtocartListIndex == -1) {
                            $('#addToCartCheck').val('0');
                            LSCA.catalogListTable.init({
                                pageid : 'viewMyCatalog',
                                url : '/common/myaccount/getCatalogListItems.jsp?listId=' + $("#default-listId").val(),
                                target : '#viewCatalog'
                            });
                        } else {
                            $('#addToCartCheck').val('1');
                            $('#' + addtocartGiftId).trigger('click');
                        }
                    });
                    if (params_.callback && typeof (params_.callback) === 'function')
                        params_.callback(params_);
                });
            }
        },
        showCatalogList : function(response, callback) {
            var data = response.data;
            var liList = '';
            var defaultCatalogId = '';
			var selectedFlag = false;
			var defaultFavoritesId = '';
            if (data) {
                LSCA.loadingSpinner.hideLoading();
                var len = data.length;
                if (len > 0) {
                    for (var i = 0; i < len; i++) {
                    	if(data[i].errorMessage == undefined || data[i].errorMessage== null || data[i].errorMessage == ""){
	                        if (data[i].defaultFlag && (data[i].selectedFlag !== undefined && data[i].selectedFlag)) {
	                            liList += '<li id="' + data[i].id + '" class="active default-Catlog">' + data[i].name + '<i id="default-' + data[i].id + '" class="default-catlog" aria-hidden="true"></i></li>';
	                            defaultCatalogId = data[i].id;
								defaultFavoritesId = data[i].id;
	                        } else if (data[i].defaultFlag) {
	                            liList += '<li id="' + data[i].id + '" class="default-Catlog">' + data[i].name + '<i id="default-' + data[i].id + '" class="default-catlog" aria-hidden="true"></i></li>';
	                            defaultFavoritesId = data[i].id;
	                        } else if(data[i].selectedFlag !== undefined && data[i].selectedFlag) {
	                            liList += '<li id="' + data[i].id + '" class="active secondary-catalogList">' + data[i].name + '<i id="edit-' + data[i].id
	                                    + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true"></i></li>';
								defaultCatalogId = data[i].id;
								selectedFlag = true;
	                        } else {
	                            liList += '<li id="' + data[i].id + '" class="secondary-catalogList">' + data[i].name + '<i id="edit-' + data[i].id
	                                    + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true"></i></li>';
	                        }
                    	} else {
                    		LSCA.GlobalValidate.showError('', data[i].errorMessage);
                    	}
                    }
                    $("#default-listId").val(defaultCatalogId);
					$("#default-favorites").val(defaultFavoritesId);
                    $("a#emailCatalog-link").attr('href', '/common/myaccount/emailMyCatalog.jsp?giftId=' + $("#default-listId").val());
					if($('#mainContainer > .container').hasClass('myOrderStatuss')){
						$("#cartErrorUrl").val('/common/myaccount/viewMyCatalog.jsp?listId=' + $("#default-listId").val());
					}else{
						$("#cartErrorUrl").val('/common/myaccount/viewMyCatalog.jsp?listId=' + $("#default-listId").val());
					}
                    

                    $(response.target).find('#catlogListView').html(liList);
                    $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
					if(selectedFlag){
						$("#empty-catalog").show();
						$('.printBlk').css('border-right', '1px solid #D0D0CE');
						$('.printBlk').css('padding-right', '');
					} else {
						$('.printBlk').css('border-right', '0px');
						$('.printBlk').css('padding-right', '0px');
					}
                    if (data.errorMessage)
                        LSCA.GlobalValidate.showError('', data.errorMessage);
                    if (callback && typeof (callback) == 'function')
                        callback();
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
            }
        }
    },
    viewDropdownCatalogList : {
        init : function(params_) {
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.viewDropdownCatalogList.showDropdownCatalogList(response, function() {
                    if (params_.callback && typeof (params_.callback) === 'function')
                        params_.callback(params_);
                });
            });
        },
        showDropdownCatalogList : function(response, callback) {
            var data = response.data;
            var valui = "";
            if (data) {
                $(data).each(function(i, v) {
                    valui += '<li id=' + v.id + ' class="giftListItem">' + v.name + '</li>';
                });
                $('#tooltip_' + $("#selected_partNo").val() + ' ul.giftListView').html(valui);
            }
        }
    },
    catalogListTable : {
        init : function(params_) {
            LSCA.loadingSpinner.showLoading();
            $(params_.target).find('table').attr('data-pagenum', '1');
			var activeItem = $('#catlogListView li.active');
			if ($(activeItem).attr('class').split(' ')[0] == "default-Catlog") {
				$('.printBlk').css('border-right', '0px');
				$('.printBlk').css('padding-right', '0px');
			}
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.catalogListTable.parseme(response, function() {
                    LSCA.mycatalogaddPaging.makePageNav(params_, function(params_) {
                        LSCA.mycatalogaddPaging.pageData(params_)
                    });
                });
                if (params_.callback && typeof (params_.callback) === 'function')
                    params_.callback(params_);
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            var listNoVal="";
            jQuery(".myOrderStatuss .favListEdit1 i").css("display","inline-block");            
            if(jQuery(".myOrderStatuss #catlogListView .default-Catlog").hasClass("active")){
				jQuery(".myOrderStatuss .favListEdit1 i").hide();
			}
			else{				
				jQuery(".myOrderStatuss .favListEdit1 i").css("display","inline-block");
			}
            $(".myOrderStatuss #catlogListView .default-Catlog i").removeClass('active');
            $(".favListEdit1 i").attr("id",$('#catlogListView li.secondary-catalogList.active i').attr("id"));
			$(".favListEdit1").attr("id",$('#catlogListView li.secondary-catalogList.active').attr("id"));
			listNoVal=jQuery(".giftList-Heading").text().trim();
			$('#viewCatalog input[name=listNameVal]').val(listNoVal);
            if (data) {
                LSCA.loadingSpinner.hideLoading();
                var len = data.length;
                if ($(response.target).find('.skyblueTable').length == 0) {
                    tblui = '<table class="skyblueTable">';
                    tblui += '<tbody></tbody>';
                    tblui += '</table>';
                    $(response.target).html(tblui);
                }
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        tblrow = '<tr id=tbl_' + data[i].partNumber + '>';
						if($('#mainContainer > .container').hasClass('myOrderStatuss')){
                       if (data[i].designId != ""	&& data[i].designId != undefined) {
							tblrow += ' <td>' + data[i].partNumber + " - "	+ data[i].designId + '</td>';
						} else {
							tblrow += ' <td>' + data[i].partNumber + '</td>';
						}
						}else{
						if (data[i].designId != ""	&& data[i].designId != undefined) {
							tblrow += ' <td><input name="' + data[i].partNumber  +  ':'+data[i].designId + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + ':'+data[i].designId+ '" /></td>';
							tblrow += ' <td>' + data[i].partNumber + " - "	+ data[i].designId + '</td>';
						} else {
							tblrow += ' <td><input name="' + data[i].partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + '" /></td>';
							tblrow += ' <td>' + data[i].partNumber + '</td>';
						} 						
						}						
                        tblrow += ' <td>' + data[i].description + '</td>';
                        tblrow += ' <td>' + data[i].unit + '</td>';
						if(!$('#mainContainer > .container').hasClass('myOrderStatuss')){
                        tblrow += ' <td>' + data[i].catalogAmount + '</td>';
						}
                        tblrow += ' <td>' + data[i].listprice + '</td>';
                        tblrow += ' <td class="yourPrice-List"><span class="tbl-loading"></span></td>';
						if($('#mainContainer > .container').hasClass('myOrderStatuss')){
						if (data[i].designId != ""	&& data[i].designId != undefined) {
							tblrow += ' <td><input name="' + data[i].partNumber  +  ':'+data[i].designId + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + ':'+data[i].designId+ '" /></td>';							
						} else {
							tblrow += ' <td><input name="' + data[i].partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + '" /></td>';
						} 							
						}
                        tblrow += ' <td class="noPrint"><a href="javascript:void(0);" part-data="' + data[i].skuId + '" class="remove"><i class="fal fa-trash-alt deletePartNo"></i></a></td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                    }
                    $(response.target).find('.skyblueTable tbody').html(tableData);
                    $('.emailBlk').show();
                    $('.errorText').text('');
                    $('#error-emptyCart').hide();
                    $("#EnterName").val('');
                    $("#EnterName").removeAttr('style');
                    if (data.errorMessage)
                        LSCA.GlobalValidate.showError('', data.errorMessage);
                    if (callback && typeof (callback) == 'function')
                        callback();
                } else {
                    $('.errorText').text(data.message);
                    $('#error-emptyCart').show();
                    $('.emailBlk,.printBlk').hide();
                    $(response.target).find('.skyblueTable tbody').html('');
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
                $('.emailBlk,.printBlk').hide();
            }
        }
    },
    recentlyOrderedProductsTable : {
        init : function(params_) {
            var tabActivated = false;
            $(document).on("click", "#recentlyOrderedProductsTab", function(e) {
                if (!tabActivated) {
                    LSCA.loadingSpinner.showLoading();
                    $(document).on("keyup", "#recentlyOrderedTable .qtyTxtbox", function(e) {
                        var $this = $(this);
                        $this.val($this.val().replace(/[^\d]/g, ''));
                    });
                    $(params_.target).find('table').attr('data-pagenum', '1');

                    LSCA.globalAjax.doCall({
                        url : params_.url,
                        target : params_.target
                    }, function(response) {
                        LSCA.recentlyOrderedProductsTable.parseme(response, function() {
                            LSCA.globalPaginateWithYourPrice.init({
                                prevnext : true,
                                pageid : 'getOrder',
                                url : '/common/myaccount/recentlyOrderedYourPrice.jsp?catalogIdList=',
                                target : '#recentlyOrderedProducts'
                            });
                        });
                        if (params_.callback && typeof (params_.callback) === 'function')
                            params_.callback(params_);
                    });
                    tabActivated = true;
                }
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            if (!$.isEmptyObject(data)) {
                LSCA.loadingSpinner.hideLoading();
                var len = data.length;
                if ($(response.target).find('.skyblueTable').length == 0) {
                    tblui = '<table class="skyblueTable pageme">';
                    tblui += '<tbody></tbody>';
                    tblui += '</table>';
                    $(response.target).html(tblui);
                }
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        tblrow = '<tr id=tbl_' + data[i].partNumber + '>';
                        if (data[i].designId != ""    && data[i].designId != undefined) {
							tblrow += ' <td class="part-number"><input name="partNumberRef" id="partNumberRef" type="hidden" value="' + data[i].partNumber + '" />' + data[i].partNumber + " - "    + data[i].designId + '</td>';
						} else {
							tblrow += ' <td class="part-number"><input name="partNumberRef" id="partNumberRef" type="hidden" value="' + data[i].partNumber + '" />' + data[i].partNumber + '</td>';
						}
                        tblrow += ' <td>' + data[i].description + '</td>';
                        tblrow += ' <td>' + data[i].unit + '</td>';
                        tblrow += ' <td>' + data[i].catalogAmount + '</td>';
                        tblrow += ' <td>' + data[i].listprice + '</td>';
                        tblrow += ' <td class="yourPrice-List"><span class="tbl-loading"></span></td>';
                        if (data[i].designId != ""    && data[i].designId != undefined){
							tblrow += ' <td><input name="' + data[i].partNumber +':' + data[i].designId + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber +':' + data[i].designId + '" /></td>';
						}
						else{
							tblrow += ' <td><input name="' + data[i].partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + '" /></td>';
						}
                        tblrow += '</tr>';
                        tableData += tblrow;
                    }
                    $(response.target).find('.skyblueTable tbody').html(tableData);
                    $('#recentlyOrderedProducts #btnAddToCart').show();
                    $('.errorText').text('');
                    if (data.errorMessage)
                        LSCA.GlobalValidate.showError('', data.errorMessage);
                    if (callback && typeof (callback) == 'function')
                        callback();
                } else {
                    LSCA.GlobalValidate.showError('', data.message ? data.message : 'Some error occured while fetching your data');
                    $('#error-emptyCart').show();
                    $(response.target).find('.skyblueTable tbody').html('');
                    $(response.target).find('.skyblueTable').hide();
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage ? data.errorMessage : 'Some error occured while fetching your data');
            }
        }
    },
    repairOrderViewTable : {
        init : function(params_) {
            LSCA.loadingSpinner.showLoading();
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.repairOrderViewTable.parseme(response, function() {
                });
                if (params_.callback && typeof (params_.callback) === 'function')
                    params_.callback(params_);
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            if (data) {
                console.log(data);
                LSCA.loadingSpinner.hideLoading();
                var transactionId = data[0].mTransactionId;
                var len = data[0].mQuoteItems.length;
                var totalLength = data[0].priceListMap.length;
                var exihibitLength = data[0].exihibitBean.length;
                var itemId = [];
                var ulleft, ulright, ulDataLeft = '', ulDataRight = '', ulexihibit = '';
                var salesPhone, salesEmail = '';
                var ssdQuoteAuthEnable = $("#ssdQuoteAuthEnable").val();
                if (ssdQuoteAuthEnable = true && (transactionId == '' || transactionId == null || transactionId == undefined)) {
                	$("#view-service-agreement").addClass('displayNone');	
                	$("#invalidTransactionId").removeClass('displayNone');	
                }
                if (exihibitLength > 0) {
                    for (var i = 0; i < exihibitLength; i++) {
                        ulexihibit += '<li><i class="fa fa-file-o" aria-hidden="true"></i><a href=' + data[0].exihibitBean[i].mExihibitLink + '>' + data[0].exihibitBean[i].mExihibitName
                                + '</a>';
                        var exhibitsPassword =  data[0].exihibitBean[i].mExihibitPassword;
                        exhibitsPassword = $.trim(exhibitsPassword);
                        if (exhibitsPassword != '' && exhibitsPassword != null && exhibitsPassword != undefined) {
                            ulexihibit += 'Password:&nbsp;<span>' + exhibitsPassword + '</span>';
                        }else {
                            ulexihibit += '<span>&nbsp;</span>';
                         }
                        ulexihibit +='</li>';
                    }
                    $(".repairOrderView .popup.custom-group-ext .custom-popup-ext ul").html(ulexihibit);
                }
                if (len > 0) {
					if(data[0].mServiceChargeOnly || data[0].mCreatedByWeb == "Y" ) { 
                        $("#reviewOnDemandQuoteTable thead th.qtyColumn").text(""); 
                        $("#reviewOnDemandQuoteTable thead th.unitPriceColumn").text("") 
                    } 

                    for (var i = 0; i < len; i++) {
                        var repairQtyValue = '', unitPriceCheck = '', totalPriceCheck = '';
                        if (data[0].mQuoteItems[i].itemQuantityValue > 0) {
                            repairQtyValue = data[0].mQuoteItems[i].itemQuantityValue;
                        }
                        if (data[0].mQuoteItems[i].unitPrice != '') {
                            unitPriceCheck = data[0].mQuoteItems[i].mFormattedUnitPrice;
                        }
                        if (data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue != '') {
                            totalPriceCheck = data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue;
                        }
                        tblrow = '<tr class=' + data[0].mQuoteItems[i].itemNumber + '>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].orderedProd + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].mServicePlan + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].chargeType + '</td>';
                        tblrow += ' <td>' + repairQtyValue + '</td>';
                        tblrow += ' <td>' + unitPriceCheck + '</td>';
                        tblrow += ' <td>' + totalPriceCheck + '</td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                        itemId.push('.' + data[0].mQuoteItems[i].itemNumber + ':last');
                    }
                    $("#reviewOnDemandQuoteTable tbody").html(tableData);
                    console.log(itemId.join());
                    $(itemId.join()).addClass('last');
                    // Sub Total
                    $('#instrumentInfo .modelDesc').text(data[0].mQuoteItems[0].modelDesc);
                    $('#instrumentInfo .modelNo').text(data[0].mQuoteItems[0].modelNumber);
                    $('#instrumentInfo .serialNo').text(data[0].mQuoteItems[0].serialNumber);
                }
                
                if(data[0].hasOwnProperty('mPreProcessType')){
					if(data[0].mPreProcessType =='ZQAC'){								
						 $('ul.breadcrumb li.active').text($("#pmBreadcrumbText").val());
					}	
					else {									
						$('ul.breadcrumb li.active').text($("#repairBreadcrumbText").val());
						
					}
				}
                if (totalLength > 0) {
                    for (var i = 0; i < totalLength; i++) {
                        $.each(data[0].mFormattedPriceListMap[i], function(k, v) {
							if(k != 'totalAmountQuote'){
								ulleft = ' <li>' + k + '</li>';
								ulright = ' <li>' + v + '</li>';
								ulDataLeft += ulleft;
								ulDataRight += ulright;
							}
                        });
                    }
                    $(".custom-total ul.custom-left-ul").html(ulDataLeft);
                    $(".custom-total ul.custom-right-ul").html(ulDataRight);
                }
                $('#repairContactInfo .contactName').text(data[0].mContactName);
                $('#repairContactInfo .companyName').text(data[0].mCompanyName);
                $('#repairContactInfo .cnt-number').text(data[0].mContactPhone);
                $('#repairContactInfo .cnt-email').text(data[0].mContactEmail);
                $('#equipLocation .eqName').text(data[0].mEquipName);
                $('#equipLocation .eqStreet').text(data[0].mEquipStreet);
                $('#equipLocation .eqCity').text(data[0].mEquipCity);
                $('#equipLocation .eqRegion').text(data[0].mEquipRegion);
                $('#equipLocation .eqCountry').text(data[0].mEquipCountry);
                $('#equipLocation .eqPostCode').text(data[0].mEquipPostCode);
                $('#netDays').text(data[0].mPaymentTerms);
                $('.rpOrdStatus').text(data[0].repairOrderStatus);
                $('#quoteId').val(data[0].mQuoteId);
                $('.quoteText').text(data[0].mQuoteId);
                $('.serviceReqNum').text(data[0].serviceReqNum);
                salesPhone = data[0].mSalesRepPhone;
                salesEmail = data[0].mSalesRepEmail;
                if ((salesPhone == '' || salesPhone == undefined) && (salesEmail == '' || salesEmail == undefined)) {
                    $('.repairOrderView .custom-quote-down').hide();
                }
                if (salesPhone == '' || salesPhone == undefined) {
                    $('.repairOrderView .custom-phone').hide();
                }
                if (salesEmail == '' || salesEmail == undefined) {
                    $('.repairOrderView #quoteEmail').hide();
                }
                $('.salesPhone').text(salesPhone);
                $('.repairOrderView #quoteEmail .fa.fa-envelope').append('<a id="sendmail" href="mailto:' + salesEmail + '?subject=' + $('#quoteEnquiry').val() + data[0].mQuoteId + '" target="_top">' + salesEmail + '</a>');
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
                console.log('error');
            }
        }
    },
    onDemandQuoteTable : {
        init : function(params_) {
            LSCA.loadingSpinner.showLoading();
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.onDemandQuoteTable.parseme(response, function() {
                });
                if (params_.callback && typeof (params_.callback) === 'function')
                    params_.callback(params_);
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            if (data) {
                console.log(data);
                LSCA.loadingSpinner.hideLoading();
                var transactionId = data[0].mTransactionId;
                var len = data[0].mQuoteItems.length;
                var totalLength = data[0].priceListMap.length;
                var exihibitLength = data[0].exihibitBean.length;
                var itemIdFirst = [];
                var itemIdLast = [];
                var ulleft, ulright, ulDataLeft = '', ulDataRight = '', ulexihibit = '';
                var salesPhone, salesEmail = '';
                var ssdQuoteAuthEnable = $("#ssdQuoteAuthEnable").val();
                if (ssdQuoteAuthEnable = true && (transactionId == '' || transactionId == null || transactionId == undefined)) {
                	$("#custom-quate-details").addClass('displayNone');	
                	$("#invalidTransactionId").removeClass('displayNone');
                }
                if (exihibitLength > 0) {
                    for (var i = 0; i < exihibitLength; i++) {
                        ulexihibit += '<li><i class="fa fa-file-o" aria-hidden="true"></i><a href=' + data[0].exihibitBean[i].mExihibitLink + '>' + data[0].exihibitBean[i].mExihibitName
                                + '</a>';
                        var exhibitsPassword =  data[0].exihibitBean[i].mExihibitPassword;
                        exhibitsPassword = $.trim(exhibitsPassword);
                        if (exhibitsPassword != '' && exhibitsPassword != null && exhibitsPassword != undefined) {
                            ulexihibit += 'Password:&nbsp;<span>' + exhibitsPassword + '</span>';
                        }else {
                            ulexihibit += '<span>&nbsp;</span>';
                        }
                          ulexihibit +='</li>';
                    }
                    $(".OnDemandQuote .popup.custom-group-ext .custom-popup-ext ul").html(ulexihibit);
                }
                if (len > 0) {
					if(data[0].mServiceChargeOnly) { 
                        $("#reviewOnDemandQuoteTable thead th.qtyColumn").text(""); 
                        $("#reviewOnDemandQuoteTable thead th.unitPriceColumn").text("") 
                    } 
                    for (var i = 0; i < len; i++) {
                        var repairQtyValue = '', unitPriceCheck = '', totalPriceCheck = '';
                        if (data[0].mQuoteItems[i].itemQuantityValue > 0) {
                            repairQtyValue = data[0].mQuoteItems[i].itemQuantityValue;
                        }
                        if (data[0].mQuoteItems[i].unitPrice != '') {
                            unitPriceCheck =  data[0].mQuoteItems[i].mFormattedUnitPrice;
                        }
                        if (data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue != '') {
                            totalPriceCheck =  data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue;
                        }
                        tblrow = '<tr class=' + data[0].mQuoteItems[i].itemNumber + '>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].orderedProd + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].mServicePlan + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].chargeType + '</td>';
                        tblrow += ' <td>' + repairQtyValue + '</td>';
                        tblrow += ' <td>' + unitPriceCheck + '</td>';
                        tblrow += ' <td>' + totalPriceCheck + '</td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                        itemIdFirst.push('.' + data[0].mQuoteItems[i].itemNumber + ':first');
                        itemIdLast.push('.' + data[0].mQuoteItems[i].itemNumber + ':last');
                    }
                    var semlen = 0;
                    if(data[0].mItemAdditionalInfo) {
                        semlen = data[0].mItemAdditionalInfo.length;
                    }
                    if (data[0].hasOwnProperty('mComments') || data[0].hasOwnProperty('mHeaderAdditionalInfo') || semlen>0) {
                        $('.sales-note').show();
                        var AdditionalInfo ='';
                        if (data[0].hasOwnProperty('mHeaderAdditionalInfo')) {
                        	
                        	if(data[0].hasOwnProperty('mProcessType')){
                        	   if(data[0].mProcessType =='ZQAC'){							
                        		  if(data[0].mCreatedByWeb == "Y" ){																
  									  AdditionalInfo =$("#pmQuoteHeaderNotes").val()+'<br>';
  									}
  									else{
  										AdditionalInfo="";
										$('.sales-note').addClass('hide');
  									}
								 $('.quoteTypeText').text($("#pmQuotesHeadingText").val());
								 $('ul.breadcrumb li.active').text($("#pmBreadcrumbText").val());
								}	
                        		else {
									$('.quoteTypeText').text($("#repairHeaderText").val());
									$('ul.breadcrumb li.active').text($("#repairBreadcrumbText").val());
                        			if(data[0].hasOwnProperty('mResponseType')){
        								if(data[0].mResponseType =='Priority'){
        									AdditionalInfo =$("#repairQuoteAddInfo1").val()+'<br>';
        								}else{
        									AdditionalInfo =$("#repairQuoteAddInfo2").val()+'<br>';
        								}
                                	}
                        		}
							}
                            
                        	
                        	/*$('.sales-note-inner p1').text(data[0].mHeaderAdditionalInfo);*/
                        }
                        if (data[0].hasOwnProperty('mComments') || semlen>0) {
                        	AdditionalInfo = AdditionalInfo+'<br>'+$("#repair_note").val()+' ';
                        }
                        if (data[0].hasOwnProperty('mComments')) {
                              AdditionalInfo =AdditionalInfo+data[0].mComments+'<br>';
                              $('.sales-note-inner p').text(data[0].mComments);
                        }
                        if (semlen > 0) { 
                              for (var i = 0; i < semlen; i++) {
                                    AdditionalInfo =AdditionalInfo+data[0].mItemAdditionalInfo[i]+'<br>';
                              }
                        } 
                        $('.sales-note-inner p').html(AdditionalInfo);
                    } else {
                        $('.sales-note').hide();
                    }
                    $("#reviewOnDemandQuoteTable tbody").html(tableData);
                    $(itemIdFirst.join()).addClass('first');
                    $(itemIdLast.join()).addClass('last');
                    // Sub Total
                    $('.modelDesc').text(data[0].mQuoteItems[0].modelDesc);
                    $('.modelNo').text(data[0].mQuoteItems[0].modelNumber);
                    $('.serialNo').text(data[0].mQuoteItems[0].serialNumber);
                    $('.sales-note-inner p').html(AdditionalInfo);
                }
                if (totalLength > 0) {
                    for (var i = 0; i < totalLength; i++) {
                        $.each(data[0].mFormattedPriceListMap[i], function(k, v) {
							if(k != 'totalAmountQuote'){
								ulleft = ' <li>' + k + '</li>';
								ulright = ' <li>' + v + '</li>';
								ulDataLeft += ulleft;
								ulDataRight += ulright;
							}
                        });
                    }
                    $(".custom-total ul.custom-left-ul").html(ulDataLeft);
                    $(".custom-total ul.custom-right-ul").html(ulDataRight);
                }
                $('.expireDate').text(data[0].quoteExpireDate);
                $('a#onDemandNext').attr('href', '/common/myaccount/onDemandPayment.jsp?quoteId=' + data[0].encryptQuoteId);
                $('#quoteId').val(data[0].mQuoteId);
                $('.quoteText').text(data[0].mQuoteId);
                $('.serviceReqNum').text(data[0].serviceReqNum);
                salesPhone = data[0].mSalesRepPhone;
                salesEmail = data[0].mSalesRepEmail;
                if ((salesPhone == '' || salesPhone == undefined) && (salesEmail == '' || salesEmail == undefined)) {
                    $('.OnDemandQuote .custom-quote-down').hide();
                }
                if (salesPhone == '' || salesPhone == undefined) {
                    $('.OnDemandQuote .custom-phone').hide();
                }
                if (salesEmail == '' || salesEmail == undefined) {
                    $('.OnDemandQuote #quoteEmail').hide();
                }
                var phnoplus = salesPhone.charAt(0);
                    if(phnoplus !='+'){
                    salesPhone = '+'+ salesPhone;
                    }
                $('.salesPhone').text(salesPhone);
                $('.OnDemandQuote #quoteEmail .fa.fa-envelope').append('<a id="sendmail" href="mailto:' + salesEmail + '?subject=' + $('#quoteEnquiry').val() + data[0].mQuoteId + '" target="_top">' + salesEmail + '</a>');
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
                console.log('error');
            }
        }
    },
    onDemandPaymentTable : {
        init : function(params_) {
            LSCA.loadingSpinner.showLoading();
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.onDemandPaymentTable.parseme(response, function() {
                });
                if (params_.callback && typeof (params_.callback) === 'function')
                    params_.callback(params_);
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            if (data) {
                console.log(data);
                LSCA.loadingSpinner.hideLoading();
                var len = data[0].mQuoteItems.length;
                var totalLength = data[0].priceListMap.length;
                var itemIdFirst = [];
                var itemIdLast = [];
                var ulleft, ulright, pleft, pright, ulDataLeft = '', ulDataRight = '', pDataLeft = '', pDataRight = '';
                var salesPhone, salesEmail = '';
                if (len > 0) {
					if(data[0].mServiceChargeOnly) { 
                        $("#reviewOnDemandQuoteTable thead th.qtyColumn").text(""); 
                        $("#reviewOnDemandQuoteTable thead th.unitPriceColumn").text("") 
                    } 
                    for (var i = 0; i < len; i++) {
                        var repairQtyValue = '', unitPriceCheck = '', totalPriceCheck = '';
                        if (data[0].mQuoteItems[i].itemQuantityValue > 0) {
                            repairQtyValue = data[0].mQuoteItems[i].itemQuantityValue;
                        }
                        if (data[0].mQuoteItems[i].unitPrice != '') {
                            unitPriceCheck =  data[0].mQuoteItems[i].mFormattedUnitPrice;
                        }
                        if (data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue != '') {
                            totalPriceCheck = data[0].mQuoteItems[i].mFormattedQuoteSystemGrossValue;
                        }
                        tblrow = '<tr class=' + data[0].mQuoteItems[i].itemNumber + '>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].orderedProd + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].mServicePlan + '</td>';
                        tblrow += ' <td>' + data[0].mQuoteItems[i].chargeType + '</td>';
                        tblrow += ' <td>' + repairQtyValue + '</td>';
                        tblrow += ' <td>' + unitPriceCheck + '</td>';
                        tblrow += ' <td>' + totalPriceCheck + '</td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                        itemIdFirst.push('.' + data[0].mQuoteItems[i].itemNumber + ':first');
                        itemIdLast.push('.' + data[0].mQuoteItems[i].itemNumber + ':last');
                    }
                    $("#reviewOnDemandQuoteTable tbody").html(tableData);
                    $(itemIdFirst.join()).addClass('first');
                    $(itemIdLast.join()).addClass('last');
					if(data[0].hasOwnProperty('mProcessType')){
						if(data[0].mProcessType =='ZQAC'){                               
							 $('.quoteTypeText').text($("#pmQuotesHeadingText").val());
							 $('ul.breadcrumb li.active').text($("#pmBreadcrumbText").val());
						}   
						else {
							$('.quoteTypeText').text($("#repairHeaderText").val());
							$('ul.breadcrumb li.active').text($("#repairBreadcrumbText").val());
						}
					}
                }
                if (totalLength > 0) {
                    for (var i = 0; i < totalLength; i++) {
                        console.log(i + '------' + data[0].mFormattedPriceListMap[i]);
                        if (i == totalLength - 1) {
                            console.log('last')
                            $.each(data[0].mFormattedPriceListMap[i], function(m, n) {
								if(m != 'totalAmountQuote'){
									pleft = m + ' <span>' + data[0].mPaymentTerms, +'<br> </span>';
									pright = n;
									pDataLeft += pleft;
									pDataRight += pright;
								}
                            });
                        } else {
                            console.log(' not last')
                            $.each(data[0].mFormattedPriceListMap[i], function(k, v) {
								if(k != 'totalAmountQuote'){
									 ulleft = ' <li>' + k + '</li>';
                                ulright = ' <li>' + v + '</li>';
                                ulDataLeft += ulleft;
                                ulDataRight += ulright;
								}
                               
                            });
                        }
                    }
                    $(".custom-total ul.custom-left-ul").html(ulDataLeft);
                    $(".custom-total ul.custom-right-ul").html(ulDataRight);
                    $(".custom-pay-info p.total-left-pay").html(pDataLeft);
                    $(".custom-pay-info p.total-right-pay").html(pDataRight);
                }
                $('.expireDate').text(data[0].quoteExpireDate);
                $('.quoteText').text(data[0].mQuoteId);
                $('.serviceReqNum').text(data[0].serviceReqNum);
                salesPhone = data[0].mSalesRepPhone;
                salesEmail = data[0].mSalesRepEmail;
                if ((salesPhone == '' || salesPhone == undefined) && (salesEmail == '' || salesEmail == undefined)) {
                    $('.OnDemandPayment .custom-quote-down').hide();
                }
                if (salesPhone == '' || salesPhone == undefined) {
                    $('.OnDemandPayment .custom-phone').hide();
                }
                if (salesEmail == '' || salesEmail == undefined) {
                    $('.OnDemandPayment #quoteEmail').hide();
                }
                $('.salesPhone').text(salesPhone);
                $('.OnDemandPayment #quoteEmail .fa.fa-envelope').append('<a id="sendmail" href="mailto:' + salesEmail + '?subject=' + $('#quoteEnquiry').val() + data[0].mQuoteId + '" target="_top">' + salesEmail + '</a>');
                $('#equipLocation .eqName').text(data[0].mEquipName);
                $('#equipLocation .eqStreet').text(data[0].mEquipStreet);
                $('#equipLocation .eqCity').text(data[0].mEquipCity);
                $('#equipLocation .eqRegion').text(data[0].mEquipRegion);
                $('#equipLocation .eqCountry').text(data[0].mEquipCountry);
                $('#equipLocation .eqPostCode').text(data[0].mEquipPostCode);

                $('#paymentBillingInfo #contact-info-div .default-cnt .contactName').text(data[0].billToName);
                $('#paymentBillingInfo #contact-info-div .default-cnt .cnt-street').text(data[0].billToStreet);
                $('#paymentBillingInfo #contact-info-div .default-cnt .cnt-city').text(data[0].billToCity);
                $('#paymentBillingInfo #contact-info-div .default-cnt .cnt-region').text(data[0].billToRegion);
                $('#paymentBillingInfo #contact-info-div .default-cnt .cnt-postal').text(data[0].billToPostCode);
                $('#paymentBillingInfo #contact-info-div .default-cnt .cnt-country').text(data[0].billToCountry);
                console.log(data[0].billToStreet + '----' + data[0].payerStreet);
                if (data[0].billToStreet == data[0].payerStreet) {
                    $("#paymentBillingInfo #view-list-more").hide();
                    $('#payerAddressCheck').val('true');
                } else {
                    $("#paymentBillingInfo #view-list-more").show();
                    $('#payerAddressCheck').val('false');
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .contactName').text(data[0].payerName);
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .cnt-street').text(data[0].payerStreet);
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .cnt-city').text(data[0].billToCity);
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .cnt-region').text(data[0].payerRegion);
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .cnt-postal').text(data[0].payerPostCode);
                    $('#paymentBillingInfo #contact-info-div .ndefault-cnt .cnt-country').text(data[0].payerCountry);
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
                console.log('error');
            }
        }
    },
    mycatalogaddPaging : {
        init : function(params_) {
            LSCA.mycatalogaddPaging.makePageNav(params_, function(params_) {
                LSCA.mycatalogaddPaging.pageData(params_)
            });
        },
        makePageNav : function(params_, callback) {
            var $rowbody = $(params_.target).find('tbody') || '', tRowCnt = $rowbody.find('tr').length || 0, limit = params_.limit || $('#catalogPaginationLimit ').val(), nums = '', onpage = parseInt($(
                    params_.target).find('table').attr('data-pagenum'));
            tRowCnt = $rowbody.find('tr').length;
            rowCntRnd = Math.ceil(tRowCnt / limit);
            if (tRowCnt > limit) {
                nums += (onpage === 1) ? '<li><span class="gray">&lt;</span></li>' : '<li><a class="prev" href="#">&lt;</a></li>';
                nums += (onpage === 1) ? '<li><span class="gray">1</span></li>' : '<li><a href="#">1</a></li>';
                if (onpage > 5) {
                    nums += '<li class="ellipsis"><span>...</span></li>';
                }
                if (onpage - 5 > 0) {
                    if (onpage < rowCntRnd - 2) {
                        s = onpage - 3;
                        e = onpage + 2
                    } else {
                        s = rowCntRnd - 5;
                        e = rowCntRnd - 1
                    }
                } else {
                    if (rowCntRnd > 10) {
                        s = 1;
                        e = 5
                    } else {
                        s = 1;
                        e = rowCntRnd - 1
                    }
                }
                for (i = s; i < e; i++) {
                    nums += (onpage === i + 1) ? '<li><span class="gray">' + (i + 1) + '</span></li>' : '<li><a href="#">' + (i + 1) + '</a></li>';
                }

                if (rowCntRnd - 3 > onpage) {
                    nums += '<li class="ellipsis"><span>...</span></li>';
                }
                nums += (onpage === rowCntRnd) ? '<li><span class="gray">' + rowCntRnd + '</span></li>' : '<li><a href="#">' + rowCntRnd + '</a></li>';
                nums += (onpage === rowCntRnd) ? '<li><span class="gray">&gt;</span></li>' : '<li><a class="next" href="#">&gt;</a></li>';
            }
            $('.catalogPagination').html(nums);

            params_.limit = limit;
            var partNoArray = [];
            if (parseInt($(params_.target).find('table').attr('data-pagenum')) === 1) {
                $rowbody.find('tr').hide();
                $(params_.target).find('img').hide();
                $(params_.target).find('tbody tr').each(function(i, v) {
                    $(this).show();
                    //partNoArray.push($(this).find('td').eq(1).text());
					if($('#mainContainer > .container').hasClass('myOrderStatuss')){
						partNoArray.push($(this).find('td').eq(5).find('input.qtyTxtbox').attr("name").split(":")[0]);
					}else{
						partNoArray.push($(this).find('td').eq(0).find('input.qtyTxtbox').attr("name").split(":")[0]);
					}					
                    if (i == limit - 1)
                        return false;
                });
                $('#partNumberList').val(partNoArray.join());
            }
            var datapgnum = parseInt($(params_.target).find('table').attr('data-pagenum'));
            var pgnum = datapgnum - 1;
            var tempLimit = $('#catalogPaginationLimit ').val();
            var discalc = (tempLimit * pgnum) - 1;
            var limitCalc = (tempLimit * datapgnum) - 1;

            if (datapgnum > 1) {
                $rowbody.find('tr').hide();
                $(params_.target).find('tbody tr').each(function(i, v) {
                    if (i > discalc) {
                        $(this).show();
                        //partNoArray.push($(this).find('td').eq(1).text());
						if($('#mainContainer > .container').hasClass('myOrderStatuss')){
							partNoArray.push($(this).find('td').eq(5).find('input.qtyTxtbox').attr("name").split(":")[0]);
						}else{
							partNoArray.push($(this).find('td').eq(0).find('input.qtyTxtbox').attr("name").split(":")[0]);
						}
                        if (i == limitCalc)
                            return false;
                    }
                });
                $('#partNumberList').val(partNoArray.join());
            }			
            LSCA.displayYourPriceList.init({
                pageid : 'viewMyCatalog',
                url : '/common/getPriceForWishList.jsp?listId=' + $("#catlogListView li.active").attr('id') + '&catalogIdList=' + $('#partNumberList').val(),
                target : '#viewCatalog'
            });
            $('.catalogPagination').find('a').off('click');
            if (callback && typeof (callback) == 'function')
                callback(params_);
        },
        pageData : function(params_) {
            var $rowbody = $(params_.target).find('tbody') || '', limit = params_.limit, onpage = parseInt($(params_.target).find('table').attr('data-pagenum')), startat = 0;
            $('.catalogPagination').find('a').on('click', function(e) {
                e.preventDefault();
                navto = parseInt($(this).text());
                if ($(this).hasClass('prev')) {
                    navto = onpage - 1
                } else if ($(this).hasClass('next')) {
                    navto = onpage + 1
                }
                if (navto > onpage) {
                    startat = (((navto - 1) * limit) - 1)
                } else if (navto != onpage) {
                    startat = (navto * limit) - (limit + 1)
                }
                $rowbody.find('tr').hide();
                startat = startat - 1;
                limit = limit + 1;
                $rowbody.find('tr').each(function(i, v) {
                    i = i - 1;
                    if (i >= startat) {
                        $(this).show();
                    }
                    if (i == startat) {
                        $(this).hide();
                    }
                    if (i == (startat + (limit - 1)))
                        return false;
                });
                $(params_.target).find('table').attr('data-pagenum', navto);
                LSCA.mycatalogaddPaging.makePageNav(params_, LSCA.mycatalogaddPaging.pageData);
				$('html,body').animate({scrollTop: $('#quoteResult').offset().top - 50},'slow'); 
            })
        }
    },
	mySalesaddPaging : {
        init : function(params_) {
            LSCA.mySalesaddPaging.makePageNav(params_, function(params_) {
                LSCA.mySalesaddPaging.pageData(params_)
            });
        },
        makePageNav : function(params_, callback) {
            var $rowbody = $(params_.target).find('tbody') || '', tRowCnt = $rowbody.find('tr').length || 0, limit = params_.limit || 20, nums = '', onpage = parseInt($(
                    params_.target).find('table').attr('data-pagenum'));
            tRowCnt = $rowbody.find('tr').length;
            rowCntRnd = Math.ceil(tRowCnt / limit);

			var ellipsisCount = 0;
				var ellipsisFlag = false;
				var currentLimit = (tRowCnt < limit)? tRowCnt:limit ;
				var currrentPageFirstRow = ((onpage-1)*currentLimit +1);
				var currrentPageLastRow = (currrentPageFirstRow+currentLimit-1);
				var paginateBcc = $(params_.target+" #paginateMsg").val();
				paginateBcc = paginateBcc.replace("{}",currrentPageFirstRow);
				if(onpage*currentLimit > tRowCnt) {
					paginateBcc = paginateBcc.replace("{}",tRowCnt);
				}
				else {
				paginateBcc = paginateBcc.replace("{}",currrentPageLastRow);
				}
				paginateBcc = paginateBcc.replace("{}",tRowCnt);
				$(params_.target+' .paginationText').html(paginateBcc);
				if(tRowCnt > limit){

					if(onpage == 1){
						//nums +=  '<li class="content"><span class="selectedpage prev grey"></span></li>';
						nums +=  '<li class="disabled page-back"><a class="prev"></a></li>';
					}else{
						//nums +=  '<li class="content"><a href="javascript:void(0);" class="activepage prev"></a></li>';
						nums +=  '<li class="page-back"><a class="prev"></a></li>';
						
					}
					for (var pgn = 1; pgn <= rowCntRnd; pgn++) {
						if (pgn == onpage) {
							//nums +=  '<li class="content selectedpage"><span class="selectedpage grey">' + pgn + "</span></li>";
							nums +=  '<li class="active"><a>' + pgn + "</a></li>";
							
						} 
						else if ((pgn == onpage+1) ||(pgn == onpage-1) || (pgn == 1)||(pgn == rowCntRnd)){
							//nums +=  '<li class="content"><a href="javascript:void(0);" class="activepage">' + pgn + "</a></li>";
							nums +=  '<li><a href="#">' + pgn + "</a></li>";
							
							ellipsisCount=0;
							ellipsisFlag=true;
						}
						else {
							ellipsisCount=ellipsisCount+1;
							if(ellipsisCount>1) {
								if(ellipsisFlag){
									//nums += '<li class="content ellipsisdot"><span class="pgEllipsisTxt">...</span></li>';
									nums += '<li class="ellipsis"><a>...</a></li>';
									
									ellipsisFlag=false;
								}
							}
							else if(ellipsisCount==1) {
								if((rowCntRnd-onpage==3 && pgn>onpage) || (onpage-1==3 && pgn<onpage))			
									//nums +=  '<li class="content"><a href="javascript:void(0);" class="activepage">' + pgn + "</a></li>";
									nums +=  '<li><a href="#">' + pgn + "</a></li>";
							}
						}
					}

					if(onpage == rowCntRnd){
						//nums +=  '<li class="content"><span class="selectedpage next grey"></span></li>';
						nums +=  '<li class="disabled page-forward"><a class="next"></a></li>';
					}else{
						//nums +=  '<li class="content"><a href="javascript:void(0);" class="activepage next"></a></li>';
						nums +=  '<li class="page-forward"><a class="next"></a></li>';
					}
				}
            $(params_.target+' .pagination').html(nums);

            params_.limit = limit;
            if (parseInt($(params_.target).find('table').attr('data-pagenum')) === 1) {
                $rowbody.find('tr').hide();
                $(params_.target).find('img').hide();
                $(params_.target).find('tbody tr').each(function(i, v) {
                    $(this).show();
                    if (i == limit - 1)
                        return false;
                });
            }
            var datapgnum = parseInt($(params_.target).find('table').attr('data-pagenum'));
            var pgnum = datapgnum - 1;
            var tempLimit = 20;
            var discalc = (tempLimit * pgnum) - 1;
            var limitCalc = (tempLimit * datapgnum) - 1;

            
             if (datapgnum > 1) {
                $rowbody.find('tr').hide();
                $(params_.target).find('tbody tr').each(function(i, v) {
                    if (i > discalc) {
                        $(this).show();
                        if (i == limitCalc)
                            return false;
                    }
                });
            }
            $(params_.target+' .pagination').find('a').off('click');
            if (callback && typeof (callback) == 'function')
                callback(params_);
        },
        pageData : function(params_) {
            var $rowbody = $(params_.target).find('tbody') || '', limit = params_.limit, onpage = parseInt($(params_.target).find('table').attr('data-pagenum')), startat = 0;
			console.log($(this).hasClass('disabled'));
            $(params_.target+' li:not(.disabled,.ellipsis) a').on('click', function(e) {
                e.preventDefault();
                navto = parseInt($(this).text());
                if ($(this).hasClass('prev')) {
                    navto = onpage - 1
                } else if ($(this).hasClass('next')) {
                    navto = onpage + 1
                }
                if (navto > onpage) {
                    startat = (((navto - 1) * limit) - 1)
                } else if (navto != onpage) {
                    startat = (navto * limit) - (limit + 1)
                }
                $rowbody.find('tr').hide();
                startat = startat - 1;
                limit = limit + 1;
                $rowbody.find('tr').each(function(i, v) {
                    i = i - 1;
                    if (i >= startat) {
                        $(this).show();
                    }
                    if (i == startat) {
                        $(this).hide();
                    }
                    if (i == (startat + (limit - 1)))
                        return false;
                });
                $(params_.target).find('table').attr('data-pagenum', navto);
                LSCA.mySalesaddPaging.makePageNav(params_, LSCA.mySalesaddPaging.pageData);
				/*if($(this).attr('class') == 'prev' || $(this).attr('class') == 'next') {
					$('html,body').animate({scrollTop: $(params_.target+' .pagination-con').offset().top - 300},'slow');
				}
				else {*/
					$('html,body').animate({scrollTop: $(params_.target).offset().top - 50},'slow');	
				//}
            })
        }
    },
    largeFileOrderCheckout : {
        init : function(params_) {
            var purchaseOrder = $("input#po");
            var invoiceEmail = $("input#payerInvoiceEmail");
            var orderEmail = $("input#orderNotificationEmail");
            var quoteNumber = $("input#quoteNo");
            var partNumber = $("input#partNumber");
            var qty = $("input#Qty");
           if(jQuery("#mainContainer").hasClass("qckOrderUpload")){
	            purchaseOrder.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            invoiceEmail.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            orderEmail.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            quoteNumber.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            partNumber.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            qty.on('keyup', function() {
	                if ($(this).val()) {
	                    $(this).css('border-color', '#e0e0e0');
	                } else {
	                    $(this).css('border-color', 'red');
	                }
	            });
	            $(document).on("keyup", ".large-file-qty", function(e) {
	                var $this = $(this);
	                $this.val($this.val().replace(/[^\d]|^0/g, ''));
	                if ($this.val()) {
	                    $this.css('border-color', '#e0e0e0');
	                } else {
	                    $this.css('border-color', 'red');
	                }
            });		
            if ($(document).find("#invoiceEmailId div.checker span").attr("class") == "checked") {
                $("#invoiceEmailId div.checker span input[type='checkbox']").attr("checked", "checked");
                invoiceEmail.removeAttr("disabled").addClass("email");
                if (invoiceEmail.val()) {
                    invoiceEmail.css('border-color', '#e0e0e0');
                } else {
                    invoiceEmail.css('border-color', 'red');
                }
            } else {
                $("#invoiceEmailId div.checker span input[type='checkbox']").removeAttr("checked");
                invoiceEmail.attr("disabled", "disabled").removeClass("email").css('border-color', '#e0e0e0');
            }

            if ($(document).find("#orderNotification div.checker span").attr("class") == "checked") {
                $("#orderNotification div.checker span input[type='checkbox']").attr("checked", "checked");
                orderEmail.removeAttr("disabled").addClass("email");
                if (orderEmail.val()) {
                    orderEmail.css('border-color', '#e0e0e0');
                } else {
                    orderEmail.css('border-color', 'red');
                }
            } else {
                $("#orderNotification div.checker span input[type='checkbox']").removeAttr("checked");
                orderEmail.attr("disabled", "disabled").removeClass("email").css('border-color', '#e0e0e0');
            }
			
			if ($(document).find("#quoteRefNumberStatus div.checker span").attr("class") == "checked") {
                $("#quoteRefNumberStatus div.checker span input[type='checkbox']").attr("checked", "checked");
                quoteNumber.removeAttr("disabled").addClass("email");
                if (quoteNumber.val()) {
                    quoteNumber.css('border-color', '#e0e0e0');
                } else {
                    quoteNumber.css('border-color', 'red');
                }
            } else {
                $("#quoteRefNumberStatus div.checker span input[type='checkbox']").removeAttr("checked");
                quoteNumber.attr("disabled", "disabled").removeClass("email").css('border-color', '#e0e0e0');
            }

            /* For invoice email validation */
            $(document).on("click", "#invoiceEmailId div.checker span", function(e) {
                className = $(this).attr("class");
                if (className == "checked") {
                    if (invoiceEmail.val()) {
                        invoiceEmail.css('border-color', '#e0e0e0');
                    } else {
                        invoiceEmail.css('border-color', 'red');
                    }
                } else {
                    invoiceEmail.css('border-color', '#e0e0e0');
                }
            });

            /* For order notification email validation */
            $(document).on("click", "#orderNotification div.checker span", function(e) {
                className = $(this).attr("class");
                if (className == "checked") {
                    orderEmail.removeAttr("disabled").addClass("email");
                    if (orderEmail.val()) {
                        orderEmail.css('border-color', '#e0e0e0');
                    } else {
                        orderEmail.css('border-color', 'red');
                    }
                } else {
                    orderEmail.attr("disabled", "disabled").removeClass("email").css('border-color', '#e0e0e0');
                }
            });

            /* For Quote Number validation */
            $(document).on("click", "#quoteRefNumber div.checker span", function(e) {
                className = $(this).attr("class");
                if (className == "checked") {
                    quoteNumber.removeAttr("disabled").addClass("required");
                    if (quoteNumber.val()) {
                        quoteNumber.css('border-color', '#e0e0e0');
                    } else {
                        quoteNumber.css('border-color', 'red');
                    }
                } else {
                    quoteNumber.attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
                }
            });
		}

            $('#reviewOrder').on('click', function(e) {
                e.preventDefault();
                if(!jQuery(".largeCheckout #inputShipto").hasClass("required")){
                var dovalidateCheckoutDetails = LSCA.GlobalValidate.init({
                    target : params_.details_target
                });
				}
				else{
					if(!jQuery("#inputShipto").hasClass("requiredTextBox")){
					 dovalidateCheckoutDetails = true;
					}
					else{
					 dovalidateCheckoutDetails = false;
					}
				}				
                var lcpoFieldCheck = true,lcfutureDateFieldVal = true;
				if ($(".largeCheckout .redQuote input[name='pOrder']:checked").val() == 'purchaseOrder') {
						if($('.largeCheckout .redQuote input#po').val() == '') {
							$('.largeCheckout .redQuote input#po').addClass('requiredTextBox');
							$('.largeCheckout .redQuote #purchaseOrderLabel').addClass('requiredLabel');
							$('.largeCheckout .redQuote input#po').next().next().show();
							lcpoFieldCheck = false;
						}
						else {
							$('.largeCheckout .redQuote input#po').removeClass('requiredTextBox');
							$('.largeCheckout .redQuote #purchaseOrderLabel').removeClass('requiredLabel');
							$('.largeCheckout .redQuote input#po').next().next().hide();
							lcpoFieldCheck = true;
						}
				}
				if ($(".largeCheckout .custom-future-date-wrap input[name='delivery']:checked").val() == 'DeliveryDate') {
					if($('.largeCheckout .custom-future-date-wrap input#calender').val() == '') {
						$('.largeCheckout .custom-future-date-wrap input#calender').addClass('requiredTextBox');
						//$('.largeCheckout #fetchDeliveryOption #purchaseOrderLabel').addClass('requiredLabel');
						$('.largeCheckout .custom-future-date-wrap input#calender').next().next().next().show();
						lcfutureDateFieldVal = false;
					}
					else {
						$('.largeCheckout .custom-future-date-wrap input#calender').removeClass('requiredTextBox');
						//$('.largeCheckout .redQuote #purchaseOrderLabel').removeClass('requiredLabel');
						$('.largeCheckout .custom-future-date-wrap input#calender').next().next().next().hide();
						lcfutureDateFieldVal = true;
					}
				}
				if ($('#shipAttention #attentionLF').is(':visible') && $('#shipAttention #attentionLF').hasClass('required')) {
                    if ($('#shipAttention #attentionLF').val() == "") {
                        $('#shipAttention #attentionLF').next().next().css('display', 'inline-block');
                        $('#shipAttention #attentionLF').prev('.f14').addClass('requiredLabel');
                        $('#shipAttention #attentionLF').addClass('requiredTextBox');
                        $('#shipAttention #attentionLF').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#shipAttention #attentionLF').next().next().hide();
                        $('#shipAttention #attentionLF').prev('.f14').removeClass('requiredLabel');
                        $('#shipAttention #attentionLF').removeClass('requiredTextBox');
                        $('#shipAttention #attentionLF').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                }
                if ($('#shipBuilding #buildingRoomLF').is(':visible') && $('#shipBuilding #buildingRoomLF').hasClass('required')) {
                    if ($('#shipBuilding #buildingRoomLF').val() == "") {
                        $('#shipBuilding #buildingRoomLF').next().next().css('display', 'inline-block');
                        $('#shipBuilding #buildingRoomLF').prev('.f14').addClass('requiredLabel');
                        $('#shipBuilding #buildingRoomLF').addClass('requiredTextBox');
                        $('#shipBuilding #buildingRoomLF').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#shipBuilding #buildingRoomLF').next().next().hide();
                        $('#shipBuilding #buildingRoomLF').prev('.f14').removeClass('requiredLabel');
                        $('#shipBuilding #buildingRoomLF').removeClass('requiredTextBox');
                        $('#shipBuilding #buildingRoomLF').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                }
				if ($('#shipPhone #phoneNumberLF').is(':visible') && $('#shipPhone #phoneNumberLF').hasClass('required')) {
					if ($('#shipPhone #phoneNumberLF').val() == "") {
						$('#shipPhone #phoneNumberLF').next().next().css('display', 'inline-block');
						$('#shipPhone #phoneNumberLF').prev('.f14').addClass('requiredLabel');
						$('#shipPhone #phoneNumberLF').addClass('requiredTextBox');
						$('#shipPhone #phoneNumberLF').parent().parent('.formGroup').css('margin-bottom', '10px');
					} else {
						$('#shipPhone #phoneNumberLF').next().next().hide();
						$('#shipPhone #phoneNumberLF').prev('.f14').removeClass('requiredLabel');
						$('#shipPhone #phoneNumberLF').removeClass('requiredTextBox');
						$('#shipPhone #phoneNumberLF').parent().parent('.formGroup').css('margin-bottom', '15px');
					}
				}
				if ($('#shipPhoneJPReq #phoneNumberLF').is(':visible') && $('#shipPhoneJPReq #phoneNumberLF').hasClass('required')) {
					if ($('#shipPhoneJPReq #phoneNumberLF').val() == "") {
						$('#shipPhoneJPReq #phoneNumberLF').next().next().css('display', 'inline-block');
						$('#shipPhoneJPReq #phoneNumberLF').prev('.f14').addClass('requiredLabel');
						$('#shipPhoneJPReq #phoneNumberLF').addClass('requiredTextBox');
						$('#shipPhoneJPReq #phoneNumberLF').parent().parent('.formGroup').css('margin-bottom', '10px');
					} else {
						$('#shipPhoneJPReq #phoneNumberLF').next().next().hide();
						$('#shipPhoneJPReq #phoneNumberLF').prev('.f14').removeClass('requiredLabel');
						$('#shipPhoneJPReq #phoneNumberLF').removeClass('requiredTextBox');
						$('#shipPhoneJPReq #phoneNumberLF').parent().parent('.formGroup').css('margin-bottom', '15px');
					}
				}
				if($(".largeFileCheckout input").hasClass("requiredTextBox")){
					$('html, body').animate({
					scrollTop: $(".requiredTextBox").offset().top - 50
				  }, 500);
				}
                if (dovalidateCheckoutDetails) {
                    var doValidateProductTable = LSCA.largeFileOrderCheckout.validateProductTable({
                        target : params_.product_table_target
                    });
                    if (doValidateProductTable && lcpoFieldCheck && lcfutureDateFieldVal) {
						/*if(!$('#quoteRefNumberStatus').is(':checked')) {
							$('#quoteNo').removeAttr('placeholder');	
							$('#quoteNo').val('');	
						}*/
						if($("#testaccount").val()=='true'){
	                        window.location = "/common/checkout/largeFileOrderCheckout.jsp?isLargeFileUpload=true&isTestAccount=1";
						}else{
							window.location ="/common/checkout/largeFileOrderThankYou.jsp#no-back";
						}
                        var largeFileOrderData = setLargeFileOrderData();
                        var largeFileProductTable = $('#largeFileUploadTable form').serialize();
                        LSCA.globalAjax.doCall({
                            url : params_.url,
                            data : {
                                largeFileOrderData : largeFileOrderData,
                                largeFileProductTable : largeFileProductTable,
                                orderNotificationEmail : $('#orderNotificationEmail').val(),
                                poNumber : $('#po').val(),
                                paymentMethod : $("input[name='pOrder']:checked").val(),
                                payerInvoiceEmail : $('#payerInvoiceEmail').val(),
                                paymentReferenceNo : $('#fspPONumberInput').val(),
                                quoteReferenceId : $('#quoteNo').val(),
                                quoteReferenceCheck : $('#quoteRefNumberStatus').is(':checked'),
                                emailCheck : $('#invoiceEmailStatus').is(':checked')
                            },
                            dataType : 'JSON',
                            type : 'POST'
                        }, function(response) {
                            // No operation required
                        });
                    }
                }
            });
        },
        validateProductTable : function(params_) {
            var message = "Enter the quantity";
            var emptyMessage = "Please select atleast one item to add to cart";
            var msgui;
            var showQtyError = false;
            var showEmptyError = false;
            if ($("#productTableQtyError").val()) {
                message = $("#productTableQtyError").val();
            }
            if ($("#productTableEmptyError").val()) {
                emptyMessage = $("#productTableEmptyError").val();
            }
            if ($(params_.target).find('#productTable > tbody >  tr:not(.last,.order-summaryrow,.dgMessageSection)').length) {
                $(params_.target).find('#productTable > tbody >  tr:not(.last,.order-summaryrow,.dgMessageSection)').each(function(i, v) {
                    if ($(this).find("td.qty-box") && !$(this).find("td.qty-box").find(".large-file-qty").val()) {
                        showQtyError = true;
                        msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + message + '</div>';
                    }
                });
            } else {
                showEmptyError = true;
                msgui = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>' + emptyMessage + '</div>';
            }

            if (showQtyError || showEmptyError) {
                $(document).find('div.errorMessages').hide();
                $(document).find('div.errorMessages').html(msgui);
                $(document).find('div.errorMessages').show();
                if ($(document).find('div.errorMessages:eq(0)').position()) {
                    $(document).scrollTop($(document).find('div.errorMessages:eq(0)').position().top);
                }
            }
            return !(showQtyError || showEmptyError);
        }
    },
    largeFileOrderSubmit : {
        init : function(params_) {
            $('#btnPlaceLargeOrder').on('click', function(e) {
                e.preventDefault();
                if ($("#agreeCheckbox").length && !$("#agreeCheckbox").is(":checked")) {
                    $("#checkboxModal").modal();
                } else {
                	if(selectedPaymentMethodVal == 'cybersource'){
                		setCyberSourceData();
                		$.ajax({
    						type: "POST",
    						contentType: "application/json; charset=utf-8",
    						url: "/rest/model/com/agilent/commerce/SoldToVerification?atg-rest-output=json",
    						data: JSON.stringify({
    							"soldToVerify": {
    								"soldToNumber": $(".LFCreview #soldToInOrder").val()
    							}
    						}),
    						success: function (responsedata) {		 
    						   if(responsedata.checkSoldToDetailsResponse == true){
    							   jQuery(".LFCreview .soldToErr span").text("");
    								jQuery(".LFCreview .soldToErr span").text(jQuery("#soldToUpdatedErrorMsg").val())
    								jQuery(".LFCreview .soldToErr").show();
    								$('html, body').animate({
										scrollTop: $(".LFCreview .soldToErr").offset().top - 150
									  }, 500);
    							}
    							else{
    								submitForm();  
    							}
    						},
    						dataType: "json"
    					});
                		//submitForm();
                	}
                	else{	
	                    var currentOrderId = $('#currentOrderId').val();
	                    var quote = $('#quoteNo').val();
	                    var specil = $('#SpecialInstructions').val();
	                    var advShip = false;
	                    if($('#advShip').length) {
	                    	advShip = $('#advShip').val();
	                    }
	                    $.ajax({
							type: "POST",
							contentType: "application/json; charset=utf-8",
							url: "/rest/model/com/agilent/commerce/SoldToVerification?atg-rest-output=json",
							data: JSON.stringify({
								"soldToVerify": {
									"soldToNumber": $(".LFCreview #soldToInOrder").val()
								}
							}),
							success: function (responsedata) {		 
							   if(responsedata.checkSoldToDetailsResponse == true){
								    jQuery(".LFCreview .soldToErr span").text("");
									jQuery(".LFCreview .soldToErr span").text(jQuery("#soldToUpdatedErrorMsg").val())
									jQuery(".LFCreview .soldToErr").show();
									$('html, body').animate({
										scrollTop: $(".LFCreview .soldToErr").offset().top - 150
									  }, 500);
								}
								else{
									getSessionBeanDatafn(null);
									window.location = params_.target_url + "?currentOrderId=" + currentOrderId + "#no-back";
									LSCA.globalAjax.doCall({
			                        url : params_.hop_url,
			                        data : {
			                            currentOrderId : currentOrderId,
			                            quote : quote,
			                            specil : specil,
			                            advShip : advShip
			                        },
			                        dataType : 'JSON',
			                        type : 'POST'
				                    }, function(response) {
				                        // No operation required
				                    });
								}
							},
							dataType: "json"
						});
                	}
                }
            });
        }
    },
    redeemQuoteDeliveryOptions : {
        init : function(params_) {
            var upsNumber = $("#RedeemQuoteupsNumber");
            var upsNumberHidden = $("#RedeemQuoteupsNumberHidden");

            var UPSGrp = $(".ups-app-rem");
            var UPSRemove = $("#UPSRemove");

            var fedExNumber = $("#RedeemQuotefedExnumber");
            var fedExNumberHidden = $("#RedeemQuotefedExnumberHidden");
            var fedExGrp = $(".fedex-app-rem");
            var fedExRemove = $("#fedExRemove");

            if (upsNumber.val()) {
                UPSRemove.show();
                upsNumber.attr("disabled", "disabled");
                fedExNumber.val('').attr("disabled", "disabled");
                fedExNumberHidden.val('');
                fedExGrp.hide();
            }
            if (fedExNumber.val()) {
                fedExRemove.show();
                fedExNumber.attr("disabled", "disabled");
                upsNumber.val('').attr("disabled", "disabled");
                upsNumberHidden.val('');
                UPSGrp.hide();
            }	
            upsNumber.on('input', function() {
				$(this).val($(this).val().replace(/[^a-z0-9]/gi,''));	
            });	
            fedExNumber.on('input', function() {
				$(this).val($(this).val().replace(/[^0-9]/gi,''));
            });			
			upsNumber.keypress(function(event){
				var keycode = event.which;
				 if(!((event.keyCode >= 65) && (event.keyCode <= 90) || (event.keyCode >= 97) && (event.keyCode <= 122) || (event.keyCode >= 48) && (event.keyCode <= 57))){
					$(this).addClass('requiredTextBox')
				}else{
					$(this).removeClass('requiredTextBox')
				}
			});	
			fedExNumber.keypress(function(event){
				var keycode = event.which;
				if (!(keycode >= 48 && keycode <= 57)) {
					$(this).addClass('requiredTextBox')
				}else{
					$(this).removeClass('requiredTextBox')
				}
			});				
            $('input[type=radio][name=delivery]').change(function(e) {
                LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
            });
        },
        doAjaxCall : function(e, params_) {
            e.preventDefault();
            LSCA.loadingSpinner.showLoading();
            var upsCheck = ($("#UpsCheck").val()) ? $("#UpsCheck").val() : false;
            var fedExCheck = ($("#fedExCheck").val()) ? $("#fedExCheck").val() : false;
            var shippingCheck = (params_.callInitiator && params_.callInitiator === 'changeShippingAddress') ? true : false;
            var url = (params_.shippingURL) ? params_.shippingURL : params_.url;
			var vatCheck = ($("#vatCheck").prop('checked')) ? $("#vatCheck").prop('checked') : false;
            LSCA.globalAjax.doCall({
                url : url,
                data : {
                    quoteId : $("#quoteNumber").val(),
                    deliveryOption : $('input[name="delivery"]:checked').val(),
                    upsCheck : upsCheck,
                    upsNumber : $("#RedeemQuoteupsNumber").val(),
                    fedExCheck : fedExCheck,
                    fedExNumber : $("#RedeemQuotefedExnumber").val(),
                    quoteTotal : $("#quotationSubtotal").val(),
                    totalTax : $("#totalTaxValue").val(),
                    currencyLocale : $("#currencyLocale").val(),
                    shippingCheck : shippingCheck,
                    makeShippingZero : $("#makeShippingZero").val(),
                    selectedAddressId : $("#customDropdown2").val(),
					vatcheck : vatCheck
                },
                dataType : 'JSON',
                type : 'GET'
            }, function(response) {
                LSCA.redeemQuoteDeliveryOptions.parseme(response, function() {
                    if (params_.callback && typeof (params_.callback) === 'function')
                        params_.callback(params_);
                });
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (!isEmpty(data)) {
                $('#fetchDynamicShippingCharge').val(true);
                $('#shippingChargeBean').val($.trim(data.shippingHandlingCharge));
                $('.shippingHandlingCharge').html($.trim(data.shippingHandlingCharge));
                $('.redeemQuoteTaxAmount').html($.trim(data.redeemQuoteTaxAmount));
                $('#quoteTotalAmountBean').val($.trim(data.quoteTotal));
                $('.quoteTotalAmount').html($.trim(data.quoteTotal));
                $('#TotalShippingCharge').val(data.doubleRedeemQuoteshippingHandlingCharge);
            }
            LSCA.loadingSpinner.hideLoading();
            callback();
        }
    },
    loadingSpinner : {
        showLoading : function() {
            if (!$(".loading").length) {
                $('body').prepend('<div class="loading"></div>');
            }
            $(".loading").css("display", "block");
            $(".loading").css("z-index", 2147483647);

        },
        hideLoading : function() {
            $(".loading").css("display", "none");
            $(".loading").css("z-index", 9999);
        }
    },
    displayYourPriceList : {
        init : function(params_) {
            $("#print-cart").hide();
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.displayYourPriceList.parseme(response, function() {
                    if (params_.callback && typeof (params_.callback) === 'function')
                        params_.callback(params_);
                });
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data) {
                var len = data.length;
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        $("#tbl_" + data[i].partNumber + " td.yourPrice-List").html(data[i].yourprice);
                    }
                    $("#print-cart").show();
                }
            }
        }
    },
    displayEmailYourPriceList : {
        init : function(params_) {
            LSCA.globalAjax.doCall({
                url : params_.url,
                target : params_.target
            }, function(response) {
                LSCA.displayEmailYourPriceList.parseme(response, function() {
                    if (params_.callback && typeof (params_.callback) === 'function')
                        params_.callback(params_);
                });
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data) {
                var len = data.length;
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        $("#tbl_" + data[i].partNumber + " td.yourPrice-List").html(data[i].yourprice);
                    }
                }
            }
        }
    },
    displayCatalogList : {
        init : function(params_) {
            $(document).on("click", ".secondary-catalogList,.default-Catlog", function(e) {
                if ($('.catlogtext-edit.requiredName').length == 0) {
                    e.preventDefault();
                    $("#catlogListView li").removeClass('active');
                    $(this).addClass('active');
                    $('.secondary-catalogList').css('height', '');
                    if ($(this).attr('class') == 'secondary-catalogList active') {
                        if ($('.edit-catlog:visible').offset() != undefined) {
                            var calcIcon = $('.edit-catlog:visible').offset().top - $('.secondary-catalogList.active').offset().top;
                            if (calcIcon > $('.secondary-catalogList.active').height()) {
                                $('.secondary-catalogList.active').css('height', $('.secondary-catalogList.active').outerHeight() + 18 + 'px')
                            }
                        }
                    }
                    $("a#emailCatalog-link").attr('href', '/common/myaccount/emailMyCatalog.jsp?giftId=' + $("#catlogListView li.active").attr('id'));
					if($('#mainContainer > .container').hasClass('myOrderStatuss')){
						$("#cartErrorUrl").val('/common/myaccount/viewMyCatalog.jsp?listId=' + $("#catlogListView li.active").attr('id'));
					}else{
						$("#cartErrorUrl").val('/common/myaccount/viewMyCatalog.jsp?listId=' + $("#catlogListView li.active").attr('id'));
					}                    
                    $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
                    if ($(this).attr('class').split(' ')[0] == "default-Catlog") {
                        $("#empty-catalog").hide();
                        $('.printBlk').css('border-right', '0px');
						$('.printBlk').css('padding-right', '0px');
                    }
                    if ($(this).attr('class').split(' ')[0] == "secondary-catalogList") {
                        $("#empty-catalog").show();
                        $('.printBlk').css('border-right', '1px solid #D0D0CE');
						$('.printBlk').css('padding-right', '');
                    }
                    LSCA.loadingSpinner.showLoading();
                    $('.catalogPagination').html('');
                    $(params_.target).find('table').attr('data-pagenum', '1');
                    LSCA.globalAjax.doCall({
                        url : params_.url + $(this).attr('id'),
                        target : params_.target
                    }, function(response) {
                        LSCA.displayCatalogList.parseme(response, function() {
                            $('.catalogPagination').html('');
                            LSCA.mycatalogaddPaging.makePageNav(params_, function(params_) {
                                LSCA.mycatalogaddPaging.pageData(params_)
                            });
                        });
                        if (params_.callback && typeof (params_.callback) === 'function')
                            params_.callback(params_);
                    });
                }
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;
            var listNoVal="";
            jQuery(".myOrderStatuss.favListEdit1 i").css("display","inline-block");
			listNoVal=jQuery(".giftList-Heading").text().trim();
			$('#viewCatalog input[name=listNameVal]').val(listNoVal);			
			if(jQuery(".myOrderStatuss #catlogListView .default-Catlog").hasClass("active")){
				jQuery(".myOrderStatuss .favListEdit1 i").hide();
			}
			else{				
				jQuery(".myOrderStatuss .favListEdit1 i").css("display","inline-block");
			}
			$(".myOrderStatuss #catlogListView .default-Catlog i").removeClass('active');
			$(".favListEdit1 i").attr("id",$('#catlogListView li.secondary-catalogList.active i').attr("id"));
			$(".favListEdit1").attr("id",$('#catlogListView li.secondary-catalogList.active').attr("id"));
            if (data) {
                LSCA.loadingSpinner.hideLoading();
                var len = data.length;
                if ($(response.target).find('.skyblueTable').length == 0) {
                    tblui = '<table class="skyblueTable">';
                    tblui += '<tbody></tbody>';
                    tblui += '</table>';
                    $(response.target).html(tblui);
                }
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        tblrow = '<tr id=tbl_' + data[i].partNumber + '>';
						if($('#mainContainer > .container').hasClass('myOrderStatuss')){
							if (data[i].designId != ""	&& data[i].designId != undefined) {
								tblrow += ' <td>' + data[i].partNumber + " - "	+ data[i].designId + '</td>';
							} else {
								tblrow += ' <td>' + data[i].partNumber + '</td>';
							}
							}else{
							if (data[i].designId != ""	&& data[i].designId != undefined) {
								tblrow += ' <td><input name="' + data[i].partNumber  +  ':'+data[i].designId + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + ':'+data[i].designId+ '" /></td>';
								tblrow += ' <td>' + data[i].partNumber + " - "	+ data[i].designId + '</td>';
							} else {
								tblrow += ' <td><input name="' + data[i].partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + '" /></td>';
								tblrow += ' <td>' + data[i].partNumber + '</td>';
							} 						
						}	
                        tblrow += ' <td>' + data[i].description + '</td>';
                        tblrow += ' <td>' + data[i].unit + '</td>';
						if(!$('#mainContainer > .container').hasClass('myOrderStatuss')){
                        tblrow += ' <td>' + data[i].catalogAmount + '</td>';
						}
                        tblrow += ' <td>' + data[i].listprice + '</td>';
                        tblrow += ' <td class="yourPrice-List"><span class="tbl-loading"></span></td>';						
						if($('#mainContainer > .container').hasClass('myOrderStatuss')){
						if (data[i].designId != ""	&& data[i].designId != undefined) {
							tblrow += ' <td><input name="' + data[i].partNumber  +  ':'+data[i].designId + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + ':'+data[i].designId+ '" /></td>';							
						} else {
							tblrow += ' <td><input name="' + data[i].partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data[i].partNumber + '" /></td>';
						} 							
						}						
                        tblrow += ' <td class="noPrint"><a href="javascript:void(0);" part-data="' + data[i].skuId + '" class="remove"><i class="fal fa-trash-alt deletePartNo"></i></a></td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                    }
                    $(response.target).find('.skyblueTable tbody').html('');
                    $(response.target).find('.skyblueTable tbody').html(tableData);
                    $('.errorText').text('');
                    $('#error-emptyCart').hide();

                    if ($('#addToCartCheck').val() == '1') {
                        $('#error-messages').show();
                        $('#addToCartCheck').val('0');
                    } else {
                        $('#error-messages').hide();
                    }
                    $("#EnterName").val('');
                    $("#EnterName").removeAttr('style');
                    $('.emailBlk').show();
                    if (data.errorMessage)
                        LSCA.GlobalValidate.showError('', data.errorMessage);
                    if (callback && typeof (callback) == 'function')
                        callback();
                } else {
                    $('.errorText').text(data.message);
                    $('#error-emptyCart').show();

                    if ($('#addToCartCheck').val() == '1') {
                        $('#error-messages').show();
                        $('#addToCartCheck').val('0');
                    } else {
                        $('#error-messages').hide();
                    }
                    $("#EnterName").val('');
                    $("#EnterName").removeAttr('style');
                    $('.emailBlk,.printBlk').hide();
                    $(response.target).find('.skyblueTable tbody').html('');
                }
            } else {
                $('.catalogPagination').html('');
                LSCA.GlobalValidate.showError('', data.errorMessage);
            }
        }
    },
    displayEmailCatalogList : {
        init : function(params_) {
            if ($(document).find('.mainContainer').hasClass('emailCatalog')) {
                LSCA.loadingSpinner.showLoading();
                var emailGiftId = LSCA.getUrlParam('giftId');
                LSCA.globalAjax.doCall({
                    url : params_.url + emailGiftId,
                    target : params_.target
                }, function(response) {
                    LSCA.displayEmailCatalogList.parseme(response, function() {
                        if (params_.callback && typeof (params_.callback) === 'function')
                            params_.callback(params_);
                    });
                });
            }
        },
        parseme : function(response, callback) {
            var data = response.data;
            var tableData;

            if (data) {
                LSCA.loadingSpinner.hideLoading();
                var len = data.length;
                if ($(response.target).find('.skyblueTable').length == 0) {
                    tblui = '<table class="skyblueTable">';
                    tblui += '<tbody></tbody>';
                    tblui += '</table>';
                    $(response.target).html(tblui);
                }
                if (len > 0 && !data.message) {
                    for (var i = 0; i < len; i++) {
                        tblrow = '<tr id=tbl_' + data[i].partNumber + '>';
                        tblrow += ' <td>' + data[i].partNumber + '</td>';
                        tblrow += ' <td>' + data[i].description + '</td>';
                        tblrow += ' <td>' + data[i].unit + '</td>';
                        tblrow += ' <td>' + data[i].catalogAmount + '</td>';
                        tblrow += ' <td>' + data[i].listprice + '</td>';
                        tblrow += ' <td class="yourPrice-List"><span class="tbl-loading"></span></td>';
                        tblrow += '</tr>';
                        tableData += tblrow;
                    }
                    $(response.target).find('.skyblueTable tbody').html('');
                    $(response.target).find('.skyblueTable tbody').html(tableData);
                    // Your Price Email
                    var yourPriceLimit = $("#emailPaginationLimit").val();
                    rowCntRnd1 = Math.ceil($('#catalogEmail table tbody tr').length / yourPriceLimit);
                    var y = 0;
                    var partNoArray1 = [];
                    for (var i = 1; i <= rowCntRnd1; i++) {
                        partNoArray1 = [];
                        $.each($('#catalogEmail table tbody tr').slice(y, i * yourPriceLimit), function(i, item) {
                            console.log($(this).find('td').eq(0).text());
                            partNoArray1.push($(this).find('td').eq(0).text());

                        });
                        LSCA.displayEmailYourPriceList.init({
                            pageid : 'emailCatalog',
                            url : '/common/getPriceForWishList.jsp?listId=' + LSCA.getUrlParam('giftId') + '&catalogIdList=' + partNoArray1.join(),
                            target : '#catalogEmail'
                        });
                        y = i * yourPriceLimit;
                    }
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
            }
        }
    },
    editMyCatalogList : {
        init : function(params_) {
            $(document).on("click",".edit-catlog",function(e) {
                e.preventDefault();
                var valID = $(this).attr('id');
                var splitId = valID.split('-');
                var text = $(this).parent().text();
                var editmaxlength = 30;
                if ($('body').attr('class') == 'zh_CN') {
                    editmaxlength = 60;
                }
                var input = $('<input class="catlogtext-edit" name="catlogtext-edit" maxlength="' + editmaxlength + '" id="text-' + splitId[1] + '" type="text" value="' + text + '" /><i id="edit-'
                        + splitId[1] + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true" style="display:none;"></i>')
                $(this).parent().text('').append(input);
                e.preventDefault();
                var editText = $("#text-" + splitId[1]).val().trim();
                var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                var validList = true;
                if (pattern.test($("#text-" + splitId[1]).val().trim())) {
                    validList = false;
                } else {
                    validList = true
                }
                $('.catlogtext-edit').click(function(event) {
                    event.stopPropagation();
                });
                input.focus();
                input.bind('blur keyup', function(e) {
                    if (e.type == 'blur' || e.keyCode == '13') {
                        if ($("#text-" + splitId[1]).val().trim() != '' && validList) {
                            var pattern1 = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                            var validList1 = true;
                            if (pattern1.test($("#text-" + splitId[1]).val().trim())) {
                                validList1 = false;
                            } else {
                                validList1 = true
                            }
                            if ($("#text-" + splitId[1]).val().trim() != '' && validList1) {
                                LSCA.loadingSpinner.showLoading();
                                $('.catlogtext-edit').removeClass('requiredName');
                                LSCA.globalAjax.doCall({
                                    url : params_.url + 'giftlistId=' + splitId[1] + '&list_name=' + encodeURIComponent($("#text-" + splitId[1]).val()),
                                    target : params_.target
                                }, function(response) {
                                    LSCA.editMyCatalogList.updateCatalogName(response, function() {
                                        LSCA.globalPaginate.init({
                                            prevnext : false
                                        });
                                        if (params_.callback && typeof (params_.callback) === 'function')
                                            params_.callback(params_);
                                    }, splitId[1]);

                                });
                                $('#error-messages').hide();
                                LSCA.GlobalValidate.showError('', '');
                            } else {
                                console.log('else');
                                $('.catlogtext-edit').addClass('requiredName');
                                console.log('validList: ' + validList1);
                                $('#error-messages').show();

                                if ($("#text-" + splitId[1]).val().trim() == '' && validList1) {
                                    LSCA.GlobalValidate.showError('', $('.emptyText-List').text());
                                } else if ($("#text-" + splitId[1]).val().trim() != '' && !validList1) {
                                    LSCA.GlobalValidate.showError('', $('.splchar-error').text());
                                }
                            }
                        } else {
                            console.log('else');
                            $('.catlogtext-edit').addClass('requiredName');
                            console.log('validList: ' + validList);
                            $('#error-messages').show();

                            if ($("#text-" + splitId[1]).val().trim() == '' && validList) {

                                LSCA.GlobalValidate.showError('', $('.emptyText-List').text());
                            } else if ($("#text-" + splitId[1]).val().trim() != '' && !validList) {

                                LSCA.GlobalValidate.showError('', $('.splchar-error').text());
                            }
                            validList = true;
                        }
                    }
                    e.stopPropagation();
                });
                e.stopPropagation();
            });
        },
        updateCatalogName : function(response, callback, gifteditId) {
            var textsplitId = gifteditId;
            if (response.data.status == 'success') {
                LSCA.loadingSpinner.hideLoading();
                var text1 = $('#text-' + textsplitId).val();
                var savedtext = $('<i id="edit-' + textsplitId + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true"></i>')
                $('#text-' + textsplitId).parent().text(response.data.catalogListName).append(savedtext);
                $('#text-' + textsplitId).remove();
                $(".giftList-Heading,#custom-main-wrapper-expand .myOrderStatuss .prnt-header-subtitle .current-favlist").text($("#catlogListView li.active").text());
                $('.secondary-catalogList').css('height', '');
                if ($('.edit-catlog:visible').offset() != undefined) {
                    var calcIcon = $('.edit-catlog:visible').offset().top - $('.secondary-catalogList.active').offset().top;
                    if (calcIcon > $('.secondary-catalogList.active').height()) {
                        $('.secondary-catalogList.active').css('height', $('.secondary-catalogList.active').outerHeight() + 18 + 'px')
                    }
                }
            }
        }
    },
    editMyCatalogList1 : {		
        init : function(params_) {
            $(document).on("click",".viewMyCatalog .editFavList",function(e) {
                e.preventDefault();	
				$("#hiddenStrVal").remove();					
                var valID = $(this).attr('id');
                var splitId = valID.split('-');
                var text = $(this).parent().text();
                var editmaxlength = 30;
                if ($('body').hasClass('zh_CN')) {
                    editmaxlength = 30;
                }
                var input = $('<input class="catlogtext-edit" name="catlogtext-edit" maxlength="' + editmaxlength + '" id="text-' + splitId[1] + '" type="text" value="' + text + '" /><i id="edit-'
                        + splitId[1] + '" class="fal fa-pencil editFavList" aria-hidden="true" style="display:none;"></i>')
                $(this).remove();
				$(".favListEdit1 i").remove();
				input.insertAfter(jQuery(".giftList-Heading"));
				$.fn.textWidth = function(text) {
					if (!$.fn.textWidth.fakeEl) $.fn.textWidth.fakeEl = $('<span id="hiddenStrVal">').hide().appendTo(document.body);
					$.fn.textWidth.fakeEl.text(text || this.val());
					return $.fn.textWidth.fakeEl.width();
				};

				$('.catlogtext-edit').on('input', function(e) {
					var textWidthVal = $(this).textWidth() + 20 + 'px';
					$(this).css('width', textWidthVal);
				}).trigger('input');
				$('.giftList-Heading').hide();
				$('.catlogtext-edit').val($('.giftList-Heading').text().trim());
				$('.catlogtext-edit').css("display","inline-block");
                e.preventDefault();
                var editText = $("#text-" + splitId[1]).val().trim();
                var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                var validList = true;
                if (pattern.test($("#text-" + splitId[1]).val().trim())) {
                    validList = false;
                } else {
                    validList = true;
                }
                $('.catlogtext-edit').click(function(event) {
                    event.stopPropagation();
                });
                input.focus();				
                input.bind('blur keyup', function(e) {
                    if (e.type == 'blur' || e.keyCode == '13') {
                        if ($("#text-" + splitId[1]).val().trim() != '' && validList) {
                        	jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                            var pattern1 = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                            var validList1 = true;
                            if (pattern1.test($("#text-" + splitId[1]).val().trim())) {
                                validList1 = false;
                            } else {
                                validList1 = true;
                            }
                            if ($("#text-" + splitId[1]).val().trim() != '' && validList1) {
                            	jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                                LSCA.loadingSpinner.showLoading();
                                $('.catlogtext-edit').removeClass('requiredName');
                                LSCA.globalAjax.doCall({
                                    url : params_.url + 'giftlistId=' + splitId[1] + '&list_name=' + encodeURIComponent($("#text-" + splitId[1]).val()),
                                    target : params_.target
                                }, function(response) {
                                    LSCA.editMyCatalogList1.updateCatalogName1(response, function() {
                                        LSCA.globalPaginate.init({
                                            prevnext : false
                                        });
                                        if (params_.callback && typeof (params_.callback) === 'function')
                                            params_.callback(params_);
                                    }, splitId[1]);

                                });
                                $('#error-messages').hide();
                                LSCA.GlobalValidate.showError('', '');
                            } else {
                            	jQuery("#mycatlogList ul li").addClass("hide-pointer");
                                $('.catlogtext-edit').addClass('requiredName');
                                //console.log('validList: ' + validList1);                                
                                if ($("#text-" + splitId[1]).val().trim() == '' && validList1) {
                                    //LSCA.GlobalValidate.showError('', $('.emptyText-List').text());
									$('#error-messages').hide();
									$('.favListEdit1 .catlogtext-edit').remove();
									$('.favListEdit1 .giftList-Heading').text($('.favListEdit1 .giftList-Heading').text());
									$(".favListEdit1 .giftList-Heading").show();
									$(".editFavList").show();
									$(".catlogListView ul li.active").text($('.favListEdit1 .giftList-Heading').text());
									jQuery("#mycatlogList ul li").removeClass("hide-pointer");
                                } else if ($("#text-" + splitId[1]).val().trim() != '' && !validList1) {
                                    LSCA.GlobalValidate.showError('', $('.splchar-error').text());
									$('#error-messages').show();
                                }
                            }
                        } else {
                            $('.catlogtext-edit').addClass('requiredName');
                            jQuery("#mycatlogList ul li").addClass("hide-pointer");
                            if ($("#text-" + splitId[1]).val().trim() == '' && validList) {
                                //LSCA.GlobalValidate.showError('', $('.emptyText-List').text());
								$('#error-messages').hide();
								$('.favListEdit1 .catlogtext-edit').remove();
								$('.favListEdit1 .giftList-Heading').text($('.favListEdit1 .giftList-Heading').text());
								$(".favListEdit1 .giftList-Heading").show();
								$(".editFavList").show();
								$(".catlogListView ul li.active").text($('.favListEdit1 .giftList-Heading').text());
								jQuery("#mycatlogList ul li").removeClass("hide-pointer");								
                            } else if ($("#text-" + splitId[1]).val().trim() != '' && !validList) {
                                LSCA.GlobalValidate.showError('', $('.splchar-error').text());
								$('#error-messages').show();
                            }
                            validList = true;
                        }
                    }
                    e.stopPropagation();
                });
                e.stopPropagation();
            });
        },
        updateCatalogName1 : function(response, callback, gifteditId) {			
            var textsplitId = gifteditId;
            if (response.data.status == 'success') {				
                LSCA.loadingSpinner.hideLoading();
				//$(".giftList-Heading").text("");
                var text1 = $('#text-' + textsplitId).val();
                var savedtext = $('<i id="edit-' + textsplitId + '" class="fal fa-pencil editFavList" aria-hidden="true"></i>')
                //$('#text-' + textsplitId).siblings(".giftList-Heading").text(response.data.catalogListName).append(savedtext);
				$('#text-' + textsplitId).siblings(".giftList-Heading").text(response.data.catalogListName);
				$(".giftList-Heading").siblings("i").show();
				$(".giftList-Heading").css("display","inline-block");
				//$(".giftList-Heading i").css("display","inline-block");
                $('#text-' + textsplitId).remove();
				$(".mycatlogList ul li.active").text($(".giftList-Heading").text());
                $('.secondary-catalogList').css('height', '');
                if ($('.edit-catlog:visible').offset() != undefined) {
                    var calcIcon = $('.edit-catlog:visible').offset().top - $('.secondary-catalogList.active').offset().top;
                    if (calcIcon > $('.secondary-catalogList.active').height()) {
                        $('.secondary-catalogList.active').css('height', $('.secondary-catalogList.active').outerHeight() + 18 + 'px')
                    }
                }
            }
        }
    },
    linkMyCatalogList : {
        init : function(params_) {
            if ($("#mainContainer").hasClass('cartPage')) {
                $(document).on("click", "#createcatlog-list", function(e) {
                    console.log('cart');
                    e.preventDefault();
                    var newText = $("#catlogName").val().trim();
                    var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                    var validList = true;
                    if (pattern.test(newText)) {
                        validList = false;
                    } else {
                        validList = true
                    }
                    if (newText != '' && validList) {
                        LSCA.loadingSpinner.showLoading();

                        LSCA.globalAjax.doCall({
                            url : params_.url + encodeURIComponent(newText),
                            target : params_.target
                        }, function(response) {
                            LSCA.linkMyCatalogList.addcatalogoverlay(response, function() {
                                if (params_.callback && typeof (params_.callback) === 'function')
                                    params_.callback(params_);
                            });
                        });
                        $('#error-msg').hide();
                        $('#catlogName').removeClass('requiredName');
                        $('.listnameLabel').removeClass('labelrequired');
                    } else {
                        $('#error-msg').show();
                        if (newText == '') {
                            $(".emptyText-List").show();
                            $(".splchar-error").hide();
                            $(".nospecialLabel").hide();
                            $('.listnameLabel').addClass('labelrequired');
                        } else if (!validList && newText != '') {
                            $(".splchar-error").show();
                            $(".emptyText-List").hide();
                            $(".nospecialLabel").hide();
                            $('.listnameLabel').addClass('labelrequired');
                        }
                        $('#catlogName').addClass('requiredName');
                    }
                });
            }
        },
        addcatalogoverlay : function(response, callback) {
            var data = response.data;
            if (data.errorMessage != '') {
                LSCA.loadingSpinner.hideLoading();
                $('#maxLimit-messages').show();
                $('#maxLimit-messages').html('<i class="fal fa-exclamation-circle"></i><span>' + data.errorMessage+ '</span>');
                $("#myCatalogModal button.close").trigger('click');
                $("#myCatalogModalCart .close").trigger('click');
            } else if (data.showSuccessMessage) {
                if (data.catalogListId) {
                    $("#error-msg").hide();
                    $(".service-error").hide();
                    $('#maxLimit-messages').hide();
                    LSCA.loadingSpinner.hideLoading();
                    $('#tooltip_' + $("#selected_partNo").val() + ' ul.giftListView').append('<li id=' + data.catalogListId + ' class="giftListItem">' + data.catalogListName + '</li>');
                    $("#" + data.catalogListId).trigger('click');
                }
            }
        }
    },
        linkMyCatalogListNew : {
            init : function(params_) {
                if ($("#mainContainer").hasClass('shoppingCartPage')) {
                    $(document).on("click", "#createcatlog-list", function(e) {
                        console.log('cart');
                        e.preventDefault();
                        var newText = $("#catlogName").val().trim();
                        var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                        var validList = true;
                        if (pattern.test(newText)) {
                            validList = false;
                        } else {
                            validList = true
                        }
                        if (newText != '' && validList) {
                            LSCA.loadingSpinner.showLoading();

                            LSCA.globalAjax.doCall({
                                url : params_.url + encodeURIComponent(newText),
                                target : params_.target
                            }, function(response) {
                        
                                LSCA.linkMyCatalogListNew.addcatalogoverlay(response, function() {
                                    if (params_.callback && typeof (params_.callback) === 'function')
                                        params_.callback(params_);
                                });
                            });
                            $('#error-msg').hide();
                            $('#catlogName').removeClass('requiredName');
                            $('.listnameLabel').removeClass('labelrequired');
                        } else {
                            $('#error-msg').show();
                            if (newText == '') {
                                $(".emptyText-List").show();
                                $(".splchar-error").hide();
                                $(".nospecialLabel").hide();
                                $('.listnameLabel').addClass('labelrequired');
                            } else if (!validList && newText != '') {
                                $(".splchar-error").show();
                                $(".emptyText-List").hide();
                                $(".nospecialLabel").hide();
                                $('.listnameLabel').addClass('labelrequired');
                            }
                            $('#catlogName').addClass('requiredName');
                        }
                    });
                }
            },
        addcatalogoverlay : function(response, callback) {
            var data = response.data;
            if (data.errorMessage != '') {
                LSCA.loadingSpinner.hideLoading();
				$('.errorCatalogTooltip.maxLimitError').hide();
                //$('#maxLimit-messages_'+ $("#selected_partNo").val()).show();
				$('#maxLimit-messages_'+ $("#selected_partNo").val()).css('display','flex');
                $('#maxLimit-messages_'+ $("#selected_partNo").val()).html('<i class="fal fa-exclamation-circle"></i><span>' + data.errorMessage+ '</span>');
                $("#myCatalogModal button.close").trigger('click');
                $("#myCatalogModalCart .close").trigger('click');
				 setTimeout(function() {
                    $('#maxLimit-messages_'+ $("#selected_partNo").val()).hide();
                }, 7000);
            } else if (data.showSuccessMessage) {
                if (data.catalogListId) {
                    $("#error-msg").hide();
                    $(".service-error").hide();
                    $('.errorCatalogTooltip.maxLimitError').hide();
                    LSCA.loadingSpinner.hideLoading();
                    $('#tooltip_' + $("#selected_partNo").val() + ' ul.giftListView').append('<li id=' + data.catalogListId + ' class="giftListItem">' + data.catalogListName + '</li>');
                    $("#" + data.catalogListId).trigger('click');
                }
            }
        }
    },
    createMyCatalogList : {
        init : function(params_) {
            if ($("#mainContainer").hasClass('viewMyCatalog')) {
                $(document).on("click", "#createcatlog-list", function(e) {
                    console.log('viewmycatalog');
                    e.preventDefault();
                    var newText = $("#catlogName").val().trim();
                    var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
                    var validList = true;
                    if (pattern.test(newText)) {
                        validList = false;
                    } else {
                        validList = true
                    }
                    if (newText != '' && validList) {
                        LSCA.loadingSpinner.showLoading();
                        LSCA.globalAjax.doCall({
                            url : params_.url + encodeURIComponent(newText),
                            target : params_.target
                        }, function(response) {
                            LSCA.createMyCatalogList.parseme(response, function() {
                                if (params_.callback && typeof (params_.callback) === 'function')
                                    params_.callback(params_);
                            });
                        });
                        $('#error-msg').hide();
                        $('#catlogName').removeClass('requiredName');
                        $('.listnameLabel').removeClass('labelrequired');
                    } else {
                        $('#error-msg').show();
                        if (newText == '') {
                            $(".emptyText-List").show();
                            $(".splchar-error").hide();
                            $(".nospecialLabel").hide();
                            $('.listnameLabel').addClass('labelrequired');
                        } else {
                            $(".splchar-error").show();
                            $(".emptyText-List").hide();
                            $(".nospecialLabel").hide();
                            $('.listnameLabel').addClass('labelrequired');
                        }
                        $('#catlogName').addClass('requiredName');
                    }
                });
            }
        },
        parseme : function(response, callback) {
            var data = response.data;
            if (data.catalogListId) {
                LSCA.loadingSpinner.hideLoading();
                if ($(document).find(response.target).length > 0) {
                    var liList = '<li id="' + data.catalogListId + '" class="secondary-catalogList">' + data.catalogListName + '<i id="edit-' + data.catalogListId
                            + '" class="fa fa-pencil fa-2 edit-catlog" aria-hidden="true"></i></li>';
                    $(response.target).find('#catlogListView').append(liList);
                    setTimeout(function() {
                        $("#myCatalogModal button.close").trigger('click');
                        $("#myCatalogModalCart .close").trigger('click');
                    }, 0);
                }
            } else {
                LSCA.loadingSpinner.hideLoading();
                $("#myCatalogModal button.close").trigger('click');
                $("#myCatalogModalCart .close").trigger('click');
                LSCA.GlobalValidate.showError('', data.errorMessage);
            }
        }
    },
    viewMyCatalogAddItem : {
        init : function(params_) {
            $('#addpartno').on('submit', function(e) {
                e.preventDefault();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#addpartno',
                    action : 'submit'
                });
                if (dovalidate) {
                    LSCA.loadingSpinner.showLoading();
                    LSCA.globalAjax.doCall({
                        url : params_.url + 'giftlistId=' + $("#catlogListView li.active").attr('id') + '&part_number=' + $(this).find("#EnterName").val().trim() + '&pageSource=mycatalog',
                        target : params_.target
                    }, function(response) {
                        LSCA.viewMyCatalogAddItem.parseme(response, function() {
                            LSCA.mycatalogaddPaging.makePageNav(params_, function(params_) {
                                LSCA.mycatalogaddPaging.pageData(params_)
                            });
                            LSCA.removeRowItem.init({
                                pageid : 'viewMyCatalog',
                                url : '/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=',
                                target : '#viewCatalog'
                            });
                        });
                    });
                } else {
                    LSCA.GlobalValidate.showError('', $('#enterPartNo').val());
                }
            });
        },
        parseme : function(response, callback) {
            var data = response.data;
            if(data.invalidPartDetails){
            	jQuery("#invalidPartsVal").val(data.invalidPartDetails);
            }
            if (data.partNumber) {
                LSCA.loadingSpinner.hideLoading();
                if ($(document).find(response.target).length > 0) {
                    if ($(response.target).find('.skyblueTable').length == 0) {
                        tblui = '<table class="skyblueTable">';
                        tblui += '<tbody></tbody>';
                        tblui += '</table>';
                        $(response.target).html(tblui);
                    }
                    if ($(response.target).find('.skyblueTable tbody tr:visible').length == 5) {
                        tblrow = '<tr id=tbl_' + data.partNumber + ' style="display:none">';
                    } else {
                        tblrow = '<tr id=tbl_' + data.partNumber + '>';
                    }		

					if(!$('#mainContainer > .container').hasClass('myOrderStatuss')){
                    tblrow += ' <td><input name="' + data.partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data.partNumber + '" /></td>';						
					}
					
                    tblrow += ' <td>' + data.partNumber + '</td>';
                    tblrow += ' <td>' + data.descripttion + '</td>';
                    tblrow += ' <td>' + data.unit + '</td>';
					if(!$('#mainContainer > .container').hasClass('myOrderStatuss')){
                    tblrow += ' <td>' + data.amount + '</td>';
					}
                    tblrow += ' <td>' + data.listprice + '</td>';
                    tblrow += ' <td class="yourPrice-List"><span class="tbl-loading"></span></td>';
					if($('#mainContainer > .container').hasClass('myOrderStatuss')){
                    tblrow += ' <td><input name="' + data.partNumber + '" type="text" value="" class="qtyTxtbox" maxlength="4"/><input name="partNumber" type="hidden" value="' + data.partNumber + '" /></td>';						
					}
                    tblrow += ' <td class="noPrint"><a href="javascript:void(0);" part-data="' + data.skuId + '" class="remove"><i class="fal fa-trash-alt deletePartNo"></i></a></td>';
                    tblrow += '</tr>';
                    if ($(response.target).find('.skyblueTable tbody').find("tr:last-child").length == 0) {
                        $(response.target).find('.skyblueTable tbody').append(tblrow);
                    } else {
                        var lastTrId = $(response.target).find('.skyblueTable tbody').find("tr:last-child").attr('id');
                        console.log(lastTrId);
                        $("#" + lastTrId).after(tblrow);
                    }
                    $("#EnterName").val('');
                    $("#EnterName").removeAttr('style');
                    $('.errorText').text('');
                    $('#error-emptyCart').hide();
                    $('.emailBlk').show();
                    if (callback && typeof (callback) == 'function')
                        callback();
                } else {
                    $('.emailBlk,.printBlk').hide();
                }
            } else {
                LSCA.GlobalValidate.showError('', data.errorMessage);
                LSCA.loadingSpinner.hideLoading();
            }
        }
    },
    qckOrderIframe : {
        init : function(params_) {
            $(params_.target).click(function() {
                $(params_.selector).css('height', '400px');
                var iframeBlk = $(params_.selector).attr('src');
                $(params_.selector).attr('src', iframeBlk);
            });
        }
    },
    qcklgOrderIframe : {
        init : function(params_) {
            $(params_.target).click(function() {
                $(params_.selector).css('height', '400px');
                var iframeBlk = $(params_.selector).attr('src');
                $(params_.selector).attr('src', iframeBlk);
            });
        }
    },
    qckOrderViewInventory : {
        init : function(params_) {
            $(params_.target).click(function() {
                $(params_.selector).css('height', '400px');
                var iframeBlk = $(params_.selector).attr('src');
                $(params_.selector).attr('src', iframeBlk);

            });
        }
    },
    clickShow : function(params_) {
        $(params_.target).click(function() {
            $(params_.selector).toggle();
        })
    },
    prodFilter : {
        init : function(params_) {
            if ($(document).find('.mainContainer').hasClass(params_.pageId)) {
                $(params_.target).attr('data-pagenum', '1');
                LSCA.globalAjax.doCall({
                    url : params_.url + '?catId=' + $(params_.target).attr('param-data'),
                    target : params_.target
                }, function(options_) {
                    LSCA.prodFilter.parseData(options_, function() {
                        LSCA.prodFilter.addFilter({
                            target : params_.target
                        }, function(params_) {
                            LSCA.prodFilter.addAction(params_);
                            LSCA.prodFilter.submitPart({
                                target : params_.target,
                                selector : ".yourprice",
                                url : $(params_.target + ' #yourprice').attr('href')
                            });
                            LSCA.prodFilter.submitPart({
                                target : params_.target,
                                selector : ".addtocart",
                                url : $(params_.target + ' form').attr('action')
                            });
                            LSCA.prodFilter.resetFilter(params_);
                            LSCA.prodFilter.addPaging.makePageNav(params_, function(params_) {
                                LSCA.prodFilter.addPaging.pageData(params_)
                            });
                            if ($(params_.target).find('thead th.dynamic').length < 1)
                                $(document).find('.resetfilter').hide();
                        });
                    });
                });
            }
        },
        parseData : function(params_, callback) {
            var data = params_.data, tblui = '', dropval = [], dataCnt = 0;
            for (dataObj in data)
                dataCnt++, vCnt = 0, hide = '', price = '', yp = '';
            if (dataCnt > 0) {
                var qtylocal = $(params_.target).find('#localizedQty').text();
                $.each(data, function(o, k) {
                    if (o != 'extra') {
                        if (o === "headerDataVo") {
                            tblui = '<table class="skyblueTable"><thead>';
                            tpart = 'h';
                        } else {
                            tblui += '<tbody>';
                            tpart = 'b';
                        }
                        $.each(k, function(i, v) {
                            if (tpart === 'h') {
                                for (vObj in v['dynamicFields'])
                                    vCnt++;
                                hide = (vCnt > 2) ? 'hide ' : '';
                            }
                            tblui += (tpart === 'h') ? '<tr><th>' + qtylocal + '</th>' : '<tr id="' + v.partNumber + '">';
                            $.each(v, function(j, w) {
                                isdynamic = (j === 'dynamicFields') ? ' dynamic' : '';
                                if (typeof (w) !== 'object') {
                                    if (tpart === 'b') {
                                        if (j === 'partNumber') {
                                            tblui += '<td><input name="' + w + '" type="text" value="" class="textboxQnt" maxlength="3" /><input name="partNumber" type="hidden" value="' + w + '" /></td>';
                                        }
                                        if (j === 'productId') {
                                            proid = w;
                                        }
                                        if (j === 'productURl') {
                                            uri = w;
                                        }
                                    }
                                    if (j !== 'productURl' && j != 'productId') {
                                        w = (tpart === 'b' && j === 'partNumber') ? '<a href="' + uri + '&navCount=' + lableObject['navCount'] + '" >' + w + '</a>' : w;
                                        hideme = (j === 'description' && hide != '') ? hide : '';
                                        if (j === 'price') {
                                            price = 'price', yp = '</br><span><img src="/store/images/loading-small.gif" alt="Loading..." style="display:none" /></span>', nowrap = ' nowrap="nowrap"';
                                        } else {
                                            price = '', yp = '', nowrap = '';
                                        }
                                        tblui += (tpart === 'h') ? '<th class="' + hideme + '">' + w + '</th>' : '<td class="' + hideme + price + '"' + nowrap + '>' + w + yp + '</td>';
                                    }
                                } else {
                                    dynCnt = 0;
                                    $.each(w, function(k, x) {
                                        tblui += (tpart === 'h') ? '<th class="' + isdynamic + '"><ul><li class="dropdown"><span data-toggle="dropdown"  data-fltrkey=' + dynCnt + '-' + x.replace(/\s/g, '')
                                                + ' class="dropdown-toggle">' + x + '<span class="caret"></span></span></th>' : '<td class="' + isdynamic + '">' + x + '</td>';
                                        dynCnt++;
                                    });
                                }
                            });
                            tblui += '</tr>';
                        });
                        tblui += (tpart === 'h') ? '</thead>' : '</tbody></table>';
                    }
                });
                msg = data.extra;
                $(msg).each(function(i, v) {
                    if (v.message && v.message != null) {
                        $('.alert').find('span').html(v.message);
                        $('.alert').show();
                    }
                });
                $(document).find(params_.target + ' form').prepend(tblui);
                $(params_.target).find('.loader').hide();
                if (callback && typeof (callback) == 'function')
                    callback();
                LSCA.replaceSpecialChar({
                    target : '.textboxQnt'
                });
            } else {
                $(params_.target).find('.prodConf').hide();
            }
        },
        addFilter : function(params_, callback) {
            var DyCnt = $(params_.target).find('thead th.dynamic').length, fltrArr = params_.fltrArr || [], fltrArrObj = [], matrixui = '';
            for (k in fltrArr) {
                if (fltrArr[k] != 'All')
                    fltrArrObj.push(k);
            }
            $(params_.target).find('thead th.dynamic').each(function(i, v) {
                var valarr = [], list = '', menuui = '', allCnt = 0, fltrCnt = 0, lastfltr = 0, visibleonly = '', fltrel = $(this).find('li.dropdown > ul.dropdown-menu');
                clmKey = $(this).find('span:eq(0)').attr('data-fltrkey') || '';
                clmVal = $(this).find('span:eq(0)').attr('data-fltrval') || '';
                if (fltrArr != '')
                    $.each(fltrArr, function(a, b) {
                        fltrCnt++;
                        if (b === 'All')
                            allCnt++;
                    });
                if (allCnt === DyCnt) {
                    fltrCnt = 0;
                    fltrArr = [];
                    params_.rowarr = []
                }
                if (fltrCnt > 0) {
                    visibleonly = (clmKey === fltrArrObj[(fltrArrObj.length) - 1] || fltrArrObj[(fltrArrObj.length) - 1] == undefined) ? '' : '.data-fltr';
                } else {
                    visibleonly = '';
                }
                $(params_.target).find('tbody tr' + visibleonly).each(function() {
                    dynel = $(this).find('td.dynamic').get(i);
                    dynval = $.trim($(dynel).text());
                    if (dynval != '') {
                        if ($.inArray(dynval, valarr) == -1)
                            valarr.push(dynval);
                    }
                });
                valarr = valarr.sort(function(a, b) {
                    return a - b
                });
                valarr.unshift('All');
                matrixui += '<li>';
                matrixui += $(this).find('li.dropdown:eq(0) > span').text() + ' : ';
                matrixui += (clmVal !== '' && clmVal !== 'All') ? clmVal : 'All';
                matrixui += '</li>';
                $.each(valarr, function(j, w) {
                    list += '<li>' + w + '</li>';
                });
                menuui = '<ul id="refinement" class="dropdown-menu drFilter pull-right" data-refinement-type="">' + list + '</ul>';
                if (fltrel.length < 1) {
                    $(this).find('li.dropdown').append(menuui);
                } else {
                    $(this).find('li.dropdown > ul.dropdown-menu').remove();
                    if (valarr.length > 0) {
                        $(this).find('li.dropdown').append(menuui);
                    }
                }
                if ($(this).find('.dropdown-toggle').attr('data-fltrval') && $(this).find('.dropdown-toggle').attr('data-fltrval') !== '' && $(this).find('.dropdown-toggle').attr('data-fltrval') !== 'All') {
                    $(this).find('span.caret').addClass('fltr');
                } else {
                    $(this).find('span.caret').removeClass('fltr');
                }
            });
            if (callback && typeof (callback) == 'function')
                callback(params_);
        },
        addAction : function(params_) {
            var fltrOn = params_.fltrArr || {}, rowarr = params_.rowarr || '', resultarr = [], refinerow2 = [], qryval = '', DyCnt = 0, doAll = 0;
            tRowCnt = (rowarr.length > 0) ? rowarr.length : $(params_.target).find('tbody tr').length;
            $(params_.target).find('thead th.dynamic').each(function(i, v) {
                DyCnt++;
                $(v).find('ul.dropdown-menu > li').on('click', function() {
                    var fltrval = $(this).text(), srchCnt = 0, dynIndex;
                    $(this).parent('ul').attr('data-refinement-type', fltrval);
                    $(this).parents('li.dropdown').removeClass('open');
                    $(v).find('span.dropdown-toggle').attr('data-fltrval', fltrval);
                    fltrOn[$(v).find('span.dropdown-toggle').attr('data-fltrkey')] = fltrval;
                    clmVal = $(this).find('span:eq(0)').attr('data-fltrval') || '';
                    $.each(fltrOn, function(e, q) {
                        srchCnt++;
                        var refinerow = [];
                        if (q !== 'All' && resultarr.length === 0)
                            refinerow2 = [];
                        dynIndex = e.split('-');
                        $(params_.target).find('tbody tr').each(function(j, w) {
                            el = ($(this).find('td.dynamic').get(dynIndex[0]));
                            qryval = $.trim($(el).text());
                            if (q == qryval && qryval != '') {
                                if (resultarr.length != 0) {
                                    if ($.inArray(j, resultarr) !== -1)
                                        refinerow.push(j);
                                    refinerow2 = refinerow;
                                } else {
                                    refinerow2.push(j);
                                }
                            }
                        });
                        resultarr = refinerow2;
                    });
                    $(params_.target).find('th.dynamic span.dropdown-toggle').each(function(i, v) {
                        if ($(this).attr('data-fltrval') == 'All' || $(this).attr('data-fltrval') == undefined || $(this).attr('data-fltrval') == '') {
                            doAll++;
                        }
                    });
                    rowarr = (doAll === DyCnt) ? [] : params_.rowarr;
                    rowarr = (resultarr.length > 0) ? resultarr : rowarr;
                    $(params_.target).find('tbody tr').removeClass('data-fltr');
                    if (rowarr.length > 0) {
                        $(params_.target).find('tbody tr').hide();
                        $(params_.target).attr('fltr-applied', 'true');
                        $(rowarr).each(function(i, v) {
                            $(params_.target).find('tbody tr:eq(' + v + ')').addClass('data-fltr');
                        });
                    } else {
                        $(params_.target).attr('fltr-applied', '');
                    }
                    LSCA.prodFilter.addFilter({
                        target : params_.target,
                        fltrindex : i,
                        fltrArr : fltrOn,
                        rowarr : rowarr
                    }, function(params_) {
                        LSCA.prodFilter.addAction(params_);
                    });
                    $(params_.target).attr('data-pagenum', '1');
                    if ($(params_.target).attr('fltr-applied') != undefined) {
                        LSCA.prodFilter.addPaging.makePageNav({
                            target : params_.target
                        }, function(params_) {
                            LSCA.prodFilter.addPaging.pageData(params_)
                        });
                    }
                });
            });
        },
        resetFilter : function(params_) {
            $('.resetfilter').on('click', function() {
                $(params_.target).find('thead th.dynamic').each(function(i, v) {
                    $(v).find('span.dropdown-toggle').attr('data-fltrval', 'All');
                    $(this).find('ul.dropdown-menu > li').off('click', function() {
                    });
                });
                $(params_.target).attr('fltr-applied', '');
                $(params_.target).find('tbody tr').removeClass('data-fltr');
                $(params_.target).attr('data-pagenum', '1');
                LSCA.prodFilter.addFilter({
                    target : params_.target
                }, LSCA.prodFilter.addAction);
                LSCA.prodFilter.addPaging.makePageNav(params_, function(params_) {
                    LSCA.prodFilter.addPaging.pageData(params_)
                });
            })
        },
        setYourPrice : function(params_) {
            $.each(params_.data, function(i, v) {
                if ($(params_.target + ' #' + i).find('td.price > span').text() === '')
                    $(params_.target + ' #' + i).find('td.price > span').append('<strong>' + v + '</strong>');
            })
            $(params_.target).find('td.price > span img').hide();
        },
        submitPart : function(params_) {
            $(params_.target).find('form').on('submit', function(e) {
                e.preventDefault()
            });
            $(params_.target).find(params_.selector).on('click',function(e) {
                var msgui = '', msgui2 = '';
                e.preventDefault();
                LSCA.imageLoader.init({
                    target : params_.target
                });
                formdata = $(params_.target + ' form').serialize();
                if ($(this).attr('id') === 'yourprice')
                    $(params_.target).find('td.price > span img').show();
                    LSCA.globalAjax.doCall({
                    url : params_.url,
                    dataType : 'json',
                    data : formdata
                },
                function(data) {
                    var data = data.data;
                    if (data.obj1 && data.obj1.message != '') {
                        msgui = (data.obj1.status === 'success') ? '<div class="alert alert-dismissable alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
                                + data.obj1.message + '</div>' : '<div class="alert alert-dismissable alert-error"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
                                    + data.obj1.message + '</div>';
                    }
                    if (data.obj2 && data.obj2.message != '') {
                        msgui2 = (data.obj2.status === 'failure') ? '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
                                + data.obj2.message + '</div>' : '<div class="alert alert-dismissable alert-error"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'
                                    + data.obj2.message + '</div>';
                    }
                    $(document).find('div.errorMessages:eq(0)').html(msgui + msgui2).show();
                    if (data.cartCountToUpdate && data.cartCountToUpdate != '') {
                        $(document).find("#cartcount").html("(" + data.cartCountToUpdate + ")");
                        $(document).find(".cartNum").html(data.cartCountToUpdate);
                        $(params_.target).find("input[type='text']").val("");
                    } else {
                        LSCA.prodFilter.setYourPrice({
                            target : params_.target,
                            data : data
                        });
                    }
                    $(params_.target).find('#loader').parents('ul').remove();
                });
            });
        },
        addPaging : {
            init : function(params_) {
                LSCA.prodFilter.addPaging.makePageNav(params_, function(params_) {
                    LSCA.prodFilter.addPaging.pageData(params_)
                });
            },
            makePageNav : function(params_, callback) {
                var $rowbody = $(params_.target).find('tbody') || '', tRowCnt = $rowbody.find('tr').length || 0, limit = params_.limit || 10, nums = '', onpage = parseInt($(params_.target).attr('data-pagenum'));
                tRowCnt = ($(params_.target).attr('fltr-applied') == 'true') ? $rowbody.find('tr.data-fltr').length : $rowbody.find('tr').length;
                rowCntRnd = Math.ceil(tRowCnt / limit);
                if (tRowCnt > limit) {
                    nums += (onpage === 1) ? '<li><span class="gray">&lt;</span></li>' : '<li><a class="prev" href="#">&lt;</a></li>';
                    nums += (onpage === 1) ? '<li><span class="gray">1</span></li>' : '<li><a href="#">1</a></li>';
                    if (onpage > 5) {
                        nums += '<li class="ellipsis"><span>...</span></li>';
                    }
                    if (onpage - 5 > 0) {
                        if (onpage < rowCntRnd - 2) {
                            s = onpage - 3;
                            e = onpage + 2;
                        } else {
                            s = rowCntRnd - 5;
                            e = rowCntRnd - 1;
                        }
                    } else {
                        if (rowCntRnd > 10) {
                            s = 1;
                            e = 5;
                        } else {
                            s = 1;
                            e = rowCntRnd - 1;
                        }
                    }
                    for (i = s; i < e; i++) {
                        nums += (onpage === i + 1) ? '<li><span class="gray">' + (i + 1) + '</span></li>' : '<li><a href="#">' + (i + 1) + '</a></li>';
                    }
                    if (rowCntRnd - 3 > onpage) {
                        nums += '<li class="ellipsis"><span>...</span></li>';
                    }
                    nums += (onpage === rowCntRnd) ? '<li><span class="gray">' + rowCntRnd + '</span></li>' : '<li><a href="#">' + rowCntRnd + '</a></li>';
                    nums += (onpage === rowCntRnd) ? '<li><span class="gray">&gt;</span></li>' : '<li><a class="next" href="#">&gt;</a></li>';
                }
                $('.paginate').html(nums);

                params_.limit = limit;
                fltron = ($(params_.target).attr('fltr-applied') == 'true') ? '.data-fltr' : '';
                if (parseInt($(params_.target).attr('data-pagenum')) === 1) {
                    $rowbody.find('tr').hide();
                    $(params_.target).find('img').hide();
                    $(params_.target).find('tbody tr' + fltron).each(function(i, v) {
                        $(this).show();
                        if (i == limit - 1)
                            return false;
                    });
                }
                $('.paginate').find('a').off('click');
                if (callback && typeof (callback) == 'function')
                    callback(params_);
            },
            pageData : function(params_) {
                var $rowbody = $(params_.target).find('tbody') || '', limit = params_.limit, onpage = parseInt($(params_.target).attr('data-pagenum')), startat = 0;
                $('.paginate').find('a').on('click', function(e) {
                    e.preventDefault();
                    navto = parseInt($(this).text());
                    if ($(this).hasClass('prev')) {
                        navto = onpage - 1;
                    } else if ($(this).hasClass('next')) {
                        navto = onpage + 1;
                    }
                    fltron = ($(params_.target).attr('fltr-applied') == 'true') ? '.data-fltr' : '';
                    if (navto > onpage) {
                        startat = (((navto - 1) * limit) - 1);
                    } else if (navto != onpage) {
                        startat = (navto * limit) - (limit + 1);
                    }
                    $rowbody.find('tr').hide();
                    startat = startat - 1;
                    limit = limit + 1;
                    $rowbody.find('tr' + fltron).each(function(i, v) {
                        i = i - 1;
                        if (i >= startat) {
                            $(this).show();
                        }
                        if (i == startat) {
                            $(this).hide();
                        }
                        if (i == (startat + (limit - 1)))
                            return false;
                    });
                    $(params_.target).attr('data-pagenum', navto);
                    LSCA.prodFilter.addPaging.makePageNav(params_, LSCA.prodFilter.addPaging.pageData);
                })
            }
        }
    },
    filterSavedCart : {
        init : function(params_) {
            if ($("#mainContainer").hasClass(params_.pageId)) {
                $("#filterTable").on('submit', function(e) {
                    e.preventDefault();
                    var trindex = [];
                    var dovalidate = LSCA.GlobalValidate.init({
                        target : '#filterTable',
                        action : 'submit'
                    });
                    if (dovalidate) {
                        $(".skyblueTable").find('tbody tr').each(function(i, v) {
                            if ($("td:eq(1)", this).text() == ($("#EnterName").val())) {
                                trindex.push(i);
                            }
                        });
                        if (trindex != 'undefined' && trindex.length > 0) {
                            $(params_.selector).find('tbody tr').hide();
                            $.each(trindex, function(j, w) {
                                $(params_.selector).find("tbody tr:eq(" + w + ")").show();
                            });
                        } else {
                            $('.errorMessages').show();
                        }
                    }
                });
            }
        }
    },
    reOrderSavedCart : {
        init : function(params_) {
            $(params_.target).find('tbody tr').each(function(i, v) {
                $('td:eq(0)', this).text(i + 1);
            });
        }
    },
    cartShowUpdate : function(params_) {
        $(params_.target).on('keyup', function() {
            var txtVal = $(this).val();
            if (/^[0-9]+$/.test(txtVal) && ((txtVal >= 0) && (txtVal <= 99999))) {
                if ($(this).parent().find('a').hasClass('hide')) {
                    $(this).parent().find('a').removeClass('hide');
                    $(".errorMessages").hide();
                }
            } else {
                LSCA.GlobalValidate.showError('', $(this).attr('title'));
            }
        });
    },
    populateState : {
        init : function(params_) {
            if (typeof postalCodelist != 'undefined' && postalCodelist != '') {
                var noZipCtry = postalCodelist.match(/[^\[\]\s,]+/g);
            }
            $(params_.target).find('.country').on('change', function() {
                LSCA.globalAjax.doCall({
                    url : params_.url + $(this).val(),
                    target : $(params_.target)
                }, function(data) {
                    LSCA.populateState.renderState.call(data.target, data);
                });
                LSCA.populateState.blurZip.call($(params_.target), noZipCtry);
            });
            LSCA.populateState.blurZip.call($(params_.target), noZipCtry);
            if ($("#mainContainer").hasClass("RegPropage")) {
                var $statetext = $(params_.target).find('.statetext'), $statelist = $(params_.target).find('.statelist');
                var fCtrlist = ctrlist.match(/[^\[\]\s,]+/g);
                if ($.inArray($('#shipcountry').val(), fCtrlist) > -1) {
                    $statetext.attr('disabled', 'disabled').show();
                }
                if ($('#shipcountry').val() == "SG") {
                    $statetext.attr('readonly', 'readonly').show().val("SG");
                }
                $('.country').each(function() {
                    LSCA.populateState.blurZip.call($(this).parents('div.pull-left'), noZipCtry)
                });
            }
        },
        renderState : function(params_) {
            var valui = '', $statetext = $(this).find('.statetext'), $statelist = $(this).find('.statelist');
            if ($(params_.data).length > 0) {
                $statetext.hide().attr('disabled', 'disabled');
                $statelist.removeAttr('disabled');
                $statelist.parent().show();
                $statelist.prev().text('--');
                $(params_.data).each(function(i, v) {
                    valui += '<option value=' + v.code + '>' + v.name + '</option>';
                });
                $(this).find('.statelist').html(valui);
                $statelist.show().uniform();

            } else {
                $statelist.attr('disabled', 'disabled');
                $statelist.parent().hide();
                var fCtrlist = ctrlist.match(/[^\[\]\s,]+/g);

                if ($.inArray($(this).find('.country').val(), fCtrlist) > -1) {
                    $statetext.attr('disabled', 'disabled').show();
                } else {
                    $statetext.show().removeAttr('disabled');
                }
                if ($('select#shipcountry').val() == "SG") {
                    $("#shippingStateText").attr('readonly', 'readonly').show().val("SG");
                } else {
                    $("#shippingStateText").removeAttr('readonly').val("");
                }
                if ($('select#billingaddress').val() == "SG") {
                    $("#billingStateText").attr('readonly', 'readonly').show().val("SG");
                } else {
                    $("#billingStateText").removeAttr('readonly').val("");
                }
            }
        },
        blurZip : function(ctryList) {
            if ($.inArray($(this).find('.country').val(), ctryList) > -1) {
                $(this).find('.zipcode').val('').removeClass('required');
                $(this).find('.zipcode').parents('div.form-group').hide();
            } else {
                $(this).find('.zipcode').addClass('required');
                $(this).find('.zipcode').parents('div.form-group').show();
            }
        }
    },
    copyBillAddr : function(params_) {
        $(params_.target).on('click', function() {
            if ($(this).prop('checked')) {
                $('#billingaddress').find('#addr').val($('#shippingaddress').find('#address').val());
                $('#billingaddress').find('#addr2').val($('#shippingaddress').find('#address2').val());
                $('#billingaddress').find('#cty').val($('#shippingaddress').find('#city').val());
                $('#billingaddress').find('#zp').val($('#shippingaddress').find('#zip').val());
                $('#billingaddress').find('.country').prev().text($('#shippingaddress').find('.country').prev().text());
                $('#billingaddress').find('.country').html($('#shippingaddress').find('.country').html());
                $('#billingaddress .country').val($('#shippingaddress .country').val());
                $('#billingaddress').find('.statelist').prev().text($('#shippingaddress').find('.statelist').prev().text());
                $('#billingaddress').find('.statelist').html($('#shippingaddress').find('.statelist').html());
                $('#billingaddress .statelist').val($('#shippingaddress .statelist').val());
                $('#billingaddress').find('.statetext').val($('#shippingaddress').find('.statetext').val());
                if ($('#shippingaddress').find('.statetext').is(':visible')) {
                    $('#billingaddress').find('.statelist').attr('disabled', 'disabled');
                    $('#billingaddress').find('.statelist').parent().hide();
                    $('#billingaddress').find('.statetext').removeAttr('disabled').show();
                } else {
                    $('#billingaddress').find('.statetext').attr('disabled', 'disabled').hide();
                    $('#billingaddress').find('.statelist').removeAttr('disabled').show();
                    $("select").uniform();
                }
                if (($('#shippingaddress').find('.statetext').attr('disabled')) == "disabled") {
                    $('#billingaddress').find('.statetext').attr('disabled', 'disabled');
                }
                if (($('#shippingaddress').find('.statetext').attr('readonly')) == "readonly") {
                    $('#billingaddress').find('.statetext').attr('readonly', 'readonly');
                }
                if (typeof postalCodelist != 'undefined' && postalCodelist != '') {
                    var noZipCtry = postalCodelist.match(/[^\[\]\s,]+/g);
                    LSCA.populateState.blurZip.call($('#billingaddress'), noZipCtry);
                }
            }
        });
    },
    selectAll : function(params_) {
        $(params_.target).click(function() {
            $(this).parents(params_.parent).find("input:checkbox").each(function() {
                if (!$(this).prop("checked")) {
                    $(this).click();
                    $(this).attr("checked", "checked");
                }
            });
        });
    },
    submitLocale : function(params_) {
        $(params_.target).find('a').on('click', function() {
            $("#setLocale").val($(this).attr('data-lang'));
            $("#userCountry_Code").val($(this).attr('countrycode'));
            var countrycode = $(this).attr('countrycode');
            if (countrycode == "CN") {
                var agilentLocale = "";
                agilentLocale = "zh_CN";
                $.cookie("agilent_locale", agilentLocale, {
                    path: '/;SameSite=None', 					
					secure: true,
                    domain : '.agilent.com.cn',
                    expires : 90
                });
            }
            $(params_.selector).click();
        });
    },
    sidebarSubmitLocale : function(params_) {
        $(params_.target).on('change', function() {
            $("#setLocale").val($(this).val());
            $(params_.selector).click();
        });
    },
    getQuoteOrder : function(params_) {
        if ($(".contentSection").hasClass(params_.pageId)) {
            if (params_.buttonClick != null && params_.buttonClick == "true" || ($("#isDirectorView").val() == null || $.trim($("#isDirectorView").val()) == "" || $("#isDirectorView").val() == "false")) {
                LSCA.imageLoader.init({
                    target : params_.selector
                });
                LSCA.globalAjax.doCall({
                    url : params_.url,
                    data : $("#quoteForm").serialize(),
                    dataType : 'HTML',
                    type : 'GET'
                }, function(data) {
                    if (data) {
                        $(params_.selector).html(data.data);
                        LSCA.globalPaginate.init({
                            prevnext : true
                        });
                        LSCA.getFooterextend();
                    }
                });
            }
            $(params_.target).on('click', function() {
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#quoteForm',
                    action : 'submit'
                });
                if (dovalidate) {
                    $(params_.target).off('click');
                    params_.buttonClick = 'true';
                    LSCA.getQuoteOrder(params_);
                }
            });
        } else {
            if (!$("#mainContainer").hasClass("myQuote") && !$("#mainContainer").hasClass("getOrder") && !$("#mainContainer").hasClass("serviceContract") && !$("#mainContainer").hasClass("viewMyCatalog")
                    && !$("#mainContainer").hasClass("lmsOrderConfirmation")) {
                LSCA.getFooterextend();
            }
        }
    },
    getMultiQuote : function(params_) {
    	
    	function getQuoteParameterByName(name, url) {
    	    if (!url) url = window.location.href;
    	    name = name.replace(/[\[\]]/g, '\\$&');
    	    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
    	        results = regex.exec(url);
    	    if (!results) return null;
    	    if (!results[2]) return '';
    	    return decodeURIComponent(results[2].replace(/\+/g, ' '));
    	}
    	
    	
    	var days = getQuoteParameterByName("days");
    	var QuoteNumber = getQuoteParameterByName("QuoteNumber");
    	var df = getQuoteParameterByName("df");
    	var dt = getQuoteParameterByName("dt");
    	var Rdf = getQuoteParameterByName("Rdf");
    	var Rdt = getQuoteParameterByName("Rdt");
    	
    	
    	
    	if(days != null || days != undefined && url.indexOf("?") > 0){
    		params_.url = '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days='+days;
    		$('.orderRange .btn-link .selectedDaysQuote').text($('#'+days).text());	
    		
    	}else if(Rdf!='' && Rdt !='' && Rdf!=null && Rdt !=null && Rdf!=undefined && Rdt !=undefined){
    		params_.url = '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=DateRange&df='+Rdf+'&dt='+Rdt;
    		var monthNames = ["Jan", "Feb", "Mar", "April", "May", "June","July", "Aug", "Sept", "Oct", "Nov", "Dec"];
			
			var invoiceRangeStart = Rdf;
			var datePartsStart = invoiceRangeStart.split("/");
			
			var invoiceRangeEnd = Rdt;
			var datePartsEnd = invoiceRangeEnd.split("/");
			
			var CNcountry = $("#countryCode").val();
			
            if(CNcountry == "CN"){
                var Date1 = new Date(datePartsStart[0], datePartsStart[1]-1, datePartsStart[2]);
                var Date2 = new Date(datePartsEnd[0], datePartsEnd[1]-1, datePartsEnd[2]);
                var startDateStringOne = Date1.getFullYear() + " " + monthNames[Date1.getMonth()] + " " + Date1.getDate();
                var startDateStringTwo = Date2.getFullYear() + " " + monthNames[Date2.getMonth()] + " " + Date2.getDate();
            }else{
                var Date1 = new Date(datePartsStart[2], datePartsStart[0]-1,datePartsStart[1] );
                var Date2 = new Date(datePartsEnd[2], datePartsEnd[0]-1,datePartsEnd[1]);
                var startDateStringOne = Date1.getDate() + " " + monthNames[Date1.getMonth()] + " " + Date1.getFullYear();
                var startDateStringTwo = Date2.getDate() + " " + monthNames[Date2.getMonth()] + " " + Date2.getFullYear();
            }

			$('#orderRangeQuote .btn-link .selectedDaysQuote').text(startDateStringOne+' - '+startDateStringTwo);
			
    	}else if(QuoteNumber!='' && df=='' && dt == ''){
    		$('#orderIDQuote').val(QuoteNumber);
    		params_.url = '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumber&quoteId='+$.trim(QuoteNumber);
    		$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueInvoice").val());
    	}else if(QuoteNumber!='' && df!='' && dt != '' && QuoteNumber!=null && df!=null && dt !=null && QuoteNumber!=undefined && df!=undefined && dt != undefined){
    		$('#startDateQuote').val(df);
    		$('#endDateQuote').val(dt);
    		params_.url = '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumberNDateRange&quoteId='+QuoteNumber+'&df='+df+'&dt='+dt;
    		$('#orderRangeQuote .btn-link .selectedDaysQuote').text(df+' - '+dt);
    	}else if(QuoteNumber=='' && df!='' && dt != ''){
    		$('#startDateQuote').val(df);
    		$('#endDateQuote').val(dt);
    		params_.url = '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=DateRange&df='+df+'&dt='+dt;
    		$('#orderRangeQuote .btn-link .selectedDaysQuote').text(df+' - '+dt);
    	}
    	
        if ($(".mainContainer").hasClass(params_.pageId)) {
           // if (params_.buttonClick != null && params_.buttonClick == "true" || ($("#isDirectorView").val() == null || $.trim($("#isDirectorView").val()) == "" || $("#isDirectorView").val() == "false")) {
        	LSCA.loadingSpinner.showLoading();
                LSCA.imageLoader.init({
                    target : params_.selector
                });
                LSCA.globalAjax.doCall({
                    url : params_.url,
                    //data : $("#quoteForm").serialize(),
                    dataType : 'HTML',
                    type : 'GET'
                }, function(data) {
                    if (data) {
                        $(params_.target).html(data.data);
                        if($('#quoteResult table').length >= 1){
                    		$('#quoteResult .pagination-con').show();	 
                    	}else{	 
                    		$('#quoteResult .pagination-con').hide();
                    	}
                        LSCA.mySalesaddPaging.makePageNav(params_, function(params_) {
        					LSCA.mySalesaddPaging.pageData(params_);
        					
        				});
                        multiQuotescrpts();
                        LSCA.getFooterextend();
                        
                    }
                    LSCA.loadingSpinner.hideLoading();
                });
                
          
        } else {
            if (!$("#mainContainer").hasClass("myQuoteListing") && !$("#mainContainer").hasClass("getOrder") && !$("#mainContainer").hasClass("serviceContract") && !$("#mainContainer").hasClass("viewMyCatalog")
                    && !$("#mainContainer").hasClass("lmsOrderConfirmation")) {
                LSCA.getFooterextend();
            }
        }
    },
	viewSalesWebOrder : {
        init : function(params_) {
            $(document).on("click",".orderRangeDropDown li.orderList a",function(e) {
				$('#orderIDNew').val('');
				$('#posoLabel').hide();
				$('#orderIDNew').removeClass('requiredTextBox');
				//$('.orderRange .btn-link').text('View last '+$(this).attr('class')+' days');
				$('.orderRange .btn-link .selectedDays').text($(this).text());
				LSCA.getSalesOrder.init({
					url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr='+$(this).attr('id')+'&pageName=myOrders&reloadOrders=true',
					target : '#orderResult',
					pageid : 'myOrderStatus'
				});
				LSCA.getWebOrder.init({
					 url : '/common/includes/ajax/webOrderHistoryJson.jsp?ordr='+$(this).attr('id')+'&pageName=myOrders',
					target : '#webOrderResult',
					pageid : 'myOrderStatus'
				});
			});
		}
	},
	searchSalesOrder : {
        init : function(params_) {
            $(document).on("click",".searchOrder #btnSubmit",function(e) {
            	$('#posoLabelEnd').hide();
            	$('#posoLabelStart').hide();
            	$('#startDate').removeClass('requiredTextBox');
            	$('#endDate').removeClass('requiredTextBox');
				if($("#orderIDNew").val() != '' && $("#startDate").val() != "" && $("#endDate").val() != "") {
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('.orderRange .btn-link .selectedDays').text($("#thirtyvalue").val());
					$('.orderRange .btn-link .selectedDays').text($("#startDate").val()+' - '+$("#endDate").val());
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderSearchJson.jsp?ordr='+$.trim($("#orderIDNew").val())+'&pageName=myOrders&action=search&df='+$("#startDate").val()+'&dt='+$("#endDate").val(),
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});
				}
				else if($("#orderIDNew").val() == '' && $("#startDate").val() != "" && $("#endDate").val() != "") {
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('.orderRange .btn-link .selectedDays').text($("#thirtyvalue").val());
					$('.orderRange .btn-link .selectedDays').text($("#startDate").val()+' - '+$("#endDate").val());
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderSearchJson.jsp?ordr=&pageName=myOrders&action=search&df='+$("#startDate").val()+'&dt='+$("#endDate").val(),
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});
				}
				else if($("#orderIDNew").val() != '') {
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					$('.orderRange .btn-link .selectedDays').text($("#thirtyvalue").val());
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderSearchJson.jsp?ordr='+$.trim($("#orderIDNew").val())+'&pageName=myOrders&action=search&df=&dt=',
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});
				}
				else if($("#startDate").val() == "" && $("#endDate").val() != "") {
					$('#startDate').addClass('requiredTextBox');	
					$('#posoLabelStart').show();
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
				}
				else if($("#startDate").val() != "" && $("#endDate").val() == "") {
					/*$('#endDate').addClass('requiredTextBox');	
					$('#posoLabelEnd').show();
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');*/
					var todayDate = new Date();
					var dd = String(todayDate.getDate()).padStart(2, '0');
					var mm = String(todayDate.getMonth() + 1).padStart(2, '0'); //January is 0!
					var yyyy = todayDate.getFullYear();

					var CNcountry = $("#countryCode").val();

					if(CNcountry == "CN"){
						DateFormat = yyyy + '/' + mm + '/' + dd;    					
					}else{
						DateFormat = mm + '/' + dd + '/' + yyyy;    					
					}
					$('#endDate').removeClass('requiredTextBox');	
					$('#posoLabelEnd').hide();
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					//$('.orderRange .btn-link .selectedDays').text($("#thirtyvalue").val());
					$('.orderRange .btn-link .selectedDays').text($("#startDate").val()+' - '+DateFormat);
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderSearchJson.jsp?ordr='+$.trim($("#orderIDNew").val())+'&pageName=myOrders&action=search&df='+$("#startDate").val()+'&dt='+DateFormat,
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});
				}
				else {
					var thirtyvalue = $("#thirtyvalue").val();
	            	$('.orderRange .btn-link .selectedDays').text(thirtyvalue);
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});	
				}
			});
            $(document).on("click","#cancelSearch",function(e) {
            	var thirtyvalue = $("#thirtyvalue").val();
            	$('.orderRange .btn-link .selectedDays').text(thirtyvalue);
            	document.getElementById('orderIDNew').value = "";
            	$('#startDate').removeClass('requiredTextBox');
            	$('#endDate').removeClass('requiredTextBox');
            	document.getElementById('startDate').value = "";
            	document.getElementById('endDate').value = "";
            	$('#posoLabelEnd').hide();
            	$('#posoLabelStart').hide();
				LSCA.getSalesOrder.init({
					url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
					target : '#orderResult',
					pageid : 'myOrderStatus'
				});
        	}); 
		}
	},
	searchDateSalesOrder : {
        init : function(params_) {
            $(document).on("click","#submitOrderDate",function(e) {
                var dovalidate = LSCA.GlobalValidate.init({
					target : '#dateRange'
                });
                $(document).find('div.errorMessages:eq(0)').hide();
				//console.log(dovalidate);
				if (dovalidate) {
					$('#orderIDNew').val('');
					$('#posoLabel').hide();
					$('#orderIDNew').removeClass('requiredTextBox');
					LSCA.getSalesOrder.init({
						url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr=dateRange&df='+$("#orderStartDate").val()+'&dt='+$("#orderEndDate").val()+'&pageName=myOrders&action=search&reloadOrders=true',
						target : '#orderResult',
						pageid : 'myOrderStatus'
					});
					LSCA.getWebOrder.init({
						 url : '/common/includes/ajax/webOrderHistoryJson.jsp?ordr=dateRange&df='+$("#orderStartDate").val()+'&dt='+$("#orderEndDate").val()+'&pageName=myOrders',
						target : '#webOrderResult',
						pageid : 'myOrderStatus'
					});
					var monthNames = ["Jan", "Feb", "Mar", "April", "May", "June","July", "Aug", "Sept", "Oct", "Nov", "Dec"];
					var CountryCn = $('#countryCode').val();
					var countryKr = $('#countryKRCode').val();
					var d1 = new Date($('#orderStartDate').val());
					var d2 = new Date($('#orderEndDate').val());
					if(CountryCn == "CN") {
						var startDateString1 = d1.getFullYear() + "/" + (d1.getMonth()+1) + "/" + d1.getDate() ;
						var startDateString2 = d2.getFullYear() + "/" + (d2.getMonth()+1) + "/" + d2.getDate() ;
					}
					else {
						var startDateString1 = (d1.getMonth()+1) + "/" + d1.getDate() + "/"+ d1.getFullYear();
						var startDateString2 = (d2.getMonth()+1) + "/" + d2.getDate() + "/"+ d2.getFullYear();	
					}
					$('.orderRange .btn-link .selectedDays').text(startDateString1+' - '+startDateString2);
					$('#rememberClose').trigger('click');
				}else{
					 if ($('#orderStartDate').val() == "") {
						$('#orderStartDate').next().css('display', 'inline-block');
						$('#orderStartDate').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderStartDate').addClass('requiredTextBox');				
					} else {
						$('#orderStartDate').next().hide();
						$('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderStartDate').removeClass('requiredTextBox');
					}
					if ($('#orderEndDate').val() == "") {
						$('#orderEndDate').next().css('display', 'inline-block');
						$('#orderEndDate').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderEndDate').addClass('requiredTextBox');				
					} else {
						$('#orderEndDate').next().hide();
						$('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderEndDate').removeClass('requiredTextBox');
					}
				}
			});
		}
	},
	getSalesOrder : {
            //if (params_.buttonClick != null && params_.buttonClick == "true" || ($("#isDirectorView").val() == null || $.trim($("#isDirectorView").val()) == "" || $("#isDirectorView").val() == "false")) {
            init : function(params_) { 
				if($(".container").hasClass(params_.pageid)) {
				LSCA.loadingSpinner.showLoading();
				$('.salesPagination').html('');
				//$('table#custom-detail-table').attr('data-pagenum', '1');
				$(params_.target).find('table').attr('data-pagenum', '1');
                LSCA.globalAjax.doCall({
                    url : params_.url,
					target : params_.target
                }, function(response) {
					LSCA.getSalesOrder.parseme(response, function() {
					});
					LSCA.mySalesaddPaging.makePageNav(params_, function(params_) {
						LSCA.mySalesaddPaging.pageData(params_)
					});
                });
				}
            },
			parseme : function(response, callback) {
				var data = response.data.sapOrdersList;
				var tableData;
				console.log('sale order : '+data);
				if (data) {
					LSCA.loadingSpinner.hideLoading();
					var len = data.length;
					if (len > 0) {
						$('#orderResult #custom-detail-table1').show();
						$('#orderResult .pagination-con').show();
						$('#orderResult .msg-stnd').hide();
						for (var i = 0; i < len; i++) {
							tblrow = '<tr>';
							tblrow += ' <td><a href=/common/myaccount/sapOrderDetails.jsp?orderId='+data[i].encryptedOrderId+'&ordNetAmt='+data[i].encryptedAmount+'>' + data[i].sapOrderid + '</a></td>';
							tblrow += ' <td>' + data[i].quoteId + '</td>';
							tblrow += ' <td>' + data[i].orderDate + '</td>';
							tblrow += ' <td>' + data[i].poNumber + '</td>';
							var countryEnabl = $("#invoiceEnableCountry").val();
							if(countryEnabl == "true"){
								tblrow += '<td>';
								 if(data[i].invoiceNumber != undefined || data[i].invoiceNumber != null){
									var countInvoice = data[i].invoiceNumber.length;
										if(countInvoice > 1){
											tblrow += '<span id="list_Invoice">';
											tblrow += '<span class="multiInvoiceLink" target=\"_blank\" href="javascript:void(0);" >View ' + countInvoice + ' Invoices</span>';
											tblrow += '<i class="fas fa-sort-up"></i>';
											tblrow += '<i class="fas fa-sort-down"></i>';
											tblrow += '<span id="multiple_invoice_list">';
											for (var j = 0; j < countInvoice; j++) {
												for (var key in data[i].invoiceNumber[j]){
													var ivoiceURL = data[i].invoiceNumber[j][key];
													if(ivoiceURL == "-"){
														tblrow += '<span class="URLNOlink">' + key + '</span>';
													}else{
														tblrow += '<a target=\"_blank\" href=' + ivoiceURL + ' >' + key + '</a>';
													}
													
												}
												
											}
											tblrow += '</span>';
											tblrow += '</span>';
										}else{
											for (var j = 0; j < countInvoice; j++) {	
												for (var key in data[i].invoiceNumber[j]){
													var ivoiceURL = data[i].invoiceNumber[j][key];
													if(ivoiceURL == "-"){
														tblrow += '<span class="URLNOlink">' + key + '</span>';
													}else{
														tblrow += '<a target=\"_blank\" href=' + ivoiceURL + ' >' + key + '</a>';
													}
												}
											}
											
										}
								 }	
								tblrow += '</td>';
								
								}
							//tblrow += ' <td>' + data[i].currency + '</td>';
							netAmountCurrency = currFormatVal.format(data[i].netAmt);
							tblrow += ' <td>' + netAmountCurrency + ' ' + resultCurrencyVal + '</td>';
							tblrow += ' <td>' + data[i].status + '</td>';
							tblrow += '</tr>';
							tableData += tblrow;
						}
						$('#custom-detail-table1 > tbody').html(tableData);
					}
					else {
						$('#orderResult #custom-detail-table1').hide();
						$('#orderResult .pagination-con').hide();
						$('#orderResult .msg-stnd').show();
				}
			}
			}
    },
  //Quote SEARCH START
    viewMultiQuote : {
        init : function(params_) {
            $(document).on("click",".orderRangeDropDownQuote li.orderList a",function(e) {
				$('.buy-selected-quote p.selcted-quote-count').css('display','none');
				$('.selected-quote-btn').prop("disabled", true);
				$('#orderIDNew').val('');
				$('#posoLabel').hide();
				$('#orderIDNew').removeClass('requiredTextBox');
				//$('.orderRange .btn-link').text('View last '+$(this).attr('class')+' days');
				/*****managing Parameter in url start*****/
				var url  = window.location.href;
    		  	var params = { 
    				   'days': $(this).attr('id'),
    				   };
    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
    		   var decodedUrl = decodeURIComponent(new_url)
    		   //  document.location.href =  new_url;
    		   history.pushState(null, null, decodedUrl);
			   /*****managing Parameter in url end*******/
				$('.orderRange .btn-link .selectedDaysQuote').text($(this).text());
				LSCA.getMultiQuote({
					url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days='+$(this).attr('id'),
					target : '#quoteResult',
			        pageId : 'myQuoteListing'
				});
				
			});
		}
	},
    searchMultiQuote : {
        init : function(params_) {
            $(document).on("click",".searchOrder #btnSubmitQuote",function(e) {
				$('.buy-selected-quote p.selcted-quote-count').css('display','none');
				$('.selected-quote-btn').prop("disabled", true);
            	$('#posoLabelEndQuote').hide();
            	$('#posoLabelStartQuote').hide();
            	$('#startDateQuote').removeClass('requiredTextBox');
            	$('#endDateQuote').removeClass('requiredTextBox');
            	if($("#orderIDQuote").val() != '' && $("#startDateQuote").val() == "" && $("#endDateQuote").val() == "" ) {
            		$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					/*****managing Parameter in url start*****/
					var url  = window.location.href;
	    		  	var params = { 
	    				   'QuoteNumber': $("#orderIDQuote").val(),
	    				   'df':'',
	    				   'dt':''
	    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumber&quoteId='+$.trim($("#orderIDQuote").val()),
						target : '#quoteResult',
				        pageId : 'myQuoteListing'

					});
				}
            	else if($("#orderIDQuote").val() != '' && $("#startDateQuote").val() != "" && $("#endDateQuote").val() != "") {
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					/*****managing Parameter in url start*****/
					var url  = window.location.href;
	    		  	var params = { 
	    				   'QuoteNumber': $("#orderIDQuote").val(),
	    				   'df':$("#startDateQuote").val(),
	    				   'dt':$("#endDateQuote").val()
	    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumberNDateRange&quoteId='+$.trim($("#orderIDQuote").val())+'&df='+$("#startDateQuote").val()+'&dt='+$("#endDateQuote").val(),
						//url : '/common/invoiceDetailJson.jsp?action=search&si='+$.trim($("#orderIDQuote").val())+'&df='+$("#startDateQuote").val()+'&dt='+$("#endDateQuote").val(),
						//url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumber&quoteId='+$.trim($("#orderIDQuote").val()),
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});
				}
				else if($("#orderIDQuote").val() == '' && $("#startDateQuote").val() != "" && $("#endDateQuote").val() != "") {
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					/*****managing Parameter in url start*****/
					var url  = window.location.href;
	    		  	var params = { 
	    		  		   'QuoteNumber': '',
	    				   'df':$("#startDateQuote").val(),
	    				   'dt':$("#endDateQuote").val()
	    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=DateRange&df='+$("#startDateQuote").val()+'&dt='+$("#endDateQuote").val(),
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});
				}
				else if($("#orderIDQuote").val() != '') {
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					/*****managing Parameter in url start*****/
					var url  = window.location.href;
					var params = { 
		    				   'QuoteNumber': $("#orderIDQuote").val(),
		    				   'df':'',
		    				   'dt':''
		    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=QuoteNumber&quoteId='+$.trim($("#orderIDQuote").val()),
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});
				}
				else if($("#startDateQuote").val() == "" && $("#endDateQuote").val() != "") {
					$('#startDateQuote').addClass('requiredTextBox');	
					$('#posoLabelStartQuote').show();
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					
					
				}
				else if($("#startDateQuote").val() != "" && $("#endDateQuote").val() == "") {
					 
					var currentDate = new Date()
					var dd = currentDate.getDate()
					var mm = currentDate.getMonth() + 1
					var yyyy = currentDate.getFullYear()
					
					var CNcountry = $("#countryCode").val();
					
                    if(CNcountry == "CN"){
                    	DateFormat = yyyy + '/' + mm + '/' + dd;    					
                    }else{
                    	DateFormat = mm + '/' + dd + '/' + yyyy;    					
                    }
					
					
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');

					/*****managing Parameter in url start*****/
					var url  = window.location.href;
	    		  	var params = { 
	    		  		   'QuoteNumber': '',
	    				   'df':$("#startDateQuote").val(),
	    				   'dt':DateFormat
	    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=DateRange&df='+$("#startDateQuote").val()+'&dt='+DateFormat,
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});
				}
				else {
					var thirtyvalueInvoice = $("#thirtyvalueInvoice").val();
					$('#orderRangeQuote .btn-link .selectedDaysQuote').text($("#thirtyvalueQuote").val());
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=thirtydays',
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});	
				}
			});
			$("#orderIDQuote").keypress(function(event) {
					var keycode = (event.keyCode ? event.keyCode : event.which);
					if (keycode == '13') {
						if ($("#orderIDQuote").is(":focus")) {
							$(document).find(".searchOrder #btnSubmitQuote").click();
						}
					}
			});
            $(document).on("click","#cancelSearchQuote",function(e) {
            	
            	$('.buy-selected-quote p.selcted-quote-count').css('display','none');
				$('.selected-quote-btn').prop("disabled", true);
            	var uri = window.location.toString();
            	if (uri.indexOf("?") > 0) {
            	    var clean_uri = uri.substring(0, uri.indexOf("?"));
            	    window.history.replaceState({}, document.title, clean_uri);
            	}
            	
            	var thirtyvalueInvoice = $("#thirtyvalueInvoice").val();
            	$('#orderRangeQuote .btn-link .selectedDaysQuote').text(thirtyvalueInvoice);
            	document.getElementById('orderIDQuote').value = "";
            	$('#startDateQuote').removeClass('requiredTextBox');
            	$('#endDateQuote').removeClass('requiredTextBox');
            	document.getElementById('startDateQuote').value = "";
            	document.getElementById('endDateQuote').value = "";
            	$('#posoLabelEndQuote').hide();
            	$('#posoLabelStartQuote').hide();
            	LSCA.getMultiQuote({
					url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=thirtydays',
					target : '#quoteResult',
			        pageId : 'myQuoteListing'
				});
        	}); 
		}
	},
	searchMultoQuoteDate : {
        init : function(params_) {
            $(document).on("click","#submitOrderDateQuote",function(e) {
				 var dovalidate = LSCA.GlobalValidate.init({
					target : '#dateRangeQuote'
				});
				//console.log(dovalidate);
				if (dovalidate) {
					$('.buy-selected-quote p.selcted-quote-count').css('display','none');
					$('.selected-quote-btn').prop("disabled", true);
					$('#orderIDQuote').val('');
					$('#posoLabelQuote').hide();
					$('#orderIDQuote').removeClass('requiredTextBox');
					/*****managing Parameter in url start*****/
					var url  = window.location.href;
	    		  	var params = { 
	    		  		   'QuoteNumber': '',
	    				   'Rdf':$("#orderStartDateQuote").val(),
	    				   'Rdt':$("#orderEndDateQuote").val()
	    				   };
	    		   var new_url = window.location.pathname+'?'+ jQuery.param(params);
	    		   var decodedUrl = decodeURIComponent(new_url)
	    		   //  document.location.href =  new_url;
	    		   history.pushState(null, null, decodedUrl);
				   /*****managing Parameter in url end*******/
					LSCA.getMultiQuote({
						url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=DateRange&df='+$("#orderStartDateQuote").val()+'&dt='+$("#orderEndDateQuote").val(),
						target : '#quoteResult',
				        pageId : 'myQuoteListing'
					});
					
					var monthNames = ["Jan", "Feb", "Mar", "April", "May", "June","July", "Aug", "Sept", "Oct", "Nov", "Dec"];
					
					var invoiceRangeStart = $('#orderStartDateQuote').val();
					var datePartsStart = invoiceRangeStart.split("/");
					
					var invoiceRangeEnd = $('#orderEndDateQuote').val();
					var datePartsEnd = invoiceRangeEnd.split("/");
					
					var CNcountry = $("#countryCode").val();
					
                    if(CNcountry == "CN"){
                        var Date1 = new Date(datePartsStart[0], datePartsStart[1]-1, datePartsStart[2]);
                        var Date2 = new Date(datePartsEnd[0], datePartsEnd[1]-1, datePartsEnd[2]);
                        var startDateStringOne = Date1.getFullYear() + " " + monthNames[Date1.getMonth()] + " " + Date1.getDate();
                        var startDateStringTwo = Date2.getFullYear() + " " + monthNames[Date2.getMonth()] + " " + Date2.getDate();
                    }else{
                        var Date1 = new Date(datePartsStart[2], datePartsStart[0]-1,datePartsStart[1] );
                        var Date2 = new Date(datePartsEnd[2], datePartsEnd[0]-1,datePartsEnd[1]);
                        var startDateStringOne = Date1.getDate() + " " + monthNames[Date1.getMonth()] + " " + Date1.getFullYear();
                        var startDateStringTwo = Date2.getDate() + " " + monthNames[Date2.getMonth()] + " " + Date2.getFullYear();
                    }

					$('#orderRangeQuote .btn-link .selectedDaysQuote').text(startDateStringOne+' - '+startDateStringTwo);
					$('#rememberCloseQuote').trigger('click');
				}else{
					 if ($('#orderStartDateQuote').val() == "") {
						$('#orderStartDateQuote').next().css('display', 'inline-block');
						$('#orderStartDateQuote').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderStartDateQuote').addClass('requiredTextBox');				
					} else {
						$('#orderStartDateQuote').next().hide();
						$('#orderStartDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderStartDateQuote').removeClass('requiredTextBox');
					}
					if ($('#orderEndDateQuote').val() == "") {
						$('#orderEndDateQuote').next().css('display', 'inline-block');
						$('#orderEndDateQuote').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderEndDateQuote').addClass('requiredTextBox');				
					} else {
						$('#orderEndDateQuote').next().hide();
						$('#orderEndDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderEndDateQuote').removeClass('requiredTextBox');
					}
				}
			});
		}
	},
	//Quote SEARCH END
	
  //CHINA INVOICS SEARCH START
    viewInvoiceOrder : {
        init : function(params_) {
            $(document).on("click",".orderRangeDropDownInvoice li.orderList a",function(e) {
				$('#orderIDNew').val('');
				$('#posoLabel').hide();
				$('#orderIDNew').removeClass('requiredTextBox');
				//$('.orderRange .btn-link').text('View last '+$(this).attr('class')+' days');
				$('.orderRange .btn-link .selectedDaysInvoice').text($(this).text());
				LSCA.getNonchinaInvoice.init({
					//url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr='+$(this).attr('id')+'&pageName=myOrders&reloadOrders=true',
					url : '/common/invoiceDetailJson.jsp?action=search&sa='+$(this).attr('id'),
					target: '#orderResult1',
					pageid: 'myOrderStatus'
				});
				
			});
		}
	},
    searchChinaInvoice : {
        init : function(params_) {
            $(document).on("click",".searchOrder #btnSubmitInvoice",function(e) {
            	$('#posoLabelEndInvoice').hide();
            	$('#posoLabelStartInvoice').hide();
            	$('#startDateInvioice').removeClass('requiredTextBox');
            	$('#endDateInvioice').removeClass('requiredTextBox');
            	if($("#orderIDInvoice").val() != '' && $("#startDateInvioice").val() == "" && $("#endDateInvioice").val() == "" ) {
            		$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&si='+$.trim($("#orderIDInvoice").val()),
						target: '#orderResult1',
						pageid: 'myOrderStatus'

					});
				}
            	else if($("#orderIDInvoice").val() != '' && $("#startDateInvioice").val() != "" && $("#endDateInvioice").val() != "") {
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#startDateInvioice").val()+' - '+$("#endDateInvioice").val());
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&si='+$.trim($("#orderIDInvoice").val())+'&df='+$("#startDateInvioice").val()+'&dt='+$("#endDateInvioice").val(),
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});
				}
				else if($("#orderIDInvoice").val() == '' && $("#startDateInvioice").val() != "" && $("#endDateInvioice").val() != "") {
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#startDateInvioice").val()+' - '+$("#endDateInvioice").val());
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&df='+$("#startDateInvioice").val()+'&dt='+$("#endDateInvioice").val(),
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});
				}
				else if($("#orderIDInvoice").val() != '') {
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&si='+$.trim($("#orderIDInvoice").val()),
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});
				}
				else if($("#startDateInvioice").val() == "" && $("#endDateInvioice").val() != "") {
					$('#startDateInvioice').addClass('requiredTextBox');	
					$('#posoLabelStartInvoice').show();
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					
					
				}
				else if($("#startDateInvioice").val() != "" && $("#endDateInvioice").val() == "") {
					
					
					var todayDate = new Date();
					var dd = String(todayDate.getDate()).padStart(2, '0');
					var mm = String(todayDate.getMonth() + 1).padStart(2, '0'); //January is 0!
					var yyyy = todayDate.getFullYear();
					
					var CNcountry = $("#countryCode").val();
					
                    if(CNcountry == "CN"){
                    	DateFormat = yyyy + '/' + mm + '/' + dd;    					
                    }else{
                    	DateFormat = dd + '/' + mm + '/' + yyyy;    					
                    }
					
					
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					//$('.orderRange .btn-link').text('View last 30 days');
					//$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#thirtyvalueInvoice").val());
					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text($("#startDateInvioice").val()+' - '+DateFormat);
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&df='+$("#startDateInvioice").val()+'&dt='+DateFormat,
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});
				}
				else {
					var thirtyvalueInvoice = $("#thirtyvalueInvoice").val();
	            	$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text(thirtyvalueInvoice);
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});	
				}
			});
            $(document).on("click","#cancelInvoiceSearch",function(e) {
            	var thirtyvalueInvoice = $("#thirtyvalueInvoice").val();
            	$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text(thirtyvalueInvoice);
            	document.getElementById('orderIDInvoice').value = "";
            	$('#startDateInvioice').removeClass('requiredTextBox');
            	$('#endDateInvioice').removeClass('requiredTextBox');
            	document.getElementById('startDateInvioice').value = "";
            	document.getElementById('endDateInvioice').value = "";
            	$('#posoLabelEndInvoice').hide();
            	$('#posoLabelStartInvoice').hide();
				LSCA.getNonchinaInvoice.init({
					url : '/common/invoiceDetailJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
					target: '#orderResult1',
					pageid: 'myOrderStatus'
				});
        	}); 
		}
	},
	searchChinaInvoiceDate : {
        init : function(params_) {
            $(document).on("click","#submitOrderDateInvoice",function(e) {
				 var dovalidate = LSCA.GlobalValidate.init({
					target : '#dateRangeInvoice'
				});
				//console.log(dovalidate);
				if (dovalidate) {
					$('#orderIDInvoice').val('');
					$('#posoLabelInvoice').hide();
					$('#orderIDInvoice').removeClass('requiredTextBox');
					LSCA.getNonchinaInvoice.init({
						url : '/common/invoiceDetailJson.jsp?action=search&df='+$("#orderStartDateInvoice").val()+'&dt='+$("#orderEndDateInvoice").val(),
						target: '#orderResult1',
						pageid: 'myOrderStatus'
					});
					
					var monthNames = ["Jan", "Feb", "Mar", "April", "May", "June","July", "Aug", "Sept", "Oct", "Nov", "Dec"];
					
					var invoiceRangeStart = $('#orderStartDateInvoice').val();
					var datePartsStart = invoiceRangeStart.split("/");
					
					var invoiceRangeEnd = $('#orderEndDateInvoice').val();
					var datePartsEnd = invoiceRangeEnd.split("/");
					
					var CNcountry = $("#countryCode").val();
					
                    if(CNcountry == "CN"){
                        var Date1 = new Date(datePartsStart[0], datePartsStart[1]-1, datePartsStart[2]);
                        var Date2 = new Date(datePartsEnd[0], datePartsEnd[1]-1, datePartsEnd[2]);
                        var startDateStringOne = Date1.getFullYear() + "/" + (Date1.getMonth()+1) + "/" + Date1.getDate();
                        var startDateStringTwo = Date2.getFullYear() + "/" + (Date2.getMonth()+1) + "/" + Date2.getDate();
                    }else{
                        var Date1 = new Date(datePartsStart[2], datePartsStart[1]-1, datePartsStart[0]);
                        var Date2 = new Date(datePartsEnd[2], datePartsEnd[1]-1, datePartsEnd[0]);
                        var startDateStringOne = Date1.getDate() + "/" + (Date1.getMonth()+1) + "/" + Date1.getFullYear();
                        var startDateStringTwo = Date2.getDate() + " " + (Date2.getMonth()+1) + "/" + Date2.getFullYear();
                    }

					$('#orderRangeInvoice .btn-link .selectedDaysInvoice').text(startDateStringOne+' - '+startDateStringTwo);
					$('#rememberCloseInvoice').trigger('click');
				}else{
					 if ($('#orderStartDateInvoice').val() == "") {
						$('#orderStartDateInvoice').next().css('display', 'inline-block');
						$('#orderStartDateInvoice').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderStartDateInvoice').addClass('requiredTextBox');				
					} else {
						$('#orderStartDateInvoice').next().hide();
						$('#orderStartDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderStartDateInvoice').removeClass('requiredTextBox');
					}
					if ($('#orderEndDateInvoice').val() == "") {
						$('#orderEndDateInvoice').next().css('display', 'inline-block');
						$('#orderEndDateInvoice').prev('.fieldLabel').addClass('requiredLabel');
						$('#orderEndDateInvoice').addClass('requiredTextBox');				
					} else {
						$('#orderEndDateInvoice').next().hide();
						$('#orderEndDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
						$('#orderEndDateInvoice').removeClass('requiredTextBox');
					}
				}
			});
		}
	},
	//CHINA INVOICS SEARCH END
    getNonchinaInvoice :{
    	init : function(params_) { 
			if($(".container").hasClass(params_.pageid)) {
			LSCA.loadingSpinner.showLoading();
			$('.salesPagination').html('');
			//$('table#custom-detail-table').attr('data-pagenum', '1');
			$(params_.target).find('table').attr('data-pagenum', '1');
            LSCA.globalAjax.doCall({
                url : params_.url,
				target : params_.target
            }, function(response) {
				LSCA.getNonchinaInvoice.parseme(response, function() {
				});
				LSCA.mySalesaddPaging.makePageNav(params_, function(params_) {
					LSCA.mySalesaddPaging.pageData(params_)
				});
            });
			}
        },
		parseme : function(response, callback) {
			var data = response.data;
			var tableData;
			
			console.log('sale order : '+data);
			var CNcountry = $("#countryCode").val();
			var KRCountry = $("#countryKRCode").val();	
			
			if (data && (CNcountry == "CN") && (KRCountry != "KR")) {
				

				LSCA.loadingSpinner.hideLoading();
				var len = Object.keys(data).length;
				if (len > 0) {
					$("#orderResult1 #custom-detail-table tbody").empty();
					$('#orderResult1 #custom-detail-table').show();
					$('#orderResult1 .pagination-con').show();
					$('#orderResult1 .msg-stnd').hide();

                        Object.keys(data).forEach(function(k){
                        	var myId = k;
                        	tblrow = '<tr>'; 
                        	tblrow += "<td id='" + myId + "' >";
                        	Object.keys(data[k]).forEach(function(k1){
                        		var idd = "#" + myId;
                        		
                        		var InvoiceUrl = data[k][k1].invoiceURL;
                        		if(InvoiceUrl === undefined || InvoiceUrl === null){
                        			tblrow +=   "<span>" + k1 +  "</span>";
                        		}else {
                        			tblrow += "<a target=\"_blank\" href='" + InvoiceUrl + "' >" + k1 + '</a>';
                        		}
                        		
                         	});	
                        	tblrow += '</td>';
                        	
                        	tblrow += ' <td><a href=/common/myaccount/sapOrderDetails.jsp?orderId='+ k +'>' + k + '</a></td>';
                        	
                        	var lgth = Object.keys(data[k]).length;
                        	tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var orDate= data[k][ival].orderDate;
                        		if(orDate != ""){
                        			tblrow += '<span>'+ orDate + '</span>'
                        		}	
                        	}
	                        tblrow += '</td>';
                        	
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var purOrder = data[k][ival].purcahseOrder;
                        		tblrow += '<span>'+ purOrder + '</span>'
                        	}
	                        tblrow += '</td>';
	                           
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var dly = data[k][ival].delivery;
                        		tblrow += '<span>'+ dly + '</span>'
                        	}
	                        tblrow += '</td>';
	                        
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var bill =data[k][ival].billing;
                        		tblrow += '<span>'+ bill + '</span>'
                        	}
	                        tblrow += '</td>';
	                        
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var vatfowd = data[k][ival].vatForwarder;
                        		tblrow += '<span>'+ vatfowd + '</span>'
                        	}
	                        tblrow += '</td>';
	                        
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var vatrak = data[k][ival].vatTracking;
                        		tblrow += '<a href="#" class="modalTrackList" data-toggle="modal" data-target="#modalTrackList" target="_blank">'+ vatrak + '</a>'
                        	}
	                        tblrow += '</td>';
                        	
	                        tblrow += "<td id='" + myId + "' >";
                        	for(var i = 0; i < lgth; i++){
                        		var idd = "#" + myId;
                        		var ival = Object.keys(data[k])[i];
                        		var vatstus = data[k][ival].vatStatus;
                        		tblrow += '<span>'+ vatstus + '</span>'
                        	}
	                        tblrow += '</td>';

                        	
                        	tblrow += '</tr>';
                        	$("#custom-detail-table tbody").append(tblrow);
                            });
					$('#custom-detail-table > tbody').html(tableData);
				
				}
				else {
					$('#orderResult1 #custom-detail-table').hide();
					$('#orderResult1 .pagination-con').hide();
					$('#orderResult1 .msg-stnd').show();
			}
		}else{
			
			LSCA.loadingSpinner.hideLoading();
			var len = Object.keys(data).length;
			if (len > 0) {
				$("#orderResult1 #custom-detail-table tbody").empty();
				$('#orderResult1 #custom-detail-table').show();
				$('#orderResult1 .pagination-con').show();
				$('#orderResult1 .msg-stnd').hide();

                    Object.keys(data).forEach(function(k){
                    	var myId = k;
                    	tblrow = '<tr>'; 
                    	tblrow += "<td id='" + myId + "' >";
                    	Object.keys(data[k]).forEach(function(k1){
                    		var idd = "#" + myId;
                    		
                    		
                    		var InvoiceUrl = data[k][k1].invoiceURL;
                    		if(InvoiceUrl === undefined || InvoiceUrl === null){
                    			tblrow +=   "<span>" + k1 +  "</span>";
                    		}else {
                    			tblrow += "<a target=\"_blank\" href='" + InvoiceUrl + "' >" + k1 + '</a>';
                    		}
                    		
                    		
                     	});	
                    	tblrow += '</td>';
                    	
                    	tblrow += ' <td><a href=/common/myaccount/sapOrderDetails.jsp?orderId='+ k +'>' + k + '</a></td>';
                    	
                    	var lgth = Object.keys(data[k]).length;
                    	tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var ival = Object.keys(data[k])[i];
                    		var idd = "#" + myId;
                    		var orDate= data[k][ival].orderDate;
                    		if(orDate != ""){
                    			tblrow += '<span>'+ orDate + '</span>'
                    		}
                    		
                    	}
                        tblrow += '</td>';
                    	
                        tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var ival = Object.keys(data[k])[i];
                    		var idd = "#" + myId;
                    		var purOrder = data[k][ival].purcahseOrder;
                    		tblrow += '<span>'+ purOrder + '</span>'
                    	}
                        tblrow += '</td>';
                        
                      // tblrow += "<td id='" + myId + "' >";
                    	//for(var i = 0; i < lgth; i++){
                    		//var idd = "#" + myId;
                    		//var Intyp =Object.values(data[k])[i].invoiceType;
                    		//tblrow += '<span>'+ Intyp + '</span>'
                    	//}
                        //tblrow += '</td>';
                        
                        tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var idd = "#" + myId;
                    		var ival = Object.keys(data[k])[i];
                    		var duDate =data[k][ival].dueDate;
                    		var status =data[k][ival].Satus;
                    		if(status == "Ovrdue"){
                    			tblrow += '<span class="duered">'+ duDate + '</span>'
                    		}else{
                    			tblrow += '<span>'+ duDate + '</span>'
                    		}  
                    	}
                        tblrow += '</td>';
                        
                        tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var idd = "#" + myId;
                    		var ival = Object.keys(data[k])[i];
                    		var inAmt =data[k][ival].invoiceAmount;
                    		tblrow += '<span>'+ inAmt + '</span>'
                    	}
                        tblrow += '</td>';
                        
                        /*tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var idd = "#" + myId;
                    		var bal =Object.values(data[k])[i].balance;
                    		tblrow += '<span>'+ bal + '</span>'
                    	}
                        tblrow += '</td>';
                        
                        tblrow += "<td id='" + myId + "' >";
                    	for(var i = 0; i < lgth; i++){
                    		var idd = "#" + myId;
                    		var status =Object.values(data[k])[i].Satus;
                    		if(status == "Ovrdue"){
                    			tblrow += '<span class="duered">'+ status + '</span>'
                    		} else if(status == "Paid") {
                    			tblrow += '<span class="duegreen">'+ status + '</span>'
                    		}else{
                    			tblrow += '<span class="dueregular">'+ status + '</span>'
                    		}
                    	}
                        tblrow += '</td>';*/
                        
                        
                    	tblrow += '</tr>';
                    	$("#custom-detail-table tbody").append(tblrow);
                        });
				$('#custom-detail-table > tbody').html(tableData);
			
			}
			else {
				$('#orderResult1 #custom-detail-table').hide();
				$('#orderResult1 .pagination-con').hide();
				$('#orderResult1 .msg-stnd').show();
		}
		}
			
		}
    },
	getWebOrder : {
            init : function(params_) { 
				if($(".container").hasClass(params_.pageid)) {
				LSCA.loadingSpinner.showLoading();
				$(params_.target).find('table').attr('data-pagenum', '1');
                LSCA.globalAjax.doCall({
                    url : params_.url,
					target : params_.target
                }, function(response) {
						LSCA.getWebOrder.parseme(response, function() {
						});
						LSCA.mySalesaddPaging.makePageNav(params_, function(params_) {
							LSCA.mySalesaddPaging.pageData(params_)
						});
                });
				}
            },
			parseme : function(response, callback) {
				var data = response.data.webOrdersList;
				var tableData;
				console.log('web order : '+data);
				if (data) {
					LSCA.loadingSpinner.hideLoading();
					var len = data.length;
					if (len > 0) {
						$('#webOrderResult').show();
						$('#webOrderResult #custom-detail-table2').show();
						$('#webOrderResult .pagination-con').show();
						$('#webOrderResult .msg-stnd').hide();
						for (var i = 0; i < len; i++) {
							tblrow = '<tr>';
							tblrow += ' <td><a href=/common/myaccount/webOrderDetails.jsp?orderId='+data[i].sapOrderid+'&Ponum='+data[i].poNumber+'>' + data[i].sapOrderid + '</a></td>';
							tblrow += ' <td>' + data[i].orderDate + '</td>';
							tblrow += ' <td>' + data[i].poNumber + '</td>';
							netAmountCurrency = currFormatVal.format(data[i].netAmt);
							tblrow += ' <td>' + netAmountCurrency + ' ' + resultCurrencyVal + '</td>';
							tblrow += ' <td>' + data[i].status + '</td>';
							tblrow += '</tr>';
							tableData += tblrow;
						}
						$('#custom-detail-table2 > tbody').html(tableData);
					}
					else {
						$('#webOrderResult').hide();
						$('#webOrderResult .pagination-con').hide();
						//$('#webOrderResult .msg-stnd').show();
				}
			}
			}
    },
    disableDirectorView : function(params_) {
        if ($(".contentSection").hasClass(params_.pageId) && ($(params_.boolVal) == true)) {
            $("#thirtydays,#sixtydays,#nintydays,#df,#dt").attr('disabled', 'disabled');
        }
    },
    clearFields : function(params_) {
        $(params_.target).find('input[type=radio]').each(function() {
            $(this).on('click', function() {
                $(params_.target).find('input[type=text]').val("").attr("disabled", "disabled").removeClass("required");
                $(this).parents('div').children('input[type=text]').removeAttr("disabled").addClass("required");
            });
        });
    },
    addRowQOStoreland : {
        init : function(params_) {
            var mTitle = $('#Qty').attr("title");
            $('#addpartNew').on('submit', function(e) {
                e.preventDefault();
                valueObj = $(this).serializeArray();
                var partNum = (valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '');
                $('#Qty').attr('title', mTitle + " " + partNum)
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#addpartNew',
                    action : 'submit'
                });
                if (dovalidate) {
                    if (valueObj[1].value > 0 && valueObj[1].value < maxQuantity) {
                        if (LSCA.addRowQOStoreland.iteminlist({
                            target : $(params_.target).find('tbody')
                        }))
                            LSCA.addRowQOStoreland.parseme();
                        $(this).find('input[type="text"]').val('');
                        $(this).find('input#partNumber').focus();
                    } else if (valueObj[1].value < 1 && valueObj[1].value < maxQuantity) {
                        LSCA.showMsg.init({
                            key : 'wholenumber'
                        }, function(data) {
                            LSCA.GlobalValidate.showError('', data)
                        });
                        $(this).find('input#Qty').focus();
                    } else {
                        LSCA.showMsg.init({
                            key : 'validquantity'
                        }, function(data) {
                            LSCA.GlobalValidate.showError('', data)
                        });
                        $(".newError").hide();
                        $(this).find('input#Qty').focus();
                    }
                }
                $('#Qty').val('1');
            });
        },
        parseme : function(e) {
            var partNum = $.trim(valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '');
            var partQnt = $.trim(valueObj[1].value).replace(/[<>\s()\.\///'";]+/g, '');
            var tabRow = $('.skyblueTable tbody tr').length;
            if (lableObject != undefined) {
                var qtylbl = lableObject['qty'], partnolbl = lableObject['partno'], addcartlbl = lableObject['addcart'];
            }
            if (tabRow == 0) {
                tblui = '<table class="skyblueTable">';
                tblui += '<thead><tr><th>' + qtylbl + '</th><th>' + partnolbl + '</th><th></th></tr></thead>';
                tblui += '<tbody></tbody>';
                tblui += '</table><div class="btnPanel text-right"><button type="button" class="btn-stnd-medium">' + addcartlbl + '</button></div>';
                $("#quickorderWrap").html(tblui);
            }
            tblrow = '<tr id="' + partNum + '">';
            tblrow += ' <td><input name="' + partNum + '" type="text" maxlength = "4" value="' + partQnt + '"  /></td>';
            tblrow += ' <td>' + partNum + ' <input name="partNumber" type="hidden" value="' + partNum + '"/></td>';
            tblrow += ' <td><a href="javascript:void(0);" part-data="' + partNum + '" class="remove"></a></td>';
            tblrow += '</tr>';
            $('.skyblueTable tbody').append(tblrow);
            setTimeout(function() {
                LSCA.doButtonRound()
            }, 200);

            LSCA.addRowQOStoreland.removeitem({
                target : $('.skyblueTable tbody').find('#' + partNum + " a")
            });
            LSCA.addRowQOStoreland.submitAddCart({
                target : '#quickorder2',
                selector : '#addToCart'
            });
            if ($('.skyblueTable tbody tr').length > 0) {
                LSCA.showMsg.init({
                    key : 'cartdataloss'
                }, function(data) {
                    window.onbeforeunload = function() {
                        return $.trim(data);
                    }
                });
            } else {
                window.onbeforeunload = null;
            }
            ($('.skyblueTable tbody tr').length > 0) ? $('#promoImages').hide() : $('#promoImages').show();
        },
        iteminlist : function(options_) {
            var partNum = $.trim(valueObj[0].value).replace(/[<>\s()\.\///'";]+/g, '');
            itemrow = $(options_.target).find('tr#' + partNum);
            tqty = parseInt($(itemrow).find('input[name="' + partNum + '"]').val()) + parseInt(valueObj[1].value);
            if (itemrow.length > 0) {
                (tqty < maxQuantity) ? (itemrow).find('input[name="' + partNum + '"]').val(tqty) : $(".newError").show();
                return false;
            } else {
                $(".newError").hide();
                return true;
            }
        },
        removeitem : function(options_) {
            $(options_.target).on('click', function() {
                $('#productlist').show();
                window.onbeforeunload = null;
                $(this).parents('tr').remove();
                itemcount = $('.skyblueTable tbody tr').length;
                if (itemcount < 1) {
                    $('.skyblueTable thead').remove();
                    $('.skyblueTable').next(".btnPanel").remove();
                }
                LSCA.globalPaginate.init({
                    prevnext : true
                });
            });

        },
        submitAddCart : function(params_) {
            $(params_.target).attr('submit-chk', '');
            $(params_.target).find('button.btn-blue,button.btn-stnd-medium').on('click', function() {
                if ($(params_.target).attr('submit-chk') != undefined) {
                    window.onbeforeunload = null;
                    $(params_.target).removeAttr('submit-chk');
                    setTimeout(function() {
                        $(params_.selector).click()
                    }, 0);
                }
            });
        }
    },
    editField : function(params_) {
        $(params_.target).each(function() {
            $(this).on('click', function() {
                $(params_.grpId).val($(this).attr('id'));
                var getFormId = $(params_.target).parents('#tableBlock').next().next().attr('id');
                switch (getFormId) {
                    case 'updateGroupInfo': {
                        $(params_.grpName).val($(this).parents('tr').find('td:eq(0)').text());
                        $(params_.grpDesc).val($(this).parents('tr').find('td:eq(1)').text());
                        break;
                    }
                    case 'updateGroupId': {
                        $(params_.grpEmail).val($(this).parents('tr').find('td:eq(0)').text());
                        var radioVal = $(this).parents('tr').find('td:eq(1)').text();
                        $(params_.grpRadio).find('input[type=radio]').removeAttr('checked');
                        $(params_.grpRadio).find('input#' + radioVal).prop('checked');
                        $("#radioFields").find('input[type=radio]').each(function() {
                            if ($(this).val() === radioVal) {
                                $(this).attr('checked', 'checked');
                                $(this).click();
                            }
                        });
                        break;
                    }
                }
                $(".btnSave").removeAttr('disabled').focus();
                $(".btnNew").hide();
            });
        });
    },
    deleteField : function(params_) {
        $(params_.target).each(function() {
            $(this).on('click', function() {
                $(params_.grpId).val($(this).attr('id'));
                $('#removeItemBtn').click();
            });
        });
    },
    selectReset : {
        init : function(params_) {
            $('button[type="reset"]').on('click', function() {
                if ($(document).find('form').hasClass(params_.formid)) {
                    $('input[type="text"], input[type="number"], input[type="email"]').attr("value", "");
                    $('textarea').text("")
                    $(params_.target).each(function() {
                        var val_ = $(this).find('option:eq(0)').text();
                        $(this).prev("span").text(val_);
                    });
                }
            });
        }
    },
    getCategoryList : {
        init : function(params_) {
            params_.page = params_.page || 1;
            if ($('#mainContainer').hasClass(params_.pageid))
                LSCA.getCategoryList.populateList(params_, LSCA.getCategoryList.setPageing);
        },
        populateList : function(params_, callback) {
            var page = params_.page;
            LSCA.imageLoader.init({
                target : params_.selector
            });
            LSCA.globalAjax.doCall({
                url : '/store/includes/category/categoryList.jsp',
                data : {
                    catId : $('#catId').val(),
                    pageNumber : page
                },
                dataType : 'html',
                type : 'GET'
            }, function(data) {
                if (data != null || data != "") {
                    $("#categoryList").html(data.data);
                }
                if (callback && typeof callback === "function")
                    callback(params_);
            })
        },
        setPageing : function(params_) {
            $(params_.target).find('ul.pagination a').on('click', function(e) {
                e.preventDefault();
                if (params_.page != parseInt($(this).attr('id'))) {
                    params_.page = parseInt($(this).attr('id'));
                    $(this).off('click');
                    LSCA.getCategoryList.populateList(params_, LSCA.getCategoryList.setPageing);
                }

            });
        }
    },
    buttonClick : function() {
        $(".btn,.btn-stnd-medium,.btn-stnd-small,.link-stnd-default").each(function() {
            var btnID = $(this).attr('btn-id');
            if (typeof btnID != 'undefined' && btnID != '' && btnID != false) {
                $(this).on('click', function(e) {
                    e.preventDefault();
                    $(document).find('input#' + btnID).click();
                    $("#mainContainer.qckOrderUpload").find('input#addToCart').attr("disabled", "disabled");
                });
            }
        });
    },
    PrDetailAddToCart : {
        init : function(params_) {
            $('#addCart').on('click', function(e) {
                e.preventDefault();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#PrDetailForm',
                    action : 'submit'
                });
                var cartQty = $('.qtyTxtbox').val();
                /* Added code for Google Analytics */
                var prodDesc = $('#prodDesc').val();
                var prodPrice = $('#trackingListprice').val();
                var categoryName = $('#categoryName').val();
                var currencySymbol = $('#currencySymbol').val();
                var cartPNo = $("div.partNo").text();
                var catId = $('#categoryId').val();
                addtocartClick(currencySymbol, categoryName, cartPNo, prodPrice, 'Agilent Technologies', categoryName, prodDesc, cartQty, catId);
                if (dovalidate) {
                    if (cartQty > 0 && cartQty < maxQuantity) {
                        $('#addToCart').click();
                    } else {
                        $(".newError").show();
                    }
                }
            });
        }
    },
    promoData : {
        init : function(params_) {
            if ($("#mainContainer").hasClass(params_.pageId)) {
                LSCA.imageLoader.init({
                    target : params_.selector
                });
                LSCA.globalAjax.doCall({
                    url : params_.url,
                    type : 'GET',
                    dataType : 'html'
                }, function(data) {
                    if (data != null || data != "") {
                        $("#promoImages").html(data.data);
                        setTimeout(function() {
                            LSCA.doButtonRound()
                        }, 200);
                        $("#promoImages ul li:nth-child(3n)").addClass('last');
                        if ($("#promoImages ul li").length > 6) {
                            $("#promoImages ul li:gt(5)").addClass("hide");
                            $("#promoImages ul li:nth-child(3n)").addClass('last');
                            $("#promoImagesView").show();
                            LSCA.promoData.showAll(params_);
                        }
                    }
                });
            }
        },
        showAll : function(params_) {
            $(params_.target).on('click', function(params_) {
                $("#promoImagesView").hide();
                $("#promoImages ul li.hide").removeClass("hide");
            });
        }
    },
    requiredOnce : function(params_) {
        params_.flagchk = params_.flagchk || false;
        $("#btnProfileDataContinue").prop('disabled', false);
        if (params_.flagchk) {
            validate = ($('.container').hasClass('regUpd')) ? true : false
        } else {
            validate = true
        }
        $(params_.target).on('click', function(e) {
            if (validate) {
                e.preventDefault();
                var count = 0, error = false, errorstr = '';
                $('.errorMessages div').html('');
                if (LSCA.GlobalValidate.init({
                    target : $(params_.target).parents('form'),
                    action : 'submit'
                })) {
                    $("#regProf").click();
                    $("#btnProfileDataContinue").prop('disabled', true);
                }
                if (error)
                    LSCA.GlobalValidate.showError('', errorstr);
            } else {
                $("#regProf").click();
                $("#btnProfileDataContinue").prop('disabled', true);
            }
        });
    },
    submitForm : function(params_) {
        params_.button = params_.button || $(params_.form).find('button');
        $(params_.form).find(params_.button).on('click', function(e) {
            e.preventDefault();
            window.onbeforeunload = null;
            $(params_.form).submit();
        });
    },
    checkboxReset : function(params_) {
        $('button[type="reset"]').on('click', function() {
            $(params_.selector).find("input:checkbox").each(function() {
                $(this).attr('checked', false).parent("span").removeClass('checked');
            })
        })
    },
    formValidate : {
        init : function(params_) {
            $(params_.selector).on('click', function() {
                formdata = $(params_.target).serialize();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : params_.target,
                    action : 'submit'
                }, LSCA.formOptionalRequired.init({
                    selector : '#givenName',
                    ClassName : 'email'
                }));
                if (dovalidate) {
                    LSCA.globalAjax.doCall({
                        url : params_.url,
                        dataType : 'html',
                        data : formdata,
                        target : params_.target
                    }, function(data) {
                        $("#pageContentDiv").html(data.data);
                        if ($(params_.target).hasClass("showpopup")) {
                            if ($(document).find(params_.selector).hasClass("sendEmail")) {
                                $(".emailId").html($("#inputEmail1").val());
                            }
                            $("#myModal").modal();
                        }
                    });
                }
            });
        }
    },
    imageLoader : {
        init : function(params_) {
            $(params_.target).prepend("<ul><li><div id='loader'><img src='/store/images/loading.gif' alt='Loading...' /></div></li></ul>");
        }
    },
    formOptionalRequired : {
        init : function(params_) {
            formvalue = $(params_.selector).val();
            if (!formvalue == "") {
                $(params_.selector).addClass(params_.ClassName);
            } else {
                $(params_.selector).removeClass(params_.ClassName);
            }
        }
    },
    langShowHide : {
        init : function(params_) {
            var divID = $('#langShowHide input[checked]').attr('value');
            $('#langWrap span').hide();
            $('.' + divID).show();
            $(params_.selector).on('click', function() {
                var divID = $(this).attr('value');
                $('#langWrap span').hide()
                $('.' + divID).show();
            });
        }
    },
    redeemQuoteValidate : {
        init : function(params_) {

            var purchaseOrder = $(".redeemQuote input#po");
            var emailCheck = $(".redeemQuote input#payerInvoiceEmail");

            var upsNumber = $("#RedeemQuoteupsNumber");
            var upsNumberHidden = $("#RedeemQuoteupsNumberHidden");
            var UPSApply = $("#UPSApply");
            var UPSRemove = $("#UPSRemove");
            var UPSGrp = $(".ups-app-rem");
            var UPSCheck = $("#UpsCheck");

            var fedExNumber = $("#RedeemQuotefedExnumber");
            var fedExNumberHidden = $("#RedeemQuotefedExnumberHidden");
            var fedExApply = $("#fedExApply");
            var fedExRemove = $("#fedExRemove");
            var fedExGrp = $(".fedex-app-rem");
            var fedExCheck = $("#fedExCheck");

            purchaseOrder.on('keyup', function() {
                if ($(this).val()) {
                    $(this).css('border-color', '#e0e0e0');
                } else {
                    $(this).css('border-color', 'red');
                }
            });
            emailCheck.on('keyup', function() {
                if ($(this).val()) {
                    $(this).css('border-color', '#e0e0e0');
                } else {
                    $(this).css('border-color', 'red');
                }
            });


			 if($('#mainContainer').hasClass('redeemQuoteNew')){ 
				fedExNumber.on('input', function() {
					if ($(this).val()) {
						$(fedExApply).show();
						$(fedExRemove).hide();
					} else {
						$(fedExApply).hide();
						$(fedExRemove).hide();
					}					
				});			 
				upsNumber.on('input', function() {
					if ($(this).val()) {
						$(UPSApply).show();
						$(UPSRemove).hide();
					} else {
						$(UPSApply).hide();
						$(UPSRemove).hide();
					}
				});						
				fedExApply.click(function(e) {					
					e.preventDefault();
					$(this).hide()
					$('#UPSApply,#UPSRemove').hide()
					$("#fedExRemove").show();
					$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully applied.');
					$("#fedex_ups_msg").show();	
					fedExCheck.val("true");
					fedExNumberHidden.val(fedExNumber.val());					
					UPSCheck.val("false");
					upsNumberHidden.val('');
					upsNumber.val('');		
					$("#RedeemQuotefedExnumber,#RedeemQuoteupsNumber").removeClass('requiredTextBox')
				});
				fedExRemove.click(function(e) {	
					e.preventDefault();	
					$(this).hide()					
					$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully removed.');
					$("#fedex_ups_msg").show();	
					UPSCheck.val("false");
					upsNumberHidden.val('');
					fedExCheck.val("false");
					fedExNumberHidden.val('');	
					fedExNumber.val('');						
				});
				UPSApply.click(function(e) {
					e.preventDefault();
					$(this).hide()
					$('#fedExApply,#fedExRemove').hide()
					$("#UPSRemove").show();
					$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully applied.');
					$("#fedex_ups_msg").show();		
					UPSCheck.val("true");
					upsNumberHidden.val(upsNumber.val());					
					fedExCheck.val("false");
					fedExNumberHidden.val('');	
					fedExNumber.val('');	
					$("#RedeemQuotefedExnumber,#RedeemQuoteupsNumber").removeClass('requiredTextBox')					
				});				
				UPSRemove.click(function(e) {
					e.preventDefault();
					$(this).hide()
					$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully removed.');
					$("#fedex_ups_msg").show();					
					UPSCheck.val("false");
					upsNumberHidden.val('');
					upsNumber.val('');	
					fedExCheck.val("false");
					fedExNumberHidden.val('');						
				});		 
			 }
			 else
			 {	
            upsNumber.on('keyup', function() {
                if ($(this).val()) {
                    UPSApply.show();
                } else {
                    UPSApply.hide();
                }
            });

            fedExNumber.on('keyup', function() {
                if ($(this).val()) {
                    fedExApply.show();
                } else {
                    fedExApply.hide();
                }
            });
			/* For FedEx validation */
            fedExApply.click(function(e) {
                e.preventDefault();
                fedExApply.hide();
				UPSApply.hide();
				$("#fedex_ups_msg").hide();		
                fedExNumber.attr("disabled", "disabled");
                fedExCheck.val("true");
                fedExNumberHidden.val(fedExNumber.val());
				$("#RedeemQuotefedExnumber,#RedeemQuoteupsNumber").removeClass('requiredTextBox')
                upsNumber.attr("disabled", "disabled");
                UPSGrp.hide();
                UPSCheck.val("false");
                upsNumberHidden.val('');
				upsNumber.val('');
                LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
            });

            fedExRemove.click(function(e) {
                e.preventDefault();
                fedExRemove.hide();
				$("#fedex_ups_msg").hide();	
				$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully removed.');
                fedExNumber.val('').removeAttr("disabled");
                fedExNumberHidden.val('');
                fedExCheck.val("false");
                upsNumber.removeAttr("disabled");
                LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
            });

            /* For UPS validation */
            UPSApply.click(function(e) {
                e.preventDefault();
                UPSApply.hide();
				fedExApply.hide();
				$("#fedex_ups_msg").hide();		
                upsNumber.attr("disabled", "disabled");
                UPSCheck.val("true");
                upsNumberHidden.val(upsNumber.val());
				$("#RedeemQuotefedExnumber,#RedeemQuoteupsNumber").removeClass('requiredTextBox')
                fedExNumber.val('').attr("disabled", "disabled");
                fedExGrp.hide();
                fedExCheck.val("false");
                fedExNumberHidden.val('');
				fedExNumber.val('');
                LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
            });

            UPSRemove.click(function(e) {
                e.preventDefault();
                UPSRemove.hide();
				$("#fedex_ups_msg").hide();	
				$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully removed.');
                upsNumber.val('').removeAttr("disabled");
                UPSCheck.val("false");
                upsNumberHidden.val('');
                fedExNumber.removeAttr("disabled");
                LSCA.redeemQuoteDeliveryOptions.doAjaxCall(e, params_);
            });
			 }
            /* For email validation */
            $(document).on("click", "#invoiceEmailId div.checker span", function(e) {
                className = $(this).attr("class");
                if (className == "checked") {
                    if (emailCheck.val()) {
                        emailCheck.css('border-color', '#e0e0e0');
                    } else {
                        emailCheck.css('border-color', 'red');
                    }
                } else {
                    emailCheck.css('border-color', '#e0e0e0');
                }
            });

            $('#btnPOSubmitOrder').on('click', function() {
            	$('.redeemQuote #step3.eMethod textarea,.redeemQuote #step3.eMethod input').removeClass("requiredLabel requiredTextBox requiredVal required");
				var flagErrFieldValue = true;
                formdata = $(params_.target).serialize();
                if ($(this).attr('id') == "btnPOSubmitOrder" && $("#agreeCheckbox").length && !$("#agreeCheckbox").is(":checked")) {
                    $("#checkboxModal").modal();
                } else {
                    setInvoiceTitles();
                    var dovalidate = LSCA.GlobalValidate.init({
                        target : params_.target
                    });
                    resetInvoiceTitles();
                    var redeemSubmit = true;	
    				var redeemTelSubmit = true;
                }
                if ($('#userCountryValue').val() == "CN") {
					var shipAttentionValue = $("#attentionSP").val();
					if (shipAttentionValue == ""){
					   $(".attentionSPReqMsg").removeClass("hide");
					   $("#attentionSP").addClass("errMsgBorder");
					   $(".redeemAttentionLbl").addClass("errMsgTxt");
					   redeemSubmit = false;
					} 
					else {
					   $(".attentionSPReqMsg").addClass("hide");
					   $("#attentionSP").removeClass("errMsgBorder");
					   $(".redeemAttentionLbl").removeClass("errMsgTxt");
					   redeemSubmit = true;
					}
					var shipAttentionValue = $("#telephoneSP").val();
					if (shipAttentionValue == ""){
					   $(".telephoneSPReqMsg").removeClass("hide");
					   $("#telephoneSP").addClass("errMsgBorder");
					   $(".redeemPhoneLbl").addClass("errMsgTxt");
					   redeemTelSubmit = false;
					} else {
					   $(".telephoneSPReqMsg").addClass("hide");
					   $("#telephoneSP").removeClass("errMsgBorder");
					   $(".redeemPhoneLbl").removeClass("errMsgTxt");
					   redeemTelSubmit = true;
					} 
                }
                if ($('#userCountryValue').val() == "IT") {
                    if ($('#invoiceCode1').val() == "") {
                    	$('#invoiceCode1').addClass('requiredTextBox');
                    	$('#CUUError').show();
                    	$('#Cuu-label').addClass('requiredLabel');
                    	 redeemSubmit = false;
                    } else {
                    	$('#invoiceCode1').removeClass('requiredTextBox');
                    	$('#CUUError').hide();
                    	$('#Cuu-label').removeClass('requiredLabel');
                    	 redeemSubmit = true;
                    }
                }
                if ($('#mandatoryUEU').val() == "true") {
                	if ($('#UEUApplied').val() == "") {
                		$('#inputUEUNumber').addClass('requiredTextBox');
                    	$('#applyUEU').show();
                		redeemSubmit = false;
                	}
                	else {
                		$('#inputUEUNumber').removeClass('requiredTextBox');
                    	$('#applyUEU').hide();
                		redeemSubmit = true;
                	}
                }
                if ($('#addCCEmail').is(':visible') && $('#addCCEmail').val() != '') {
            		var emails = $('#addCCEmail').val().split(';');
            		 for (var i = 0; i < emails.length; i++) {
                    var mailarr = emails[i], f = true;                                
                        if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                            f = false;                
                    if (!f) {
                    	$('#addCCEmail').addClass('requiredTextBox');
                    	$('#invalidEmail').show();
                    	redeemSubmit = false;
                    	break;
    				}else{
    					$('#addCCEmail').removeClass('requiredTextBox');
    					$('#invalidEmail').hide();
    					redeemSubmit = true;
    				} 
            	}
    			}               
                
                $('#shippingAddressSection ~ .revieworderValue input.requiredVal').each(function(i) {
                    if($(this).val() == ''){     
						$(this).prev('.requiredLabelVal').addClass('errMsgTxt');
						$(this).next().next().removeClass("hide");
						$(this).addClass("errMsgBorder");     
						flagErrFieldValue = false;
						}
					else {
						$(this).prev('.requiredLabelVal').removeClass('errMsgTxt');
						$(this).next().next().addClass("hide");
						$(this).removeClass("errMsgBorder");						
                    }
				});          	
            	if(dovalidate && redeemSubmit && redeemTelSubmit && flagErrFieldValue && !($('#mainContainer').hasClass('redeemQuoteNew'))) {
					 $('#sbmtOrder').click();
					 $(".redeemQuote #btnPOSubmitOrder").prop('disabled', true);
				}
                
            });
			//new redeem quote submit
			$('.redeemQuoteNew #btnPOSubmitOrder').on('click', function(e) {				
				e.preventDefault();		
				$('#loading,#pageLoader').hide();
				termsConditionCheck();				
			
			});	
			//new redeem quote cc  submit
			$('#btnnewCCSubmitOrder').on('click', function(e) {
				e.preventDefault();				
				$('#loading,#pageLoader').hide();
				$('.redeemQuoteNew .checkoutShippingBilling .form-group input#po').removeClass('requiredTextBox');
				termsConditionCheck();				
            });	
			var tcCheck,redeemSubmit,payerEmailSUb,redeemEmailCheck,pageerror=false;
			function termsConditionCheck(){
				if ($(".terms-condition input").length && !$(".terms-condition input").is(":checked")) {
					$(".terms-condition .termsContent").addClass("required");
					$("#uniform-agreeCheckbox span").addClass("requiredTextBox");
					$(".terms-condition .termsContentother").addClass("requiredTextBoxClass");
					$("#tandcErrorMsg").show();
					tcCheck=false;
				}
				else{
					$(".terms-condition .termsContent").removeClass("required");
					$("#uniform-agreeCheckbox span").removeClass("requiredTextBox");
					$(".terms-condition .termsContentother").removeClass("requiredTextBoxClass");
					$("#tandcErrorMsg").hide();
					tcCheck=true;
				}	
				if ($(".terms-conditioncn input").length && !$(".terms-conditioncn input").is(":checked")) {
					$(".terms-conditioncn input").addClass("requiredTextBox");
					$("#tandcErrorMsgcn").show();
				}
				else{
					$(".terms-conditioncn input").removeClass("requiredTextBox");
					$("#tandcErrorMsgcn").hide();
				}		
			if ($('#addCCEmail').is(':visible') && $('#addCCEmail').val() != '') {
				var emails = $('#addCCEmail').val().split(';');
				 for (var i = 0; i < emails.length; i++) {
				var mailarr = emails[i], f = true;                                
					if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
						f = false;                
				if (!f) {
					$('#addCCEmail').addClass('requiredTextBox');
					$('#invalidEmail').show();
					redeemSubmit = false;
					break;
				}else{
					$('#addCCEmail').removeClass('requiredTextBox');
					$('#invalidEmail').hide();
					redeemSubmit = true;
				} 
			}
			}else{
				$('#addCCEmail').removeClass('requiredTextBox');
				$('#invalidEmail').hide();
				redeemSubmit = true;				
			}		
			if ($('#fspAccountNumberInput').is(':visible') && $('#fspAccountNumberInput').val() == '' && $('#fspAccountNumberInput').attr('disabled') == undefined) {
				$('#fspAccountNumberInput').addClass('requiredTextBox');
				fsptextbox = false;
			}else{
				$('#fspAccountNumberInput').removeClass('requiredTextBox');
				fsptextbox = true;
			}
			if ($(".checkoutShippingBilling #fetchDeliveryOption input[name='delivery']:checked").val() == 'DeliveryDate') {
				if($('.checkoutShippingBilling #fetchDeliveryOption input#calender').val() == '') {
					$('.checkoutShippingBilling #fetchDeliveryOption input#calender').addClass('requiredTextBox');
					$('.checkoutShippingBilling #fetchDeliveryOption input#calender').next().next().next().show();
					redeemfutureDateFieldVal = false;
				}
				else {
					$('.checkoutShippingBilling #fetchDeliveryOption input#calender').removeClass('requiredTextBox');
					$('.checkoutShippingBilling #fetchDeliveryOption input#calender').next().next().next().hide();
					redeemfutureDateFieldVal = true;
				}
			}else{
				$('.checkoutShippingBilling #fetchDeliveryOption input#calender').removeClass('requiredTextBox');
				$('.checkoutShippingBilling #fetchDeliveryOption input#calender').next().next().next().hide();
				redeemfutureDateFieldVal = true;
			}				
			if ($('#po').is(':visible') && $('#po').val() == '') {
				$('#po').addClass('requiredTextBox');
			}else{
				$('#po').removeClass('requiredTextBox');
			}			
				if ($('#payerInvoiceEmail').is(':visible') && $('#payerInvoiceEmail').val() != '') {
					var emails = $('#payerInvoiceEmail').val().split(',');
					 for (var i = 0; i < emails.length; i++) {
					var mailarr = emails[i], f = true;                                
						if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
							f = false;                
					if (!f) {
						$('#payerInvoiceEmail').addClass('requiredTextBox');
						$('#invalidPayerEmail').show();
						payerEmailSUb = false;
						break;
					}else{
						$('#payerInvoiceEmail').removeClass('requiredTextBox');
						$('#invalidPayerEmail').hide();
						payerEmailSUb = true;
					} 
				}
				}else{
						$('#payerInvoiceEmail').removeClass('requiredTextBox');
						$('#invalidPayerEmail').hide();
						payerEmailSUb = true;					
				} 
				if ($('#contactEmail').is(':visible') && $('#contactEmail').val() != '') {
					var emails = $('#contactEmail').val().split(',');
					 for (var i = 0; i < emails.length; i++) {
					var mailarr = emails[i], f = true;                                
						if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
							f = false;                
					if (!f) {
						$('#contactEmail').addClass('requiredTextBox');
						$('#contactinvalidEmail').show();
						redeemEmailCheck = false;
						break;
					}else{
						$('#contactEmail').removeClass('requiredTextBox');
						$('#contactinvalidEmail').hide();
						redeemEmailCheck = true;
					} 
				}
				}else{
						$('#contactEmail').removeClass('requiredTextBox');
						$('#contactinvalidEmail').hide();
						redeemEmailCheck = true;					
				}	
			$('.redeemQuoteNew input.required').each(function(){
				if($(this).val() == '') {
					$(this).addClass('requiredTextBox').prev().addClass('requiredLabel');
					$(this).next().show();
				}
				else {
					$(this).removeClass('requiredTextBox').prev().removeClass('requiredLabel');
					$(this).next().hide();
					pageerror=true
				}                   
			})   		
			$('.redeemQuoteNew .modal input').removeClass('requiredTextBox');				
			if($(".redeemQuoteNew input").hasClass("requiredTextBox")){
				$('html, body').animate({
				scrollTop: $(".requiredTextBox").offset().top - 50
			  }, 500);
			  $('.redeemQuoteNew .order-summary-total-section #btnPOSubmitOrder').removeAttr('disabled')
			  pageerror=false
			  return false
			}else{
				pageerror=true
			}	
			if($('#btnPOSubmitOrder').is(':visible') && payerEmailSUb && redeemEmailCheck && redeemSubmit && tcCheck && pageerror && fsptextbox && redeemfutureDateFieldVal){
				 LSCA.loadingSpinner.showLoading();
				 $('#btnPOSubmitOrder').attr('disabled',true);	
				 copyFormTextFields();	   
				 if($('.redeemQuoteNew #editQuote').val()=="true" && changedQtyFlagcheck){
						editQuoteAjaxCall();
				 }
			     $('#sbmtQuoteOrder').click();				 			 
				 //alert('PO')
			}else if($('#btnnewCCSubmitOrder').is(':visible') && payerEmailSUb && redeemEmailCheck && redeemSubmit && tcCheck && pageerror && fsptextbox && redeemfutureDateFieldVal){
				//alert('CC')
				LSCA.loadingSpinner.showLoading();
				$('#btnnewCCSubmitOrder').attr('disabled',true);
				formdata = $(params_.target).serialize();
                setInvoiceTitles();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : params_.target
                });
                resetInvoiceTitles();
                if (dovalidate) {
                    setCyberSourceData();
                    if($('.redeemQuoteNew #editQuote').val()=="true" && changedQtyFlagcheck){
						editQuoteAjaxCall();
					}
                    $('#submitCC').click();
                }
			}			
			}		
            $('#btnCCSubmitOrder').on('click', function() {
                formdata = $(params_.target).serialize();
                setInvoiceTitles();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : params_.target
                });
                resetInvoiceTitles();
                if (dovalidate) {
                    setCyberSourceData();
                    $('#submitCC').click();
                }
            });
        },
        fedExUPSCallBack : function(params_) {
            if ($("#fedExCheck").val() === "true") {
                $("#fedExRemove").show();
				$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully applied.');
				$("#fedex_ups_msg").show();				
            }else{
				$("#fedex_ups_msg").show();			
			}
            if ($("#UpsCheck").val() === "true") {
                $("#UPSRemove").show();
				$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully applied.');
				$("#fedex_ups_msg").show();				
            }else{
				$("#fedex_ups_msg").show();			
			}
        }
    },
    NormalFormValidate : {
        init : function(params_) {
        	var soldToFlagCheck=false;
            $(params_.selector).on('click', function() {
            	if((!$(this).hasClass('craditCardbtnPlaceOrder'))&& ($('#mainContainer').hasClass('checkoutShippingBilling'))){
					$.ajax({
						type: "POST",
						contentType: "application/json; charset=utf-8",
						async: false,
						url: "/rest/model/com/agilent/commerce/SoldToVerification?atg-rest-output=json",
						data: JSON.stringify({
							"soldToVerify": {
								"soldToNumber": $(".checkoutShippingBilling #soldToNumber").val()
							}
						}),
						
						success: function (responsedata) {
						   if(responsedata.checkSoldToDetailsResponse == true){
							   soldToFlagCheck=true;
								window.location.href="/common/cart.jsp";
							}
						},
						dataType: "json"
					});
				}
                formdata = $(params_.target).serialize();
                /* for UPS and FEDEX validation */
                if ($(params_.selector).hasClass('sbmtCreate')) {
                    if (($("#inputFedEx").val().length == 0) && ($("#inputUPS").val().length == 0)) {
                        $("#fedExForm").find("#inputUPS").removeClass("required");
                        $("#fedExForm").find("#inputFedEx").attr('title', "Please enter FedEx or UPS number");

                    } else if (($("#inputFedEx").val().length != 0) || ($("#inputUPS").val().length != 0)) {
                        $("#fedExForm").find("#inputUPS").removeClass("required");
                        $("#fedExForm").find("#inputFedEx").removeClass("required");
                    }
                }
                if ($(params_.target).hasClass("OptionalRequired")) {
                    var dovalidate = LSCA.GlobalValidate.init({
                        target : params_.target
                    }, LSCA.formOptionalRequired.init({
                        selector : '.optionalEmail1',
                        ClassName : 'email'
                    }), LSCA.formOptionalRequired.init({
                        selector : '.optionalEmail2',
                        ClassName : 'email'
                    }), LSCA.formOptionalRequired.init({
                        selector : '.optionalEmail3',
                        ClassName : 'email'
                    }));
                } else {
                    /* added if check for CR APP-3755 China Direct Customers */
                    if ($(this).attr('id') == "btnPlaceOrder" && $("#agreeCheckbox").length && !$("#agreeCheckbox").is(":checked")) {
                        $("#checkboxModal").modal();
                    } else {
                        var dovalidate = LSCA.GlobalValidate.init({
                            target : params_.target
                        });
                    }
                }
                if (dovalidate) {
                    // PM5189322-IM148322575 - start
                    var subFlag = true;
                    if ($(this).attr('id') == "btnPlaceOrder") {
                    	if ($('#userCountryValue').val() == "IT") {
                            if ($('#invoiceCode1').val() == "") {
                            	$('#invoiceCode1').addClass('requiredTextBox');
                            	$('#CUUError').show();
                            	$('#Cuu-label').addClass('requiredLabel');
                            	subFlag = false;
                            	$("#btnPlaceOrder").prop('disabled', false);
                            } else {
                            	$('#invoiceCode1').removeClass('requiredTextBox');
                            	$('#CUUError').hide();
                            	$('#Cuu-label').removeClass('requiredLabel');
                            	subFlag = true;
                            	$("#btnPlaceOrder").prop('disabled', true);
                            }
                        }
                    	$('#ccEmailtoSAP').removeClass('requiredTextBox');
    					$('#invalidEmail').hide();
    					$('#payerInvoiceEmail').removeClass('requiredTextBox');
    					$('#payerInvoiceEmail').css('border-color', '#e0e0e0');
    					$('#invalidPayerEmail').hide();
    					var ccEmailSUb = true;
    					var payerEmailSUb = true;
                    	if ($('#ccEmailtoSAP').is(':visible') && $('#ccEmailtoSAP').val() != '') {
                    		var emails = $('#ccEmailtoSAP').val().split(';');
                    		 for (var i = 0; i < emails.length; i++) {
                            var mailarr = emails[i], f = true;                                
                                if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                                    f = false;                
                            if (!f) {
                            	$('#ccEmailtoSAP').addClass('requiredTextBox');
                            	$('#invalidEmail').show();
                            	ccEmailSUb = false;
                            	break;
            				}else{
            					$('#ccEmailtoSAP').removeClass('requiredTextBox');
            					$('#invalidEmail').hide();
            					ccEmailSUb = true;
            				} 
                    	}
            			}
                    	if ($('#payerInvoiceEmail').is(':visible') && $('#payerInvoiceEmail').val() != '') {
                    		var emails = $('#payerInvoiceEmail').val().split(',');
                    		 for (var i = 0; i < emails.length; i++) {
                            var mailarr = emails[i], f = true;                                
                                if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                                    f = false;                
                            if (!f) {
                            	$('#payerInvoiceEmail').addClass('requiredTextBox');
                            	$('#invalidPayerEmail').show();
                            	payerEmailSUb = false;
                            	break;
            				}else{
            					$('#payerInvoiceEmail').removeClass('requiredTextBox');
            					$('#invalidPayerEmail').hide();
            					payerEmailSUb = true;
            				} 
                    	}
            			}
                    	if(payerEmailSUb && ccEmailSUb) {
                    		subFlag = true;
                    	}
                    	else {
                    		subFlag = false;
                    	}
                    }
					var poFieldCheck = true;
					var flagFieldVal = true;
					var futureDateFieldVal = true;
					var shipAdressCheck = $('#emptyShipAddressFlag').val();
					var billingAdressCheck = $('#emptyBillAddressFlag').val();
					var addressErrorMessage = $('#emptyAddressErrorMessage').val();
					var emptyDeleteShipAddress = $('#emptyDeleteShipAddressFlag').val();
					$('.checkoutShippingBilling .checkout-col-left input.required:not(#inputShipto,#po,#fspAccountNumberInput,#inputUEUNumber)').each(function(i) {
						//console.log($(this).val());
						if($(this).val() == '') {
						//console.log($(this).attr('class'));
						$(this).addClass('requiredTextBox');
						$(this).prev('.fieldLabel').addClass('requiredLabel');
						$(this).next().next().show();
						flagFieldVal = false;
						}
						else {
						$(this).removeClass('requiredTextBox');
						$(this).prev('.fieldLabel').removeClass('requiredLabel');
						$(this).next().next().hide();
						flagFieldVal = true;
						}
					});
					if ($(".checkoutShippingBilling .redQuote input[name='pOrder']:checked").val() == 'purchaseOrder') {
						if($('.checkoutShippingBilling .redQuote input#po').val() == '') {
							$('.checkoutShippingBilling .redQuote input#po').addClass('requiredTextBox');
							$('.checkoutShippingBilling .redQuote #purchaseOrderLabel').addClass('requiredLabel');
							$('.checkoutShippingBilling .redQuote input#po').next().next().show();
							poFieldCheck = false;
						}
						else {
							$('.checkoutShippingBilling .redQuote input#po').removeClass('requiredTextBox');
							$('.checkoutShippingBilling .redQuote #purchaseOrderLabel').removeClass('requiredLabel');
							$('.checkoutShippingBilling .redQuote input#po').next().next().hide();
							poFieldCheck = true;
						}
					}
					if ($(".checkoutShippingBilling #fetchDeliveryOption input[name='delivery']:checked").val() == 'DeliveryDate') {
						if($('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').val() == '') {
							$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').addClass('requiredTextBox');
							//$('.checkoutShippingBilling #fetchDeliveryOption #purchaseOrderLabel').addClass('requiredLabel');
							$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').next().next().next().show();
							futureDateFieldVal = false;
						}
						else {
							$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').removeClass('requiredTextBox');
							//$('.checkoutShippingBilling .redQuote #purchaseOrderLabel').removeClass('requiredLabel');
							$('.checkoutShippingBilling #fetchDeliveryOption input#deliveryCalender').next().next().next().hide();
							futureDateFieldVal = true;
						}
					}
					if ($(".terms-conditioncn input").length && !$(".terms-conditioncn input").is(":checked")) {
						$(".terms-conditioncn input").addClass("requiredTextBox");
						$("#tandcErrorMsgcn").show();
					}
					else{
						$(".terms-conditioncn input").removeClass("requiredTextBox");
						$("#tandcErrorMsgcn").hide();
					}						
					$('#change-edit-shiping-modal input,#addBillingPopup input').removeClass('requiredTextBox');
					if($(".checkoutShippingBilling input").hasClass("requiredTextBox")){
						$('html, body').animate({	scrollTop: $(".requiredTextBox").offset().top - 50	}, 500);
						$('.checkoutShippingBilling .order-summary-outer .pobtnPlaceOrder').prop("disabled",false);
						pageerror=false
						return false
					}else{
						pageerror=true
					}		

					var addBillCheck=true;
					if($('#emptyShipAddressFlag').length){
						if(shipAdressCheck == 'true' || billingAdressCheck == 'true' || emptyDeleteShipAddress == 'true'){
							$('.sectionFirst').next('.msg-stnd').remove();
							$('<div class="msg-stnd errStnd multi" style="align-items: flex-start;"><div class="custom-msg-icon"><i class="fal fa-exclamation-circle"></i><span>'+addressErrorMessage+'</span></div></div>').insertAfter('.sectionFirst')
							$('html, body').animate({	scrollTop: 0}, 500);
							addBillCheck=false
						}else{
							$('.sectionFirst').next('.msg-stnd').remove();
							addBillCheck=true
						}	
					}					
					
					//console.log(flagFieldVal);
					if(subFlag && flagFieldVal && poFieldCheck && futureDateFieldVal && !soldToFlagCheck && pageerror && addBillCheck && !($('#mainContainer').hasClass('redeemQuoteNew'))) {
						LSCA.loadingSpinner.showLoading();
						setTimeout(function() {
						$(params_.target2).click()
						}, 0);
					} else{
						if(!$('#mainContainer').hasClass('redeemQuoteNew')){
							LSCA.loadingSpinner.hideLoading();
						}	
					}
					
                	/*if(subFlag) {
                        setTimeout(function() {
                            $(params_.target2).click()
                        }, 0);
                    }*/
                    // PM5189322-IM148322575 - end
                }
            });
        }
    },
    onCheckButtonDisable : function(params_) {
        $(params_.target).on('click', function() {
            var checkValue = ($(this).prop("checked"));
            if (checkValue == true) {
                $(params_.selector).removeAttr("disabled");
            } else {
                $(params_.selector).attr('disabled', "disabled")
            }
        });
    },
    webOrderSubmit : function(params_) {
        $(params_.target).on('click', function() {
            $(params_.selector).click();
        });
    },
    onClickButtonEnable : function(params_) {
        $(params_.target).on('click', function() {
            $(params_.selector).removeAttr("disabled");
        });
    },
    selectOptionSelected : {
        init : function(params_) {
            $(params_.target).each(function() {
                $(this).on('click', function() {
                    var routingItemValue = $(this).parents("td").find("#routingItemValue").val();
                    $(params_.updateValue1).val($(this).attr('id'));
                    $(params_.updateValue2).val(routingItemValue);
                    var linkValue = $.trim($(this).parents("tr").find(params_.dataValue).text());
                    $(params_.selector).find("option").each(function() {
                        var optionValue = $.trim($(this).text());
                        if (linkValue == optionValue) {
                            $(this).prop("selected", true);
                            if ($(params_.selector).prop("disabled") == false) {
                                var val_ = $(this).text();
                                $(params_.selector).prev("span").text(val_);
                            }
                        }
                    })
                }, LSCA.onClickButtonEnable({
                    target : '.editSelect',

                    selector : '.btnSave'
                }), LSCA.onCheckButtonDisable({
                    target : '.editSelect',
                    selector : '.btnNew'
                }))
            })
        }
    },
    linkClickButtonSubmit : function(params_) {
        $(params_.target).on('click', function() {
            $(this).parents(params_.parentselector).find(params_.selector).click();
        });
    },
    selectedRadioValue : function(params_) {
        $(params_.target).each(function() {
            var checkStatus = ($(this).prop("checked"));
            if (checkStatus == true) {
                $("#routingNewItemValue").val($(this).val());
            }
        });
    },
    emptyShoppingCart : function(params_) {
        $(params_.target).on('click', function() {
            var anwser = confirm('Are you sure want to clear your Shopping Cart?')
            if (anwser) {
                /* create request array */
                var bulkDelAjax = '';
                $("#cartTable tbody .skyblueTable tbody tr.favCatCartstock").each(function() {
                    if ($(this).hasClass("bottomshadow")) {
                    } else {
                        cId = $(this).find("a.remove").attr("id");
                        pNo = $(this).find("a.remove").attr("part-num");
                        prdQnty = $(this).prev().find("input[name=" + cId + "]").val();
                        bulkDelAjax = bulkDelAjax + "catalogIds=" + pNo + "&" + pNo + "=" + prdQnty + "&";
                        bulkDelPage = "bluk cart remove";
                    }
                });
                callAjaxMethodRemove(bulkDelAjax, bulkDelPage);
                /* create request array ends here */
                setTimeout(function() {
                    $("#emptyCartBtn").click()
                }, 3000);
            } else {
                return false;
            }
        })
    },
    textValueButtonDisable : function(params_) {
        var textValue = $(params_.target).val();
        if (!textValue == "") {
            $(params_.selector).attr('disabled', "disabled");
        } else {
            $(params_.selector).removeAttr("disabled");
        }
    },
    searchSubmit : function() {
        $("#searchForm").on('submit', function(e) {
            e.preventDefault();
            var input = $('#searchinput').val();
            if ($.cookie)
                var cookie_locale = $.cookie('agilent_locale');
            window.location = "/search/?Ntt=" + input;
        });
    },
    autoFocus : function(params_) {
        $(params_.target).focus();
    },
    showDiv : {
        init : function(params_) {
            $(params_.target).click(function() {
                $(params_.selector).show();
                LSCA.showDiv.hideDiv({
                    selector : params_.selector,
                    target : '.closeDiv'
                })
            })
        },
        hideDiv : function(params_) {
            $(params_.target).click(function() {
                $(params_.selector).hide();
            })

        }
    },
    replaceSpecialChar : function(params_) {
        $(params_.target).keyup(function() {
            var $this = $(this);
            $this.val($this.val().replace(/[^\d]/g, ''));
        });
    },
    srchAnimate : {
        init : function(params_) {
            $(params_.target).on('focus', function() {
                var width = 425;
                if ($('html').hasClass('lt-ie8')) {
                    width = 400;
                }
                $(this).animate({
                    width : width + 'px'
                }, 300);
            }).on('blur', function() {
                $(this).animate({
                    width : '215px'
                }, 300);
            });
        }
    },
    preventCCP : {
        init : function(params_) {
            $(params_.target).bind('cut copy paste', function(e) {
                e.preventDefault();
            });
        }
    },
    sideBarData : {
        init : function(params_) {
            LSCA.globalAjax.doCall({
                url : params_.url,
                selector : params_.selector
            }, function(data) {
                $.each(data.data, function(i, v) {
                    $.each(v[0], function(j, w) {
                        if (typeof w !== 'object') {
                            $(params_.selector).find('ul').append("<li class='mbot10'><a href='javascript:void(0);'>" + w + "</a></li>");
                        } else {
                            $.each(w, function(k, x) {
                                if (typeof x !== 'object') {
                                    $(params_.selector).find('ul').append("<li class='mbot10'><a href='javascript:void(0);'>" + j + "</a></li>");
                                }
                            });
                        }
                    });
                });
            });
        }
    },
    disableCalender : {
        init : function(params_) {
            var checkValue = $(params_.selector).prop('checked')
            if (checkValue) {
                $(params_.target).datepicker('enable')
            } else {
                $(params_.target).datepicker('disable').val("")
            }
            $(params_.selector2).on('click', function() {
                var checkValue = $(params_.selector).prop('checked')
                if (checkValue) {
                    $(params_.target).datepicker('enable')
                } else {
                    $(params_.target).datepicker('disable').val("")
                }
            })
        }
    },
    saveShopingCart : {
        init : function(params_) {
            $(params_.target).on('submit',function(e) {
                                e.preventDefault();
                                var dovalidate = LSCA.GlobalValidate.init({
                                    target : params_.target,
                                    action : 'submit'
                                });
                                if (dovalidate) {
                    LSCA.globalAjax.doCall({
                                                        url : params_.url + $(this).find("#EnterName").val()
                                                    },
                                                    function(response) {
                                                        if (response.data.nameAllreadyExist == "true" && response.data.errorToShow == "true") {
                                                            var msgSave = (response.data.message);
                                                            $("#myModal").modal();
                                                            $("#myModal").find("#saveCartMsg").html(msgSave);
                                                            $("#myModal").find("#savedCartResponse").on('click', function() {
                                                                LSCA.globalAjax.doCall({
                                                                    url : '/store/includes/ajax/ajaxMergeSavedCart.jsp?description=' + $(params_.target).find("#EnterName").val(),
                                                                    target : $(this)
                                                                }, function(data) {
                                                                    if (data.data.errorToShow == "false") {
                                                                        window.location = "/common/myaccount/mySavedCart.jsp";
                                                                    } else if (data.data.errorToShow == "true") {
                                                                        window.location = "/common/checkout/saveShoppingCart.jsp";
                                                                    }
                                                                })
                                                            })
                            $("#myModal").find("#savedCartNoResponse").on('click',function() {
                                                                                $("#myModal").modal('hide');
                                                                                $(params_.target).find("#EnterName").val("").focus();
                                                                                var errmsg = '<div class="alert alert-dismissable alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Please enter a different name for saving cart </div>';
                                                                                $(document).find('div.errorMessages:eq(0)').hide();
                                                                                $(document).find('div.errorMessages:eq(0)').html(errmsg);
                                                                                $(document).find('div.errorMessages:eq(0)').show();
                                                                            })
                                                        } else if (response.data.errorToShow == "false") {
                                                            window.location = "/common/myaccount/mySavedCart.jsp";
                                                        } else if (response.data.errorToShow == "true") {
                                                            window.location = "/common/checkout/saveShoppingCart.jsp";
                                                        }
                                                    });
                                } else {
                                    LSCA.showMsg.init({
                                        key : 'savecartname'
                                    }, function(data) {
                                        LSCA.GlobalValidate.showError('', data)
                                    });

                                }
                            });
        }
    },
    setPlaceHolder : {
        init : function() {
            if ($('html').hasClass('Explorer')) {
                $('input').each(function() {
                    if ($(this).attr('placeholder')) {
                        $(this).val($(this).attr('placeholder'));
                        LSCA.setPlaceHolder.clearonfocus.call(this);
                    }
                });
                LSCA.setPlaceHolder.clearonsubmit.call(this);
            }
        },
        clearonfocus : function() {
            $(this).on('focus', function() {
                if ($(this).val() == $(this).attr('placeholder'))
                    $(this).val('')
            });
            $(this).on('blur', function() {
                if ($(this).val() == '')
                    $(this).val($(this).attr('placeholder'))
            });
        },
        clearonsubmit : function() {
            $(document).find('form').on('submit', function() {
                $('input').each(function() {
                    if ($(this).val() == $(this).attr('placeholder'))
                        $(this).val('');
                });
            })
        }
    },
    billShipHandler : {
        init : function(params_) {
            LSCA.billShipHandler.submithandler(params_);
        },
        submithandler : function(params_) {
            var shiptoflag = false;
            var submitbtn = $(params_.target).find('.panel-body button[type="button"]:not(.close,#submitShipAdd,#submitShipAddpop,#btnShipContinue,#shiptocustomer,#ueuNumberApply,#selectshipaddr,#saveBillAdd)');
            $(submitbtn).on('click', function(e) {
                e.preventDefault();
                var panel = $(this).parents('.panel'), $this = $(this);
                if (!$(submitbtn).hasClass('sbmtOrder')) {
                    LSCA.billShipHandler.radiosubmit();
                    if ($(this).attr('id') == 'btn-continue') {
                        $("#ajaxBillAddress #billAttention").val($("#attenBillingSection #billAttnno").val());
                        $("#ajaxBillAddress #payerPhoneNumber").val($("#attenBillingSection #billPhoneNo").val());
                    }
                    if ($(this).attr('id') == 'shiptocustomer') {
                        formtype = 'form#fetchship';
                        fdata = $(panel).find(formtype).serialize();
                        LSCA.globalAjax.doCall({
                            url : $(panel).find(formtype).attr('action'),
                            data : fdata,
                            context : $(this),
                            target : $(this)
                        }, function(data) {
                            var shiptocontinuemsg = data.data;
                            params_.btn = data.target;
                            if (shiptocontinuemsg.status != 'success') {
                                shiptoflag = false;
                                $(panel).find(".billErrorContainer").html(shiptocontinuemsg.innerHTML).show();
                                if ($("#optionsRadios1").prop('checked')) {
                                    $(".rightblockDivide #shipAddContainer").css("min-height", "130px");
                                    $("#shipAddContainer").html('');
                                }
                                $('#buildRoomNoCNSP').val('');
                                $('#attentionCNSP').val('');
                                $('#phoneNumberCNSP').val('');
                                $('#informationCNSP').val('');
                            } else {
                                shiptoflag = true;
                                $("#shipAddContainer").html(shiptocontinuemsg.innerHTML);
                            }
                        });
                    } else if ($(this).attr('id') == 'ueuNumberApply') {
                        formtype = 'form#ueuFetchShip';
                        fdata = $(panel).find(formtype).serialize();
                        LSCA.globalAjax.doCall({
                            url : $(panel).find(formtype).attr('action'),
                            data : fdata,
                            context : $(this),
                            target : $(this)
                        }, function(data) {
                            var shiptocontinuemsg = data.data;
                            params_.btn = data.target;
                            if (shiptocontinuemsg.status != 'success') {
                                shiptoflag = false;
                                $(panel).find(".billErrorContainer").html(shiptocontinuemsg.innerHTML).show();
                                if (!isEmpty($("#inputUEUNumber").val())) {
                                    $(".rightblockDivide #shipAddContainer").css("min-height", "130px");
                                    $("#shipAddContainer").html('');
                                }
                                /*$('#buildRoomNoCNSP').val('');
                                $('#attentionCNSP').val('');
                                $('#phoneNumberCNSP').val('');
                                $('#informationCNSP').val('');*/
                            } else {
                                shiptoflag = true;
                                $("#shipAddContainer").html(shiptocontinuemsg.innerHTML);
                            }
                        });
                    } else {
                        formtype = ($(panel).find("#optionsRadios1").prop('checked')) ? 'form#dropship' : 'form:visible';
                        fdata = $(panel).find(formtype).serialize();
                        LSCA.globalAjax.doCall({
                            url : $(panel).find(formtype).attr('action'),
                            data : fdata,
                            context : $(this),
                            target : $(this)
                        }, function(data) {
                            var msg = data.data;
                            params_.btn = data.target;
                            if (msg.status != 'success') {
                                $(panel).find(".billErrorContainer").html(msg.innerHTML).show();
                                if ($("#optionsRadios1").prop('checked') && shiptoflag == false) {
                                    $(".rightblockDivide #shipAddContainer").css("min-height", "130px");
                                    $("#shipAddContainer").html('');
                                }
                            } else {
                                if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                                    window.location.href = "/common/checkout/reviewAndPlaceOrder.jsp";
                                } else {
                                    // LMS change
                                    if ($('#lmsOrder').val() == 'true') {
                                        LSCA.billShipHandler.doubleSwitchaccordion(params_);
                                    } else {
                                        LSCA.billShipHandler.switchaccordion(params_);
                                        var applyShippingBorder;
                                        if ($('#shippingLeft').height() > $('#shippingRight').height()) {
                                            applyShippingBorder = $('#shippingLeft').height() - 15;
                                        } else {
                                            applyShippingBorder = $('#shippingRight').height();
                                        }
                                        if (applyShippingBorder > 230) {
                                            $('#shippingRight .borderLeft').css('height', applyShippingBorder + 'px');
                                        }
                                    }
                                }
                            }
                        });
                    }
                }
                $('.billErrorContainer').hide();
            });
            $(document).on('click', '#shiptocustomer', function(e) {
                $('#fetchship #inputShipto').attr('style', '');
                $('#fetchship #inputShipto').removeClass('requiredTextBox');
                $('.shipToEntryFields .mText').hide();
                $('.shipToFields > label').removeClass('requiredLabel');
                $('.shipToEntryFields #errorShipLabel').html('').hide();
                $('.rightaddressDiv label').removeClass('requiredLabel');
                $('.rightaddressDiv .rightMandatoryFields input').removeClass('requiredTextBox');
                $('.rightaddressDiv .rightMandatoryFields span.mText').hide();

                formdata = $('#fetchship').serialize();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#fetchship'
                });

                if (dovalidate) {
                    formtype = 'form#fetchship';
                    LSCA.globalAjax.doCall({
                        url : $('#fetchship').attr('action'),
                        data : formdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var shiptocontinuemsg = data.data;
                        params_.btn = data.target;
                        if (shiptocontinuemsg.status != 'success') {
                            console.log('error');
                            //if (shiptocontinuemsg.innerHTML.indexOf('Please enter valid ship to number.') != -1) {
                                $('#fetchship #inputShipto').attr('style', '');
                                $('#fetchship #inputShipto').addClass('requiredTextBox');
                                $('.shipToEntryFields .mText').hide();
                                $('.shipToFields > label').addClass('requiredLabel');
                                $('.shipToEntryFields #errorShipLabel').html(shiptocontinuemsg.innerHTML).show();
                           // }
                        } else {
                        	$("#custom-change-shipAddress").hide();
                        	$('#shipto-Address').show();
                        	$("#shipAddContainer").html(shiptocontinuemsg.innerHTML);
                            $("#shipto-Address").html(shiptocontinuemsg.innerHTML);
                            
                            formdata = $("#dropship").serialize();
        					LSCA.globalAjax.doCall({
        						url: '/common/checkout/ajaxCheckoutShipping.jsp',
        						data: formdata,
        						context: $(this),
        						target: $(this)
        					}, function(data) {
        						var msg = data.data;
        						if (msg.status == 'success') {
        							console.log(msg.status);
        							 if($(document).find('.checkoutShippingBilling').length > 0) {
       							      stickyPriceDetails();
        							 }
        						}
        					});
                            if( $('form#shipAddDetailJP').length > 0) {
								$('form#shipAddDetailJP #Organization').val(data.data.dropShipToInfo.organization);
								$('form#shipAddDetailJP #Person').val(data.data.dropShipToInfo.attention);
								$('form#shipAddDetailJP #Tel').val(data.data.dropShipToInfo.contactNumber);
							}
							if( $('form#shipAddDetailCN').length > 0) {
								$('form#shipAddDetailCN #buildRoomNoCNSP').val(data.data.dropShipToInfo.buildingRoomNo);
								$('form#shipAddDetailCN #attentionCNSP').val(data.data.dropShipToInfo.attention);
								$('form#shipAddDetailCN #phoneNumberCNSP').val(data.data.dropShipToInfo.contactNumber);
								$('form#shipAddDetailCN #informationCNSP').val('');
							}
							if( $('form#shipAddDetailOthers').length > 0) {
								$('form#shipAddDetailOthers #shipAttnno').val(data.data.dropShipToInfo.attention);
								$('form#shipAddDetailOthers #shipBuildingNo').val(data.data.dropShipToInfo.buildingRoomNo);
								$('form#shipAddDetailOthers #contactNum').val(data.data.dropShipToInfo.contactNumber);
							}
                        }
                    });
                } else {
                    if ($('#fetchship #inputShipto').val() == "") {
                        $('#fetchship #inputShipto').attr('style', '');
                        $('#fetchship #inputShipto').addClass('requiredTextBox');
                        $('.shipToEntryFields .mText').show();
                        $('.shipToFields > label').addClass('requiredLabel');
                        $('.shipToEntryFields #errorShipLabel').html('').hide();
                    }
                }
            });

            // Hide/Show ueuNumber Apply link
            $("#inputUEUNumber").on('input', function() {
                $(this).val($(this).val().replace(/[^\d]/g, ''));
                if ($(this).val()) {
                    $("#ueuNumberApplySpan").show();
                } else {
                    $("#ueuNumberApplySpan").hide();
                    $('#ueuFetchShip #inputUEUNumber').removeClass('requiredTextBox');
                    $('.ueuNumberEntryField .mText').hide();
                }
                $(window).keydown(function(event){
                	if ($("#inputUEUNumber").is(":focus") && (event.keyCode == 13)) {
                      event.preventDefault();
                    }
                });
            });
            
            // new fedEx UPS Apply link logic
            $(function () {
            	if ($("#fedex_num").val()!="") {
            		$("#apply_fedEx").show();
            	}
            if ($("#ups_num").val()!="") {
            	$("#apply_ups").show();
            	}
            });
            $("#fedex_num").on('input', function() {
				$(this).val($(this).val().replace(/[^0-9]/gi,''));
                if ($(this).val()) {
                    $("#apply_fedEx").show();
                    $("#remove_fedEx").hide();
                } else {
                    $("#apply_fedEx").hide();
                    $("#remove_fedEx").hide();
                }
            });
			$("#fedex_num").keypress(function(event){
				var keycode = event.which;
				if (!(keycode >= 48 && keycode <= 57)) {
					$(this).addClass('requiredTextBox')
				}else{
					$(this).removeClass('requiredTextBox')
				}
			});				
            $("#ups_num").on('input', function() {
				$(this).val($(this).val().replace(/[^a-z0-9]/gi,''));	
                if ($(this).val()) {
                    $("#apply_ups").show();
                    $("#remove_ups").hide();
                } else {
                    $("#apply_ups").hide();
                    $("#remove_ups").hide();
                }
            });
			$("#ups_num").keypress(function(event){
				var keycode = event.which;
				 if(!((event.keyCode >= 65) && (event.keyCode <= 90) || (event.keyCode >= 97) && (event.keyCode <= 122) || (event.keyCode >= 48) && (event.keyCode <= 57))){
					$(this).addClass('requiredTextBox')
				}else{
					$(this).removeClass('requiredTextBox')
				}
			});			
            $(document).on('click', '#fedEx_apply', function(e) {
            		$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully applied.');
            		$("#apply_fedEx").hide();
            		$("#apply_ups").hide();
            		$("#remove_ups").hide();
            		$("#remove_fedEx").show();
            		if(document.getElementById('ups_num') != null) {
            			document.getElementById('ups_num').value = "";
            		}
            		$("#fedex_ups_msg").show();
					$("#ups_num,#fedex_num").removeClass('requiredTextBox')
            });
            $(document).on('click', '#ups_apply', function(e) {
            	$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully applied.');
        		$("#apply_ups").hide();
        		$("#apply_fedEx").hide();
        		$("#remove_fedEx").hide();
        		$("#remove_ups").show();
        		if(document.getElementById('fedex_num') != null) {
        			document.getElementById('fedex_num').value = "";
        		}
        		$("#fedex_ups_msg").show();
				$("#ups_num,#fedex_num").removeClass('requiredTextBox')
            });
            $(document).on('click', '#ups_remove', function(e) {
            	$('#fedex_ups_msg .custom-msg-icon').html('UPS account was successfully removed.');
            	document.getElementById('ups_num').value = "";
            	$("#remove_ups").hide();
            	$("#fedex_ups_msg").show();
            });
            $(document).on('click', '#fedEx_remove', function(e) {
            	$('#fedex_ups_msg .custom-msg-icon').html('FedEx account was successfully removed.');
            	document.getElementById('fedex_num').value = "";
            	$("#remove_fedEx").hide();
            	$("#fedex_ups_msg").show();
            });

            $(document).on('click', '#ueuNumberApply', function(e) {
            	$(".UEU-remove-msg").css('display', 'none');
            	$('#UEUAddress').hide();
            	$('#applyUEU').hide();
                $('#ueuFetchShip #inputUEUNumber').attr('style', '');
                $('#inputUEUNumber').removeClass('requiredTextBox');
                $('.ueuNumberEntryField .mText').hide();
                $('.ueuNumberField > label').removeClass('requiredLabel');
                $('.ueuNumberEntryField #errorUEULabel').html('').hide();
                $('.rightaddressDiv label').removeClass('requiredLabel');
                $('.rightaddressDiv .rightMandatoryFields input').removeClass('requiredTextBox');
                $('.rightaddressDiv .rightMandatoryFields span.mText').hide();

                formdata = $('#ueuFetchShip').serialize();
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#ueuFetchShip'
                });

                if (dovalidate) {
                    formtype = 'form#ueuFetchShip';
                    LSCA.globalAjax.doCall({
                        url : $('#ueuFetchShip').attr('action'),
                        data : formdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var shiptocontinuemsg = data.data;
                        params_.btn = data.target;
							var visibleRightForm = 'shipAddDetailOthers';
							if ($('form#shipAddDetailCN').is(':visible')) {
								visibleRightForm = '#shipAddDetailCN';
							}
							if ($('form#shipAddDetailJP').is(':visible')) {
								visibleRightForm = '#shipAddDetailJP';
							}
							if ($('form#shipAddDetailOthers').is(':visible')) {
								visibleRightForm = '#shipAddDetailOthers';
							}
							var shipRightHeight = $('#shippingRight .borderLeft .addressBox').height() + $('#shippingRight .borderLeft '+visibleRightForm).height()+55;
                        if (shiptocontinuemsg.status != 'success') {
                            $('#ueuFetchShip #inputUEUNumber').attr('style', '');
                            $('#inputUEUNumber').addClass('requiredTextBox');
                            $('.ueuNumberEntryField .mText').hide();
                            $('.ueuNumberField > label').addClass('requiredLabel');
                            $('.ueuNumberEntryField #errorUEULabel').html(shiptocontinuemsg.innerHTML).show();
                        } else {
                        	$('#UEUAddress').show();
                            $("#UEUAddress").html(shiptocontinuemsg.innerHTML);
                            $("#UEUAddressBlock").html(shiptocontinuemsg.innerHTML);
							$("#UEUAddressBlock").addClass('UEUBorderTop');
							$('#ueuNumberApplySpan').hide();
							document.getElementById('UEUApplied').value = "true";
							formdata = $("#dropship").serialize();
        					/*LSCA.globalAjax.doCall({
        						url: '/common/checkout/ajaxCheckoutShipping.jsp',
        						data: formdata,
        						context: $(this),
        						target: $(this)
        					}, function(data) {
        						var msg = data.data;
        						if (msg.status == 'success') {
        							console.log(msg.status);
        						}
        					});*/
                        }
						if($("#UEUAddressBlock").html() != ""){
							
							if($('.rightaddressDiv .newTextareablock').length > 0){
								$('.UEUBorderTop').css('margin-top','30px');
								 shipRightHeight = shipRightHeight + 249;
                        }
							else {
								 shipRightHeight = shipRightHeight + 246;	
                        }
							$('#shippingRight .borderLeft').css('height', shipRightHeight + 'px'); 
                        }
                    });
                } else {
                    if ($('#ueuFetchShip #inputUEUNumber').val() == "") {
                        $('#ueuFetchShip #inputUEUNumber').attr('style', '');
                        $('#inputUEUNumber').addClass('requiredTextBox');
                        $('.ueuNumberEntryField .mText').show();
                        $('.ueuNumberField > label').addClass('requiredLabel');
                        $('.ueuNumberEntryField #errorUEULabel').html('').hide();
                    }
                }
            });
            
            $(document).on('click', '#ueuNumberRemove', function(e) {
            	formtype = 'form#ueuFetchShip';
                LSCA.globalAjax.doCall({
                    url : $(formtype).attr('action')
                });
            	$('#UEUAddress').hide();
            	$(".UEU-remove-msg").css('display', 'inline-block');
            	document.getElementById('inputUEUNumber').value = "";
            	document.getElementById('UEUApplied').value = "";
            	
            });
            $(document).on('click', '#shipto-address-remove', function(e) {
            	document.getElementById("optionsRadios1").checked = false;
            	$("#inputShipto").attr("disabled", "disabled");
            	$("#shiptocustomer").css('display', 'none');
            	$('.customDropshipWrap').css('display','none');
            	$("#shipto-remove-msg").css('display','block');
            	$("#disabled-shiptocustomer").css('display', 'inline-block');
            	$('#shipto-Address').hide();
            	$("#shipAddContainer").html(""); 
            	$('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
            	$('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
            	$.ajax({type:"POST", url:"/common/checkout/ajaxFetchDefaultShippingAddress.jsp",dataType:"html"})
    				.done(function(msg){
    					$("#shipAddContainer").html(msg);
						 if( $('form#shipAddDetailJP').length > 0) {
							$('form#shipAddDetailJP #Organization').val('');
							$('form#shipAddDetailJP #Person').val('');
							$('form#shipAddDetailJP #Tel').val('');
						}
						if( $('form#shipAddDetailCN').length > 0) {
							$('form#shipAddDetailCN #buildRoomNoCNSP').val('');
							$('form#shipAddDetailCN #attentionCNSP').val('');
							$('form#shipAddDetailCN #phoneNumberCNSP').val('');
							$('form#shipAddDetailCN #informationCNSP').val('');
						}
						if( $('form#shipAddDetailOthers').length > 0) {
							$('form#shipAddDetailOthers #shipAttnno').val('');
							$('form#shipAddDetailOthers #shipBuildingNo').val('');
							$('form#shipAddDetailOthers #contactNum').val('');
						}
    					 formdata = $("#dropship").serialize();
    					 $('.custom-after-changeshipAddress').show();
    					 $("#shipAddContainer").html(msg);
    						LSCA.globalAjax.doCall({
    							url: '/common/checkout/ajaxCheckoutShipping.jsp',
    							data: formdata,
    							context: $(this),
    							target: $(this)
    						}, function(data) {
    							var msg = data.data;
    							if (msg.status == 'success') {
    								console.log(msg.status);
    								if($(document).find('.checkoutShippingBilling').length > 0) {
         							      stickyPriceDetails();
          							 }
    							}
    						});
    					copyfromHidden();
    				})
            	$("#custom-change-shipAddress").show();
            });
            $(document).on('click', '#submitShipAdd', function(e) {
                $('#addShippingPopup #stateProv').removeAttr('disabled', 'disabled');
                formdata = $('#shipAddressMngForm').serialize();

                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#shipAddressMngForm'
                });

                if (dovalidate) {
                    console.log('if');
                    $this = $(this);
                    LSCA.globalAjax.doCall({
                        url : $('#shipAddressMngForm').attr('action'),
                        data : formdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var msg = data.data;
                        params_.btn = data.target;
                        if (msg.status == 'success') {
                            // LSCA.billShipHandler.switchaccordion(params_);
                            $('form#shipAddDetailCN #attentionCNSP').val($("#addShippingPopup #attentionCNSP").val());
                            $('form#shipAddDetailCN #buildRoomNoCNSP').val($("#addShippingPopup #buildRoomNoCNSP").val());
                            $('form#shipAddDetailCN #phoneNumberCNSP').val($("#addShippingPopup #phoneNumberCNSP").val());
                            $('form#shipAddDetailCN #informationCNSP').val($("#addShippingPopup #informationCNSP").val());
                            $('form#shipAddDetailOthers #shipAttnno').val($("#addShippingPopup #shipAttentionNo").val());
                            $('form#shipAddDetailOthers #shipBuildingNo').val($("#addShippingPopup #shipBuildNo").val());
                            $('form#shipAddDetailOthers #shipAttnno.required').val($("#addShippingPopup #shipAttnno").val());
                            $('form#shipAddDetailOthers #shipBuildingNo.required').val($("#addShippingPopup #shipBuildingNo").val());
                            $('form#shipAddDetailOthers #contactNum.required').val($("#addShippingPopup #contactNum").val());
                            $('form#shipAddDetailJP #Tel').val($("#addShippingPopup #telephone").val());
                            $('form#shipAddDetailJP #Person').val($("#addShippingPopup #person").val());
                            $('form#shipAddDetailJP #Organization').val($("#addShippingPopup #organization").val());
                            $('form#shipAddDetailJP #Tel').val($("#addShippingPopup #contactNum").val());
                            $("#addShippingPopup  button.close").trigger('click');
                            $('#addShippingPopup .formGroup').attr('style', '');
                            $("#shippingverifiedList ul li input").attr('checked', false);
                            var reviewAddressId = 'reviewShipEdit=true';
                            initialgetValue(null, reviewAddressId);
                            if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                                // Do Nothing
                            } else {
                                // LMS change
                                if ($('#lmsOrder').val() == 'true') {
                                    LSCA.billShipHandler.doubleSwitchaccordion(params_);
                                }
                            }
                            $(".custom-after-changeshipAddress").css('display', 'block');
                            $("#fullBillingAddress").css('display', 'none');
                        } else {
                            console.log('error');
                            $('.errorMessages').hide();
                            var shipToZipErrorMsg = fetchErrorMessage(msg, "invalid.postal");
                            if (!isEmpty(shipToZipErrorMsg)) {
                                $('#addShippingPopup #zip').next().next().text($('#errorProperFormat').val());
                                $('#addShippingPopup #zip').next().next().css('display', 'inline-block');
                                $('#addShippingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                                $('#addShippingPopup #zip').addClass('requiredTextBox');
                                $('#addShippingPopup #zip').parent('.formGroup').css('margin-bottom', '10px');
                            } else {
                                $('#addShippingPopup #zip').next().next().text($('#errorRequiredField').val());
                                $('#addShippingPopup #zip').next().next().hide();
                                $('#addShippingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                                $('#addShippingPopup #zip').removeClass('requiredTextBox');
                                $('#addShippingPopup #zip').parent('.formGroup').css('margin-bottom', '15px');
                            }
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').removeClass("requiredTextBox");
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').attr('style', '');
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').next().next().hide();
                            if($('#addShippingPopup #city').parent().next().attr('id') == 'stateDiv'){
                                $('#addShippingPopup input#city').css('width','200px');
                            }
                            else {
                                $('#addShippingPopup input#city').css('width','420px');
                            }
                        }
                    });
                    $('#collapseTwo .billErrorContainer').hide();
                    $('#collapseTwo .billErrorContainer').html('');
                } else {
                    console.log('else');
                    $('.errorMessages').hide();
                    $('#collapseTwo .billErrorContainer').hide();
                    $('#collapseTwo .billErrorContainer').html('');

                    /*if ($('#addShippingPopup #cname').val() == "") {
                        $('#addShippingPopup #cname').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #cname').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #cname').addClass('requiredTextBox');
                        $('#addShippingPopup #cname').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #cname').next().next().hide();
                        $('#addShippingPopup #cname').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #cname').removeClass('requiredTextBox');
                        $('#addShippingPopup #cname').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #attentionCNSP').val() == "") {
                        $('#addShippingPopup #attentionCNSP').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #attentionCNSP').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #attentionCNSP').addClass('requiredTextBox');
                        $('#addShippingPopup #attentionCNSP').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #attentionCNSP').next().next().hide();
                        $('#addShippingPopup #attentionCNSP').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #attentionCNSP').removeClass('requiredTextBox');
                        $('#addShippingPopup #attentionCNSP').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #phoneNumberCNSP').val() == "") {
                        $('#addShippingPopup #phoneNumberCNSP').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #phoneNumberCNSP').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #phoneNumberCNSP').addClass('requiredTextBox');
                        $('#addShippingPopup #phoneNumberCNSP').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #phoneNumberCNSP').next().next().hide();
                        $('#addShippingPopup #phoneNumberCNSP').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #phoneNumberCNSP').removeClass('requiredTextBox');
                        $('#addShippingPopup #phoneNumberCNSP').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #address2').val() == "") {
                        $('#addShippingPopup #address2').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #address2').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #address2').addClass('requiredTextBox');
                        $('#addShippingPopup #address2').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #address2').next().next().hide();
                        $('#addShippingPopup #address2').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #address2').removeClass('requiredTextBox');
                        $('#addShippingPopup #address2').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #city').val() == "") {
                        $('#addShippingPopup #city').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #city').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #city').addClass('requiredTextBox');
                        $('#addShippingPopup #city').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #city').next().next().hide();
                        $('#addShippingPopup #city').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #city').removeClass('requiredTextBox');
                        $('#addShippingPopup #city').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }*/
                    //code change as part of AMS-67
                    if ($("#addShippingPopup #stateDiv option:selected" ).text() == "Select"){
                		$('#addShippingPopup #stateDiv .fieldLabel').addClass('requiredLabel'); 
               		   	$('#addShippingPopup #stateDiv #uniform-stateProv').next().css('display', 'inline-block');                 
              			$('#addShippingPopup #uniform-stateProv').addClass('requiredTextBox');
              			$('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '10px');
                	} else {
                        $('#addShippingPopup #stateDiv .fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #stateDiv #uniform-stateProv').next().hide();
                        $('#addShippingPopup #uniform-stateProv').removeClass('requiredTextBox');
                        $('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                        $('.modal-header .close,#addShippingPopup').click(function(){
                     if ($('#addShippingPopup #uniform-stateProv').hasClass('requiredTextBox')){
                    	 $('#addShippingPopup #uniform-stateProv').removeClass('requiredTextBox');
                     }
                    });  
                     //code changes completed for AMS-67
                    
                    /*if ($('#addShippingPopup #zip').val() == "") {
                        $('#addShippingPopup #zip').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #zip').addClass('requiredTextBox');
                        $('#addShippingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #zip').next().next().hide();
                        $('#addShippingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #zip').removeClass('requiredTextBox');
                        $('#addShippingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #countrypopup').val() == "") {
                        $('#addShippingPopup #countrypopup').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #countrypopup').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #countrypopup').addClass('requiredTextBox');
                        $('#addShippingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #countrypopup').next().next().hide();
                        $('#addShippingPopup #countrypopup').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #countrypopup').removeClass('requiredTextBox');
                        $('#addShippingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #organization').is(':visible')) {
                        if ($('#addShippingPopup #organization').val() == "") {
                            $('#addShippingPopup #organization').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #organization').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #organization').addClass('requiredTextBox');
                            $('#addShippingPopup #organization').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #organization').next().next().hide();
                            $('#addShippingPopup #organization').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #organization').removeClass('requiredTextBox');
                            $('#addShippingPopup #organization').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipAttnno').is(':visible')) {
                        if ($('#addShippingPopup #shipAttnno').val() == "") {
                            $('#addShippingPopup #shipAttnno').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipAttnno').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipAttnno').addClass('requiredTextBox');
                            $('#addShippingPopup #shipAttnno').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipAttnno').next().next().hide();
                            $('#addShippingPopup #shipAttnno').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipAttnno').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipAttnno').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipAttentionNo').is(':visible')) {
                        if ($('#addShippingPopup #shipAttentionNo').val() == "") {
                            $('#addShippingPopup #shipAttentionNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipAttentionNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipAttentionNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipAttentionNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipAttentionNo').next().next().hide();
                            $('#addShippingPopup #shipAttentionNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipAttentionNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipAttentionNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipBuildingNo').is(':visible')) {
                        if ($('#addShippingPopup #shipBuildingNo').val() == "") {
                            $('#addShippingPopup #shipBuildingNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipBuildingNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipBuildingNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildingNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipBuildingNo').next().next().hide();
                            $('#addShippingPopup #shipBuildingNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipBuildingNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildingNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipBuildNo').is(':visible')) {
                        if ($('#addShippingPopup #shipBuildNo').val() == "") {
                            $('#addShippingPopup #shipBuildNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipBuildNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipBuildNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipBuildNo').next().next().hide();
                            $('#addShippingPopup #shipBuildNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipBuildNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #contactNum').is(':visible')) {
                        if ($('#addShippingPopup #contactNum').val() == "") {
                            $('#addShippingPopup #contactNum').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #contactNum').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #contactNum').addClass('requiredTextBox');
                            $('#addShippingPopup #contactNum').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #contactNum').next().next().hide();
                            $('#addShippingPopup #contactNum').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #contactNum').removeClass('requiredTextBox');
                            $('#addShippingPopup #contactNum').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }*/

                }
            });
			var editAddrSubmitObj;
            $(document).on('click', '#submitShipAddpop', function(e) {
                $('#addShippingPopup #stateProv').removeAttr('disabled', 'disabled');
				
                formdata = $('#shipAddressMngForm').serialize();

                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#shipAddressMngForm'
                });

                if (dovalidate) {
                    console.log('if');
                    $this = $(this);
                    LSCA.globalAjax.doCall({
                        url : $('#shipAddressMngForm').attr('action'),
                        data : formdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var msg = data.data;
                        params_.btn = data.target;
                        if (msg.status == 'success') {
                            // LSCA.billShipHandler.switchaccordion(params_);
                            $('form#shipAddDetailCN #attentionCNSP').val($("#addShippingPopup #attentionCNSP").val());
                            $('form#shipAddDetailCN #buildRoomNoCNSP').val($("#addShippingPopup #buildRoomNoCNSP").val());
                            $('form#shipAddDetailCN #phoneNumberCNSP').val($("#addShippingPopup #phoneNumberCNSP").val());
                            $('form#shipAddDetailCN #informationCNSP').val($("#addShippingPopup #informationCNSP").val());
                            $('form#shipAddDetailOthers #shipAttnno').val($("#addShippingPopup #shipAttentionNo").val());
                            $('form#shipAddDetailOthers #shipBuildingNo').val($("#addShippingPopup #shipBuildNo").val());
                            $('form#shipAddDetailOthers #shipAttnno.required').val($("#addShippingPopup #shipAttnno").val());
                            $('form#shipAddDetailOthers #shipBuildingNo.required').val($("#addShippingPopup #shipBuildingNo").val());
                            $('form#shipAddDetailOthers #contactNum.required').val($("#addShippingPopup #contactNum").val());
                            $('form#shipAddDetailJP #Tel').val($("#addShippingPopup #telephone").val());
                            $('form#shipAddDetailJP #Person').val($("#addShippingPopup #personJP").val());
                            $('form#shipAddDetailJP #Organization').val($("#addShippingPopup #organizationJP").val());
                            $('form#shipAddDetailOthers #Organization').val($("#addShippingPopup #organizationJP").val());
                            //$('form#shipAddDetailJP #Tel').val($("#addShippingPopup #contactNum").val());
                            $("#addShippingPopup  button.close").trigger('click');
                            $('#addShippingPopup .formGroup').attr('style', '');
                            $("#shippingverifiedList ul li input").attr('checked', false);
                            var reviewAddressId = 'reviewShipEdit=true';
                            initialgetValuepop(null, reviewAddressId);
                            if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                                // Do Nothing
                            } else {
                                // LMS change
                                if ($('#lmsOrder').val() == 'true') {
                                    LSCA.billShipHandler.doubleSwitchaccordion(params_);
                                }
                            }
                            $(".custom-after-changeshipAddress").css('display', 'block');
                            $("#fullBillingAddress").css('display', 'none');
							if($('#shippingPopupFlag').val() == 'false') {
								stickyPriceDetails(); 
							}							
							if($('#shippingPopupFlag').val() == 'true' && $('#addrType').val() == 'WEB') {
								
								editAddrSubmitObj ={
									cnameSubmitVal:$('#addShippingPopup #cname').val(),
									addr2SubmitVal:$('#addShippingPopup #address2').val(),
									citySubmitVal: $('#addShippingPopup #city').val(),
									stateSubmitVal : $('#addShippingPopup #stateProv').val(),
									zipcodeSubmitVal : $('#addShippingPopup #zip').val()
								}
								console.log("editAddrSubmitObj "+editAddrSubmitObj.cnameSubmitVal+" " +editAddrSubmitObj.addr2SubmitVal+" "+editAddrSubmitObj.citySubmitVal+" "+editAddrSubmitObj.stateSubmitVal+" "+editAddrSubmitObj.zipcodeSubmitVal);
								if(editAddrObj.cnameVal!=editAddrSubmitObj.cnameSubmitVal || editAddrObj.addr2Val!=editAddrSubmitObj.addr2SubmitVal|| editAddrObj.cityVal!=editAddrSubmitObj.citySubmitVal|| editAddrObj.stateVal!=editAddrSubmitObj.stateSubmitVal|| editAddrObj.zipcodeVal!=editAddrSubmitObj.zipcodeSubmitVal){
									stickyPriceDetails(); 
								} 
							}
                        } else {
                            console.log('error');
                            $('.errorMessages').hide();
                            var shipToZipErrorMsg = fetchErrorMessage(msg, "invalid.postal");
                            if (!isEmpty(shipToZipErrorMsg)) {
                                $('#addShippingPopup #zip').next().next().text($('#errorProperFormat').val());
                                $('#addShippingPopup #zip').next().next().css('display', 'inline-block');
                                $('#addShippingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                                $('#addShippingPopup #zip').addClass('requiredTextBox');
                                $('#addShippingPopup #zip').parent('.formGroup').css('margin-bottom', '10px');
                            } else {
                                $('#addShippingPopup #zip').next().next().text($('#errorRequiredField').val());
                                $('#addShippingPopup #zip').next().next().hide();
                                $('#addShippingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                                $('#addShippingPopup #zip').removeClass('requiredTextBox');
                                $('#addShippingPopup #zip').parent('.formGroup').css('margin-bottom', '15px');
                            }
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').removeClass("requiredTextBox");
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').attr('style', '');
                            $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city').next().next().hide();
                            if($('#addShippingPopup #city').parent().next().attr('id') == 'stateDiv'){
                                $('#addShippingPopup input#city').css('width','200px');
                            }
                            else {
                                $('#addShippingPopup input#city').css('width','420px');
                            }
                        }
                    });
                    $('#collapseTwo .billErrorContainer').hide();
                    $('#collapseTwo .billErrorContainer').html('');
                } else {
                    console.log('else');
                    $('.errorMessages').hide();
                    $('#collapseTwo .billErrorContainer').hide();
                    $('#collapseTwo .billErrorContainer').html('');

                    /*if ($('#addShippingPopup #cname').val() == "") {
                        $('#addShippingPopup #cname').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #cname').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #cname').addClass('requiredTextBox');
                        $('#addShippingPopup #cname').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #cname').next().next().hide();
                        $('#addShippingPopup #cname').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #cname').removeClass('requiredTextBox');
                        $('#addShippingPopup #cname').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #attentionCNSP').val() == "") {
                        $('#addShippingPopup #attentionCNSP').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #attentionCNSP').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #attentionCNSP').addClass('requiredTextBox');
                        $('#addShippingPopup #attentionCNSP').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #attentionCNSP').next().next().hide();
                        $('#addShippingPopup #attentionCNSP').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #attentionCNSP').removeClass('requiredTextBox');
                        $('#addShippingPopup #attentionCNSP').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #phoneNumberCNSP').val() == "") {
                        $('#addShippingPopup #phoneNumberCNSP').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #phoneNumberCNSP').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #phoneNumberCNSP').addClass('requiredTextBox');
                        $('#addShippingPopup #phoneNumberCNSP').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #phoneNumberCNSP').next().next().hide();
                        $('#addShippingPopup #phoneNumberCNSP').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #phoneNumberCNSP').removeClass('requiredTextBox');
                        $('#addShippingPopup #phoneNumberCNSP').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #address2').val() == "") {
                        $('#addShippingPopup #address2').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #address2').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #address2').addClass('requiredTextBox');
                        $('#addShippingPopup #address2').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #address2').next().next().hide();
                        $('#addShippingPopup #address2').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #address2').removeClass('requiredTextBox');
                        $('#addShippingPopup #address2').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #city').val() == "") {
                        $('#addShippingPopup #city').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #city').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #city').addClass('requiredTextBox');
                        $('#addShippingPopup #city').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #city').next().next().hide();
                        $('#addShippingPopup #city').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #city').removeClass('requiredTextBox');
                        $('#addShippingPopup #city').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }*/
					
					$('#addShippingPopup input.required').each(function(i) {
						if($(this).val() == '') {
								//console.log('this');
								$(this).addClass('requiredTextBox');
								$(this).prev('.fieldLabel').addClass('requiredLabel');
								$(this).next().next().show();
								$(this).parent('.formGroup').css('margin-bottom', '10px');
								//flagErrFieldVal = false;
							}
							else {
								$(this).removeClass('requiredTextBox');
								$(this).prev('.fieldLabel').removeClass('requiredLabel');
								$(this).next().next().hide();
								$(this).parent('.formGroup').css('margin-bottom', '15px');
								//flagErrFieldVal = true;
							}
					});
					var selectValue = $('#selectValue').val();
					if ($("#addShippingPopup #uniform-stateProv span" ).text() == selectValue){
						$('#addShippingPopup #stateDiv .fieldLabel').addClass('requiredLabel'); 
               		   	$('#addShippingPopup #stateDiv #uniform-stateProv').next().css('display', 'inline-block');                 
              			$('#addShippingPopup #uniform-stateProv').addClass('requiredTextBox');
              			$('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '10px');
					} else {
						$('#addShippingPopup #stateDiv .fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #stateDiv #uniform-stateProv').next().hide();
                        $('#addShippingPopup #uniform-stateProv').removeClass('requiredTextBox');
                        $('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '15px');
					}
                    //code change as part of AMS-67
                    /*if ($("#addShippingPopup #stateDiv option:selected" ).text() == "Select"){
                		$('#addShippingPopup #stateDiv .fieldLabel').addClass('requiredLabel'); 
               		   	$('#addShippingPopup #stateDiv #uniform-stateProv').next().css('display', 'inline-block');                 
              			$('#addShippingPopup #uniform-stateProv').addClass('requiredTextBox');
              			$('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '10px');
                	} else {
                        $('#addShippingPopup #stateDiv .fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #stateDiv #uniform-stateProv').next().hide();
                        $('#addShippingPopup #uniform-stateProv').removeClass('requiredTextBox');
                        $('#addShippingPopup #stateDiv').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }*/
                       /* $('.modal-header .close,#addShippingPopup').click(function(){*/
                        	 $('.modal-header .close').click(function(){
                     if ($('#addShippingPopup #uniform-stateProv').hasClass('requiredTextBox')){
                    	 $('#addShippingPopup #uniform-stateProv').removeClass('requiredTextBox');
                     }
                    });  
                        
                     //code changes completed for AMS-67
                    
                    /*if ($('#addShippingPopup #zip').val() == "") {
                        $('#addShippingPopup #zip').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #zip').addClass('requiredTextBox');
                        $('#addShippingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #zip').next().next().hide();
                        $('#addShippingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #zip').removeClass('requiredTextBox');
                        $('#addShippingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #countrypopup').val() == "") {
                        $('#addShippingPopup #countrypopup').next().next().css('display', 'inline-block');
                        $('#addShippingPopup #countrypopup').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addShippingPopup #countrypopup').addClass('requiredTextBox');
                        $('#addShippingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addShippingPopup #countrypopup').next().next().hide();
                        $('#addShippingPopup #countrypopup').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addShippingPopup #countrypopup').removeClass('requiredTextBox');
                        $('#addShippingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addShippingPopup #organization').is(':visible')) {
                        if ($('#addShippingPopup #organization').val() == "") {
                            $('#addShippingPopup #organization').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #organization').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #organization').addClass('requiredTextBox');
                            $('#addShippingPopup #organization').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #organization').next().next().hide();
                            $('#addShippingPopup #organization').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #organization').removeClass('requiredTextBox');
                            $('#addShippingPopup #organization').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipAttnno').is(':visible')) {
                        if ($('#addShippingPopup #shipAttnno').val() == "") {
                            $('#addShippingPopup #shipAttnno').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipAttnno').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipAttnno').addClass('requiredTextBox');
                            $('#addShippingPopup #shipAttnno').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipAttnno').next().next().hide();
                            $('#addShippingPopup #shipAttnno').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipAttnno').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipAttnno').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipAttentionNo').is(':visible')) {
                        if ($('#addShippingPopup #shipAttentionNo').val() == "") {
                            $('#addShippingPopup #shipAttentionNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipAttentionNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipAttentionNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipAttentionNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipAttentionNo').next().next().hide();
                            $('#addShippingPopup #shipAttentionNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipAttentionNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipAttentionNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipBuildingNo').is(':visible')) {
                        if ($('#addShippingPopup #shipBuildingNo').val() == "") {
                            $('#addShippingPopup #shipBuildingNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipBuildingNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipBuildingNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildingNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipBuildingNo').next().next().hide();
                            $('#addShippingPopup #shipBuildingNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipBuildingNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildingNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #shipBuildNo').is(':visible')) {
                        if ($('#addShippingPopup #shipBuildNo').val() == "") {
                            $('#addShippingPopup #shipBuildNo').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #shipBuildNo').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #shipBuildNo').addClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildNo').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #shipBuildNo').next().next().hide();
                            $('#addShippingPopup #shipBuildNo').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #shipBuildNo').removeClass('requiredTextBox');
                            $('#addShippingPopup #shipBuildNo').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addShippingPopup #contactNum').is(':visible')) {
                        if ($('#addShippingPopup #contactNum').val() == "") {
                            $('#addShippingPopup #contactNum').next().next().css('display', 'inline-block');
                            $('#addShippingPopup #contactNum').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addShippingPopup #contactNum').addClass('requiredTextBox');
                            $('#addShippingPopup #contactNum').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addShippingPopup #contactNum').next().next().hide();
                            $('#addShippingPopup #contactNum').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addShippingPopup #contactNum').removeClass('requiredTextBox');
                            $('#addShippingPopup #contactNum').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }*/

                }
            });
            $(document).on('click', '#custom-edit-pop', function(e) {
            	 $('#addShippingPopup #shipAttentionNo').removeClass('requiredTextBox');
            	 $('#addShippingPopup #shipAttentionNo').attr('style','');
            	 $('#addShippingPopup #shipBuildNo').removeClass('requiredTextBox');
            	 $('#addShippingPopup #shipBuildNo').attr('style','');
            	 $('#addShippingPopup #organization').removeClass('requiredTextBox');
                 $('#addShippingPopup #organization').attr('style','');
                 $('#addShippingPopup #person').removeClass('requiredTextBox');
                 $('#addShippingPopup #person').attr('style','');
            });
			var applyRightHeight = 0;
			var initialHeight = $('#shippingRight .borderLeft').height();
            $(document).find("#btnShipContinue").on('click', function(e) {
                var prtialRdoChkd = $(document).find("#collapseThree #partialRadio").attr("checked");
                if (prtialRdoChkd == "checked") {
                    if ($.cookie("CountryCode") == 'CN') {
                        // Do Nothing
                    } else {
                        $(document).find('#btnAdvancedShippingOptions').click();
                    }
                }

                LSCA.billShipHandler.radiosubmit();
                var defaultRightForm = 'shipAddDetailOthers';
                if ($('form#shipAddDetailCN').is(':visible')) {
                    defaultRightForm = '#shipAddDetailCN';
                }
                if ($('form#shipAddDetailJP').is(':visible')) {
                    defaultRightForm = '#shipAddDetailJP';
                }
                if ($('form#shipAddDetailOthers').is(':visible')) {
                    defaultRightForm = '#shipAddDetailOthers';
                }

                var dovalidate = LSCA.GlobalValidate.init({
                    target : defaultRightForm
                });

                if (dovalidate) {
                    if ($('#fetchship #inputShipto').val() == "" && $("#optionsRadios1").prop('checked')) {
                        $('#fetchship #inputShipto').attr('style', '');
                        $('#fetchship #inputShipto').addClass('requiredTextBox');
                        $('.shipToEntryFields .mText').show();
                        $('.shipToFields > label').addClass('requiredLabel');
                        $('.shipToEntryFields #errorShipLabel').html('').hide();
                    } else {
                        $('#fetchship #inputShipto').attr('style', '');
                        $('#fetchship #inputShipto').removeClass('requiredTextBox');
                        $('.shipToEntryFields .mText').hide();
                        $('.shipToFields > label').removeClass('requiredLabel');
                        $('.shipToEntryFields #errorShipLabel').html('').hide();
                    }
                    if ($('#shipAddContainerJP #Organization').is(':visible')) {
                        if ($('#shipAddContainerJP #Organization').val() != "") {
                            $('#shipAddContainerJP #Organization').attr('style', '');
                            $('#shipAddContainerJP #Organization').removeClass('requiredTextBox');
                            $('#shipAddContainerJP #Organization').next().hide();
                            $('#shipAddContainerJP label[for=Organization]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerJP #Tel').is(':visible')) {
                        if ($('#shipAddContainerJP #Tel').val() != "") {
                            $('#shipAddContainerJP #Tel').attr('style', '');
                            $('#shipAddContainerJP #Tel').removeClass('requiredTextBox');
                            $('#shipAddContainerJP #Tel').next().hide();
                            $('#shipAddContainerJP label[for=Tel]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerExtra #attentionCNSP').is(':visible')) {
                        if ($('#shipAddContainerExtra #attentionCNSP').val() != "") {
                            $('#shipAddContainerExtra #attentionCNSP').attr('style', '');
                            $('#shipAddContainerExtra #attentionCNSP').removeClass('requiredTextBox');
                            $('#shipAddContainerExtra #attentionCNSP').next().hide();
                            $('#shipAddContainerExtra label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerExtra #phoneNumberCNSP').is(':visible')) {
                        if ($('#shipAddContainerExtra #phoneNumberCNSP').val() != "") {
                            $('#shipAddContainerExtra #phoneNumberCNSP').attr('style', '');
                            $('#shipAddContainerExtra #phoneNumberCNSP').removeClass('requiredTextBox');
                            $('#shipAddContainerExtra #phoneNumberCNSP').next().hide();
                            $('#shipAddContainerExtra label[for=phoneNumber]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerOthers #shipAttnno').is(':visible')) {
                        if ($('#shipAddContainerOthers #shipAttnno').val() != "") {
                            $('#shipAddContainerOthers #shipAttnno').attr('style', '');
                            $('#shipAddContainerOthers #shipAttnno').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipAttnno').next().next().hide();
                            $('#shipAddContainerOthers label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                    if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")) {
                        if ($('#shipAddContainerOthers #shipAttnno').val() != "") {
                            $('#shipAddContainerOthers #shipAttnno').attr('style', '');
                            $('#shipAddContainerOthers #shipAttnno').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipAttnno').next().next().hide();
                            $('#shipAddContainerOthers label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                        if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")) {
                            if ($('#shipAddContainerOthers #Organization').val() != "") {
                            	$('#shipAddContainerOthers #Organization').attr('style', '');
                            	$('#shipAddContainerOthers #Organization').removeClass('requiredTextBox');
                                $('#shipAddContainerOthers label[for=Organization]').removeClass('requiredLabel');
                            }
                        }
                    if ($('#shipAddContainerOthers #shipBuildingNo').is(':visible')) {
                        if ($('#shipAddContainerOthers #shipBuildingNo').val() != "") {
                            $('#shipAddContainerOthers #shipBuildingNo').attr('style', '');
                            $('#shipAddContainerOthers #shipBuildingNo').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipBuildingNo').next().next().hide();
                            $('#shipAddContainerOthers label[for=shipBuildingNo]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerOthers #contactNum').is(':visible')) {
                        if ($('#shipAddContainerOthers #contactNum').val() != "") {
                            $('#shipAddContainerOthers #contactNum').attr('style', '');
                            $('#shipAddContainerOthers #contactNum').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #contactNum').next().next().hide();
                            $('#shipAddContainerOthers label[for=contactNum]').removeClass('requiredLabel');
                        }
                    }
                    if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")){
                        if ($('#shipAddContainerOthers #contactNum').val() != "") {
                            $('#shipAddContainerOthers #contactNum').attr('style', '');
                            $('#shipAddContainerOthers #contactNum').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #contactNum').next().next().hide();
                            $('#shipAddContainerOthers label[for=contactNum]').removeClass('requiredLabel');
                        }
                    }

                   // if (!isEmpty($("#inputUEUNumber").val()) || $("#optionsRadios1").prop('checked')) {
                    if ($("#optionsRadios1").prop('checked')) {
                        formtype = 'form#dropship';
                    } else {
                        formtype = 'form#ajaxRightSideAddress';
                        $('#shipto-Address').hide();                        
                    }
                    fdata = $(formtype).serialize();
                    LSCA.globalAjax.doCall({
                        url : $(formtype).attr('action'),
                        data : fdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var msg = data.data;
                        params_.btn = data.target;
                        if (msg.status != 'success') {
                            $('.errorMessages').hide();
                            var shipToErrorMsg = fetchErrorMessage(msg, "invalidShipToNumber");
                            if (!isEmpty(shipToErrorMsg)) {
                                $('#fetchship #inputShipto').attr('style', '');
                                $('#fetchship #inputShipto').addClass('requiredTextBox');
                                $('.shipToEntryFields .mText').hide();
                                $('.shipToFields > label').addClass('requiredLabel');
                                $('.shipToEntryFields #errorShipLabel').html(shipToErrorMsg).show();
                            }
                            var ueuErrorMsg = fetchErrorMessage(msg, "invalidUEUNumber");
                            if (!isEmpty(ueuErrorMsg)) {
                                $('#ueuFetchShip #inputUEUNumber').attr('style', '');
                                $('#inputUEUNumber').addClass('requiredTextBox');
                                $('.ueuNumberEntryField .mText').hide();
								$('.ueuNumberField > label').addClass('requiredLabel');
								$('.ueuNumberEntryField #errorUEULabel').html(ueuErrorMsg).show();
                            }
                        } else {
                            if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                                window.location.href = "/common/checkout/reviewAndPlaceOrder.jsp";
                            } else {
                                // LMS change
                                if ($('#lmsOrder').val() == 'true') {
                                    LSCA.billShipHandler.doubleSwitchaccordion(params_);
                                } else {
                                    LSCA.billShipHandler.switchaccordion(params_);
                                }
                            }
                        }
                    });
                } else {
                    console.log('empty fields');
                    $('.errorMessages').hide();
                    if ($('#shipAddContainerJP #Organization').is(':visible')) {
                        if ($('#shipAddContainerJP #Organization').val() == "") {
                            $('#shipAddContainerJP #Organization').attr('style', '');
                            $('#shipAddContainerJP #Organization').addClass('requiredTextBox');
                            $('#shipAddContainerJP #Organization').next().show();
                            $('#shipAddContainerJP label[for=Organization]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerJP #Organization').attr('style', '');
                            $('#shipAddContainerJP #Organization').removeClass('requiredTextBox');
                            $('#shipAddContainerJP #Organization').next().hide();
                            $('#shipAddContainerJP label[for=Organization]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerJP #Tel').is(':visible') && $('#shipAddContainerJP #Tel').hasClass('required')) {
                        if ($('#shipAddContainerJP #Tel').val() == "") {
                            $('#shipAddContainerJP #Tel').attr('style', '');
                            $('#shipAddContainerJP #Tel').addClass('requiredTextBox');
                            $('#shipAddContainerJP #Tel').next().show();
                            $('#shipAddContainerJP label[for=Tel]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerJP #Tel').attr('style', '');
                            $('#shipAddContainerJP #Tel').removeClass('requiredTextBox');
                            $('#shipAddContainerJP #Tel').next().hide();
                            $('#shipAddContainerJP label[for=Tel]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerExtra #attentionCNSP').is(':visible')) {
                        if ($('#shipAddContainerExtra #attentionCNSP').val() == "") {
                            $('#shipAddContainerExtra #attentionCNSP').attr('style', '');
                            $('#shipAddContainerExtra #attentionCNSP').addClass('requiredTextBox');
                            $('#shipAddContainerExtra #attentionCNSP').next().show();
                            $('#shipAddContainerExtra label[for=attention]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerExtra #attentionCNSP').attr('style', '');
                            $('#shipAddContainerExtra #attentionCNSP').removeClass('requiredTextBox');
                            $('#shipAddContainerExtra #attentionCNSP').next().hide();
                            $('#shipAddContainerExtra label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                    if ($('#shipAddContainerExtra #phoneNumberCNSP').is(':visible')) {
                        if ($('#shipAddContainerExtra #phoneNumberCNSP').val() == "") {
                            $('#shipAddContainerExtra #phoneNumberCNSP').attr('style', '');
                            $('#shipAddContainerExtra #phoneNumberCNSP').addClass('requiredTextBox');
                            $('#shipAddContainerExtra #phoneNumberCNSP').next().show();
                            $('#shipAddContainerExtra label[for=phoneNumber]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerExtra #phoneNumberCNSP').attr('style', '');
                            $('#shipAddContainerExtra #phoneNumberCNSP').removeClass('requiredTextBox');
                            $('#shipAddContainerExtra #phoneNumberCNSP').next().hide();
                            $('#shipAddContainerExtra label[for=phoneNumber]').removeClass('requiredLabel');
                        }
                    }
                    
                    if ($('#shipAddContainerOthers #shipAttnno').is(':visible')) {
                        if ($('#shipAddContainerOthers #shipAttnno').val() == "") {
                            $('#shipAddContainerOthers #shipAttnno').attr('style', '');
                            $('#shipAddContainerOthers #shipAttnno').addClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipAttnno').next().next().show();
                            $('#shipAddContainerOthers label[for=attention]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerOthers #shipAttnno').attr('style', '');
                            $('#shipAddContainerOthers #shipAttnno').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipAttnno').next().next().hide();
                            $('#shipAddContainerOthers label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                    if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")) {
                        if ($('#shipAddContainerOthers #shipAttnno').val() == "") {
                            $('#shipAddContainerOthers #shipAttnno').attr('style', '');
                            $('#shipAddContainerOthers #shipAttnno').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipAttnno').next().next().hide();
                            $('#shipAddContainerOthers label[for=attention]').removeClass('requiredLabel');
                        }
                    }
                        if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")) {
                            if ($('#shipAddContainerOthers #Organization').val() == "") {
                            	$('#shipAddContainerOthers #Organization').attr('style', '');
                            	$('#shipAddContainerOthers #Organization').addClass('requiredTextBox');
                                $('#shipAddContainerOthers label[for=Organization]').addClass('requiredLabel');
                            }
                        }
                    if ($('#shipAddContainerOthers #shipBuildingNo').is(':visible')) {
                        if ($('#shipAddContainerOthers #shipBuildingNo').val() == "") {
                            $('#shipAddContainerOthers #shipBuildingNo').attr('style', '');
                            $('#shipAddContainerOthers #shipBuildingNo').addClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipBuildingNo').next().next().show();
                            $('#shipAddContainerOthers label[for=shipBuildingNo]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerOthers #shipBuildingNo').attr('style', '');
                            $('#shipAddContainerOthers #shipBuildingNo').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #shipBuildingNo').next().next().hide();
                            $('#shipAddContainerOthers label[for=shipBuildingNo]').removeClass('requiredLabel');
                        }
                    }
                   
                    if ($('#shipAddContainerOthers #contactNum').is(':visible')) {
                        if ($('#shipAddContainerOthers #contactNum').val() == "") {
                            $('#shipAddContainerOthers #contactNum').attr('style', '');
                            $('#shipAddContainerOthers #contactNum').addClass('requiredTextBox');
                            $('#shipAddContainerOthers #contactNum').next().next().show();
                            $('#shipAddContainerOthers label[for=contactNum]').addClass('requiredLabel');
                        } else {
                            $('#shipAddContainerOthers #contactNum').attr('style', '');
                            $('#shipAddContainerOthers #contactNum').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #contactNum').next().next().hide();
                            $('#shipAddContainerOthers label[for=contactNum]').removeClass('requiredLabel');
                        }
                    }
                    if (($('#userCountryValue').val() == "JP") && ($('#memberTypeValue').val() == "member")){
                        if ($('#shipAddContainerOthers #contactNum').val() == "") {
                            $('#shipAddContainerOthers #contactNum').attr('style', '');
                            $('#shipAddContainerOthers #contactNum').removeClass('requiredTextBox');
                            $('#shipAddContainerOthers #contactNum').next().next().hide();
                            $('#shipAddContainerOthers label[for=contactNum]').removeClass('requiredLabel');
                        }
                    }

                    if (!isEmpty($("#inputUEUNumber").val())) {
                        formtype = 'form#ueuFetchShip';
                        LSCA.globalAjax.doCall({
                            url : $('#ueuFetchShip').attr('action'),
                            data : $('#ueuFetchShip').serialize(),
                            context : $(this),
                            target : $(this)
                        }, function(data) {
                            var shiptocontinuemsg = data.data;
                            params_.btn = data.target;
                        });
                    } else {
                        if ($('#fetchship #inputShipto').val() == "" && $("#optionsRadios1").prop('checked')) {
                            $('#fetchship #inputShipto').attr('style', '');
                            $('#fetchship #inputShipto').addClass('requiredTextBox');
                            $('.shipToEntryFields .mText').show();
                            $('.shipToFields > label').addClass('requiredLabel');
                            $('.shipToEntryFields #errorShipLabel').html('').hide();
                        } else {
                            $('#fetchship #inputShipto').attr('style', '');
                            $('#fetchship #inputShipto').removeClass('requiredTextBox');
                            $('.shipToEntryFields .mText').hide();
                            $('.shipToFields > label').removeClass('requiredLabel');
                            $('.shipToEntryFields #errorShipLabel').html('').hide();

                            formtype = 'form#fetchship';
                            LSCA.globalAjax.doCall({
                                url : $('#fetchship').attr('action'),
                                data : $('#fetchship').serialize(),
                                context : $(this),
                                target : $(this)
                            }, function(data) {
                                var shiptocontinuemsg = data.data;
                                params_.btn = data.target;
                                if (shiptocontinuemsg.status != 'success') {
                                    console.log('error');
                                    //if (shiptocontinuemsg.innerHTML.indexOf('Please enter valid ship to number.') != -1) {
                                        $('#fetchship #inputShipto').attr('style', '');
                                        $('#fetchship #inputShipto').addClass('requiredTextBox');
                                        $('.shipToEntryFields .mText').hide();
                                        $('.shipToFields > label').addClass('requiredLabel');
                                        $('.shipToEntryFields #errorShipLabel').html(shiptocontinuemsg.innerHTML).show();
                                   // }
                                } else {
                                    $('#fetchship #inputShipto').attr('style', '');
                                    $('#fetchship #inputShipto').removeClass('requiredTextBox');
                                    $('.shipToEntryFields .mText').hide();
                                    $('.shipToFields > label').removeClass('requiredLabel');
                                    $('.shipToEntryFields #errorShipLabel').html('').hide();
                                }
                            });
                        }
                    }
                    
                    }
                    var shipRightHeight = $('#shippingRight .borderLeft').height();
				
					if (applyRightHeight==0) { 
                    if($("#UEUAddressBlock").html() != ""){
							initialHeight = shipRightHeight;
							var shipRightHeight3 = initialHeight + 15 * $('#shippingRight input.requiredTextBox').length;	
						$('#shippingRight .borderLeft').css('height', shipRightHeight3 + 'px');
						applyRightHeight = 1; 
                    }
                }
					 else if (applyRightHeight==1) { 
						if($("#UEUAddressBlock").html() != ""){
							var shipRightHeight2 = initialHeight + 15 * $('#shippingRight input.requiredTextBox').length;	
						$('#shippingRight .borderLeft').css('height', shipRightHeight2 + 'px');
						applyRightHeight = 1; 
                     }
                }
            });
            $(document).on('click', '#editShipAddId', function(e) {
                setTimeout(function() {
                    if (window.innerHeight > $("#addShippingPopup .modal-container").outerHeight(true) + 79) {
                        var parentWindowHeight = window.innerHeight - 60;
                        var overLayHeight = $("#addShippingPopup .modal-container").outerHeight(true) + 79;
                        var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                        if (navigator.userAgent.match(/msie/i)) {
                            calcOverlayTop = calcOverlayTop - 5;
                        }
                        if (navigator.userAgent.match(/chrome/i) || navigator.userAgent.match(/firefox/i)) {
                            calcOverlayTop = calcOverlayTop - 5;
                        }
                        $("#addShippingPopup .modal-content").css("top", calcOverlayTop + 'px');
                    }
                }, 500);
                var verifiedAddressFlag = $(this).attr('class');
                $('#billingForm').css('margin-bottom', '42px');
                $('#shipAddNew').val('false');
                var selectedAddressID = $('#shipAddContainer .addressBox').attr('id');
                $('#addShippingPopup .modal-title').text($('#editAddress').val());
                $('#addShippingPopup #submitShipAdd').text($('#saveAddress').val());
                var shippingstate = $('#shipAddContainer .billingAddressBlock #state').text();
                $('#addShippingPopup #stateProv').val(shippingstate);
                $('#addShippingPopup #uniform-stateProv span').text($('#addShippingPopup #stateProv option[value=' + shippingstate + ']').text());
                $('#addShippingPopup #cname').val($('#shipAddContainer .addressBox#' + selectedAddressID + ' p#companyName').text());
                $('#addShippingPopup #attentionCNSP').val($('#collapseTwo #shipAddContainerExtra #attentionCNSP').val());
                $('#addShippingPopup #buildRoomNoCNSP').val($('#collapseTwo #shipAddContainerExtra #buildRoomNoCNSP').val());
                $('#addShippingPopup #phoneNumberCNSP').val($('#collapseTwo #shipAddContainerExtra #phoneNumberCNSP').val());
                $('#addShippingPopup #organization').val($('#collapseTwo #shipAddContainerJP #Organization').val());
                $('#addShippingPopup #person').val($('#collapseTwo #shipAddContainerJP #Person').val());
                $('#addShippingPopup #telephone').val($('#collapseTwo #shipAddContainerJP #Tel').val());
                $('#addShippingPopup #shipAttentionNo').val($('#collapseTwo #shipAddContainerOthers #shipAttnno').val());
                $('#addShippingPopup #shipBuildNo').val($('#collapseTwo #shipAddContainerOthers #shipBuildingNo').val());
                $('#addShippingPopup #shipAttnno').val($('#collapseTwo #shipAddContainerOthers #shipAttnno').val());
                $('#addShippingPopup #shipBuildingNo').val($('#collapseTwo #shipAddContainerOthers #shipBuildingNo').val());
                $('#addShippingPopup #contactNum').val($('#collapseTwo #shipAddContainerOthers #contactNum').val());
                $('#addShippingPopup #address2').val($('#shipAddContainer .addressBox#' + selectedAddressID + ' p#address1').text().replace(/,\s*$/, ""));
                $('#addShippingPopup #city').val($('#shipAddContainer .addressBox#' + selectedAddressID + ' #city').text().replace(/,\s*$/, ""));
                $('#addShippingPopup #zip').val($('#shipAddContainer .addressBox#' + selectedAddressID + ' #postalCode').text().replace(/,\s*$/, ""));
                $('#addShippingPopup #countrypopupValue').val($('#shipAddContainer .addressBox#' + selectedAddressID + ' p#countryName').text());
                $('#addShippingPopup #informationCNSP').val($('#collapseTwo #shipAddContainerExtra #informationCNSP').val());
                $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip,#addShippingPopup #contactNum,#addShippingPopup #shipBuildingNo,#addShippingPopup #shipAttnno,#addShippingPopup #attentionCNSP,#addShippingPopup #phoneNumberCNSP,#addShippingPopup #person,#addShippingPopup #telephone').removeAttr("readonly");
                $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip,#addShippingPopup #contactNum,#addShippingPopup #shipBuildingNo,#addShippingPopup #shipAttnno,#addShippingPopup #attentionCNSP,#addShippingPopup #phoneNumberCNSP,#addShippingPopup #person,#addShippingPopup #telephone').removeClass("requiredTextBox");
                $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip,#addShippingPopup #contactNum,#addShippingPopup #shipBuildingNo,#addShippingPopup #shipAttnno,#addShippingPopup #attentionCNSP,#addShippingPopup #phoneNumberCNSP,#addShippingPopup #person,#addShippingPopup #telephone').removeClass("DisabledText");
                $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip,#addShippingPopup #contactNum,#addShippingPopup #shipBuildingNo,#addShippingPopup #shipAttnno,#addShippingPopup #attentionCNSP,#addShippingPopup #phoneNumberCNSP,#addShippingPopup #person,#addShippingPopup #telephone').attr('style','');
                if ($('#addShippingPopup input#city').parent().next().attr('id') == 'stateDiv') {
                    $('#addShippingPopup input#city').css('width', '200px');
                    $('#addShippingPopup #stateProv').attr('disabled', 'disabled');
                    $('#addShippingPopup #stateProv,#addShippingPopup div#uniform-stateProv span').addClass('DisabledText');
                } else {
                    $('#addShippingPopup input#city').css('width', '420px');
                }
                $('#addShippingPopup label.fieldLabel').removeClass('requiredLabel');
                $('#addShippingPopup .requiredText').hide();
                if (verifiedAddressFlag == 'verifiedLink') {
                    $('#newAddressCounty').val('AGILENT_VERIFIED');
                    $('#addShippingPopup #stateProv').attr('disabled', 'disabled');
                    $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip').attr("readonly", "true");
                    $('#addShippingPopup #cname,#addShippingPopup #address2,#addShippingPopup #city,#addShippingPopup #zip').addClass("DisabledText");
                }
                if (verifiedAddressFlag == 'nonVerifiedLink') {
                   $('#addShippingPopup #stateProv').removeAttr('disabled', 'disabled');
                   $('#addShippingPopup #stateProv,#addShippingPopup div#uniform-stateProv span').removeClass('DisabledText');
                   $('#addShippingPopup div#uniform-stateProv').removeClass('disabled');
                }
                $('.billErrorContainer').hide();
                $('.billErrorContainer').html('');
            });
            $(document).on('click', '#addBillingPopup  button.close', function(e) {
                $('#addBillingPopup .formGroup').attr('style', '');
            });
            $(document).on('click', '#editBillAddID', function(e) {
                $('#billingForm').css('margin-bottom', '42px');
                setTimeout(function() {
                    if (window.innerHeight > $("#addBillingPopup .modal-container").outerHeight(true) + 79) {
                        var parentWindowHeight = window.innerHeight - 60;
                        var overLayHeight = $("#addBillingPopup .modal-container").outerHeight(true) + 79;
                        var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                        if (navigator.userAgent.match(/msie/i)) {
                            calcOverlayTop = calcOverlayTop - 5;
                        }
                        if (navigator.userAgent.match(/chrome/i) || navigator.userAgent.match(/firefox/i)) {
                            calcOverlayTop = calcOverlayTop - 5;
                        }
                        $("#addBillingPopup .modal-content").css("top", calcOverlayTop + 'px');
                    }
                }, 500);
                $('#billingPopupFlag').val('true');
                $('#billAttentionSection').show();
                var selectedAddressID = $('#billAddContainer .addressBox').attr('id');
                $('#addBillingPopup .modal-title').text($('#BillEditAddress').val());
                $('#addBillingPopup #saveBillAdd').text($('#saveAddress').val());
                var billingstate = $('#billAddContainer .billingAddressBlock #state').text();
                $('#addBillingPopup #stateProv').val(billingstate);
                $('#addBillingPopup #uniform-stateProv span').text($('#addBillingPopup #stateProv option[value=' + billingstate + ']').text());
                $('#addBillingPopup #fname').val($('#proFname').val());
                $('#addBillingPopup #lname').val($('#proLname').val());
                $('#addBillingPopup #cname').val($('#billAddContainer .addressBox#' + selectedAddressID + ' p#companyName').text());
                $('#addBillingPopup #billAttnno').val($('#collapseOne .billing-section #billAttnno').val());
                $('#addBillingPopup #billPhoneNo').val($('#collapseOne .billing-section #billPhoneNo').val());
                $('#addBillingPopup #stAddr').val($('#billAddContainer .addressBox#' + selectedAddressID + ' p#address1').text().replace(/,\s*$/, ""));
                $('#addBillingPopup #city').val($('#billAddContainer .addressBox#' + selectedAddressID + ' #city').text().replace(/,\s*$/, ""));
                $('#addBillingPopup #zip').val($('#billAddContainer .addressBox#' + selectedAddressID + ' #postalCode').text().replace(/,\s*$/, ""));
                $('#addBillingPopup #countrypopupValue').val($('#billAddContainer .addressBox#' + selectedAddressID + ' p#countryName').text());
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #countrypopupValue,#addBillingPopup #fname,#addBillingPopup #lname').attr("readonly", "true");
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').addClass("DisabledText");
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').removeClass("requiredTextBox");
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').attr('style', '');
                if ($('#addBillingPopup #city').parent().next().attr('id') == 'stateDiv') {
                    $('#addBillingPopup input#city').css('width', '200px');
                    $('#addBillingPopup #stateProv').attr('disabled', 'disabled');
                    $('#addBillingPopup #stateProv,#addBillingPopup div#uniform-stateProv span').addClass('DisabledText');
                } else {
                    $('#addBillingPopup input#city').css('width', '420px');
                }
                $('#addBillingPopup label.fieldLabel').removeClass('requiredLabel');
                $('#addBillingPopup .requiredText').hide();
                $('.billErrorContainer').hide();
                $('.billErrorContainer').html('');
                $('.verifyMessage').hide();
            });
            $(document).on('click', '#addNewBillAddID', function(e) {
                $('#billingForm').css('margin-bottom', '38px');
                setTimeout(function(){ 
					var intViewportHeight  = window.innerHeight;
					var intShipToAddtHeight = $("#addBillingPopup .modal-dialog").height();
						if (intShipToAddtHeight >= intViewportHeight ){
							$('#addBillingPopup .modal-dialog').css({'top' : '0'});
							$('#addBillingPopup .modal-dialog').css({'transform' : 'none'});
						}else{
							$('#addBillingPopup .modal-dialog').css({'top' : '50%'});
							$('#addBillingPopup .modal-dialog').css({'transform' : '-50%'});
						}
					},500);
                $('#billingPopupFlag').val('false');
                $('#addBillingPopup .modal-title').text($('#BillNewAddress').val());
                $('#addBillingPopup #saveBillAdd').text($('#shipSubmit').val());
                $('#addBillingPopup #stateDiv').show();
                $('#addBillingPopup #stateProv').removeAttr('disabled', 'disabled');
                $('#addBillingPopup #stateProv,#addBillingPopup div#uniform-stateProv span').removeClass('DisabledText');
                $('#addBillingPopup div#uniform-stateProv').removeClass('disabled');
                $('#addBillingPopup #countrypopupValue').attr("readonly", "true");

                if ($('#webBillingFlag').val() == "true") {
                    $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #countrypopupValue,#addBillingPopup #fname,#addBillingPopup #lname').attr("readonly", "true");
					//AMS-263 Changes
                    $('#formbilling #billAttentionSection').hide();
                } else {
                    $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').removeAttr("readonly");
                    $('#billAttentionSection').show();
                }
                if ($('#webBillingFlag').val() == "false" || $('#webBillingFlag').val() == undefined) {
                    $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').val("");
                }
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').removeClass("requiredTextBox");
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').removeClass("DisabledText");
                $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #zip,#addBillingPopup #fname,#addBillingPopup #lname').attr('style', '');
                if ($('#addBillingPopup #city').parent().next().attr('id') == 'stateDiv') {
                    $('#addBillingPopup input#city').css('width', '200px');
                } else {
                    $('#addBillingPopup input#city').css('width', '420px');
                }
                $('#addBillingPopup label.fieldLabel').removeClass('requiredLabel');
                $('#addBillingPopup .requiredText').hide();
                $('.billErrorContainer').hide();
                $('.billErrorContainer').html('');
                $('.verifyMessage').show();
            });
			$(document).on('click', '.redeemQuoteNew #shipNewAddress', function(e) {
				setTimeout(function(){ 
				var intViewportHeight  = window.innerHeight;
				var intShipToAddtHeight = $("#change-edit-shiping-modal .modal-dialog").height();
					if (intShipToAddtHeight >= intViewportHeight ){
						$('#change-edit-shiping-modal .modal-dialog').css({'top' : '0'});
						$('#change-edit-shiping-modal .modal-dialog').css({'transform' : 'none'});
					}else{
						$('#change-edit-shiping-modal .modal-dialog').css({'top' : '50%'});
						$('#change-edit-shiping-modal .modal-dialog').css({'transform' : '-50%'});
					}
				},500);				
			});
            $(document).on('click', '#billing-continue', function(e) {
            //making code changes as part of AMS-262-unable to clcik continue button in edit billing page
            	if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewBillEdit') == 'true' || LSCA.getQueryParam('reviewBillMethodEdit') == 'true') {
				window.location.href = "/common/checkout/reviewAndPlaceOrder.jsp";
           		} 
                if (($('#nonVerAddSize').val() > 90) && ($('#nonVerAddSize').val() < 100)) {
                    $('#shipaddrFirsterror').css('display', 'block');
                }
                if ($('#nonVerAddSize').val() >= 100) {
                    $('#shipaddrSecerror').css('display', 'block');
                    $('#shipNewAddress').css('pointer-events', 'none');
                }
                formdata = $('#formbilling').serialize();
                LSCA.globalAjax.doCall({
                    url : $('#formbilling').attr('action'),
                    data : formdata,
                    context : $(this),
                    target : $(this)
                }, function(data) {
                    var msg = data.data;
                    params_.btn = data.target;
                    if (msg.status == 'success') {
                        console.log('success');
                        LSCA.billShipHandler.switchaccordion(params_);
                        var applyShippingBorder;
                        if ($('#shippingLeft').height() > $('#shippingRight').height()) {
                            applyShippingBorder = $('#shippingLeft').height() - 15;
                        } else {
                            applyShippingBorder = $('#shippingRight').height();
                        }
                        if (applyShippingBorder > 230) {
                            $('#shippingRight .borderLeft').css('height', applyShippingBorder + 'px');
                        }
                    } else {
                        console.log('error');
                    }
                });
            });
            $(document).on('click', '#saveBillAdd', function(e) {
                var dovalidate = LSCA.GlobalValidate.init({
                    target : '#formbilling'
                });
                LSCA.billShipHandler.radiosubmit();
                $('#collapseOne .billing-section #billAttnno').val($('#addBillingPopup #billAttnno').val());
                $('#collapseOne .billing-section #billPhoneNo').val($('#addBillingPopup #billPhoneNo').val());
                $("#ajaxBillAddress #billAttention").val($("#addBillingPopup #billAttnno").val());
                $("#ajaxBillAddress #payerPhoneNumber").val($("#addBillingPopup #billPhoneNo").val());
				if($(document).find('.checkoutShippingBilling').length > 0) {
                var panel = $(this).parents('.panel'), $this = $(this);
                formtype = ($(document).find("#optionsRadios1").prop('checked')) ? 'form#dropship' : 'form:visible';
                formdata = $(document).find(formtype).serialize();
				}
				else {
					var panel = $(this).parents('.panel'), $this = $(this);
					formtype = ($(panel).find("#optionsRadios1").prop('checked')) ? 'form#dropship' : 'form:visible';
					formdata = $(panel).find(formtype).serialize();
				}
               
                if (dovalidate) {
                    console.log('if');
                    $this = $(this);
					if(jQuery("#isPPSOrder").val()!= "true"){
						formAttrURL=$('#formbilling').attr('action');
					}
					else{
						formAttrURL=$('#formbilling').attr('action');
						if(formAttrURL.indexOf('?') > 0){
							formAttrURL=$('#formbilling').attr('action')+"&addBillingAddrFlag=true";
						}
						else{
							formAttrURL=$('#formbilling').attr('action')+"?addBillingAddrFlag=true";
						}
					}
                    LSCA.globalAjax.doCall({
                        url : formAttrURL,
                        data : formdata,
                        context : $(this),
                        target : $(this)
                    }, function(data) {
                        var msg = data.data;
                        params_.btn = data.target;
                        if (msg.status == 'success') {
                        	$('#invoiceCode1').val("");
                        	$('#invoiceCode2').val("");
                        	$('#invoiceCode3').val("");
                        	$('#invoiceCodeOthers').val("");
                        	$('#eanNumber').val("");
                            $('#collapseOne .billing-section #billAttnno').val($('#addBillingPopup #billAttnno').val());
                            $('#collapseOne .billing-section #billPhoneNo').val($('#addBillingPopup #billPhoneNo').val());
                            $("#addBillingPopup  button.close").trigger('click');
                            $('#addBillingPopup .formGroup').attr('style', '');
                            
                            var reviewAddressId = 'reviewEdit=true';
                            if($(document).find('.checkoutShippingBilling').length > 0) {
								if($('#billingPopupFlag').val() == "false") {
									var selectedBillAddrId = "";
								}	
								else {
									var selectedBillAddrId = $(document).find('#changeBillingIdVal').val();
								}
								
								getAddBillingAddress(null, reviewAddressId, selectedBillAddrId);
								$('.billingAddressFields #billAttnno').val($('#addBillingPopup #billAttnno').val());
								$('.billingAddressFields #billPhoneNo').val($('#addBillingPopup #billPhoneNo').val());
								if($('#billingPopupFlag').val() == "false") {
									$('.billingAddress-wrap .warn-msg-top').show();
								}	
								else {
									$('.billingAddress-wrap .warn-msg-top').hide();
								}
								$("#shippingPopUpList #billingverifiedList ul li input").attr('checked', false);
								jQuery(document).find('#'+$('#changeBillingIdVal').val()+'_val').prop('checked', true);
							}
							else {
								$("#billingverifiedList ul li input").attr('checked', false);
								getValue(null, reviewAddressId);
							}
                            if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                                window.location.href = "/common/checkout/reviewAndPlaceOrder.jsp";
                            } else {
                                // LMS change
                                if ($('#lmsOrder').val() == 'true') {
                                    LSCA.billShipHandler.doubleSwitchaccordion(params_);
                                } else {
                                    LSCA.billShipHandler.switchaccordion(params_);
                                }
                            }
                        } else {
                            console.log('error');
                            if (msg.innerHTML.indexOf('postal code') != -1) {
                                $('#addBillingPopup #zip').next().next().text($('#errorProperFormat').val());
                                $('#addBillingPopup #zip').next().next().css('display', 'inline-block');
                                $('#addBillingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                                $('#addBillingPopup #zip').addClass('requiredTextBox');
                                $('#addBillingPopup #zip').parent('.formGroup').css('margin-bottom', '10px');
                            } else {
                                $('#addBillingPopup #zip').next().next().text($('#errorRequiredField').val());
                                $('#addBillingPopup #zip').next().next().hide();
                                $('#addBillingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                                $('#addBillingPopup #zip').removeClass('requiredTextBox');
                                $('#addBillingPopup #zip').parent('.formGroup').css('margin-bottom', '15px');
                            }
                            $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #fname,#addBillingPopup #lname').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #fname,#addBillingPopup #lname').removeClass("requiredTextBox");
                            $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #fname,#addBillingPopup #lname').attr('style', '');
                            $('#addBillingPopup #cname,#addBillingPopup #stAddr,#addBillingPopup #city,#addBillingPopup #fname,#addBillingPopup #lname').next().next().hide();
                        }
                    });
                    $('.billErrorContainer').hide();
                } else {
                    console.log('else');
                    $('.errorMessages').hide();
                    if ($('#addBillingPopup #fname').is(':visible')) {
                        if ($('#addBillingPopup #fname').val() == "") {
                            $('#addBillingPopup #fname').next().next().css('display', 'inline-block');
                            $('#addBillingPopup #fname').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addBillingPopup #fname').addClass('requiredTextBox');
                            $('#addBillingPopup #fname').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addBillingPopup #fname').next().next().hide();
                            $('#addBillingPopup #fname').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addBillingPopup #fname').removeClass('requiredTextBox');
                            $('#addBillingPopup #fname').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }
                    if ($('#addBillingPopup #lname').is(':visible')) {
                        if ($('#addBillingPopup #lname').val() == "") {
                            $('#addBillingPopup #lname').next().next().css('display', 'inline-block');
                            $('#addBillingPopup #lname').prev('.fieldLabel').addClass('requiredLabel');
                            $('#addBillingPopup #lname').addClass('requiredTextBox');
                            $('#addBillingPopup #lname').parent().parent('.formGroup').css('margin-bottom', '10px');
                        } else {
                            $('#addBillingPopup #lname').next().next().hide();
                            $('#addBillingPopup #lname').prev('.fieldLabel').removeClass('requiredLabel');
                            $('#addBillingPopup #lname').removeClass('requiredTextBox');
                            $('#addBillingPopup #lname').parent().parent('.formGroup').css('margin-bottom', '15px');
                        }
                    }

                    if ($('#addBillingPopup #cname').val() == "") {
                        $('#addBillingPopup #cname').next().next().css('display', 'inline-block');
                        $('#addBillingPopup #cname').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addBillingPopup #cname').addClass('requiredTextBox');
                        $('#addBillingPopup #cname').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addBillingPopup #cname').next().next().hide();
                        $('#addBillingPopup #cname').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addBillingPopup #cname').removeClass('requiredTextBox');
                        $('#addBillingPopup #cname').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addBillingPopup #stAddr').val() == "") {
                        $('#addBillingPopup #stAddr').next().next().css('display', 'inline-block');
                        $('#addBillingPopup #stAddr').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addBillingPopup #stAddr').addClass('requiredTextBox');
                        $('#addBillingPopup #stAddr').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addBillingPopup #stAddr').next().next().hide();
                        $('#addBillingPopup #stAddr').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addBillingPopup #stAddr').removeClass('requiredTextBox');
                        $('#addBillingPopup #stAddr').parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addBillingPopup #city').val() == "") {
                        $('#addBillingPopup #city').next().next().css('display', 'inline-block');
                        $('#addBillingPopup #city').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addBillingPopup #city').addClass('requiredTextBox');
                        $('#addBillingPopup #city').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addBillingPopup #city').next().next().hide();
                        $('#addBillingPopup #city').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addBillingPopup #city').removeClass('requiredTextBox');
                        $('#addBillingPopup #city').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addBillingPopup #zip').val() == "") {
                        $('#addBillingPopup #zip').next().next().css('display', 'inline-block');
                        $('#addBillingPopup #zip').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addBillingPopup #zip').addClass('requiredTextBox');
                        $('#addBillingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addBillingPopup #zip').next().next().hide();
                        $('#addBillingPopup #zip').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addBillingPopup #zip').removeClass('requiredTextBox');
                        $('#addBillingPopup #zip').parent().parent('.formGroup').css('margin-bottom', '15px');
                    }
                    if ($('#addBillingPopup #countrypopup').val() == "") {
                        $('#addBillingPopup #countrypopup').next().next().css('display', 'inline-block');
                        $('#addBillingPopup #countrypopup').prev('.fieldLabel').addClass('requiredLabel');
                        $('#addBillingPopup #countrypopup').addClass('requiredTextBox');
                        $('#addBillingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '10px');
                    } else {
                        $('#addBillingPopup #countrypopup').next().next().hide();
                        $('#addBillingPopup #countrypopup').prev('.fieldLabel').removeClass('requiredLabel');
                        $('#addBillingPopup #countrypopup').removeClass('requiredTextBox');
                        $('#addBillingPopup #countrypopup').parent('.formGroup').css('margin-bottom', '15px');
                    }
                }
            });
            /* Change for AP-1851 */
            $('.panel').on('click', '#saveShipAdd,#saveShipAddEdit', function(e) {
                var panel = $(this).parents('.panel'), $this = $(this);
                LSCA.billShipHandler.radiosubmit();
                formtype = ($(panel).find("#optionsRadios1").prop('checked')) ? 'form#dropship' : 'form:visible';
                fdata = $(panel).find(formtype).serialize();
                LSCA.globalAjax.doCall({
                    url : $(panel).find(formtype).attr('action'),
                    data : fdata,
                    context : $(this),
                    target : $(this)
                }, function(data) {
                    var msg = data.data;
                    params_.btn = data.target;
                    if (msg.status != 'success') {
                        $(panel).find(".billErrorContainer").html(msg.innerHTML).show();
                    } else {
                        if (LSCA.getQueryParam('reviewEdit') == 'true' || LSCA.getQueryParam('reviewShipEdit') == 'true' || LSCA.getQueryParam('reviewShipMethodEdit') == 'true') {
                            window.location.href = "/common/checkout/reviewAndPlaceOrder.jsp";
                        } else {
                            if ($('#lmsOrder').val() == 'true') {
                                LSCA.billShipHandler.doubleSwitchaccordion(params_);
                            } else {
                                LSCA.billShipHandler.switchaccordion(params_);
                            }
                        }
                    }
                });
                $('.billErrorContainer').hide();
            });
        },
        switchaccordion : function(params_) {
            var panel = $(params_.btn).parents('.panel'), npIndex = $(params_.target).find(panel).index() + 1;
            $(panel).find('.panel-heading').addClass('success');
            $(panel).find('.panel-collapse').collapse('toggle');
            $(params_.target).find('.panel:eq(' + String(npIndex) + ') .panel-heading').removeClass('disabled');
            $(params_.target).find('.panel:eq(' + String(npIndex) + ') .panel-title').removeClass('disable');
            $(params_.target).find('.panel:eq(' + String(npIndex) + ') .panel-collapse').collapse('toggle');
        },
        switchBillAccordion : function(params_) {
            $(document).find('.billHeading').addClass('success');
            $(document).find('.bill-collapse').collapse('toggle');
            $(params_.target).find('.panel:eq(' + String(1) + ') .panel-heading').removeClass('disabled');
            $(params_.target).find('.panel:eq(' + String(1) + ') .panel-title').removeClass('disable');
            $(params_.target).find('.panel:eq(' + String(1) + ') .panel-collapse').collapse('toggle');
        },
        doubleSwitchaccordion : function(params_) {
            var panel = $(params_.btn).parents('.panel'), npIndex = $(params_.target).find(panel).index() + 1;
            $(panel).find('.panel-heading').addClass('success');
            $(panel).find('.panel-collapse').collapse('toggle');
            $(params_.target).find('.panel:eq(' + String(3) + ') .panel-heading').removeClass('disabled');
            $(params_.target).find('.panel:eq(' + String(3) + ') .panel-title').removeClass('disable');
            $(params_.target).find('.panel:eq(' + String(3) + ') .panel-collapse').collapse('toggle');
        },
        radiosubmit : function() {
        	if ($("#optionsRadios1").prop('checked')) {
                $("#dropShipmentCheck").val($("#optionsRadios1").val());
                $("#shipToNumber").val($("#inputShipto").val());
                $("#shiptocustomer").show();
                $("#disabled-shiptocustomer").hide();
                $("#inputShipto").removeAttr("disabled", "disabled");
                $("#dropship #ueuNumberBean").val($("#inputUEUNumber").val());
                $("#dropship #dropShipOrganization").val($("#shipAddContainerJP #Organization").val());
                $("#dropship #dropShipPerson").val($("#shipAddContainerJP #Person").val());
                $("#dropship #dropShipTel").val($("#shipAddContainerJP #Tel").val());
                $("#payerPhoneNumber").val($("#billPhoneNo").val());
                $("#contactNumber").val($("#contactNum").val());
                $("#shipBuildingNum").val($("#shipBuildingNo").val());
                $("#dropship #shipAttentionCN").val($("#shipAddContainerExtra #attentionCNSP").val());
                $("#dropship #shipBuildRoomNoCN").val($("#shipAddContainerExtra #buildRoomNoCNSP").val());
                $("#dropship #shipPhoneNumberCN").val($("#shipAddContainerExtra #phoneNumberCNSP").val());
                $("#dropship #shipInformationCN").val($("#shipAddContainerExtra #informationCNSP").val());
				$("#dropship #shipAttention").val($("#shipAddContainerOthers #shipAttnno").val());
				$("#dropship #contactNumber").val($("#shipAddContainerOthers #contactNum").val());
				$("#dropship #shipBuildingNum").val($("#shipAddContainerOthers #shipBuildingNo").val());
            } else {
                $("#ajaxRightSideAddress #shipOrganization").val($("#shipAddContainerJP #Organization").val());
                $("#ajaxRightSideAddress #shipPerson").val($("#shipAddContainerJP #Person").val());
                $("#ajaxRightSideAddress #shipTel").val($("#shipAddContainerJP #Tel").val());
                $("#ajaxRightSideAddress #shipAttention").val($("#shipAddContainerOthers #shipAttnno").val());
                $("#ajaxRightSideAddress #organization").val($("#shipAddContainerOthers #organization").val());
                $("#billAttention").val($("#billAttnno").val());
                $("#payerPhoneNumber").val($("#billPhoneNo").val());
                $("#ajaxRightSideAddress #contactNumber").val($("#shipAddContainerOthers #contactNum").val());
                $("#ajaxRightSideAddress #shipBuildingNum").val($("#shipAddContainerOthers #shipBuildingNo").val());
                $("#shiptocustomer").hide();
                $("#disabled-shiptocustomer").css('display', 'inline-block');
                $("#inputShipto").attr("disabled", "disabled");
                $("#ajaxRightSideAddress #shipAttentionCN").val($("#shipAddContainerExtra #attentionCNSP").val());
                $("#ajaxRightSideAddress #shipBuildRoomNoCN").val($("#shipAddContainerExtra #buildRoomNoCNSP").val());
                $("#ajaxRightSideAddress #shipPhoneNumberCN").val($("#shipAddContainerExtra #phoneNumberCNSP").val());
                $("#ajaxRightSideAddress #shipInformationCN").val($("#shipAddContainerExtra #informationCNSP").val());
                $("#ajaxRightSideAddress #ueuNumberBean").val($("#inputUEUNumber").val());
            }
        }
    },
    createLeftMenu : {
        init : function(params_) {
            if ($('#mainContainer').find('div.sidebar').length > 0) {
                if (!$('.sidebar').hasClass('categories')) {
                    if ($("#mainContainer").hasClass(params_.pageId)) {
                        lableObject['navAction'] = 'push';
                    } else {
                        lableObject['navAction'] = 'jump';
                    }
                    LSCA.createLeftMenu.fetchcatlist();
                } else {
                    $("#browseCategory").find('h2').on('click', function(e) {
                        lableObject['navAction'] = 'jump';
                        e.preventDefault();
                        LSCA.createLeftMenu.fetchcatlist();
                        $("#browseCategory").find("div.sidebar").removeClass("categories");
                        $(this).off('click');
                    });
                }
            }
        },
        fetchcatlist : function() {
            LSCA.imageLoader.init({
                target : 'ul#categories'
            });
            LSCA.globalAjax.doCall({
                url : '/store/browseProductJSON.jsp',
                target : this
            }, LSCA.createLeftMenu.createui);
        },
        createui : function(data) {
            var catui = '', arow = '', data = data.data;
            $.each(data, function(i, v) {
                catui += '<li>';
                var arow = (LSCA.countObjArr(v) > 1) ? '<span></span>' : '';
                $.each(v, function(i, v) {
                    if (i == 'title')
                        catui += '<a href="#">' + arow + '' + v + '</a>';
                    if (i == 'child') {
                        catui += '<div class="dropCols">';
                        var tcount = Math.ceil(LSCA.countObjArr(v) / 2), catcount = 0;
                        catui += '<div class="pull-left colGrid">';
                        $.each(v, function(i, v) {
                            $.each(v, function(i, v) {
                                if (i == 'title')
                                    catui += '<h3>' + v + '</h3>';
                                if (i == 'child') {
                                    catui += '<ul>';
                                    $.each(v, function(i, v) {
                                        catui += '<li><a href="' + v['url'] + '?navAction=' + lableObject['navAction'] + '&navCount=' + lableObject['navCount'] + '">' + v['title'] + '</a></li>';
                                    });
                                    catui += '</ul>';
                                }
                            });
                            catcount++;
                            if (catcount === tcount) {
                                catui += '</div><div class="pull-left colGrid">';
                                catcount = 0
                            }
                        });
                        catui += '</div></div>'
                    }
                });
                catui += '</li>';
            });
            $('ul#categories').html(catui);
            $(".sidebar").find("ul#categories > li > a").on('click', function(e) {
                e.preventDefault()
            });
            $('ul#categories').find('li').hover(function() {
                $this = $(this);
                setTimeout(function() {
                    LSCA.createLeftMenu.setposition.call($this)
                }, 100);
            }, function() {
                $(this).find('div.dropCols').removeAttr('style');
                $(this).find('span').hide();
                $('.sidebar').find("ul#categories > li").removeClass('active');
            });
        },
        setposition : function() {
            if (!$(this).hasClass('active')) {
                $(".sidebar").find("ul#categories > li").removeClass("active");
                $(this).addClass('active');
                if ($(this).find('div.dropCols').length > 0) {
                    $(document).find('input').blur();
                    var menuH = $(this).find('div.dropCols').height(), headerH = $('div.container').position().top, pointPos = 0, scrollPos = $(window).scrollTop(), posTop = 0;
                    var dispH = (scrollPos >= headerH) ? $(window).height() : $(window).height() - headerH;
                    pointPos = $(this).position().top - headerH;
                    menuH = (menuH > dispH) ? dispH - 20 : menuH + 10;
                    posTop = (scrollPos / 2) + (headerH);
                    if (scrollPos >= headerH) {
                        if (scrollPos >= $(this).position().top - 20) {
                            posTop = $(this).position().top - 20;
                        } else if (menuH < dispH / 2) {
                            if ($(this).position().top - scrollPos < menuH) {
                                posTop = $(this).position().top - 20;
                            } else {
                                posTop = ($(this).position().top - menuH) + 40;
                            }
                        } else if ($(this).position().top - scrollPos < menuH) {
                            posTop = scrollPos + 10;
                        } else if ($(this).position().top - scrollPos >= menuH) {
                            posTop = menuH;
                        }
                    } else {
                        if (menuH >= dispH - pointPos && menuH <= (dispH - (dispH - pointPos))) {
                            posTop = ($(this).position().top - menuH) + 40;
                        } else if ((menuH >= (dispH - (dispH - pointPos)) && menuH < dispH - pointPos) || (menuH <= (dispH - (dispH - pointPos)) && menuH < dispH - pointPos)) {
                            posTop = $(this).position().top - 20;
                        }
                    }
                    var leftPos = $(this).position().left + $(this).width();
                    $(this).find('div.dropCols').css({
                        left : leftPos + 12,
                        height : menuH,
                        top : posTop
                    });
                    $(this).find('div.dropCols').css({
                        display : 'block'
                    });
                }
                $(this).find('a > span').css({
                    left : leftPos,
                    top : $(this).position().top,
                    display : 'block'
                })
            }
            $('html').on('click touchstart', function() {
                $("ul#categories").find('span').hide();
                $("ul#categories").find('div.dropCols').removeAttr('style');
                $('.sidebar').find("ul#categories > li").removeClass('active');
            });
            $("ul#categories").on('touchstart', function(e) {
                e.stopPropagation()
            });
        }
    },
    disablePageBack : {
        init : function() {
            var history_api = typeof history.pushState !== 'undefined'
            // The previous page asks that it not be returned to
            if (location.hash == '#no-back') {
                // Push "#no-back" onto the history, making it the most recent "page"
                if (history_api)
                    history.pushState(null, '', '#stay')
                else
                    location.hash = '#stay'
                // When the back button is pressed, it will harmlessly change the url
                // hash from "#stay" to "#no-back", which triggers this function
                window.onhashchange = function() {
                    // User tried to go back; warn user, rinse and repeat
                    if (location.hash == '#no-back') {
                        if (history_api)
                            history.pushState(null, '', '#stay')
                        else
                            location.hash = '#stay'
                    }
                }
            }
        }
    },
    restricttextareamaxlength : {
        init : function(params_) {
            $('textarea.maxlength').on('keyup', function(e) {
                var maxlength = params_.maxlength, tval = $(this).val();
                tval = tval.substr(0, maxlength);
                $(this).val(tval);
            });
        }
    },
    modalIFrameLoad : {
        hide : function(params_) {
            if ($('#mainContainer').hasClass(params_.pageid)) {
                $('#myModal').on('show.bs.modal', function(e) {
                    $('#myModal').find('iframe').hide();
                });
            }
        }
    },
    doButtonRound : function() {
        if (window.PIE) {
            setTimeout(function() {
                $('.container .btn-blue,.container .btn-stnd-medium,.container .btn-stnd-small,.container .link-stnd-default,.container .btn-grey,.container .myAcDrdwn,.container .placeOrderBox,.container .addressBox,.container .alert,.container .checkStatusBox,.container .orderBox h5,.container .orderBox').each(function() {
                                    PIE.attach(this)
                                })
                    }, 200)
        }
    },
    setGlobalFlyout : function() {
        $(".dropMenu").each(function() {
            width = 0;
            $(".col_1", this).each(function() {
                width = width + $(this).width()
            });
            $(this).css({
                'width' : width + 72
            });
            if ($('html').hasClass('Explorer8')) {
                $(this).css({
                    'width' : width + 82
                })
            }
            if ($('html').hasClass('Explorer7')) {
                $(this).css({
                    'width' : width + 35
                });
            }
        });
        $(".dropMenu").parent().on('mouseover', function() {
            $(document).find('input').blur();
            $("ul#categories").find('div.dropCols').removeAttr('style');
            $("ul#categories").find('span').hide();
        });
    },
    iPadDropFix : function() {
        // For ipad dropdown
        $('.dropdown-toggle').click(function(e) {
            // APP-12861
            if (navigator.userAgent.match(/iPad/i) != null) {
                e.preventDefault();
            }
            setTimeout($.proxy(function() {
                if ('ontouchstart' in document.documentElement) {
                    $(this).siblings('.dropdown-backdrop').off().remove();
                }
            }, this), 0);
        });
    },
    vatExamtModal : function() {
        // vatExamtModal open
        $("#vatExempt").on('click', function() {
            var checkVal = $(this).prop("checked");
            if (checkVal) {
                $("#vatExamtModal").modal();
            }
        });
    },
    advShip : {
        init : function(params_) {
            /* added for calender on future date AP-905 -Start */
            $(document).find('.calenderAdvshp').each(function(i) {
                var pId = $(this).attr('partialItemId');
                $('.date_' + pId).datepicker({
                    showOn : "button",
                    buttonImage : "../images/icon-calender.png",
                    buttonImageOnly : true,
                    minDate : 2,
                    maxDate : '+12M',
                    dateFormat : 'yy-mm-dd',
                    pickerClass : '.date_' + pId
                }).attr('readonly', true);
            });
            /* End of change */
            if ($(document).find('div').hasClass(params_.pageId)) {
                $('select').css("width", "100px").uniform();
                $(params_.target).one('click', function() {
                    $(params_.target).parent().removeClass("mbot10").addClass("background");
                    btnHTML = $("#collapseThree").find(".btnSpace").html();
                    $("#collapseThree").find(".btnSpace").hide();
                    $(params_.selector).removeClass("hide").append("<div class='btnSpace mbot10 mLeft20'>" + btnHTML + "</div></div>");
                    if ($("#collapseThree #DeliveryDate").is(":checked")) {
                        $("#collapseThree #standardShipping").click().attr("checked", "checked");
                    }
                    $("#collapseThree #DeliveryDate").attr("disabled", "disabled").removeAttr("checked");
                    $("#collapseThree #consolidateRadio").removeAttr("checked").attr("disabled", "disabled");
                    $("#collapseThree #partialRadio").click().attr("checked", "checked");
                    $(params_.selector).show();
                    advShipData('', params_);
                });
                $(params_.advQty).on('keyup', function() {
                    // for stopping multiple ajax fire
                    $("a.advShip").unbind("click");
                    var maxValue = $(this).attr('maxqty');
                    var val = $(this).val();
                    if ($.isNumeric(val) && val.indexOf('.') === -1 && val != '0') {
                        if (parseInt(val) > parseInt(maxValue)) {
                            LSCA.GlobalValidate.showErrorScroll('', "Quantity entered cannot be greater than maximum quantity or stock quantity", '');
                            $(this).val('');
                        } else {
                            LSCA.GlobalValidate.hideError('');
                        }
                    } else {
                        $(this).val('');
                    }
                });
                $(params_.chngShp).on('click', function() {
                    var cId = $(this).attr('commerceid');
                    var parItem = $(this).attr('partialItemId');
                    var qty = $('.pqty_' + parItem).val();
                    var maxQtyTomv = $('.pqty_' + parItem).attr('maxQtyTomv');
                    var currQty = $('#prmQty_' + parItem).text();
                    var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toImmediateShip" + "&currQty=" + currQty + "&parItem=" + parItem;
                    if (parseInt(maxQtyTomv) < parseInt(qty)) {
                        LSCA.GlobalValidate.showErrorScroll('', "Quantity entered cannot be greater than in stock quantity", '');
                        $('.pqty_' + parItem).val('');
                        qty = 0;
                    } else {
                        LSCA.GlobalValidate.hideError('');
                    }
                    $(params_.target).parent().hide();
                    if (qty > 0) {
                        advShipData(queryString, params_);
                    } else {
                        LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
                    }
                });
                $(params_.adShp).on('click', function() {
                    var cId = $(this).attr('commerceid');
                    var parItem = $(this).attr('partialItemId');
                    var qty = $('.imqty_' + parItem).val();
                    var currQty = $('#imdCurqty_' + parItem).text();
                    var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toPrimaryShip" + "&currQty=" + currQty + "&parItem=" + parItem;
                    $(params_.target).parent().hide();
                    if (qty > 0) {
                        advShipData(queryString, params_);
                    } else {
                        LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
                    }
                });
                $(params_.splitItemImd).on('click', function() {
                    var cId = $(this).attr('commerceid');
                    var parItem = $(this).attr('partialItemId');
                    var qty = $('.imqty_' + parItem).val();
                    var currQty = $('#imdCurqty_' + parItem).text();
                    var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toImmediateShip" + "&splitItem=yes" + "&currQty=" + currQty + "&parItem=" + parItem;
                    $(params_.target).parent().hide();
                    if (qty > 0) {
                        advShipData(queryString, params_);
                    } else {
                        LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
                    }
                });
                $(params_.splitItemPrmy).on('click', function() {
                    var cId = $(this).attr('commerceid');
                    var parItem = $(this).attr('partialItemId');
                    var qty = $('.pqty_' + parItem).val();
                    var currQty = $('#prmQty_' + parItem).text();
                    var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toPrimaryShip" + "&splitItem=yes" + "&currQty=" + currQty + "&parItem=" + parItem;
                    $(params_.target).parent().hide();
                    if (qty > 0) {
                        $(this).off();
                        advShipData(queryString, params_);
                    } else {
                        LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
                    }
                });
                $(params_.delDate).on('click', function() {
                    var cId = $(this).attr('commerceid');
                    var parItem = $(this).attr('partialItemId');
                    var date = $('.date_' + parItem).val();
                    var queryString = "cItemRefId=" + cId + "&parItem=" + parItem + "&delDate=" + date + "&updateDate=yes";
                    if (date != null && date != "") {
                        advShipData(queryString, params_);
                    } else {
                        LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Date", '');
                    }
                });
            }
        }
    },
    /* APP-4409 */

    invInfo : {
        init : function(params_) {
            $(params_.target).one('click', function() {
               //invInfoData(params_);
            });
        }
    },
    invCRMInfo : {
        init : function(params_) {
            $(params_.target).one('click', function() {
                invCRMInfoData(params_);
            });
        }
    },
    toggleCheckbox : {
        init : function(params_) {
            if ($(document).find('div').hasClass(params_.pageId)) {
                $(params_.target).find("label.fontNormal").on("click", function() {
                    var clickId = $(this).find("div.checker").attr("id");
                    switch (clickId) {
                        case "uniform-UpsCheck": {
                            if ($(params_.target).find("#uniform-fedExCheck span").hasClass("checked")) {
                                $(params_.target).find("#uniform-fedExCheck span").removeClass("checked");
                                $(params_.target).find("#uniform-fedExCheck input[type='checkbox']").removeAttr("checked");
                            }
                            break;
                        }
                        case "uniform-fedExCheck": {
                            if ($(params_.target).find("#uniform-UpsCheck span").hasClass("checked")) {
                                $(params_.target).find("#uniform-UpsCheck span").removeClass("checked");
                                $(params_.target).find("#uniform-UpsCheck input[type='checkbox']").removeAttr("checked");
                            }
                            break;
                        }
                    }
                });
            }
        }
    },
    toggleCheckboxNew : {
        init : function(params_) {
            if ($(document).find('div').hasClass(params_.pageId)) {
                $(params_.target).find("label input").on("click", function() {
                    var clickId = $(this).parent().attr("id");
                    switch (clickId) {
                        case "uniform-UpsCheck": {
                                $(params_.target).find("#uniform-fedExCheck input").removeClass("checked");
                                $(params_.target).find("#uniform-fedExCheck input[type='checkbox']").removeAttr("checked"); 
                            break;
                        }
                        case "uniform-fedExCheck": {
                                $(params_.target).find("#uniform-UpsCheck input").removeClass("checked");
                                $(params_.target).find("#uniform-UpsCheck input[type='checkbox']").removeAttr("checked");
                            break;
                        }
                    }
                });
            }
        }
    },
    reqQuoteDet : {
        init : function(params_) {
            if ($(document).find("form").hasClass(params_.pageId)) {
                $(params_.selector).on("click", function() {
                    if ($(this).val() == params_.cmpVal) {
                        $(this).parents(".form-group").next("div").removeClass("hide");
                    } else {
                        $(this).parents(".form-group").next("div").addClass("hide");
                    }
                });
            }
        }
    },
    triggerSSOEvent : {
        init : function(params_) {
            LSCA.triggerSSOEvent.onClickSSOLink(params_);
            $(params_.divTarget).append('<div id="sso" style="display:none"><div>');
        },
        onClickSSOLink : function(params_) {
            $(params_.target).on('click', function(e) {
                e.preventDefault();
                $.ajax({
                    type : "POST",
                    url : $(params_.target).attr('href').replace('http:', ''),
                    dataType : "html",
                    beforeSend : function() {
                        $(params_.loaderClass).prepend('<div class="fadeMe"><img alt="Loading..." src="/store/images/loading.gif"> </div>');
                    },
                    success : function(data) {
                        $('div#sso').html(data);
                        var data = $('form#ssoform').serialize();
                        console.log('first form response:::' + data);
                        var action = $('form#ssoform').attr('action').replace('http:', '');
                        $.ajax({
                            url : action,
                            type : 'POST',
                            data : data,
                            dataType : "html",
                            success : function(res) {
                                var text = res.responseText;
                                console.log('Second form :::' + res);
                                console.log('Second form response:::' + text);
                                $('div#sso').html(res);
                                $('form#samlform').submit()
                            }
                        });
                    }
                });
            });
        }
    },
    getFooterextend : function() {
        if (!$("#mainContainer").hasClass("checkoutBillingShipping")) {
            var contentHeight, assignContentVal;
            if ($("#mainContainer").height() != null) {
                contentHeight = $("#mainContainer").height();
                assignContentVal = "#mainContainer";
            }

            if ($(".atgHeaderDiv").height()) {
                var totalBlocksHeight = $(".atgHeaderDiv").height() + $(".atgFooterDiv").height() + contentHeight;
            } else {
                var totalBlocksHeight = $("header.globalHeader").height() + $("footer div.homesocialBarDiv").height() + $("footer#footer").height() + contentHeight;
            }
            var windowHeight = $(window).height();

            var calcContainerHeight = windowHeight - totalBlocksHeight;
            if (windowHeight > totalBlocksHeight) {
                var appliedHeight = calcContainerHeight + contentHeight;
                if ($("#mainContainer").hasClass("largeFileOrderThankYou")) {
                    appliedHeight = appliedHeight - 160;
                }
                $(assignContentVal).css('height', appliedHeight + 'px');
            }
        }
    },

    btnShippingMethodContinue : {
        init : function(params_) {
            $(params_.target).one('click', function() {
                var chinaVat = $('#chinaVatSelected').val();
                if(chinaVat == 'selected'){
                   $('#invVatInfoCheck').parent().closest('div').hide();
                   invInfoData(params_);
                }
            });
        }
    }

};

// ************************ DO YOUR ALL JS CALLS AND CAHNGES BELOW
// ************************//
(function($) {
    // jQuery.noConflict();
    /* dsp global button click */
    LSCA.buttonClick();
    LSCA.setGlobalFlyout();
    LSCA.iPadDropFix();
    // round corner PIE
    LSCA.doButtonRound();
    LSCA.setPlaceHolder.init();
    LSCA.langShowHide.init({
        selector : '#langShowHide input[type="radio"]'
    });
    LSCA.addRowQO.init({
        url : '/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp',
        target : '.qckOrderUpload'
    });
    LSCA.lcaddRowQO.init({
        url : '/store/includes/homePage/quickorder/jsonQuickOrderAddToGrid.jsp',
        target : '.largeCheckout'
    });
    LSCA.addRowQOStoreland.init({
        target : '#quickorder2'
    }); // ----Storelanding add row----//
    LSCA.removeRowItem.init({
        pageid : 'qckOrderUpload',
        url : '/store/includes/ajax/ajaxRemoveLineItem.jsp?part_number=',
        target : '#productTable'
    });
    LSCA.removeRowItem.init({
        pageid : 'viewMyCatalog',
        url : '/store/includes/ajax/ajaxRemoveGiftListItem.jsp?giftId=',
        target : '#viewCatalog'
    });
    LSCA.removeRowItem.init({
        pageid : 'savedCart',
        url : '/store/includes/ajax/ajaxRemoveSavedCart.jsp?savedOrderId=',
        target : '#savedCartTable'
        //callback : LSCA.reOrderSavedCart.init
    });
    LSCA.removeRowItem.init({
        pageid : 'savedCartDetail',
        url : '/store/includes/ajax/ajaxRemovesavedCartLineItem.jsp?',
        target : '.mySavedCart'
    });
    LSCA.viewMyCatalogAddItem.init({
        url : '/store/includes/ajax/ajaxAddToMyCatalog.jsp?',
        target : '#viewCatalog'
    });
    // Create Catalog List
    LSCA.createMyCatalogList.init({
        pageid : 'viewMyCatalog',
        url : '/store/includes/ajax/ajaxCreateMyCatalogList.jsp?list_name=',
        target : '#mycatlogList'
    });
    // Delete Catalog List
    LSCA.removeMyCatalogList.init({
        url : '/store/includes/ajax/ajaxRemoveMyCatalogList.jsp?giftlistId=',
        target : '#viewCatalog'
    });
    // Rename catalog list
    LSCA.editMyCatalogList.init({
        url : '/store/includes/ajax/ajaxEditMyCatalogListName.jsp?',
        target : '#catlogListView'
    });
    LSCA.editMyCatalogList1.init({
        url : '/store/includes/ajax/ajaxEditMyCatalogListName.jsp?',
        //target : '#catlogListView'
    });
    // Display Right Table on click of Giftlist
    LSCA.displayCatalogList.init({
        pageid : 'viewMyCatalog',
        url : '/common/myaccount/getCatalogListItems.jsp?listId=',
        target : '#viewCatalog'
    });
    // Default list load on page refresh
	if(window.location.href.indexOf('rtulid') != -1) {
    	 LSCA.viewCatalogList.init({
             pageid : 'viewMyCatalog',
             url : '/common/myaccount/getMyCatalogLists.jsp?rtulid='+window.location.href.split('rtulid=')[1].trim(),
             target : '#mycatlogList'
         }); 
    } else {
		LSCA.viewCatalogList.init({
			pageid : 'viewMyCatalog',
			url : '/common/myaccount/getMyCatalogLists.jsp',
			target : '#mycatlogList'
		});
	}
    // For email catalog
    LSCA.displayEmailCatalogList.init({
        pageid : 'emailCatalog',
        url : '/common/myaccount/getCatalogListItems.jsp?listId=',
        target : '#catalogEmail'
    });
    // My catalog overlay_contacts
    LSCA.changeCatalogAddItem.init({
        pageid : 'cartPage',
        url : '/store/includes/ajax/ajaxAddToMyCatalog.jsp?',
        target : '#overlay_catlog'
    });
    // Create Catalog List on overlay cart
    LSCA.linkMyCatalogList.init({
        pageid : 'cartPage',
        url : '/store/includes/ajax/ajaxCreateMyCatalogList.jsp?list_name=',
        target : '#myCatalogModal'
    });
    LSCA.linkMyCatalogListNew.init({
        pageid : 'shoppingCartPage',
        url : '/store/includes/ajax/ajaxCreateMyCatalogList.jsp?list_name=',
        target : '#myCatalogModalCart'
    });
    // My catalog overlay_contacts end

    // Reedem Quote Dropdown
    LSCA.changeShippingAddress.init({
        pageid : 'redeemQuote',
        url : '/common/myaccount/ajaxSelectedAddressDetails.jsp?addressType=shipping&selectedAddressId=',
        target : '#customDropdown2',
        shippingURL : '/common/myaccount/fetchShippingCharge.jsp',
        callInitiator : 'changeShippingAddress'
    });
    LSCA.changeBillingAddress.init({
        pageid : 'redeemQuote',
        url : '/common/myaccount/ajaxSelectedAddressDetails.jsp?addressType=billing&selectedAddressId=',
        target : '#customDropdown1'
    });
    LSCA.favoriteUpdateItem.init({
        pageid : 'cartPage',
        url : '/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=',
        url2 : '/store/includes/ajax/ajaxAddToMyCatalog.jsp?part_number=',
        target : '#cartTable'
    });
    LSCA.RadioShowHide.init({
        targetEl : '#no',
        elAttr : 'checked',
        targetE2 : '#yes',
        e2Attr : 'checked',
        toggleClass : $('.taxForm'),
        button : $(".continue")
    });
    LSCA.RadioShowHide.ShowHide({
        selector : $('input[type="radio"]'),
        target : $('.taxForm'),
        button : $(".continue")
    });
    LSCA.populateState.init({
        url : '/store/includes/ajax/ajaxStateListOnCountrySelection.jsp?countryCode=',
        target : '#shippingaddress'
    })
    LSCA.populateState.init({
        url : '/store/includes/ajax/ajaxStateListOnCountrySelection.jsp?countryCode=',
        target : '#billingaddress'
    })
    LSCA.copyBillAddr({
        target : '#billShip'
    });
    LSCA.selectAll({
        target : ".selAll",
        parent : "div.pchbox"
    });
    // select option resets
    LSCA.selectReset.init({
        target : '.samForm select',
        formid : 'samForm'
    });
    LSCA.selectReset.init({
        target : '',
        formid : 'clearForm'
    });
    LSCA.submitLocale({
        target : '#lang-dropmenu',
        selector : '#languageBtn'
    });
    LSCA.submitLocale({
        target : '#countryLists .countryList',
        selector : '#cntrySel'
    });

    LSCA.sidebarSubmitLocale({
        target : '.sidebar .selectLang',
        selector : '#languageBtn'
    });
    LSCA.clickShow({
        target : '.nAddress',
        selector : '.dropAddress'
    });
    LSCA.showDiv.init({
        target : '#salesAssistantLnk',
        selector : '#salesAssistant'
    });
    /* for quick order iframe */
    LSCA.qckOrderIframe.init({
        target : '.batchUp .btnUpload',
        selector : '.iframeBlock'
    });
    /* for large file order iframe */
    LSCA.qcklgOrderIframe.init({
        target : '.batchUp .btnUpload',
        selector : '.iframeLargeFileBlock'
    });
    /* Added for APP-3850 CN JP availability check */
    LSCA.qckOrderViewInventory.init({
        target : '.batchUp .btnUploadInventory',
        selector : '.iframeInventoryBlock'
    });
    LSCA.prodFilter.init({
        pageId : "productListing",
        target : ".gridWrap",
        url : "/store/getPageGridData.jsp"
    });
    /* Saved Cart Table */
    LSCA.filterSavedCart.init({
        target : '.savedCart .gobtn',
        selector : '.skyblueTable',
        pageId : "savedCart"
    });
    /* cart update button on change textbox value */
    LSCA.cartShowUpdate({
        target : '.cartTable .textboxQnt',
        selector : '.cartTable .skyblueTable'
    });
    /* My Quote == getQuote */
    LSCA.getQuoteOrder({
        url : '/common/includes/ajax/ajaxDisplayQuotesDroplet.jsp',
        target : '.btnGo',
        selector : '#quoteResult',
        pageId : 'myQuote'
    });
    /* My Quote listing == getQuote */
    LSCA.getMultiQuote({
        url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?days=thirtydays',
        target : '#quoteResult',
        pageId : 'myQuoteListing'
    });
    
    LSCA.viewMultiQuote.init({
        url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?',
        target : 'searchOrder'
    });
	LSCA.searchMultiQuote.init({
        url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?',
        target : 'searchOrder'
    });
	LSCA.searchMultoQuoteDate.init({
        url : '/common/includes/ajax/ajaxDisplayMultiQuotesDroplet.jsp?',
        target : 'orderDateRange'
    });
	
	LSCA.viewSalesWebOrder.init({
        url : '/common/includes/ajax/sapOrderHistoryJson.jsp?',
        target : 'orderRangeDropDown'
    });
	LSCA.searchSalesOrder.init({
        url : '/common/includes/ajax/sapOrderHistoryJson.jsp?',
        target : 'searchOrder'
    });
	LSCA.searchDateSalesOrder.init({
        url : '/common/includes/ajax/sapOrderHistoryJson.jsp?',
        target : 'orderDateRange'
    });
	if($('#myAgilentUser').val()=='false'){
		LSCA.getSalesOrder.init({
			url : '/common/includes/ajax/sapOrderHistoryJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
			target : '#orderResult',
			pageid : 'myOrderStatus'
		});
	}
	
	LSCA.viewInvoiceOrder.init({
        url : '/common/includes/ajax/invoiceDetailJson.jsp?',
        target : 'searchOrder'
    });
	LSCA.searchChinaInvoice.init({
        url : '/common/includes/ajax/invoiceDetailJson.jsp?',
        target : 'searchOrder'
    });
	LSCA.searchChinaInvoiceDate.init({
        url : '/common/includes/ajax/invoiceDetailJson.jsp?',
        target : 'orderDateRange'
    });
	LSCA.getNonchinaInvoice.init({
        url : '/common/invoiceDetailJson.jsp?ordr=thirtydays&pageName=myOrders&reloadOrders=true',
        target : '#orderResult1',
        pageid : 'myOrderStatus'
    });
	if($('#myAgilentUser').val()=='false'){
		LSCA.getWebOrder.init({
			url : '/common/includes/ajax/webOrderHistoryJson.jsp?ordr=thirtyday&pageName=myOrders',
			target : '#webOrderResult',
			pageid : 'myOrderStatus'
		});
	}
    /* Check Order Status == get order */
    LSCA.getQuoteOrder({
        url : '/common/includes/ajax/ajaxSapOrderHistory.jsp?',
        target : '.btnGo',
        selector : '#orderResult',
        pageId : 'getOrder'
    });
    /* Recently Ordered Products== get order */
    LSCA.recentlyOrderedProductsTable.init({
        pageid : 'getOrder',
        url : '/common/myaccount/recentlyOrderedItems.jsp',
        target : '#recentlyOrderedProducts'
    });
    /* My Quote == Disable Director View */
    LSCA.disableDirectorView({
        boolVal : 'true',
        pageId : 'myQuote'
    });
    /* My Quote == clear form fields */
    LSCA.clearFields({
        target : '#quoteForm'
    });
    /* Next preveious navigation */
    LSCA.globalPaginate.init({
        prevnext : true
    });
    /* BCC order email group edit */
    LSCA.editField({
        target : '.editField',
        grpName : '#grpName',
        grpDesc : '#grpDesc',
        grpId : '#updateIdField'
    });
    /* BCC email routing manager edit */
    LSCA.editField({
        target : '.editField',
        grpEmail : '#grpEmail',
        grpRadio : '#radioFields',
        grpId : '#updateIdField'
    });
    /* BCC order email group delete */
    LSCA.deleteField({
        target : '.delField',
        grpId : '#deleteIdField'
    });
    /* sidebar */
    LSCA.getCategoryList.init({
        url : '/store/includes/category/categoryList.jsp?catId=',
        page : 1,
        target : '#categoryList',
        pageid : 'categoryPage'
    });
    /* Product Detail Add To Cart */
    LSCA.PrDetailAddToCart.init();
    /* promotional images storelanding */
    LSCA.promoData.init({
        url : '/store/includes/homePage/promoImages.jsp?dataSize=',
        target : '.btnVwAll',
        pageId : 'homePage'
    });
    LSCA.triggerSSOEvent.init({
        target : '.SSOclass',
        divTarget : '.mainContainer',
        loaderClass : '.container.orConfir'
    });
    /* check atleast once profile */
    if ($('#mainContainer').hasClass('RegPropage') | $('#mainContainer').hasClass('areaofInterestpage')) {
        LSCA.requiredOnce({
            target : '.btnContinue, .btnUpdate',
            selector : '.pchbox',
            flagchk : true
        });
    } else {
        LSCA.requiredOnce({
            target : '.btnContinue, .btnUpdate',
            selector : '.pchbox'
        });
    }
    /* global form submit */
    // ----//Clear Check Box//----//
    LSCA.checkboxReset({
        selector : '#regSubForm,#regProfileForm'
    });
    /* email form validate */
    LSCA.formValidate.init({
        selector : '.sendEmail',
        url : '/store/myaccount/emailShoppingCartSuccess.jsp',
        target : '#emailShoppingCart'
    });
    LSCA.formValidate.init({
        selector : '.sendEmailing',
        url : '/store/myaccount/emailOrderDetailsSuccess.jsp',
        target : '#emailCartform'
    });
    LSCA.formValidate.init({
        selector : '.sendEmail',
        url : '/store/myaccount/emailShoppingCartSuccess.jsp',
        target : '#emailShoppingCatalog'
    });
    $("#emailOrderDetailsClose").click(function() {
        $("#pageContentDiv").html(" ");
    });
    LSCA.saveShopingCart.init({
        url : '/store/includes/ajax/ajaxSaveCart.jsp?description=',
        target : '#saveShopingCart'
    });
    // Normal Form Validation//
    LSCA.NormalFormValidate.init({
        selector : '.sbmtOrder',
        target : '#reviewOrder',
        target2 : '#sbmtOrder'
    });
    LSCA.NormalFormValidate.init({
        selector : '.sbmtCreate',
        target : '#fedExForm',
        target2 : '#sbmtCreate'
    });
    LSCA.NormalFormValidate.init({
        selector : '#quickOrderAddCart',
        target : '#quickOrderCart',
        target2 : '#quick-order-add-to-cart-button'
    });
    // BCC order Status Tool Normal Form Validation//
    LSCA.NormalFormValidate.init({
        selector : '#sapUpdate',
        target : '#sapUpdateForm',
        target2 : '#updateorder'
    });
    // BCC webOrderRoutes page
    LSCA.webOrderSubmit({
        target : '#webOrder input[type="radio"]',
        selector : '#webOrderSubmit'
    });
    LSCA.linkClickButtonSubmit({
        target : '.deleteRow',
        selector : '.delete',
        parentSelector : 'tr'
    });
    // on Check Button Disable

    LSCA.onCheckButtonDisable({
        selector : '#btnTest',
        target : '#billShip'
    });
    // BCC select Option Selected
    LSCA.selectOptionSelected.init({
        selector : '#salesOrganization',
        target : '.editSelect',
        dataValue : '.selectValue1',
        updateValue1 : '#routingDataValueUpdate',
        updateValue2 : '#routingItemValueUpdate'
    }, LSCA.selectOptionSelected.init({
        selector : '#productLine',
        target : '.editSelect',
        dataValue : '.selectValue2'
    }), LSCA.selectOptionSelected.init({
        selector : '#distributionGroup',
        target : '.editSelect',
        dataValue : '.selectValue3'
    }));
    // BCC selected Radio Value
    LSCA.selectedRadioValue({
        target : '#webOrder input[type="radio"]'
    });
    // BCC text box value empty button disable
    LSCA.textValueButtonDisable({
        selector : '#sapUpdateForm input, #sapUpdateForm textarea, #sapUpdateForm button',
        target : '#sapOrder'
    });
    // empty cart link prompt dialog
    LSCA.emptyShoppingCart({
        target : '#emptyShoppingCart'
    });
    /* textbox autofocus */
    LSCA.autoFocus({
        target : '.autoFocus'
    });
    LSCA.replaceSpecialChar({
        target : '#Qty,.textboxQnt,.qtyTxtbox,.fedexNum,#reqQty'
    });
    /* animate search textbox */
    /* cut copy paste */
    LSCA.preventCCP.init({
        target : '.ccp'
    });
    LSCA.billShipHandler.init({
        target : '#accordion'
    })
    // create left menu and submenu
    LSCA.createLeftMenu.init({
        pageId : 'homePage'
    }); /* JSON url need to update here */
    LSCA.disablePageBack.init();
    LSCA.restricttextareamaxlength.init({
        maxlength : 132
    });
    LSCA.modalIFrameLoad.hide({
        pageid : 'quickOrder'
    });
    // For Advance shipping
    LSCA.advShip.init({
        target : '.advShip',
        selector : '#advShp',
        pageId : 'checkoutBillingShipping',
        chngShp : '.addImdShp',
        adShp : '.addPrmShp',
        advQty : '.advQty',
        cancel : '#advShipcancel',
        splitItemPrmy : '.splitItemPrmy',
        splitItemImd : '.splitItemImd',
        delDate : '.delDate'
    });
    LSCA.invInfo.init({
        target : '.invInfo',
        selector : '#invoice'
    });
    LSCA.invCRMInfo.init({
        target : '.invCRMInfo',
        selector : '#invoiceDetails'
    });
    LSCA.btnShippingMethodContinue.init({
        target : '#btnShippingMethodContinue',
        selector : '#invoice'
    });

    if ($(document).find("select").length > 0 || $(document).find("input[type=checkbox]").length > 0) {
        $("select").not(".noUniform").uniform();
        $("input[type=checkbox]").not(".noUniform").uniform();
    }
    /* ends here */
    /* country List equal height begins */
    var maxHeight = -1;
    $('.countryList > div, .placeOrderBox').each(function() {
        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
    });
    $('.countryList > div, .placeOrderBox').each(function() {
        $(this).height(maxHeight + 8);
    });
    /* DCCOM 4736 starts */
    $('#redeemPageDiv .placeOrderBox').each(function() {
        $(this).height(maxHeight + 8);
    });
    $('#largeFileCheckoutDiv .placeOrderBox').each(function() {
        $(this).height(maxHeight + 8);
    });
    /* DCCOM 4736 ends */
    /* country List equal height ends */
    $('.cal').datepicker().attr('readonly', true);

    $("#df").datepicker({
        onClose : function(selectedDate) {
            $("#dt").datepicker("option", "minDate", selectedDate);
        }
    }).attr('readonly', true);
    $("#dt").datepicker({
        onClose : function(selectedDate) {
            $("#df").datepicker("option", "maxDate", selectedDate);
        }
    }).attr('readonly', true);
	/*$("#orderStartDate").datepicker({
        onClose : function(selectedDate) {
            $("#orderEndDate").datepicker("option", "minDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderStartDate').next().hide();
				$('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderStartDate').removeClass('requiredTextBox');
				$('#orderStartDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#orderEndDate").datepicker({
        onClose : function(selectedDate) {
            $("#orderStartDate").datepicker("option", "maxDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderEndDate').next().hide();
				$('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderEndDate').removeClass('requiredTextBox');
				$('#orderEndDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);*/
    
    
    var CNcountry = $("#countryCode").val();
    if(CNcountry == "CN"){

  $("#orderStartDateInvoice").datepicker({
	  onClose : function(selectedDate) {
		  $("#orderEndDateInvoice").datepicker("option", "minDate", selectedDate);
	  },

        dateFormat: "yy/mm/dd",
        onSelect : function(selected) {
          if(selected != ''){
				 $('#orderStartDateInvoice').next().hide();
				 $('#orderStartDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
				 $('#orderStartDateInvoice').removeClass('requiredTextBox');
				 $('#orderStartDateInvoice').css('border-color', '');
			}
		}
    });

    $("#orderEndDateInvoice").datepicker({
        onClose : function(selectedDate) {
            $("#orderStartDateInvoice").datepicker("option", "maxDate", selectedDate);
        },
        dateFormat: "yy/mm/dd",
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderEndDateInvoice').next().hide();
				$('#orderEndDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderEndDateInvoice').removeClass('requiredTextBox');
				$('#orderEndDateInvoice').css('border-color', '');
			}
		}
    });
    
    $("#startDateInvioice").datepicker({
        
        dateFormat: "yy/mm/dd",
		onSelect : function(selected) {
			if(selected != ''){
				$('#posoLabelStartInvoice').hide();
				//$('#startDateInvioice').next().hide();
				$('#startDateInvioice').prev('.fieldLabel').removeClass('requiredLabel');
				$('#startDateInvioice').removeClass('requiredTextBox');
				$('#startDateInvioice').css('border-color', '');
			}
		}
    });
    
    /******************QUOTE************/
    $("#orderStartDateQuote").datepicker({
  	  onClose : function(selectedDate) {
  		  $("#orderEndDateQuote").datepicker("option", "minDate", selectedDate);
  	  },

          dateFormat: "yy/mm/dd",
          onSelect : function(selected) {
            if(selected != ''){
  				 $('#orderStartDateQuote').next().hide();
  				 $('#orderStartDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
  				 $('#orderStartDateQuote').removeClass('requiredTextBox');
  				 $('#orderStartDateQuote').css('border-color', '');
  			}
  		}
      });

      $("#orderEndDateQuote").datepicker({
          onClose : function(selectedDate) {
              $("#orderStartDateQuote").datepicker("option", "maxDate", selectedDate);
          },
          dateFormat: "yy/mm/dd",
  		onSelect : function(selected) {
  			if(selected != ''){
  				$('#orderEndDateQuote').next().hide();
  				$('#orderEndDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
  				$('#orderEndDateQuote').removeClass('requiredTextBox');
  				$('#orderEndDateQuote').css('border-color', '');
  			}
  		}
      });
      
      $("#startDateQuote").datepicker({
          
          dateFormat: "yy/mm/dd",
  		onSelect : function(selected) {
  			if(selected != ''){
  				$('#posoLabelStartQuote').hide();
  				//$('#startDateInvioice').next().hide();
  				$('#startDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
  				$('#startDateQuote').removeClass('requiredTextBox');
  				$('#startDateQuote').css('border-color', '');
  			}
  		}
      });

    }else{

    	$("#orderStartDateInvoice").datepicker({
            onClose : function(selectedDate) {
                $("#orderEndDateInvoice").datepicker("option", "minDate", selectedDate);
            },
            dateFormat: "dd/mm/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#orderStartDateInvoice').next().hide();
    				$('#orderStartDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#orderStartDateInvoice').removeClass('requiredTextBox');
    				$('#orderStartDateInvoice').css('border-color', '');
    			}
    		}
        });

        $("#orderEndDateInvoice").datepicker({
            onClose : function(selectedDate) {
                $("#orderStartDateInvoice").datepicker("option", "maxDate", selectedDate);
            },
            dateFormat: "dd/mm/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#orderEndDateInvoice').next().hide();
    				$('#orderEndDateInvoice').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#orderEndDateInvoice').removeClass('requiredTextBox');
    				$('#orderEndDateInvoice').css('border-color', '');
    			}
    		}
        });
        $("#startDateInvioice").datepicker({
            
            dateFormat: "dd/mm/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#posoLabelStartInvoice').hide();
    				//$('#startDateInvioice').next().hide();
    				$('#startDateInvioice').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#startDateInvioice').removeClass('requiredTextBox');
    				$('#startDateInvioice').css('border-color', '');
    			}
    		}
        });
        /*******QUOTE********/
        $("#orderStartDateQuote").datepicker({
            onClose : function(selectedDate) {
                $("#orderEndDateInvoice").datepicker("option", "minDate", selectedDate);
            },
            dateFormat: "mm/dd/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#orderStartDateQuote').next().hide();
    				$('#orderStartDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#orderStartDateQuote').removeClass('requiredTextBox');
    				$('#orderStartDateQuote').css('border-color', '');
    			}
    		}
        });

        $("#orderEndDateQuote").datepicker({
            onClose : function(selectedDate) {
                $("#orderStartDateQuote").datepicker("option", "maxDate", selectedDate);
            },
            dateFormat: "mm/dd/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#orderEndDateQuote').next().hide();
    				$('#orderEndDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#orderEndDateQuote').removeClass('requiredTextBox');
    				$('#orderEndDateQuote').css('border-color', '');
    			}
    		}
        });
        $("#startDateQuote").datepicker({
            
            dateFormat: "mm/dd/yy",
    		onSelect : function(selected) {
    			if(selected != ''){
    				$('#posoLabelStartQuote').hide();
    				//$('#startDateInvioice').next().hide();
    				$('#startDateQuote').prev('.fieldLabel').removeClass('requiredLabel');
    				$('#startDateQuote').removeClass('requiredTextBox');
    				$('#startDateQuote').css('border-color', '');
    			}
    		}
        });
    }
    
    
     if(CNcountry == "CN"){
		 $("#orderStartDate").datepicker({
			 dateFormat: "yy/mm/dd",
        onClose : function(selectedDate) {
            $("#orderEndDate").datepicker("option", "minDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderStartDate').next().hide();
				$('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderStartDate').removeClass('requiredTextBox');
				$('#orderStartDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#orderEndDate").datepicker({
		dateFormat: "yy/mm/dd",
        onClose : function(selectedDate) {
            $("#orderStartDate").datepicker("option", "maxDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderEndDate').next().hide();
				$('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderEndDate').removeClass('requiredTextBox');
				$('#orderEndDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#startDate").datepicker({
		dateFormat: "yy/mm/dd",
        onClose : function(selectedDate) {
            $("#endDate").datepicker("option", "minDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				/*$('#startDate').next().hide();*/
				$('#startDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#startDate').removeClass('requiredTextBox');
				$('#startDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#endDate").datepicker({
		dateFormat: "yy/mm/dd",
        onClose : function(selectedDate) {
            $("#startDate").datepicker("option", "maxDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				/*$('#endDate').next().hide();*/
				$('#endDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#endDate').removeClass('requiredTextBox');
				$('#endDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
	}
	else{
		$("#orderStartDate").datepicker({
        onClose : function(selectedDate) {
            $("#orderEndDate").datepicker("option", "minDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderStartDate').next().hide();
				$('#orderStartDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderStartDate').removeClass('requiredTextBox');
				$('#orderStartDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#orderEndDate").datepicker({
        onClose : function(selectedDate) {
            $("#orderStartDate").datepicker("option", "maxDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				$('#orderEndDate').next().hide();
				$('#orderEndDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#orderEndDate').removeClass('requiredTextBox');
				$('#orderEndDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
		$("#startDate").datepicker({		
        onClose : function(selectedDate) {
            $("#endDate").datepicker("option", "minDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				/*$('#startDate').next().hide();*/
				$('#startDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#startDate').removeClass('requiredTextBox');
				$('#startDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
    $("#endDate").datepicker({		
        onClose : function(selectedDate) {
            $("#startDate").datepicker("option", "maxDate", selectedDate);
        },
		onSelect : function(selected) {
			if(selected != ''){
				/*$('#endDate').next().hide();*/
				$('#endDate').prev('.fieldLabel').removeClass('requiredLabel');
				$('#endDate').removeClass('requiredTextBox');
				$('#endDate').css('border-color', '');
			}
		}
    }).attr('readonly', true);
	}
    $(".tooltip").tooltip();
    // Datepicker
    var maxiDate,mindateVal="",maxdateVal="";
	if($('#memberTypeValue').val() == "distributor"){
		maxiDate = '+6M';
	}else{
		maxiDate = '+12M';
	}
	if(jQuery(".redeemQuoteNew #installationPresent").val()=="true"){
		mindateVal=14;
		maxdateVal='+180D';
	}
	else{
		mindateVal=2;
		if($('#memberTypeValue').val() == "distributor"){
			maxdateVal = '+6M';
		}
		else{
			maxdateVal='+12M';
		}
	}
    $('.calender:not(.rc-calender)').datepicker({
        showOn : "button",
        buttonImage : "../images/A_Icon_Calendar_V2.svg",
        buttonImageOnly : true,
        minDate : 2,
        maxDate : maxiDate
    }).attr('readonly', true);
    $('.rc-calender').datepicker({
        showOn : "button",
        buttonImage : "../images/A_Icon_Calendar_V2.svg",
        buttonImageOnly : true,
        minDate : mindateVal,
        maxDate : maxdateVal
    }).attr('readonly', true);
    if(jQuery(".redeemQuoteNew #installationPresent").val()=="true"){
		$(".redeemQuoteNew #deliveryOptionsDiv li #DeliveryDate").trigger("click");
		$('.redeemQuoteNew #deliveryOptionsDiv .custom-future-date').show();
		//$('.rc-calender').datepicker('show');
	}
    LSCA.disableCalender.init({
        selector : '#DeliveryDate',
        target : '.radioContBox #calender, .placeOrderBox #calender ',
        selector2 : '.radioContBox input[type="radio"], .placeOrderBox input[type="radio"]'
    });
    LSCA.toolTipFly.init({
        target : '.mainListItem',
        selector : '.drop_cols'
    });

    /* search box integration */
    LSCA.searchSubmit();
    LSCA.vatExamtModal();

    $('.panel-collapse').collapse({
        toggle : false
    });
    // show all function for category list left menu start
    var catListCount = $("#browseCategory").find(".childCat li").length;
    var catlist = $("#browseCategory").find(".childCat li:eq(14)");
    if (catListCount <= 15) {
        $("#showAll").hide();
    } else if (catListCount >= 16) {
        $(catlist).nextAll().hide();
        $("#showAll").show();
        $("#showAll").on('click', function() {
            $(catlist).nextAll().show();
            $("#showAll").hide();
        })
    }
    /* for toggle checkbox on billing shipping page */
    LSCA.toggleCheckbox.init({
        target : '.selectChk .radioBoxPanel',
        selector : '',
        pageId : 'checkoutBillingShipping'
    });
    /* for toggle checkbox on billing shipping page for new checkbox*/
    LSCA.toggleCheckboxNew.init({
        target : '.selectChk .radioBoxPanel',
        selector : '',
        pageId : 'checkoutBillingShipping'
    });

    /* for toggle checkbox on redeem quote page */
    LSCA.toggleCheckbox.init({
        target : '.selectChk .radioBoxPanel',
        selector : '',
        pageId : 'redeemQuote'
    });
})(jQuery)

function resourceErrorMsg(key) {
    LSCA.GlobalValidate.showError('', $('#' + key).text());
}
function resourceCreditErrorMsg(key) {
    $(".errorMsg").text($('#' + key).text());
    $(".errorMessages.errorMsg").show();
}
function promoData(queryString) {
    $.ajax({
        type : "GET",
        url : "/store/includes/homePage/promoImages.jsp?" + queryString,
        dataType : "html",
        cache : false
    }).done(function(data) {
        if (data != null || data != "") {
            $("#promoImages").html(data);
            if (queryString != "")
                $("#promoImagesView").hide();
        }
    })
}
$('#myModalFileUpload').on('hidden.bs.modal', function() {
    $(".iframeLargeFileBlock").contents().find("body").remove();
});
function heightPanel() {
    $(".iframeBlock").addClass("adjHeight");
    $('.adjHeight').css('height', '200px');
}

function heightPanelInventoryView() {
    $(".iframeInventoryBlock").addClass("adjHeight");
    $('.adjHeight').css('height', '200px');
}

function heightPanelLargeFileView() {
    $(".iframeLargeFileBlock").addClass("adjHeight");
    $('.adjHeight').css('height', '200px');
}
// ----Added for APP-3850 For japan china availability check----//
function modalIFrameLoadShowCommon() {
    $('#myModal').find('iframe').show();
}

function modalIFrameLoadShowInventoryCommon() {
    $('#myModelInventory').find('iframe').show();
}

function modalIFrameLoadShowFileUploadCommon() {
    $('#myModalFileUpload').find('iframe').show();
}

var webserviceURL = "/_vti_bin/RelatedProducts.asmx";
var jQuery_1_10_2 = jQuery;
$("#submtRequestQuote").click(function(e) {
    e.preventDefault();
    requestQuote($("#cartTable .skyblueTable").map(function() {
        return {
            title : $(this).find("a.partNo").text(),
            description : $(this).find("a.partDescr").text()
        };
    }).get());
});

/**
 * Causes this information to be added to the current user's session, which will
 * display when they visit the request a quote page. You can pass in any string
 * value for the title and description and it will display it as you passed it
 * in; there is no lookup of the information in the database (it doesn't get the
 * part or product and verify that it exists). Redirects the browser to the
 * request quote page on completion
 *
 * @param partOrders
 *            an array of objects that look like this: obj.part: name of the
 *            part obj.description: description to use for the part
 */
reqId = $("#requestquoteIdobs").val();
function requestQuote(partOrders) {
    var partOrderString = "";
    jQuery_1_10_2.each(partOrders, function(index, partOrder) {
        partOrderString += encodeURIComponent(partOrder.title) + "-$-" + encodeURIComponent(partOrder.description);
        if (index != partOrders.length - 1) {
            partOrderString += "-#-";
        }
    });
    $.ajax({
        type : "POST",
        contentType : "application/json; charset=utf-8",
        url : getURLForWebserviceMethod("RequestQuote"),
        data : JSON.stringify({
            "partNumberDetails" : partOrderString
        }),
        success : function() {
            window.location.href = reqId + "/en-US/_layouts/agilent/RequestQuote.aspx?Source=/common/cart.jsp";
        },
        dataType : "json"
    });

}
// for AP-856 advance shippment
function advShipData(queryString, params_) {
    $("#advShp").html('');
    LSCA.imageLoader.init({
        target : params_.selector
    });
    $.ajax({
        type : "POST",
        url : "/common/includes/ajax/ajaxAddPartialShip.jsp?" + queryString,
        dataType : "html",
        cache : false
    }).done(function(data) {
        if (data != null || data != "") {
            $("#advShp").html(data);
            btnHTML = $("#collapseThree .radioContBox").find(".btnSpace").html();
            $(params_.selector).removeClass("hide");
            LSCA.advShip.init({
                target : '.advShip',
                selector : '#advShp',
                pageId : 'checkoutBillingShipping',
                chngShp : '.addImdShp',
                adShp : '.addPrmShp',
                advQty : '.advQty',
                splitItemPrmy : '.splitItemPrmy',
                splitItemImd : '.splitItemImd',
                delDate : '.delDate'
            });
            LSCA.billShipHandler.init({
                target : '#accordion'
            });
            $("#collapseThree .radioContBox").find(".btnSpace").remove();
            $("a.advShip").parent().show();
        }
    })
}

/* APP-4409 */
function invInfoData(params_) {
    $("#invoice").html('');
    LSCA.imageLoader.init({
        target : params_.selector
    });
    $.ajax({
        type : "POST",
        url : "/common/includes/ajax/ajaxInvoiceInfo.jsp?",
        dataType : "html",
        cache : false
    }).done(function(data) {
        if (data != null || data != "") {
            $("#invoice").html(data);
            $(params_.selector).removeClass("hide");

        }
    })
}

function getURLForWebserviceMethod(method) {
    return reqId + webserviceURL + "/" + method;
}

// add to cart from product home page
$(document).on("submit", "#quickorder2", function(e) {
    try {
        /* create array */
        var stringAjax = '';
        $("#quickorder2 tbody tr").each(function() {
            prodQty = $(this).find('input[type=text]').val();
            prodPartNo = $(this).attr('id');
            stringAjax = stringAjax + "catalogIds=" + prodPartNo + "&" + prodPartNo + "=" + prodQty + "&";
            pageLink = "home add";
        });
        callAjaxMethod(stringAjax, pageLink);
    } catch (e) {
        console.log("Something went wrong !!!");
    }
});

// add to cart from product cart page
$(document).on("click", "#quickOrderAddCart", function(e) {
    try {
        e.preventDefault();
        // Quantity gets doubled in add to cart
        if ($('#partNumber').val() != '' && $('#Qty').val() != '') {
            $('#quickOrderAddCart').attr('disabled', 'disabled');
        }
        /* create array */
        var stringOrder = '';
        prodQty = $("#quickOrderCart").find('#Qty').val();
        prodPartNo = $("#quickOrderCart").find('#partNumber').val();
        stringOrder = stringOrder + "catalogIds=" + prodPartNo + "&" + prodPartNo + "=" + prodQty;
        pageSrc = "cart add";
        if ((prodQty != "") && (prodPartNo != "")) {
            callAjaxMethod(stringOrder, pageSrc);
        }
    } catch (e) {
        console.log("Something went wrong !!!");
    }
});

// add to cart from product listing page
$("#addtocart,#addtocart2").on('click', function(e) {
    try {
        /* create array */
        var strAjax = '';
        $(".productListing .rgtPnl .gridWrap form tbody tr").each(function() {
            prodQty = $(this).find('.textboxQnt').val();
            prodPartNo = $(this).attr('id');
            if (prodQty != "") {
                strAjax = strAjax + "catalogIds=" + prodPartNo + "&" + prodPartNo + "=" + prodQty + "&";
            }
            pageURL = "productFilter add";
        });
        callAjaxMethod(strAjax, pageURL);
    } catch (e) {
        console.log("Something went wrong !!!");
    }
});

/* qckOrderVwUploadedFileData add to Cart */
$(document).on("click", ".qckOrderUpload .addToCart", function(e) {
    e.preventDefault();
    var queryUrl = '';
    var qckUrl = "Quick Order File Upload add";
    $(this).parent().prev().find("tbody tr").each(function() {
        var prodQnt = $(".textboxQnt").val();
        var prodPart = $(".textboxQnt").attr("name");
        if (prodQnt != "") {
            queryUrl = queryUrl + "catalogIds=" + prodPart + "&" + prodPart + "=" + prodQnt + "&";
        }
    });
    callAjaxMethod(queryUrl, qckUrl);
    setTimeout(function() {
        $("#addToCart").click()
    }, 3000);
});
/* qckOrderVwUploadedFileData remove from Cart */

/* :::-- savedCartDetail :::: -- remove from cart --::: */
$(".savedCartDetail .mySavedCart tbody .skyblueTable").each(function() {
    $(this).find("a.remove").on("click", function(e) {
        e.preventDefault();
        var strajax = "";
        var prodQty = $(this).parents("tr").find(".qtyTxtbox").val();
        var prodpart = $(this).parents("tr").find(".qtyTxtbox").attr("name");
        strajax = strajax + "catalogIds=" + prodpart + "&" + prodpart + "=" + prodQty + "&";
        pageURL = "Saved Cart Details Remove Products";
        callAjaxMethodRemove(strajax, pageURL);
    });
});

/* :::-- viewMyCatalog :::: -- remove from cart --::: */
$(".viewMyCatalog #quoteResult .skyblueTable tbody tr").each(function() {
    $(this).find("a.remove").on("click", function(e) {
        e.preventDefault();
        var strajax = "";
        var prodQty = $(this).parents("tr").find(".qtyTxtbox").val();
        if (prodQty == "") {
            prodQty = 1;
        } else {
            prodQty = prodQty;
        }
        var prodpart = $(this).parents("tr").find(".qtyTxtbox").attr("name");
        strajax = strajax + "catalogIds=" + prodpart + "&" + prodpart + "=" + prodQty + "&";
        pageURL = "View My Catalog Remove Products";
        callAjaxMethodRemove(strajax, pageURL);
    });
});

$(".savedCartDetail .btnSpace #btnAddToCart").on("click", function(e) {
    e.preventDefault();
    var strAjax = "";
    pageurl = "Saved Cart Details Add Products";
    $(this).parent().prev().find(".mySavedCart tbody .skyblueTable").each(function() {
        var prodPart = $(this).find(".qtyTxtbox").attr("name");
        var prodqty = $(this).find(".qtyTxtbox").val();
        if (prodqty != "") {
            strAjax = strAjax + "catalogIds=" + prodPart + "&" + prodPart + "=" + prodqty + "&";
        }
    });
    callAjaxMethod(strAjax, pageurl);
    setTimeout(function() {
        $("#addToCart").click()
    }, 3000);
});

$(".viewMyCatalog .btnSpace #btnAddToCart").on("click", function(e) {
    e.preventDefault();
    var strAjax = "";
    pageurl = "View My Catalog Add Products";
    $(this).parent().prev().find("tbody tr").each(function() {
        var prodPart = $(this).find(".qtyTxtbox").attr("name");
        var prodqty = $(this).find(".qtyTxtbox").val();
        if (prodqty == "") {
            prodqty = 1;
        } else {
            prodqty = prodqty;
        }
        strAjax = strAjax + "catalogIds=" + prodPart + "&" + prodPart + "=" + prodqty + "&";
    });
    callAjaxMethod(strAjax, pageurl);
    setTimeout(function() {
        $("#addToCart").click()
    }, 3000);
});

$("#recentlyOrderedProducts .btnSpace #btnAddToCart").on("click", function(e) {
    try {
        e.preventDefault();
        var strAjax = "";
        var msgui = '';
        var msgui2 = '';
        var target = "#recentlyOrderedProducts";
        var url = $(target + ' form').attr('action');
        var formdata = $(target + ' form').serialize();
        var pageurl = "Recently Ordered Products Add Products";

        LSCA.loadingSpinner.showLoading();

        $("#recentlyOrderedTable").find("tbody tr").each(function() {
            var prodPart = $(this).find(".qtyTxtbox").attr("name");
            var prodqty = $(this).find(".qtyTxtbox").val();
            if (prodqty != "") {
                strAjax = strAjax + "catalogIds=" + prodPart + "&" + prodPart + "=" + prodqty + "&";
            }
        });
        callAjaxMethod(strAjax, pageurl);

        LSCA.globalAjax.doCall({url:url, dataType:'json', data:formdata}, function(data) {
            var data = data.data;
            if (data.obj1 && data.obj1.message != '') {
               msgui = (data.obj1.status === 'success')? '<div class="msg-stnd msg-box-success"><i class="fal fa-check-circle shopping-cart-sucess"></i><span ng-show="successPart" class="singleCartValidation"><a class="success-link" href="/common/cart.jsp">'+data.obj1.message+'</a></span></div>' : '<div class="msg-stnd msg-box-error"><i class="fal fa-exclamation-circle"></i><span>'+data.obj1.message+'</span></div>';
            }
            if (data.obj2 && data.obj2.message != '') {
                msgui2 = (data.obj2.status === 'failure')? '<div class="msg-stnd msg-box-error"><i class="fal fa-exclamation-circle"></i><span>'+data.obj2.message+'</span></div>' : '<div class="msg-stnd msg-box-error"><i class="fal fa-exclamation-circle"></i><span>'+data.obj2.message+'</span></div>';
            }

            $(document).find('#error-ajax-cart').html(msgui + msgui2).show();
            if (data.cartCountToUpdate && data.cartCountToUpdate != '') {
                $(document).find("#cartcount").html("(" + data.cartCountToUpdate + ")");
                $(document).find(".cartNum").html(data.cartCountToUpdate);
                $(target).find("input[type='text']").val("");
            }
            LSCA.loadingSpinner.hideLoading();
        });
    } catch (e) {
        console.log("Something went wrong !!!");
    }
});

$(".sapOrder #btnAddToCart").on("click", function() {
    $(".btnWrap").find("#addToCart").click();
    /*var strAjax = "";
    pageUrl = "SAP Order Details Add To Cart";
    $(this).parent().prev().find(".skyblueTable.textWrap tbody tr:even").each(function() {
        var productId = $(this).find("td:eq(1)").text();
        var defQty = $(this).find("td:eq(0)").text();
        var productQty = $(document).find("input[name=" + productId + "]").val();
        if (productQty == "") {
            productQty = defQty;
        } else {
            productQty = productQty;
        }
        strAjax = strAjax + "catalogIds=" + productId + "&" + productId + "=" + productQty + "&";
    });
    callAjaxMethod(strAjax, pageUrl);
    setTimeout(function() {
        $(".btnWrap").find("#addToCart").click()
    }, 3000);*/    
});

$(document).on("click", ".qckOrderUpload .remFav .remove", function(e) {
    e.preventDefault();
    var reqUrl = '';
    var remUrl = "Quick Order File Upload Remove";
    var reqQt = $(this).parents("tr").find(".textboxQnt").val();
    var reqPrt = $(this).attr("part-data");
    if (reqQt != "") {
        reqUrl = reqUrl + "catalogIds=" + reqPrt + "&" + reqPrt + "=" + reqQt + "&";
    }
    callAjaxMethodRemove(reqUrl, remUrl);
});

function callAjaxMethod(queryString, reqURL) {
    $.ajax({
        type : "GET",
        url : "/store/AddToCartArray.jsp?" + queryString,
        cache : false
    }).done(function(data) {
        var addProducts = [];
        addProducts = eval(data);
    });
}

function callAjaxMethodRemove(qryStr, reURL) {
    $.ajax({
        type : "GET",
        url : "/store/AddToCartArray.jsp?" + qryStr,
        cache : false
    }).done(function(data) {
        var remProducts = [];
        remProducts = eval(data);
    });
}

$(".cartTable #showcartItems .remove").on("click", function(e) {
    var delAjax = "";
    cId = $(this).attr("id");
    partNo = $(this).attr("part-num");
    prodQty = $("input[name=" + cId + "]").val();
    delAjax = delAjax + "catalogIds=" + partNo + "&" + partNo + "=" + prodQty;
    delPage = "cart remove";
    callAjaxMethodRemove(delAjax, delPage);
});

$(".favCatCartstock").each(function() {
    var strAjax = '';
    $("a.partId", this).on("click", function(e) {
        var prodQty = $(this).parents(".favCatCartstock").prev().find(".textboxQnt").val();
        var prodPartNo = $(this).attr("part-remove");
        if (prodQty != "") {
            strAjax = strAjax + "catalogIds=" + prodPartNo + "&" + prodPartNo + "=" + prodQty + "&";
        }
        if ($(this).hasClass("removeFav")) {
            pageURL = "Cart Page Remove from my catalog";
        } else {
            pageURL = "Cart Page Add to my catalog";
        }
        callAjaxMethod(strAjax, pageURL);
    });
});

$(document).on("click", ".picDetails .btnAdd", function(e) {
    e.preventDefault();
    $this = $(this);
    var strajax = "";
    var prodpart = $(this).parents(".picDetails").find("h4 a").text();
    // Here only 1 prod can be added (related products)
    prodQty = 1;
    strajax = strajax + "catalogIds=" + prodpart + "&" + prodpart + "=" + prodQty + "&";
    pageURL = "Related Products Add To cart";
    callAjaxMethod(strajax, pageURL);
    setTimeout(function() {
        $this.parent().find("#addCartBtn").click()
    }, 3000);
});

$(document).on('click', '#advShipcancel', function() {
    $("#advShipcancel").addClass("disabled");
    var isCancel = true;
    if (!$(this).hasClass("hideContinue")) {
        var btnCopy = '<div class="clearfix col-lg-12 mrginTP20 btnSpace topBorder p15 overVis"><button type="button" class="btn-stnd-medium btnLightBlue upper">'+$('#shipContinue').val()+'</button></div>';
    }
    $.ajax({
        type : "post",
        url : "/common/includes/ajax/ajaxAddPartialShip.jsp?isCancel=" + isCancel,
        dataType : "html",
        cache : false
    }).done(function() {
        if ($("#dangerousMix").val() != "true") {
            $("#collapseThree #DeliveryDate, #collapseThree #consolidateRadio").removeAttr("disabled");
            $("#collapseThree #consolidateRadio").attr("checked", "checked");
            $("#collapseThree #partialRadio").removeAttr("checked");
            $("#collapseThree #consolidateRadio").parent().click();
        }
        $("#deliveryOptionsDiv").append(btnCopy);
        $(".adShp").show();
        $(".advShp").hide();
        $(".advShp").find(".btnSpace").remove();
        LSCA.billShipHandler.init({
            target : '#accordion'
        });
        $(".addressBox").children().addClass("mbot10").removeClass("background");
    }).error(function() {
        console.log('Something went wrong!')
    });
});

$(document).on('click', '#invSave', function() {
    var data = $("#invoiceForm").serialize();
    var time = $("#customerName1").serialize();
    var saveInvoice = true;
    var invoiceFormValidate = LSCA.GlobalValidate.init({
                    target : '#invoiceForm'
    });
    if(invoiceFormValidate) {
        $('#checkoutVATErrMsg').addClass('hide');
        $.ajax({
            type : "post",
            url : "/common/includes/ajax/ajaxInvoiceInfo.jsp?saveInvoice=" + saveInvoice,
            data : data,
            dataType : "html",
            cache : false
        }).done(function() {
            LSCA.invInfo.init({
                target : '.invInfo',
                selector : '#invoice'
            });
            $("#invoiceBox").removeClass("gradInv");
            $("#invoiceBox").addClass("grad");
            $("#invEdit").removeClass("hide");
            $("#invSave").addClass("hide");
            $("#invoiceBox :input").attr("disabled", "true")

        }).error(function() {
            console.log('Something went wrong!')
        });
    } else if(invoiceFormValidate === false) {
        $('#checkoutVATErrMsg').removeClass('hide');
        $('#shipErrMsgCn').hide();
    }
});

$(document).on('click', '#invEdit', function() {
    $("#invSave").removeClass("hide");
    $("#invEdit").addClass("hide");
    $("#invoiceBox :input").removeAttr("disabled");
    $("#invoiceBox").removeClass("grad");
    $("#invoiceBox").addClass("gradInv");

});

$(document).find(".cartPage").keypress(function(event) {
    var keycode = (event.keyCode ? event.keyCode : event.which);
    if (keycode == '13') {
        if ($(".promoTxt").is(":focus")) {
            $(document).find("#sbmtCoupon").click();
        }
    }
});

// For toggle fields in requestQuote
$(document).ready(function() {
    if ($('#custom-main-wrapper .custom-total .custom-total-detail-discount ul li').length > 2) {
        $('#custom-main-wrapper .custom-total .custom-total-detail-discount ul li:nth-child(2) strong').css("border-bottom", "1px solid #e5e5e5")
    }
    $('#areaOfInteres').click(function(evt) {
        var count = 1;
        resetSelctBox();
        $("#areaOfInteres option:selected").each(function() {
            count++;
            var option = $(this);
            if (($(option).prop("selected") == true) && option.hasClass("activeSelect") && !evt.ctrlKey) {
                $(option).attr('selected', false);
                $(option).removeClass("activeSelect");
                $(option).removeClass("rmHideClass");
            } else {
                $(option).addClass("activeSelect");
                $(option).attr("selected", "selected");
            }
            // hide box code
            showHideAdditionField(option)
        });
    });

    // View More link
    $("#paymentBillingInfo #view-list-more").click(function() {
        if (navigator.userAgent.match(/chrome/i)) {
            $("#paymentBillingInfo ul.default-cnt").css("min-height", "91px");
        }
        $("#paymentBillingInfo .ndefault-cnt").show();
        $("#paymentBillingInfo #view-list-more").hide();
        $("#paymentBillingInfo #view-list-less").show();
    });
    // View Less Link
    $("#paymentBillingInfo #view-list-less").click(function() {

        $("#paymentBillingInfo .ndefault-cnt").hide();
        if (navigator.userAgent.match(/chrome/i)) {
            $("#paymentBillingInfo ul.default-cnt").css("min-height", "94px");
        }
        $("#paymentBillingInfo #view-list-more").show();
        $("#paymentBillingInfo #view-list-less").hide();
    });

    // Contact List Count
    var ContactListCount = $(".default-cnt").length + $(".ndefault-cnt").length;
    var contarrayList = [];
    var cotactListCheck = true;
    var AddLinkFlag = false;
    showHideAddLink(ContactListCount);
    var thresholdToAdd = $("#contactThreshold").val()
    // View More link
    $("#view-list-more").click(function() {
        $('.primary-cnt').css('display', 'inline-block');
        if (navigator.userAgent.match(/chrome/i)) {
            $("ul.default-cnt").css("min-height", "91px");
        }
        $(".ndefault-cnt").show();
        $("#view-list-more").hide();
        $("#view-list-less").show();
        if (ContactListCount < thresholdToAdd && $(".ndefault-cnt").is(":visible")) {
            $("#addcontact-block").show();
        } else {
            $("#addcontact-block").hide();
            $("#view-list-less").css("padding-top", "0px");
            // When 5 list without add contact link
            $("ul.ndefault-cnt:last-child").css("padding-bottom", "27px");
            if ($("#Contact-QuoteForm").val() == 'quote' && navigator.userAgent.match(/firefox/i)) {
                // When 5 list without add contact link
                $("#checkoutApproval ul.ndefault-cnt:last-child").css("padding-bottom", "28px");
            }
            if ($("#Contact-QuoteForm").val() == 'contract' && (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i))) {
                $("#contact-info-div ul.default-cnt").css("min-height", "90px");
            }
        }
    });
    // View Less Link
    $("#view-list-less").click(function() {
        $('.primary-cnt').hide();
        $(".ndefault-cnt").hide();
        if (navigator.userAgent.match(/chrome/i)) {
            $("ul.default-cnt").css("min-height", "94px");
            if ($("#Contact-QuoteForm").val() == 'quote') {
                $("ul.default-cnt").css("min-height", "93px");
            }
        }
        if ($("#Contact-QuoteForm").val() == 'contract' && (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i))) {
            $("#contact-info-div ul.default-cnt").css("min-height", "91px");
        }
        $("#view-list-more").show();
        $("#view-list-less").hide();
        if (ContactListCount == 1 && !$(".ndefault-cnt").is(":visible")) {
            $("#addcontact-block").show();
        } else {
            $("#addcontact-block").hide();
        }
    });

    function showHideAddLink(ContactListCount) {
        // Add Contact Logic implementation
        if (ContactListCount == 1) {
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i) || navigator.userAgent.match(/firefox/i)) {
                $("#contact-info-div ul.default-cnt").css("min-height", "94px");
            }
            $("#addcontact-block").show();
            $("#view-list-more").hide();
            $("#view-list-less").hide();
        }
        if ((ContactListCount == 2 || ContactListCount == 3 || ContactListCount == 4) && !$(".ndefault-cnt").is(":visible")) {
            $("#addcontact-block").hide();
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i) || navigator.userAgent.match(/firefox/i)) {
                $("#contact-info-div ul.default-cnt").css("min-height", "91px");
            }
            $("#view-list-more").show();
            $("#view-list-less").hide();
        }
        if ((ContactListCount == 2 || ContactListCount == 3 || ContactListCount == 4) && $(".ndefault-cnt").is(":visible")) {
            $("#addcontact-block").show();
            $("#view-list-more").hide();
            $("#view-list-less").show();
        }
        if (ContactListCount >= thresholdToAdd && $(".ndefault-cnt").is(":visible")) {
            console.log('4');
            $("#addcontact-block").hide();
            $("#view-list-more").hide();
            $("#view-list-less").css("padding-top", "4px");
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
                $("#view-list-less").css("padding-top", "2px");
            }
            if (navigator.userAgent.match(/chrome/i)) {
                $("#view-list-less").css("padding-top", "3px");
            }
            $("#view-list-less").show();
        }
        if (ContactListCount >= thresholdToAdd && !$(".ndefault-cnt").is(":visible")) {
            $("#addcontact-block").hide();
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i) || navigator.userAgent.match(/firefox/i)) {
                $("#contact-info-div ul.default-cnt").css("min-height", "91px");
            }
            $("#view-list-more").show();
            $("#view-list-less").hide();
        }
        // Update count in view more
        $(".cnt-countList").text($(".ndefault-cnt").length);
    }

    showHideAddLink(ContactListCount);
    // Add contact link popup open
    $('.custom-addform').click(function() {
        AddLinkFlag = true;
        $('#contact-info-div input.cntid-list').each(function() {
            contarrayList.push($(this).val());
        });
        console.log(contarrayList);
        contarrayList.forEach(function(item) {
            console.log('cnt list tile : ' + item);
            $('#overlay_contacts option[value=' + item + ']').remove();
        });
        $('body').addClass('custom-scroll')
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $('.custom-addcontact_form_cl').show();
        if ($("div[data-popup='popup-addContact']").is(':visible')) {
            AddLinkFlag = true;
        }
        console.log("Add link");
    });
    $('#overlay_contacts').on('change', function(e) {
        if (jQuery.inArray(this.value, contarrayList) != -1) {
            console.log("is in array");
            cotactListCheck = false;
            $("#cntExist").show();
        } else {
            console.log("is NOT in array");
            cotactListCheck = true;
            $("#cntExist").hide();
        }
    });

    $(".custom-addcontact_form_cl #uniform-overlay_contacts option").click(function() {
        $("#uniform-overlay_contacts option").removeClass("active");
        $(this).addClass("active");
        $("#requiredAdd").hide();
    });

    $("#add-cnt-close").click(function() {
        contarrayList = [];
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $("#uniform-overlay_contacts > span").text($("#selectdrpdown").val());
        $("#overlay_contacts").prop('selectedIndex', 0);
        $(".custom-form-container ").hide();
        if (!$("div[data-popup='popup-addContact']").is(':visible')) {
            AddLinkFlag = false;
        }
        console.log("close btn");
        e.preventDefault();
    });
    $("#add-event-block button.custom-addcontactcancel").click(function(e) {
        contarrayList = [];
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $("#uniform-overlay_contacts > span").text($("#selectdrpdown").val());
        $("#overlay_contacts").prop('selectedIndex', 0);
        $(".custom-form-container ").hide();
        if (!$("div[data-popup='popup-addContact']").is(':visible')) {
            AddLinkFlag = false;
        }
        console.log("Add cancel");
        e.preventDefault();
    });

    $(".custom-addcontact_form_cl .custom-addcontactlist").click(function(e) {
        e.preventDefault();
        var dropDownCheck = true;
        if ($('#overlay_contacts').val() == '') {
            dropDownCheck = false;
            $("#requiredAdd").show();
        } else {
            dropDownCheck = true;
            $("#requiredAdd").hide();
            if (!cotactListCheck) {
                $("#cntExist").show();
            } else {
                $("#cntExist").hide();
            }
        }
        if (dropDownCheck && cotactListCheck) {
            if ($("#Contact-QuoteForm").val() == 'contract') {
                var Inputdata = {
                    contactId : $("#overlay_contacts").val(),
                    mode : "I",
                    partnerType : "",
                    transactionNo : $("#transactionId-val").val()
                };
            } else if ($("#Contact-QuoteForm").val() == 'quote') {
                var Inputdata = {
                    contactId : $("#overlay_contacts").val(),
                    mode : "I",
                    partnerType : "",
                    transactionNo : $("#QuoteForm-Id").val()
                };
            }
            $.ajax({
                type : "POST",
                url : "../myaccount/lynxContactUpdates.jsp?service=" + $("#Contact-QuoteForm").val(),
                data : JSON.stringify(Inputdata),
                contentType : "application/json",
                dataType : "json",
                cache : false,
                beforeSend : function() {
                    if (!$(".loading").length) {
                        $('body').prepend('<div class="loading"></div>');
                    }
                    $(".loading").css("display", "block");
                    $(".loading").css("z-index", 2147483647);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483640);
                    $('.custom-addcontactlist').attr('disabled', true);
                },
                success : function(data) {
                    console.log("ajax here");
                    console.log(data);
                    $("#contact-info-div").append("<ul class='ndefault-cnt' style='display: block;'><li class='cnt-name'><p><b>" + data.details.firstName + " "
                            + data.details.lastName + "</b></p></li><li class='cnt-number'>" + data.details.phone + "</li><li class='cnt-email'>"
                            + data.details.email + "</li><input type='hidden' name='cntid-list' value=" + $('#overlay_contacts').val() + " class='cntid-list' /></ul>");
                    $('.primary-cnt').css('display', 'inline-block');
                    ContactListCount = $(".default-cnt").length + $(".ndefault-cnt").length;
                    AddLinkFlag = false;
                    console.log("Add contact success");
                    showHideAddLink(ContactListCount);
                    contarrayList = [];
                    $(".loading").css("display", "none");
                    $(".loading").css("z-index", 9999);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483647);
                    $('.custom-addcontactlist').attr('disabled', false);
                    $("#cntExist").hide();
                    $("#requiredAdd").hide();
                    $("#uniform-overlay_contacts > span").text($("#selectdrpdown").val());
                    $("#overlay_contacts").prop('selectedIndex', 0);
                    $(".custom-form-container ").hide();
                },
                error : function(x, t, m) {
                    console.log('Something went wrong!')
                    ContactListCount = $(".default-cnt").length + $(".ndefault-cnt").length;
                    AddLinkFlag = false;
                    console.log("Add contact error");
                    showHideAddLink(ContactListCount);
                    contarrayList = [];
                    $(".loading").css("display", "none");
                    $(".loading").css("z-index", 9999);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483647);
                    $('.custom-addcontactlist').attr('disabled', false);
                    $("#cntExist").hide();
                    $("#requiredAdd").hide();
                    $("#uniform-overlay_contacts > span").text($("#selectdrpdown").val());
                    $("#overlay_contacts").prop('selectedIndex', 0);
                    $(".custom-form-container ").hide();
                }
            });
        }
    });
    $("#AddContact-OverLay").hover(function() {
        console.log("hi in ");
        console.log("AddLinkFlag In : " + AddLinkFlag)
    }, function() {
        console.log("hi out");
        console.log("AddLinkFlag Out : " + AddLinkFlag)
        if (AddLinkFlag || $("div[data-popup='popup-addContact']").is(':visible')) {
            console.log("AddLinkFlag In ");
            if (ContactListCount > 1) {
                console.log("hover 1");
                $(".ndefault-cnt").show();
                $("#view-list-more").hide();
                $("#view-list-less").show();
            }
            if (ContactListCount == 1 && !$(".ndefault-cnt").is(":visible")) {
                console.log("hover2");
                $("#addcontact-block").show();
                $("#view-list-more").hide();
            }
            if (ContactListCount <= 4 && $(".ndefault-cnt").is(":visible")) {
                console.log("hover3");
                $("#addcontact-block").show();
                $("#view-list-more").hide();
            }
            if (ContactListCount >= 5 && $(".ndefault-cnt").is(":visible")) {
                console.log("hover4");
                $("#addcontact-block").hide();
                $("#view-list-less").show();
            }
        } else {
            console.log("AddLinkFlag Out ");
            $(".ndefault-cnt").hide();
            $('.primary-cnt').hide();
            $("#view-list-more").show();
            $("#view-list-less").hide();
            if (ContactListCount == 1 && !$(".ndefault-cnt").is(":visible")) {
                $("#addcontact-block").show();
                $("#view-list-more").hide();
            } else {
                $("#addcontact-block").hide();
            }
        }
    });
    $("#paymentBillingInfo #AddContact-OverLay").hover(function() {
        console.log("paymentBillingInfo hi in " + $('#payerAddressCheck').val());
    }, function() {
        console.log("paymentBillingInfo hi out" + $('#payerAddressCheck').val());
        $("#paymentBillingInfo .ndefault-cnt").hide();
        if (navigator.userAgent.match(/chrome/i)) {
            $("#paymentBillingInfo ul.default-cnt").css("min-height", "94px");
        }
        if ($('#payerAddressCheck').val() == 'true') {
            $("#paymentBillingInfo #view-list-more").hide();
            $("#paymentBillingInfo #view-list-less").hide();
        } else {
            $("#paymentBillingInfo #view-list-more").show();
            $("#paymentBillingInfo #view-list-less").hide();
        }
    });

    var UpdateContactList = $(".primary-Block").length + $(".Secondary-Block").length;
    var UpdateThreshold = 5;
    var UpdatecontarrayList = [];
    var UpdateContactListCheck = true;
    showUpdateAddLink(UpdateContactList);
    function showUpdateAddLink(UpdateContactList) {
        if (UpdateContactList < UpdateThreshold) {
            $("#Editable-Add").removeClass("fadeContactDiv");
            $("#Editable-Add").show();
            $("#nonEditableAdd").hide();
        } else {
            $("#Editable-Add").hide();
            $("#nonEditableAdd").removeClass("fadeContactDiv");
            $("#nonEditableAdd").show();
        }
    }

    $(".primaryCheck").click(function() {
        if ($(".update-contractQuoteForm").val() == 'contract') {
            var Inputdata = {
                contactId : $(this).attr('id').split('-')[1],
                mode : "S",
                partnerType : "",
                transactionNo : $("#transactionId-val").val(),
                currentPrimaryId : $(".primary-Block input.update-cntId").val(),
                editPage : true
            };
        } else if ($(".update-contractQuoteForm").val() == 'quote') {
            var Inputdata = {
                contactId : $(this).attr('id').split('-')[1],
                mode : "S",
                partnerType : "",
                transactionNo : $("#QuoteForm-Id").val(),
                currentPrimaryId : $(".primary-Block input.update-cntId").val(),
                editPage : true
            };
        }
        $.ajax({
            type : "POST",
            url : "../myaccount/lynxContactUpdates.jsp?service=" + $(".update-contractQuoteForm").val(),
            data : JSON.stringify(Inputdata),
            contentType : "application/json",
            dataType : "json",
            cache : false,
            beforeSend : function() {
                if (!$(".loading").length) {
                    $('body').prepend('<div class="loading"></div>');
                }
                $(".loading").css("display", "block");
                $('.primaryCheck').attr('disabled', true);
            },
            success : function(data) {
                $(".loading").css("display", "none");
                $('.primaryCheck').attr('disabled', false);
                location.reload();
            },
            error : function(x, t, m) {
                console.log('Something went wrong!');
                $(".loading").css("display", "none");
                $('.primaryCheck').attr('disabled', false);
                location.reload();
            }
        });
    });

    $(".removeCheck").click(function() {
        if ($(".update-contractQuoteForm").val() == 'contract') {
            var Inputdata = {
                contactId : $(this).attr('id').split('-')[1],
                mode : "D",
                partnerType : "",
                transactionNo : $("#transactionId-val").val(),
                currentPrimaryId : $(".primary-Block input.update-cntId").val(),
                editPage : true
            };
        } else if ($(".update-contractQuoteForm").val() == 'quote') {
            var Inputdata = {
                contactId : $(this).attr('id').split('-')[1],
                mode : "D",
                partnerType : "",
                transactionNo : $("#QuoteForm-Id").val(),
                currentPrimaryId : $(".primary-Block input.update-cntId").val(),
                editPage : true
            };
        }
        $.ajax({
            type : "POST",
            url : "../myaccount/lynxContactUpdates.jsp?service=" + $(".update-contractQuoteForm").val(),
            data : JSON.stringify(Inputdata),
            contentType : "application/json",
            dataType : "json",
            cache : false,
            beforeSend : function() {
                if (!$(".loading").length) {
                    $('body').prepend('<div class="loading"></div>');
                }
                $(".loading").css("display", "block");
                $('.removeCheck').attr('disabled', true);
            },
            success : function(data) {
                $(this).parent().parent().remove();
                UpdateContactList = $(".primary-Block").length + $(".Secondary-Block").length;
                showUpdateAddLink(UpdateContactList);
                $(".loading").css("display", "none");
                $('.removeCheck').attr('disabled', false);
                location.reload();
            },
            error : function(x, t, m) {
                console.log('Something went wrong!');
                $(".loading").css("display", "none");
                $('.removeCheck').attr('disabled', false);
                location.reload();
            }
        });
    });
    $('.updateAddcontact').click(function() {
        $('#ContactView input.update-cntId').each(function() {
            UpdatecontarrayList.push($(this).val());
        });
        console.log(UpdatecontarrayList);
        UpdatecontarrayList.forEach(function(item) {
            console.log('cnt list tile : ' + item);
            $('#updateOverlay_contacts option[value=' + item + ']').remove();
        });
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $('.custom-Updateaddcontact_form_cl').show();
    });
    $('#updateOverlay_contacts').on('change', function(e) {
        if (jQuery.inArray(this.value, UpdatecontarrayList) != -1) {
            console.log("is in array");
            UpdateContactListCheck = false;
            $("#cntExist").show();
        } else {
            console.log("is NOT in array");
            UpdateContactListCheck = true;
            $("#cntExist").hide();
        }
    });
    $(".custom-Updateaddcontact_form_cl #uniform-updateOverlay_contacts option").click(function() {
        $("#uniform-updateOverlay_contacts option").removeClass("active");
        $(this).addClass("active");
        $("#requiredAdd").hide();
    });
    $(".custom-Updateaddcontact_form_cl #update-cnt-close").click(function(e) {
        UpdatecontarrayList = [];
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $("#uniform-updateOverlay_contacts > span").text($("#selectdrpdown").val());
        $("#updateOverlay_contacts").prop('selectedIndex', 0);
        $(".custom-form-container ").hide();
        e.preventDefault();
    });
    $(".custom-Updateaddcontact_form_cl #update-event-block button.custom-addcontactcancel").click(function(e) {
        UpdatecontarrayList = [];
        $("#cntExist").hide();
        $("#requiredAdd").hide();
        $("#uniform-updateOverlay_contacts > span").text($("#selectdrpdown").val());
        $("#updateOverlay_contacts").prop('selectedIndex', 0);
        $(".custom-form-container ").hide();
        e.preventDefault();
    });
    $(".custom-Updateaddcontact_form_cl .custom-addcontactlist").click(function(e) {
        e.preventDefault();
        var UpdatedropDownCheck = true;
        if ($('#updateOverlay_contacts').val() == '') {
            UpdatedropDownCheck = false;
            $("#requiredAdd").show();
        } else {
            UpdatedropDownCheck = true;
            $("#requiredAdd").hide();
            if (!UpdateContactListCheck) {
                $("#cntExist").show();
            } else {
                $("#cntExist").hide();
            }
        }
        if (UpdatedropDownCheck && UpdateContactListCheck) {
            if ($(".update-contractQuoteForm").val() == 'contract') {
                var Inputdata = {
                    contactId : $("#updateOverlay_contacts").val(),
                    mode : "I",
                    partnerType : "",
                    transactionNo : $("#transactionId-val").val(),
                    editPage : true
                };
            } else if ($(".update-contractQuoteForm").val() == 'quote') {
                var Inputdata = {
                    contactId : $("#updateOverlay_contacts").val(),
                    mode : "I",
                    partnerType : "",
                    transactionNo : $("#QuoteForm-Id").val(),
                    editPage : true
                };
            }
            $.ajax({
                type : "POST",
                url : "../myaccount/lynxContactUpdates.jsp?service=" + $(".update-contractQuoteForm").val(),
                data : JSON.stringify(Inputdata),
                contentType : "application/json",
                dataType : "json",
                cache : false,
                beforeSend : function() {
                    if (!$(".loading").length) {
                        $('body').prepend('<div class="loading"></div>');
                    }
                    $(".loading").css("display", "block");
                    $(".loading").css("z-index", 2147483647);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483640);
                    $('.custom-Updateaddcontact_form_cl .custom-addcontactlist').attr('disabled', true);
                },
                success : function(data) {
                    console.log("ajax here");
                    console.log(data);
                    UpdateContactList = $(".primary-Block").length + $(".Secondary-Block").length;
                    showUpdateAddLink(UpdateContactList);
                    UpdatecontarrayList = [];
                    $(".loading").css("display", "none");
                    $(".loading").css("z-index", 9999);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483647);
                    $('.custom-Updateaddcontact_form_cl .custom-addcontactlist').attr('disabled', false);
                    $("#cntExist").hide();
                    $("#requiredAdd").hide();
                    $("#uniform-updateOverlay_contacts > span").text($("#selectdrpdown").val());
                    $("#updateOverlay_contacts").prop('selectedIndex', 0);
                    $(".custom-form-container ").hide();
                    location.reload();
                },
                error : function(x, t, m) {
                    console.log('Something went wrong!')
                    UpdateContactList = $(".primary-Block").length + $(".Secondary-Block").length;
                    showUpdateAddLink(UpdateContactList);
                    UpdatecontarrayList = [];
                    $(".loading").css("display", "none");
                    $(".loading").css("z-index", 9999);
                    $('[data-popup="popup-addContact"]').css("z-index", 2147483647);
                    $('.custom-Updateaddcontact_form_cl .custom-addcontactlist').attr('disabled', false);
                    $("#cntExist").hide();
                    $("#requiredAdd").hide();
                    $("#uniform-updateOverlay_contacts > span").text($("#selectdrpdown").val());
                    $("#updateOverlay_contacts").prop('selectedIndex', 0);
                    $(".custom-form-container ").hide();
                    location.reload();
                }
            });
        }
    });

    var affixtopheaderHeight = $(".affix-top").height();
    if (affixtopheaderHeight == null) {
        var affixheaderHeight = $(".affix").height();
        if (affixheaderHeight != null) {
            headerHeightTemp = 122 - affixheaderHeight;
            $("#bin").css("padding-top", affixheaderHeight + headerHeightTemp);
        }

    }

    $('#btnReviewOrderForQuote').click(function() {
        $('#reviewOrderBtn').click();
    });

    $("#optionsRadios1").click(function() {
        if ($("#optionsRadios1").prop('checked')) {
            $("#shiptocustomer").show();
            $("#disabled-shiptocustomer").hide();
            $("#inputShipto").removeAttr("disabled", "disabled");
           // $("#inputShipto").val('');
            $('#fetchship #inputShipto').attr('style', '');
            $('#fetchship #inputShipto').removeClass('requiredTextBox');
            $('.shipToEntryFields .mText').hide();
            $('.shipToFields > label').removeClass('requiredLabel');
            $('.shipToEntryFields #errorShipLabel').html('').hide();
            $("#shipto-remove-msg").css('display','none');
        } else {
            $("#shiptocustomer").hide();
            $("#disabled-shiptocustomer").show();
            $("#inputShipto").attr("disabled", "disabled");
            $("#inputShipto").val('');
            $('#fetchship #inputShipto').attr('style', '');
            $('#fetchship #inputShipto').removeClass('requiredTextBox');
            $('.shipToEntryFields .mText').hide();
            $('.shipToFields > label').removeClass('requiredLabel');
            $('.shipToEntryFields #errorShipLabel').html('').hide();
        }
    });

    $("#enternewlist").on('keypress', function(e) {
        if (e.keyCode == '13') {
            $("#add-catalog").trigger('click');
            return false;
        }
    });

    $("#print-cart a").on('click', function() {
        window.print();
    });
    $('#calender').change(function() {
        $('#hdate').val($('#calender').val());
    })
    $('#calender').val($('#hdate').val());

    $(document).on("click", "#maxLimit-messages.alert-dismissable .close", function(e) {
        $('#maxLimit-messages').hide();
    });
    $(document).on("click", "#error-emptyCart .alert-dismissable .close", function(e) {
        $('#error-emptyCart').hide();
    });
    $(document).on("click", "div.overlayLink", function(e) {
        $('#tooltip_' + $("#selected_partNo").val()).hide();
        $('#list_' + $("#selected_partNo").val() + ' img.upArrow').hide();
        $('#list_' + $("#selected_partNo").val() + ' img.downArrow').show();
        $('#catlogName').removeClass('requiredName');
        $('.listnameLabel').removeClass('labelrequired');
        $('#error-msg').hide();
        $('.nospecialLabel').show();
        $('#catlogName').val('');
        if (window.innerHeight > $("#myCatalogModal #dropdown-wrapper").outerHeight(true) + 74) {
            var parentWindowHeight = window.innerHeight - 60;
            var overLayHeight = $("#myCatalogModal #dropdown-wrapper").outerHeight(true) + 74;
            var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
            if (navigator.userAgent.match(/msie/i)) {
                calcOverlayTop = calcOverlayTop + 27;
            }
            $("#myCatalogModal .modal-content").css("top", calcOverlayTop + 'px');
        }
    });
    $(document).on("click", "div#createListLink", function(e) {
        $('#catlogName').removeClass('requiredName');
        $('.listnameLabel').removeClass('labelrequired');
        $('#error-msg').hide();
        $('.nospecialLabel').show();
        $('#catlogName').val('');
        if (window.innerHeight > $("#myCatalogModal #dropdown-wrapper").outerHeight(true) + 74) {
            var parentWindowHeight = window.innerHeight - 60;
            var overLayHeight = $("#myCatalogModal #dropdown-wrapper").outerHeight(true) + 74;
            var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
            $("#myCatalogModal .modal-content").css("top", calcOverlayTop + 'px');
        }
    });

    $(".catalogTooltip").hover(function() {
    }, function() {
        $(".catalogTooltip").hide();
        $('#list_' + $("#selected_partNo").val() + ' img.upArrow').hide();
        $('#list_' + $("#selected_partNo").val() + ' img.downArrow').show();
    });
    $(document).on('mouseenter', '.addToFavoritesDropDown', function (event) { 
    	}).on('mouseleave', '.addToFavoritesDropDown', function (event) {   
    		$(".addToFavoritesDropDown").hide();
    	});
    $("#editShippingAddressLink").click(function() {
        $('#uniform-customDropdown2').css("width", "200px");
        $('#uniform-customDropdown2 span').css("width", "150px");
        $('#shippingAddressSection,#editShippingAddressLink').hide();
        $('#editShipAddressSec').show();
    });
    $("#editBillingAddressLink").click(function() {
        $('#uniform-customDropdown1').css("width", "200px");
        $('#uniform-customDropdown1 span').css("width", "150px");
        $('#billingAddressSection,#editBillingAddressLink').hide();
        $('#editBillAddressSec').show();
    });
    if($(document).find('#mainContainer').hasClass('salesContractMYA')){
	$("#pdfChinaOrderDownloadForm").submit();
    }
});

$(document).ready(function() {
    $("#attriblockview").hide();
    $(".viewless").hide();
    $(".showblock").click(function() {
        $(this).next("#attriblockview").slideToggle(500);
        $(this).find(".viewless, .viewmore").toggle();
    });
	
	//Enable ATG to monitor My Invoice views/downloads performance
	$('.top-nav ul li.vat,.top-nav ul li.invoice,#custom-main-wrapper-expand #myOrderWrapper #myOrderMainTabs .ui-tabs-nav li#salesInvoiceTab').click(function() {
		$.ajax({
			type: "POST",
			url: '/rest/model/com/agilent/commerce/LogInvoicePageViews/logInvoiceViews',
			success: function(result) {
                console.log('Enable ATG to monitor My Invoice views/downloads performance triggered!');
            },
			error: function() {
				console.log('Something went wrong on Enable ATG to monitor My Invoice views/downloads performance!');
			}
		});
	})	
	
	//add Classs on myfav page
	if($('#mainContainer > .container').hasClass('myOrderStatuss')){
		$('body').addClass('printclass')
	}	
	//Print Country name on myfav page
	$('#custom-main-wrapper-expand .myOrderStatuss .pay-date-stamp.country span:last-child').text($.cookie('CountryName'))

	//Print Today date on myfav page
	const d = new Date()
	const year = d.getFullYear()
	var date = d.getDate()
	date.toString().length == 1 ? date = '0' + date : date
	const months = {
		0: 'Jan',
		1: 'Feb',
		2: 'Mar',
		3: 'Apr',
		4: 'May',
		5: 'Jun',
		6: 'Jul',
		7: 'Aug',
		8: 'Sep',
		9: 'Oct',
		10: 'Nov',
		11: 'Dec'
	}
	const monthIndex = d.getMonth()
	const monthName = months[monthIndex]
	$('#custom-main-wrapper-expand .myOrderStatuss .pay-date-stamp.date span:last-child').text(date + " " + monthName + " " + year)	
});

$(document).ready(function() {
    $("#lmsattriblockview").show();
    $(".viewless").show();
    $(".lmsshowblock").click(function() {
        $(this).next("#lmsattriblockview").slideToggle(500);
        $(this).find(".viewless, .viewmore").toggle();
    });
	//Disable chrome auto populate email field for checkout and redeem quote pages
	/*$('#payerInvoiceEmail,#addCCEmail,#ccEmailtoSAP').focus(function(){
		$(this).attr('autocomplete','nope')
	})*/
});
$(document).ready(function() {
    var tooltipheight = $('.info-tooltip').height();
    $(".info-icon").hover(function() {
        if (tooltipheight <= 23) {
            $(".tooltiptext").css("bottom", "28px");
        }
    });

    // Listen to click event on the submit button
    $('#lmsBtnPOSubmitOrder').click(function(e) {
        e.preventDefault();
        var ponum = $("#po").val();
        if (ponum == "") {
            $("#po").addClass("invalid");
            return false;
        } else {
            $("#po").removeClass("invalid");
        }
    });
	
	function truncateTextByHeight(container, height, ender) {  
	if(container.origText == "" || container.innerHTML.trim() == "")
		return;
	if(!container.origText)
		getWords(container);
	var words = container.words;
	container.innerHTML = words[0];
	var currHeight = container.offsetHeight;
	if(currHeight > height)
		return;
	if(!ender)
		ender = "";
	var prevText = words[0];
	var currHeight = container.offsetHeight;
	if(currHeight > height)
		return;
	for(var i=1; i < words.length; i++) {
		var currText = prevText + words[i];
		container.innerHTML = currText + ender;
		var currHeight = container.offsetHeight;
		if(currHeight > height) {
			container.innerHTML = prevText.trim() + ender;
			return;
		}
		prevText = currText;
	}
	if(i == words.length)
		container.innerHTML = container.origText;
}
	
function getWords(container) {   
	var tmpContainer = document.createElement('div');
	tmpContainer.style.width = 0;
	tmpContainer.style.position = 'absolute';
	tmpContainer.style.top = '-9999em';
	tmpContainer.style.left = '-9999em';
	document.body.appendChild(tmpContainer);
	container.origText = container.innerHTML.trim();
	var chars = container.origText.split("");
	var words = [];
	var word = chars[0];
	tmpContainer.innerHTML = chars[0];
	var prevHeight = tmpContainer.offsetHeight;
	for(var i=1; i < chars.length; i++) {
		tmpContainer.innerHTML += chars[i];
		var currHeight = tmpContainer.offsetHeight;
		if(currHeight > prevHeight) {
			prevHeight = currHeight;
			words.push(word);
			word = chars[i];
		} else {
			word += chars[i];
		}
	}
	words.push(word);
	container.words = words;
	document.body.removeChild(tmpContainer);
}

function truncateprodItems() {
$('#custom-main-wrapper-expand .myFavTableSection .custom-detail-table tr td:nth-child(2) p').each(function() {
		var desc = $(this);
		if(typeof desc.get(0) != 'undefined')
		truncateTextByHeight(desc.get(0), 20, "...")
	});
}
truncateprodItems()
$(window).resize(truncateprodItems);	
});
$('#lmsBtnPOSubmitOrder').click(function(e) {
    if ($(this).attr('id') == "lmsBtnPOSubmitOrder" && $("#lmsagreeCheckbox").length && !$("#lmsagreeCheckbox").is(":checked")) {
        e.preventDefault();
        $("#lmsCheckboxModal").modal();
    }
});

function showHideAdditionField(option) {
    if (($(option).attr("id") == "osr") || ($(option).attr("id") == "ospm")) {
        if ($("#osr").hasClass("activeSelect") == true || $("#ospm").hasClass("activeSelect") == true) {
            $(".alternate,.bttc,.modelNo,.serialNo").removeClass("hide");
        } else if ($(option).hasClass("rmHideClass")) {
            $(".alternate,.bttc,.modelNo,.serialNo").removeClass("hide");
            $(option).removeClass("rmHideClass");
        } else {
            $(".alternate,.bttc,.modelNo,.serialNo").addClass("hide");
            $(option).addClass("rmHideClass");
        }
    }
}

function resetSelctBox() {
    $("#areaOfInteres option:not(:selected)").each(function() {
        $(this).removeClass("rmHideClass");
        $(this).removeClass("activeSelect");
        showHideAdditionField(this);
    });
}

/* for email validation on reviewandplaceorder */
$("#invoiceEmailId div.checker span").on("click", function() {
    className = $(this).attr("class");
    if (className == "checked") {
        $("input[type='checkbox']", this).attr("checked", "checked");
        $("input#payerInvoiceEmail").removeAttr("disabled").addClass("email");
    } else {
        $("input[type='checkbox']", this).removeAttr("checked");
        $("input#payerInvoiceEmail").attr("disabled", "disabled").removeClass("email");
        $(".checkoutShippingBilling input#payerInvoiceEmail").removeAttr("disabled");
    }
});

var clsname = $(document).find("#invoiceEmailId div.checker span").attr("class");
if (clsname == "checked") {
    $("#invoiceEmailId div.checker span input[type='checkbox']").attr("checked", "checked");
    $("input#payerInvoiceEmail").removeAttr("disabled").addClass("email");
} else {
    $("#invoiceEmailId div.checker span input[type='checkbox']").removeAttr("checked");
    $("input#payerInvoiceEmail").attr("disabled", "disabled").removeClass("email");
    $(".checkoutShippingBilling input#payerInvoiceEmail").removeAttr("disabled");
}
// For restricting special characters in Company VAT number
$('#vatexemptbox').keyup(function() {
	$(this).val($(this).val().replace(/[^a-z0-9-]/gi,''));
});	
// For restricting all special characters except % and ' in packing list for china user
$('#informationCNSP').keyup(function() {
    var yourInput = $(this).val();
    re = /[`~!@#$^&*()_|+\=?;:",.<>\{\}\[\]\\]/gi;
    var isSplChar = re.test(yourInput);
    if (isSplChar) {
        var no_spl_char = yourInput.replace(/[`~!@#$^&*()_|+\=?;:",.<>\{\}\[\]\\]/gi, '');
        $(this).val(no_spl_char);
    }
    if ($(this).val() && $(this).hasClass("invalid")) {
        $(this).removeClass("invalid");
        $(".errorMessages").hide();
    }
});
// For restricting special characters except '/- in review order Chinese page
$('#attentionCNSP,#buildRoomNoCNSP,#phoneNumberCNSP,#quoteNo,#customerName1,#companyTaxCode1,#invaddress,#bankName1,#bankAccount1,#customerName2,#city2,#shippingAdrress2,#postCode2,#contactorName2,#contactorPhNum2,#attentionSP,#buildingRoomSP,#telephoneSP').keyup(function() {
    var yourInput = $(this).val();
    re = /[`~!@#$%^&*()_|+\=?;:",.<>\{\}\[\]\\]/gi;
    var isSplChar = re.test(yourInput);
    if (isSplChar) {
        var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\=?;:",.<>\{\}\[\]\\]/gi, '');
        $(this).val(no_spl_char);
    }
    if ($(this).val() && $(this).hasClass("invalid")) {
        $(this).removeClass("invalid");
        $(".errorMessages").hide();
    }
});
$('#SpecialInstructions1,.redeemQuoteNew #splInst,.largeCheckout #splInst,.largeFileOrderReviewPage #SpecialInstructions').keyup(function() {
    var yourInput = $(this).val();
    re = /[`~!#$%^&*()|+\=?;"<>\{\}\[\]\\]/gi;
    var isSplChar = re.test(yourInput);
    if (isSplChar) {
        var no_spl_char = yourInput.replace(/[`~!#$%^&*()|+\=?;"<>\{\}\[\]\\]/gi, '');
        $(this).val(no_spl_char);
    }
    if ($(this).val() && $(this).hasClass("invalid")) {
        $(this).removeClass("invalid");
        $(".errorMessages").hide();
    }
});
// Restrict max length to 500 if the country is china and user enter Chinese char
var maxlen = $(".splInsTextarea").attr('maxlength')
$(".splInsTextarea").on('keyup',function(){   
	var sentence= $(this).val();
	var regexpNonLatin = /[^\u0000-\u007F]/.test(sentence);
	if(regexpNonLatin == true){
	 $(".splInsTextarea").attr('maxlength',500)
	 sentencetrim = sentence.substring(0, 500);
	 $(this).val(sentencetrim)
	}else{
	$(".splInsTextarea").attr('maxlength',maxlen)
	}
});
// For restricting special characters except /- in review order PO number
$('#po,#fspPONumberInput').keyup(function() {
    var yourInput = $(this).val();
    re = /[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\]/gi;
    var isSplChar = re.test(yourInput);
    if (isSplChar) {
        var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\]/gi, '');
        $(this).val(no_spl_char);
    }
    if ($(this).val() && $(this).hasClass("invalid")) {
        $(this).removeClass("invalid");
        $(".errorMessages").hide();
    }
});

$(window).load(function() {
    // For removing duplicate print button on order confirmation
    $(".checkStatusBox").find(".printOrder:eq(1)").remove();

    if ($('form#checkoutform2')) {
        var chkoutBtnUI = $(".promoBot button[btnId='btnCheckout1']").clone();
    } 
	else  if ($('form#punchCheckoutId').length > 0) {
        var chkoutBtnUI = $(".promoBot button[btn-id='punchCheckout']").clone();
      //APP-24723 Changes for Chekout button dissappearing for punchout user  
    }else {
        var chkoutBtnUI = $(".promoBot button").clone();
    }
	//APP-24723 Changes for Chekout button dissappearing for punchout user
    //$(chkoutBtnUI).replaceAll(".chkOutArea button");
    LSCA.buttonClick();
    $(document).on("click", "#chk", function() {
        $(".chkOutArea button").click();
    });

    $(document).on('click', '#addRemFav', function(e) {
        e.preventDefault();
        if ($(this).hasClass("addFavTxt")) {
            $(this).removeClass("addFavTxt").addClass("removeFavTextLink");
        }
        if ($(this).hasClass("removeFavTextLink")) {
            $(this).addClass("addFavTxt").removeClass("removeFavTextLink");
        }
        $(this).parents('td').find('a.favorite')[0].click();
    });

    $(document).on("click", "#adShpLink", function() {
        $('.advShip').click();
    });

    $(document).find("button[type=reset]").click(function() {
        $(this).parents("form").find(".form-control").each(function() {
            $(this).attr("value", "")
        });
    });
});
if (navigator.appVersion.indexOf("MSIE") > -1) {
    $("form input").keypress(function(e) {
        if (e.which === 13) {
            $("#login").click();
        }
    });
}

$(window).load(function() {
    if ($(document).find("form").hasClass("disFrmReq")) {
        if ($(document).find("#reqRet").length) {
            $(document).find(".salutationLI input[type='radio']").each(function() {
                if ($("#titleDefault").val() == $(this).val()) {
                    $(this).attr("checked", "checked");
                }
            });
            var selecteJobFunText = "";
            $("#primJobFunSel option").each(function() {
                if ($("#primJobFun").val() == $(this).val()) {
                    $(this).attr("selected", true);
                    selecteJobFunText = $(this).text();
                }
            });
            var selectedContactmethod = "";
            $("#contactMethod option").each(function() {
                if ($("#contactMethod").val() == $(this).val()) {
                    $(this).attr("selected", true);
                    selectedContactmethod = $(this).text();
                }
            });
            setTimeout(function() {
                $("#uniform-primJobFunSel span").text(selecteJobFunText);
                $("#uniform-contactMethod span").text(selectedContactmethod);
            }, 1000);

            $("#dakoCountry option").each(function() {
                $(this).removeAttr("selected");
                if ($("#countryCode").val() == $(this).val()) {
                    $(this).attr("selected", true);
                    $(this).parents().find("#dakoCountry").parent().find("span").text($(this).text());
                }
            });
            var prd = $("#prodAreas").val();
            prd = prd.slice(1, -1);
            var prdNew = prd.split(", ");
            for (var i = 0; i < prdNew.length; i++) {
                $("#areaOfInteres option").each(function() {
                    if (prdNew[i] == $(this).val()) {
                        $(this).attr("selected", true);
                    }
                });
            }
            var ind = $("#indAreas").val();
            ind = ind.slice(1, -1);
            var indNew = ind.split(", ");
            for (var i = 0; i < indNew.length; i++) {
                $("#industryArea option").each(function() {
                    if (indNew[i] == $(this).val()) {
                        $(this).attr("selected", true);
                    }
                });
            }
            setTimeout(function() {
                $("form[name='requestQuote'] input, form[name='requestQuote'] select").attr('disabled', true);
            }, 1000);
        }
    }
    $("#areaOfInteres option:selected").each(function() {
        if (($(this).attr("id") == "osr") || ($(this).attr("id") == "ospm")) {
            $(this).click();
        }
    });

    // Added for request quote update details page
    var OnSelectReasonData = $("#nonActionable").val();
    nonActionableReason(OnSelectReasonData);
    $(document).find("#btn-continue").on('click', function(e) {
        if (($('#nonVerAddSize').val() > 90) && ($('#nonVerAddSize').val() < 100)) {
            $('#shipaddrFirsterror').css('display', 'block');
        }
        if ($('#nonVerAddSize').val() >= 100) {
            $('#shipaddrSecerror').css('display', 'block');
            $('#shipNewAddress').css('pointer-events', 'none');
        }
        var applyShippingBorder;
        if ($('#shippingLeft').height() > $('#shippingRight').height()) {
            applyShippingBorder = $('#shippingLeft').height() - 15;
        } else {
            applyShippingBorder = $('#shippingRight').height();
        }
        if (applyShippingBorder > 230) {
            $('#shippingRight .borderLeft').css('height', applyShippingBorder + 'px');
        }
    });
    $('input[type="radio"]').click(function() {
        if ($(this).attr('id') == 'partialRadio') {
            $(document).find('#btnAdvancedShippingOptions').click();
        }
        if ($(this).attr('id') == 'partialRadio' && $("#distributorUser").val() == 1) {
        	LSCA.loadingSpinner.showLoading();
			$('div#chekoutItemSection').css('min-height','300px');
        	$('div#chekoutItemSection').html(''); 
			if(jQuery("#isPPSOrder").val()!= "true"){
                urlValue= "/common/includes/ajax/checkout-Product-DistUser.jsp";
            }
            else{
                urlValue= "/common/includes/ajax/checkout-Product-DistUserPPS.jsp";
            }
        	$.ajax({type:"POST",url:urlValue,dataType:"html"})
        	.done(function(msg){
        		$("div#chekoutItemSection").html(msg);
        		 if($('#immediateOption').val() == 'true'){
    		        $('tr.custom-immediate').show();
    		    }
        		LSCA.loadingSpinner.hideLoading();
				additionalReqToggle();
				hplcCheckBoxToggle();
				checkoutIVDWidth();
        	}).error(function(){
        		console.log('Something went wrong!');
        		LSCA.loadingSpinner.hideLoading();
        	});
        }
        if ($(this).attr('id') == 'consolidateRadio') {
        	LSCA.loadingSpinner.showLoading();
			$('div#chekoutItemSection').css('min-height','300px');
        	$('div#chekoutItemSection').html(''); 
			if(jQuery("#isPPSOrder").val()!= "true"){
                urlVal= "/common/checkout/checkout-product-listing.jsp";
            }
            else{
                urlVal= "/common/checkout/checkout-product-listingPPS.jsp";
            }
        	$.ajax({type:"POST",url:urlVal,dataType:"html"})
        	.done(function(msg){
        		$("div#chekoutItemSection").html(msg);
        		LSCA.loadingSpinner.hideLoading();
				additionalReqToggle();
				hplcCheckBoxToggle();
				checkoutIVDWidth();
        	}).error(function(){
        		console.log('Something went wrong!');
        		LSCA.loadingSpinner.hideLoading();
        	});
        }
    });
});

// For request quote update details page for displaying reasons on radiobutton selection
function nonActionableReason(radiobutton) {
    if (radiobutton == "Yes") {
        $("#reasonContainer").empty();
        $("#reasonDrpDwn").removeClass('hide');
        $("#crmRfrnceId").removeClass('hide');
        $("#reasonContainer").html($("#crmYesReason").clone(true));
        $("#reasonContainer #crmYesReasonSel").uniform();
        updateReasonData('crmYesReasonSel');
    } else if (radiobutton == "No") {
        $("#reasonContainer").empty();
        $("#reasonDrpDwn").removeClass('hide');
        $("#crmRfrnceId").addClass('hide');
        $("#reasonContainer").html($("#crmNoReason").clone(true));
        $("#reasonContainer #crmNoReasonSel").uniform();
        updateReasonData('crmNoReasonSel');
    } else if (radiobutton == "Awaiting validation") {
        $("#reasonContainer").empty();
        $("#reasonDrpDwn").removeClass('hide');
        $("#crmRfrnceId").addClass('hide');
        $("#reasonContainer").html($("#crmAwaitingvalidationReason").clone(true));
        $("#reasonContainer #crmAwaitingvalidationReasonSel").uniform();
        updateReasonData('crmAwaitingvalidationReasonSel');
    } else if (radiobutton == "None") {
        $("#reasonDrpDwn,#crmRfrnceId").addClass('hide');
        $("#reasonContainer").empty();
    }
}

function ChangeCase(elem) {
    elem.value = elem.value.toUpperCase();
}

// Added for Google Analytics
function datalayerpush(lbl) {
    if ((lbl) == 'bzEmail') {
        lbl = 'Email Address';
    } else if ((lbl) == 'cnfEmail') {
        lbl = 'Confirm Email';
    } else if ((lbl) == 'pwd') {
        lbl = 'Password';
    } else if ((lbl) == 'cnfPwd') {
        lbl = 'Confirm Password';
    } else if ((lbl) == 'familyName') {
        lbl = 'Family Name';
    } else if ((lbl) == 'givenName') {
        lbl = 'Given Name';
    } else if ((lbl) == 'loginName') {
        lbl = 'Login Name';
    } else if ((lbl) == 'telephone') {
        lbl = 'Telephone';
    } else if ((lbl) == 'companyName') {
        lbl = 'Company Name';
    } else if ((lbl) == 'zip') {
        lbl = 'Shipping Zip/Postal Code';
    } else if ((lbl) == 'address') {
        lbl = 'Shipping Address';
    } else if ((lbl) == 'city') {
        lbl = 'Shipping City';
    } else if ((lbl) == 'shipcountry') {
        lbl = 'Shipping City';
    } else if ((lbl) == 'zp') {
        lbl = 'Billing Zip/Postal Code';
    } else if ((lbl) == 'addr') {
        lbl = 'Billing Address';
    } else if ((lbl) == 'cty') {
        lbl = 'Billing City';
    } else if ((lbl) == 'cntry') {
        lbl = 'Billing Country';
    }
    dataLayer.push({
        'event' : 'eventTracker',
        'eventCat' : 'Registration Form',
        'eventAct' : 'Error',
        'eventLbl' : lbl,
        'eventVal' : 0
    });
}
function addtocartClick(currencyCode, name, id, price, brand, category, variant, quantity, cdProdNameStepId) {
    if (!isEmpty(price)) {
        var lastCommaIndex = 1;
        var n = price.lastIndexOf(",");
        if (n > 0) {
            lastCommaIndex = price.length - n;
        }
        price = price.replace(/\D/g, '');
        // This condition is to check the prices such as 1,800,123 and it be 1800123.00 in GA
        // For others: such as 1,800,12 it should be 1800.12 in GA
        if (lastCommaIndex != 4) {
            price = price / Math.pow(10, 2);
        }
        price = parseFloat(price).toFixed(2);
    } else if (price == null) {
        price = "NA";
    }
    dataLayer.push({
        'event' : 'eventTracker',
        'eventCat' : 'eCommerce',
        'eventAct' : 'Add to Cart',
        'eventLbl' : name,
        'eventVal' : 0,
        'ecommerce' : {
            'currencyCode' : currencyCode,
            'add' : {
                'products' : [ {
                    'name' : name,
                    'id' : id,
                    'price' : price,
                    'brand' : brand,
                    'category' : category,
                    'variant' : variant,
                    'quantity' : quantity,
                    'dimension14' : cdProdNameStepId
                } ]
            }
        },
        'eventCallback' : function() {
            dataLayer.push({
                'ecommerce' : undefined
            });
        }
    });
}
function addtocartClickGA(currencyCode, name, id, price, brand, category, variant, quantity, cdProdNameStepId) {
    if (!isEmpty(price)) {
        var lastCommaIndex = 1;
        var n = price.lastIndexOf(",");
        if (n > 0) {
            lastCommaIndex = price.length - n;
        }
        price = price.replace(/\D/g, '');
        // This condition is to check the prices such as 1,800,123 and it be 1800123.00 in GA
        // For others: such as 1,800,12 it should be 1800.12 in GA
        if (lastCommaIndex != 4) {
            price = price / Math.pow(10, 2);
        }
        price = parseFloat(price).toFixed(2);
    } else if (price == null) {
        price = "NA";
    }
    dataLayer.push({
        'event' : 'eventTracker',
        'eventCat' : 'eCommerce',
        'eventAct' : 'Add to Cart',
        'eventLbl' : name,
        'eventVal' : 0,
        'ecommerce' : {
            'currencyCode' : currencyCode,
            'add' : {
                'products' : [ {
                    'name' : name,
                    'id' : id,
                    'price' : price,
                    'brand' : brand,
                    'category' : category,
                    'variant' : variant,
                    'quantity' : quantity,
                    'dimension14' : cdProdNameStepId
                } ]
            }
        }
    });
}
function isEmpty(inputStr) {
    var EMPTYREGEX = /^\s*$/;
    if (inputStr == null || EMPTYREGEX.test(inputStr)) {
        return true;
    } else {
        return false;
    }
}

function copyfromHidden() {
    $("#shipBuildingNo").val($("#hiddenbuildNo").text());
    $("#shipAttnno").val($("#hiddenShipAttn").text());
    if (document.getElementById('contactNum')) {
        $("#contactNum").val($("#hiddenPhoneNo").text());
    }
}

$("#myOrderMainTabs").tabs({
    classes : {
        "ui-tabs" : "",
        "ui-tabs-nav" : "",
        "ui-tabs-tab" : "",
        "ui-tabs-panel" : ""
    }
}).removeClass('ui-widget');

$("#myOrderMainTabs, #myOrderMainTabs *").removeClass('ui-widget ui-widget-content ui-widget-header ui-tabs-panel');

function updateLMSQuantity(partNumber, lmsQuantityStatic) {
    var quantity = $("#lmsQty").val();
    var lmsURLParam = $("#lmsURLParam").val();
    var successURL = "/common/checkout/lmsOrderReviewPage.jsp?isLMSUser=true&lmspartNo=" + partNumber + "&lmsQty=" + quantity + "&lmsurl=" + lmsURLParam;
    $("#updateSuccessURL").val(successURL);
    $("#updateQuantity").click();
    $("#lmsBtnPOSubmitOrder").prop('disabled', true);
    $("#lmsBtnCCSubmitOrder").prop('disabled', true);
}

$(document).ready(function() {
	if($('head link[rel="shortcut icon"]').length == 0) {
		$('head').append('<link rel="shortcut icon" href="/common/images/favicon.ico" />');
	}
    $("#lmsQty").on('keyup', function() {
        var quantity = $("#lmsQty").val();
        if (/^[0-9]+$/.test(quantity) && ((quantity > 0) && (quantity <= 999999))) {
            if ($(".lmsUpdateRef").hasClass('hide')) {
                $(".lmsUpdateRef").removeClass('hide');
            }
            if ($(this).hasClass('invalid')) {
                $(this).removeClass('invalid');
            }
            $(".errorMessages").hide();
        } else if (/^[0-9]+$/.test(quantity) && quantity == 0) {
            $('#lmsQty').val(1);
            if ($(".lmsUpdateRef").hasClass('hide')) {
                $(".lmsUpdateRef").removeClass('hide');
            }
            if ($(this).hasClass('invalid')) {
                $(this).removeClass('invalid');
            }
        } else {
            $(this).addClass("invalid");
            $(".lmsUpdateRef").addClass('hide');
            LSCA.GlobalValidate.showErrorLMS('', $(this).attr('title'));
        }
    });
});

var toggleOnce = false, billingActive = false, shippingActive = false, existingBillingOption = $("#customDropdown1").val(), existingShippingOption = $("#customDropdown2").val();

if (navigator.userAgent.indexOf('Safari') > -1 && navigator.userAgent.indexOf('Chrome') < 0) {
    toggleOnce = true;
}

$("#customDropdown1").click(function() {
    if (billingActive || toggleOnce) {
        if (existingBillingOption && existingBillingOption === $(this).val()) {
            $('#billingAddressSection').show();
            $('#editBillingAddressLink').show();
            $('#editBillAddressSec').hide();
        }
        existingBillingOption = $(this).val();
    }
    billingActive = !billingActive;
});

$("#customDropdown2").click(function() {
    if (shippingActive || toggleOnce) {
        if (existingShippingOption && existingShippingOption === $(this).val()) {
            $('#shippingAddressSection').show();
            $('#editShippingAddressLink').show();
            $('#editShipAddressSec').hide();
        }
        existingShippingOption = $(this).val();
    }
    shippingActive = !shippingActive;
});

$("#customPrintSubmit").click(function() {
    $("#pdfQuoteDownloadForm").submit();
});

$(document).ready(function() {
    if ((navigator.platform.toUpperCase().indexOf('MAC') != -1) && navigator.userAgent.match(/chrome/i)) {
        $("body").addClass("mac");
    }
	if (navigator.platform.toUpperCase().indexOf('MAC') != -1) {
        $("body").addClass("mac");
    }
    $('#largeFileNonEdit textarea.DisabledText,#largeFileNonEdit input.DisabledText').attr("readonly", "true");
    $("#largeFileNonEdit input#payerInvoiceEmail").removeAttr("disabled");
    $("#SpecialInstructions").removeAttr("readonly");
    $("#largeFileNonEdit input#quoteNo").removeAttr("readonly");
    if ($('#collapseTwo #shippingverifiedList li').length >= 10) {
        if (navigator.userAgent.match(/firefox/i)) {
            $('#collapseTwo #shippingverifiedList').css({
                height : '306px',
                overflow : 'hidden'
            });
        }
        if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
            $('#collapseTwo #shippingverifiedList').css({
                height : '307px',
                overflow : 'hidden'
            });
        }
        if (navigator.userAgent.match(/chrome/i)) {
            $('#collapseTwo #shippingverifiedList').css({
                height : '315px',
                overflow : 'hidden'
            });
        }
        if ((navigator.userAgent.indexOf('Mac OS X') != -1) && navigator.userAgent.match(/chrome/i)) {
            $('#collapseTwo #shippingverifiedList').css({
                height : '315px',
                overflow : 'hidden',
                'padding-left' : '1px'
            });
        }
        if ($('html').hasClass('Mac') && $('html').hasClass('Safari')) {
            $('#collapseTwo #shippingverifiedList').css({
                height : '270px',
                overflow : 'hidden',
                'padding-left' : '1px'
            });
        }
        $('.shipaddrmore').css('display', 'block');
    }

    if ($('.pmList.accordion-section-title').length == 0) {
        $('.monthTooltip').css('left', '7.5%');
         if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
            $('.monthTooltip').css('left', '7.9%');
         }
    }

    var defaultmnlist = [];
    $('.custom-group .custom-section-content .custom-info .monthList input.itemPrevMainVal').each(function() {
        if ($(this).val() != '') {
            defaultmnlist.push($(this).val());
        }
    });
    var defaultreplacemonthIdVal = defaultmnlist.join();
    defaultreplacemonthIdVal = defaultreplacemonthIdVal.replace(/,/g, ";");
    $('#selectIdMonth').val(defaultreplacemonthIdVal);
	$('#Modal1 #selectIdMonth,#Modal2 #selectIdMonth').val(defaultreplacemonthIdVal);
    var quoteDateVal = $('#contractDate').val();
    if (quoteDateVal != undefined && quoteDateVal != null) {
        quoteDateVal = quoteDateVal.split('-')[1];
        quoteDateVal = parseInt(quoteDateVal);
        var nextMonth = quoteDateVal + 1;
        if (quoteDateVal == 12) {
            nextMonth = 1;
        }
        console.log(quoteDateVal + '--' + nextMonth);
    }
    $('.monthListView li#' + quoteDateVal + '.monthListItem').remove();
    $('.monthListView li#' + nextMonth + '.monthListItem').remove();

    $(".monthList").on("click", function() {
        var selectedMonth = $(this).attr('id').split('_')[1];
        if ($(this).prev().prev().attr('id') == undefined) {
            $('#tooltip_' + selectedMonth + '.monthTooltip').css({
                'left' : '7.5%',
                'margin-top' : '7px'
            });
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
                $('#tooltip_' + selectedMonth + '.monthTooltip').css({
                    'left' : '7.9%'
                });
            }
        }
        $('div.monthTooltip:not(#tooltip_' + selectedMonth + ')').hide();
        $('#tooltip_' + selectedMonth).toggle();
    });

    $("img.updownArrow").on("click", function() {
        var selectedMonth = $(this).prev().attr('id').split('_')[1];
        if ($(this).prev().prev().prev().attr('id') == undefined) {
            $('#tooltip_' + selectedMonth + '.monthTooltip').css({
                'left' : '7.5%',
                'margin-top' : '7px'
            });
            if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
                 $('#tooltip_' + selectedMonth + '.monthTooltip').css({
                    'left' : '7.9%'
                });
            }
        }
        $('div.monthTooltip:not(#tooltip_' + selectedMonth + ')').hide();
        $('#tooltip_' + selectedMonth).toggle();
    });

    $("li.monthListItem").on("click", function() {
        console.log($(this));
        var selectedMonthList = $(this).parent().parent().attr('id').split('_')[1];
        $('#month_' + selectedMonthList + ' .selectMonthList').hide();
        $('#month_' + selectedMonthList + ' .scheduleMonthList span.monthText').text($(this).text());
        if($(this).parent().parent().prev().prev().hasClass('nonPM')){
            $('#month_' + selectedMonthList + ' .scheduleMonthList').html($('#selectPMLabel').val()+" <span class='monthText'></span>");
            $('#month_' + selectedMonthList + ' .scheduleMonthList span.monthText').text($(this).text());
        }
        $('#month_' + selectedMonthList + ' input.itemPrevMainVal').val(selectedMonthList + ':' + $(this).attr('id'));
        $('#month_' + selectedMonthList + ' .scheduleMonthList').show();
        $('#tooltip_' + selectedMonthList).hide();

        $('#selectIdMonth').val('');
		$('#Modal1 #selectIdMonth,#Modal2 #selectIdMonth').val('');
        var mnlist = [];
        $('.custom-group .custom-section-content .custom-info .monthList input.itemPrevMainVal').each(function() {
            if ($(this).val() != '') {
                mnlist.push($(this).val());
            }
        });
        var replacemonthIdVal = mnlist.join();
        replacemonthIdVal = replacemonthIdVal.replace(/,/g, ";");
        $('#selectIdMonth').val(replacemonthIdVal);
		$('#Modal1 #selectIdMonth,#Modal2 #selectIdMonth').val(replacemonthIdVal);
    });

    $(".monthTooltip").mouseleave(function() {
        $(".monthTooltip").hide();
    });
    /* verfied China State List */
    $("#list_VerfiedState").on("click", function() {
        var stateListPosition = $('#list_VerfiedState').position().left;
        $('#select_state_cart').css('left',stateListPosition+'px');
        $('#select_state_shopping_cart').css('left',stateListPosition+'px');
         $('#select_state_cart').toggle();
         $('#select_state_shopping_cart').toggle();
         $('#list_VerfiedState').find(".upArrow, .downArrow").toggle();
     });
     $("#select_state_cart").hover(function() {
    }, function() {
        $("#select_state_cart").hide();
        $('#list_VerfiedState img.upArrow').hide();
        $('#list_VerfiedState img.downArrow').show();
    });
     
     $("#select_state_shopping_cart").hover(function() {
     }, function() {
         $("#select_state_shopping_cart").hide();
         $('#list_VerfiedState img.upArrow').hide();
         $('#list_VerfiedState img.downArrow').show();
     });
    var mouse_is_inside;
    $('#list_VerfiedState,#select_state_cart').hover(function() {
        mouse_is_inside = true;
    }, function() {
        mouse_is_inside = false;
    });
    $('#list_VerfiedState,#select_state_shopping_cart').hover(function() {
        mouse_is_inside = true;
    }, function() {
        mouse_is_inside = false;
    });
    $(document).bind('mousedown', function() {
        if (mouse_is_inside == 'undefined') {
            return false;
        }
        if (!mouse_is_inside) {
            $("#select_state_cart").hide();
            $("#select_state_shopping_cart").hide();
            $('#list_VerfiedState img.upArrow').hide();
            $('#list_VerfiedState img.downArrow').show();
        }
    });

    $("#select_state_cart li.stateListItem").click(function(e) {
        e.preventDefault();
        var currentURL = window.location.href;
        var selectedStateId = $(this).attr('id');
        currentURL = LSCA.updateQueryStringParameter(currentURL, 'stateId', selectedStateId);
        window.location.href = currentURL;
    });
	
	var serviceContractSortingAsc=false;
	$('#sortingBlock').css('overflow', 'hidden');
	$('#sortingBlock').css('width', '820px');
	$(".serviceSort").click(function() {
		if(serviceContractSortingAsc)
		{
			$('.custom-left-group.desc').show();
			$('.custom-left-group.asc').hide();
			$(".serviceSort").addClass("bpSortDscSortBlue");
			$(".serviceSort").removeClass("bpSortAscSortBlue");
			serviceContractSortingAsc=false;
		}
		else
		{
			$('.custom-left-group.desc').hide();
			$('.custom-left-group.asc').show();
			$(".serviceSort").addClass("bpSortAscSortBlue");
			$(".serviceSort").removeClass("bpSortDscSortBlue");
			serviceContractSortingAsc=true;
		}
});
	//UEU Number Edit Start
	if(LSCA.getQueryParam('reviewShipEdit') == 'true' && LSCA.getQueryParam('UEUnumber') !='') {
		$('#inputUEUNumber').val(LSCA.getQueryParam('UEUnumber'));
		$('#ueuNumberApplySpan').show();
		$("#ueuNumberApply").trigger('click');
	}
	//UEU Number Edit End
	
	$('#promoCodeApply').click(function(){
		$('.discountLabel').removeClass('requiredLabel');
		$('#dynamicDiscountId').removeClass('requiredTextBox');
		$('#dynamicDiscountId').next().hide();
		$('#dynamicDiscountId').val('');
		setTimeout(function() {
			if (window.innerHeight > 225) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = 225;
				var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
				$("#promotionDiscountPopup .modal-content").css("top", calcOverlayTop + 'px');
			}
		}, 200);
});
	$(document).on('click', '#promotionApplyDiscount', function(e) {
		var discountValue = $('#promotionDiscountForm #dynamicDiscountId').val();

		if (discountValue != '') {
			$('#promotionDiscountForm .discountLabel').removeClass('requiredLabel');
			$('#promotionDiscountForm #dynamicDiscountId').removeClass('requiredTextBox');
			$('#promotionDiscountForm #dynamicDiscountId').next().hide();
		} else {
			$('#promotionDiscountForm .discountLabel').addClass('requiredLabel');
			$('#promotionDiscountForm #dynamicDiscountId').addClass('requiredTextBox');
			$('#promotionDiscountForm #dynamicDiscountId').next().css('display','inline-block');
		}
	});
	 $(document).on('click', '#cancelDiscount', function(e) {
		$('#promotionDiscountForm #dynamicDiscountId').val('');
		$('#dynamicDiscountClose').trigger('click');
	});
});

/* Chaina vat attribute validation Start */
function validateNormalVAT() {
    $('#invAddressTelStr').hide();
    $('#invAddress2BankStr').hide();
    $('#invBankAccStr').hide();
    $('#special_vat_span1').hide();
    $('#special_vat_span2').hide();
    $('#special_vat_span3').hide();
    $('#invAddressTel').removeClass('required');
    $('#invAddress2Bank').removeClass('required');
    $('#invBankAcc').removeClass('required');
    $('#invaddress').removeClass("required requiredTextBox");
    $('#bankName1').removeClass("required requiredTextBox");
    $('#bankAccount1').removeClass("required requiredTextBox");
    $('#bankAccount1').prev('.fieldLabel').removeClass('requiredLabel');
    $('#bankName1').prev('.fieldLabel').removeClass('requiredLabel');
    $('#invaddress').prev('.fieldLabel').removeClass('requiredLabel');
    $('#invAddressTel').css('border-color', '#cccccc');
    $('#invAddress2Bank').css('border-color', '#cccccc');
    $('#invBankAcc').css('border-color', '#cccccc');
}

function validateSpecialVAT() {
    $('#invAddressTelStr').show();
    $('#invAddress2BankStr').show();
    $('#invBankAccStr').show();
    $('#invAddressTel').addClass('required');
    $('#invAddress2Bank').addClass('required');
    $('#invBankAcc').addClass('required');
    $('#invaddress').addClass('required');
    $('#bankName1').addClass('required');
    $('#bankAccount1').addClass('required');
}

function onPageLoadValidateVAT() {
    var invoiceNormalVAT = $("#invoiceNormalVAT").prop("checked");
    var invoiceSpecialVAT = $("#invoiceSpecialVAT").prop("checked");
    if (invoiceNormalVAT === true) {
        validateNormalVAT();
    } else if (invoiceSpecialVAT === true) {
        validateSpecialVAT();
    }
}

function validateInvoiceVAT() {
    var invoiceFormValidate = LSCA.GlobalValidate.init({
        target : '#invoiceForm'
    });
    if (invoiceFormValidate === true) {
        $('#checkoutVATErrMsg').addClass('hide');
        $('#sbmtOrder').click();
        return true;
    } else if (invoiceFormValidate === false) {
        $('#checkoutVATErrMsg').removeClass('hide');
        $('#shipErrMsgCn').hide();
        return false;
    }
}
/* China vat attribute validation End */

function isNotEmptyObj(obj) {
    if (obj !== undefined && obj !== null && !$.isEmptyObject(obj)) {
        return true;
    } else {
        return false;
    }
}

function fetchErrorMessage(response, errorCode) {
    var errorMessage = "";
    if (isNotEmptyObj(response) && isNotEmptyObj(response.errorMessages)) {
        var errorMessages = response.errorMessages;
        for (var i = 0; i < errorMessages.length; i++) {
            if (!isEmpty(errorMessages[i].errorCode) && errorMessages[i].errorCode == errorCode) {
                errorMessage = errorMessages[i].message;
                break;
            }
        }
    }
    return errorMessage;
}

function numberOnly(thisElement) {
	if(!isNotEmptyObj(thisElement)){
		return;
	}
    var element = thisElement;
    var regex = /[^0-9]/gi;
    element.value = element.value.replace(regex, "");
}

$(window).load(function() {
	var optionText;
	var lnt;
	var deOtion;
	if ($("input[name='pay']:checked").val() == 'fsp') {
		$("#me").attr('checked',false);
		$("#fspOption").trigger('click');
		$("#fspOption").attr('checked',true);
		$(".custom-display-container-fsp").removeClass('displayNone');		
		$(".custom-display-container").addClass('displayNone');
		$(".custom-full-div-me").addClass('displayNone');
	}

	deOtion = $("#fspPlan option:selected").text();
	$('#customOpt').text(deOtion);
	$('#customOpt').on('click',function(){
		$('#fspPlan').toggle();
		lnt = $('#fspPlan').find("option").length;
		if((lnt < 5) && (lnt >= 1) ){
			$('#fspPlan').attr("size",lnt);
		}else{
			$('#fspPlan').attr("size","5");
		}
	});
	$('#fspPlan').on('change',function(){
		optionText = $("#fspPlan option:selected").text();
		deOtion = $("#fspPlan option:selected").text();
		$('#customOpt').text(optionText);
		$('#fspPlan').css("display","none");
		if(optionText != "Other"){
			$('#fsp').attr("disabled","disabled");
			$('#fsp').removeClass("required");
			$('#fspAccountNumberInput').prev().hide();
			$('#fspAccountNumberInput').attr("disabled","disabled");
			$('#fspAccountNumberInput').removeClass("required requiredTextBox");
			$('#fsp').val('');
			$('#fspAccountNumberInput').val('');
			$('#fspPONumberInput').val('');
		}else{
			$('#fsp').removeAttr("disabled");
			$('#fsp').addClass("required");
			$('#fspAccountNumberInput').prev().show();
			$('#fspAccountNumberInput').removeAttr("disabled");
			$('#fspAccountNumberInput').addClass("required");
		}
	});
	
	$("#orderIDNew").keypress(function(event) {
		var keycode = (event.keyCode ? event.keyCode : event.which);
		if (keycode == '13') {
			if ($("#orderIDNew").is(":focus")) {
				$(document).find(".searchOrder #btnSubmit").click();
			}
		}
}); 
	$(".cxSitePrepCustom li").click(function(){
		console.log($(this).attr('id'));
		if($(this).attr('id') == 'orderDetailsTab') {
			$('#home').show();
			$('#SDSCOFA').removeClass('active in');
			$('#siteprep,#SDSCOFA').hide();
		}
		if($(this).attr('id') == 'sitePreprationTab') {
			$('#siteprep').show();
			$('#SDSCOFA').removeClass('active in');
			$('#home,#SDSCOFA').hide();
		}
		if($(this).attr('id') == 'SDSTab') {
			$('#SDSCOFA').addClass('active in');
			$('#SDSCOFA').show();
			$('#siteprep,#home').hide();
				
		}
	});
	$(document).ready(function() {
		if($('#myAgilentUser').val()=='true'){
			$('#salesOrders,#webOrderResult,#custom-main-wrapper-expand #myOrderWrapper .ui-tabs-nav').hide();
			$('#myOrderWrapper,#salesInvoice').show();
		}
		$(document).on('click','#list_Invoice', function(){
				$(this).toggleClass("listactivearrow");
		 });
        $(document).on('click','#custom-edit-pop', function(){
        	$( "#changeshippingAddressModal .modal-header button" ).trigger( "click" );
        });
		var stockArray = [];
		if ($('#redeemQuoteOrderForm table tbody tr').length > 0) {
			$('#redeemQuoteOrderForm table tbody tr').each(function(i, v) {
				if($(this).attr('data-partNoId') != '' && $(this).attr('data-partNoId') != undefined) {
					//console.log($(this).attr('data-partNoId').split('_')[1])
					stockArray.push($(this).attr('data-partNoId').split('_')[1]);
				}
			});
			//console.log(stockArray.join());
			var stockArrayList = stockArray.join();
			
			
			$.ajax({
                type : "POST",
                url : '/common/prdDetailSrchJSON.jsp?withQty=true&catalogIds='+stockArrayList,
                contentType : "application/json",
                dataType : "json",
                cache : false,
                beforeSend : function() {
					//$('#redeemQuoteOrderForm table tbody tr:not(.Lastrow,.desginIDRow-Add,.designIDRow) td:nth-child(2)').append('<div class="stockavail tbl-loading"></div>');
					$('#redeemQuoteOrderForm table tbody tr td div.stockavail').addClass('tbl-loading');
                },
                success : function(data) {  
                    
					$.each(data, function(k, v) {
						var kPartNo = k.replace('|','_');
						//$('tr#trow_'+kPartNo+' td:nth-child(2)').html($('tr#trow_'+k+' td:nth-child(2)').html());
						$('tr#trow_'+kPartNo+' td div.stockavail').text(v.stockAvailability);
						//$('tr#trow_'+kPartNo+' td div.stockavail').addClass('inStockColor 0');
						var stockMsg;
						if(v.stockAvailability != '' && (v.stockAvailabilityDate != '' && v.stockAvailabilityDate != undefined)) {
							stockMsg = v.stockAvailability.split(':');
							stockMsg = stockMsg[0]+'<span class="separator">:</span> <span class="estimated-ship">'+stockMsg[1]+' '+v.stockAvailabilityDate+'</span>';
							//stockMsg = v.stockAvailability+': <span class="estimated-ship">'+v.stockAvailabilityDate+'</span>';
							$('tr#trow_'+kPartNo+' td div.stockavail').addClass('inStockColor');
							if(v.stockAvailabilityDate == "eMethod"){
								$('tr#trow_'+kPartNo+' td div.stockavail').removeClass('inStockColor');
								$('tr#trow_'+kPartNo+' td div.stockavail').addClass('eMethodColor');
							}
						}
						else if(v.stockAvailability == '' && (v.stockAvailabilityDate != '' && v.stockAvailabilityDate != undefined)) {
							stockMsg = '<span class="estimated-ship">'+v.stockAvailabilityDate+'</span>';
							$('tr#trow_'+kPartNo+' td div.stockavail').addClass('inStockColor');
						}
						else {
							if(v.stockAvailability != '' && v.stockAvailability != undefined) {
								if(v.stockAvailability.indexOf('madeToOrder') != -1) {
									stockMsg = v.stockAvailability.split('|')[1];
									$('tr#trow_'+kPartNo+' td div.stockavail').addClass('madeToOrderColor');
								}
								else if(v.stockAvailability.indexOf('OutOfStock') != -1) {
									stockMsg = v.stockAvailability.split('|')[1];
									$('tr#trow_'+kPartNo+' td div.stockavail').addClass('OutOfStock');
								}
								else {
									//stockMsg = v.stockAvailability;
									if(v.stockAvailability.split(':').length > 1) {
										stockMsg = v.stockAvailability.split(':');
										stockMsg = stockMsg[0]+': <span class="estimated-ship">'+stockMsg[1]+'</span>';
									}
									else {
										stockMsg = v.stockAvailability;
									}
									$('tr#trow_'+kPartNo+' td div.stockavail').addClass('inStockColor');
								}
							}
						}
						$('tr#trow_'+kPartNo+' td div.stockavail').html(stockMsg);
						
						$('tr#trow_'+kPartNo+' td div.stockavail').removeClass('tbl-loading');
					});
					setTimeout(function() {
						 $('tr td div.stockavail').removeClass('tbl-loading');
					  }, 200);
                },
                error : function(x, t, m) {
					$('#redeemQuoteOrderForm table tbody tr td div.stockavail').removeClass('tbl-loading');
                    console.log('Something went wrong!');
                }
            });
			
		}
		var redeemstockArray = [];
		if ($('.redeemQuoteNew .skyblueTable:first-child tbody tr').length > 0) {
			$('.redeemQuoteNew .skyblueTable:first-child tbody tr').each(function(i, v) {
				if($(this).attr('data-partNoId') != '' && $(this).attr('data-partNoId') != undefined) {
					//console.log('data-partNoId:'+ $(this).attr('data-partNoId').split('_')[1])
					redeemstockArray.push($(this).attr('data-partNoId').split('_')[1]);
				}
			});
			//console.log('redeemstockArray.join:' +redeemstockArray.join());
			var stockArrayList = redeemstockArray.join();
			$.ajax({
                type : "POST",
                url : '/common/prdDetailSrchJSON.jsp?withQty=true&catalogIds='+stockArrayList,
                contentType : "application/json",
                dataType : "json",
                cache : false,
                beforeSend : function() {
					$('.redeemQuoteNew .skyblueTable:first-child tbody tr td div.stockavail').addClass('tbl-loading');
                },
                success : function(data) {                      
					$.each(data, function(k, v) {
						var kPartNo = k.replace('|','_');
						$('tr#trow_'+kPartNo+' td div.stockavail p').html('<span>'+v.stockAvailability+'</span>');
						var stockMsg;						
						if(v.prodExpDate != '' && v.prodExpDate != undefined){
							kPartNoo = kPartNo;
							kPartNoo = kPartNo.split('SHELF -');
							kPartNoo = kPartNoo[0]+kPartNoo[1];
							$('tr#trow_'+kPartNoo+' .pull-left .product-inner .item-expiration').text(v.prodExpDate);
						}
						if(v.stockAvailability != '' && (v.stockAvailabilityDate != '' && v.stockAvailabilityDate != undefined)) {
							stockMsg = v.stockAvailability.split(':');
							stockMsg = '<span>'+stockMsg[0]+'</span> – '+stockMsg[1]+'<b>'+v.stockAvailabilityDate+'</b>';
							$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('custom-instock');
							if(v.stockAvailabilityDate == "eMethod"){
								$('tr#trow_'+kPartNo+' td div.stockavail p').removeClass('custom-instock');
								$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('eMethodColor');
							}
						}
						else if(v.stockAvailability == '' && (v.stockAvailabilityDate != '' && v.stockAvailabilityDate != undefined)) {
							stockMsg = '<b>'+v.stockAvailabilityDate+'</b>';
							$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('custom-instock');
						}
						else {
							if(v.stockAvailability != '' && v.stockAvailability != undefined) {
								if(v.stockAvailability.indexOf('madeToOrder') != -1) {
									stockMsg = v.stockAvailability.split('|')[1];
									$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('madeToOrder');
								}
								else if(v.stockAvailability.indexOf('OutOfStock') != -1) {
									stockMsg = v.stockAvailability.split('|')[1];
									$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('OutOfStock');
								}
								else {
									if(v.stockAvailability.split(':').length > 1) {
										stockMsg = v.stockAvailability.split(':');
										stockMsg = '<span>'+stockMsg[0]+'</span> – '+stockMsg[1];
									}
									else {
										stockMsg = v.stockAvailability;
									}
									$('tr#trow_'+kPartNo+' td div.stockavail p').addClass('custom-instock');
								}
							}
						}
						$('tr#trow_'+kPartNo+' td div.stockavail p').html(stockMsg);						
						$('tr#trow_'+kPartNo+' td div.stockavail').removeClass('tbl-loading');
					});
					setTimeout(function() {
						 $('tr td div.stockavail').removeClass('tbl-loading');
					  }, 200);
                },
                error : function(x, t, m) {
					$('.redeemQuoteNew .skyblueTable:first-child tbody tr td div.stockavail').removeClass('tbl-loading');
                    console.log('Something went wrong!');
                }
            });
			
		}		
		
		
    }); 
	
	function sdsData() {
		LSCA.loadingSpinner.showLoading();
		$.ajax({
		type : "GET",
		url : '/rest/model/com/agilent/commerce/FetchOrderDetails/getBatchLotDetails?orderId='+$('#sdsOrderId').val()+'&batchLotRequired=true&atg-rest-output=json&src='+$('#srcValue').val(),
		cache : false,
		success: function(data) {
			/*if(data.getBatchLotDetails.partNumberList) {
				$("#sdscofsTableCustom #SDSCOFA,ul.cxSitePrepCustom #SDSTab").show();
			}
			else {
				$("#sdscofsTableCustom #SDSCOFA,ul.cxSitePrepCustom #SDSTab").hide();              
			}*/
			LSCA.loadingSpinner.hideLoading();
			var data1 = data.getBatchLotDetails.partNumberList;
			var tableData = "";
			var len = data1.length;
			var ulleft='';
			var ulDataLeft='';
			if(len == 0) {
				$('#sdsNoRecord').show();
				$('#sdscofsTableCustom').hide();
			}
			else {
				$("li").removeClass("SdsCofaTab hide");
				for (var i = 0; i < len; i++) {
					tblrow = '<tr id='+ data1[i].partNumber + '>';
					if(data1[i].pnpURL == ''){
					  tblrow += ' <div>' + data1[i].partNumber + '</div>';  
					}
					else
					{
					   tblrow += ' <div><a href=../..'+encodeURI(data1[i].pnpURL) +' target=_blank>' + data1[i].partNumber + '</a></div>'; 
					} 
					tblrow += ' <td>' + data1[i].description + '</td>';
					if(data1[i].sdsResultList[0] == '' || data1[i].sdsResultList[0] == undefined) {
						tblrow += ' <td>Pending...</td>';
					}
					else {
						tblrow += ' <td><a href='+encodeURI(data1[i].sdsResultList[0].url.replace(/[\[\]']+/g,'')) +' target=_blank>' + data1[i].sdsResultList[0].content + '</a></td>';
					}
					
						for (var j = 0; j < data1[i].cofResultList.length; j++) {
							console.log(i  +'-------------' + j)
							if(data1[i].cofResultList[j].content != undefined) {
											ulleft = '<li><a href='+encodeURI(data1[i].cofResultList[j].url.replace(/[\[\]']+/g,'')) +' target=_blank>' + data1[i].cofResultList[j].content + '</a></li>';
							}
							ulDataLeft += ulleft;
							ulleft ="";
						}
					tblrow += ' <td><ul>' + ulDataLeft + '</ul></td>';
					tblrow += '</tr>';
					tableData += tblrow;
					ulDataLeft = "";
				}
				$('#sdsNoRecord').hide();
			}
			$('#sdscofsTableCustom tbody').html(tableData);
			
		},
		error: function() {
			console.log('data');
			
		}
		});
    }
	function sdsNewData() {
		LSCA.loadingSpinner.showLoading();
		$.ajax({
		type : "GET",
		url : '/rest/model/com/agilent/commerce/FetchOrderDetails/getBatchLotDetails?orderId='+$('#sdsNewOrderId').val()+'&batchLotRequired=true&atg-rest-output=json',
		cache : false,
		success: function(data) {
			
			LSCA.loadingSpinner.hideLoading();
			var data1 = data.getBatchLotDetails.partNumberList;
			var tableData = "";
			var len = data1.length;
			var ulleft='';
			var ulDataLeft='';
			if(len == 0) {
				$('#sdsNoRecordErrorMessage').show();
				$('.sdscofsDivCustom').hide();
			}
			else {
				$("li").removeClass("SdsCofaTab hide");
				for (var i = 0; i < len; i++) {
					tblrow = '<div class="agt-table-row" id='+ data1[i].partNumber + '>';
					if(data1[i].pnpURL == ''){
					  tblrow += ' <div>' + data1[i].partNumber + '</div>';  
					}
					else
					{
					   tblrow += ' <div><a href=../..'+encodeURI(data1[i].pnpURL) +' target=_blank>' + data1[i].partNumber + '</a></div>'; 
					} 
					tblrow += ' <div>' + data1[i].description + '</div>';
					tblrow += ' <div></div>';
					if(data1[i].sdsResultList[0] == '' || data1[i].sdsResultList[0] == undefined) {
						tblrow += ' <div id="pending_hover_outer">Pending...<span id="pending_hover">Safety Data Sheet is not available at this time. If you have any questions, please reach out to <a href="https://www.agilent.com/en/support">Technical Support</a>.</span></div>';
					}
					else {
						tblrow += ' <div><a href='+encodeURI(data1[i].sdsResultList[0].url.replace(/[\[\]']+/g,'')) +' target=_blank>' + data1[i].sdsResultList[0].content + '</a></div>';
					}
					
						for (var j = 0; j < data1[i].cofResultList.length; j++) {
							if(data1[i].cofResultList[j].content != undefined) {
											ulleft = '<div><a href='+encodeURI(data1[i].cofResultList[j].url.replace(/[\[\]']+/g,'')) +' target=_blank>' + data1[i].cofResultList[j].content + '</a></div>';
							}
							ulDataLeft += ulleft;
							ulleft ="";
						}
					tblrow += ' <div>' + ulDataLeft + '</div>';
					tblrow += '</div>';
					tableData += tblrow;
					ulDataLeft = "";
				}
				$('#sdsNoRecordErrorMessage').hide();
			}
			$('.sdscofsDivCustom div.agt-table-body').html(tableData);
			
		},
		error: function() {
			console.log('data');
			
		}
		});
    }
	if($('#sdsOrderId').val() != undefined) {
		if($( "#mainContainer" ).hasClass( "sapOrderOld")){
			sdsData();
		}
	}
	if($('#sdsNewOrderId').val() != undefined) {
		sdsNewData();
	}
}); 



//VAT tracking

function getVatTrack() {
	var currTrackIDD = parseInt(window.currTrackID);
	$("#trackingTable tbody").empty('');
	$(".custom-tracking-head").find("span#custom-currt-vatID").remove();
	LSCA.loadingSpinner.showLoading();
	$.ajax({
	type : "GET",
	url : '/common/vatShippingDetailJson.jsp?tn='+ parseInt(window.currTrackID) +'',
	dataType: "json",
	success: function(data) {
		var data = data.zvattracking.item;
		var tableData;
		if (data) {
			LSCA.loadingSpinner.hideLoading();
			var len = data.length;
			if (len > 0) {
				$(".custom-tracking-head").append("<span id='custom-currt-vatID'>"+data[0].trackingnumber+'</span>');
				$('#trackingTable').show();
				$('#trackingTable .msg-stnd').hide();
				for (var i = 0; i < len; i++) {
					tblrow = '<tr>';
					tblrow += ' <td>' + data[i].datetime + '</td>';
					tblrow += ' <td>' + data[i].location + '</td>';
					tblrow += ' <td>' + data[i].expressstatus + '</td>';
					tblrow += '</tr>';
					tableData += tblrow;
				}
				$('#trackingTable > tbody').html(tableData);
			}
			else {
				$('#trackingTable').hide();
				$('#trackingTable .msg-stnd').show();
		}
		}else{
			   console.log('data');
			   LSCA.loadingSpinner.hideLoading();
			}
		
	},
	error: function() {
		console.log('data');
		
	}
	});
}

$(document).on('click', '.modalTrackList', function(e) {
		window.currTrackID = $(this).text();
	    $("#custom-currt-vatID").val(window.currTrackID);
		getVatTrack();

});


$( document ).ready(function() {
	var bannerMsgVal=jQuery(".shopping-cart-spa #cartMainContainer .banner-msg span").text().trim();
	if(bannerMsgVal!=""){
		jQuery(".shopping-cart-spa #cartMainContainer .banner-msg").addClass("showbanner");
	}
	var lntpay = $('ul.custom-payment-mode li').length;
	if(lntpay > 2){
	$('.custom-payment-mode').addClass('custom-flexi-pay-mode');
	}
	
	$('input[type=radio][name=pOrder]').change(function() {
		if ((!$(document).find('#mainContainer').hasClass('redeemQuote')) && (!$(document).find('#mainContainer').hasClass('redeemQuoteNew')) && (!$(document).find('#mainContainer').hasClass('largeCheckout'))) {
			if (this.value == 'purchaseOrder') {
				var radioValue = this.value;
				radioClick(radioValue)
				 $('.custom-payment-mode .msg-stnd.info-msg').hide();
			  //  LSCA.billShipHandler.radiosubmit();
			}
			else if (this.value == 'creditCard') {
				var radioValue = this.value;
				radioClick(radioValue)
				$('.custom-payment-mode .msg-stnd.info-msg').show();
			   // LSCA.billShipHandler.radiosubmit();
			}
			else if (this.value == 'flexibleSpendPlan') {
				var radioValue = this.value;
				radioClick(radioValue)
				 $('.custom-payment-mode .msg-stnd.info-msg').hide();
			   // LSCA.billShipHandler.radiosubmit();
			}
		}	
	});
	
	
	function radioClick(radioValue_val) {
		$.ajax({
			type: "GET",
			url:'/rest/model/com/agilent/commerce/EditBillingAddressActor/editPaymentMethod?atg-rest-output=true&newPayMethod=' + radioValue_val,
			contentType: "application/json;charset=UTF-8",
			dataType: "json",
			timeout: 30000,
			success: function(result) { }
		});
	}
	
	function alignMsgStnd(){
        var alignMessageStnd = function() {
            var el = $(this).children('span');
            var divHeight = el.outerHeight()
            var lineHeight = parseInt(el.css('line-height'));
            var lines = divHeight / lineHeight;
            $(this).css('align-items', lines<=2 ? 'center' : 'flex-start');
        }
		$('.message-stnd').each(alignMessageStnd);  
		$('.msg-stnd').each(alignMessageStnd);
	}
	
	alignMsgStnd();
	$(window).resize(alignMsgStnd);
	
});	



$( document ).ready(function() {

	$("#selectshipaddress").click(function(){
		$("#custom-change-shipAddress .fullBillingAddress").hide();
		$(".custom-after-changeshipAddress").show();
	});

});

$( document ).ready(function() {
    $(".pageme tbody tr td:nth-child(3)").each(function(index) {
		var descriptionContent= $(this).text().length
		if(descriptionContent >= 130){
			var str = $(this)
			str.text(str.text().substr(0,130));
		}
    });

	$("#selectbilladdr").click(function(){
		$("#custom-change-BillAddress .fullBillingAddress").hide();
		$(".custom-after-changebillAddress").show();
	});
	
	if($('#custom-main-wrapper #custom-quate-details .custom-id').outerHeight() <= 60){
		$('#custom-main-wrapper #custom-quate-details .custom-quote-down').css('margin-top','37px');
		$('#custom-main-wrapper #custom-quate-details .bnr-container').css('margin-top','35px');
	}
	if($('#custom-main-wrapper #custom-pay-step3 .custom-id').outerHeight() <= 60){
		$('#custom-main-wrapper #custom-pay-step3 .custom-quote-down').css('margin-top','37px');
		$('#custom-main-wrapper #custom-pay-step3 .bnr-container').css('margin-top','35px');
	}
	
	$("#vatCheck").click(function(){
        var checkVatStatus;
        $('.vatexemptwrap').toggleClass('hide');    
        $('#vatexemptbox').val('');
        var quoteTotal = $('#QuotationTotal').val();
        var quoteTax = $('#TotalTax').val();
        var quoteShippingCharge = $('#TotalShippingCharge').val();
       	/*var quotecursymbol = $('#subTotalVal').text().trim();
		quotecursymbol = quotecursymbol.substring(0,1)*/
		var currencyLocale = $("#currencyLocale").val();
		
        if($('#vatCheck').prop('checked') == true)
        {
            checkVatStatus = true;
            $("#vatCheck").attr('data-target','#vatBillingModal');
           /* if($('#mainContainer').hasClass('redeemQuoteNew')){
	            total = quoteTotal - quoteTax;
				total = total.toFixed(2)
				taxAmount = '0.00';
				$('#taxVal').text(quotecursymbol+taxAmount);
				$('.totalVatValue').text(quotecursymbol+total);
				$('#quoteTotalAmountBean').val(total);
				$('#quoteTotalTaxBean').val(taxAmount);
				$('#QuoteTotalTax').val(taxAmount);
            }*/
        }
        else {
            checkVatStatus = false;
            $("#vatCheck").attr('data-target','');
	    /*    if($('#mainContainer').hasClass('redeemQuoteNew')){
				$('#taxVal').text(quotecursymbol+quoteTax);
				$('.totalVatValue').text(quotecursymbol+quoteTotal);  
				$('#quoteTotalAmountBean').val(quoteTotal);
				$('#quoteTotalTaxBean').val(quoteTax);
				$('#QuoteTotalTax').val(quoteTax);
            }*/
        }
        setTimeout(function() {
            if (window.innerHeight > 290) {
                var parentWindowHeight = window.innerHeight;
                var overLayHeight = 290;
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                $("#vatBillingModal .modal-content").css("top", calcOverlayTop + 'px');
            }
        }, 200);
        var apivaturl;
             if($('#mainContainer').hasClass('redeemQuoteNew')){           
            apivaturl ='/common/myaccount/fetchVatExempt.jsp?vatExempt='+checkVatStatus+"&currencyLocale="+currencyLocale+'&atg-rest-output=json';
        }else if($('#mainContainer').hasClass('checkoutShippingBilling')){
            apivaturl = '/rest/model/com/agilent/commerce/VATExempt/applyVATExempt?isVatExempt='+checkVatStatus+'&atg-rest-output=json';
		}	
            LSCA.loadingSpinner.showLoading(); 
         if($('#mainContainer').hasClass('redeemQuoteNew')){	
		    	$.ajax({
	            type : "POST",
	            url : apivaturl,
	            cache : false,
				data :{
					"quoteTotal" : quoteTotal,
					"quoteShippingCharge" : quoteShippingCharge,
					"quoteTax" : quoteTax
				},
			      success: function(data) {				
	                LSCA.loadingSpinner.hideLoading();	              
						var dataa = JSON.parse(data);
	                	$('#order-summary-table .taxVatValue').text(dataa.QuoteTax);
	   	                $('#order-summary-table .totalVatValue').text(dataa.QuoteTotalAmount);
						$('#quoteTotalAmountBean').val(dataa.QuoteTotalAmount);
						$("#totalTaxValue").val(dataa.TotalTaxDouble);
	            },
	            error: function() {
	                console.log('error');
	            }
	        });
		 
          } else {		 
	        $.ajax({
	            type : "GET",
	            url : apivaturl,
	            cache : false,
			      success: function(data) {				
	                LSCA.loadingSpinner.hideLoading();	              
	                	  $('#order-summary-table .taxVatValue').text(data.PriceDetails.Tax);
	  	                  $('#order-summary-table .totalVatValue').text(data.PriceDetails.Total);
	            },
	            error: function() {
	                console.log('error');
	            }
	        }); 
			}
	    });

	/*$('.checkoutShippingBilling .redQuote input:radio').on('change', function() {
		if ($(".checkoutShippingBilling .redQuote input[name='pOrder']:checked").val() == 'purchaseOrder') {
			$(".checkoutShippingBilling .redQuote input#po").show();
			$(".checkoutShippingBilling .redQuote input#po").removeAttr("disabled").addClass("required");
		}
		if ($(".checkoutShippingBilling .redQuote input[name='pOrder']:checked").val() == 'creditCard') {
			$(".checkoutShippingBilling .redQuote input#po").val('');	
			$(".checkoutShippingBilling .redQuote input#po").hide();
			$(".checkoutShippingBilling .redQuote input#po").attr("disabled", "disabled");
			$(".checkoutShippingBilling .redQuote input#po").removeClass("required");
			$('.checkoutShippingBilling .redQuote input#po').removeClass('requiredTextBox');
			$('.checkoutShippingBilling .redQuote #purchaseOrderLabel').removeClass('requiredLabel');
			$('.checkoutShippingBilling .redQuote input#po').next().next().hide();
		}
	});*/
	
	$(document).on("click", "#downloadChinaOrderPdf", function(e) {
		$("#pdfChinaOrderDownloadForm").submit();
	});
	function removeParam(key, sourceURL) {
		var rtn = sourceURL.split("?")[0],
			param,
			params_arr = [],
			queryString = (sourceURL.indexOf("?") !== -1) ? sourceURL.split("?")[1] : "";
		if (queryString !== "") {
			params_arr = queryString.split("&");
			for (var i = params_arr.length - 1; i >= 0; i -= 1) {
				param = params_arr[i].split("=")[0];
				if (param === key) {
					params_arr.splice(i, 1);
				}
			}
			rtn = rtn + "?" + params_arr.join("&");
		}
		return rtn;
	}
	if($(".sapOrderDetailsPage #interimURL").val() != '' && $(".sapOrderDetailsPage #interimURL").val() != undefined) {
		var originalURL = $(".sapOrderDetailsPage #interimURL").val();
		var alteredURL = removeParam("oeid", originalURL);
	    window.location.href= alteredURL;
	}
	jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").prev().addClass("remove-border");
	jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").each(function(){		
		var colspanVal = jQuery(this).prev().find("td").length;
		jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row td").attr("colspan",colspanVal);
	});
	$(document).on("click", ".favoriteList li", function(e) {
		$(".favoriteList li").removeClass('active');
		jQuery("#mycatlogList ul li").removeClass("hide-pointer");
		$(this).addClass('active');
		$(".favListHeading").html($(".favoriteList ul li.active").text());
		$("#myFavTableList,.errorMessagesSection").show();
		$(".myFavContentSection #noItems").hide();
		$("#partNumberinput").removeClass('requiredTextBox');   
		$("#partNoEmpty").hide();
	});
	$(document).on("click", "#createNewFavList", function(e) {
	
		//$("#createNewFavList").addClass('opened');
		$(this).toggleClass("opened");
		if($(this).hasClass("opened")) {
			$("#favListName").val('');
		    $("#favListName").removeClass('requiredTextBox'); 
			$(".createListPopup").css('padding-bottom','20px');
		    $("#favNameEmpty,.splchar-error") .hide();
			$(".createListPopup").show();
			$( "#favListName" ).focus();
		}
		else{
			$(".createListPopup").hide();
		}
		
	});
	$('body').click(function(evt){    
		//console.log($(evt.target.id));
		//console.log($(evt.target.class));
		if(evt.target.className != 'createListPopup' && evt.target.id != 'createNewFavList' && evt.target.id != 'favLabel' && evt.target.id != 'favListName' && evt.target.id != 'createFavList' && evt.target.id != 'favNameEmpty') {
			$('.createListPopup').hide();
			$("#favListName").val('');
		    $("#favListName").removeClass('requiredTextBox'); 
		    $(".createListPopup").css('padding-bottom','20px');
			$("#createNewFavList").removeClass("opened");
		}
	});
	$(document).on("click", "#createFavList", function(e) {
		var newText = $("#favListName").val().trim();
		var pattern = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
		var validList = true;
		if (pattern.test(newText)) {
			validList = false;
		} else {
			validList = true
		}
		if (newText != '' && validList) {
			$("#favListName").removeClass('requiredTextBox');    
			$("#favNameEmpty,.splchar-error").hide();
			$('.createListPopup').hide();
			$("#createNewFavList").removeClass("opened");
			$(".createListPopup").css('padding-bottom','20px');
			$("ul.favoriteListView li").removeClass('active');
			var liText = "<li class='secondaryFavList active'><a href='javascript:void(0)'>"+$("#favListName").val()+"</a></li>"
			$("ul.favoriteListView").prepend(liText);
			$("ul.favoriteListView li.active").trigger('click');
			$("#myFavTableList,.errorMessagesSection").hide();
			$(".myFavContentSection #noItems").show();
			$("#partNumberinput").removeClass('requiredTextBox');   
			$("#partNoEmpty").hide();
		}
		else {
			if($("#favListName").val() == ""){
				$("#favListName").addClass('requiredTextBox');    
				$("#favNameEmpty").css('display','block');
				$(".splchar-error").hide();
				$(".createListPopup").css('padding-bottom','5px');
			}
			else {
				$("#favListName").addClass('requiredTextBox');    
				$(".splchar-error").css('display','block');
				$("#favNameEmpty").hide();
				$(".createListPopup").css('padding-bottom','5px');
			}
		}
		
	});
	$(document).on("click",".favListEdit",function(e) {
		$('.favListHeading').hide();
		$('.favText-edit').val($('.favListHeading').text());
		$('.favText-edit').show();
		$('.editFavList').hide();
		$("#partNo-splchar-error").hide();
		$('.favText-edit').removeClass('requiredTextBox');
		e.preventDefault();

		$('.favText-edit').click(function(event) {
			event.stopPropagation();
		});
		$('.favText-edit').focus();
		$('.favText-edit').bind('blur keyup', function(e) {
			if (e.type == 'blur' || e.keyCode == '13') {
				var pattern1 = /[`~!@#$%^&*()|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
				var validList1 = true;
				if (pattern1.test($(".favText-edit").val().trim())) {
					validList1 = false;
				} else {
					validList1 = true
				}
				if ($(".favText-edit").val().trim() == '') {
					$('.favText-edit').hide();
					$('.favListHeading').text($('.favListHeading').text());
					$(".favListHeading").show();
					$(".editFavList").show();
					$('.favText-edit').hide();
					$("#partNo-splchar-error").hide();
					$('.favText-edit').removeClass('requiredTextBox');
					$(".favoriteList ul li.active").text($('.favListHeading').text());
				}
				else {
					if ($(".favText-edit").val().trim() != '' && validList1) {
						$('.favText-edit').hide();
						$('.favListHeading').text($(document).find('.favText-edit').val());
						$(".favListHeading").show();
						$(".editFavList").show();
						$('.favText-edit').hide();
						$("#partNo-splchar-error").hide();
						$('.favText-edit').removeClass('requiredTextBox');
						$(".favoriteList ul li.active").text($(document).find('.favText-edit').val());
					}
					else {
						$('.favListHeading').hide();
						$('.favText-edit').show();
						$('.favText-edit').addClass('requiredTextBox');
						$('.editFavList').hide();
						$("#partNo-splchar-error").css('display','block');
					}
				}
				
				/*$('.favText-edit').hide();
				$('.favListHeading').text($(document).find('.favText-edit').val());
				$(".favListHeading").show();
				$(".editFavList").show();
				$('.favText-edit').hide();
				$(".favoriteList ul li.active").text($(document).find('.favText-edit').val());*/
			}
			e.stopPropagation();
		});
		e.stopPropagation();

	});
	$(document).on("click", ".addPartNumberForm #AddToFavList", function(e) {
		if($("#partNumberinput").val() == ""){
			$("#partNumberinput").addClass('requiredTextBox');   
			$("#partNoEmpty").css('display','flex');
		}
		else {
			$("#partNumberinput").removeClass('requiredTextBox');   
			$("#partNoEmpty").hide();
		}
	});
	$(document).on("click", ".viewMyFavorite #btnAddToCart", function(e) {
		var empty = 0;
		$('.myFavTableSection table td.qtyColumn input[type=text]').each(function(){
		   if (this.value == "") {
			   empty++;
			} 
		});
		if(empty > 0)
		{
            $("#qtyerrMsg").show();
			$("#qtysuccessMsg").hide();
		}
		else{
			$("#qtyerrMsg").hide();
			$("#qtysuccessMsg").show();
		}
	});
	$('#cancelDelete,#confirmDelete').click(function() {
        $("#deleteConfirmPopup span.newCloseIcon").trigger('click');
    });	
	$('.viewMyFavorite #deleteList').click(function(){
		setTimeout(function(){ 
            $("#deleteConfirmPopup .modal-dialog").css("top", '0px');
            if (window.innerHeight > $("#deleteConfirmPopup .modal-dialog").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight;
                var overLayHeight = $("#deleteConfirmPopup .modal-dialog").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                console.log("parentWindowHeight : " + parentWindowHeight);
                console.log("overLayHeight : " + overLayHeight);
                console.log("calcOverlayTop : " + calcOverlayTop);
                $("#deleteConfirmPopup .modal-dialog").css("top", calcOverlayTop + 'px');
            }
        },500);
	});
	$(document).on("click", ".deleteColumn .deletePartNo", function(e) {
		$(this).closest ('tr').remove ();
		//console.log($('.myFavTableSection table tbody tr').length);
		if($('.myFavTableSection table tbody tr').length == 0) {
			$("#myFavTableList,.errorMessagesSection").hide();
            $(".myFavContentSection #noItems").show();
		}
	});
	$(document).on("click", "#deleteConfirmPopup #confirmDelete", function(e) {
		$("ul.favoriteListView li.active").remove();
		$("ul.favoriteListView li:first-child").addClass('active');
		$("ul.favoriteListView li.active").trigger('click');
	});



});

var resultCurrencyVal,countryCode,netAmountCurrency;
if($.cookie('pl_profile_type') != undefined) {
	var profileTypeVal = $.cookie('pl_profile_type').split("&")[1].trim();
}
			var currencyObj = {
				"04DG": "USD",
				"04FI": "EUR",
				"0475": "USD",
				"0418": "USD",
				"04AU": "AUD",
				"04AT": "EUR",
				"04BE": "EUR",
				"04BR": "BRL",
				"04SG": "SGD",
				"04CA": "CAD",
				"04C9": "CNY",
				"04CN": "CNY",
				"04CS": "CNY",
				"04CC": "CNY",
				"04CE": "CNY",
				"04CG": "CNY",
				"04CZ": "CNY",
				"04NZ": "NZD",
				"04DK": "DKK",
				"04FR": "EUR",
				"04DE": "EUR",
				"04HK": "USD",
				"04IE": "EUR",
				"04IT": "EUR",
				"04JP": "JPY",
				"04MY": "MYR",
				"04MX": "USD",
				"04NL": "EUR",
				"04ES": "EUR",
				"04PR": "USD",
				"04SE": "SEK",
				"04CH": "CHF",
				"04TW": "TWD",
				"04TH": "THB",
				"04GB": "GBP",
				"04US": "USD",
				"04KR": "KRW",
				"04IN": "INR"
			};
			$.each( currencyObj , function( key, currencyValue ) {
			  if(profileTypeVal == key){
			  resultCurrencyVal=currencyValue;
			  }
			});
			countryCode = $.cookie('CountryCode');
			var currFormatVal = new Intl.NumberFormat(countryCode, {
                    //style: 'currency',
                    currency: resultCurrencyVal
                }); 

$("#send_email").on("click", function() {
	var email_flag = false;
	$('#specialist_List input.specialistCheckbox').each(function(i) {
		if ($(this).prop("checked") == true) {
			email_flag = true;
		}
	});
	if(email_flag) {
		formdata = $('#sendServiceEmail').serialize();
		LSCA.globalAjax.doCall({
			url: $('#sendServiceEmail').attr('action'),
			data : formdata,
			context : $(this),
			target : $(this)
		});
		$("#send_email").hide();
		$("#hidden_send_email").show();
		$('.thankYouMessageOuterSection .message-box-error').hide();
		$('.thankYouMessageOuterSection .message-box-success').show();	
	}
	else {
		$('.thankYouMessageOuterSection .message-box-success').hide();	
		$('.thankYouMessageOuterSection .message-box-error').show();
	}
});
$("#informationCNSP").focusout(function() {
	var str = document.getElementById("informationCNSP").value;	
	str = str.replace(/\%\s/g, "%");
	str = str.replace(/\%/g, "% ");
	document.getElementById("informationCNSP").value = str;		
});
function termsConditionCheck(){
$('.checkoutShippingBilling #btnPlaceOrder').click(function(e) {
	if ($(this).attr('id') == "btnPlaceOrder" && $(".terms-condition input").length && !$(".terms-condition input").is(":checked")) {
        e.preventDefault();
        $(".terms-condition .termsContent").addClass("required");
        $("#uniform-agreeCheckbox span").addClass("requiredTextBox");
		$(".terms-condition .termsContentother").addClass("requiredTextBoxClass");
		$("#tandcErrorMsg").show();
		creditCardFlagVal=false;
    }
else{
    $(".terms-condition .termsContent").removeClass("required");
    $("#uniform-agreeCheckbox span").removeClass("requiredTextBox");
	$(".terms-condition .termsContentother").removeClass("requiredTextBoxClass");
	$("#tandcErrorMsg").hide();
	creditCardFlagVal=true;
}
if($(".checkoutShippingBilling input").hasClass("requiredTextBox")){
    $('html, body').animate({
    scrollTop: $(".requiredTextBox").offset().top - 50
  }, 500);
}
}); 
}
function additionalReqToggle(){
	jQuery(".checkout-item-right.additional-req .addReqToggle").click(function(){
	 jQuery(this).parents('.additional-req').find("textarea").toggle();
	 jQuery(this).toggleClass("showLabel");
	}); 
}
function checkoutIVDWidth(){
	if(jQuery(".checkoutShippingBilling #ivdRegStatus").val()== "true"){		
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("width","420px");
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("max-width","420px");
	}
	else{
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("width","474px");
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("max-width","474px");
	}
	if($('.redeemQuoteNew.checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable:first-child > tbody > tr:first-child td').length == 4){
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("width","425px");
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("max-width","425px");		
	}else{
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("width","474px");
		jQuery(".checkoutShippingBilling .addressBox .custom-item-details-wrap .skyblueTable tbody tr:not(.noBorder,.last,.grandTotal) td:first-child").css("max-width","474px");		
	}
}
function hplcCheckBoxToggle(){
	$(".checkoutShippingBilling .hplc-wrap").each(function(){
	    $(this).find("input[type=checkbox]").change(function(){
	        if($(this).prop("checked")){
	        	$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').css('display','block');			
				$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').find("#lotNumberInput").removeAttr("disabled", "disabled");
				$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').find('#lotNumberInput').addClass('required');
				$(this).parents(".hplc-wrap").siblings(".customlotNumberWrap").find(".lotErrMsg").hide();
				$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').find("#lotNumberInput").val('');
				$(this).parents(".hplc-wrap").css("margin-bottom","20px");
	        }else {
	        	$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').css('display','none');
				$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').find("#lotNumberInput").attr("disabled", "disabled");
				$(this).parents(".hplc-wrap").siblings('.customlotNumberWrap').find("#lotNumberInput").removeClass('requiredTextBox required');
				$(this).parents(".hplc-wrap").css("margin-bottom","30px");
	        }  
	   });
	});
}
function editQuoteAjaxCall(){
	var rqpartNoList = "",editQuoteDetails = "",ajaxcallFlag=false;
	var eqarrval = [];
$(".redeemQuoteNew .rq-qtytxt").each(function () {
	if($(this).hasClass("requiredTextBox")){		
		ajaxcallFlag=true;
	}
	var rq_qtyVal = $(this).val();
	//var rq_partNoVal = $(this).parents('tr').find(".product-inner .partNo p").text();
	var rq_partNoVal = $(this).parents('tr').attr("data-editquote").trim();
	rqpartNoList += rq_partNoVal + ":" + rq_qtyVal + ",";
	eqarrval.push($(this).parents('tr').attr("data-editquote").trim());
	LSCA.loadingSpinner.showLoading();
});
if(!ajaxcallFlag){
$.ajax({
	type: "POST",
	contentType: "application/json; charset=utf-8",
	url: "/rest/model/com/agilent/commerce/EditRedeemQuantity?atg-rest-output=json",
	data: JSON.stringify({
		"editRedeemQty": {
			"shipPartNo": $(".redeemQuoteNew #shipAddrId").val(),
			"quoteNumber": $(".redeemQuoteNew #quoteNumber").val(),
			"Items": rqpartNoList
		}
	}),
	
	success: function (responsedata) {		 
        var rq_partNoVal1="",keyLength=0;
		LSCA.loadingSpinner.hideLoading();
		$.each(responsedata.fetchEditRedeemQtyDataResponse.lineItems, function (key, value) {        
            for(var i=0;i<eqarrval.length;i++){
				if(eqarrval[i]==key){
							//console.log("eqarrval[i]-->"+eqarrval[i]);
							jQuery('tr[data-editquote=' + eqarrval[i] + '] .customYrprice span').text(value.listPrice);
							jQuery('tr[data-editquote=' + eqarrval[i] + '] .customListprice span').text(value.yourPrice);
							jQuery('tr[data-editquote=' + eqarrval[i] + '] .totalPrice span').text(value.total);
							if((value.ya9DiscountMsg!="") && (value.ya9DiscountMsg!=null)){
                                jQuery('tr[data-editquote=' + eqarrval[i] + '] .promocode-row .customPromo span').text(value.ya9DiscountMsg);
                            }
				}
            }
            if($('tr[data-editquote=' + key + '] .rq-qtytxt').val()!="0" && $('tr[data-editquote=' + key + '] .rq-qtytxt').val()!=""){
            	$('tr[data-editquote=' + key + ']').removeClass("zeroRow");
            }
		});
		$('#quotationSubtotal').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationSubtotal);
		$('#totalTaxValue').val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTax);
		$(".redeemQuoteNew #order-summary-table #subTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.subtotal);
		$(".redeemQuoteNew #order-summary-table #shippingVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.shippingCharges);
		$(".redeemQuoteNew #order-summary-table #taxVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.tax);
		$("#below-orderTotal #orderTotalVal .orderTotalVal-Inner").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.subtotal);
		$(".redeemQuoteNew #order-summary-table #orderTotalVal").text(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.total);
		$(".redeemQuoteNew #redeemQuoteOrderForm #quoteTotalAmountVal").val(responsedata.fetchEditRedeemQtyDataResponse.quotePriceInfo.quotationTotal);
	},
	dataType: "json"
});
}
else{
	LSCA.loadingSpinner.hideLoading();
}
}
termsConditionCheck();
additionalReqToggle();
hplcCheckBoxToggle();
var bomFirstQtyVal="";
var changedValue="";
$(".redeemQuoteNew .rq-qtytxt").on("change",function (e) {
	var parentBOMQtyVal=$(this).attr("data-rqqty");
	$(this).parents("tr").removeClass("changedRow").addClass("changedRow");
	changedValue=$(this).parents("tr.changedRow").attr("data-rqeditquote");
	bomFirstQtyVal=$(this).val();
	$("tr.bomproduct:not(.bpfist)").each(function(){		
		if($(this).attr("data-rqeditquote") == changedValue && bomFirstQtyVal!=""){
			bomQty=$(this).find(".qtyVal").attr("data-rqqty");
			bomQty=(bomQty/parentBOMQtyVal)*bomFirstQtyVal;
			console.log("QtyValFinal"+bomQty);
			$(this).find(".qtyVal").text(bomQty);
		}
	});		
});
$(".redeemQuoteNew .rq-qtytxt").on("keydown change",function (e) { 
	var $thisrqVal = $(this);
	changedQtyFlagcheck=true;
	setTimeout(function(){ 
		if(e.type == 'change' || e.keyCode == '13'){
			if(e.keyCode == '13'){
				e.preventDefault();
				$thisrqVal.trigger("blur");
			}
			editQuoteAjaxCall();
		}
	}, 500);
});
$(".checkoutShippingBilling .order-summary-total-section .terms-condition input").change(function() {	
	if($(this).prop("checked") == true){		
	$(".terms-condition .termsContent").removeClass("required");
    $("#uniform-agreeCheckbox span").removeClass("requiredTextBox");
	$(".terms-condition .termsContentother").removeClass("requiredTextBoxClass");
	$("#tandcErrorMsg").hide();
	}
	else{	
		 $(".terms-condition .termsContent").addClass("required");
        $("#uniform-agreeCheckbox span").addClass("requiredTextBox");
		$(".terms-condition .termsContentother").addClass("requiredTextBoxClass");
		$("#tandcErrorMsg").show();
	}
}); 
$(document).on('change', '.terms-conditioncn input', function() {		
	if($(this).prop("checked") == true){		
		$(".terms-conditioncn input").removeClass("requiredTextBox");
		$("#tandcErrorMsgcn").hide();
	}
	else{	
		$(".terms-conditioncn input").addClass("requiredTextBox");
		$("#tandcErrorMsgcn").show();
	}
});


function multiQuotescrpts(){

	$('.myQuoteListing .custom-detail-table tbody tr').each(function(){
        var tdHe = $(this).find('td').find('.block-with-text').height();
        if(tdHe < 37) {
                        $(this).find('td').find('.block-with-text').addClass('singleLineDes');
        }
});


	var $checkboxes = $('.myQuoteListingTable tbody td .checkbox-quote');
    var $checkboxesHead = $('.myQuoteListingTable thead .checkbox-quote-head');
    var countUnCheckedCheckboxes = $checkboxes.filter('.checkbox-quote').length;
    
    console.log(countUnCheckedCheckboxes);
    
    $checkboxes.change(function(){
    	var countCheckedCheckboxes = $checkboxes.filter(':checked').length;
        if(countCheckedCheckboxes > 0){
        	$('.buy-selected-quote p.selcted-quote-count').css('display','inline-block');
        	$('.selected-quote-btn').prop("disabled", false);
        }else {
        	$('.buy-selected-quote p.selcted-quote-count').css('display','none');
        	$('.selected-quote-btn').prop("disabled", true);
        }               	
        $('#quote-count').text(countCheckedCheckboxes);
        if(countCheckedCheckboxes === countUnCheckedCheckboxes) {
        	$checkboxesHead.prop('checked', true).parent('span').addClass('checked');
        }else {
        	$checkboxesHead.prop('checked', false).parent('span').removeClass('checked');
        }
        if($(this).prop('checked')){
        	$(this).parents('tr').addClass('active');
        }else {
        	$(this).parents('tr').removeClass('active');
        }
    });
    
    $checkboxesHead.change(function(){
    	if($(this).prop("checked")) {
    		$('.myQuoteListingTable tbody tr').each(function(){
        		$(this).find('.checkbox-quote').prop('checked', true).parent('span').addClass('checked');
        	});
        	$checkboxes.change();
    	}else {
    		$('.myQuoteListingTable tbody tr').each(function(){
        		$(this).find('.checkbox-quote').prop('checked', false).parent('span').removeClass('checked');
        	});
    		$checkboxes.change();
    	}
    	
    });
    var CustomQuoteNo = [];
    $(".myQuoteListingTable input[type='checkbox']").on("click", function(){
    	CustomQuoteNo = [];
    	setTimeout(function(){ 	                
            $.each($("tbody tr.active td input[type='checkbox']:checked"), function(){
            	CustomQuoteNo.push($(this).val());
            });
            localStorage.removeItem("QuotesNumber");
        	localStorage.setItem("QuotesNumber", JSON.stringify(CustomQuoteNo));
        }, 500);
    });
    if($("#isPunchoutFlow").val()== "true") {
    	$('.myQuoteListingTable input[type="checkbox"]').wrap('<div class="checker"><span class="checkbox-GreyOut"></span></div>');
    	$('.checkbox-GreyOut input[type="checkbox"]').attr("disabled","disabled");
    } else {
    	$('.myQuoteListingTable input[type="checkbox"]').wrap('<div class="checker"><span></span></div>');
    }
        $('.myQuoteListingTable input[type="checkbox"]').on('change', function(){
    	if($(this).prop('checked')){
    		$(this).parent('span').addClass('checked');
        }else {
        	$(this).parent('span').removeClass('checked');
        }            	
    });
    $( ".custom-tooltip-quote" ).tooltip({
		position: {
       my: "center top",
       at: "center bottom+15",
       collision: "none"
	    },
	   tooltipClass: "addOn-Tooltip myQuote-Tooltip",
	});
	function multiQuotes(e){
		$.ajax({
			type:"POST", 
			url:"/common/myaccount/redeemQuote.jsp", 
			contentType: 'application/html',
	        data: $(this).serialize(),
	        success: function( data, textStatus, jQxhr ){
	        	//window.location = "/common/myaccount/redeemQuote.jsp?"+"multiquote=true&quoteid="+CustomQuoteNo;
				window.location = "/common/myaccount/redeemQuote.jsp?"+"multiquote=true&quoteid="+JSON.parse(localStorage.getItem("QuotesNumber")); 
	        },
	        error: function( jqXhr, textStatus, errorThrown ){
	            console.log( errorThrown );
	        }
		        
		});
	};
	$('#selectedQuoteBtn').on('click', function(){
		multiQuotes();
	});
};
jQuery(document).ready(function(){
	checkoutIVDWidth();
	if(jQuery(".redeemQuoteNew #installationPresent").val()=="true"){
		$('.rc-calender').datepicker('setDate', 'today'+14);
	}
	if($(".shoppingCartPage #rtuCart").val() == "true"){
		jQuery("body").addClass("rtu-cart");
		jQuery(".shoppingCartPage .partnoEntryList > div:nth-child(1)").css("opacity","1");
	}
	if(jQuery(".customthanku-Wraper #ivdRegStatus").val()== "true"){		
			jQuery(".customthanku-Wraper .custom-item-details-wrap .skyblueTable thead th").attr("colspan","5");
	}
	$('.redeemQuote #step3.eMethod input[type="radio"],.redeemQuote #step3.eMethod input[type="checkbox"]').attr("disabled", true);	
	$('.redeemQuote #step3.eMethod input,.redeemQuote #step3.eMethod textarea').removeAttr("title");
	$('.redeemQuote #step3.eMethod textarea,.redeemQuote #step3.eMethod input').attr("disabled", true);
	$('.redeemQuote #step3.eMethod input[type="radio"],.redeemQuote #step3.eMethod input[type="checkbox"]').removeAttr("checked");
	//Favorites | type only digits in QTY field
	$(document).on("input","#custom-main-wrapper-expand .myOrderStatuss .qtyTxtbox",function() {
			$(this).val($(this).val().replace(/[^0-9]/gi,''));
	});	

	/*if(jQuery(".customthanku-Wraper #isPPSOrder").val()=="true"){
		var atgOrderIDVal = jQuery(".customthanku-Wraper #ppsOrderId").val().trim();
		var authKey = jQuery(".customthanku-Wraper #ppsOrderAuthKey").val();
		var authVal = jQuery(".customthanku-Wraper #ppsOrderAuthValue").val();
		jQuery.ajax({
				beforeSend: function(x) {
						x.setRequestHeader(authKey,authVal);
				},
				url:jQuery(".customthanku-Wraper #ppsUpdateUrl").val(),
				type: "POST",
				data: {"atgOrderId": atgOrderIDVal},
				dataType: "json",
				success: function(responsedata) {
					console.log(responsedata);
				}
		});
	}*/
   $(document).on("keyup", ".lotNumber-inputwrap #lotNumberInput", function(e) {
		//var regexhplc= /[a-zA-Z0-9]+/g;
		var $this = $(this);
		$this.val($this.val().replace(/[^a-zA-Z0-9-_;, ]+/g, ''));
		$this.val($this.val().replace(/^\s+/g, ''));
		if($(this).val()){
			$('#lotNumberInput').removeClass('requiredTextBox');
			$(".customlotNumberWrap .lotErrMsg").hide();
		}
		else{
			$('#lotNumberInput').addClass('requiredTextBox');
			$(".customlotNumberWrap .lotErrMsg").show();
		}
	});
	/*checkout and redeem quote dropship textbox enter*/
	$("#inputShipto").on('keypress', function(e) {
		if (e.keyCode == '13') {
			if($('#mainContainer').hasClass('redeemQuoteNew')){
				$(".redeemQuoteNew #shiptocustomer1").trigger('click');
			}else if($('#mainContainer').hasClass('checkoutShippingBilling')){
				$("#shiptocustomer").trigger('click');
			}		
			return false;
		}
	});
$('.viewMyCatalog #error-messages').on("click",".req-quote-Link", function(e){
		e.preventDefault();		
		var ajaxCallUrl = '/common/requestQuote.jsp?pageName=cartPage';
		var cartQty="",cartPNo="",prodDesc="",postData="";	
			var arrValues = jQuery("#invalidPartsVal").val().split("::");
			//console.log("arrValues----->"+arrValues.length);
			for(var i = 0; i < arrValues.length; i++)
			{
				cartQty = arrValues[i].split("||")[1];
				cartPNo = arrValues[i].split("||")[0];
				prodDesc = arrValues[i].split("||")[2];
				postData+="partNumber="+cartPNo+"&"+cartPNo+"Qty="+cartQty+"&"+cartPNo+"Desc="+prodDesc+"&";
			}
		submitRequestQuoteForm(postData, ajaxCallUrl);
});
$('#orderCenterErrorMsg #req-quote-Link').on('click', function(e){
		e.preventDefault();		
		var ajaxCallUrl = '/common/requestQuote.jsp?pageName=cartPage';
		var cartQty="",cartPNo="",prodDesc="",postData="";	
			var arrValues = jQuery("#invalidParts").val().split("::");
			//console.log("arrValues----->"+arrValues.length);
			for(var i = 0; i < arrValues.length; i++)
			{
				cartQty = arrValues[i].split("||")[1];
				cartPNo = arrValues[i].split("||")[0];
				prodDesc = arrValues[i].split("||")[2];
				postData+="partNumber="+cartPNo+"&"+cartPNo+"Qty="+cartQty+"&"+cartPNo+"Desc="+prodDesc+"&";
			}
		submitRequestQuoteForm(postData, ajaxCallUrl);
});
$('.shoppingCartPage #erroeMessages_outer').on("click",".req-quote-Link", function(e){
	e.preventDefault();		
	var ajaxCallUrl = '/common/requestQuote.jsp?pageName=cartPage';
	var cartQty="",cartPNo="",prodDesc="",postData="";	
		var arrValues = jQuery("#invalidPartsVal").val().split("::");
		//console.log("arrValues----->"+arrValues.length);
		for(var i = 0; i < arrValues.length; i++)
		{
			cartQty = arrValues[i].split("||")[1];
			cartPNo = arrValues[i].split("||")[0];
			prodDesc = arrValues[i].split("||")[2];
			postData+="partNumber="+cartPNo+"&"+cartPNo+"Qty="+cartQty+"&"+cartPNo+"Desc="+prodDesc+"&";
		}
	submitRequestQuoteForm(postData, ajaxCallUrl);
});
$('#orderCenterErrorMsg #req-quote-Link-obsolete').on('click', function(e){
	e.preventDefault();		
	var ajaxCallUrl = '/common/requestQuote.jsp?pageName=cartPage';
	var cartQty="",cartPNo="",prodDesc="",postData="";	
		var arrValues = jQuery("#obsoleteParts").val().split("::");
		//console.log("arrValues----->"+arrValues.length);
		for(var i = 0; i < arrValues.length; i++)
		{
			cartQty = arrValues[i].split("||")[1];
			cartPNo = arrValues[i].split("||")[0];
			prodDesc = arrValues[i].split("||")[2];
			postData+="partNumber="+cartPNo+"&"+cartPNo+"Qty="+cartQty+"&"+cartPNo+"Desc="+prodDesc+"&";
		}
	submitRequestQuoteForm(postData, ajaxCallUrl);
});
$('.shoppingCartPage #erroeMessages_outer').on("click",".req-quote-Link-obsolete", function(e){
e.preventDefault();		
var ajaxCallUrl = '/common/requestQuote.jsp?pageName=cartPage';
var cartQty="",cartPNo="",prodDesc="",postData="";	
	var arrValues = jQuery("#obsoletePartsVal").val().split("::");
	//console.log("arrValues----->"+arrValues.length);
	for(var i = 0; i < arrValues.length; i++)
	{
		cartQty = arrValues[i].split("||")[1];
		cartPNo = arrValues[i].split("||")[0];
		prodDesc = arrValues[i].split("||")[2];
		postData+="partNumber="+cartPNo+"&"+cartPNo+"Qty="+cartQty+"&"+cartPNo+"Desc="+prodDesc+"&";
	}
submitRequestQuoteForm(postData, ajaxCallUrl);
});
function submitRequestQuoteForm(postData, ajaxCallUrl){
	var formData = postData.split('&');
	if(formData !== null && formData.length >0){
	var form = document.createElement("form");
	form.setAttribute("id", "hiddenFormRquote");
	form.method = "POST";
	form.action = ajaxCallUrl;   
	for(var i=0;i<formData.length;i++){
		var formDataValue = formData[i].split('=');
		if(formDataValue != null && formDataValue.length ==2){
			var element1 = document.createElement("input");
			element1.value=formDataValue[1];
			element1.name=formDataValue[0];
			form.appendChild(element1);  

		}
	}
	document.body.appendChild(form);
	form.submit();
	}	
}
});

