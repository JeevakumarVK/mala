 /*
 * @Description: This is a combined control script for supporting scirpt.js.
 * @Author: Kavimani Gunasekaran for CTS Agilent Team.
 */

 function invCRMInfoData(params_) {
        $("#invoiceDetails").html('');
        LSCA.imageLoader.init({
            target : params_.selector
        });
        $.ajax({
            type : "POST",
            url : "/common/myaccount/contractInvoiceDetails.jsp?",
            dataType : "html",
            cache : false
        }).done(function(data) {
            if (data != null || data != "") {
                $("#invoiceDetails").html(data);
                $(params_.selector).removeClass("hide");
            }
            $(".invCRMInfo").on('click',function() {
                $('#invoiceDetails .renewattriblockview').slideToggle(500);
                $(this).find(".crmViewless, .crmViewmore").toggle();
            });
        })
}
 
 function getValueOfElement(elementName) {
	 var returnValue = "";
	 if(document.getElementById(elementName) != null) {
		 returnValue = document.getElementById(elementName).value;
	 }
	 return returnValue;
 } 
 
 
$(document).on('click', '#invCRMEdit', function() {
        $("#invCRMSave").removeClass("hide");
        $("#invCRMEdit").addClass("hide");
        $("#invoiceBox :input").removeAttr("disabled");
 });

 $(document).on('click', '#invCRMSave', function() {
        var data = $("#placeRenewalOrder").serialize();
        var time = $("#customerName1").serialize();
        var saveInvoice = true;
        $.ajax({
            type : "post",
            url : "/common/myaccount/contractInvoiceDetails.jsp?saveInvoice=" + saveInvoice,
            data : data,
            dataType : "html",
            cache : false
        }).done(function() {
            /* LSCA.invCRMInfo.init({
                    target : '.invCRMInfo',
                    selector : '#invoiceDetails'
             });*/
            $("#invCRMEdit").removeClass("hide");
            $("#invCRMSave").addClass("hide");
            $("#invoiceBox :input").attr("disabled", "true")

        }).fail(function() {
            console.log('Something went wrong!')
        });
 });

$(document).on('click', '#lmsSbmtOrder', function() {
    console.log('click');
    setTimeout(function(){
        console.log('beforeloading');
        $(".loader-overlay").show(); }, 500);
        console.log('afterloading');
   
});

$("#fedExCheckId div.checker span").on("click", function() {
    className = $(this).attr("class");
    if (className == "checked") {
        $("input[type='checkbox']", this).attr("checked", "checked");
        $("input#fedEXNumber").removeAttr("disabled").addClass("required");
    } else {
        $("input[type='checkbox']", this).removeAttr("checked");
        $("input#fedEXNumber").attr("disabled", "disabled").removeClass("required").css('border-color', '#e0e0e0');
    }
});

$("#fedEXNumber").on('keyup', function() {
    $(this).val($(this).val().replace(/[^\d]/g, ''));
    if ($(this).val()) {
        $(this).css('border-color', '#e0e0e0');
    } else {
        $(this).css('border-color', 'red');
    }
});
/*warrantyQuestions page script*/
$(document).on('click', '#warrantyCoversionFormBtn', function() {
    var check = true;
    $("input:radio").each(function() {
        var name = $(this).attr("name");
        if ($("input:radio[name=" + name + "]:checked").length == 0) {
			$(this).parent('label').prev(".war-ques-txt").addClass("req");
            $(this).parent('label').next(".que-error").removeClass("hide");
            check = false;
        }
    });
    if (check == true) {
        $('#warrantyCoversionSbmtBtn').click();
    }
});

$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd .warr-submit').attr('disabled','disabled');
$('.warranty-container .WarrWrapper .warr-bnr-txt a.btnTransparent').on('click', function(){
    $('html, body').animate({
        scrollTop: $('.warranty-container .WarrWrapper .contentWrap .qa-inner-sec').offset().top-53
    }, 500);
});
var repair,pm,oq;
$(".WarrantyQA input[name=serv-model]:radio").on('change',function () {
	if($(this).val() == 'fullyDependant'){
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:first-child').addClass('yes').removeClass('no');
		repair = 'y';
	}else{
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:first-child').addClass('no').removeClass('yes');
		repair = 'n';
	}
	radioLogic(repair,pm,oq)
});	
$(".WarrantyQA input[name=annual]:radio").on('change',function () {
	if($(this).val() == 'yes'){
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:nth-child(2)').addClass('yes').removeClass('no');
		pm = 'y';
	}else{
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:nth-child(2)').addClass('no').removeClass('yes');
		pm = 'n';
	}
	radioLogic(repair,pm,oq)
});
$(".WarrantyQA input[name=qualify]:radio").on('change',function () {
	if($(this).val() == 'yes'){
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:last-child').addClass('yes').removeClass('no');
		oq = 'y';
	}else{
		$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd ul li:last-child').addClass('no').removeClass('yes');
		oq = 'n';
	}
	radioLogic(repair,pm,oq)
});
function radioLogic(a,b,c){
		if(a != undefined && b != undefined && c != undefined){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').css('opacity',1)
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd .warr-submit').removeAttr('disabled');
		}
		if(a == 'y' && b == 'y' && c == 'y' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap silverwoq')			
		}
		if(a == 'y' && b == 'y' && c == 'n' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap silver')
		}		
		if(a == 'y' && b == 'n' && c == 'y' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap silverwoq')
		}	
		if(a == 'y' && b == 'n' && c == 'n' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap bronze')
		}		
		if(a == 'n' && b == 'y' && c == 'y' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap pmoq')
		}	
		if(a == 'n' && b == 'y' && c == 'n' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap pmonly')
		}	
		if(a == 'n' && b == 'n' && c == 'y' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap pmoq')
			//$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap oq')
		}	
		if(a == 'n' && b == 'n' && c == 'n' ){
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').removeAttr('class')
			$('.warranty-container .WarrWrapper .contentWrap .servicePreview .servicePadd #servicePlanwrap').addClass('servicePlanwrap link')
		}		
}

/*
function getFSPDetails() {
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", "/rest/model/com/agilent/profile/fsp/FspService/saveFlexibleSpendPlanDetails?atg-rest-output=json&featureName=cartCheckout&restCall=true",true);
    xhttp.send();
}


function getFSPDetails() {
    LSCA.globalAjax.doCall({
        url : '/rest/model/com/agilent/profile/fsp/FspService/saveFlexibleSpendPlanDetails?atg-rest-output=json&featureName=cartCheckout&restCall=true',
        type: 'GET'
    });
}

$("#btnLogin").on('click', function(e) {
    getFSPDetails();
});
*/

function combineContract() {
	$.ajax({
		type : "GET",
		url : '/rest/model/com/agilent/commerce/LynxServiceActor/fetchActiveContracts?quoteStartDate='+$('#contractDate').val()+'&atg-rest-output=json',
		//url : '/common/js/popup1.json',
		//dataType: "json",
		cache : false,
		success: function(data) {
			var data1 = data.fetchActiveContracts;
			var tableData = "";
			var len = data1.length;
			if(len == 0) {
				$('#quoteNextBtn').removeAttr('data-toggle');
				$('#quoteNextBtn').removeAttr('data-target');
				$('#quoteNextBtn').attr("type", "submit");
				$('#createWarranty_link').hide();
			}
			else {
				for (var i = 0; i < len; i++) {
					tblrow = '<tr id='+ data1[i].contractId + '>';
					tblrow += ' <td class="radio-bt"><input type="radio" name="quoteCheckbox" value=' + data1[i].contractId + '><input type="hidden" name="encryptedContractId" id="encryptedContractId" value=' + data1[i].encryptedContractId + '><input type="hidden" name="erenewalQuoteId" id="erenewalQuoteId" value=' + data1[i].erenewalQuoteId + '></td>';
					tblrow += ' <td class="contract"><a href=/common/myaccount/viewServiceContract.jsp?contractId='+data1[i].encryptedContractId+'&autoRenewalFlag=false target=_blank>' + data1[i].contractId + '</a></td>';
					var d1 = data1[i].subscriptionStartDate.split('-');
					var d2 = data1[i].subscriptionEndDate.split('-');
					var coverageStartDate = d1[1] + "/" + d1[2] + "/" + d1[0];
					var coverageEndDate = d2[1] + "/" + d2[2] + "/" + d2[0];
					tblrow += ' <td class="col3 cov-date">' + coverageStartDate + ' - '+coverageEndDate+'</td>';
					tblrow += ' <td class="col4 total-price">' + data1[i].price + '</td>';
					tblrow += '</tr>';
					tableData += tblrow;
				}
				$('#Modal1 tbody').html(tableData);
			}	
		},
		error: function() {
			console.log('error');
		}
	});
}

function changeQuote() {
	$.ajax({
		type : "GET",
		url : '/rest/model/com/agilent/commerce/LynxServiceActor/fetchActiveContracts?quoteStartDate='+$('#contractDate').val()+'&atg-rest-output=json',
		//url : '/common/js/popup1.json',
		//dataType: "json",
		cache : false,
		success: function(data) {
			var data1 = data.fetchActiveContracts;
			var tableData = "";
			var len = data1.length;
			var selectRadioBtn = $('#selectedContractId').val();
			if(len == 0) {
				$('#changeQuoteLink,#changeQuoteLink + #changeQuoteTooltiptext').hide();
			}
			else {
				for (var i = 0; i < len; i++) {
					tblrow = '<tr id='+ data1[i].contractId + '>';
					if(selectRadioBtn == data1[i].contractId) {
						tblrow += ' <td class="radio-bt"><input type="radio" name="changequoteradio" value=' + data1[i].contractId + ' checked="true"><input type="hidden" name="encryptedContractId" id="encryptedContractId" value=' + data1[i].encryptedContractId + '><input type="hidden" name="erenewalQuoteId" id="erenewalQuoteId" value=' + data1[i].erenewalQuoteId + '></td>';
					}
					else {
						tblrow += ' <td class="radio-bt"><input type="radio" name="changequoteradio" value=' + data1[i].contractId + '><input type="hidden" name="encryptedContractId" id="encryptedContractId" value=' + data1[i].encryptedContractId + '><input type="hidden" name="erenewalQuoteId" id="erenewalQuoteId" value=' + data1[i].erenewalQuoteId + '></td>';
					} 
					tblrow += ' <td class="contract"><a href=/common/myaccount/viewServiceContract.jsp?contractId='+data1[i].encryptedContractId+'&autoRenewalFlag=false target=_blank>' + data1[i].contractId + '</a></td>';
					var d1 = data1[i].subscriptionStartDate.split('-');
					var d2 = data1[i].subscriptionEndDate.split('-');
					var coverageStartDate = d1[1] + "/" + d1[2] + "/" + d1[0];
					var coverageEndDate = d2[1] + "/" + d2[2] + "/" + d2[0];
					tblrow += ' <td class="col3 cov-date">' + coverageStartDate + ' - '+coverageEndDate+'</td>';
					tblrow += ' <td class="col4 total-price">' + data1[i].price + '</td>';
					tblrow += '</tr>';
					tableData += tblrow;
				}
				$('#Modal3 tbody').html(tableData);
			}	
		},
		error: function() {
			console.log('error');
		}
	});
}

$("#changeQuoteSubmit").on('click', function(e) {
	$('#Modal3 .empty-message').hide();
	$('#Modal3 .selected-radio').hide();
	if ($('#Modal3 input[name=changequoteradio]:checked').length) {
		//Need to check the radio button change logic
		var warrantyQuoteId = "";
		if($('#selectedContractId').val() == $('#Modal3 input[name=changequoteradio]:checked').val()) {
			$('#Modal3 .selected-radio').css('display','flex');
		}
		else {
		var enccrycontractId = $('#Modal3 input[name=changequoteradio]:checked').next().val();
		var enccryeRenewalQuoteId = $('#Modal3 input[name=changequoteradio]:checked').next().next().val();
		if($('#selectedContractId').val() == '') {
            warrantyQuoteId = $('#encryptedQuoteId').val();
      }
      else {
            warrantyQuoteId = $('#encOriginalQuoteId').val();
      }
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
			url : '/rest/model/com/agilent/commerce/LynxServiceActor/moveToAdjustQuoteService',
			data : JSON.stringify({
				"warrantyQuote":warrantyQuoteId,
				"contractId":enccrycontractId,
				"eRenewalQuoteId":enccryeRenewalQuoteId,
				"atg-rest-output":"json"
			}),
			beforeSend : function() {
				$("#changeQuoteSubmit").attr("disabled", "disabled");
					LSCA.loadingSpinner.showLoading();
			},
			success: function(data) {
				if(data.success == true) {
						LSCA.loadingSpinner.hideLoading();
					$("#changeQuoteSubmit").attr("disabled", "disabled");
					window.location.href = "/common/myaccount/reviewQuoteThankYou.jsp";
				}	
			},
			error: function() {
				console.log('error');
			}
		});
      }
      }
      else {
           $('#Modal3 .empty-message').show();
      }	
});

$("#yesCombine").on('click', function(e) {
	 if ($('#Modal1 input[name=quoteCheckbox]:checked').length) {
		var enccrycontractId = $('#Modal1 input[name=quoteCheckbox]:checked').next().val();
		var enccryeRenewalQuoteId = $('#Modal1 input[name=quoteCheckbox]:checked').next().next().val();
		var showPopUp = $('#showPopup').val();
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
			url : '/rest/model/com/agilent/commerce/LynxServiceActor/moveToAdjustQuoteService',
			data : JSON.stringify({
				"warrantyQuote":$('#encryptedQuoteId').val(),
				"contractId":enccrycontractId,
				"eRenewalQuoteId":enccryeRenewalQuoteId,
				"atg-rest-output":"json"
			}),
			beforeSend : function() {
				$("#yesCombine").attr("disabled", "disabled");
				LSCA.loadingSpinner.showLoading();
			},
			success: function(data) {
				if(data.success == true) {
					LSCA.loadingSpinner.hideLoading();
					$("#yesCombine").attr("disabled", "disabled");
					window.location.href = "/common/myaccount/reviewQuoteThankYou.jsp?addonadjustind=true";
				}	
			},
			error: function() {
				console.log('error');
			}
		});
           
      }
      else {
           $('#Modal1 .message-stnd').show();
      }	
});

$("#yesFindPlan").on('click', function(e) {
	 if ($('#Modal2 input[name=contractCheckbox]:checked').length) {
		var opportunityIdsValue = $('#Modal2 input[name=contractCheckbox]:checked').map(function() {return this.value;}).get().join(';');
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
			url : '/rest/model/com/agilent/commerce/LynxServiceActor/moveToCreateAdjustedQuote?atg-rest-output=json',
			data : JSON.stringify({
				"opportunityIds": opportunityIdsValue,
				"originalQuote":$('#quoteId').val(),
				"showPopup":$('#showPopup').val()
			}),
			beforeSend : function() {
				$("#yesFindPlan").attr("disabled", "disabled");
				LSCA.loadingSpinner.showLoading();
			},
			success : function(data) {
				if(data.success == true) {
				LSCA.loadingSpinner.hideLoading();
				$("#yesFindPlan").attr("disabled", "disabled");
				window.location.href = "/common/myaccount/warrantyQuestions.jsp";
				}	
			},
			error: function() {
				console.log('error');
			},
			dataType : "json"
		});
			}
      else {
           $('#Modal2 .message-stnd').show();
      }	
});

$("#changeCoverage").on('click', function(e) {
	 if ($('#Modal4 input[name=contractCheckbox]:checked').length) {
		//Need to check the checkbox  change logic
		var selectArrayList = [];
		var defaultArrayList = [];
		var opportunityIdsValue = $('#Modal4 input[name=contractCheckbox]:checked').map(function() {return this.value;}).get().join(';');
		var opportunityIdsValue1 = $('#Modal4 input[name=contractCheckbox]:checked').map(function() {return this.value;}).get().join(',');
		selectArrayList.push(opportunityIdsValue1);
		defaultArrayList.push($('#selectedInstrumentId').val());
		var changeFlag = true;

		for (var i = 0; i < defaultArrayList.length; i++) {
			if (selectArrayList.indexOf(defaultArrayList[i]) !== -1) {
				changeFlag = false;        
			}
		}
		if(changeFlag) {
			$('#Modal4 .selected-checkbox.message-stnd').hide();
			$('#Modal4 .message-stnd').hide();
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
			url : '/rest/model/com/agilent/commerce/LynxServiceActor/moveToCreateAdjustedQuote?atg-rest-output=json',
			data : JSON.stringify({
				"opportunityIds": opportunityIdsValue,
				"originalQuote":$('#quoteId').val()
			}),
			beforeSend : function() {
				$("#changeCoverage").attr("disabled", "disabled");
				LSCA.loadingSpinner.showLoading();
			},
			success : function(data) {
				if(data.success == true) {
				LSCA.loadingSpinner.hideLoading();
				$("#changeCoverage").attr("disabled", "disabled");
				window.location.href = "/common/myaccount/warrantyQuestions.jsp";
				}	
			},
			error: function() {
				console.log('error');
			},
			dataType : "json"
		});
      }
      else {
				$('#Modal4 .message-stnd').hide();
				$('#Modal4 .selected-checkbox.message-stnd').css('display','flex');
		  }	
      }
      else {
           $('#Modal4 .message-stnd').show();
		   $('#Modal4 .selected-checkbox.message-stnd').css('display','none');
      }	
});

$("#changeSystem").on('click', function(e) {
	 if ($('#Modal4 input[name=contractCheckbox]:checked').length) {
		//Need to check the checkbox  change logic
		var selectArrayList = [];
		var defaultArrayList = [];
		var opportunityIdsValue = $('#Modal4 input[name=contractCheckbox]:checked').map(function() {return this.value;}).get().join(';');
		var opportunityIdsValue1 = $('#Modal4 input[name=contractCheckbox]:checked').map(function() {return this.value;}).get().join(',');
		selectArrayList.push(opportunityIdsValue1);
		defaultArrayList.push($('#selectedInstrumentId').val());
	
		var changeFlag = true;

		for (var i = 0; i < defaultArrayList.length; i++) {
			if (selectArrayList.indexOf(defaultArrayList[i]) !== -1) {
				changeFlag = false;        
			}
		}
		//console.log('final flag : '+changeFlag);
		if(changeFlag) {
		$('#Modal4 .selected-checkbox.message-stnd').hide();
		$('#Modal4 .message-stnd').hide();
		$.ajax({
			type : "POST",
			contentType : "application/json; charset=utf-8",
			url : '/rest/model/com/agilent/commerce/LynxServiceActor/submitAdjustedQuote?atg-rest-output=json',
			data : JSON.stringify({
				"opportunityIds": opportunityIdsValue,
				"originalQuote":$('#originalQuoteId').val(),
				"adjustedQuote":$('#quoteId').val()
			}),
			beforeSend : function() {
				$("#changeSystem").attr("disabled", "disabled");
					LSCA.loadingSpinner.showLoading();
			},
			success : function(data) {
				if(data.success == true) {
						LSCA.loadingSpinner.hideLoading();
					$("#changeSystem").attr("disabled", "disabled");
					window.location.href = "/common/myaccount/warrantyQuoteInterimConfirmation.jsp";
				}	
			},
			error: function() {
				console.log('error');
			},
			dataType : "json"
		});
      }
      else {
			$('#Modal4 .message-stnd').hide();
			$('#Modal4 .selected-checkbox.message-stnd').css('display','flex');
      }
      }
      else {
           $('#Modal4 .message-stnd').show();
		   $('#Modal4 .selected-checkbox.message-stnd').css('display','none');
      }	
});

$("#quotenoCombine").on('click', function(e) {
		$("#Modal1 #redirectBtn").click();
});

$("#contractnoCombine").on('click', function(e) {
		$("#Modal2 #redirectBtn").click();
});

$("#Modal1 i").on('click', function(e) {
	$("#Modal1 #redirectBtn").click();
});
$("#Modal2 i").on('click', function(e) {
	$("#Modal2 #redirectBtn").click();
});
$("#Modal3 i").on('click', function(e) {
	$('#Modal3 #closeCombinePopup').trigger('click');
});
$("#Modal4 i").on('click', function(e) {
	$('#Modal4 #closeCombinePopup').trigger('click');
});

function getInstrumentRenewalQuote() {
	var systemIds = $('#systemIds').val().replace(/[\[\]']+/g,'');
	var endDate = $('#endDate').val();
	var urlParam = '&systemIds='+ systemIds +'&endDate='+ endDate;
	//LSCA.loadingSpinner.showLoading();
	$.ajax({
		type : "GET",
		url : "/rest/model/com/agilent/commerce/LynxServiceActor/getInstrumentDetails?atg-rest-output=json"+urlParam,
		//url : '/common/js/popup2.json',
		//dataType: "json",
		cache : false,
		success : function(data) {                                                                  
			console.log(data);
			var data1 = data.LynxInstrumentDetails;
			var tableData = "";
			var len = data1.length;
			if(len == 0) {
				$('#contractNextBtn').removeAttr('data-toggle');
				$('#contractNextBtn').removeAttr('data-target');
				$('#contractNextBtn').attr("type", "submit");
				$('#creteERenewal_link').hide();
			}
			else {
				for (var i = 0; i < len; i++) {
					tblrow = '<tr id='+ data1[i].OpportunityId + '>';
					tblrow += ' <td class="check-box"><input type="checkbox" name="contractCheckbox" value=' + data1[i].OpportunityId + '></td>';
					tblrow += ' <td class="sys-det">' + data1[i].InstrumentName + '</td>';

					var d1 = data1[i].ExpiredDate.split('-');
					var coverageExpiredDate = d1[1] + "/" + d1[2] + "/" + d1[0];
					tblrow += ' <td class="col3 war-exp">' + coverageExpiredDate + '</td>';
					tblrow += '</tr>';
					tableData += tblrow;
				}
				$('#Modal2 tbody').html(tableData);
			}
		},
		error : function() {
			console.log('Service call failed');
		}
	});
}

function changeInstrumentRenewalQuote() {
	var systemIds = $('#systemIds').val().replace(/[\[\]']+/g,'');
	var endDate = $('#endDate').val();
	var urlParam = '&systemIds='+ systemIds +'&endDate='+ endDate;
	//LSCA.loadingSpinner.showLoading();
	$.ajax({
		type : "GET",
		url : "/rest/model/com/agilent/commerce/LynxServiceActor/getInstrumentDetails?atg-rest-output=json"+urlParam,
		//url : '/common/js/popup2.json',
		//dataType: "json",
		cache : false,
		success : function(data) {                                                                  
			console.log(data);
			var data1 = data.LynxInstrumentDetails;
			var tableData = "";
			var len = data1.length;
			if(len == 0) {
				$('#changeCoverageLink,#combineContractLink,#changeCoverageLink + div#changeQuoteTooltiptext,#combineContractLink + div#changeQuoteTooltiptext').hide();
			}
			else {
				var checkedFlag= 'checked=checked';
				 var checkedoArrayList = [];
				for (var i = 0; i < len; i++) {
					tblrow = '<tr id='+ data1[i].OpportunityId + '>';
					if(data1[i].Selected == "true") {
						checkedoArrayList.push(data1[i].OpportunityId);
						tblrow += ' <td class="check-box"><input type="checkbox" name="contractCheckbox" value=' + data1[i].OpportunityId + ' '+checkedFlag+'></td>';
					}
					else {
						tblrow += ' <td class="check-box"><input type="checkbox" name="contractCheckbox" value=' + data1[i].OpportunityId + '></td>'; 
					}
					tblrow += ' <td class="sys-det" title="'+ data1[i].InstrumentName +'">' + data1[i].InstrumentName + '</td>';

					var d1 = data1[i].ExpiredDate.split('-');
					var coverageExpiredDate = d1[1] + "/" + d1[2] + "/" + d1[0];
					tblrow += ' <td class="col3 war-exp">' + coverageExpiredDate + '</td>';					tblrow += '</tr>';
					tableData += tblrow;
				}
				$('#selectedInstrumentId').val(checkedoArrayList);
				$('#Modal4 tbody').html(tableData);
				
				
			}
		},
		error : function() {
			console.log('Service call failed');
		}
	});
}

function getActivePopup(){
	if(document.getElementById('Modal1').style.display === 'block'){
		return '#Modal1';
	}else if(document.getElementById('Modal2').style.display === 'block'){
		return '#Modal2';
	}else if(document.getElementById('Modal3').style.display === 'block'){
		return '#Modal3';
	}else {
		return '#Modal4';
	}
}

$("#contractNextBtn").on('click', function(e) {
	$('#Modal2 table tbody tr td.sys-det').each(function(){
		$(this).html(truncateTextByChar($(this).html(), 40, " ..."));
	});
});

$("#contractNextBtn,#quoteNextBtn,#changeQuoteLink,#changeCoverageLink,#combineContractLink").on('click', function(e) {
	$('.message-stnd').hide();
	if(/^((?!chrome|android).)*safari/i.test(navigator.userAgent)){		
		setTimeout(function() {
			var activePopup = getActivePopup();
			var popupHt = $(activePopup + " .agt-modal-center").height();
			if(window.innerHeight > popupHt) {
				var parentWindowHeight = window.innerHeight - 60;
				var overLayHeight = popupHt;
				var calcOverlayTop = (parentWindowHeight - overLayHeight)/2;
				$(activePopup + " .agt-modal-center").css("top",calcOverlayTop+'px');
			}
		}, 200);
	}
});

$("#changeQuoteLink").on('click', function(e) {
	$('#Modal3 table tbody tr td:first-child input[type=radio]').each(function(){
		if($(this).val() == $('#selectedContractId').val()) {
			 $('#Modal3 input[name=changequoteradio][value='+$(this).val()+']').prop("checked",true);
		}
	});
});

$("#changeCoverageLink").on('click', function(e) {
	$('#Modal4 table tbody tr td.sys-det').each(function(){
		$(this).html(truncateTextByChar($(this).html(), 40, " ..."));
	});
	$('#Modal4 table tbody tr td input[name=contractCheckbox]').prop('checked', false);
	$('#Modal4 table tbody tr td input[name=contractCheckbox]').each(function(){
		var checkedListSplit = $('#selectedInstrumentId').val().split(',');
		for(i=0;i< checkedListSplit.length;i++) {
			$("#Modal4 input[value='" + checkedListSplit[i] + "']").prop('checked', true);
		}
	});
});

if(window.location.pathname == '/common/myaccount/quoteDetails.jsp'){
	if($('#getServiceCall').val() == 'Modal1') {
	combineContract();
	}
	else if($('#getServiceCall').val() == 'Modal3') {
	changeQuote();
	}
	else if($('#getServiceCall').val() == 'Modal2') {
	getInstrumentRenewalQuote();
		$('#defaultQuoteVal').val($('#selectedContractId').val());
	}
	else if($('#getServiceCall').val() == 'Modal4') {
	changeInstrumentRenewalQuote();
}
}

function truncateTextByChar (content, showChar, ender) {
	if(content.length > showChar) {
		var c = content.substr(0, showChar);
		var h = content.substr(showChar-1, content.length - showChar);
		var html = c + '<span class="moreellipses">' + ender+ '</span>';
		return html;
	}
}

$("input[name=pay]").on('click', function(e) {
	$('#placeRenewalOrder .errorMessages').hide();
});

$(document).on("click", "#cartItemSection #addToImmediate", function(e) {
	var cId = $(this).attr('commerceid');
	var parItem = $(this).attr('partialItemId');
	var qty = $('.pqty_' + parItem).val();
	var maxQtyTomv = $('.pqty_' + parItem).attr('maxQtyTomv');
	var currQty = $('#prmQty_' + parItem).text();
	var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toImmediateShip" + "&currQty=" + currQty + "&parItem=" + parItem +"&chinaGenCart=" + $('#chinaGenCarthidden').val();
	if(qty == '' ) {
		console.log('empty')
		//LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
		$('#addtoImmediateErrorMsg span').text("Please Enter a valid Quantity");
		$('#addtoImmediateErrorMsg').show();
	}
	if (parseInt(maxQtyTomv) < parseInt(qty)) {
	console.log('grater if')
		//LSCA.GlobalValidate.showErrorScroll('', "Quantity entered cannot be greater than in stock quantity", '');
		$('#addtoImmediateErrorMsg span').text("Quantity entered cannot be greater than in stock quantity");
		$('#addtoImmediateErrorMsg').show();
		$('.pqty_' + parItem).val('');
		qty = 0;
	} /*else {
	console.log('grater else')
		$('#addtoImmediateErrorMsg').hide();
	}*/
	//$(params_.target).parent().hide();
	if (qty > 0) {
	console.log('imm ajax calling')
	LSCA.loadingSpinner.showLoading();
		//$("#cartItemSection").html('');
		$('#addtoImmediateErrorMsg').hide();
		if(jQuery("#isPPSOrder").val()!= "true"){
            addtoImmediateUrlValue= "/common/includes/ajax/checkout-Product-DistUser.jsp?" + queryString;
        }
        else{
        	addtoImmediateUrlValue= "/common/includes/ajax/checkout-Product-DistUserPPS.jsp?" + queryString;
        }
		$.ajax({
			type : "POST",
			url : addtoImmediateUrlValue,
			dataType : "html",
			cache : false
		}).done(function(data) {
			if (data != null || data != "") {
				$("#cartItemSection").html(data);
				  if($('#immediateOption').val() == 'true'){
				        $('tr.custom-immediate').show();
				  }
				LSCA.loadingSpinner.hideLoading();
				jQuery(".checkout-item-right.additional-req .addReqToggle").on('click',function(){
				 jQuery(this).parents('.additional-req').find("textarea").toggle();
				 jQuery(this).toggleClass("showLabel");
				}); 
				jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").prev().addClass("remove-border");
				jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").each(function(){		
					var colspanVal = jQuery(this).prev().find("td").length;
					jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row td").attr("colspan",colspanVal);
				});
				checkoutIVDWidth();
				 /*LSCA.advShip.init({
		                target : '.advShip',
		                selector : '#advShp',
		                pageId : 'checkoutBillingShipping',
		                chngShp : '.addImdShp',
		                adShp : '.addPrmShp',
		                advQty : '.advQty',
		                splitItemPrmy : '.splitItemPrmy',
		                splitItemImd : '.splitItemImd',
		                delDate : '.delDate'
		            });*/
			}
		})
	} 
});
//Large file review page Addto Immetiate Logic
$(document).on("click", "#largeReviewItemSection #addToImmediate", function(e) {
	var cId = $(this).attr('commerceid');
	var parItem = $(this).attr('partialItemId');
	var qty = $('.pqty_' + parItem).val();
	var maxQtyTomv = $('.pqty_' + parItem).attr('maxQtyTomv');
	var currQty = $('#prmQty_' + parItem).text();
	var order_id = $('#order_id').val();
	var ts = $('#ts').val();
	var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toImmediateShip" + "&currQty=" + currQty + "&parItem=" + parItem + "&order_id=" + order_id + "&ts=" + ts+"&large_order=true";
	if(qty == '' ) {
		console.log('empty')
		//LSCA.GlobalValidate.showErrorScroll('', "Please Enter a valid Quantity", '');
		$('#addtoImmediateErrorMsg span').text("Please Enter a valid Quantity");
		$('#addtoImmediateErrorMsg').show();
	}
	if (parseInt(maxQtyTomv) < parseInt(qty)) {
	console.log('grater if')
		//LSCA.GlobalValidate.showErrorScroll('', "Quantity entered cannot be greater than in stock quantity", '');
		$('#addtoImmediateErrorMsg span').text("Quantity entered cannot be greater than in stock quantity");
		$('#addtoImmediateErrorMsg').show();
		$('.pqty_' + parItem).val('');
		qty = 0;
	} 
	if (qty > 0) {
	console.log('imm ajax calling')
	LSCA.loadingSpinner.showLoading();
		//$("#cartItemSection").html('');
		$('#addtoImmediateErrorMsg').hide();
        addtoImmediateUrlValue= "/common/checkout/largeFilePrductListing-DistUser.jsp?" + queryString;
		$.ajax({
			type : "POST",
			url : addtoImmediateUrlValue,
			dataType : "html",
			cache : false
		}).done(function(data) {
			if (data != null || data != "") {
				console.log(data);
				$("#largeReviewItemSection").html('');
				$("#largeReviewItemSection").html(data);
				  if($('#immediateOption').val() == 'true'){
				        //$('tr.custom-immediate').show();
				  }
				LSCA.loadingSpinner.hideLoading();
			}
		})
	} 
});


//largeFileOrderReview | add to immediate 
$(document).on("click", "#LFCitemSection #addToImm", function(e) {
		e.preventDefault();
		var cId = $(this).attr('commerceid');
		var parItem = $(this).attr('partialItemId');
		var qty = $('.pqty_' + parItem).val();
		var maxQtyTomv = $('.pqty_' + parItem).attr('maxqtytomv');
		var currQty = $('#prmQty_' + parItem).text();
		var queryString = "cItemRefId=" + cId + "&partialQty=" + qty + "&shipType=toImmediateShip" + "&currQty=" + currQty + "&parItem=" + parItem;
		if(qty == '' ) {
			console.log('empty')
			$('#addtoImmediateErrorMsg span').text("Please Enter a valid Quantity");
			$('.customthanku-Wraper .custom-item-details-wrap .skyblueTable thead tr:first-child').addClass('clearspace');
		}
		if (parseInt(maxQtyTomv) < parseInt(qty)) {
		console.log('grater if')
			$('#addtoImmediateErrorMsg span').text("Quantity entered cannot be greater than in stock quantity");
			$('.customthanku-Wraper .custom-item-details-wrap .skyblueTable thead tr:first-child').addClass('clearspace');
			$('.pqty_' + parItem).val('');
			qty = 0;
		} 
		if (qty > 0) {
		console.log('imm ajax calling')
		/*LSCA.loadingSpinner.showLoading();
			$('#addtoImmediateErrorMsg').hide();
			$.ajax({
				type : "POST",
				url : "/common/includes/ajax/checkout-Product-DistUser.jsp?" + queryString,
				dataType : "html",
				cache : false
			}).done(function(data) {
				if (data != null || data != "") {
					$("#cartItemSection").html(data);
					  if($('#immediateOption').val() == 'true'){
							$('tr.custom-immediate').show();
					  }
					LSCA.loadingSpinner.hideLoading();
					jQuery(".checkout-item-right.additional-req .addReqToggle").on('click',function(){
					 jQuery(this).parents('.additional-req').find("textarea").toggle();
					 jQuery(this).toggleClass("showLabel");
					}); 
					jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").prev().addClass("remove-border");
					jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row").each(function(){		
						var colspanVal = jQuery(this).prev().find("td").length;
						jQuery(".checkoutShippingBilling .custom-item-details-wrap > form > .skyblueTable > tbody > tr.promocode-row td").attr("colspan",colspanVal);
					});
				}
			})*/
		} 
	});
	//largeFileOrderReview | type only digits in QTY field
	$(document).on("input",".LFCreview .skyblueTable tbody tr td:first-child input[type='text']",function() {
			$(this).val($(this).val().replace(/[^0-9]/gi,''));
	});		
/*$('input[type=radio][name=delivery]').on('change',function(e) {
	$.ajax({
		type : "POST",
		url : "/common/checkout/ajaxCheckoutShippingMethod.jsp",
		data : {
            deliveryOption : $('input[name="delivery"]:checked').val()
		},
		dataType : "html",
	});
});*/ 
$(document).on("click", "#shipNewAddress", function(e) {
	$('#addShippingPopup #shipAttentionNo').removeClass('requiredTextBox');
	$('#addShippingPopup #shipBuildNo').removeClass('requiredTextBox');
	$('#addShippingPopup #shipBuildNo').attr('style', '');
	$('#addShippingPopup #shipAttentionNo').attr('style', '');
}); 
$(document).on('click', '#cancelEmptyCart', function() {
    $('#cartEmptyPopupClose').trigger('click');
});
$('#deliveryOptionsDiv input[name="delivery"]:not(#DeliveryDate)').on('change',function(e) {
	if(!$('#mainContainer').hasClass('redeemQuoteNew')){	
		LSCA.loadingSpinner.showLoading();
		$.ajax({
			type : "POST",
			url : "/common/checkout/ajaxCheckoutDeliveryMethod.jsp",
			data : {
				deliveryOption : $('#deliveryOptionsDiv input[name="delivery"]:checked').val()
			},
			dataType : "html",
			cache : false,
			success: function(data) {
				console.log(data);			
				 stickyPriceDetails();	
				 if ($("#mainContainer").hasClass("checkoutShippingBilling")) {
					 $(".checkoutShippingBilling #chekoutItemSection .custom-item-details-wrap tr:not(.promocode-row,.last,.grandTotal,.dgMessageSection,.custom-remaining,.custom-immediate,.chinaTC)").each(function() {
						if($(this).attr('data-instockinfo')){
						$(this).find(".custom-estimated-time .custom-instock span.inStockQtyVal").text($(this).attr('data-instockinfo'));
						$(this).find(".custom-estimated-time .custom-estimate .estShipDate").text($(this).attr('data-eststockinfo'));
						$(this).find(".custom-estimated-time p.custom-estimate:nth-child(1)").show();	
						$(this).find(".custom-estimated-time p.custom-estimate:nth-child(2)").show();	
						}
						else if($(this).attr('data-eststockinfo')){
						$(this).find(".custom-estimated-time .custom-estimate .estShipDate").text($(this).attr('data-eststockinfo'));
						$(this).find(".custom-estimated-time").show();
						}
						});
				 }
			},
			error: function() {
				LSCA.loadingSpinner.hideLoading();
				console.log('error');
			}
		});
	}	
});
function deleteShippingAddress(addId){
	$.ajax({type:"POST", url:"/common/checkout/deleteShippingAddress.jsp?addressId="+addId+"&addressType=WEB", dataType:"html"})
	.done(function(msg){
	$("#shipAddContainer").html("");                             
	$('.shipingAddress-wrap #custom-change-shipAddress #newShippingAdd').remove();
	$('.shipingAddress-wrap #custom-change-shipAddress #fullBillingAddress').remove();
		$.ajax({type:"POST", url:"/common/checkout/ajaxFetchDefaultShippingAddress.jsp",dataType:"html"})
		.done(function(msg){
			$('.custom-after-changeshipAddress').show();
			$("#shipAddContainer").html(msg);
			 formdata = $("#dropship").serialize();
				LSCA.globalAjax.doCall({
					url: '/common/checkout/ajaxCheckoutShipping.jsp',
					data: formdata,
					context: $(this),
					target: $(this)
				}, function(data) {
					var msg = data.data;
					if (msg.status == 'success') {
						if($(document).find('.checkoutShippingBilling').length > 0) {
							      stickyPriceDetails();
							 }
					}
				})
	})
	 .fail(function(){console.log('Something went wrong!')});
})
}
makeCreateQuoteDisable = $('#makeCreateQuoteDisable').val();
$(document).ready(function(){
	if(makeCreateQuoteDisable == "true"){
		$("#btnCreateQuote").attr("disabled", "disabled");
	}
	if ($('form#paymnt input[type=radio]').length == 1) {
		$('#purchaseOrder').next().next().css('visibility', 'hidden');
		$("form#paymnt ul li").css('padding-left','0');
	}
});
$(document).on('click', '#sap-order-detail', function() {
	window.location.href = "/common/myaccount/checkOrderStatus.jsp";
});
$(document).on('click', '#web-order-detail', function() {
	window.location.href = "/common/myaccount/checkOrderStatus.jsp";
});
if ($('form#paymnt input[type=radio]').length == 1) {
	$('#purchaseOrder').next().next().css('visibility', 'hidden');
	$("form#paymnt ul li").css('padding-left','0');
}


function isEmptyCheck(elementId){
	var fieldVal = $(elementId).val();
	if(fieldVal == "" || fieldVal === null){
		return true;
	}else {
		return false;
	}
}
function showErrorMessage(elementId){
	$(elementId + 'Err').css('display', 'inline-block');
	$(elementId + 'Lbl').addClass('requiredLabel');
	$(elementId).addClass('requiredTextBox');						
}

function hideErrorMessage(elementId){
	$(elementId + 'Err').hide();
	$(elementId + 'Lbl').removeClass('requiredLabel');
	$(elementId).removeClass('requiredTextBox');
	$(elementId + 'Medical').hide();		
}
function getQuoteParameterByName(name, url) {
	if (!url) url = window.location.href;
	name = name.replace(/[\[\]]/g, '\\$&');
	var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
		results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
$(document).ready(function(){
	$("#triggerForwardQuote").trigger("click");
	$("#forwardQuoteEmail").val("");
	$(".forward-section").hide();
	$("#forwardQuoteForm").show();
	$('#forwardQuoteCancelBtn,#fQCancelBtn').on("click",function() {
        $("#forwardQuote span.newCloseIcon").trigger('click');
		$("#forwardQuote .modal-container").removeClass("FQSecondSection");
		window.location.href=decodeURIComponent($('#mya_referer').text()); 
    });
	$('#forwardQuote .newCloseIcon').on("click",function() {
		window.location.href=decodeURIComponent($('#mya_referer').text()); 
	});
	$('#fQCancelBtn').on("click",function() {
		$(".forward-section").hide();
		$("#forwardQuoteForm").show();
		$("#forwardQuote .modal-container").removeClass("FQSecondSection");
	});
	$("#forwardQuoteEmail").on("keydown",function(e){		
		var keycode = (e.keyCode ? e.keyCode : e.which);
		if (keycode == 13) {
				e.preventDefault();
				$("#submitForwardQuote").trigger("click");
		}
	});
	$("#submitForwardQuote").on("click",function(){
		if (isEmptyCheck('#forwardQuoteEmail')) {
				$('#forwardQuoteEmailErr').text($('#emailValidationEmptyMsg').val());
                showErrorMessage('#forwardQuoteEmail');
                $('#forwardQuoteErrResponse').hide();
            } else {
                hideErrorMessage('#forwardQuoteEmail');
				if ($('#forwardQuoteEmail').val() != '') {
                var mailarr = $('#forwardQuoteEmail').val(), f = true;                                
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
                        f = false;                
                if (!f) {
                    $('#forwardQuoteEmailErr').text($('#emailValidationMsg').val());
                    showErrorMessage('#forwardQuoteEmail');
					$('#forwardQuoteErrResponse').hide();
					//submitForm = false;
				}else{
					LSCA.loadingSpinner.showLoading();
					hideErrorMessage('#forwardQuoteEmail');
					$("#forwardQuoteErrResponse").hide();
					LSCA.globalAjax.doCall({
						url: '/rest/model/com/agilent/commerce/ForwardQuoteService/generateEmailLink?atg-rest-output=json',
						dataType: 'json',
						type:"POST",
						data: {"recipientEmailId": $(".forwardQuote #forwardQuoteEmail").val(),"returnUrl": $(".forwardQuote #returnUrl").val(),"payload": encodeURIComponent($(".payLoadVal").val())},
					}, function(response) {
						LSCA.loadingSpinner.hideLoading();
						if(response.data.success == true){
						/*var senderemail=$(".forwardQuote #forwardQuoteEmail").val();
						var subject=response.data.fwdQuoteEmailSub;
						var generatedLink=response.data.generatedLink;
						var body=response.data.fwdQuoteEmailBody1+"%0d%0a"+encodeURIComponent(generatedLink)+"%0d%0a"+response.data.fwdQuoteEmailBody2;
						var mail = 'mailto:'+senderemail+'?subject='+subject+'&body='+body;
						$("#forwardMailLink").attr("href",mail);
						$("#btnOutlook").trigger("click");*/						
						$(".forward-section").show();
						$("#forwardQuoteForm,.disclaimer-note").hide();
						$("#forwardQuote .modal-container").addClass("FQSecondSection");
						$("#forwardQuoteEmail").val("");
						}
						else{							
							$('#forwardQuoteErrResponse').text(response.data.errorMessages[0].localizedMessage);
							showErrorMessage('#forwardQuoteEmail');
							//$("#forwardQuoteEmail").val("");
							$("#forwardQuoteEmailErr").hide();
							$('#forwardQuoteErrResponse').show();						
							
						}
					
					});
					
				} 
			}
            }
	
	});
	
	
	$("#yesForwardQuote").on("click",function(){
		$(".forward-section").hide();
		$("#forwardQuoteForm,.disclaimer-note").show();
		$("#forwardQuoteEmail").val("");
		$("#forwardQuote .modal-container").removeClass("FQSecondSection");
	});
	
	$(".forwardQuoteInterim #emailId").on('keyup paste', function(e) {
		if($('#emailId').val() == "" && e.keyCode != 13) {
			$(".email-wrapper").removeClass('error-msg');
			$('.email-wrapper .email-error-msg').hide();
		}
	});
	$(".forwardQuoteInterim #emailId").on("keydown",function(e){		
		var keycode = (e.keyCode ? e.keyCode : e.which);
		if (keycode == 13) {
			e.preventDefault();
			$(".forwardQuoteInterim #emailSubmit").trigger("click");
		}
	});
	$('.forwardQuoteInterim #emailSubmit').on('click', function(e){
		var emailCheck = true;
		if($('#emailId').val() == ""){
			$(".email-wrapper").addClass('error-msg');
			$('.email-wrapper .email-required-msg').show();
			$(".forwardQuoteInterim .msg-stnd.errStnd,.email-wrapper .email-error-msg").hide();
			emailCheck = false;	
		}
		else {
			var mailarr = $('#emailId').val(), f = true;                                
			if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(mailarr))))
					f = false;                
			if (!f) {
				$(".email-wrapper").addClass('error-msg');
				$('.email-wrapper .email-error-msg').show();
				$(".forwardQuoteInterim .msg-stnd.errStnd,.email-wrapper .email-required-msg").hide();
				emailCheck = false;
			}else{
				$(".email-wrapper").removeClass('error-msg');
				$('.email-wrapper .email-error-msg,.email-wrapper .email-required-msg').hide();
				emailCheck = true;
				$("#hiddenSubmit").trigger("click");
			} 
		}
	});
	
	
});


function setPageHeightFn() {
	if ($(window).width() > 767) {
		var headerHtVal = $('.atgHeaderDiv').outerHeight(true);
		var footerHtVal = $('.atgFooterDiv').outerHeight(true);
		if ($("body").hasClass("addMargin")) {
			var cookieHeightVal = $("#onetrust-banner-sdk").outerHeight(true);
			var setHeightVal = headerHtVal + footerHtVal + cookieHeightVal;
			$("body #mainContainer.mainContainer.forwardQuote,body #mainContainer.mainContainer.forwardQuoteInterim").css("min-height", "calc(100vh - " + setHeightVal + "px)");
		} else {
			var setHeightVal = headerHtVal + footerHtVal;
			$("body #mainContainer.mainContainer.forwardQuote,body #mainContainer.mainContainer.forwardQuoteInterim").css("min-height", "calc(100vh - " + setHeightVal + "px)");
		}
	}
}

$(window).on("load", function() {
    setPageHeightFn();
});
$(document).on("click", "#onetrust-banner-sdk #onetrust-accept-btn-handler", function(){
	 setTimeout(function() {
		setPageHeightFn();
	 }, 500);
});
$(window).on("resize", function() {
    setPageHeightFn();
});
