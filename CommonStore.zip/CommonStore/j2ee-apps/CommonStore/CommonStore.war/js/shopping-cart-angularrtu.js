var shoppingCartApp = angular.module('shoppingCartApp', ['ngSanitize']);
couponPromoStatus = '';
recommendedAddStatus = '';
cartItemUpdated = false;
singleAddStatus = '';
addToCartSuccess = false;

// Constant Declaration
shoppingCartApp.constant('RESOURCES', {
    CART_ORDER_URL:
        '/rest/model/com/agilent/commerce/CartDetailsService/cartDetails?atg-rest-output=json',
    ADD_TO_CART_ORDER_URL:
        '/rest/model/com/agilent/commerce/AddToCartService/addItemtoCart?atg-rest-output=json',
    REMOVE_ITEM_URL:
        '/rest/model/atg/commerce/order/purchase/CartModifierActor/removeItemFromOrder?atg-rest-output=json',
    QUANTITY_UPDATE_URL:
        '/rest/model/atg/commerce/order/purchase/CartModifierActor/updateCommerceItemQuantity?atg-rest-output=json',
    DESIGN_DETAIL_UPDATE_URL:
        '/rest/model/atg/commerce/order/purchase/CartModifierActor/updateDesignDetailsToCart?atg-rest-output=json',
    APPLY_PROMO_URL:
        '/rest/model/com/agilent/commerce/ApplyPromo/claimCoupon?atg-rest-output=json',
    APPLY_READYTO_US_PROMO_URL:
        '/rest/model/com/agilent/commerce/ApplyPromo/validateCoupon?atg-rest-output=json',
    CART_SAVE_LATER:
        '/rest/model/com/agilent/commerce/SaveForLaterService/getSFLItems?atg-rest-output=json',
    CART_SAVE_LATER_PRODUCT_DESCRIPTION_IMAGE:
        '/rest/model/com/agilent/commerce/SaveForLaterService/fetchDataGridPrdDetails?atg-rest-output=json&productId=',		
	CART_SAVE_LATER_PRICE:
		'prdDetailSrchJSON.jsp?catalogIds=',
	CART_SAVE_LATER_ADD:
		'/rest/model/com/agilent/commerce/SaveForLaterService/moveItemsFromCartToSFL?atg-rest-output=json',		
	CART_SAVE_LATER_REMOVE:
		'/rest/model/com/agilent/commerce/SaveForLaterService/removeItemsFromSFL?atg-rest-output=json'		
//	CART_SAVE_LATER_PRICE1:
//      'js/prdDetailSrchJSON.json'		
});

// Controller
shoppingCartApp.controller('ShoppingCart', function(
    cartHttpService,
    cartUtilityService,
    $window,
    RESOURCES,
    $scope
) {
    var AgilentName = 'Agilent Technologies';
    var vm = this;
    vm.addQuantity = addQuantity;
    vm.cartErrorMessage = '';
    vm.cartItems = [];
	vm.saveForLaterItems = [];
    vm.cartItemsCount = 0;
	vm.saveForLaterCount = 0;
    vm.errorFlag = false;
    vm.getOrderDetails = getOrderDetails;
	vm.getsaveForLater = getsaveForLater;
	vm.getSFLPrice = getSFLPrice;
    vm.showUpdate = showUpdate;
    vm.redirectProducts = redirectProducts;
    vm.removeItem = removeItem;
	vm.removeSFLItem = removeSFLItem;
	vm.addSFLItem = addSFLItem;
	vm.movetoCart = movetoCart;
    vm.removeQuantity = removeQuantity;
    vm.updateQuantity = updateQuantity;
    $scope.PromoInfoMsg = '';
	//$scope.rtuFlagVal=$("#rtuCart").val();

    vm.getOrderDetails();
	if($('#enableSFL').val() == 'true' && $('.savedForLater ').length){
		vm.getsaveForLater();	
	}	
    $scope.stateOrderdetails = function(event) {
        var stateId = event.currentTarget.id;
        var CNstate = event.currentTarget.innerText;
        var CNstaeName = CNstate.replace(/\s/g, '');
        var urlParam = RESOURCES.CART_ORDER_URL + '&&lastOrderShipStateAddr=' + stateId;
        cartHttpService.getStateOrderDetailsService(urlParam).then(
            function(orderData, status) {
				$('#successMessages_outer').hide();
                $('.SelectedState').text(CNstaeName);
                $('#select_state_shopping_cart').hide();
				var callback = getOrderSuccess();
                callback(orderData, status);
            },
            function(error) {
                console.error('Some error occured in get order details');
				$('.loading').hide();
            }
        );
    };

    $scope.addtoFavDiv = function(event) {
        LSCA.favoriteShoppingUpdateItem.init({
            pageid: 'shoppingCartPage',
            url: '/store/includes/ajax/ajaxRemoveGiftListItem.jsp?skuId=',
            url2: '/store/includes/ajax/ajaxAddToMyCatalog.jsp?part_number=',
            target: '#addFavSection',
            partData: event.currentTarget.id
        });
    };

    // fetch order details
	function getOrderDetails(addToCartItem) {
        cartHttpService.getOrderDetailsService().then(getOrderSuccess(addToCartItem), function (error) {
            console.error('Some error occured in get order details');
			$('.loading').hide();
        })
    };
	function getOrderSuccess(addToCartItem) {
        return function(orderData, status) {
            $scope.PromoInfoMsg = orderData.data.getCartDetailsResponse.PromoInfoMsg;
			$scope.PromoSuccessMsg = orderData.data.promoSuccessMsg;
			$scope.PromoErrorMsg = orderData.data.promoErrorMsg;
            if ($scope.PromoInfoMsg) {
                $('#restorePromoMessage').removeClass('cart-hide').show();
            } else {
				$('#restorePromoMessage').hide();
			}
			 if ($scope.PromoSuccessMsg) {
				 $("#promoSuccessMessage span").html($scope.PromoSuccessMsg);
                $('#promoSuccessMessage').removeClass('cart-hide').show();
            } else {
				$('#promoSuccessMessage').hide();
			}
			 if ($scope.PromoErrorMsg) {
				  $("#promoErrorMessage span").html($scope.PromoErrorMsg);
                $('#promoErrorMessage').removeClass('cart-hide').show();
            } else {
				$('#promoErrorMessage').hide();
			}
			if(orderData.data.getCartDetailsResponse.SFLPartNumberMessage){
				$('.savedForLater-info p.multi-partinfo').html(orderData.data.getCartDetailsResponse.SFLPartNumberMessage)
				$("#savedforlatermodal").modal('show');	
				vm.getsaveForLater();
			}
            buildCartList(orderData, addToCartItem);

            cartUtilityService.showContent();
            // Show cart count in global navigation pane
            var totalCartCount = vm.cartItemsCount = vm.cartItems.cartcount;
            showCartCount(totalCartCount);
            
            if(vm.cartItems.ppsDakoProduct == "true"){						
				$(".pps-store-msg").show();
				$(".pps-store-msg").addClass("showpps-store-msg");
			}
			else{	
				$(".pps-store-msg").removeClass("showpps-store-msg");
				if(!$(".pps-store-msg").hasClass("showpps-store-msg")){
					$(".pps-store-msg").hide();
				}
			}
            // handle all alerts when getting order list
            handleGetOrderListError();

            // Recommendation
            if (typeof getRcommendedProduct === 'function') {
                getRcommendedProduct(vm.cartItems);
            }

            (function(i) {
                var checkRecommendedPartNo = function() {
                    if (recommendedAddStatus) {
                        cartItemUpdated ? addToCartRecommended(Object.keys(vm.cartItems.lineItems)) : setTimeout(checkRecommendedPartNo, 1000);
                    }
                }
                checkRecommendedPartNo();
            })(1);

            if (addToCartSuccess) {
                $scope.successPart = true;				
                $('#successMessagesPage_outer').show();
                $('html, body').animate({ scrollTop: 0 }, 'slow');
                addToCartSuccess = false;
            }
			LSCA.loadingSpinner.hideLoading();
        }
    }
    
    function buildCartList(orderData, addToCartItem) {
        vm.cartItems = angular.copy(
            orderData.data.getCartDetailsResponse
        );
        cartItemUpdated = recommendedAddStatus === 'true';
        var newCartItems = [];
        vm.cartItems.itemOrder.forEach(function(itemKey, index) {
            
            var cartItem = vm.cartItems.lineItems[itemKey];
            cartItem['skuType'] = cartItem.customArraySkuType === 'Restricted' || cartItem.customArraySkuType === 'UnRestricted' ? 'WithDesignID' : 'WithoutDesignID';
            cartItem['itemToUpdate'] = {
                designDetails: [],
                designIdCount: 1,
                partNumber: cartItem.partNumber
            };
            if (cartItem.skuType === 'WithDesignID') {
                cartItem = initWithDesignId(cartItem);
            }
            newCartItems.push(cartItem);
            // Add a new cart item after updation
            if(addToCartItem && addToCartItem.partNumber === cartItem.partNumber) {
                addQuantity(cartItem);
            }
        });
        vm.cartItems['newCartItems'] = sortCartItems(newCartItems, vm.cartItems.itemOrder);

    }
    function buildSFLCartList() {
        var newCartItems = [];
        vm.saveForLaterItems.itemOrder.forEach(function(itemKey, index) {            
            var cartItem = vm.saveForLaterItems.lineItems[itemKey];
            cartItem['skuType'] = cartItem.customArraySkuType === 'Restricted' || cartItem.customArraySkuType === 'UnRestricted' ? 'WithDesignID' : 'WithoutDesignID';
            cartItem['itemToUpdate'] = {
                designDetails: [],
                designIdCount: 1,
                partNumber: cartItem.partNumber
            };
            if (cartItem.skuType === 'WithDesignID') {
                cartItem = initWithDesignId(cartItem);
            }
            newCartItems.push(cartItem);
        });
        vm.saveForLaterItems['newCartItems'] = sortCartItems(newCartItems, vm.saveForLaterItems.itemOrder);
    }
    function initWithDesignId(cartItem) {
        var qunaityIdCount = 1,cItemDesignListObjFlag=false;
        var tempDesignDetails = [];
        angular.forEach(cartItem.cItemDesignList, function(quantity, designId) {					
			if(designId == "emptyDes"){
				cItemDesignListObjFlag=true;
			}
		});	
        if(!$.isEmptyObject(cartItem.cItemDesignList) && !cItemDesignListObjFlag) {
        	angular.forEach(cartItem.cItemDesignList, function(quantity, designId) {
				var guideName = '', guideNameObj=cartItem.guideDetails,cannotEdit=false,titleText="",designIdHide=false;
				if(designId!==""){
					designIdHide=true;
				}				
				for (var key in guideNameObj) {					
					if(designId == key){
						guideName =guideNameObj[key];
					}
				}				
				if(guideName==""){
					cannotEdit=true;
				}
				titleText = designId + ' ' + guideName;	
                tempDesignDetails.push({
                    designId: designId,
                    quantity: quantity,
					cannotEditFlag:cannotEdit,
					designIdHideFlag:designIdHide,
					guidename:guideName,
					guidenametruncate:truncateText(titleText, 14),
					titleText:titleText,
                    itemId: cartItem.partNumber + '-' + qunaityIdCount,
                    itemNumber: qunaityIdCount,
                    status: 'existing'
                });
                cartItem.itemToUpdate.designIdCount = qunaityIdCount++;
            });
            cartItem.itemToUpdate.designDetails = tempDesignDetails.sort(function(item, next) {
                return item.designId > next.designId ? 1 : item.designId < next.designId ? -1 : 0;
            });
        } else {
            cartItem.itemToUpdate = {
                designDetails: [{
                    designId: '',
                    quantity: cartItem.Qty,
                    cannotEditFlag:true,
                    itemId: cartItem.partNumber + '-' + qunaityIdCount,
                    itemNumber: qunaityIdCount,
                    status: 'new'
                }],
                designIdCount: qunaityIdCount,
                partNumber: cartItem.partNumber
            };
        }
        if (cartItem.customArraySkuType === 'UnRestricted') {
            var itemId = 0;
            cartItem.designIdList.forEach(function(item) {
                item['itemId'] = ++itemId;
                item['selectLabel'] = truncateText(item.description + ' ' + item.designId, 16);
                item['id'] = cartItem.partNumber + '-' + item['itemId'];
            });
        }
        return cartItem;
    }
	// fetch save for later
	function getsaveForLater() {
        cartHttpService.getSaveForLaterService().then(getSaveLaterSuccess(), function (error) {
            console.error('Some error occured in get save for later details');
        })
    };	
	var getSFLproductsList = [];
	var getSFLproductsListprice = [];
	function getSaveLaterSuccess() {
		getSFLproductsList = [];
		getSFLproductsListprice = [];
		 return function(orderData) {
			vm.saveForLaterItems = angular.copy(
				orderData.data
			);	
			angular.forEach(vm.saveForLaterItems.lineItems, function(value, key) {
			  this.push(key+'&sOrg='+value.salesOrg)
			}, getSFLproductsListprice);			
			angular.forEach(vm.saveForLaterItems.lineItems, function(value, key) {
			  this.push(key)
			}, getSFLproductsList);		
			//getSFLproductsListprice = getSFLproductsListprice.toString();			
			if(vm.saveForLaterItems.itemsCount != 0){
				getSFLproductsListDI = getSFLproductsList.toString();
				getSFLProductDescImage(getSFLproductsListDI);							
			}else{
				$('.savedForLater').show();
			}	
			
		 }
	}
	// fetch save for later description and images
	function getSFLProductDescImage(getSFLproductsList) {
        cartHttpService.getSFLProductDescImageService(getSFLproductsList).then(getSaveLaterProdcutImageSuccess(), function (error) {
            console.error('Some error occured in get save for later description and images details');
			$('.loading').hide();
        })
    };		
	function getSaveLaterProdcutImageSuccess() {
		 return function(orderData) {
			Object.keys(vm.saveForLaterItems.lineItems).map(function (partNumber) {
			  if (orderData.data.ProductDesc.hasOwnProperty(partNumber)) Object.assign(vm.saveForLaterItems.lineItems[partNumber], orderData.data.ProductDesc[partNumber]);
			});	
			buildSFLCartList();				
			$('.savedForLater').show();
			//getSFLPrice(getSFLproductsListprice);	
			for(i=0;i<getSFLproductsListprice.length;i++){
				getSFLPrice(getSFLproductsListprice[i]);	
			}		
			$scope.sflobsoletepartno = []	
		 }
	}	
	// fetch save for later price
	function getSFLPrice(getSFLproductsListprice) {
		//console.log('getSFLPrice started: '+getSFLproductsListprice)		
        cartHttpService.getSFLPriceService(getSFLproductsListprice).then(getSFLPriceSuccess(), function (error) {
            console.error('Some error occured in get save for later pricing details');
			$('.shopping-cart-spa .stock-details,.shopping-cart-spa .item-price').removeClass('loadingspinner');
			//$('.loading').hide();
        })
    };	
 	function getSFLPriceSuccess() {
		 return function(orderData) {		 
			Object.keys(vm.saveForLaterItems.lineItems).map(function (partNumber) {
			  if (orderData.data.hasOwnProperty(partNumber)) 
				{
					Object.assign(vm.saveForLaterItems.lineItems[partNumber], orderData.data[partNumber]);					
					$scope.sflProductEnabled = vm.saveForLaterItems.lineItems[partNumber].productEnabled;
					$scope.sflproductEntitlement = vm.saveForLaterItems.lineItems[partNumber].productEntitlement;
					$scope.sflYourPrice = vm.saveForLaterItems.lineItems[partNumber].yourPrice;
					if($scope.sflYourPrice != ""){
					$scope.sflYourPrice = (vm.saveForLaterItems.lineItems[partNumber].yourPrice).match(/\d/g);
					$scope.sflYourPrice = $scope.sflYourPrice[0];
					}else{
						$scope.sflYourPrice == 0
					}
					$scope.sfllistPrice = vm.saveForLaterItems.lineItems[partNumber].listPrice;
					if($scope.sfllistPrice != ""){
					$scope.sfllistPrice = (vm.saveForLaterItems.lineItems[partNumber].listPrice).match(/\d/g);
					if($scope.sfllistPrice != null){
                        $scope.sfllistPrice = $scope.sfllistPrice[0];
                    }else{
                        $scope.sfllistPrice = 0
                    }
					}else{
						$scope.sfllistPrice == 0
					}
					if($('#eCommStatus').val() == 'SAP'){					
						$scope.sflPriceCheck = $scope.sflYourPrice;
					}else{
						$scope.sflPriceCheck = $scope.sfllistPrice;
					}
					$scope.sflErrorMsg = vm.saveForLaterItems.lineItems[partNumber].errorMessage;
					$scope.sflpartNumber = vm.saveForLaterItems.lineItems[partNumber].partNumber;
					$scope.sflgiftItemId = vm.saveForLaterItems.lineItems[partNumber].giftItemId;					
					if($scope.sflProductEnabled == false || $scope.sflproductEntitlement == true){	
						if($scope.sflErrorMsg != '' && $scope.sflPriceCheck == 0 ){	
							for(i=0;i<vm.saveForLaterItems.itemOrder.length;i++){
								if($scope.sflpartNumber == vm.saveForLaterItems.itemOrder[i]){								
									removeSFLItem($scope.sflgiftItemId,i) 
									$scope.sflobsoletepartno.push($scope.sflpartNumber);
									$scope.globalErr = new Array(									
										($scope.sflobsoletepartno.toString()).replace(/[,]/g, ', ') +' '+ $('#errorSFLErrorField').val()
									);
									$('#erroeMessages_outer').show();
									$('html, body').animate({ scrollTop: 0 }, 'slow');																	
								}
							}
						}
					}										
				}

			});					
		 }
	}
    function handleGetOrderListError() {
        $('.newAlert').hide();
        $('#maxLimit-messages').hide();
        var $errorMessagesOuter = $('#erroeMessages_outer');
        if (!$.isEmptyObject(vm.cartItems.errorMessages)) {
            var errorMessages = vm.cartItems.errorMessages;
            if (errorMessages.length > 0) {
                $scope.errorpart = true;
                $('.serviceError').html(errorMessages);
                addToCartSuccess = false;
                $errorMessagesOuter.show();
                $('html, body').animate({ scrollTop: 0 }, 'slow');
            }
        }
        if (vm.errorFlag === true) {
            $('#orderCenterErrorMsg div').css('display', 'none');
            $errorMessagesOuter.show();
            vm.errorFlag = false;
        }
    }

    function showCartCount(totalCartCount) {
        // if it is cart page add total item count
        if (
            $('#main-wrapper-shopping-cart').hasClass(
                'shoppingCartWrapper'
            )
        ) {
            $('.globalHeadernav .cartItem.cartNum').text(
                totalCartCount
            );
        }
    }

    function sortCartItems(cartItems, order) {
        var rearrangedCartItems = [];
        order.forEach(function(cartItemKey) {
            if (cartItems.hasItOwn)
            rearrangedCartItems.push(cartItemKey)
        });
        return cartItems;
    }

    function validateQuanity(cartItem, designDetail) {
        var status = true;
        if (cartItem.skuType === 'WithDesignID') {
            var elQuantity = $('#qty-' + designDetail.itemId);
            designDetail.quantity = designDetail.quantity && designDetail.quantity.toString().replace(/[^0-9]/gi, '');

            // Check quantity has any value in quantity
            if (cartUtilityService.isNonZeroValue(designDetail.quantity)) {
                elQuantity.removeClass('requiredTextBox');
                $("#qtyErrorMessage-" + designDetail.itemId).text('').hide();
            } else {
                status = false;
            }
        } else {
            var elQuantity = $('#qty-' + cartItem.partNumber);
            cartItem.Qty = cartItem.Qty.replace(/[^0-9]/gi, '');

            if (cartItem.Qty != '') {
                elQuantity.removeClass('requiredTextBox');
                angular.element('#cartErrorMessage').hide();
                vm.cartErrorMessage = '';
            } else {
                elQuantity.find('.cart-quantity .cart-hide').hide();
                status = false;
            }
        }
        return status;
    }

    function validateDesignId(cartItem, designDetail) {
        if (cartItem.skuType === 'WithoutDesignID') {
            return 'Success';
        }
        if (cartItem.customArraySkuType === 'Restricted' && designDetail.designId.length > 8) {
            //designDetail.designId = designDetail.designId.substr(0, 8);
            if(cartItem.crisprInd == false){
                designDetail.designId = designDetail.designId.substr(0, 8);
			}
			else{
				designDetail.designId = designDetail.designId;
			}
        }
        var status = 'Success';
        var elDesignIDList = $("#designIDList-" + designDetail.itemId);
        if (cartUtilityService.isNonZeroValue(designDetail.designId)) {
            var elDesignIDError = $("#designIDErrorMessage-" + designDetail.itemId);
            var pattern = /[a-zA-Z0-9 -]+/g;
            var cartItemDesignId = designDetail.designId.match(pattern);
            cartItemDesignId = cartItemDesignId ? cartItemDesignId.join('') : cartItemDesignId;
            if (cartItemDesignId !== designDetail.designId) {
                status = 'NoSpecialChar';
                designDetail.designId = cartItemDesignId;
            } else {
                elDesignIDList.removeClass('requiredTextBox');
                elDesignIDError.text("").hide();
            }
        } else {
            status = 'Required';
        }
        return status;
    }
    
    function showUpdate(cartItem, designDetail, field) {
        couponPromoStatus = '';
        //cleaning globalmessages messages
        $scope.globalSuccess = '';
        $('#successMessages_outer').hide();
        $('#successMessagesPage_outer').hide();
        var elUpdateLink = $('#updateLink-' + cartItem.partNumber);
        elUpdateLink.hide();

        var isValidQuantity = validateQuanity(cartItem, designDetail);
        var designIdStatus = validateDesignId(cartItem, designDetail);
        var hasError = false;

        angular.forEach(cartItem.designDetails, function(item, index) {
            var isValdiQty = validateQuanity(cartItem, item);
            var designStatus = validateDesignId(cartItem, item);
            if (!isValdiQty || designStatus !== 'Success') {
                hasError = true;
            }
        });

        if (designIdStatus === 'Success' && isValidQuantity && !hasError) {
            elUpdateLink.show();
            return false;
        }

        if (field === 'quantity' && !isValidQuantity) {
            var elQuantity = $('#qty-' + designDetail.itemId);
            $scope.globalErr = '';
            $('#erroeMessages_outer').hide();
            showQuantityError(cartItem, designDetail, elQuantity);
        }
        if(field === 'designId' && designIdStatus !== 'Success') {
            showDesignIdError(cartItem, designDetail, designIdStatus);
        }
    }

    function showQuantityError(cartItem, designDetail, element) {
        var errValidString = $('#invalidNumErr').val();
        if (cartItem.customArraySkuType && cartItem.customArraySkuType === 'UnRestricted' || cartItem.customArraySkuType === 'Restricted') {
            $("#qtyErrorMessage-" + designDetail.itemId).text(errValidString).show();
        } else {
            vm.cartErrorMessage = errValidString;
            $('#cartErrorMessage').show();
            cartUtilityService.scrollPageTop();
        }

        element.addClass('requiredTextBox');
    }

    function showDesignIdError(cartItem, designDetail, errorStatus) {
        $("#designIDList-" + designDetail.itemId).addClass('requiredTextBox');
        switch(errorStatus) {
            case 'NoSpecialChar': {
                $("#designIDErrorMessage-" + designDetail.itemId).text($("#designIdNoSpecialCharLabel").val()).show();
            } break;
            case 'Required': {
                $("#designIDErrorMessage-" + designDetail.itemId).text(
                    $(cartItem.customArraySkuType === 'UnRestricted' ? "#selectDesignIdRequired" : "#designIdRequiredLabel").val()
                ).show();
            } break;
        }
    }

    function redirectProducts() {
        if(window.location.hostname == "stgwww.cos.agilent.com") {
            location.href = "//stgwww.agilent.com/en/products";
        }
        else {
            $window.location = '/en-us/products';
        } 
    }
	$scope.isActiveDeleteSFL = function(item) {
        return $scope.deleteSFLselected === item;
	};	
    function removeSFLItem(item,index,isdelete) {
		$scope.globalErr = '';	
		$('#erroeMessages_outer,#successMessages_outer,#successMessagesPage_outer,#orderCenterErrorMsg div,#restorePromoMessage').hide();
		if(isdelete){
			$('.savedForLater .cartAction-section').addClass('disable')	
			$scope.deleteSFLselected = item; 					
		}	
        if (!$.isEmptyObject(item)) {			
			var itemarr = new Array(item)			
            var itemToRemove = {removeGiftitemIds:itemarr}
            cartHttpService.SFLremoveService(itemToRemove).then(
                function(success) {   					
                    if (success.data.success) {
						vm.saveForLaterItems.newCartItems.splice(index, 1)	
						$('.savedForLater .cartAction-section').removeClass('disable')				
						vm.saveForLaterItems.itemsCount = vm.saveForLaterItems.itemsCount - 1;							
						$('.savedForLater .cart-action + .cart-action').removeClass('loadingspinner')	
                    } else {        
						$scope.deleteSFLselected = 	undefined;		
						$scope.globalErr = new Array(
							success.data.errorMessages[0].localizedMessage
						);
						$('#erroeMessages_outer').show();
						$('html, body').animate({ scrollTop: 0 }, 'slow');					
						$('.loading').hide();
						$('.savedForLater .cartAction-section').removeClass('disable')	
						$('.savedForLater .cart-action + .cart-action').removeClass('loadingspinner')	
                    }
                },
                function(error) {					
                   console.error('Some error occured in remove SFL item');
					$('.loading').hide();
					$scope.deleteSFLselected = 	undefined;		
					$('.savedForLater .cartAction-section').removeClass('disable')	
					$('.savedForLater .cart-action').removeClass('loadingspinner')						
                }			
			);
        }		
	}	
	 $scope.isActive = function(item) {
        return $scope.SFLselected === item;
	};
    function addSFLItem($event,item) {	
		couponPromoStatus = '';
		$event.preventDefault();
		$scope.SFLselected = item;	
		console.log($scope.SFLselected)
		$scope.globalErr = '';
		if(item.Qty >= 1){
		  iQty = item.Qty 	
		}else{
		  iQty = 1	
		}		
		$('#erroeMessages_outer,#successMessages_outer,#successMessagesPage_outer,#orderCenterErrorMsg div,#cartErrorMessage,#restorePromoMessage').hide();
		var itemSFLadd = {
			itemIds: item.commerceItem,
			quantity: iQty	
		};		
		cartHttpService
            .SFLaddService(RESOURCES.CART_SAVE_LATER_ADD, itemSFLadd)
            .then(
                function(success) {   					
                    if (success.data.success) {
						vm.getOrderDetails();
						vm.getsaveForLater(); 					
                    } else {    
						$scope.SFLselected = undefined;
						$scope.globalErr = new Array(
							success.data.errorMessage
						);
						$('#erroeMessages_outer').show();
						$('html, body').animate({ scrollTop: 0 }, 'slow');					
						$('.loading').hide();
						$('.shopping-cart-spa .cart-action').removeClass('loadingspinner')
                    }
                },
                function(error) {					
                    console.error('Some error occured while adding your item to SFL');	
					$('.shopping-cart-spa .cart-action').removeClass('loadingspinner')
					$('.loading').hide();
					$scope.SFLselected = undefined;
                }
            );		
	}		
    function removeItem(selectedItem) {
        couponPromoStatus = '';
        //cleaning globalmessages messages
        $('#erroeMessages_outer').hide();
        $scope.globalErr = '';
        $('#successMessages_outer').hide();
        $('#successMessagesPage_outer').hide();
        $scope.globalSuccess = '';

        //Added code for Google Analytics
        $('#itemQty').val(selectedItem.Qty);
        $('#prodDesc').val(selectedItem.description);
        $('#itemPrice').val(selectedItem.listPrice);
        $('#categoryName').val(selectedItem.commerceItem);
        $('#partNumber').val(selectedItem.partNumber);
        $('#categoryId').val(selectedItem.orderId);
        $('#prodVarient').val(selectedItem.productLine);
        trackRemoveItemfromCartGA();
        // END Added code for Google Analytics
        if (!$.isEmptyObject(selectedItem)) {
            var itemToRemove = {
                removalCommerceIds: selectedItem.partNumber,
                restCall: 'true'
            };
            angular.element('#cartErrorMessage').hide();
            LSCA.loadingSpinner.showLoading();
            cartHttpService.removeItemService(itemToRemove).then(
                function(removeResult, status) {
                    if (!$.isEmptyObject(removeResult.data.errorMessage)) {
                        vm.cartErrorMessage =
                            removeResult.data.errorMessage[0].localizedMessage;
                        angular.element('#cartErrorMessage').show();
                        LSCA.loadingSpinner.hideLoading();
                    } else {
                        vm.cartErrorMessage = '';
                        angular.element('#cartErrorMessage').hide();
                        vm.getOrderDetails();
                    }
                },
                function(handleError) {
                    console.error('Some error occured in remove item');
                    LSCA.loadingSpinner.hideLoading();
                });
        }
    }

    function updateQuantity(selectedItem, newField) {
		var isDesignDetail = selectedItem.itemToUpdate && !$.isEmptyObject(selectedItem.itemToUpdate['designDetails']);
        couponPromoStatus = '';
        addToCartSuccess = false;
        $('#erroeMessages_outer').hide();
        $scope.globalErr = '';
        if (!cartUtilityService.isNonZeroValue(selectedItem.Qty)) {
            return false;
        }
        selectedItem.itemToUpdate.designIdCount = selectedItem.itemToUpdate.designDetails.length;
        var itemToUpdate = isDesignDetail ? selectedItem.itemToUpdate : {
            partNumber: selectedItem.partNumber,
            quantity: selectedItem.Qty
        };
        $('#cartErrorMessage').hide();
        
        var updateService = isDesignDetail ? 'updateDesignDetailService' : 'updateQuantityService';
        cartHttpService[updateService](itemToUpdate).then(
            function(updateResult, status) {
                if (updateResult.data.success === true) {
                    angular.element('#cartErrorMessage').hide();
                    vm.cartErrorMessage = '';
                    angular
                        .element('#updateLink-' + selectedItem.partNumber)
                        .hide();
                        newField ? vm.getOrderDetails(selectedItem) : vm.getOrderDetails();
                } else {
                    if (!$.isEmptyObject(updateResult.data.errorMessages)) {
                        if (vm.cartItemsCount == 1) {
                            vm.errorFlag = true;
                            $scope.globalErr =
                                updateResult.data.errorMessages[0];
                            $('.update-qty').html(
                                updateResult.data.errorMessages[0]
                            );
                            newField ? vm.getOrderDetails(selectedItem) : vm.getOrderDetails();
                        } else {
                            vm.cartErrorMessage =
                                updateResult.data.errorMessages[0];
                            angular.element('#cartErrorMessage').show();
                        }
                    }
                }
            },
            function(handleError) {
                console.error('Some error occured in remove item');
				$('.loading').hide();
            }
        );
    }

    // Add quantity for Cart item with design ID
    var cartQuantityMaxLimit = 6;
    function addQuantity(cartItem) {
        if($('#updateLink-' + cartItem.partNumber).is(':visible')) {
            vm.updateQuantity(cartItem, true);
            return false;
        }
        cartItem.itemToUpdate.designIdCount += 1;
        cartItem.itemToUpdate.designDetails.push({
            designId: '',
            quantity: 1,
            cannotEditFlag:true,
            itemId: cartItem.partNumber + '-' + cartItem.itemToUpdate.designIdCount,
            itemNumber: cartItem.itemToUpdate.designIdCount,
            status: 'new'
        });
        var cartItemCount = cartItem.itemToUpdate.designDetails.length;
        if (!!cartItem.designIdList && cartItemCount >= cartItem.designIdList.length || cartItemCount >= cartQuantityMaxLimit) {
            $('#addQuantityButton-' + cartItem.partNumber).hide();
        }
    }

    // Remove quantity for Cart item with design ID
    function removeQuantity(cartItem, designDetail) {
        var ind = -1;
        cartItem.itemToUpdate.designDetails.some(function(item, i) {
            if (item.itemId === designDetail.itemId) {
                ind = i;
                return true;
            }
        });
        cartItem.itemToUpdate.designDetails.splice(ind, 1);
        var cartItemCount = cartItem.itemToUpdate.designDetails.length;
        if ((cartItem.designIdList && cartItemCount < cartItem.designIdList.length) || cartItemCount < cartQuantityMaxLimit) {
            $('#addQuantityButton-' + cartItem.partNumber).show();
        }
        if (designDetail.status !== 'new') {
            updateQuantity(cartItem);
        }
    }

    /**
     * Start - Google Analytics add to cart recommendation
     */
    function addToCartRecommended(lineItemKeys) {
        if (
            recommendedAddStatus == 'true' &&
            lineItemKeys.length > 0 &&
            $scope.recommendedQty != undefined
        ) {
            recommendedAddStatus = '';
            cartItemUpdated = false;
            var cartRecommendationAnalytics = { };
            cartRecommendationAnalytics.cartQty = $scope.recommendedQty;
            $scope.recommendedPartNo = $scope.recommendedPartNo.toUpperCase();
            cartRecommendationAnalytics.prodDesc =
                vm.cartItems.lineItems[$scope.recommendedPartNo] ? vm.cartItems.lineItems[$scope.recommendedPartNo][
                    'description'
                ] : '';
            cartRecommendationAnalytics.prodPrice =
            vm.cartItems.lineItems[$scope.recommendedPartNo] ? vm.cartItems.lineItems[$scope.recommendedPartNo][
                    'listPrice'
                ] : '';
            cartRecommendationAnalytics.categoryName =
            vm.cartItems.lineItems[$scope.recommendedPartNo] ? vm.cartItems.lineItems[$scope.recommendedPartNo][
                    'commerceItem'
                ] : '';
            cartRecommendationAnalytics.currencySymbol =
                vm.cartItems.orderPriceInfo['currencyCode'];
            cartRecommendationAnalytics.cartPNo =
            vm.cartItems.lineItems[$scope.recommendedPartNo] ? vm.cartItems.lineItems[$scope.recommendedPartNo][
                    'partNumber'
                ] : '';
            cartRecommendationAnalytics.catId = vm.cartItems['orderId'];
            cartRecommendationAnalytics.productLine =
            vm.cartItems.lineItems[$scope.recommendedPartNo] ? vm.cartItems.lineItems[$scope.recommendedPartNo][
                    'productLine'
                ] : '';
            recommendedAddtoCartGA(cartRecommendationAnalytics);
        }

        if (
            singleAddStatus == 'true' &&
            lineItemKeys.length > 0 &&
            $scope.qtyNo != undefined
        ) {
            singleAddStatus = '';

            var cartQty = $scope.qtyNo;
            $scope.partNo = $scope.partNo.toUpperCase();
            var prodDesc =
            vm.cartItems.lineItems[$scope.partNo] ? vm.cartItems.lineItems[$scope.partNo]['description'] : '';
            var prodPrice =
            vm.cartItems.lineItems[$scope.partNo] ? vm.cartItems.lineItems[$scope.partNo]['listPrice'] : '';
            var categoryName =
            vm.cartItems.lineItems[$scope.partNo] ? vm.cartItems.lineItems[$scope.partNo]['commerceItem'] : '';
            var currencySymbol =
                vm.cartItems.orderPriceInfo['currencyCode'];
            var cartPNo =
            vm.cartItems.lineItems[$scope.partNo] ? vm.cartItems.lineItems[$scope.partNo]['partNumber'] : '';
            var catId = vm.cartItems['orderId'];
            addtocartClickGA(
                currencySymbol,
                categoryName,
                cartPNo,
                prodPrice,
                AgilentName,
                categoryName,
                prodDesc,
                cartQty,
                catId
            );
        }
    }
    /*** End - Google Analytics add to cart recommendation ***/

    //start add to cart function
    $scope.globalErr = '';
    $scope.globalSuccess = '';

    $scope.noPartNo = false;
    $scope.noPartQty = false;
    $scope.successPart = false;
    $scope.noCouponCode = false;
    $('.singleCartValidation').removeClass('hidden');

    var addcartItemInput = {
        productId: '',
        quantity: '1'
    };

		var addcartItem = {
			addItemCount: '1',
			items: [{
				productId:'',
				quantity: '1'
			}]
		};
		$scope.addcartItemList = {
			items: [{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			}]
		};

    $scope.addcartItem = addcartItem;
    $scope.addcartItemInput = addcartItemInput;	
		$scope.addItemLink = function() {
			$scope.addcartItemList.items.push({
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			},{
				productId:'',
				quantity: '1'
			});
			
			if($scope.addcartItemList.items.length == 20){
				$(".addMoreDiv > i,.addMoreDiv #addmore1,.addMoreDiv .divider").hide();
			}
		}
		
		$scope.clearItemLink = function() {
			angular.forEach($scope.addcartItemList.items, function(item) {		
				item.productId="";
				item.quantity="1";
			});
		}
		$scope.blurQty = function() {
			angular.forEach($scope.addcartItemList.items, function(item) {
				if(item.quantity == ""){
					item.quantity="1";
				}
			});
		}
	 $scope.isActiveMTC = function(item) {
        return $scope.MTCselected === item;
	};		
	function movetoCart(item,index,$event) {
		couponPromoStatus = '';
		$scope.errorpart = false;
		$event.preventDefault();
		$scope.MTCselected = item;			
		$scope.movetoCartPartNo = item.partNumber;
		$('#erroeMessages_outer,#successMessages_outer,#successMessagesPage_outer,#orderCenterErrorMsg div,#cartErrorMessage,#restorePromoMessage').hide();
		if(item.salesOrg != vm.cartItems.cartSalesOrg && vm.cartItems.cartSalesOrg != undefined){
			$scope.globalErr = '';
			$scope.globalErr = new Array(
				item.partNumber+" "+$("#cartSFLPartsMessage").val()
			);	
			$('#erroeMessages_outer').show();
			$('html, body').animate({ scrollTop: 0 }, 'slow');	
			$('.savedForLater .cartAction-section').removeClass('disable')
			$scope.MTCselected = undefined;				
			return false;	
		}		
        var movetoCartItem = {
            addItemCount: 1,
            items: [{
                productId: item.partNumber,
                quantity: item.quantity
            }]
        };
		cartHttpService
            .addToCartService(RESOURCES.ADD_TO_CART_ORDER_URL, movetoCartItem)
            .then(
                function(success) {
                    if (success.data.success) {
                        $scope.noPartQty = false;
                        $scope.noPartNo = false;
                        $scope.noCouponCode = false;
                        $('.promo-input').removeClass('requiredTextBox');
                        $scope.globalErr = '';
                        getOrderDetails();
						removeSFLItem(item.giftItemId,index) 
                        addToCartSuccess = true;
							if (!$.isEmptyObject(success.data.errorMessages)) {
								$scope.MTCselected = undefined;		
								$scope.globalErr = new Array(
									success.data.errorMessages[0].localizedMessage
								);
								$('#erroeMessages_outer').show();
								$('html, body').animate({ scrollTop: 0 }, 'slow');
							}

                    } else {
                        $scope.noPartQty = false;
                        $scope.noPartNo = false;
                        $scope.noCouponCode = false;
                        $('.promo-input').removeClass('requiredTextBox');
                        $('#orderCenterErrorMsg div').css(
                            'display',
                            'none'
                        );
                        $('#erroeMessages_outer').show();
						$scope.MTCselected = undefined;	
                        if (!$.isEmptyObject(success.data.errorMessages)) {
                            $scope.globalErr = new Array(
                                success.data.errorMessages[0].localizedMessage
                            );
                        } else {
                            $scope.globalErr = new Array($("#someErrorOccurredLabel").val());
                        }
                        if (!$.isEmptyObject(success.data.invalidParts)) {
							jQuery("#invalidPartsVal").val(success.data.invalidParts);
						}
                        if (!$.isEmptyObject(success.data.obsoleteParts)) {
							jQuery("#obsoletePartsVal").val(success.data.obsoleteParts);
						}
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
						LSCA.loadingSpinner.hideLoading();
						$('.savedForLater .cartAction-section').removeClass('disable')	
						$('.savedForLater .cart-action').removeClass('loadingspinner')
                    }
						$scope.clearItemLink();
                    
                },
                function(error) {
                    console.error('Some error occured while adding your item to cart');
					$('.savedForLater .cart-action').removeClass('loadingspinner')
					$('.savedForLater .cartAction-section').removeClass('disable')
					$scope.MTCselected = undefined;	
                }
            );
	}	

    $scope.addtoCart = function() {
        couponPromoStatus = '';
        singleAddStatus = 'true';
		$scope.errorpart = false;
        $scope.partNo = addcartItemInput.productId;
        $scope.qtyNo = addcartItemInput.quantity;	
		var addtoCartQtyMaxLimit = 20,rowCount=0;
		angular.forEach($scope.addcartItemList.items, function(item) {
			if(item.productId!=""){
				addcartItemInput.productId = item.productId;
				addcartItemInput.quantity = item.quantity;
				rowCount++;				
			}			
        })
		$scope.addcartItem.addItemCount=rowCount;

        if ($('.cart-quantity span a.cart-text:visible').length > 0) {
            $('.cart-quantity span a.cart-text').hide();
        }
			if (
            (addcartItemInput.quantity == '' &&
                addcartItemInput.productId == '') ||
            (addcartItemInput.quantity == undefined &&
                addcartItemInput.productId == undefined)
        ) {
            $scope.noPartQty = true;
            $scope.noPartNo = true;
            $scope.successPart = false;
            $('#erroeMessages_outer').hide();
            $('.entryList:first-child .partNoText').addClass('requiredTextBox');
            $('.entryList:first-child .qtyText').addClass('requiredTextBox');
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('#successMessagesPage_outer').hide();
            $scope.globalErr = '';
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            return;
        } else if (
            addcartItemInput.quantity == '' ||
            addcartItemInput.quantity == undefined
        ) {
            $scope.noPartQty = true;
            $scope.noPartNo = false;
            $scope.successPart = false;
            $('.entryList:first-child .qtyText').addClass('requiredTextBox');
            $('.entryList:first-child .partNoText').removeClass('requiredTextBox');
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('#successMessagesPage_outer').hide();
            $scope.globalErr = '';
            $('#erroeMessages_outer').hide();
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            return;
        } else if (
            addcartItemInput.productId == '' ||
            addcartItemInput.productId == undefined
        ) {
            $scope.noPartNo = true;
            $scope.noPartQty = false;
            $scope.successPart = false;
            $('.entryList:first-child .partNoText').addClass('requiredTextBox');
            $('.entryList:first-child .qtyText').removeClass('requiredTextBox');
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('#successMessagesPage_outer').hide();
            $scope.globalErr = '';
            $('#erroeMessages_outer').hide();
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            return;
        } else {
            $scope.noPartQty = false;
            $scope.noPartNo = false;
            $scope.successPart = false;
            $('#erroeMessages_outer').hide();
            $('.entryList:first-child .partNoText').removeClass('requiredTextBox');
            $('.entryList:first-child .qtyText').removeClass('requiredTextBox');
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('#successMessagesPage_outer').hide();
            $scope.globalErr = '';
        }
		addcartItem.items = [];
		angular.forEach($scope.addcartItemList.items, function(item) {
			if(item.productId!="" && item.quantity!=""){			
			$scope.addcartItem.items.push(item);
			}
		});

		
        cartHttpService
            .addToCartService(RESOURCES.ADD_TO_CART_ORDER_URL, addcartItem)
            .then(
                function(success) {
                    addcartItem.items = [];	
					addcartItemInput.productId = '';
					addcartItemInput.quantity = '1';
                    if (success.data.success) {
                        $scope.noPartQty = false;
                        $scope.noPartNo = false;
                        $scope.noCouponCode = false;
                        $('.promo-input').removeClass('requiredTextBox');
                        $('#erroeMessages_outer').hide();
                        $('#successMessages_outer').hide();
                        $scope.globalErr = '';
                        getOrderDetails();
                        addToCartSuccess = true;
							if (!$.isEmptyObject(success.data.errorMessages)) {
								$scope.globalErr = new Array(
									success.data.errorMessages[0].localizedMessage
								);
								$('#erroeMessages_outer').show();
								$('html, body').animate({ scrollTop: 0 }, 'slow');
							}
							if(success.data.SFLPartNumberMessage){                            
								$scope.globalErr = '';
								if(!$.isEmptyObject(success.data.errorMessages)){
									$scope.globalErr = new Array(
										success.data.errorMessages[0].localizedMessage
									);
									$('#erroeMessages_outer').show();	
									$('html, body').animate({ scrollTop: 0 }, 'slow');	
								}else{
									$('#erroeMessages_outer').hide();	
								}								
								$('.savedForLater-info p.multi-partinfo').html(success.data.SFLPartNumberMessage)
								$("#savedforlatermodal").modal('show');	
								vm.getsaveForLater();
							}
                    } else {
                        $scope.noPartQty = false;
                        $scope.noPartNo = false;
                        $scope.noCouponCode = false;
                        $('.promo-input').removeClass('requiredTextBox');
                        $('#orderCenterErrorMsg div').css(
                            'display',
                            'none'
                        );
                        $('#erroeMessages_outer').show();
						$('.loading').hide();
                        if (!$.isEmptyObject(success.data.errorMessages)) {
                            $scope.globalErr = new Array(
                                success.data.errorMessages[0].localizedMessage
                            );
                        } else {
                            $scope.globalErr = new Array($("#someErrorOccurredLabel").val());
                        }
                        if (!$.isEmptyObject(success.data.invalidParts)) {
							jQuery("#invalidPartsVal").val(success.data.invalidParts);
						}
                        if (!$.isEmptyObject(success.data.obsoleteParts)) {
							jQuery("#obsoletePartsVal").val(success.data.obsoleteParts);
						}
						if(success.data.SFLPartNumberMessage){
                            $scope.globalErr = '';
							if(!$.isEmptyObject(success.data.errorMessages)){
								$scope.globalErr = new Array(
									success.data.errorMessages[0].localizedMessage
								);
								$('#erroeMessages_outer').show();									
							}else{
								$('#erroeMessages_outer').hide();	
							}
							$('.savedForLater-info p.multi-partinfo').html(success.data.SFLPartNumberMessage)
							$("#savedforlatermodal").modal('show');	
							vm.getsaveForLater();
						}						
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                    }
						$scope.clearItemLink();
                    
                },
                function(error) {					
                    console.error('Some error occured while adding your item to cart');	
					$('.loading').hide();
                }
            );
    };
    // End add to cart function
	//Sale org label display
	$scope.getSalesOrgLabel = function(salesorg) {
		var salorglabel="";
		salorglabel = angular.element(document.getElementById(salesorg)).val();
		if(salorglabel != undefined){
			return salorglabel;
		}else{
			return "";	
		}
		   
	};
    //recommended add to cart start
    $scope.recommendedAddCart = function(qty, partNumber) {
        recommendedAddStatus = 'true';
        $scope.recommendedQty = qty;
        $scope.recommendedPartNo = partNumber;

        var recomAddcartItem = {
            addItemCount: '1',
            items: [{
                productId: partNumber,
                quantity: qty
            }]
        };

        cartHttpService
            .addToCartService(RESOURCES.ADD_TO_CART_ORDER_URL, recomAddcartItem)
            .then(
                function(success) {
                    if (success.data.success == true) {
                        $('#erroeMessages_outer').hide();
                        $scope.globalErr = '';
                        var recommendedBlockId =
                            '#partNo_' + partNumber + ' .successColor';
                        var recommendedBlockIdIcon =
                            '#partNo_' + partNumber + ' .gn-success-msg';
                        $(recommendedBlockId).show();
                        $(recommendedBlockIdIcon).css(
                            'display',
                            'inline-block'
                        );
                        getOrderDetails();
                    } else {
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#erroeMessages_outer').show();
						$('.loading').hide();
                        $scope.globalErr = new Array(
                            success.data.errorMessages[0].localizedMessage
                        );
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                    }
                },
                function(error) {
                    console.error('Some error occured in get order details');
					$('.loading').hide();
                });
    };

    //recommended add to cart end

    //Apply promocode start
    var applyPromo = {
        couponCode: ''
    };

    $scope.applyPromo = applyPromo;

    $scope.applyPromoCode = function() {
        couponPromoStatus = 'false';
        $scope.globalErr = '';
        $('#erroeMessages_outer').hide();

        if ($scope.applyPromo.couponCode == '') {
            $('.promo-input').addClass('requiredTextBox');
            $scope.noCouponCode = true;
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            $scope.globalErr = '';
            return;
        } else {
            $('.promo-input').removeClass('requiredTextBox');
        }
        
        cartHttpService
            .addPromoService(RESOURCES.APPLY_PROMO_URL, applyPromo)
            .then(
                function(success) {
                    //clearing previous messages
                    $scope.globalErr = '';
                    $('#erroeMessages_outer').hide();
                    $('#successMessages_outer').hide();
                    $('#successMessagesPage_outer').hide();
                    $('#restorePromoMessage').hide();
                    $scope.globalSuccess = '';
                    $scope.noCouponCode = false;
                    if (success.data.success == true) {
                    	couponPromoStatus = 'true';
                        if (success.data.quoteExpiryMessage != '') {
                            $('#removePromoPopup #promoForm .formSection').html(
                                success.data.quoteExpiryMessage
                            );
                        }
                        if (success.data.quoteExpCoupons != '') {
                            $('#quoteExpCoupons').val(
                                success.data.quoteExpCoupons
                            );
                        }
                        // clear promo
                        $scope.applyPromo.couponCode = '';
                        $scope.globalSuccess = success.data.successMessages;
                        $('#successMessages_outer').show();
                        if (
                            success.data.errorMessages != undefined &&
                            success.data.errorMessages.length > 0
                        ) {
                            $scope.globalErr = success.data.errorMessages;
                            $('#orderCenterErrorMsg div').css(
                                'display',
                                'none'
                            );
                            $('#erroeMessages_outer').show();
                        }
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                        getOrderDetails();
                    } else if (success.data.dynamicPromo == true) {
                        $('#promotionDiscountPopup').modal('show');
						$('.loading').hide();
                    } else {
                        // clear promo
                        $scope.applyPromo.couponCode = '';
                        $scope.globalErr = success.data.errorMessages;
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#erroeMessages_outer').show();
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                        getOrderDetails();
                    }
                },
                function(error) {
                    console.error('Some error occured in get order details');
					$('.loading').hide();
                });
    };

    $scope.applyPromoReadyToUse = function() {
        $scope.globalErr = '';
        $('#erroeMessages_outer').hide();

        if ($scope.applyPromo.couponCode == '') {
            $scope.noCouponCode = true;
            $('#orderCenterErrorMsg div').css('display', 'none');
            $('#erroeMessages_outer').show();
            $scope.globalErr = '';
            return;
        }

        cartHttpService
            .addPromoReadyToUseService(
                RESOURCES.APPLY_READYTO_US_PROMO_URL,
                applyPromo
            )
            .then(
                function(success) {
                    //clearing previous messages
                    $scope.globalErr = '';
                    $('#erroeMessages_outer').hide();
                    $('#successMessages_outer').hide();
                    $('#successMessagesPage_outer').hide();
                    $scope.globalSuccess = '';
                    $scope.noCouponCode = false;

                    if (success.data.success == true) {
                        // clear promo
                        $scope.applyPromo.couponCode = '';
                        
                        $scope.globalSuccess = success.data.successMessages;
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#successMessages_outer').show();
                        if (
                            success.data.errorMessages != undefined &&
                            success.data.errorMessages.length > 0
                        ) {
                            $scope.globalErr = success.data.errorMessages;
                            $('#orderCenterErrorMsg div').css(
                                'display',
                                'none'
                            );
                            $('#erroeMessages_outer').show();
                        }

                        getOrderDetails();
                    } else if (success.data.dynamicPromo == true) {
                        $('#promotionDiscountPopup').modal('show');
						$('.loading').hide();
                    } else {
                        $scope.globalErr = success.data.errorMessages;
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#erroeMessages_outer').show();
						$('.loading').hide();
                    }
                },
                function(error) {
                    console.error('Some error occured in get order details');
					$('.loading').hide();
                });
    };
    //Apply promocode end

    //dynamic coupon call start
    $scope.dynamicCouponPrice = '';
    $scope.addDynamicPromo = function() {
        var dynamicCoupon = {};
        dynamicCoupon = {
            couponCode: $scope.applyPromo.couponCode,
            dynamicPromo: 'true',
            dynamicDiscount: $scope.dynamicCouponPrice
        };
        $scope.dynamicCoupon = dynamicCoupon;
        if ($scope.dynamicCoupon.dynamicDiscount != '') {
            $('#promotionDiscountForm .discountLabel').removeClass(
                'requiredLabel'
            );
            $('#promotionDiscountForm #dynamicDiscountId').removeClass(
                'requiredTextBox'
            );
            $('#promotionDiscountForm #dynamicDiscountId')
                .next()
                .hide();
        } else {
            $('#promotionDiscountForm .discountLabel').addClass(
                'requiredLabel'
            );
            $('#promotionDiscountForm #dynamicDiscountId').addClass(
                'requiredTextBox'
            );
            $('#promotionDiscountForm #dynamicDiscountId')
                .next()
                .css('display', 'inline-block');
            return;
        }

        //dynamic coupon call with dynamic discount
        cartHttpService
            .addPromoService(RESOURCES.APPLY_PROMO_URL, dynamicCoupon)
            .then(
                function(success) {
                    // clear promo
                    $scope.applyPromo.couponCode = '';
                    if (success.data.success == true) {
						couponPromoStatus = 'true';
                        $scope.globalSuccess = success.data.successMessages;
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#successMessages_outer').show();
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                        getOrderDetails();
                        $('#promotionDiscountPopup').modal('hide');
                    } else {
                        $scope.globalErr = success.data.errorMessages;
                        $('#orderCenterErrorMsg div').css('display', 'none');
                        $('#erroeMessages_outer').show();
                        $('#promotionDiscountPopup').modal('hide');
                        $('html, body').animate({ scrollTop: 0 }, 'slow');
                        getOrderDetails();
                    }
                },
                function(error) {
                    console.error('Some error occured in get order details');
					$('.loading').hide();
                }
            );
    };
    //dynamic coupon call end
});

// Http service call
shoppingCartApp.factory('cartHttpService', function($http, RESOURCES) {
    var httpService = {};
    httpService.getOrderDetailsService = function() {
        if (couponPromoStatus == 'true' && couponPromoStatus != undefined) {
            return $http.get(
                RESOURCES.CART_ORDER_URL +
                    '&repriceOrder=false&noCache=' +
                    new Date().getTime()
            );
        } else {
            return $http.get(
                RESOURCES.CART_ORDER_URL + '&noCache=' + new Date().getTime()
            );
        }
    };
    httpService.getSaveForLaterService = function() {
        return $http.get(
				RESOURCES.CART_SAVE_LATER 
			);
    };
    httpService.getSFLProductDescImageService = function(getSFLproductsList) {
        return $http.get(
				RESOURCES.CART_SAVE_LATER_PRODUCT_DESCRIPTION_IMAGE+getSFLproductsList
			);
    };		
    httpService.getSFLPriceService = function(getSFLproductsList) {
        return $http.get(RESOURCES.CART_SAVE_LATER_PRICE+getSFLproductsList,{ timeout: $('#sflPricingTimeout').val() });
		//return $http.get(RESOURCES.CART_SAVE_LATER_PRICE1);		
    };	
    httpService.SFLaddService = function(url, data) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(url, data);		
    };	
    httpService.SFLremoveService = function(itemToRemove) {
        return $http.post(RESOURCES.CART_SAVE_LATER_REMOVE, itemToRemove);
    };		
    httpService.getStateOrderDetailsService = function(url) {
		LSCA.loadingSpinner.showLoading();
        return $http.get(url);
    };
    httpService.addToCartService = function(url, data) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(url, data);
    };
    httpService.removeItemService = function(itemToRemove) {
        LSCA.loadingSpinner.showLoading();
        return $http.post(RESOURCES.REMOVE_ITEM_URL, itemToRemove);
    };
    httpService.updateQuantityService = function(itemToUpdate) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(RESOURCES.QUANTITY_UPDATE_URL, itemToUpdate);
    };
    httpService.updateDesignDetailService = function(itemToUpdate) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(RESOURCES.DESIGN_DETAIL_UPDATE_URL, itemToUpdate);
    };
    // promo service
    httpService.addPromoService = function(url, data) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(url, data);
    };
    httpService.addPromoReadyToUseService = function(url, data) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(url, data);
    };
    //promo service for ready to use

    // dynamic promo service
    httpService.dynamicPromoService = function(url, data) {
		LSCA.loadingSpinner.showLoading();
        return $http.post(url, data);
    };
    return httpService;
});

shoppingCartApp.service('cartUtilityService', function() {
    this.trimFromLast = trimFromLast;
    this.showContent = showContent;
    this.scrollPageTop = scrollPageTop;
    this.isNonZeroValue = isNonZeroValue;

    function trimFromLast(input) {
        var delimFound = false;
        for (var i = input.length - 1; i >= 0; i--) {
            if (
                input[i] == ' ' ||
                input[i] == '\uFF0C' ||
                input[i] == '\u3002' ||
                input[i] == '\u002D' ||
                input[i] == '\u2014' ||
                input[i] == ',' ||
                input[i] == '\u3001' ||
                input[i] == '\u002C' ||
                input[i] == '\u4E00' ||
                input[i] == '\u2009'
            ) {
                delimFound = true;
            } else if (delimFound) {
                var str2 = input.substring(0, i + 1);
                return input.substring(0, i + 1);
            }
        }
        return '';
    }

    function showContent() {
        $('#emptyCartContent, #item-remain, #chinaState, #cartItem, #cartLeft-border, #totalPriceWidget, #cart-action-links').show();
    }

    function scrollPageTop() {
        $(document).scrollTop(0);
    }

    function isNonZeroValue(value) {
        return value !== null && value !== undefined && value !== '' && !Array.isArray(value) && typeof value !== 'object';
    }
});

shoppingCartApp.filter('trustAsHtml', function($sce) {
    return function(text) {
        return $sce.trustAsHtml(text);
    };
});

shoppingCartApp.filter('truncateText', function($sce) {
    return truncateText;
});

function truncateText(text, max) {
    if (!text) return '';

    max = parseInt(max, 10); // 10 is for decimal
    if(!max) return text;
    if(text.length <= max) return text;

    text = text.substr(0, max);
    return text + '…';
};

shoppingCartApp.directive('truncateDesc', function(
    $timeout,
    cartUtilityService
) {
    return {
        restrict: 'A',
        link: function(scope, element, attributes) {
            $timeout(init, false);
            function init() {
                var origContent = '';
                while (element[0].offsetHeight > 40) {
                    origContent = element.html();
                    origContent = cartUtilityService.trimFromLast(origContent);
                    element.html(origContent + '...');
                }
            }
        }
    };
});

shoppingCartApp.factory('loaderInterceptor', function ($q) {
    var numLoadings = 0;
    return {
        request: function (config) {
            numLoadings++;
            // Show loader
            //LSCA.loadingSpinner.showLoading();
            return config || $q.when(config)
        },
        response: function (response) {
            if ((--numLoadings) === 0) {
                // Hide loader
                //LSCA.loadingSpinner.hideLoading();
            }
            return response || $q.when(response);
        },
        responseError: function (response) {
            if (!(--numLoadings)) {
                // Hide loader
                LSCA.loadingSpinner.hideLoading();
            }
            return $q.reject(response);
        }
    };
}).config(function ($httpProvider) {
    $httpProvider.interceptors.push('loaderInterceptor');
});
