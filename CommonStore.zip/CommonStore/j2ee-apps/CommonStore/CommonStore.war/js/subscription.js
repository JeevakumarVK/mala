$(document).ready(function() {
	(function($) {
		$.fn.hasScrollBar = function() {
			return this.get(0).scrollHeight > this.height();
		}
	})(jQuery);
    $('.subscriptionInfo .accordiansection dt').on("click", function () {
        $(this).removeClass('active');
        if (!$(this).next('dd').hasClass('in')) {
            $(this).addClass('active');
        }
    });
	if(window.location.href.indexOf('createReview') == -1 && window.location.href.indexOf('edit') == -1) {
		//console.log('copyfromHidden call');
		copyfromHidden();//Create/edit and not for review edit
	}
	var maxHeight = -1;
    $('.reviewColumn').each(function() {
        maxHeight = maxHeight > $(this).height() ? maxHeight : $(this).height();
    });
    $('.reviewColumn').each(function() {
        $(this).height(maxHeight + 8);
    });
  // Create subscription Start
	var skipAlign = $('#bin').css('margin-right').replace('px','');
	skipAlign = parseInt(skipAlign)+50;
	console.log(skipAlign)
	//$('.skip-text').parent('.skipCancelSubscription').css('right',skipAlign+'px');
	//$('.skip-button').parent('.skipCancelSubscription').css('right',skipAlign+'px');
	
	//$('.skip-text').parent('.skipCancelSubscription').css('left','748px');
	//$('.skip-button').parent('.skipCancelSubscription').css('left','815px');
    function getSpecificDate(noOfDaysAdd) {
        var currentDate = new Date();
        currentDate.setDate(currentDate.getDate() + noOfDaysAdd);
        var day = currentDate.getDate();
        day = (day < 10 ? '0' : '') + day;
        var month = currentDate.getMonth() + 1;
        month = (month < 10 ? '0' : '') + month;
        var year = currentDate.getFullYear();
        return month + '/' + day + '/' + year;
    }
	
	function daydiff(first, second) {
		return (second-first)/(1000*60*60*24)
	}
	
	 function parseDate(str) {
		var mdy = str.split('/');
		return new Date(mdy[2], mdy[0]-1, mdy[1]);
	}
	
	var subStartDate = getSpecificDate(0);
    var subEndDate = getSpecificDate(365);
	
	
	$("#subscriptionForm input,#subscriptionForm textarea").on('keypress', function(e) {
		if($(this).val() == '') {
			if (e.which == 32)
			return false;
		}
	 });
	 $("#subscriptionForm input,#subscriptionForm textarea").on('blur', function(e) {
		var tempVal = $.trim($(this).val());
		if($.trim(tempVal) === '') {
			$(this).val('');
		}
	 });
	var editFlag = false;
	if(window.location.href.indexOf('subscriptionId') != -1 && LSCA.getUrlParam('src') == undefined) {
		editFlag = true;
	}
	if(window.location.href.indexOf('subscriptionId') != -1 && LSCA.getUrlParam('src') == 'review') {
		editFlag = false;
	}
	if(editFlag){
	$('#submitSubr').addClass('disabled-saveBtn');
		$("#subscriptionForm input,#subscriptionForm textarea").on('keyup paste', function() {
			console.log('textbox/textarea event');
			  $('#submitSubr').removeClass('disabled-saveBtn');
		 });
		 $('#schedule-frequency-data, #subscriptionEndDate, #repeatWeeklyFrequency-data,#onWeek-data,#onMonth-data,#onMonthDay-data,#onMonthFirst-data,#subscriptionForm input[type=radio]').on('change',function(){
			console.log('dropdown/radio button event');
			$('#submitSubr').removeClass('disabled-saveBtn');
		 });
	}
	if($('#editScheduleFreq').length > 0) {
				
		if ($('#editScheduleFreq').val() == 'Weekly') {
			$('#onMonth').hide();
			$('#onMonthDay').hide();
			$('#onWeek').show();
			$('#repeatEveryWeekly').show();
			$('#repeatEveryMonthly').hide();
			$('#onMonthFirst').hide();
			$('#onMonthFirst-data').attr('disabled',true);
		} else if ($('#editScheduleFreq').val() == 'onceMonthly') {
			$('#onMonth').show();
			$('#onMonthDay').show();
			$('#onWeek').hide();
			$('#repeatEveryWeekly').hide();
			$('#repeatEveryMonthly').show();
			$('#onWeek-data').attr('disabled',true);
			if ($('#editOccurance').val() == 0) {
				$('#onMonthDay').show();
				$('#onMonthFirst').hide();
			} else {
				$('#onMonthDay').hide();
				$('#onMonthFirst').show();
			}
		}
	}
	else {
		$("#subscriptionStartDate").val(subStartDate);
		$("#subscriptionEndDate").val(subEndDate);
		$('#onWeek-data').attr('disabled',true);

	} 

    // var germanUser = $("#forceDisableEndDate").val();
    // if (germanUser == 'true') {
    //     $("#subscriptionEndDate").datepicker({
    //         minDate : '+1D',
    //         maxDate : '+365D'
    //     }).attr('readonly', true);
    // }

    /*$(document).on("change", "#schedule-frequency-data", function(e) {
        if ($(this).val() == 'onceMonthly') {
            $('#onMonth').show();
            $('#onMonthDay').show();
            $('#onWeek').hide();
            $('#repeatEveryWeekly').hide();
            $('#repeatEveryMonthly').show();
			$('#uniform-repeatMonthlyFrequency-data span').text('1');
			$("#repeatMonthlyFrequency-data").prop('selectedIndex', 0);
            $('#uniform-onMonth-data span').text($('#onMonth-data option[value=0]').text());
			$("#onMonth-data").prop('selectedIndex', 0);
			$('#uniform-onMonthDay-data span').text('1');
			$("#onMonthDay-data").prop('selectedIndex', 0);
			$('#onMonthFirst-data').attr('disabled',false);
			$('#onWeek-data').attr('disabled',true);
        }
        if ($(this).val() == 'Weekly') {
            $('#onMonth').hide();
            $('#onMonthDay').hide();
            $('#onWeek').show();
            $('#repeatEveryWeekly').show();
            $('#repeatEveryMonthly').hide();
            $('#onMonthFirst').hide();
			$('#uniform-repeatWeeklyFrequency-data span').text('1');
			$("#repeatWeeklyFrequency-data").prop('selectedIndex', 0);
			$('#uniform-onWeek-data span').text($('#onWeek-data option[value=2]').text());
			$("#onWeek-data").prop('selectedIndex', 0);
			$('#onWeek-data').attr('disabled',false);
			$('#onMonthFirst-data').attr('disabled',true);
        }
    });
    $(document).on("change", "#onMonth-data", function(e) {
        if ($(this).val() == 0) {
            $('#onMonthDay').show();
            $('#onMonthFirst').hide();
			$('#uniform-onMonthDay-data span').text('1');
			$("#onMonthDay-data").prop('selectedIndex', 0);
        } else {
            $('#onMonthDay').hide();
            $('#onMonthFirst').show();
			$('#uniform-onMonthFirst-data span').text($('#onMonthFirst-data option[value=2]').text());
			$("#onMonthFirst-data").prop('selectedIndex', 0);
        }
    });*/
    var daysToAdd = 365;
	var creditEndDate = 365;
	var editEndDate = 1;
	if ($("#mainContainer").hasClass('createSubscription')) {
	editEndDate = daydiff(parseDate(getSpecificDate(0)), parseDate($('#subscriptionStartDate').val()));
	if(editEndDate >= 0) {
		editEndDate = editEndDate;
	}
	else {
		editEndDate =1;
	}
	}
	if($('#cardExpDate').val() != '' && $('#cardExpDate').length > 0) {
		var creditDateDiff = daydiff(parseDate(getSpecificDate(0)), parseDate($('#cardExpDate').val()));
		//console.log('creditDateDiff - '+creditDateDiff);
		creditEndDate = creditDateDiff
	}
    // $("#subscriptionStartDate").datepicker({
    //     // dateFormat: 'dd MM yy',
    //     minDate : '+1D',
    //    maxDate : '+'+creditEndDate+'D',
    //     onSelect : function(selected) {
	// 		if(editFlag && $('#submitSubr').hasClass('disabled-saveBtn') && selected != ''){
	// 			$('#submitSubr').removeClass('disabled-saveBtn');
	// 		}
    //         if (selected != '') {
    //             $("#subscriptionEndDate").attr('disabled', false);
    //             $("#subscriptionEndDate").attr('readonly', true);
    //         }
    //         var dtMax = new Date(selected);
    //         dtMax.setDate(dtMax.getDate());
    //         var dd = dtMax.getDate();
    //         var mm = dtMax.getMonth() + 1;
    //         var y = dtMax.getFullYear();
    //         var dtFormatted = mm + '/' + dd + '/' + y;
    //         $("#subscriptionEndDate").datepicker("option", "minDate", dtFormatted);
    //         if (germanUser == 'true') {
    //             var dtMax1 = new Date();
    //         } else {
    //             var dtMax1 = new Date(selected);
    //         }
	// 		if($('#cardExpDate').val() != '' && $('#cardExpDate').length > 0) {
	// 			creditDateDiff = daydiff(parseDate(dtMax1.getMonth() + 1 + '/' + dtMax1.getDate() + '/' + dtMax1.getFullYear()), parseDate($('#cardExpDate').val()));
	// 			//console.log('creditDateDiff selected start date - '+creditDateDiff);
	// 			creditEndDate = creditDateDiff
	// 		}
    //         dtMax1.setDate(dtMax1.getDate() + creditEndDate);
    //         var dd1 = dtMax1.getDate();
    //         var mm1 = dtMax1.getMonth() + 1;
    //         var y1 = dtMax1.getFullYear();
    //         var dtFormatted1 = mm1 + '/' + dd1 + '/' + y1;
    //         $("#subscriptionEndDate").datepicker("option", "maxDate", dtFormatted1);
    //     }
    // }).attr('readonly', true);
    // $("#subscriptionEndDate").datepicker({
	// 	minDate : '+'+editEndDate+'D',
	// 	 maxDate : '+'+creditEndDate+'D',
	// 	 onSelect : function(selected) {
	// 		if(editFlag && $('#submitSubr').hasClass('disabled-saveBtn') && selected != ''){
	// 			$('#submitSubr').removeClass('disabled-saveBtn');
	// 		}
	// 	 }
	// }).attr('readonly', true);
    var formatedDate1;
    // var reviewEndDate = $('#subscriptionEndDate').val();
    if (editFlag || LSCA.getUrlParam("src") == "review") {
        $( "#subscriptionEndDate" ).datepicker({
            dateFormat: 'dd M yy',
            onSelect : function(selected){
                if(editFlag && $('#submitSubr').hasClass('disabled-saveBtn')){
                    			$('#submitSubr').removeClass('disabled-saveBtn');
                    		}
            }
        });
  } else {
 // Subscription Start Date
 var todayDate = new Date();
 todayDate.setDate(todayDate.getDate());
 var dd = todayDate.getDate();
 var mm = todayDate.toLocaleString('en-US', { month: 'short' });
 var y = todayDate.getFullYear();
 var formatedDate = dd +" "+ mm +" "+ y;
 $( "#subscriptionStartDate" ).datepicker({
 dateFormat: 'dd M yy',}, $('#subscriptionStartDate').val(formatedDate));

// Subscription  End Date 
var oneYearFromNow = new Date();
oneYearFromNow.setDate(oneYearFromNow.getDate());
 var dd1 = oneYearFromNow.getDate();
 var mm1 = oneYearFromNow.toLocaleString('en-US', { month: 'short' });
 var y1 = oneYearFromNow.getFullYear()+1;
 formatedDate1 = dd1 +" "+ mm1 +" "+ y1;
$( "#subscriptionEndDate" ).datepicker({minDate: 0, maxDate: "+1Y", 
 dateFormat: 'dd M yy',}); $('#subscriptionEndDate').val(formatedDate1);
  }

  // frequency Check
  var frequency = $('#schedule-frequency-data').val();
  $('#SubRangeEndDate').val($('#subscriptionEndDate').val());
  onLoadFreq(frequency);
  function checkFreq() {
      $('#subscriptionEndDate').datepicker('destroy');
      $("#subscriptionEndDate").datepicker({
          dateFormat: 'dd M yy',
          minDate: frequency,
          maxDate: "+1Y",
      });
      $('#SubRangeStartDate').datepicker('destroy');
      $( "#SubRangeStartDate" ).datepicker({dateFormat: 'dd M yy', minDate: frequency, maxDate:frequency, onSelect:frequency,}).datepicker("setDate", "0");
      if (editFlag || LSCA.getUrlParam("src") == "review") {
        // $('#subscriptionEndDate').val(reviewEndDate);
  }
      else{
        $('#subscriptionEndDate').val(formatedDate1);
      }
  }
  // Freq Range Check
  function dateCheck(from, to, check) {
    var fDate, lDate, cDate;
    fDate = Date.parse(from);
    lDate = Date.parse(to);
    cDate = Date.parse(check);
    if ((fDate <= cDate )) {
        return true;
    }
    return false;
}
  // On page load Frequency check 
  function onLoadFreq(frequencyVal){
  switch (frequencyVal) {
    case ('w1'):
        frequency = '+1W';
        checkFreq()
        break;
    case ('w2'):
        frequency = '+2W';
        checkFreq()
        break;
    case ('w3'):
        frequency = '+3W';
        checkFreq()
        break;
    case ('w4'):
        frequency = '+4W';
        checkFreq()
        break;
    case ('w5'):
        frequency = '+5W';
        checkFreq()
        break;
    case ('w6'):
        frequency = '+6W';
        checkFreq()
        break;
    case ('w7'):
        frequency = '+7W';
        checkFreq()
        break;
    case ('m1'):
        frequency = '+1M';
        checkFreq()
        break;
    case ('m2'):
        frequency = '+2M';
        checkFreq()
        break;
    case ('m3'):
        frequency = '+3M';
        checkFreq()
        break;
    case ('m4'):
        frequency = '+4M';
        checkFreq()
        break;
    case ('m5'):
        frequency = '+5M';
        checkFreq()
        break;
    case ('m6'):
        frequency = '+6M';
        checkFreq()
        break;
    case ('m7'):
        frequency = '+7M';
        checkFreq()
        break;
    default:
        frequency = 365;
        checkFreq()
}
  }
  // Frequency change 
  $('#schedule-frequency-data').on('change', function () {
    onLoadFreq($(this).val());
    if (dateCheck($('#SubRangeStartDate').val(), $('#SubRangeEndDate').val(), $('#subscriptionEndDate').val())) {
        
    }
    else {
        $('#subscriptionEndDate').val("");
    }
  });
  
  
  if ($('input[name="purchaseTypeOpt"]:checked').val() == 'creditCard') {
        $('.infoBlueBox').show();
		$('#subscriptionPoNumber').attr('readonly',true);
		$('#subscriptionPoNumber').addClass('DisabledText');
    }
	else if ($('input[name="purchaseTypeOpt"]:checked').val() == 'purchaseOrder') {
		$('#subscriptionPoNumber').attr('readonly',false);
		$('#subscriptionPoNumber').removeClass('DisabledText');
	}

	var subSection = { basicInfo : false, 
						billingInfo : false, 
						shipInfo : false, 
						shipMethod : false, 
						paymentInfo : false, 
						itemInfo : false 
					};	
	var emailCheck = false;	
	var poNumberCheck = false;				
    $(document).on('click', '#submitSubr', function(e) {		
        var dovalidate = LSCA.GlobalValidate.init({
            target : '#subscriptionForm'
        });
        //console.log(dovalidate);
		
        if (dovalidate) {
            
            if ($('input[name="purchaseTypeOpt"]:checked').val() == 'purchaseOrder') {
                if ($('#subscriptionPoNumber').val() == '') {
					$('.poRequired').css('margin-left',parseInt($('#subscriptionPoNumber').offset().left - $('.subscriptionPayment').offset().left)+'px');
                    $('#subscriptionPoNumber').next().next().css('display', 'block');
                    $('#subscriptionPoNumber').prev('.radioText').addClass('requiredLabel');
                    $('#subscriptionPoNumber').addClass('requiredTextBox');
					poNumberCheck = true;
					subSection.paymentInfo = true;
                } else {
                    $('#subscriptionPoNumber').next().next().hide();
                    $('#subscriptionPoNumber').prev('.radioText').removeClass('requiredLabel');
                    $('#subscriptionPoNumber').removeClass('requiredTextBox');
					poNumberCheck = false;
                }
                $('.infoBlueBox').hide();
            }			
			if ($('#subscriberInvoiceEmail').val() !== undefined && $('#subscriberInvoiceEmail').val() != '') {
				var mailarr = $('#subscriberInvoiceEmail').val(), paymentFlag = true;
                mailarr = mailarr.split(',');
                $.each(mailarr, function(i, v) {
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
                        paymentFlag = false;
                });
                if (!paymentFlag) {
                    $('#subscriberInvoiceEmail').next().next().text($('#emailValidationError').val());
                    $('#subscriberInvoiceEmail').next().next().css('display', 'inline-block');
                    $('#subscriberInvoiceEmail').prev('.fieldLabel').addClass('requiredLabel');
                    $('#subscriberInvoiceEmail').addClass('requiredTextBox');
					emailCheck = true;
					subSection.paymentInfo = true;
                } else {
                    $('#subscriberInvoiceEmail').next().next().hide();
                    $('#subscriberInvoiceEmail').prev('.fieldLabel').removeClass('requiredLabel');
                    $('#subscriberInvoiceEmail').removeClass('requiredTextBox');
					emailCheck = false;
                }
			}
			else {
				$('#subscriberInvoiceEmail').next().next().hide();
				$('#subscriberInvoiceEmail').prev('.fieldLabel').removeClass('requiredLabel');
				$('#subscriberInvoiceEmail').removeClass('requiredTextBox');
			}

            $('#subscriptionName,#subscriptionStartDate,#subscriptionEndDate').next().next().hide();
            $('#shipAttnnoCN,#ShipPhoneNo,#shipOrganization').next().next().hide();
            $('#subscriptionName,#subscriptionStartDate,#subscriptionEndDate,#shipAttnnoCN,#ShipPhoneNo,#shipOrganization').prev('.fieldLabel').removeClass('requiredLabel');
            $('#subscriptionName,#subscriptionStartDate,#subscriptionEndDate,#shipAttnnoCN,#ShipPhoneNo,#shipOrganization').removeClass('requiredTextBox');

            // Submit the form
			if(!emailCheck && !poNumberCheck) {
				if ($('input[name="purchaseTypeOpt"]:checked').val() == 'creditCard') {
					setCyberSourceData();
					
				}else{
					$('#subscriptionSbmt').click();
				}
				
			}else{
				getScrollSection();
			}			
        } else {
            if ($('#subscriptionName').val() == "") {
                $('#subscriptionName').next().next().css('display', 'inline-block');
                $('#subscriptionName').prev('.fieldLabel').addClass('requiredLabel');
                $('#subscriptionName').addClass('requiredTextBox');
				subSection.basicInfo = true;
            } else {
                $('#subscriptionName').next().next().hide();
                $('#subscriptionName').prev('.fieldLabel').removeClass('requiredLabel');
                $('#subscriptionName').removeClass('requiredTextBox');
            }
            if ($('#subscriptionStartDate').val() == '') {
                $('#subscriptionStartDate').next().next().css('display', 'inline-block');
                $('#subscriptionStartDate').prev('.fieldLabel').addClass('requiredLabel');
                $('#subscriptionStartDate').addClass('requiredTextBox');
				subSection.basicInfo = true;
            } else {
                $('#subscriptionStartDate').next().next().hide();
                $('#subscriptionStartDate').prev('.fieldLabel').removeClass('requiredLabel');
                $('#subscriptionStartDate').removeClass('requiredTextBox');
            }
            if ($('#subscriptionEndDate').val() == '') {
                $('#subscriptionEndDate').next().next().css('display', 'inline-block');
                $('#subscriptionEndDate').prev().prev('.fieldLabel').addClass('requiredLabel');
                $('#subscriptionEndDate').addClass('requiredTextBox');
				subSection.basicInfo = true;
            } else {
                $('#subscriptionEndDate').next().next().hide();
                $('#subscriptionEndDate').prev().prev('.fieldLabel').removeClass('requiredLabel');
                $('#subscriptionEndDate').removeClass('requiredTextBox');
            }

           /* if ($('#billAttnno').val() == "") {
                $('#billAttnno').next().next().css('display', 'inline-block');
                $('#billAttnno').prev('.fieldLabel').addClass('requiredLabel');
                $('#billAttnno').addClass('requiredTextBox');
				subSection.billingInfo = true;
            } else {
                $('#billAttnno').next().next().hide();
                $('#billAttnno').prev('.fieldLabel').removeClass('requiredLabel');
                $('#billAttnno').removeClass('requiredTextBox');
            }*/
            if ($('#shipAttnnoCN').val() == "") {
                $('#shipAttnnoCN').next().next().css('display', 'inline-block');
                $('#shipAttnnoCN').prev('.fieldLabel').addClass('requiredLabel');
                $('#shipAttnnoCN').addClass('requiredTextBox');
				subSection.shipInfo = true;
            } else {
                $('#shipAttnnoCN').next().next().hide();
                $('#shipAttnnoCN').prev('.fieldLabel').removeClass('requiredLabel');
                $('#shipAttnnoCN').removeClass('requiredTextBox');
            }
			if ($('#shipOrganization').val() == "") {
                $('#shipOrganization').next().next().css('display', 'inline-block');
                $('#shipOrganization').prev('.fieldLabel').addClass('requiredLabel');
                $('#shipOrganization').addClass('requiredTextBox');
				subSection.shipInfo = true;
            } else {
                $('#shipOrganization').next().next().hide();
                $('#shipOrganization').prev('.fieldLabel').removeClass('requiredLabel');
                $('#shipOrganization').removeClass('requiredTextBox');
            }
            if ($('#ShipPhoneNo').val() == "") {
                $('#ShipPhoneNo').next().next().css('display', 'inline-block');
                $('#ShipPhoneNo').prev('.fieldLabel').addClass('requiredLabel');
                $('#ShipPhoneNo').addClass('requiredTextBox');
				subSection.shipInfo = true;
            } else {
                $('#ShipPhoneNo').next().next().hide();
                $('#ShipPhoneNo').prev('.fieldLabel').removeClass('requiredLabel');
                $('#ShipPhoneNo').removeClass('requiredTextBox');
            }
            if ($('input[name="purchaseTypeOpt"]:checked').val() == 'purchaseOrder') {
                if ($('#subscriptionPoNumber').val() == '') {
					$('.poRequired').css('margin-left',parseInt($('#subscriptionPoNumber').offset().left - $('.subscriptionPayment').offset().left)+'px');
                    $('#subscriptionPoNumber').next().next().css('display', 'block');
                    $('#subscriptionPoNumber').prev('.radioText').addClass('requiredLabel');
                    $('#subscriptionPoNumber').addClass('requiredTextBox');
					subSection.paymentInfo = true;
                } else {
                    $('#subscriptionPoNumber').next().next().hide();
                    $('#subscriptionPoNumber').prev('.radioText').removeClass('requiredLabel');
                    $('#subscriptionPoNumber').removeClass('requiredTextBox');
                }
                $('.infoBlueBox').hide();
            }
			if ($('#subscriberInvoiceEmail').val() !== undefined && $('#subscriberInvoiceEmail').val() != '') {
				var mailarr = $('#subscriberInvoiceEmail').val(), paymentFlag = true;
                mailarr = mailarr.split(',');
                $.each(mailarr, function(i, v) {
                    if (!(/^\w+([\.+-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($.trim(v))))
                        paymentFlag = false;
                });
                if (!paymentFlag) {
                    $('#subscriberInvoiceEmail').next().next().text($('#emailValidationError').val());
                    $('#subscriberInvoiceEmail').next().next().css('display', 'inline-block');
                    $('#subscriberInvoiceEmail').prev('.fieldLabel').addClass('requiredLabel');
                    $('#subscriberInvoiceEmail').addClass('requiredTextBox');
					subSection.paymentInfo = true;
                } else {
                    $('#subscriberInvoiceEmail').next().next().hide();
                    $('#subscriberInvoiceEmail').prev('.fieldLabel').removeClass('requiredLabel');
                    $('#subscriberInvoiceEmail').removeClass('requiredTextBox');
                }
			}else {
				$('#subscriberInvoiceEmail').next().next().hide();
				$('#subscriberInvoiceEmail').prev('.fieldLabel').removeClass('requiredLabel');
				$('#subscriberInvoiceEmail').removeClass('requiredTextBox');
			}
			getScrollSection();
        }
    });
    $(document).on('click', '#add-quick-order-item', function(e) {
        if ($('#subscribedPartnum').val() == "") {
            $('#subscribedPartnum').next().css('display', 'inline-block');
            $('#subscribedPartnum').prev('.fieldLabel').addClass('requiredLabel');
            $('#subscribedPartnum').addClass('requiredTextBox');
        } else {
            $('#subscribedPartnum').next().hide();
            $('#subscribedPartnum').prev('.fieldLabel').removeClass('requiredLabel');
            $('#subscribedPartnum').removeClass('requiredTextBox');
        }
        if ($('#subscribedQty').val() == "") {
            $('#subscribedQty').next().css('display', 'inline-block');
            $('#subscribedQty').prev('.fieldLabel').addClass('requiredLabel');
            $('#subscribedQty').addClass('requiredTextBox');
        } else {
            $('#subscribedQty').next().hide();
            $('#subscribedQty').prev('.fieldLabel').removeClass('requiredLabel');
            $('#subscribedQty').removeClass('requiredTextBox');
        }
        if ($('#subscribedPartnum').val() != "" && $('#subscribedQty').val() != "") {
        	$('#subUpdatePartNumber').val($('#subscribedPartnum').val());
            $('#subUpdateItemQty').val($('#subscribedQty').val());
            $('#subscriptionSubmitType').val("addItem");
			setSectionPosition('itemSection', 'addItem');
            $('#subscriptionSbmt').click();
        }
        if ($('.subscription-table tr').length == 0) {
            $('.subscriptionAddItems').css('margin-bottom', '60px');
        } else {
            $('.subscriptionAddItems').css('margin-bottom', '0px');
        }
    });

    if ($('.subscription-table tr').length == 0) {
        $('.subscriptionAddItems').css('margin-bottom', '60px');
    } else {
        $('.subscriptionAddItems').css('margin-bottom', '0px');
    }

    $(document).on('click', '#selectshipaddr,#cancelBtn', function(e) {
        $("#addShippaddrPopup  button.close").trigger('click');
    });

    $(document).on('click', '.shipaddrmore', function(e) {
        var popupHeadingText;
        if ($(this).attr('id') == 'editBillingAddr') {
            popupHeadingText = $('#billAddress').val();
            popupHeadingText = 'Billing Addresses';
        } else if ($(this).attr('id') == 'editShippingAddr') {
            popupHeadingText = $('#shipAddress').val();
            popupHeadingText = 'Shipping Addresses';
        }
        $("#addShippaddrPopup .modal-content .modal-title").text(popupHeadingText);
        if (window.innerHeight > 538 + 79) {
            var parentWindowHeight = window.innerHeight;
            var overLayHeight = 538 + 79;
            var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
            if (navigator.userAgent.match(/msie/i)) {
                calcOverlayTop = calcOverlayTop - 2;
            }
            if (navigator.userAgent.match(/chrome/i) || navigator.userAgent.match(/firefox/i)) {
                calcOverlayTop = calcOverlayTop - 2;
            }
            $("#addShippaddrPopup .modal-content").css("top", calcOverlayTop + 'px');
        }
    });

    /*$('.textboxQnty').on('keyup', function() {
        var txtVal = $(this).val();
        if (/^[0-9]+$/.test(txtVal) && ((txtVal >= 0) && (txtVal <= 99999))) {
            if ($(this).next().find('.updateQtyRef').hasClass('hide')) {
                $(this).next().find('.updateQtyRef').removeClass('hide');
                $(this).removeClass('invalid');
                $(this).removeClass('requiredTextBox');
                $(this).parent().find(".requiredText").hide();
            }
        } else {
            $(this).next().find('.updateQtyRef').addClass('hide');
            $(this).removeClass('invalid');
            $(this).addClass('requiredTextBox');
            $(this).parent().find(".requiredText").css('display', 'block');
        }
    });*/
	
	$(document).on("keyup", "#subscriptionItemTable .textboxQnty", function(e) {
		var txtVal = $(this).val();
		var $this = $(this);
		$this.val($this.val().replace(/[^\d]/g, ''));
		if($this.val() == 0){
			$this.val('');
		}
		if (/^[0-9]+$/.test(txtVal) && ((txtVal > 0) && (txtVal <= 99999))) {
            if ($(this).next().find('.updateQtyRef').hasClass('hide')) {
                $(this).next().find('.updateQtyRef').removeClass('hide');
            }
        } else {
            $(this).next().find('.updateQtyRef').addClass('hide');
        }
	});
	$(document).on("blur", "#subscriptionItemTable .textboxQnty", function(e) {
		var $this = $(this);
		if($this.val() == ''){
			$this.val('1');
			if ($(this).next().find('.updateQtyRef').hasClass('hide')) {
                $(this).next().find('.updateQtyRef').removeClass('hide');
		}
		}
		
	});

	$(document).on("keyup", "#subscribedQty", function(e) {
		var $this = $(this);
		$this.val($this.val().replace(/[^\d]/g, ''));
		if($this.val() == 0){
			$this.val('');
		}
	});
	$(document).on("keypress", "#subscriptionForm input:not(#subscribedPartnum,#subscribedQty,#subscriptionItemTable .textboxQnty),#subscriptionForm textarea", function(e) {
	  if (e.which == 13) {
	   console.log(e.which);
	   $('#submitSubr').trigger('click');  
	   var dovalidateEnter = LSCA.GlobalValidate.init({
            target : '#subscriptionForm'
        });
		if(!dovalidateEnter || emailCheck || poNumberCheck){
		return false;		
		}
	  }
	});
	$(document).on("keypress", "#subscribedPartnum,#subscribedQty", function(e) {
		if (e.which == 13) {
		   $('#add-quick-order-item').trigger('click');	
		   return false;		   
        }				
	});
	$(document).on("keypress", "#subscriptionItemTable .textboxQnty", function(e) {
		if (e.which == 13) {
			e.preventDefault();
            return false;
		}
	});
	$(document).on("blur", "#subscribedQty", function(e) {
		var $this = $(this);
		if($this.val() == ''){
			$this.val('1');
		}
	});

    $(document).on('click', '.purchaseTypeOpt', function(e) {
        if ($('input[name="purchaseTypeOpt"]:checked').val() == 'creditCard') {
            $('.infoBlueBox').show();
            $('#subscriptionPoNumber').next().next().hide();
            $('#subscriptionPoNumber').prev('.radioText').removeClass('requiredLabel');
            $('#subscriptionPoNumber').removeClass('requiredTextBox');
            $('#subscriptionPoNumber').removeClass('required');
            $('#subscriptionPoNumber').attr('style', '');
			$('#subscriptionPoNumber').attr('readonly',true);
			$('#subscriptionPoNumber').addClass('DisabledText');
			$('#subscriptionPoNumber').val('');
        } else {
            $('.infoBlueBox').hide();
            $('#subscriptionPoNumber').addClass('required');
			$('#subscriptionPoNumber').attr('readonly',false);
			$('#subscriptionPoNumber').removeClass('DisabledText');
        }
    });

    $('#createshipaddr').off().on('click', function() {
    	var createSelectedShipAddr = $('input[type=radio][name=createshippingAddressData]:checked').attr('id');
        $.ajax({
            type : "POST",
            url : "/common/checkout/createSubscriptionShipAddress.jsp?addressId=" + createSelectedShipAddr,
            dataType : "html"
        }).done(function(msg) {
            $("#createShippAddrSelectedData").html(msg);
            copyfromHidden();
            $("#createShippaddrPopup  button.close").trigger('click');
           
        }).fail(function() {
            console.log('Something went wrong!')
        });
    });
    $('.subscriptionCancelShipping').on('click', function() {
        $("#createShippaddrPopup  button.close").trigger('click');
    });

    $('#createbilladdr').off().on('click', function() {
        var createSelectedBillAddr = $('input[type=radio][name=createbillingAddressData]:checked').attr('id');
        $.ajax({
            type : "POST",
            url : "/common/checkout/createSubscriptionBillAddress.jsp?addressId=" + createSelectedBillAddr,
            dataType : "html"
        }).done(function(msg) {
            $("#createSelectedBillAddrSelectedData").html(msg);
            $("#createBillingaddrPopup  button.close").trigger('click');
        }).fail(function() {
            console.log('Something went wrong!')
        });
    });
    $('.subscriptionCancelBilling').on('click', function() {
        $("#createBillingaddrPopup  button.close").trigger('click');
    });
    $('.subscriptionShippingEdit').off().on('click', function() {
        var subscriptionshipAddrValue = $('input[name=shipSubAddress]').val();
        $("#createShippaddrPopup input[name=createshippingAddressData][value='addressId=" + subscriptionshipAddrValue + "']").attr('checked', 'checked');
        setTimeout(function() {
			console.log($('#createShippaddrPopup #shippingPopUpList .shipAddressList').hasScrollBar());
			if(!$('#createShippaddrPopup #shippingPopUpList .shipAddressList').hasScrollBar()) {
				$('#createShippaddrPopup #shippingPopUpList .shipAddressList').css('margin-right','43px');
			}
			else {
				$('#createShippaddrPopup #shippingPopUpList .shipAddressList').css('margin-right','0px');
			}
			console.log($('#createShippaddrPopup #shippingPopUpList .shipAddressList').hasScrollBar());
			var addrLength = $('#createShippaddrPopup .modal-content #shippingPopUpList .shipAddressList li').length * 30;
			addrLength = addrLength + 200;
			console.log('oh : '+addrLength);
			console.log('wh : '+window.innerHeight);
			if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
				if (window.innerHeight > addrLength) {
					var parentWindowHeight = window.innerHeight - 60;
					var overLayHeight = addrLength;
					var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
					// $("#createShippaddrPopup .modal-content").css("top", calcOverlayTop + 30 + 'px');
				}
			}
			if (navigator.userAgent.match(/chrome/i) || navigator.userAgent.match(/firefox/i)) {
				console.log('ot : '+$("#createShippaddrPopup .modal-content").outerHeight(true));
				console.log('wh : '+window.innerHeight);
            if (window.innerHeight > $("#createShippaddrPopup .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#createShippaddrPopup .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                // $("#createShippaddrPopup .modal-content").css("top", calcOverlayTop + 30 + 'px');
            }
			}
        }, 200);
    });
    $('.subscriptionBillingEdit').off().on('click', function() {
        var subscriptionbillAddrValue = $('input[name=billSubAddress]').val();
        $("#createBillingaddrPopup input[name=createbillingAddressData][id='" + subscriptionbillAddrValue + "']").attr('checked', 'checked');
        setTimeout(function() {
			console.log($('#createBillingaddrPopup #shippingPopUpList .shipAddressList').hasScrollBar());
			if(!$('#createBillingaddrPopup #shippingPopUpList .shipAddressList').hasScrollBar()) {
				$('#createBillingaddrPopup #shippingPopUpList .shipAddressList').css('margin-right','43px');
			}
			else {
				$('#createBillingaddrPopup #shippingPopUpList .shipAddressList').css('margin-right','0px');
			}
			console.log($('#createBillingaddrPopup .modal-content #shippingPopUpList .shipAddressList li').length);
			var addrLength = $('#createBillingaddrPopup .modal-content #shippingPopUpList .shipAddressList li').length * 30;
			addrLength = addrLength + 200;
			console.log('oh : '+addrLength);
			console.log('wh : '+window.innerHeight);
			if (navigator.userAgent.match(/msie/i) || navigator.userAgent.match(/trident/i)) {
				if (window.innerHeight > addrLength) {
					var parentWindowHeight = window.innerHeight - 60;
					var overLayHeight = addrLength;
					var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
					// $("#createBillingaddrPopup .modal-content").css("top", calcOverlayTop + 30 + 'px');
				}
			}
			if (navigator.userAgent.match(/chrome/i) || navigator.userAgent.match(/firefox/i)) {
				console.log('ot : '+$("#createBillingaddrPopup .modal-content").outerHeight(true));
				console.log('wh : '+window.innerHeight);
            if (window.innerHeight > $("#createBillingaddrPopup .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#createBillingaddrPopup .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                // $("#createBillingaddrPopup .modal-content").css("top", calcOverlayTop + 30 + 'px');
            }
			}
        }, 200);
    });
    $(document).on('click', '#cancelSkipLink', function(e) {
        $("#skipNextOrderPopup div#skipClose").trigger('click');
    });
    $(document).on('click', '#skipNextOrderBtn', function(e) {
        $("#skipNextOrderPopup div#skipClose").trigger('click');
        $('#skipNextSubOrderSbmt').click();
        LSCA.loadingSpinner.showLoading(); 
    });
    $(document).on('click', '#cancelSubNoLink', function(e) {
        $("#cancelSubscriptionPopup div#cancelClose").trigger('click');
    });
    $(document).on('click', '#cancelSubYesBtn', function(e) {
    	$("#hiddenCancelReason").val($("#cancelReason").val());
        $("#cancelSubscriptionPopup div#cancelClose").trigger('click');
        $('#cancelSubscriptionSbmt').click();
        LSCA.loadingSpinner.showLoading(); 
    });
    $(document).on('click', '#cancelSubDeleteLink', function(e) {
        $("#deleteSubscriptionPopup div#deleteSubClose").trigger('click');
    });
    $(document).on('click', '#deleteSubscriptionBtn', function(e) {
        $("#deleteSubscriptionPopup div#deleteSubClose").trigger('click');
        $('#deleteSubscriptionSbmt').click();
    });
    $(document).on('click', '#editSubscriptionBlock .skip-button', function(e) {
        setTimeout(function() {
            if (window.innerHeight > $("#skipNextOrderPopup .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#skipNextOrderPopup .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                // $("#skipNextOrderPopup .modal-content").css("top", calcOverlayTop + 'px');
            }
        }, 200);
    });
    $(document).on('click', '#editSubscriptionBlock #cancelSubscription', function(e) {
        setTimeout(function() {
            if (window.innerHeight > $("#cancelSubscriptionPopup .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#cancelSubscriptionPopup .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                // $("#cancelSubscriptionPopup .modal-content").css("top", calcOverlayTop + 'px');
            }
        }, 200);
    });
    $(document).on('click', '.mySubscriptionContent .mySubRemoveImg', function(e) {
        setTimeout(function() {
            if (window.innerHeight > $("#deleteSubscriptionPopup .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#deleteSubscriptionPopup .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                $("#deleteSubscriptionPopup .modal-content").css("top", calcOverlayTop + 'px');
            }
        }, 200);
    });
	
	function stringTruncation(myString, maxLen){
		var myString = myString.trim();
		   if(myString.length > maxLen) {
				var myTruncatedString = myString.substring(0,maxLen);
				myTruncatedString = myTruncatedString.trim() + '...';
				return myTruncatedString;
			} else {
				return myString;
			}
	}
	
	$('#subscriptionItemTable .partNumberDesc').each(function() {
			var formatedText = stringTruncation($(this).text(), 62);
			$(this).text(formatedText);
    });	
	$('#review-detail-table .partNumberDesc').each(function() {
			var formatedText = stringTruncation($(this).text(), 62);
			$(this).text(formatedText);
    });			
	function scrollToWindowPostion(scrollSection, position){
		if(position == 0){
			position = 50;
		}
		//$(document).scrollTop($(document).find(scrollSection).position().top - position);
		$(document).scrollTop($(document).find(scrollSection).offset().top - position);
	}

	function getScrollSection(){
		//console.log('ddtt', subSection);
		if(subSection.basicInfo){
			scrollSection = 'div.subscriptionSection';
		} else if(subSection.billingInfo) {
			scrollSection = 'div.subscriptionBillingInfo';		
		}  else if(subSection.shipInfo) {
			scrollSection = 'div.subscriptionShippingInfo';		
		}  else if(subSection.shipMethod) {
			scrollSection = 'div.subscriptionShippingMethod';		
		}  else if(subSection.paymentInfo) {
			scrollSection = 'div.subscriptionPayment';		
		}	else if(subSection.itemInfo) {
			scrollSection = 'div.subscriptionAddItems';		
		}	
		scrollToWindowPostion(scrollSection, 0);
		subSection = { basicInfo : false, billingInfo : false, shipInfo : false, shipMethod : false, paymentInfo : false, itemInfo : false };		
	}
		
	function focusOnLastAction(){
		if($.trim($('#errorMessage').text()) == '' && $.trim($('#subscriptionSuccessMsg').text()) == '') {
			var actionSection = getSectionPosition("itemSection"); 
			if(actionSection == 'addItem'){
				scrollToWindowPostion('div.subscriptionAddItems', 0);
			} else if(actionSection == 'updOrRemoveItem'){ 
				scrollToWindowPostion('table#subscription-detail-table', 0);
			}        			
		} 	
		setSectionPosition("itemSection", 0);
	}
	if(window.location.href.indexOf('createSubscription.jsp') != -1){
		focusOnLastAction();
	}
});

function updateSubscriptionItemQty(partNumber) {
    $('#subUpdatePartNumber').val(partNumber);
    var dynamicQtyId = '#subItemQty' + partNumber;
    $('#subUpdateItemQty').val($(dynamicQtyId).val());
    $('#subscriptionSubmitType').val("updItem");
	setSectionPosition("itemSection", 'updOrRemoveItem');
    $('#subscriptionSbmt').click();
}

function removeSubscriptionItem(commerceItemId) {
    $('#subRemoveItemId').val(commerceItemId);
    $('#subscriptionSubmitType').val("rmvItem");
	setSectionPosition("itemSection", 'updOrRemoveItem');
    $('#subscriptionSbmt').click();
}

function removeSubscription(element, encryptedSubscriptionId, subscriptionName) {
    $('#deleteSubscriptionId').val($.trim($(element).attr('id')));
    $('#deleteEncryptedSubId').val($.trim(encryptedSubscriptionId));
    $('#deleteSubscriptionName').val($.trim(subscriptionName));
    $("#deleteSubscriptionPopup").modal();
    $("#subsCancelError").hide();
}

$(".reviewSubscription .terms-conditioncn input").on("change",function() {    
    if($(this).prop("checked") == true){        
        $(".terms-conditioncn").removeClass("notchecked");
        $("#tandcErrorMsgcn").hide();
    }
    else{    
        $(".terms-conditioncn").addClass("notchecked");
        $("#tandcErrorMsgcn").show();
    }
});

function reviewClickSubmit() {
    if (!$("#subscriptiongreeCheckbox").is(":checked")) {
        setTimeout(function() {
            if (window.innerHeight > $("#reviewCheckboxModal .modal-content").outerHeight(true)) {
                var parentWindowHeight = window.innerHeight - 60;
                var overLayHeight = $("#reviewCheckboxModal .modal-content").outerHeight(true);
                var calcOverlayTop = (parentWindowHeight - overLayHeight) / 2;
                $("#reviewCheckboxModal .modal-content").css("top", calcOverlayTop + 'px');
            }
        }, 200);
        $("#reviewCheckboxModal").modal();
    } else {
		if($(".terms-conditioncn input").is(":visible")){
			if ($(".terms-conditioncn input").is(":checked")) {
				$(".terms-conditioncn").removeClass("notchecked");
				$("#tandcErrorMsgcn").hide();
				if (selectedPaymentMethod == 'creditCard' && creditCardEdit == 'false') {
					submitForm();
				} else {
					document.getElementById('formSubmit').click();
				}
			} else {
				$(".terms-conditioncn").addClass("notchecked");
				$("#tandcErrorMsgcn").show();
			}
		}else{
			if (selectedPaymentMethod == 'creditCard' && creditCardEdit == 'false') {
				submitForm();
			} else {
				document.getElementById('formSubmit').click();
			}
		}
    }      
}
function copyfromHidden() {
    $("#shipBuildingNo").val($("#hiddenbuildNo").text());
    $("#shipAttnno").val($("#hiddenShipAttn").text());
	$("#shipAttnnoCN").val($("#hiddenShipAttn").text());
    if (document.getElementById('ShipPhoneNo')) {
        $("#ShipPhoneNo").val($("#hiddenPhoneNo").text());
    }
}

function getSectionPosition(objName){
	if (typeof(Storage) !== undefined) {
		return sessionStorage.getItem(objName);
	}
}

function setSectionPosition(objKey, objValue){
	if (typeof(Storage) !== undefined) {
		sessionStorage.setItem(objKey, objValue);
	}
}

function changePurchaseOrder() {
	$('#purchasePreviousPay').hide();
	$('#purchasePOCC').show();
	$('#creditPOCC').show();
	$('#cardMaskedNumber').val('');
	if ($('input[name="purchaseTypeOpt"]:checked').val() == 'creditCard') {
	    $('#subCC').val("false");
	} else {
	    $('#subCC').val("true");
	}
	if($('#submitSubr').hasClass('disabled-saveBtn')){
		$('#submitSubr').removeClass('disabled-saveBtn');
} 
} 

$('input[type=radio][name=purchaseTypeOpt]').on('change',function() {
	$('#cardMaskedNumber').val('');
    if (this.value == 'creditCard') {
        $('#subCC').val("false");
    } else {
        $('#subCC').val("true");
    }
}); 

