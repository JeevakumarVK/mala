/*This script has been created for Google Analytics implementation*/

$(document).ready(function(){
		$('.formQuote input, .formQuote select, .formQuote textarea').on('change',function() {
		   var currentId = $(this).attr('id');
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Request For Quote', 'eventAct':'Form Interactions', 'eventLbl':currentId , 'eventVal':0 });
	
		});
			
});
		$(document).ready(function() {
			  $("#btnLogin").on('click',function(e){
					 dataLayer.push({'event': 'eventTracker', 'eventCat': 'Login', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':0 }); 
			  });
			  $("#submitQuote").on('click',function(e){
				  document.getElementById('sbmtQuote').click();
				  dataLayer.push({'event': 'eventTracker', 'eventCat': 'Request For Quote', 'eventAct':'Button Clicked', 'eventLbl': '', 'eventVal':0 }); 
			  });
			$(document).find(".removeID").on("click",function(){ 
				$(".citemhidden").val($(this).attr("id"));
				setTimeout(function(){$("#removeItemBtn").click()},3000);
			});
			
			// Quick order -  Large file Checkout
			$("#quick-order-file-upload-large").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'LARGE FILE CHECKOUT', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':'quick-order-file-upload-large'}); 
			});
			// Quick order -  Large file order review and Submit
			$("#btnPlaceLargeOrder").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'LARGE FILE SUBMIT', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':'btnPlaceLargeOrder'}); 
			});
			// View Service Contract - Download 
			$("#view-service-agreement  #downloadViewService").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Review Contract Page', 'eventLbl': 'Download PDF', 'eventVal':'0'}); 
			});			
			// View Service Contract - View Exhibits  
			$("#view-service-agreement .custom-back-button.btn.left-ext").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Review Contract Page', 'eventLbl': 'View Exhibits', 'eventVal':'0'}); 
			});				
			// Quote Details - Download 
			$(".QuoteDetails #downloadQuote").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Renew Contract Page', 'eventLbl': 'Download PDF', 'eventVal':'0'}); 
			});					
			// Quote Details - View Exhibits  
			$(".QuoteDetails .custom-back-button.btn.left-ext").on('click',function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Renew Contract Page', 'eventLbl': 'View Exhibits', 'eventVal':'0'}); 
			});	
			// Quote Details - View Current Contract 
			$(".QuoteDetails .ViewCurrentContract a").on('click',function(e){				
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Renew Contract Page', 'eventLbl': 'View Contract - '+$('#gaContractID').val(), 'eventVal':'0'});		
			});				
			// Quote Details - Next
			$(".QuoteDetails .cus_bott_right_button > button").on('click',function(e){				
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Renew Contract Page', 'eventLbl': 'Click Next', 'eventVal':'0'});	
			});						
			// renewContractPayment -   Place order
			$("#btnPOPlaceOrder,#btnCCPlaceOrder").on('click',function(e){
				gaContractID = $('#gaContractID').val() ? $('#gaContractID').val():'';
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Service Contract', 'eventAct':'Payment Page', 'eventLbl':gaContractID, 'eventVal':'0'}); 
			});				
		});
		
function trackRemoveItemfromCart(currencyCode,prodDesc,partNumber,itemPrice,prodVarient,itemQty,categoryName,categoryId) {
	dataLayer.push({
		'event' : 'eventTracker',
		'eventCat' : 'eCommerce',
		'eventAct' : 'Remove from Cart',
		'eventLbl' : prodDesc,
		'eventVal' : 0,
		'ecommerce' : {
			'currencyCode' : currencyCode,
			'remove' : {
				'products' : [ {
					'name' : prodDesc,
					'id' : partNumber,
					'price' : itemPrice,
					'brand' : 'Agilent Technologies',
					'category' : categoryName,
					'variant' : prodVarient,
					'quantity' : itemQty,
					'dimension14': categoryId
				} ]
			}
		},
		'eventCallback' : function() {
			dataLayer.push({
				'ecommerce' : undefined
			});
		}
	});
}

