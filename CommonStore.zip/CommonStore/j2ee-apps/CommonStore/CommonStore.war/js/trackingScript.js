/*This script has been created for Google Analytics implementation*/

$(document).ready(function(){
		$('.formQuote input, .formQuote select, .formQuote textarea').change(function() {
		   var currentId = $(this).attr('id');
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'Request For Quote', 'eventAct':'Form Interactions', 'eventLbl':currentId , 'eventVal':0 });
	
		});
			
});
		$(document).ready(function() {
			  $("#btnLogin").click(function(e){
					 dataLayer.push({'event': 'eventTracker', 'eventCat': 'Login', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':0 }); 
			  });
			  $("#submitQuote").click(function(e){
				  document.getElementById('sbmtQuote').click();
				  dataLayer.push({'event': 'eventTracker', 'eventCat': 'Request For Quote', 'eventAct':'Button Clicked', 'eventLbl': '', 'eventVal':0 }); 
			  });
			$(document).find(".removeID").on("click",function(){ 
				$(".citemhidden").val($(this).attr("id"));
				setTimeout(function(){$("#removeItemBtn").click()},3000);
			});
			
			// Quick order -  Large file Checkout
			$("#quick-order-file-upload-large").click(function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'LARGE FILE CHECKOUT', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':'quick-order-file-upload-large'}); 
			});
			// Quick order -  Large file order review and Submit
			$("#btnPlaceLargeOrder").click(function(e){
				dataLayer.push({'event': 'eventTracker', 'eventCat': 'LARGE FILE SUBMIT', 'eventAct':'Button Click', 'eventLbl': '', 'eventVal':'btnPlaceLargeOrder'}); 
			});
		});
		
function trackRemoveItemfromCart(currencyCode,prodDesc,partNumber,itemPrice,prodVarient,itemQty,categoryName,categoryId) {
	dataLayer.push({
		'event' : 'eventTracker',
		'eventCat' : 'eCommerce',
		'eventAct' : 'Remove from Cart',
		'eventLbl' : prodDesc,
		'eventVal' : 0,
		'ecommerce' : {
			'currencyCode' : currencyCode,
			'remove' : {
				'products' : [ {
					'name' : prodDesc,
					'id' : partNumber,
					'price' : itemPrice,
					'brand' : 'Agilent Technologies',
					'category' : categoryName,
					'variant' : prodVarient,
					'quantity' : itemQty,
					'dimension14': categoryId
				} ]
			}
		},
		'eventCallback' : function() {
			dataLayer.push({
				'ecommerce' : undefined
			});
		}
	});
}

