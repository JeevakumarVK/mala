package com.agilent.commonstore.analytics.droplet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.commons.lang3.LocaleUtils;

import atg.commerce.order.CommerceItem;
import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;
import atg.userprofiling.Profile;

import com.agilent.base.commerce.cache.PartDetailsCacheResponse;
import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.AgilentOrderHolder;
import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.platform.Constants;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.pricing.AgilentItemPriceInfo;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.util.AgilentUtil;
import com.agilent.datagrid.helper.DataGridRestHelper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
/**
 * @author avneetkaur.m
 * @project Agilent.Hydra
 * 
 */

public class AnalyticsOrderConfirmationGenerator extends DynamoServlet{

	public static final String OUTPUT = "output";	 
	private static final ParameterName OPARAM_OUTPUT = ParameterName.getParameterName(OUTPUT);

	private AgilentCatalogTools 		mCatalogTools;	
	AgilentOrderHolder 					mShoppingCart;
	private Repository 					mProductCatalog; 	
	private CountryUtils       			mCountryUtils;
	private Map<String, String> 		mCurrencyCodeToLocaleMap;
	private DataGridRestHelper mDataGridRestHelper;
	

	@Override
	public void service(final DynamoHttpServletRequest request, final DynamoHttpServletResponse response)
		throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        vlogDebug("AnalyticsOrderConfirmationGenerator::service:: START TIME:: {0}", startTime);
	    
		String currencyCode = "";
		String taxAmount="";
		String totalAmount="";
		String shippingAmout="";
		String couponCode="";
		RepositoryItem productItem = null;
		String productId="";
		String orderRef="";
		String salesOrg = null;
		JsonArray products = new JsonArray();
		JsonObject productString=new JsonObject();
		String pagename=request.getServletPath();
		/*Genomics parameters*/
		String prodName = null;
		String genCateId="";
		String skuId = null;
		String genDescription = null;
		String language = null;		 
		language = requestLocale().getLanguage();
		
		Profile profile = (Profile) request.resolveName("/atg/userprofiling/Profile");
		AgilentProfile agilentProfile=(AgilentProfile)profile;
		String country = agilentProfile.getUserCountry(); 
		try {
			salesOrg= getCountryUtils().getSalesOrgForCountry(country);
			currencyCode = getCountryUtils().getSalesOrgCurrencyCodeMap().get(salesOrg);
		} catch (RepositoryException e) {
			vlogError("SalesOrganization can not find", profile);
		}
		
		String currencyLocale = getCurrencyCodeToLocaleMap().get(currencyCode);
		Locale locale = LocaleUtils.toLocale(currencyLocale);
		
		AgilentOrder order= (AgilentOrder) getShoppingCart().getCurrent();
		vlogDebug("Current order:" +order);
		vlogDebug("PageName analytics order confirmation page:" +pagename);
		if((pagename.contains("thankuForYourOrder.jsp") || pagename.contains("orderConfirmation.jsp")) && order.isTransient()){
			order=(AgilentOrder) getShoppingCart().getLast();
			vlogDebug("Last order/Order confirmation page:" +order);
		}
		productString=new JsonObject();
		if(null !=order){
		orderRef = order.getSapOrderId();
		vlogDebug("SAP Order Id:" +orderRef);
		if(null == orderRef){
			orderRef = order.getId();
			vlogDebug("Sap is down or web order is placed. WEB Order Id:" +orderRef);
		}
		
			try {
			final List<CommerceItem> items = order.getCommerceItems();
			if(null!=order.getPriceInfo()){
				taxAmount=AgilentUtil.getPriceFormat(convertCurrency(order.getPriceInfo().getTax(),locale));
				totalAmount=AgilentUtil.getPriceFormat(convertCurrency(order.getPriceInfo().getTotal(),locale));
				shippingAmout=AgilentUtil.getPriceFormat(convertCurrency(order.getPriceInfo().getShipping(),locale));
			}
			couponCode=order.getCouponCode();
			
			if (items != null) {
				Map<String, PartDetailsCacheResponse> partDataGridDetails = null;
				partDataGridDetails = getDataGridRestHelper().fetchDescriptionForCommerceItems(items,(AgilentProfile) profile,language);
				
				for (final CommerceItem item : items) {
					
					String productLine=(String) ((RepositoryItem) item.getAuxiliaryData().getCatalogRef()).getPropertyValue("productLine");
					//AMS-432 Fix for PL missing START
					if(null != productLine && (productLine.contains("UF") || productLine.contains("GE"))){
					//AMS-432 Fix for PL missing END	
						/*For Genomics products*/
						try {
							productId = item.getAuxiliaryData().getProductId();
							productItem = getProductCatalog().getItem(productId, "product");
							prodName = productItem.getItemDisplayName();
							String cateId = getDataGridRestHelper().getCategoryIdFromPartId(productId);
							ArrayList<String> catList = new ArrayList<String>();
							catList.clear();
							catList.add(cateId);
							Map<String, String> catMap   = new HashMap<String, String>();							
							catMap = getDataGridRestHelper().getParentInfo(catList, language);
							if (catMap != null && !catMap.isEmpty()){						
								genCateId =	catMap.get(Constants.ID);							 
							}
							RepositoryItem skuItem = (RepositoryItem) item.getAuxiliaryData().getCatalogRef();
								JsonObject productMap = new JsonObject();
								skuId = (String) skuItem.getPropertyValue("catalogId");
								genDescription = skuItem.getItemDisplayName();
								productMap.addProperty("name", prodName);
								productMap.addProperty("id", skuId);
								productMap.addProperty("brand", "Agilent Technologies");
								productMap.addProperty("variant", genDescription);
								productMap.addProperty("category", prodName);
								productMap.addProperty("quantity", String.valueOf(item.getQuantity()));
								productMap.addProperty("dimension14", genCateId);
								if(null!=item.getPriceInfo()){
								productMap.addProperty("price", AgilentUtil.getPriceFormat(convertCurrency(item.getPriceInfo().getListPrice(),locale)));
								productMap.addProperty("yprice", AgilentUtil.getPriceFormat(convertCurrency(((AgilentItemPriceInfo) item.getPriceInfo()).getYourPrice(),locale)));
								}
								products.add(productMap);
								productString.add("products", products);
						} catch (RepositoryException e) {
							e.printStackTrace();
						}
					}else{
					productId=item.getAuxiliaryData().getProductId();
					productItem = getProductCatalog().getItem(productId, "product");
					Map<String, Map<String, String>> partsMap = null;
					String description ="";
					if(StringUtils.isNotEmpty(productId)){
//						List<String> partNumberList = new ArrayList<String>();
//						partNumberList.add(productId);
//						vlogDebug("Current Language: {0} ::::: Part Number List : {1}", language, partNumberList);
//						// Getting Part number Details from PartNumber List
//						partsMap = getDataGridRestHelper().getPartNumbersMap(partNumberList,language);
//						if (partsMap != null && !partsMap.isEmpty()){
//							Map<String, String> partMap = partsMap.get(productId);
//							if (partsMap != null && !partsMap.isEmpty()){
//								description = partMap.get(Constants.DESCRIPTION);
//							}
//						}		
						
						if (partDataGridDetails != null && !partDataGridDetails.isEmpty()
								&& partDataGridDetails.get(productId) != null) {
							description = partDataGridDetails.get(productId).getDescription();
						}
					}
					String cateId = getDataGridRestHelper().getCategoryIdFromPartId(productId);					
					ArrayList<String> catList = new ArrayList<String>();
					catList.clear();
					catList.add(cateId);
					Map<String, String> catMap   = new HashMap<String, String>();
					JsonObject productMap=new JsonObject();
					catMap = getDataGridRestHelper().getParentInfo(catList, language);
					if (catMap != null && !catMap.isEmpty()){						
					productMap.addProperty("name", catMap.get(Constants.NAME));
					productMap.addProperty("category", catMap.get(Constants.NAME));
					}
					productMap.addProperty("id", productId);
					if(null!=item.getPriceInfo()){
					productMap.addProperty("price", AgilentUtil.getPriceFormat(convertCurrency(item.getPriceInfo().getListPrice(),locale)));
					productMap.addProperty("yprice", AgilentUtil.getPriceFormat(convertCurrency(((AgilentItemPriceInfo) item.getPriceInfo()).getYourPrice(),locale)));
					}
					productMap.addProperty("brand", "Agilent Technologies");					
					productMap.addProperty("variant", description);
					productMap.addProperty("quantity", String.valueOf(item.getQuantity()));
					productMap.addProperty("dimension14", catMap.get(Constants.ID));
					products.add(productMap);
					productString.add("products", products);
				}
			  }
			} else {
				if (this.isLoggingDebug()) {
					this.vlogDebug("last shopping cart Items are null");
				}
			}
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		}
		request.setParameter("id", orderRef);
		request.setParameter("affiliation", "Agilent Technologies Store");
		request.setParameter("revenue",totalAmount);
		request.setParameter("tax", taxAmount);
		request.setParameter("shipping", shippingAmout);
		request.setParameter("coupon", couponCode);
		request.setParameter("products", productString.toString());
		request.setParameter("currencyCode", currencyCode);
		request.serviceLocalParameter(OPARAM_OUTPUT, request, response);
		
		long endTime = System.currentTimeMillis();
        vlogDebug("AnalyticsOrderConfirmationGenerator::service:: END TIME:: {0} :: TOTAL TIME:: {1}", endTime, (endTime - startTime));

	}
	
		/** It return the local to get the language  
		 * @return
		 */
		public static Locale requestLocale() {
			Locale locale = ServletUtil.getCurrentRequest().getRequestLocale().getLocale();
	        if (locale == null) {
	            locale = new Locale(Constants.DEFAULT_LANGUAGE, Constants.DEFAULT_COUNTRY); 
	        }
			return locale;
		}

	
	private String convertCurrency( Object pCurrency, Locale pLocale) {
        return AgilentCurrencyTagConverter.formatCurrency(pCurrency, pLocale);
    }

	/**
	 * @return the catalogTools
	 */
	public AgilentCatalogTools getCatalogTools() {
		return mCatalogTools;
	}


	/**
	 * @param pCatalogTools the catalogTools to set
	 */
	public void setCatalogTools(AgilentCatalogTools pCatalogTools) {
		mCatalogTools = pCatalogTools;
	}


	/**
	 * @return the shoppingCart
	 */
	public AgilentOrderHolder getShoppingCart() {
		return mShoppingCart;
	}


	/**
	 * @param pShoppingCart the shoppingCart to set
	 */
	public void setShoppingCart(AgilentOrderHolder pShoppingCart) {
		mShoppingCart = pShoppingCart;
	}



	/**
	 * @return the productCatalog
	 */
	public Repository getProductCatalog() {
		return mProductCatalog;
	}



	/**
	 * @param pProductCatalog the productCatalog to set
	 */
	public void setProductCatalog(Repository pProductCatalog) {
		mProductCatalog = pProductCatalog;
	}

	/**
	 * @return the mCountryUtils
	 */
	public CountryUtils getCountryUtils() {
		return mCountryUtils;
	}

	/**
	 * @param mCountryUtils the mCountryUtils to set
	 */
	public void setCountryUtils(CountryUtils mCountryUtils) {
		this.mCountryUtils = mCountryUtils;
	}

	/**
	 * @return the mCurrencyCodeToLocaleMap
	 */
	public Map<String, String> getCurrencyCodeToLocaleMap() {
		return mCurrencyCodeToLocaleMap;
	}

	/**
	 * @param mCurrencyCodeToLocaleMap the mCurrencyCodeToLocaleMap to set
	 */
	public void setCurrencyCodeToLocaleMap(Map<String, String> mCurrencyCodeToLocaleMap) {
		this.mCurrencyCodeToLocaleMap = mCurrencyCodeToLocaleMap;
	}

    /**Gets the value of property DataGridRestHelper
     * @return
     */
    public DataGridRestHelper getDataGridRestHelper() {
		return mDataGridRestHelper;
	}

	/**Sets the value of property dataGridRestHelper with value mDataGridRestHelper
	 * @param dataGridRestHelper
	 */
	public void setDataGridRestHelper(DataGridRestHelper dataGridRestHelper) {
		this.mDataGridRestHelper = dataGridRestHelper;
	}

}