package com.agilent.commonstore.commerce.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;
import static com.agilent.base.platform.Constants.PARAM_PAYMENT_OPTION;
import static com.agilent.base.platform.Constants.OPARAM_DOC_SUBMIT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;


import atg.commerce.order.Order;
import atg.commerce.order.OrderHolder;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;

public class AdrFileMessageDroplet extends DynamoServlet {

	private Profile profile;
	private List<String> allowedCountryList;
	private String isAddFileUploaded="isAddFileUploaded";
	private final String PURCHASE_ORDER="purchaseOrder";
	private List<String> ordDocSalesOrgList;
	
	public void service( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
		String country=null;
		String sapContact=null;
		String sapSalesOrg=null;
		ParameterName paymentOption = ParameterName.getParameterName(PARAM_PAYMENT_OPTION);
		String paymentType =  (String) request.getObjectParameter(paymentOption);
		vlogDebug("Inside AdrFileMessageDroplet class value of parameter paymentOption -{0}", paymentType);
		OrderHolder currentCart = (OrderHolder) request.resolveName("/atg/commerce/ShoppingCart");
		Order order = currentCart.getLast();
		Profile profile = (Profile) request.resolveName("/atg/userprofiling/Profile");
		boolean prevAddFileUploaded=(Boolean)profile.getPropertyValue(isAddFileUploaded);
		if(profile !=null){
		  country=(String) profile.getPropertyValue("userCountry");
		  sapContact=(String) profile.getPropertyValue("sapContactNumber");
		  sapSalesOrg=(String) profile.getPropertyValue("sapSalesOrg");
		  
		}
		if(getAllowedCountryList().contains(country) && sapContact == null && !prevAddFileUploaded){
			vlogDebug("Inside AdrFileMessageDroplet class,Setting OUTPUT service parameter");
			request.serviceParameter(OUTPUT, request, response);
		}
		/**
		 * Added for AP-732 doc upload for PO
		 * Commented below line as this is not part of Sep RBE Release
		 */
		/*else if( !paymentType.isEmpty() && paymentType.equals(PURCHASE_ORDER) && null != sapSalesOrg && !getOrdDocSalesOrgList().isEmpty() && getOrdDocSalesOrgList().contains(sapSalesOrg) && null != sapContact){
			vlogDebug("Inside AdrFileMessageDroplet class,Setting DOC_SUBMIT service parameter");
		request.serviceParameter(OPARAM_DOC_SUBMIT, request, response);
		}
		*/
	}

	public Profile getProfile() {
		return profile;
	}

	public List<String> getAllowedCountryList() {
		return allowedCountryList;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public void setAllowedCountryList(List<String> allowedCountryList) {
		this.allowedCountryList = allowedCountryList;
	}

	public List<String> getOrdDocSalesOrgList() {
		return ordDocSalesOrgList;
	}

	public void setOrdDocSalesOrgList(List<String> ordDocSalesOrgList) {
		this.ordDocSalesOrgList = ordDocSalesOrgList;
	}
	
}
