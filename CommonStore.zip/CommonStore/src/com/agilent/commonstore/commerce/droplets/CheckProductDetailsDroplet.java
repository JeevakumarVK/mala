/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.commerce.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.transaction.TransactionManager;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.order.AgilentCommerceItem;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.helper.OrderManagerHelper;

import atg.commerce.CommerceException;
import atg.commerce.order.CommerceItem;
import atg.commerce.order.CommerceItemManager;
import atg.commerce.order.OrderManager;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;

/**
 * This class is used to check product details.
 */
@SuppressWarnings("unchecked")
public class CheckProductDetailsDroplet extends DynamoServlet {
    private static final String EMPTY_STRING = "";
    private static final String PROFILE = "profile";
    private static final String ORDER = "order";
    private static final String PRODUCT_LINE = "productLine";
    private static final String CATALOG_ID = "catalogId";

    private AgilentCatalogTools mCatalogTools;
    private CommerceItemManager mCommerceItemManager;
    private OrderManager mOrderManager;
    private TransactionManager mTransactionManager;
    private List<String> mStockProductLines;
    private OrderManagerHelper mOrderManagerHelper;
    public OrderManagerHelper getOrderManagerHelper() {
 		return mOrderManagerHelper;
 	}

 	public void setOrderManagerHelper(OrderManagerHelper mOrderManagerHelper) {
 		this.mOrderManagerHelper = mOrderManagerHelper;
 	}

    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException {

        Profile profile = (Profile) pReq.getObjectParameter(PROFILE);
        AgilentOrder order = (AgilentOrder) pReq.getObjectParameter(ORDER);
        RepositoryItem pSku = null;
        List<CommerceItem> commerceItems = new ArrayList<CommerceItem>();
        Set<String> remCommerceItems = new HashSet<String>();
        Set<String> remEntitledItems = new HashSet<String>();
        Set<String> remOutOfStockItems = new HashSet<String>();
        Set<String> remPartialStockItems = new HashSet<String>();

        synchronized (order) {
            commerceItems = order.getCommerceItems();
            Iterator<CommerceItem> commItem = commerceItems.iterator();
            while (commItem.hasNext()) {
                long quantity = 0;
                long stockQuantity = 0;
                boolean entitledBlocked = false;
                boolean outOfStockBlocked = false;
                boolean partialStockBlocked = false;
                String catalogId = EMPTY_STRING;
                CommerceItem commerceItem = (CommerceItem) commItem.next();
                try {
                    pSku = getCatalogTools().findSKU(commerceItem.getCatalogRefId());
                } catch (RepositoryException repoExp) {
                    vlogError(repoExp, "RepositoryException occurred while reading sku value.");
                }
                if (null != profile && null != pSku) {
                    catalogId = (String) pSku.getPropertyValue(CATALOG_ID);
                    entitledBlocked = getCatalogTools().isProductBelongToEntitlement(profile, pSku);
                    if (commerceItem instanceof AgilentCommerceItem) {
                        AgilentCommerceItem comItem = (AgilentCommerceItem) commerceItem;
                        quantity = comItem.getQuantity();
                        String productLine = (String) pSku.getPropertyValue(PRODUCT_LINE);
                        if (null != comItem.getStockQuantity()) {
                            stockQuantity = comItem.getStockQuantity().longValue();
                        }
                        if ((stockQuantity <= 0) && (getStockProductLines().contains(productLine))) {
                            outOfStockBlocked = true;
                        } else if ((stockQuantity > 0) && (quantity > stockQuantity) && (getStockProductLines().contains(productLine))) {
                            partialStockBlocked = true;
                        }
                    }
                }
                if (entitledBlocked) {
                    remCommerceItems.add(commerceItem.getId());
                    remEntitledItems.add(catalogId);
                }
                if (outOfStockBlocked) {
                    remCommerceItems.add(commerceItem.getId());
                    remOutOfStockItems.add(catalogId);
                }
                if (partialStockBlocked) {
                    remCommerceItems.add(commerceItem.getId());
                    String removedItem = catalogId + " qty " + quantity;
                    remPartialStockItems.add(removedItem);
                }
            }

            if (!remCommerceItems.isEmpty()) {
                for (String remItem : remCommerceItems) {
                    try {
                        getCommerceItemManager().removeItemFromOrder(order, remItem);
                    } catch (CommerceException e) {
                        vlogDebug("CommerceException", e);
                    }
                }
            }

            try {
                order.updateVersion();
                getOrderManager().updateOrder(order);
            } catch (CommerceException comExp) {
                vlogDebug(comExp, "CommerceException occurred while updating order {0}", order.getId());
            }
        }

        boolean serviceOutput = false;
        boolean updateCartCookie = false;

        if (!remEntitledItems.isEmpty()) {
            updateCartCookie = true;
            pReq.setParameter("entitledItems", Boolean.TRUE);
            serviceOutput = true;
        }
        if (!remOutOfStockItems.isEmpty()) {
            updateCartCookie = true;
            pReq.setParameter("remOutOfStockItems", remOutOfStockItems);
            serviceOutput = true;
        }
        if (!remPartialStockItems.isEmpty()) {
            updateCartCookie = true;
            pReq.setParameter("remPartialStockItems", remPartialStockItems);
            serviceOutput = true;
        }

        if (updateCartCookie) {
            Cookie[] cookies = pReq.getCookies();
            String cartValue = String.valueOf(0);
            if (order != null && !order.isTransient()) {
                cartValue = String.valueOf(getOrderManagerHelper().checkCartItemCount(order));
            }
            if (null != cookies && cookies.length > 0) {
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("GenomicsCartCount")) {
                        cookie.setValue(cartValue);                    
                        pRes.addCookie(cookie);
                        vlogDebug("Successfully updated GenomicsCartCount cookie.");
                    }
                    if (cookie.getName().equals("CartValue")) {
                        cookie.setValue(cartValue);                    
                        pRes.addCookie(cookie);
                        vlogDebug("Successfully updated CartValue cookie.");
                    }
                }
                pReq.setParameter("updatedCartCount", cartValue);
                serviceOutput = true;
            }
        }

        // Setting Service OUTPUT
        if (serviceOutput) {
            pReq.serviceParameter(OUTPUT, pReq, pRes);
            vlogDebug("Service OUTPUT is set for CheckProductDetailsDroplet.");
        }
    }

    /**
     * Gets the value of property catalogTools
     *
     * @return the value of property catalogTools
     */
    public AgilentCatalogTools getCatalogTools() {
        return mCatalogTools;
    }
    /**
     * Sets the value of property catalogTools with value pCatalogTools
     *
     * @param pCatalogTools
     *            for setting property catalogTools
     */
    public void setCatalogTools(AgilentCatalogTools pCatalogTools) {
        mCatalogTools = pCatalogTools;
    }

    /**
     * Gets the value of property commerceItemManager
     *
     * @return the value of property commerceItemManager
     */
    public CommerceItemManager getCommerceItemManager() {
        return mCommerceItemManager;
    }
    /**
     * Sets the value of property commerceItemManager with value pCommerceItemManager
     *
     * @param pCommerceItemManager
     *            for setting property commerceItemManager
     */
    public void setCommerceItemManager(CommerceItemManager pCommerceItemManager) {
        mCommerceItemManager = pCommerceItemManager;
    }

    /**
     * Gets the value of property orderManager
     *
     * @return the value of property orderManager
     */
    public OrderManager getOrderManager() {
        return mOrderManager;
    }
    /**
     * Sets the value of property orderManager with value pOrderManager
     *
     * @param pOrderManager
     *            for setting property orderManager
     */
    public void setOrderManager(OrderManager pOrderManager) {
        mOrderManager = pOrderManager;
    }

    /**
     * Gets the value of property transactionManager
     *
     * @return the value of property transactionManager
     */
    public TransactionManager getTransactionManager() {
        return mTransactionManager;
    }
    /**
     * Sets the value of property transactionManager with value pTransactionManager
     *
     * @param pTransactionManager
     *            for setting property transactionManager
     */
    public void setTransactionManager(TransactionManager pTransactionManager) {
        mTransactionManager = pTransactionManager;
    }

    /**
     * Gets the value of property stockProductLines
     *
     * @return the value of property stockProductLines
     */
    public List<String> getStockProductLines() {
        return mStockProductLines;
    }
    /**
     * Sets the value of property stockProductLines with value pStockProductLines
     *
     * @param pStockProductLines
     *            for setting property stockProductLines
     */
    public void setStockProductLines(List<String> pStockProductLines) {
        mStockProductLines = pStockProductLines;
    }
}
