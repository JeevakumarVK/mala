/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.commerce.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;

import com.agilent.base.platform.CountryUtils;
import com.agilent.base.profile.Constants;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;

/**
 * This class is used to create cookie for readyto use list.
 */
@SuppressWarnings("unchecked")
public class ReadyToUseListDroplet extends DynamoServlet {
    private CountryUtils mCountryUtils;
    
    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException {
        String readyToUseListId = pReq.getParameter(Constants.RTU_LIST_ID);
        Cookie cookie = ServletUtil.createCookie(Constants.RTU_COOKIE, readyToUseListId);
        String domain = pReq.getServerName();
        if(StringUtils.isNotBlank(domain) && domain.contains(getCountryUtils().getChinaProfileCookieDomain())){
        	vlogDebug("Domain name from Request:::{0}",domain);
			cookie.setDomain(getCountryUtils().getChinaProfileCookieDomain());
        }else{
			vlogDebug("Domain name from Request:::{0}",domain);
        	cookie.setDomain(getCountryUtils().getCountryCookieDomainName());
        }
        cookie.setMaxAge(60 * 10);
        cookie.setPath(Constants.FORWARD_SLASH);
        pRes.addCookie(cookie);
        pReq.serviceParameter(OUTPUT, pReq, pRes);
        vlogDebug("Service OUTPUT is set for ReadyToUseListDroplet.");
        }
    
/**
 * Gets the value of countryUtils
 *
 * @return returns the property countryUtils
 */
public CountryUtils getCountryUtils() {
    return mCountryUtils;
}

/**
 * Sets the value of property countryUtils with value pCountryUtils
 *
 * @param pCountryUtils
 *            the countryUtils to set
 */
public void setCountryUtils(CountryUtils pCountryUtils) {
    mCountryUtils = pCountryUtils;
}

   
}
