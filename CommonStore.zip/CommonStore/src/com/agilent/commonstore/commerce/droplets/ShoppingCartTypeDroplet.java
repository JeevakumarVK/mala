/**
 * 
 */

package com.agilent.commonstore.commerce.droplets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;

import atg.commerce.order.CommerceItem;
import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import com.agilent.base.commerce.order.AgilentOrder;

/**
 * @author sujata.da
 * 
 */
public class ShoppingCartTypeDroplet extends DynamoServlet {

    private List<String> mGenProductLine;

    public void service( DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException {
        ParameterName currentOrder = ParameterName.getParameterName("order");
        AgilentOrder order = (AgilentOrder) pReq.getObjectParameter(currentOrder);
        boolean isGenCart = true;
        List<CommerceItem> commerceItems = new ArrayList<CommerceItem>();
        commerceItems = order.getCommerceItems();
        for ( CommerceItem commerceItem : commerceItems) {
            String productLine = (String) ((RepositoryItem) commerceItem.getAuxiliaryData().getCatalogRef()).getPropertyValue("productLine");

            if (!StringUtils.isEmpty(productLine) && !getGenProductLine().contains(productLine)) {
                isGenCart = false;
                break;
            }
        }
        if (isGenCart) {
            pReq.setParameter("cartType", "GenomicsCart");
        } else {
            pReq.setParameter("cartType", "LscaCart");
        }
        pReq.serviceParameter("output", pReq, pRes);
    }

    public List<String> getGenProductLine() {
        return mGenProductLine;
    }

    public void setGenProductLine( List<String> pGenProductLine) {
        mGenProductLine = pGenProductLine;
    }

}
