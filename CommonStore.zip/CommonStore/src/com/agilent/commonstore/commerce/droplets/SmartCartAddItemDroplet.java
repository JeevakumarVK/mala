/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.commerce.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This class is used to form the input pattern for adding items to cart from the query string
 */
@SuppressWarnings("unchecked")
public class SmartCartAddItemDroplet extends DynamoServlet {
    private static final String AND_STRING = "&";
    private static final String EQUAL_STRING = "=";
    private static final int NUMBER_TWO = 2;
    private static final String UTF_8 = "UTF-8";
    private static final String SMART_ALERT_FLAG = "sa";
    private static final String PART_NO_KEY = "p";
    private static final String QTY_KEY = "q";
    private static final String REG_NUMERIC = "^[0-9]+$";
    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException {
		List<String> partNumberList = new ArrayList<String>();
		String queryString = pReq.getQueryString();
		int qCount = 1;
		String qKey = QTY_KEY + qCount;
		Map<String, String> partMapInitial = new HashMap<String, String>();
		Map<String, String> quantityMapInitial = new HashMap<String, String>();
		Map<String, Integer> quantityMapFinal = new HashMap<String, Integer>();
		if(StringUtils.isNotBlank(queryString)){
		for (String param : queryString.split(AND_STRING)) {
			String[] keyValue = param.split(EQUAL_STRING, NUMBER_TWO);
			try {
				String urlKey = URLDecoder.decode(keyValue[0], UTF_8);
				String urlValue = keyValue.length > 1 ? URLDecoder.decode(keyValue[1], UTF_8) : "";
				if (!urlKey.equalsIgnoreCase(SMART_ALERT_FLAG)) {
					if (urlKey.startsWith(PART_NO_KEY)) {
						if(!partMapInitial.containsKey(urlKey)){
						partMapInitial.put(urlKey, urlValue);
						}
						else{
							vlogInfo("Part Number Key {0} Repeated ,hence not added the part number ",urlKey);	
						}
					} else if (urlKey.startsWith(QTY_KEY)) {
						if(!quantityMapInitial.containsKey(urlKey)){
						quantityMapInitial.put(urlKey, urlValue);
						}
						else{
							vlogInfo("Quantity Key {0} Repeated ,hence not added the quantity",urlKey);
						}
					}
				}

			} catch (UnsupportedEncodingException e) {
				vlogError("UnsupportedEncodingException in SmartCartAddItemDroplet", e);
			}
		}
		for (Map.Entry<String, String> entry1 : partMapInitial.entrySet()) {
			String partNo = entry1.getValue();
			String partKey = entry1.getKey();
 			String[] qCountKey = partKey.split(PART_NO_KEY,0);
		    if(null != qCountKey){
		    	qKey = QTY_KEY + Integer.parseInt(qCountKey[1]);
		    }
			if((null != partNumberList && !partNumberList.contains(partNo)) || null == partNumberList){
			String quantity = quantityMapInitial.get(qKey);
		
			if (null != quantity && quantity.matches(REG_NUMERIC)) {				
				quantityMapFinal.put(partNo, Integer.parseInt(quantity));			
				partNumberList.add(partNo);
			}
			else{
				
				vlogInfo("Quantity not found for the part Number {0} or the non-numeric number for quantity hence no quantity added ",qKey);
			}
			
			}else{
				vlogInfo("Part Number {0} Repeated ,hence not added the part number key {1} ", partNo,entry1.getKey());	
			}

		}
		}
		if (null != partNumberList) {
			// declaration and initialize String Array
			String partNumbers[] = new String[partNumberList.size()];
			// Convert ArrayList to object array
			Object[] partNumberArray = partNumberList.toArray();
			// Iterating and converting to String
			int count = 0;
			for (Object partNo : partNumberArray) {
				partNumbers[count++] = (String) partNo;
			}

			pReq.setParameter("partNumberList", partNumbers);
		}
		pReq.setParameter("quantityMap", quantityMapFinal);
		pReq.setParameter("smartAlert", "1");
		pReq.serviceParameter(OUTPUT, pReq, pRes);
	}

}
