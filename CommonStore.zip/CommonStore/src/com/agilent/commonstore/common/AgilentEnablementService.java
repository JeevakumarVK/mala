/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.common;

import java.io.IOException;

import javax.servlet.ServletException;

import com.agilent.base.commerce.services.EnablementServiceManager;
import com.agilent.base.common.Constants;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.SessionBean;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;

/**
 * This service class is used for processing enablement and auto registration flow.
 *
 * @author Biseswar Choudhury
 * @project TBT - Ready To Use Account and Cart
 */
public class AgilentEnablementService extends DynamoServlet implements Constants {

    private EnablementServiceManager mEnablementManager;

    /*
     * (non-Javadoc)
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest, atg.servlet.DynamoHttpServletResponse)
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        vlogDebug("Method service - start");
        AgilentProfile profile = null;
        SessionBean sessionBean = null;
        String redirectUrl = getEnablementManager().getCartPageURL() + ENBL_FLOW_ERROR_3;
        // Read current profile
        if (null != ServletUtil.getCurrentUserProfile()) {
            profile = (AgilentProfile) ServletUtil.getCurrentUserProfile();
        }
        if (null != profile && null != profile.getSessionBean()) {
            sessionBean = profile.getSessionBean();
            // Set checking and enabling current user flag to true (default value)
            getEnablementManager().setCheckAndEnableUser(true);
            // Process e-Enablement flow for current request.
            //Set Source to RTU for Auto registration
            getEnablementManager().processEnablement(pRequest, pResponse, profile, sessionBean);            
            redirectUrl = sessionBean.getEnablementDetails().getRedirectUrl();
        }
        vlogDebug("Method service - end");
        pResponse.sendRedirect(redirectUrl);
    }

    /**
     * Gets the value of property enablementManager
     *
     * @return the value of property enablementManager
     */
    public EnablementServiceManager getEnablementManager() {
        return mEnablementManager;
    }
    /**
     * Sets the value of property enablementManager with value pEnablementManager
     *
     * @param pEnablementManager
     *            for setting property enablementManager
     */
    public void setEnablementManager(EnablementServiceManager pEnablementManager) {
        mEnablementManager = pEnablementManager;
    }
}
