/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.common;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;

import com.agilent.base.common.Constants;
import com.agilent.base.common.services.ViewCentralManager;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.rest.okta.IntegrateOktaConnectionManager;
import com.agilent.base.rest.okta.vo.OktaUser;
import com.agilent.base.userprofiling.CountrySalesOrgProfilePropertySetter;

import com.agilent.profile.okta.rest.helper.AgilentUserOKTAHelper;
import com.agilent.profile.okta.services.rest.helper.IntegrationServiceConstants;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.lms.services.AgilentLmsManager;
import com.agilent.base.rest.lms.model.attendee.Attendee;
import com.agilent.migration.profile.UserMigrationDataBean;
import com.agilent.migration.profile.UserProfileMigrationHelper;

/**
 * This service class is used for authorizing token and then creating user in ATG
 *
 * 
 * 
 */
public class AgilentOktaUserRegisterService extends DynamoServlet implements Constants {

    private IntegrateOktaConnectionManager mOktaHttpConnectionManager;
    private AgilentProfileTools mProfileTools;
    private static final String DEFAULT_lOCALE_EN_US = "en_US";
    private static final String DEFAULT_SALES_ORG = "04US";
    private static final String DEFAULT_COUNTRY = "US";

    public static final String CUSTOMER_NAME1 = "customerName1";
    public static final String COMPANY_TAX_CODE1 = "companyTaxCode1";
    public static final String ADDRESS1 = "address1";
    public static final String BANK_NAME1 = "bankName1";
    public static final String BANK_ACCOUNT1 = "bankAccount1";
    public static final String CUSTOMER_NAME2 = "customerName2";
    public static final String CITY2 = "city2";
    public static final String SHIPPING_ADDRESS2 = "shippingAdrress2";
    public static final String POST_CODE2 = "postCode2";
    public static final String CONTACTOR_NAME2 = "contactorName2";
    public static final String CONTACTOR_PHNUM2 = "contactorPhNum2";

    public static final String B2BUSER = "b2bUser";
    public static final String DIRECTOR_ACCOUNT = "directorAccount";
    public static final String GROUP_ID = "groupId";
    public static final String SHOW_DUTY_FREE_PRICE = "showDutyFreePrice";
    public static final String ADD_FILE_UPLOADED = "isAddFileUploaded";
    public static final String PAYER_INVOICE_EMAIL = "payerInvoiceEmail";
    public static final String ADVANCE_SHIPDISABLE = "advShpDisable";
    private static final String CARTPAGE_REG_COOKIE_NAME = "cartPageRegCookie";
    private CountrySalesOrgProfilePropertySetter mCountrySalesOrgProfilePropertySetter;
    private String mRedirectUrl;
    private AgilentUserOKTAHelper mAgilentOKTAUserHelper;
    private List<String> mEnabledCountryList;
    private String mErrorUrl;
    private AgilentConfigurationSecond configuration;
    private AgilentLmsManager agilentLMSManager;
    private String lmsLoginErrorReturnURL;
    private Boolean isLMSProfile;
    private UserProfileMigrationHelper userProfileMigrationHelper;
    private ViewCentralManager viewCentralManager;
    private String lmsLoginSuccessUrl;

    /*
     * (non-Javadoc)
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest, atg.servlet.DynamoHttpServletResponse)
     */
  

    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        vlogDebug("Method service - start");
        String responseString;
        OktaUser responseOktaUser = null;
        OktaUser userDetails = null;
        Gson gson = new Gson();
        String login = null;
        String token = pRequest.getParameter(IntegrationServiceConstants.TOKEN);
        responseString = getOktaHttpConnectionManager().authorizeToken(token);
        String domain = pRequest.getServerName();
        String redirectionUrl = getRedirectUrl();
        if (StringUtils.isNotBlank(responseString)) {
            responseOktaUser = gson.fromJson(responseString, OktaUser.class);
            login = responseOktaUser.get_embedded().getUser().getProfile().getLogin();
            userDetails = getOktaHttpConnectionManager().findUserDetailsUsingEmail(login);
        } else {
            redirectionUrl = getErrorUrl();
        }

        if (null != userDetails) {
            try {
                MutableRepositoryItem userItem = null;
                userItem = getProfileTools().getProfileRepository().createItem(getProfileTools().getDefaultProfileType());
                boolean eCommerceEnabled = (Boolean) getAgilentOKTAUserHelper().computeEcommerceEnabledCountry(userDetails.getProfile().getUSR_UDF_SHIPPINGCOUNTRY());
                createUserInRepo(userItem, userDetails,eCommerceEnabled);
                String userLocale = userDetails.getProfile().getLocale();
                String fileUploadId = userDetails.getProfile().getFileUploadId();
                  Profile lProfile = new Profile();
                RepositoryItem profile = getProfileTools().getProfileItem(userItem.getRepositoryId());
                lProfile.setDataSource(profile);
                lProfile.setProfileTools(getProfileTools());
                lProfile.getProfileTools();
                getAgilentOKTAUserHelper().postUserRegistration(lProfile, eCommerceEnabled, userLocale, fileUploadId);
                //Profile going to create in LMS If user comes in LMS page
                String lmsIdentifer = userDetails.getProfile().getLmsIdentifier();
                String lmsBuyCreditIndicator =userDetails.getProfile().getLmsBuyCreditIdentifier();
                String lmsAppIndicator = null;
                Boolean isLMSProfileCreated = false;
                if (getConfiguration().getEnableLMS() && ((StringUtils.isNotBlank(lmsIdentifer) && lmsIdentifer.contains(getConfiguration().getLmsATGLandingCookieSSO()))
                        || (StringUtils.isNotBlank(lmsBuyCreditIndicator) && lmsBuyCreditIndicator.contains(getConfiguration().getLmsATGLandingCookie())))) {
                    vlogInfo("----- AgilentOktaUserRegisterService  entering into LMS Flow ------");
                    Cookie LMSApplication = new Cookie(getConfiguration().getLmsApplicationCookie(), lmsIdentifer);
                    LMSApplication.setPath("/");
                    if(StringUtils.isNotBlank(domain) && domain.contains(getConfiguration().getChinaProfileCookieDomain())){
                    	LMSApplication.setDomain(getConfiguration().getChinaProfileCookieDomain());
                    }else{
                    	LMSApplication.setDomain(".agilent.com");
                    }
                   // LMSApplication.setDomain(".agilent.com");
                    pResponse.addCookie(LMSApplication);
                    Attendee lAttendee = null;
                    UserMigrationDataBean userBean = null;
                    String email = null;
                    if (getConfiguration().getEnableLMS()) {
                        lAttendee = getAgilentLMSManager().createAttendeeData(lProfile);
                    }
                    isLMSProfileCreated = getViewCentralManager().registerLMSUserProfile(lProfile, lAttendee, pRequest);
                    // isLMSProfileCreated = profileCreationInvocationToLMS(lAttendee, lProfile);
                    vlogInfo("----- AgilentOktaUserRegisterService ::: isLMSProfileCreated---->{0}", isLMSProfileCreated);
                    if (isLMSProfileCreated != null && !isLMSProfileCreated) {
                        isLMSProfile = true;
                        if (null != lProfile) {
                            userBean = new UserMigrationDataBean();
                            email = (String) lProfile.getPropertyValue(IntegrationServiceConstants.USER_EMAIL_ID);
                            getUserProfileMigrationHelper().removeATGProfile(userBean, lProfile);
                            if (userBean.isProfileDeletionState()) {
                                vlogDebug("User deleted  in ATG atg id  {0},Email {1} ", userItem.getRepositoryId(), email);
                            } else {
                                vlogDebug("User not deleted  in ATG ");
                            }
                        }
                        redirectionUrl = getLmsLoginErrorReturnURL();
                    } else {
                        lmsAppIndicator = IntegrationServiceConstants.PROVISON_APP_LMS;
                        vlogInfo("User successfully created in OKTA ,ATG and LMS");
                        redirectionUrl = getLmsLoginSuccessUrl();
                        if (getConfiguration().getEnableLMS()) {
                            setLmsAddressInfo(lProfile);
                        }
                    }
                } else if (StringUtils.isNotBlank(lmsBuyCreditIndicator) && lmsBuyCreditIndicator.contains(IntegrationServiceConstants.CART_PAGE)) {
                    Cookie cartPageRegCookie = new Cookie(CARTPAGE_REG_COOKIE_NAME, lmsBuyCreditIndicator);
                    cartPageRegCookie.setPath("/");
                    if(StringUtils.isNotBlank(domain) && domain.contains(getConfiguration().getChinaProfileCookieDomain())){
                    	cartPageRegCookie.setDomain(getConfiguration().getChinaProfileCookieDomain());
                    }else{
                    	cartPageRegCookie.setDomain(".agilent.com");
                    }
                    //cartPageRegCookie.setDomain(".agilent.com");
                    pResponse.addCookie(cartPageRegCookie);
                }
                getOktaHttpConnectionManager().updateDataInOktaPostATGUserCreate(userDetails.getProfile().getEmail(), userDetails.getProfile().getPROVISION_APP(),
                        userItem.getRepositoryId(), lmsAppIndicator);
            } catch (RepositoryException e) {
                vlogError(e, "Exception occured at ATG User Creation :: {0}", e.getMessage());
                redirectionUrl = getErrorUrl();
            }

        } else {
            redirectionUrl = getErrorUrl();
        }
        vlogDebug("Method service - end");
        pResponse.sendRedirect(redirectionUrl);
    }
    
    /**
     * This method populates the lmsAddressInfo property if it is empty, during login/registration. 
     * Value is copied from default shipping address 
     */
    private void setLmsAddressInfo(Profile pProfile) {
        AgilentPropertyManager propManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        RepositoryItem shippingAddrItem = (RepositoryItem) pProfile.getPropertyValue("shippingAddress");
        if (null == pProfile.getPropertyValue(propManager.getLmsAddressInfoPropertyName())) {
        	pProfile.setPropertyValue(propManager.getLmsAddressInfoPropertyName(), shippingAddrItem);
            vlogInfo("set LMS address post registration/LogIn for profile :" + pProfile.getRepositoryId());
        }
    }
    /**
     * This method is used for creating user in ATG
     * 
     * @param userItem
     * @param registerInput
     * @throws IOException
     * @throws RepositoryException
     */
    public void createUserInRepo(MutableRepositoryItem userItem,OktaUser userDetails,boolean eCommerceEnabled) throws IOException, RepositoryException {

        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        String encryptedNewPassword = null;
        if (null != userDetails.getCredentials()) {
            encryptedNewPassword = getProfileTools().getPropertyManager().generatePassword(userDetails.getCredentials().getPassword().toString(), "pa$$word");
        }
        userItem.setPropertyValue(propMgr.getLoginPropertyName(), userDetails.getProfile().getEmail());
        userItem.setPropertyValue(propMgr.getAdLoginNamePropertyName(), userDetails.getProfile().getUSR_UDF_ADLOGINNAME());
        userItem.setPropertyValue(propMgr.getPasswordPropertyName(), encryptedNewPassword);
        userItem.setPropertyValue(propMgr.getFirstNamePropertyName(), userDetails.getProfile().getFirstName());
        userItem.setPropertyValue(propMgr.getLastNamePropertyName(), userDetails.getProfile().getLastName());
        userItem.setPropertyValue(propMgr.getEmailAddressPropertyName(), userDetails.getProfile().getEmail());
        userItem.setPropertyValue(propMgr.getTitle(), userDetails.getProfile().getTitle());
        userItem.setPropertyValue(propMgr.getDepartment(), userDetails.getProfile().getUSR_DEPT_NO());
        userItem.setPropertyValue(propMgr.getRegion(), userDetails.getProfile().getUSR_STATE());

        if (StringUtils.isEmpty(userDetails.getProfile().getUSR_COUNTRY())) {
            userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), DEFAULT_COUNTRY);
        } else {
            userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), userDetails.getProfile().getUSR_COUNTRY());
        }

        if (!StringUtils.isEmpty(userDetails.getProfile().getUSR_UDF_ECOMMERCESTATUS())) {
            userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), userDetails.getProfile().getUSR_UDF_ECOMMERCESTATUS().equals(IntegrationServiceConstants.VALUE_SAP)
                    ? IntegrationServiceConstants.VALUE_SAP : IntegrationServiceConstants.VALUE_WEB);
        } else {
            userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), IntegrationServiceConstants.VALUE_WEB);
        }

        if (!StringUtils.isEmpty(userDetails.getProfile().getUSR_UDF_MEMBERTYPE())) {
            userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), userDetails.getProfile().getUSR_UDF_MEMBERTYPE().equals(IntegrationServiceConstants.VALUE_DISTRIBUTOR)
                    ? IntegrationServiceConstants.VALUE_DISTRIBUTOR : IntegrationServiceConstants.VALUE_MEMBER);
        } else {
            userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), IntegrationServiceConstants.VALUE_MEMBER);
        }

        userItem.setPropertyValue(propMgr.getDefaultShippingMethodPropertyName(), IntegrationServiceConstants.STANDARDSHIPPING);
        userItem.setPropertyValue(propMgr.getDefaultPaymentMethodPropertyName(), IntegrationServiceConstants.PAY_METHOD_PO);
        userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
        userItem.setPropertyValue(propMgr.getLocalePropertyName(), DEFAULT_lOCALE_EN_US);
        if (null != userDetails.getProfile().isUSR_UDF_TESTACCOUNT()) {
            userItem.setPropertyValue(propMgr.getTestAccountPropertyName(), userDetails.getProfile().isUSR_UDF_TESTACCOUNT() ? true : false);
        }
        else{
            userItem.setPropertyValue(propMgr.getTestAccountPropertyName(),false);
        }
        
      
      
        if (null != userDetails.getProfile().isUSR_UDF_INCLUDEPUNCHOUTSHIP()) {
            userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(), userDetails.getProfile().isUSR_UDF_INCLUDEPUNCHOUTSHIP() ? true : false);
        }
        else{
            userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(),false);
        }
        if (null != userDetails.getProfile().isUSR_UDF_INCLUDEPUNCHOUTTAXES()) {
            userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(), userDetails.getProfile().isUSR_UDF_INCLUDEPUNCHOUTTAXES() ? true : false);
        }
        else{
            userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(),false);
        }
        if (null != userDetails.getProfile().isUSR_UDF_ADVANCESHIPPINGDISABLE()) {
            userItem.setPropertyValue(ADVANCE_SHIPDISABLE, userDetails.getProfile().isUSR_UDF_ADVANCESHIPPINGDISABLE() ? true : false);
        }
        else{
            userItem.setPropertyValue(ADVANCE_SHIPDISABLE,false);
        }
        // userItem.setPropertyValue(propMgr.getAccessLibrayOptInPropertyName(),idmUserInputBean.getAccesLibraryOptIn()
        // == 1 ? true : false);
        userItem.setPropertyValue(propMgr.getPartnerNamePropertyName(), userDetails.getProfile().getUSR_UDF_B2BPARTNER());
        userItem.setPropertyValue(propMgr.getPartnerIdentifierrPropertyName(), userDetails.getProfile().getUSR_UDF_B2BUNIQUEIDENTIFIER());
        userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), userDetails.getProfile().getUSR_UDF_PUNCHOUTMEMBER());
        userItem.setPropertyValue(propMgr.getShippAddTypeProppertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGADDRESSTYPE());
        userItem.setPropertyValue(propMgr.getDefaultSAPBillToAddressPropertyName(), userDetails.getProfile().getUSR_UDF_DEFAULTSAPBILLADDRESS());
        userItem.setPropertyValue(propMgr.getDefaultSAPShipToAddressPropertyName(), userDetails.getProfile().getUSR_UDF_DEFAULTSAPSHIPADDRESS());
        userItem.setPropertyValue(propMgr.getTaxExemptedNumPropertyName(), userDetails.getProfile().getTaxExempteNumber());
        userItem.setPropertyValue(propMgr.getTaxExemptCertPropertyName(), userDetails.getProfile().getTaxExemptCertificatePath());
        if (null != userDetails.getProfile().isUSR_UDF_TAXEXEMPTED()) {
            userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(), userDetails.getProfile().isUSR_UDF_TAXEXEMPTED() ? true : false);
        }
        else{
            userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(),false);
        }
        if (null != userDetails.getProfile().isUSR_UDF_ISB2BUSER()) {
            userItem.setPropertyValue(B2BUSER, userDetails.getProfile().isUSR_UDF_ISB2BUSER() ? true : false);
        }
        else{
            userItem.setPropertyValue(B2BUSER,false);
        }
        userItem.setPropertyValue(GROUP_ID, userDetails.getProfile().getUSR_UDF_B2BGROUPID());

        if (!StringUtils.isEmpty(userDetails.getProfile().getUSR_UDF_FEDEXUPSCOLLECTNUMBER())) {
            userItem.setPropertyValue(propMgr.getFedexUpsCollectNumber(), userDetails.getProfile().getUSR_UDF_FEDEXUPSCOLLECTNUMBER());
        }

        if (!StringUtils.isEmpty(userDetails.getProfile().getUSR_UDF_UPSCOLLECTNUMBER())) {
            userItem.setPropertyValue(propMgr.getUPSCollectNumber(), userDetails.getProfile().getUSR_UDF_UPSCOLLECTNUMBER());
        }

        userItem.setPropertyValue(IntegrationServiceConstants.USER_BILLING_ADDRESS, createBillContactInfo(userDetails));
        userItem.setPropertyValue(IntegrationServiceConstants.USER_SHIPPING_ADDRESS, createShipContactInfo(userDetails));
        if (eCommerceEnabled) {
            createSecondaryAddress(userItem);
        }

        String salesOrg = DEFAULT_SALES_ORG;
        if (this.getCountrySalesOrgProfilePropertySetter() != null && userDetails.getProfile().getUSR_UDF_BILLINGCOUNTRY() != null) {
            salesOrg = this.getCountrySalesOrgProfilePropertySetter().getSalesOrg(userDetails.getProfile().getUSR_UDF_BILLINGCOUNTRY());
            if (salesOrg == null) {
                salesOrg = DEFAULT_SALES_ORG;
                vlogDebug("Cannot retrieve SAP Sales Org for country :" + userDetails.getProfile().getUSR_UDF_BILLINGCOUNTRY());
            }

            userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
            if (salesOrg != null && "04MX".equals(salesOrg)) {

                userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), false);
            } else {
                userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), true);
            }
            
            userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGCOUNTRY());

        }

        // Invoice details insert

        userItem.setPropertyValue(CUSTOMER_NAME1, userDetails.getProfile().getUSR_UDF_INVOICECUSTOMERNAME());
        userItem.setPropertyValue(COMPANY_TAX_CODE1, userDetails.getProfile().getUSR_UDF_INVOICETAXCODE());
        userItem.setPropertyValue(ADDRESS1, userDetails.getProfile().getUSR_UDF_INVOICEADDRESS());
        userItem.setPropertyValue(BANK_NAME1, userDetails.getProfile().getUSR_UDF_INVOICEBANKNAME());
        userItem.setPropertyValue(BANK_ACCOUNT1, userDetails.getProfile().getUSR_UDF_INVOICEBANKACCOUNT());
        userItem.setPropertyValue(CUSTOMER_NAME2, userDetails.getProfile().getUSR_UDF_CUSTOMERNAME());
        userItem.setPropertyValue(CITY2, userDetails.getProfile().getUSR_UDF_INVOICECITY());
        userItem.setPropertyValue(SHIPPING_ADDRESS2, userDetails.getProfile().getUSR_UDF_INVOICESHIPADDRESS());
        userItem.setPropertyValue(POST_CODE2, userDetails.getProfile().getUSR_UDF_INVOICEPOSTCODE());
        userItem.setPropertyValue(CONTACTOR_NAME2, userDetails.getProfile().getUSR_UDF_INVOICECONTACTPERSON());
        userItem.setPropertyValue(CONTACTOR_PHNUM2, userDetails.getProfile().getUSR_UDF_INVOICEPHONENUMBER());

        getProfileTools().getProfileRepository().addItem(userItem);

    }

    /**
     * This method is used for creating the billing address in ATG
     * 
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createBillContactInfo(OktaUser userDetails) throws RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createBillContactInfo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(IntegrationServiceConstants.ITEM_CONTACT_INTO);
        if (userDetails != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), userDetails.getProfile().getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), userDetails.getProfile().getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), userDetails.getProfile().getUSR_UDF_COMPANYNAME());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGADDRESS1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGADDRESS2());
            item.setPropertyValue(propMgr.getCityPropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGCITY());
            item.setPropertyValue(propMgr.getStatePropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGSTATE());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGPOSTALCODE());
            item.setPropertyValue(propMgr.getCountryPropertyName(), userDetails.getProfile().getUSR_UDF_BILLINGCOUNTRY());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), userDetails.getProfile().getPrimaryPhone());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), userDetails.getProfile().getUSR_UDF_EXTENSION());
            if (isLoggingDebug()) {
                vlogDebug("BillContactInfo Items {0}", item);
            }
        }
        return item;
    }

    /**
     * This method is used for creating Shipping Address information in ATG
     * 
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createShipContactInfo(OktaUser userDetails) throws RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createShipContactInfo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(IntegrationServiceConstants.ITEM_CONTACT_INTO);
        if (userDetails != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), userDetails.getProfile().getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), userDetails.getProfile().getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), userDetails.getProfile().getUSR_UDF_COMPANYNAME());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGADDRESS1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGADDRESS2());
            item.setPropertyValue(propMgr.getCityPropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGCITY());
            item.setPropertyValue(propMgr.getStatePropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGSTATE());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGPOSTALCODE());
            item.setPropertyValue(propMgr.getCountryPropertyName(), userDetails.getProfile().getUSR_UDF_SHIPPINGCOUNTRY());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), userDetails.getProfile().getPrimaryPhone());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), userDetails.getProfile().getUSR_UDF_EXTENSION());
        }
        if (isLoggingDebug()) {
            vlogDebug("ShipContactInfo Items {0}", item);
        }
        return item;
    }

    
    
    
    /**
     * This method is used for creating secondary addresses for the user
     * 
     * @param userItem
     */
    private void createSecondaryAddress(MutableRepositoryItem userItem) {
        AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        Map secondaryAddresses = (Map) userItem.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
        RepositoryItem shippingAddress = (RepositoryItem) userItem.getPropertyValue(IntegrationServiceConstants.USER_SHIPPING_ADDRESS);
        // To make sure nickname will be unique always
        long number = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;
        String nickname = String.valueOf(number);
        Map<String, RepositoryItem> secondaryAdd = (Map<String, RepositoryItem>) userItem.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
        Set<String> key = secondaryAdd.keySet();
        Random rdn = new Random();
        while (key.contains(nickname)) {
            nickname = nickname + rdn.nextInt(100);
        }
        secondaryAddresses.put(nickname, shippingAddress);
    }
    
    

    /**
     * Gets the value of property mOktaHttpConnectionManager
     *
     * @return the value of property mOktaHttpConnectionManager
     */
    public IntegrateOktaConnectionManager getOktaHttpConnectionManager() {
        return mOktaHttpConnectionManager;
    }
    /**
     * Sets the value of property mOktaHttpConnectionManager with value mOktaHttpConnectionManager
     *
     * @param mOktaHttpConnectionManager
     *            for setting property mOktaHttpConnectionManager
     */
    public void setOktaHttpConnectionManager(IntegrateOktaConnectionManager mOktaHttpConnectionManager) {
        this.mOktaHttpConnectionManager = mOktaHttpConnectionManager;
    }


    /**
     * Gets the value of property mProfileTools
     *
     * @return the value of property mProfileTools
     */
    public AgilentProfileTools getProfileTools() {
        return mProfileTools;
    }


    /**
     * Sets the value of property mProfileTools with value mProfileTools
     *
     * @param mProfileTools
     *            for setting property mProfileTools
     */
    public void setProfileTools(AgilentProfileTools mProfileTools) {
        this.mProfileTools = mProfileTools;
    }


    /**
     * Gets the value of property mCountrySalesOrgProfilePropertySetter
     *
     * @return the value of property mCountrySalesOrgProfilePropertySetter
     */
    public CountrySalesOrgProfilePropertySetter getCountrySalesOrgProfilePropertySetter() {
        return mCountrySalesOrgProfilePropertySetter;
    }


    /**
     * Sets the value of property mCountrySalesOrgProfilePropertySetter with value mCountrySalesOrgProfilePropertySetter
     *
     * @param mCountrySalesOrgProfilePropertySetter
     *            for setting property mCountrySalesOrgProfilePropertySetter
     */
    public void setCountrySalesOrgProfilePropertySetter(CountrySalesOrgProfilePropertySetter mCountrySalesOrgProfilePropertySetter) {
        this.mCountrySalesOrgProfilePropertySetter = mCountrySalesOrgProfilePropertySetter;
    }


    /**
     * Gets the value of property mRedirectUrl
     *
     * @return the value of property mRedirectUrl
     */
    public String getRedirectUrl() {
        return mRedirectUrl;
    }


    /**
     * Sets the value of property mRedirectUrl with value mRedirectUrl
     *
     * @param mRedirectUrl
     *            for setting property mRedirectUrl
     */
    public void setRedirectUrl(String mRedirectUrl) {
        this.mRedirectUrl = mRedirectUrl;
    }


    /**
     * Gets the value of property mAgilentOKTAUserHelper
     *
     * @return the value of property mAgilentOKTAUserHelper
     */
    public AgilentUserOKTAHelper getAgilentOKTAUserHelper() {
        return mAgilentOKTAUserHelper;
    }


    /**
     * Sets the value of property mAgilentOKTAUserHelper with value mAgilentOKTAUserHelper
     *
     * @param mAgilentOKTAUserHelper
     *            for setting property mAgilentOKTAUserHelper
     */
    public void setAgilentOKTAUserHelper(AgilentUserOKTAHelper mAgilentOKTAUserHelper) {
        this.mAgilentOKTAUserHelper = mAgilentOKTAUserHelper;
    }


    /**
     * Gets the value of property mEnabledCountryList
     *
     * @return the value of property mEnabledCountryList
     */
    public List<String> getEnabledCountryList() {
        return mEnabledCountryList;
    }


    /**
     * Sets the value of property mEnabledCountryList with value mEnabledCountryList
     *
     * @param mEnabledCountryList
     *            for setting property mEnabledCountryList
     */
    public void setEnabledCountryList(List<String> mEnabledCountryList) {
        this.mEnabledCountryList = mEnabledCountryList;
    }

    /**
     * Gets the value of property mErrorUrl
     *
     * @return the value of property mErrorUrl
     */
    public String getErrorUrl() {
        return mErrorUrl;
    }

    /**
     * Sets the value of property mErrorUrl with value mErrorUrl
     *
     * @param mErrorUrl
     *            for setting property mErrorUrl
     */
    public void setErrorUrl(String mErrorUrl) {
        this.mErrorUrl = mErrorUrl;
    }

	/**
	 * @return the configuration
	 */
	public AgilentConfigurationSecond getConfiguration() {
		return configuration;
	}

	/**
	 * @param configuration the configuration to set
	 */
	public void setConfiguration(AgilentConfigurationSecond configuration) {
		this.configuration = configuration;
	}

	/**
	 * @return the agilentLMSManager
	 */
	public AgilentLmsManager getAgilentLMSManager() {
		return agilentLMSManager;
	}

	/**
	 * @param agilentLMSManager the agilentLMSManager to set
	 */
	public void setAgilentLMSManager(AgilentLmsManager agilentLMSManager) {
		this.agilentLMSManager = agilentLMSManager;
	}

	/**
	 * @return the lmsLoginErrorReturnURL
	 */
	public String getLmsLoginErrorReturnURL() {
		return lmsLoginErrorReturnURL;
	}

	/**
	 * @param lmsLoginErrorReturnURL the lmsLoginErrorReturnURL to set
	 */
	public void setLmsLoginErrorReturnURL(String lmsLoginErrorReturnURL) {
		this.lmsLoginErrorReturnURL = lmsLoginErrorReturnURL;
	}

	/**
	 * @return the isLMSProfile
	 */
	public Boolean getIsLMSProfile() {
		return isLMSProfile;
	}

	/**
	 * @param isLMSProfile the isLMSProfile to set
	 */
	public void setIsLMSProfile(Boolean isLMSProfile) {
		this.isLMSProfile = isLMSProfile;
	}

	/**
	 * @return the userProfileMigrationHelper
	 */
	public UserProfileMigrationHelper getUserProfileMigrationHelper() {
		return userProfileMigrationHelper;
	}

	/**
	 * @param userProfileMigrationHelper the userProfileMigrationHelper to set
	 */
	public void setUserProfileMigrationHelper(UserProfileMigrationHelper userProfileMigrationHelper) {
		this.userProfileMigrationHelper = userProfileMigrationHelper;
	}

	/**
	 * @return the viewCentralManager
	 */
	public ViewCentralManager getViewCentralManager() {
		return viewCentralManager;
	}

	/**
	 * @param viewCentralManager the viewCentralManager to set
	 */
	public void setViewCentralManager(ViewCentralManager viewCentralManager) {
		this.viewCentralManager = viewCentralManager;
	}

	/**
	 * @return the lmsLoginSuccessUrl
	 */
	public String getLmsLoginSuccessUrl() {
		return lmsLoginSuccessUrl;
	}

	/**
	 * @param lmsLoginSuccessUrl the lmsLoginSuccessUrl to set
	 */
	public void setLmsLoginSuccessUrl(String lmsLoginSuccessUrl) {
		this.lmsLoginSuccessUrl = lmsLoginSuccessUrl;
	}
   

 
}
