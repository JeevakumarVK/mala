/**
 * 
 */
package com.agilent.commonstore.common.droplets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.pps.PPSCheckoutHelper;
import com.agilent.base.common.pps.PPSCheckoutInfo;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;

import atg.commerce.order.OrderHolder;
import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * @author 618305
 *
 */
public class CreateOrderFromInput extends DynamoServlet implements Constants {
    

    private PPSCheckoutHelper ppsCheckoutHelper;
    private EncryptDecryptHelper mEncryptDecryptHelper;

    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        OrderHolder orderHolder = (OrderHolder) pRequest.getObjectParameter(ParameterName.getParameterName(ORDER_HOLDER));
        String postData = this.getPostedData(pRequest);
        vlogInfo("Post Body = {0}", postData);
        try {
        	postData = getEncryptDecryptHelper().javascriptAmicableDecrypt(postData);
        	vlogInfo("Post Body after decryption = {0}", postData);
		} catch (ApplicationException e) {
			 vlogError(e, "ApplicationException got while trying to Decrypt the input json body");
			 pRequest.serviceParameter(EMPTY, pRequest, pResponse);
			 return;
		}
        AgilentOrder webOrder = null;
        if (StringUtils.isNotBlank(postData)) {
            PPSCheckoutInfo checkoutInfo = getPpsCheckoutHelper().populateCheckoutInfo(postData);
            if (checkoutInfo != null) {
                webOrder = getPpsCheckoutHelper().loadOrCreateOrderFromJson(checkoutInfo);
                pRequest.setParameter(CHECKOUT_INFO, checkoutInfo);
            }
            if (webOrder == null) {
                vlogError("Some error occured While Creating or Loading Order");
                pRequest.serviceParameter(EMPTY, pRequest, pResponse);
            } else {
                if (orderHolder != null) {
                    synchronized (webOrder) {
                        vlogInfo("Setting as current Order= {0}", webOrder.getId());
                        orderHolder.setCurrent(webOrder);
                    }
                }
                vlogDebug("Saved Order Id = {0}", webOrder.getId());
                try {
                    String temp = getEncryptDecryptHelper().javascriptAmicableEncrypt(webOrder.getId());
                    vlogDebug("Saved Order Id after encryption= {0}", temp);
                    //temp = URLEncoder.encode(temp, Constants.UTF_8);
                    temp = getEncryptDecryptHelper().baseEncrypt(temp);
                    vlogDebug("Saved Order Id after encoding= {0}", temp);
                    pRequest.setParameter(ORDERID, temp);
                    pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
                } catch (ApplicationException e) {
                    vlogError(e, "ApplicationException got while trying to encrypt the order id");
                    pRequest.serviceParameter(EMPTY, pRequest, pResponse);
                    return;
                }
            }
        } else {
            pRequest.serviceParameter(EMPTY, pRequest, pResponse);
            vlogError("Required Data Missing for creating an Order");
        }
    }

    /**
     * This method will return the Post body in the request
     * 
     * @param request
     * @return
     * @throws IOException
     */
    public String getPostedData(DynamoHttpServletRequest request) throws IOException {
        vlogDebug("CreateOrderFromInput.getPostedData()");
        String lResponseData = null;
        String lInputLine = null;
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader lInputReader = new BufferedReader(new InputStreamReader(request.getInputStream()));

        while ((lInputLine = lInputReader.readLine()) != null) {
            stringBuilder.append(lInputLine);
        }

        lInputReader.close();
        lResponseData = stringBuilder.toString();
        vlogDebug("CreateOrderFromInput.getPostedData() returning " + lResponseData);
        return lResponseData;
    }
    

    /**
     * @return the ppsCheckoutHelper
     */
    public PPSCheckoutHelper getPpsCheckoutHelper() {
        return ppsCheckoutHelper;
    }

    /**
     * @param ppsCheckoutHelper
     *            the ppsCheckoutHelper to set
     */
    public void setPpsCheckoutHelper(PPSCheckoutHelper ppsCheckoutHelper) {
        this.ppsCheckoutHelper = ppsCheckoutHelper;
    }
    
 
    /**
     * Gets the value of encryptDecryptHelper
     *
     * @return returns the property encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }

    /**
     * Sets the value of property encryptDecryptHelper with value encryptDecryptHelper
     *
     * @param encryptDecryptHelper the encryptDecryptHelper to set
     */
    public void setEncryptDecryptHelper( EncryptDecryptHelper pEncryptDecryptHelper) {
        mEncryptDecryptHelper = pEncryptDecryptHelper;
    }

}
