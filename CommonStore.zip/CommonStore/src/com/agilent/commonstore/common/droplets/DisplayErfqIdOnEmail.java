/**
 * 
 */
package com.agilent.commonstore.common.droplets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;

import com.agilent.base.commerce.Constants;
import com.agilent.base.profile.AgilentProfileTools;

/**
 * @author sujata.da
 *
 */
public class DisplayErfqIdOnEmail extends DynamoServlet implements Constants {
	/* (non-Javadoc)
	 * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest, atg.servlet.DynamoHttpServletResponse)
	 */
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		String reqCountry=pRequest.getParameter(REQ_COUNTRY);
		vlogDebug("Inside DisplayErfqIdOnEmail,value of Parameter reqCountry:{0}", reqCountry);
		Profile profile = (Profile) pRequest.resolveName("/atg/userprofiling/Profile");
		 AgilentProfileTools profileTools=(AgilentProfileTools)profile.getProfileTools();
		 List<String> isDisplayErfqId=profileTools.getErfqIdEnabledCountryfrmSite();
		 if(null != isDisplayErfqId && !isDisplayErfqId.isEmpty()  && isDisplayErfqId.contains(reqCountry)){
			 vlogDebug("Country in rejected list");
			 vlogDebug("Inside DisplayErfqIdOnEmail,value of isDisplayErfqId:{0}", isDisplayErfqId.toString());
			 pRequest.serviceParameter(TRUE, pRequest, pResponse);
		 }else{
			 vlogDebug("Inside DisplayErfqIdOnEmail, isDisplayErfqId is either null, empty or country not in list");
			 pRequest.serviceParameter(FALSE, pRequest, pResponse);
		 }
		 
		
	}
	

}
