package com.agilent.commonstore.common.droplets;

import java.io.IOException;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.order.AgilentOrder;

import atg.commerce.order.HardgoodShippingGroup;
import atg.commerce.order.OrderHolder;
import atg.commerce.order.ShippingGroup;
import atg.core.util.ContactInfo;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class DisplayShipToAddressDroplet extends DynamoServlet {
	
	
	OrderHolder orderHolder;
	public OrderHolder getOrderHolder() {
		return orderHolder;
	}
	public void setOrderHolder(OrderHolder orderHolder) {
		this.orderHolder = orderHolder;
	}
	public void service(DynamoHttpServletRequest pReq,
			DynamoHttpServletResponse pRes) throws ServletException,
			IOException{
		AgilentOrder agilentOrder = (AgilentOrder) orderHolder.getCurrent();
		ShippingGroup sg = (ShippingGroup) agilentOrder.getShippingGroups().get(0);
		ContactInfo orderAddress = (ContactInfo) ((HardgoodShippingGroup) sg).getShippingAddress();
		pReq.setParameter("shippingToAddress", orderAddress);
		pReq.serviceLocalParameter(Constants.OUTPUT, pReq, pRes);

	}

}
