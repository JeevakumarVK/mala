package com.agilent.commonstore.common.droplets;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;
import atg.userprofiling.Profile;

import com.agilent.base.commerce.Constants;
import com.agilent.base.common.services.InvoiceRequestBean;
import com.agilent.base.common.services.SapManager;
import com.agilent.base.platform.sap.client.Z_ECOM_GET_INVOICE_STATUS.ZCHINAVATINVOICE;
import com.agilent.base.platform.sap.client.Z_ECOM_GET_INVOICE_STATUS.ZINVOICEINFO;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.SessionBean;
import com.agilent.i18n.service.InternationalizationService;
import com.google.gson.Gson;

/**
 * This class is used for providing invoice related information in JSON format.
 */
public class FetchInvoiceDetailJson extends DynamoServlet {

	private static final String DEFAULT_SORT_PARAM = "Dec_date";
	private SapManager sapManager;
	private String downloadInvoice;
	private String defaultDays;
	private EncryptDecryptHelper mEncryptDecryptHelper;
	
	SimpleDateFormat sapFormat = new SimpleDateFormat("yyyy-MM-dd");
	SimpleDateFormat invoiceChinaFormat = new SimpleDateFormat("yyyy-MMMM-dd");
	SimpleDateFormat invoiceFormat = new SimpleDateFormat("dd-MMMM-yyyy");

	SimpleDateFormat sercahChina = new SimpleDateFormat("yyyy/MM/dd");
	SimpleDateFormat searchNonChina = new SimpleDateFormat("dd/MM/yyyy");
	
	private InternationalizationService mInternationalizationService;
	
	public InternationalizationService getInternationalizationService() {
        return mInternationalizationService;
    }

    /**
     * Sets the value of property internationalizationService with value pInternationalizationService
     *
     * @param pInternationalizationService
     *            for setting property internationalizationService
     */
    public void setInternationalizationService(InternationalizationService pInternationalizationService) {
        mInternationalizationService = pInternationalizationService;
    }

	@Override
	public void service(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		vlogDebug("FetchInvoiceDetailJson method start");
		Profile pProfile = (Profile) pRequest.getObjectParameter("profile");
		SessionBean pSessionBean = (SessionBean) pRequest.getObjectParameter("sessionBean");
		String searchId = (String) pRequest.getObjectParameter("searchId");
		String startDate = (String) pRequest.getObjectParameter("startDate");
		String endDate = (String) pRequest.getObjectParameter("endDate");
		String searchAction = (String) pRequest.getObjectParameter("searchAction");
		String action = (String) pRequest.getObjectParameter("action");
		String userContry = (String) pProfile.getPropertyValue(Constants.USERCOUNTRY);
		Set<String> sapDocIdList=new HashSet<String>();
		vlogDebug("FetchInvoiceDetailJson method end");
		try {
			pResponse.setContentType("text/html");
			pResponse.setCharacterEncoding("UTF-8");
			InvoiceRequestBean invoiceRequestBean = new InvoiceRequestBean();
			if(action != null && "search".equalsIgnoreCase(action)) {
				invoiceRequestBean.setInvoiceNumber(searchId);
				invoiceRequestBean.setOrderFromDate(startDate);
				invoiceRequestBean.setOrderEndDate(endDate);
				invoiceRequestBean.setSearchAction(searchAction);
				invoiceRequestBean.setSearch(true);
				searchJSON(invoiceRequestBean, pProfile);
			}
			if (getSapManager().IsSAPAvailable() == false) {
				vlogError("SAP is down");
				pResponse.getWriter().write("SAP is down");
			} else {
				if(!invoiceRequestBean.isSearch()) {
		    		Calendar cal = Calendar.getInstance();
		    		cal.setTime(new Date());
		    		cal.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(getDefaultDays()));
		    		invoiceRequestBean.setOrderFromDate(sapFormat.format(cal.getTime()));
		        	invoiceRequestBean.setOrderEndDate(sapFormat.format(new Date()));
				}

				getSapManager().fetchInvoiceDetail(pSessionBean, pProfile, invoiceRequestBean);
				Map<String, Map<String, InvoiceDetailVO>> jsonMap;
				
				if (StringUtils.isNotBlank(userContry) && userContry.equals(Constants.COUNTRY_CODE_CHINA)) {
					jsonMap = new LinkedHashMap<String, Map<String, InvoiceDetailVO>>();
					List<ZCHINAVATINVOICE> ZINVOICEINFOChinaList = invoiceRequestBean.getItemZCHINAVATINVOICE();
					
					String sortBy = DEFAULT_SORT_PARAM;
                    Comparator<ZCHINAVATINVOICE> comparator = getComparatorChina(sortBy);
                    if (ZINVOICEINFOChinaList != null && !ZINVOICEINFOChinaList.isEmpty()) {
                        vlogInfo("unsorted list" + ZINVOICEINFOChinaList);
                        if (comparator != null) {
                            Collections.sort(ZINVOICEINFOChinaList, comparator);
                        }
                    } 
					
					for (ZCHINAVATINVOICE zchinavatinvoice : ZINVOICEINFOChinaList) {
						InvoiceDetailVO invoiceDetailVO = new InvoiceDetailVO();
						if(zchinavatinvoice.getORDERDATE() != null) {
							Date orderDate = sapFormat.parse(zchinavatinvoice.getORDERDATE());
							invoiceDetailVO.setOrderDate(sercahChina.format(orderDate));
						}
						if (StringUtils.isNotBlank(zchinavatinvoice.getSALESORDER())){
						String encryptedOrderIdForMyA = getEncryptDecryptHelper().baseEncrypt(zchinavatinvoice.getSALESORDER());
						invoiceDetailVO.setEncryptedOrderIdForMyA(encryptedOrderIdForMyA);
						}
						invoiceDetailVO.setPurcahseOrder(zchinavatinvoice.getPURCHASEORDER());
						invoiceDetailVO.setDelivery(zchinavatinvoice.getDELIVERYNUMBER());
						invoiceDetailVO.setBilling(zchinavatinvoice.getBILLINGNUMBER());
						invoiceDetailVO.setVatForwarder(zchinavatinvoice.getVATFORWARDER());
						
						invoiceDetailVO.setVatStatus(zchinavatinvoice.getVATSTATUS());
						if(zchinavatinvoice.getINVOICEDATE() != null) {
							try {
								Date invoiceIssueDate = sapFormat.parse(zchinavatinvoice.getINVOICEDATE());
								invoiceDetailVO.setInvoiceIssueDate((sercahChina.format(invoiceIssueDate)));
							}
							catch(ParseException pe){
								vlogError("error occurred while parsing the invoice issue date {0}", zchinavatinvoice.getINVOICEDATE());
							}
							
						}
						
						
						if(StringUtils.isNotBlank(zchinavatinvoice.getINVOICETYPE())) {
							String invoiceTypeConverted = "";
							invoiceDetailVO.setInvoiceTypeFromSAP(zchinavatinvoice.getINVOICETYPE());
							if(zchinavatinvoice.getINVOICETYPE().equalsIgnoreCase(Constants.INVOICETYPE2)) {
								invoiceTypeConverted = getInternationalizationService().getLocalizeMessage(Constants.SHIP_NORMALVAT, null);
								invoiceDetailVO.setVatTracking(zchinavatinvoice.getVATTRACKING());
							}
							else if(zchinavatinvoice.getINVOICETYPE().equalsIgnoreCase(Constants.INVOICETYPE51)) {
								invoiceTypeConverted = getInternationalizationService().getLocalizeMessage(Constants.SHIP_NORMALVATNEW, null);
								invoiceDetailVO.setVatTracking(getInternationalizationService().getLocalizeMessage(Constants.SHIP_VATETRACKING, null));
							}
							else if(zchinavatinvoice.getINVOICETYPE().equalsIgnoreCase(Constants.INVOICETYPE0)) {
								invoiceTypeConverted = getInternationalizationService().getLocalizeMessage(Constants.SHIP_SPECIALVAT, null);
								invoiceDetailVO.setVatTracking(zchinavatinvoice.getVATTRACKING());
							}
							else if(zchinavatinvoice.getINVOICETYPE().equalsIgnoreCase(Constants.INVOICETYPE52)) {
								invoiceTypeConverted = getInternationalizationService().getLocalizeMessage(Constants.SHIP_SPECIALVATNEW, null);
								invoiceDetailVO.setVatTracking(getInternationalizationService().getLocalizeMessage(Constants.SHIP_VATETRACKING, null));
							}
							invoiceDetailVO.setChinaInvoiceType(invoiceTypeConverted);
						}

						if(jsonMap.containsKey(zchinavatinvoice.getSALESORDER())) { 
							Map<String, InvoiceDetailVO> invoiceDetail = jsonMap.get(zchinavatinvoice.getSALESORDER());
							invoiceDetailVO.setOrderDate("");
							invoiceDetail.put(zchinavatinvoice.getVATINVOICE(), invoiceDetailVO);
						}
						else {
							Map<String, InvoiceDetailVO> invoiceDetail = new LinkedHashMap<String, InvoiceDetailVO>();
							String encryptedOrderId = getEncryptDecryptHelper().encrypt(zchinavatinvoice.getSALESORDER());
							// pass zinvoiceinfo.getSALESORDER() to encrypted form to get encryptedOrderId;
							invoiceDetailVO.setEncryptedOrderId(encryptedOrderId);
							invoiceDetail.put(zchinavatinvoice.getVATINVOICE(), invoiceDetailVO);
							jsonMap.put(zchinavatinvoice.getSALESORDER(), invoiceDetail);
						}
					}
				}
				else {
					jsonMap = new LinkedHashMap<String, Map<String, InvoiceDetailVO>>();
					List<ZINVOICEINFO> ZINVOICEINFOList = invoiceRequestBean.getItemZINVOICEINFO();
					
					String sortBy = DEFAULT_SORT_PARAM;
                    Comparator<ZINVOICEINFO> comparator = getComparator(sortBy);
                    if (ZINVOICEINFOList != null && !ZINVOICEINFOList.isEmpty()) {
                        vlogInfo("unsorted list" + ZINVOICEINFOList);
                        if (comparator != null) {
                            Collections.sort(ZINVOICEINFOList, comparator);
                        }
                    } 
					
					for (ZINVOICEINFO zinvoiceinfo : ZINVOICEINFOList) {
						InvoiceDetailVO invoiceDetailVO = new InvoiceDetailVO();
						if(zinvoiceinfo.getBALANCE() != null) {
							if (zinvoiceinfo.getBALANCE().compareTo(BigDecimal.ZERO) != 0) {
								invoiceDetailVO.setBalance(zinvoiceinfo.getBALANCE().toString());
							} 
							else {
								invoiceDetailVO.setBalance("-");
							}
						}
						if(zinvoiceinfo.getINVOICEAMOUNT() != null) {
							if (zinvoiceinfo.getINVOICEAMOUNT().compareTo(BigDecimal.ZERO) != 0) {
								invoiceDetailVO.setInvoiceAmount(zinvoiceinfo.getINVOICEAMOUNT().toString());
							} 
							else {
								invoiceDetailVO.setInvoiceAmount("-");
							}
						}
						invoiceDetailVO.setInvoiceType(zinvoiceinfo.getINVOICETYPE());
						invoiceDetailVO.setPurcahseOrder(zinvoiceinfo.getPURCHASEORDER());
						if(StringUtils.isNotBlank(zinvoiceinfo.getORDERDATE())) {
							Date orderDate = sapFormat.parse(zinvoiceinfo.getORDERDATE());
							if (StringUtils.isNotBlank(userContry) && userContry.equals(Constants.COUNTRY_CODE_KOREA)) {
								invoiceDetailVO.setOrderDate(sercahChina.format(orderDate));
							}else{
								invoiceDetailVO.setOrderDate(invoiceFormat.format(orderDate));
							}
							
						}
						if(StringUtils.isNotBlank(zinvoiceinfo.getDUEDATE())) {
							Date orderDueDate = sapFormat.parse(zinvoiceinfo.getDUEDATE());
							if (StringUtils.isNotBlank(userContry) && userContry.equals(Constants.COUNTRY_CODE_KOREA)) {
								invoiceDetailVO.setDueDate(sercahChina.format(orderDueDate));								
							}else{
								invoiceDetailVO.setDueDate(invoiceFormat.format(orderDueDate));
							}
						}
						invoiceDetailVO.setSatus(zinvoiceinfo.getSTATUS());
						if(StringUtils.isNotBlank(zinvoiceinfo.getSAPDOCID())) {
							logDebug("SAPDOCId is: "+zinvoiceinfo.getSAPDOCID());
							sapDocIdList.add(zinvoiceinfo.getSAPDOCID());
							invoiceDetailVO.setInvoiceURL(getDownloadInvoice() + zinvoiceinfo.getSAPDOCID() + "&source=myInvoicePage");
						}
	                   if (StringUtils.isNotBlank(zinvoiceinfo.getSALESDOCNUMBER())){
						String encryptedOrderIdForMyA = getEncryptDecryptHelper().baseEncrypt(zinvoiceinfo.getSALESDOCNUMBER());
						invoiceDetailVO.setEncryptedOrderIdForMyA(encryptedOrderIdForMyA);
						}
						if(jsonMap.containsKey(zinvoiceinfo.getSALESDOCNUMBER())) { 
							Map<String, InvoiceDetailVO> invoiceDetail = jsonMap.get(zinvoiceinfo.getSALESDOCNUMBER());
							invoiceDetailVO.setOrderDate("");
							invoiceDetail.put(zinvoiceinfo.getINVOICENUMBER(), invoiceDetailVO);
						}
						else {
							Map<String, InvoiceDetailVO> invoiceDetail = new LinkedHashMap<String, InvoiceDetailVO>();
							String encryptedOrderId = getEncryptDecryptHelper().encrypt(zinvoiceinfo.getSALESDOCNUMBER());
							// pass zinvoiceinfo.getSALESDOCNUMBER() to encrypted form to get encryptedOrderId;
							invoiceDetailVO.setEncryptedOrderId(encryptedOrderId);
							invoiceDetail.put(zinvoiceinfo.getINVOICENUMBER(), invoiceDetailVO);
							jsonMap.put(zinvoiceinfo.getSALESDOCNUMBER(), invoiceDetail);
						}
					}
				}
				String json = new Gson().toJson(jsonMap);
				vlogDebug("Json in String {0} ", json);
				pResponse.getWriter().write(json);
			}
				//set sapDocIdList in session bean
			logDebug("sapDocIdList is: "+sapDocIdList);
				logDebug("setting  sapDocIdList in FetchInvoiceDetailJson is: "+sapDocIdList);
				pSessionBean.setSapDocIdList(sapDocIdList);
			
		} catch (Exception e) {
			vlogError("repository exeption {0}", e);
		}
	}
	
	public void searchJSON(InvoiceRequestBean invoiceRequestBean, Profile pProfile) { 

        try {
           	String userContry = (String) pProfile.getPropertyValue(Constants.USERCOUNTRY);
            // case 1: Order number and date range both present
            if (!StringUtils.isBlank(invoiceRequestBean.getOrderEndDate()) 
            		&& !StringUtils.isBlank(invoiceRequestBean.getOrderFromDate())) {
             	if (StringUtils.isNotBlank(userContry) && (userContry.equals(Constants.COUNTRY_CODE_CHINA) || userContry.equals(Constants.COUNTRY_CODE_KOREA))) {
            		Date startParsedate = sercahChina.parse(invoiceRequestBean.getOrderFromDate());
            		Date endParsedate = sercahChina.parse(invoiceRequestBean.getOrderEndDate());
            		invoiceRequestBean.setOrderEndDate(sapFormat.format(endParsedate));
            		invoiceRequestBean.setOrderFromDate(sapFormat.format(startParsedate));
            	} 
            	else {
            		Date startParsedate = searchNonChina.parse(invoiceRequestBean.getOrderFromDate());
            		Date endParsedate = searchNonChina.parse(invoiceRequestBean.getOrderEndDate());
            		invoiceRequestBean.setOrderEndDate(sapFormat.format(endParsedate));
            		invoiceRequestBean.setOrderFromDate(sapFormat.format(startParsedate));
            	}
            }
            // Case 2 search Action : 30, 60, 90 
            else if (StringUtils.isNotBlank(invoiceRequestBean.getSearchAction())) {
    			Calendar cal = Calendar.getInstance();
    			cal.setTime(new Date());
    			cal.add(Calendar.DAY_OF_MONTH, -Integer.parseInt(invoiceRequestBean.getSearchAction()));
    			invoiceRequestBean.setOrderFromDate(sapFormat.format(cal.getTime()));
        		invoiceRequestBean.setOrderEndDate(sapFormat.format(new Date()));
            }
         }

        catch (ParseException pe) {
            vlogError("Exception occurred while parsing date" + pe);
        }
	}
	
	
   public Comparator<ZINVOICEINFO> getComparator(final String pSortBy) {
        String sortBy = "";
        if (pSortBy.equalsIgnoreCase("all"))
            sortBy = "date";
        else
            sortBy = pSortBy.split("_")[1];
        if ("date".equalsIgnoreCase(sortBy)) {
            return new Comparator<ZINVOICEINFO>() {

                @Override
                public int compare(ZINVOICEINFO pO1, ZINVOICEINFO pO2) {
                    int result = 0;
                    try {
                        Date orderDate1 = sapFormat.parse(pO1.getORDERDATE());
                        Date orderDate2 = sapFormat.parse(pO2.getORDERDATE());
                        if (!pSortBy.equalsIgnoreCase("all")) {
                            final String sortOrder = pSortBy.split("_")[0];
                            if ("Asc".equalsIgnoreCase(sortOrder)) {
                                result = orderDate1.compareTo(orderDate2);
                                if (result == 0) {
                                    result = pO1.getSALESDOCNUMBER().compareTo(
                                            pO2.getSALESDOCNUMBER());
                                }
                            } else {
                                result = orderDate2.compareTo(orderDate1);
                                if (result == 0) {
                                    result = pO2.getSALESDOCNUMBER().compareTo(
                                            pO1.getSALESDOCNUMBER());
                                }
                            }
                        } else {
                            result = orderDate2.compareTo(orderDate1);
                            if (result == 0) {
                                result = pO2.getSALESDOCNUMBER().compareTo(
                                        pO1.getSALESDOCNUMBER());
                            }
                        }
                    } catch (ParseException exception) {
                        vlogError(exception, "");
                    }
                    return result;
                }
            };
        }

        return null;
    }
   
   public Comparator<ZCHINAVATINVOICE> getComparatorChina(final String pSortBy) {
       String sortBy = "";
       if (pSortBy.equalsIgnoreCase("all"))
           sortBy = "date";
       else
           sortBy = pSortBy.split("_")[1];
       if ("date".equalsIgnoreCase(sortBy)) {
           return new Comparator<ZCHINAVATINVOICE>() {

               @Override
               public int compare(ZCHINAVATINVOICE pO1, ZCHINAVATINVOICE pO2) {
                   int result = 0;
                   try {
                       Date orderDate1 = sapFormat.parse(pO1.getORDERDATE());
                       Date orderDate2 = sapFormat.parse(pO2.getORDERDATE());
                       if (!pSortBy.equalsIgnoreCase("all")) {
                           final String sortOrder = pSortBy.split("_")[0];
                           if ("Asc".equalsIgnoreCase(sortOrder)) {
                               result = orderDate1.compareTo(orderDate2);
                               if (result == 0) {
                                   result = pO1.getSALESORDER().compareTo(
                                           pO2.getSALESORDER());
                               }
                           } else {
                               result = orderDate2.compareTo(orderDate1);
                               if (result == 0) {
                                   result = pO2.getSALESORDER().compareTo(
                                           pO1.getSALESORDER());
                               }
                           }
                       } else {
                           result = orderDate2.compareTo(orderDate1);
                           if (result == 0) {
                               result = pO2.getSALESORDER().compareTo(
                                       pO1.getSALESORDER());
                           }
                       }
                   } catch (ParseException exception) {
                       vlogError(exception, "");
                   }
                   return result;
               }
           };
       }

       return null;
   }
	    


	/**
	 * @return the sapManager
	 */
	public SapManager getSapManager() {
		return sapManager;
	}

	/**
	 * @param sapManager
	 *            the sapManager to set
	 */
	public void setSapManager(SapManager sapManager) {
		this.sapManager = sapManager;
	}

	/**
	 * @return the downloadInvoice
	 */
	public String getDownloadInvoice() {
		return downloadInvoice;
	}

	/**
	 * @param downloadInvoice the downloadInvoice to set
	 */
	public void setDownloadInvoice(String downloadInvoice) {
		this.downloadInvoice = downloadInvoice;
	}

	/**
	 * @return the defaultDays
	 */
	public String getDefaultDays() {
		return defaultDays;
	}

	/**
	 * @param defaultDays the defaultDays to set
	 */
	public void setDefaultDays(String defaultDays) {
		this.defaultDays = defaultDays;
	}
	public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }

    public void setEncryptDecryptHelper(EncryptDecryptHelper pEncryptDecryptHelper) {
        mEncryptDecryptHelper = pEncryptDecryptHelper;
    }
}
