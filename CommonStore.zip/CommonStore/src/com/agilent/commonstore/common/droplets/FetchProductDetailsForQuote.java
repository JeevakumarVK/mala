/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */
package com.agilent.commonstore.common.droplets;

import com.agilent.base.commerce.Constants;
import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletException;

import atg.repository.MutableRepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.core.util.StringUtils;
import atg.repository.MutableRepository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;

public class FetchProductDetailsForQuote extends DynamoServlet implements Constants {
	private MutableRepository mRequestQuoteRepository;
	
	/**
	 * @return the mRequestQuoteRepository
	 */
	public MutableRepository getRequestQuoteRepository() {
		return mRequestQuoteRepository;
	}

	/**
	 * @param mRequestQuoteRepository the mRequestQuoteRepository to set
	 */
	
	
	public void setRequestQuoteRepository(MutableRepository mRequestQuoteRepository) {
		this.mRequestQuoteRepository = mRequestQuoteRepository;
	}
	

	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
try
{
		String quoteId= pRequest.getParameter("requestQuoteId");
		vlogDebug("showing data from jsp {0}",quoteId);
		MutableRepositoryItem mutRepItem = (MutableRepositoryItem) getRequestQuoteRepository().getItem(quoteId, "requestQuote");
		Set<RepositoryItem> partNums = (Set<RepositoryItem>) mutRepItem.getPropertyValue("partNums");
		boolean cripsrInd = false;
		if(!partNums.isEmpty()){
			
			for(RepositoryItem item : partNums) {
				if(StringUtils.isNotEmpty((String) item.getPropertyValue(GUIDE_NAME_PROPERTY)) && StringUtils.isNotEmpty((String) item.getPropertyValue(DESIGNID)))
				{
					vlogDebug("Its is crispr initiated quote");
					cripsrInd = true;
					break;
				}
				
			}
			vlogDebug("part data details");
			pRequest.setParameter(CRISPR_INDICATOR, cripsrInd);
			pRequest.setParameter("quoteDetails", partNums);
			pRequest.serviceParameter("OUTPUT", pRequest, pResponse);
		}
		
}catch(RepositoryException e){
	
}
	}



	

}