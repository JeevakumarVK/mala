package com.agilent.commonstore.common.droplets;

import java.io.IOException;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;

import com.agilent.base.common.services.SapManager;
import com.agilent.base.platform.sap.client.Z_ECOM_GET_VAT_TRACKING_INFO.ZECOMGETVATTRACKINGINFOResponse;
import com.agilent.base.profile.SessionBean;
import com.google.gson.Gson;

/**
 * This class is used for providing China VAT shipping related information in JSON format.
 */
public class FetchVatShippingDetailJson extends DynamoServlet {

	private SapManager sapManager;

	@Override
	public void service(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		vlogDebug("FetchInvoiceDetailJson method start");
		Profile pProfile = (Profile) pRequest.getObjectParameter("profile");
		SessionBean pSessionBean = (SessionBean) pRequest
				.getObjectParameter("sessionBean");
		String trackingNo = (String) pRequest.getObjectParameter("trackingNo");

		try {
			pResponse.setContentType("text/html");
			pResponse.setCharacterEncoding("UTF-8");
			ZECOMGETVATTRACKINGINFOResponse  zECOMGETVATTRACKINGINFOResponse = getSapManager().fetchVatTrackingDetail(trackingNo, pSessionBean, pProfile);
			String json = new Gson().toJson(zECOMGETVATTRACKINGINFOResponse);
			vlogDebug("Json in String {0} ", json);
			pResponse.getWriter().write(json);
					

		} catch (Exception e) {
			vlogError("repository exeption {0}", e);
		}
	}

	/**
	 * @return the sapManager
	 */
	public SapManager getSapManager() {
		return sapManager;
	}

	/**
	 * @param sapManager
	 *            the sapManager to set
	 */
	public void setSapManager(SapManager sapManager) {
		this.sapManager = sapManager;
	}

}
