/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */
package com.agilent.commonstore.common.droplets;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.services.PartDetailsVO;
import com.agilent.base.profile.SessionBean;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * @author avneetkaur.m
 *
 */
public class FetchWCSReqQuoteDetails extends DynamoServlet implements Constants {
	
	
	//DCCOM-27238 changes start
		private AgilentCatalogTools mCatalogTools;
		
		 /**
	     * Gets the value of catalogTools
	     * 
	     * @return returns the property catalogTools
	     */
	    public AgilentCatalogTools getCatalogTools() {
	        return mCatalogTools;
	    }

	    /**
	     * Sets the value of property catalogTools with value catalogTools
	     * 
	     * @param catalogTools
	     *            the catalogTools to set
	     */
	    public void setCatalogTools( AgilentCatalogTools catalogTools) {
	        mCatalogTools = catalogTools;
	    }
	
	public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		
		String productName=pRequest.getParameter(PRODUCT_NAME);
		String[] partNumberArray=pRequest.getParameterValues(COMMERCEITEM_PART_NUMBER);
		
		
		Map<String,PartDetailsVO> partDetails = new LinkedHashMap<String,PartDetailsVO>();
		Gson gson = new Gson();
		SessionBean sessionBean = (SessionBean) pRequest.resolveName("/com/agilent/profile/SessionBean");
		
		//Request Quote Code for Search added---
		String src=pRequest.getParameter("source");
		String type=pRequest.getParameter("type");
		
		//APP-15249 - Search results not passing part ID to RFQ form - Edited on June 01/06/2017
		                 
          vlogDebug("Inside FetchWCSReqQuoteDetails: SRC {0}", src);
          vlogDebug("Inside FetchWCSReqQuoteDetails: type {0}", type);
          vlogDebug("Inside FetchWCSReqQuoteDetails: productName {0}", productName);
          vlogDebug("Inside FetchWCSReqQuoteDetails: partNumberArray {0}", partNumberArray);
                               
          if(("").equals(src))
          {
             src = null;
          }                              
          if(("").equals(type))
          {
             type = null;
          }
          if(partNumberArray != null && partNumberArray.length == 0)
		  {
            partNumberArray = null;
          }
          if(("").equals(productName))
           {
              productName = null;
           }
           //APP-15249 - Changes End.

		
		if(null!=src && src.equalsIgnoreCase("search")){
			String partDesc=pRequest.getParameter("reqDescription");
			String partTitle=pRequest.getParameter("reqTitle");
			//String reqproductID=pRequest.getParameter("reqproductID");
			Map<String,String> srchRfqDetails = new HashMap<String,String> ();
			if(null!=partTitle && null!=partDesc){
			srchRfqDetails.put(partTitle,partDesc);
			}
			//SessionBean map property added to restore the post data on refresh
			if (sessionBean != null && !srchRfqDetails.isEmpty()){
			sessionBean.setSrchRfqDetails(srchRfqDetails);
			vlogDebug("Session Bean Data {0}", sessionBean.getSrchRfqDetails());
			}
				if(!srchRfqDetails.isEmpty()) {
					pRequest.setParameter("srchRfqDetails", srchRfqDetails);
					pRequest.serviceParameter("searchDetails", pRequest, pResponse);
					pRequest.setParameter("searchDetailsjson", gson.toJson(srchRfqDetails));
				}else{
					vlogDebug("showing data from sessionbean {0}",sessionBean.getSrchRfqDetails());
					pRequest.setParameter("srchRfqDetails", sessionBean.getSrchRfqDetails());
					pRequest.serviceParameter("searchDetails", pRequest, pResponse);
					pRequest.setParameter("searchDetailsjson", gson.toJson(sessionBean.getSrchRfqDetails()));
				}
		}
		else if((null != productName && (!productName.isEmpty()))){
			vlogDebug("Inside product Details");
			Map<String,String> productDetails = new HashMap<String,String>();
			StringBuilder prodQty=new StringBuilder();
			prodQty.append(productName);
			prodQty.append(QTY);
			if(null != productName && !productName.isEmpty()){
			    String productQuantity=pRequest.getParameter(prodQty.toString()); //"Qty"
			    //changed for getting default quantity to be 1 when no qty is mentioned

			    if(null==productQuantity || productQuantity.isEmpty()){
			        productQuantity=QTY_ONE;
			    } 
                if (null != productName && !productName.isEmpty()) {
                    String dbEncodedProductName = URLEncoder.encode(URLEncoder.encode(productName, Constants.UTF_8), Constants.UTF_8);
                    productDetails.put(dbEncodedProductName, productQuantity);
                }
			}

			vlogDebug("product Details map",productDetails );
			//SessionBean map property added to restore the post data on refresh
			if (sessionBean != null && !productDetails.isEmpty()){
			    sessionBean.setProdDetails(productDetails);
			    sessionBean.setPartDetails(Collections.<String,PartDetailsVO>emptyMap());
			    vlogDebug("Session product Details map", sessionBean.getProdDetails());
			    //sessionBean.getProdDetails().put(3, productDetails);
			}				
			
				if(!productDetails.isEmpty()){
					vlogDebug("Inside product Details map");
					pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails());
					pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(sessionBean.getProdDetails()));
					 
					/*Collection<Integer> s=sessionBean.getProdDetails().keySet();
					if(count!=1){
						Integer lastValue=(Integer) s.toArray()[s.size()-1];
						pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails().get(lastValue));//to check
						pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(sessionBean.getProdDetails().get(lastValue)));
					}else{
						pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails().get(count));//to check
						pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(sessionBean.getProdDetails().get(count)));
					}*/
					//pRequest.setParameter(PRODUCT_DETAILS, productDetails);
			//pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails().get(lastValue));
					
					//pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(productDetails));
				} /*else if(!sessionBean.getProdDetails().isEmpty()){//user comes from another page
					pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails());
					pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(sessionBean.getProdDetails()));	
				}*/
			
	        pRequest.serviceParameter(PRODUCT, pRequest, pResponse);
		}else if((null!=partNumberArray && partNumberArray.length>0) ){
			vlogDebug("Inside part Details");
			boolean isCrisprProductFlag = false;
			if(null!=partNumberArray && partNumberArray.length>0){
			List<String> partNumbers=Arrays.asList(partNumberArray);
			String partNumber="";
			String partNumberQuantity="";
			String partNumberDesc="";
			String crisprDesignId="";
			String crisprGuideName="";
			boolean isCrisprProduct = false;
			
			Map<String,List<String>> mapToStoreReqParameters = new HashMap<String, List<String>>();
			
			for(String partNumberValue : partNumbers) {
				isCrisprProduct = getCatalogTools().checkIfProductIsCrispr(partNumberValue);
				if(isCrisprProduct && StringUtils.isNotBlank(pRequest.getParameter(partNumberValue + DESIGN_ID)) && StringUtils.isNotBlank(pRequest.getParameter(partNumberValue +GUIDE_NAME)) ) {
					isCrisprProductFlag = true;
					break;
				}
			}
			if(isCrisprProductFlag) {
				
			       for(String catalogId: partNumbers) {
			    	   List<String> newList = new ArrayList<String>();
			    	   if(mapToStoreReqParameters != null && !mapToStoreReqParameters.isEmpty() && mapToStoreReqParameters.containsKey(catalogId)) {
			    		   List<String> newList2 = mapToStoreReqParameters.get(catalogId);
			    		if(newList2.contains(catalogId)) {
			    			   newList2.add(catalogId);
			    		   }
			    		  
			    	   }else {
			    		   newList.add(catalogId);
			    		   mapToStoreReqParameters.put(catalogId, newList);
			    	   }
			    	   
			       }
			       
			       for(List<String> partNumberList : mapToStoreReqParameters.values()) {
			    	   int index = 0;
			    	   for(String catalogIdValue: partNumberList) {
			    		   PartDetailsVO partDetailsVo = new PartDetailsVO();
							 String[] guideNameArray=pRequest.getParameterValues(catalogIdValue +GUIDE_NAME);
								String[] designIdArray=pRequest.getParameterValues(catalogIdValue + DESIGN_ID);
								String[] quantityArray=pRequest.getParameterValues(catalogIdValue + QTY);
								if(guideNameArray != null && guideNameArray.length != 0) {
									crisprGuideName=guideNameArray[index];
								}
								if(designIdArray != null && designIdArray.length != 0) {
									crisprDesignId=designIdArray[index];
								}
								if(quantityArray != null && quantityArray.length != 0) {
									partNumberQuantity=quantityArray[index];
								}
								
							 
							 vlogDebug("CrisprProduct for rfq form:: crisprDesignId {0}", crisprDesignId);
							 vlogDebug("isCrisprProduct for rfq form:: crisprGuideName {0}", crisprGuideName);
							 vlogDebug("isCrisprProduct for rfq form:: partNumberQuantity {0}", partNumberQuantity);
							 pRequest.setParameter(CRISPR_PRODUCT_FLAG, isCrisprProduct);
							
							 if(partNumberQuantity.isEmpty()){
									partNumberQuantity=QTY_ONE;
								}
								partDetailsVo.setPartNumberQuantity(partNumberQuantity);
								
								partDetailsVo.setCrisprDesignId(crisprDesignId);
								partDetailsVo.setCrisprGuideName(crisprGuideName);
								if(isCrisprProduct) {
									partDetailsVo.setPartNumber(catalogIdValue);
									String key = catalogIdValue +AND_OPERATOR+ crisprDesignId;
									partDetails.put(key, partDetailsVo);
								}
								
						index++;
			    	   }
			    	   
			       }
				
			}
			else {
				Iterator<String> iterator=partNumbers.iterator();
				while(iterator.hasNext()){
					
					partNumber=iterator.next();
					PartDetailsVO partDetailsVo = new PartDetailsVO();
					if(null!=partNumber && !partNumber.isEmpty()){
						
						partNumberQuantity=pRequest.getParameter(partNumber + QTY);
						
						partNumberDesc=pRequest.getParameter(partNumber + PARTNUMBER_DESCRIPTION);
						if(null!=partNumberDesc && partNumberDesc.isEmpty()){
							partNumberDesc=SYMBOL_HYPHEN;
						}
						if(null!=partNumberQuantity && partNumberQuantity.isEmpty()){
							partNumberQuantity=QTY_ONE;
						}
						partDetailsVo.setPartNumberQuantity(partNumberQuantity);
						partDetailsVo.setPartNumberDesc(partNumberDesc);
						
						
							partDetails.put(partNumber, partDetailsVo);
						
						
					}
					
				}
			}
			}
				vlogDebug("part Details map",partDetails );
			//SessionBean map property added to restore the post data on refresh
			if (sessionBean != null && !partDetails.isEmpty()){
			sessionBean.setPartDetails(partDetails);
			sessionBean.setCrisprProductFlag(isCrisprProductFlag);
			 sessionBean.setProdDetails(Collections.<String,String>emptyMap());
		    vlogDebug("Session part Details map", sessionBean.getPartDetails());
			}
				if(!partDetails.isEmpty()){
					vlogDebug("Inside part Details map");
					pRequest.setParameter(PART_DETAILS, sessionBean.getPartDetails());
					pRequest.setParameter(PART_DETAILS_JSON, gson.toJson(partDetails));
					/*pRequest.setParameter(PART_DETAILS, partDetails);
					pRequest.setParameter(PART_DETAILS_JSON, gson.toJson(partDetails));*/
				} 
			
	        pRequest.serviceParameter(PART, pRequest, pResponse);
			
		}else if(partNumberArray==null && productName==null && src==null && type==null){
			vlogDebug("Inside refresh method of part details");
			if(sessionBean.getProdDetails().isEmpty())
			{
			pRequest.setParameter(PART_DETAILS, sessionBean.getPartDetails());
			pRequest.setParameter(PART_DETAILS_JSON, gson.toJson(sessionBean.getPartDetails()));
			pRequest.setParameter(CRISPR_PRODUCT_FLAG, sessionBean.isCrisprProductFlag());
			pRequest.serviceParameter(PART, pRequest, pResponse);
			}
			if(sessionBean.getPartDetails().isEmpty())
			{
				pRequest.setParameter(PRODUCT_DETAILS, sessionBean.getProdDetails());
				pRequest.setParameter(PRODUCT_DETAILS_JSON, gson.toJson(sessionBean.getProdDetails()));	
			     pRequest.serviceParameter(PRODUCT, pRequest, pResponse);
			}
		}
		 
		else{
			pRequest.serviceParameter(EMPTY, pRequest, pResponse);
		}

	}
}
