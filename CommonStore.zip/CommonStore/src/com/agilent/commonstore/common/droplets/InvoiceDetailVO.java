package com.agilent.commonstore.common.droplets;


public class InvoiceDetailVO {
	
	private String invoiceId;
	private String salesOrder;
	private String orderDate;
	private String purcahseOrder;
	private String invoiceType;
	private String dueDate;
	private String invoiceAmount;
	private String balance;
	private String Satus;
	// For China
	private String delivery;
	private String billing;
	private String vatForwarder;
	private String vatTracking;
	private String vatStatus;
	private String invoiceURL;
	private String encryptedOrderId;
	private String chinaInvoiceType;
	private String invoiceIssueDate;
	private String invoiceTypeFromSAP;
	private String encryptedOrderIdForMyA;

	/**
	 * @return the invoiceTypeFromSAP
	 */
	public String getInvoiceTypeFromSAP() {
		return invoiceTypeFromSAP;
	}
	/**
	 * @param invoiceTypeFromSAP the invoiceTypeFromSAP to set
	 */
	public void setInvoiceTypeFromSAP(String invoiceTypeFromSAP) {
		this.invoiceTypeFromSAP = invoiceTypeFromSAP;
	}
	/**
	 * @return the chinaInvoiceType
	 */
	public String getChinaInvoiceType() {
		return chinaInvoiceType;
	}
	/**
	 * @param chinaInvoiceType the chinaInvoiceType to set
	 */
	public void setChinaInvoiceType(String chinaInvoiceType) {
		this.chinaInvoiceType = chinaInvoiceType;
	}
	/**
	 * @return the invoiceIssueDate
	 */
	public String getInvoiceIssueDate() {
		return invoiceIssueDate;
	}
	/**
	 * @param invoiceIssueDate the invoiceIssueDate to set
	 */
	public void setInvoiceIssueDate(String invoiceIssueDate) {
		this.invoiceIssueDate = invoiceIssueDate;
	}
	/**
	 * @return the encryptedOrderId
	 */
	public String getEncryptedOrderId() {
		return encryptedOrderId;
	}
	/**
	 * @param encryptedOrderId the encryptedOrderId to set
	 */
	public void setEncryptedOrderId(String encryptedOrderId) {
		this.encryptedOrderId = encryptedOrderId;
	}
	/**
	 * @return the invoiceId
	 */
	public String getInvoiceId() {
		return invoiceId;
	}
	/**
	 * @param invoiceId the invoiceId to set
	 */
	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}
	/**
	 * @return the salesOrder
	 */
	public String getSalesOrder() {
		return salesOrder;
	}
	/**
	 * @param salesOrder the salesOrder to set
	 */
	public void setSalesOrder(String salesOrder) {
		this.salesOrder = salesOrder;
	}

	/**
	 * @return the purcahseOrder
	 */
	public String getPurcahseOrder() {
		return purcahseOrder;
	}
	/**
	 * @param purcahseOrder the purcahseOrder to set
	 */
	public void setPurcahseOrder(String purcahseOrder) {
		this.purcahseOrder = purcahseOrder;
	}
	/**
	 * @return the invoiceType
	 */
	public String getInvoiceType() {
		return invoiceType;
	}
	/**
	 * @param invoiceType the invoiceType to set
	 */
	public void setInvoiceType(String invoiceType) {
		this.invoiceType = invoiceType;
	}

	/**
	 * @return the invoiceAmount
	 */
	public String getInvoiceAmount() {
		return invoiceAmount;
	}
	/**
	 * @param invoiceAmount the invoiceAmount to set
	 */
	public void setInvoiceAmount(String invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	/**
	 * @return the balance
	 */
	public String getBalance() {
		return balance;
	}
	/**
	 * @param balance the balance to set
	 */
	public void setBalance(String balance) {
		this.balance = balance;
	}
	/**
	 * @return the satus
	 */
	public String getSatus() {
		return Satus;
	}
	/**
	 * @param satus the satus to set
	 */
	public void setSatus(String satus) {
		Satus = satus;
	}
	/**
	 * @return the orderDate
	 */
	public String getOrderDate() {
		return orderDate;
	}
	/**
	 * @param orderDate the orderDate to set
	 */
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}
	/**
	 * @param dueDate the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	/**
	 * @return the delivery
	 */
	public String getDelivery() {
		return delivery;
	}
	/**
	 * @param delivery the delivery to set
	 */
	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}
	/**
	 * @return the billing
	 */
	public String getBilling() {
		return billing;
	}
	/**
	 * @param billing the billing to set
	 */
	public void setBilling(String billing) {
		this.billing = billing;
	}
	/**
	 * @return the vatForwarder
	 */
	public String getVatForwarder() {
		return vatForwarder;
	}
	/**
	 * @param vatForwarder the vatForwarder to set
	 */
	public void setVatForwarder(String vatForwarder) {
		this.vatForwarder = vatForwarder;
	}
	/**
	 * @return the vatTracking
	 */
	public String getVatTracking() {
		return vatTracking;
	}
	/**
	 * @param vatTracking the vatTracking to set
	 */
	public void setVatTracking(String vatTracking) {
		this.vatTracking = vatTracking;
	}
	/**
	 * @return the vatStatus
	 */
	public String getVatStatus() {
		return vatStatus;
	}
	/**
	 * @param vatStatus the vatStatus to set
	 */
	public void setVatStatus(String vatStatus) {
		this.vatStatus = vatStatus;
	}
	/**
	 * @return the invoiceURL 
	 */
	public String getInvoiceURL() {
		return invoiceURL;
	}
	/**
	 * @param invoiceURL the invoiceURL to set
	 */
	public void setInvoiceURL(String invoiceURL) {
		this.invoiceURL = invoiceURL;
	}

	public String getEncryptedOrderIdForMyA() {
		return encryptedOrderIdForMyA;
	}
	public void setEncryptedOrderIdForMyA(String encryptedOrderIdForMyA) {
		this.encryptedOrderIdForMyA = encryptedOrderIdForMyA;
	}
	

}
