package com.agilent.commonstore.common.droplets;

import java.util.HashMap;
import java.util.Map;

public class InvoiceVO {
	
	private Map<String, InvoiceDetailVO> invoiceMap = new HashMap<String, InvoiceDetailVO>();

	/**
	 * @return the invoiceMap
	 */
	public Map<String, InvoiceDetailVO> getInvoiceMap() {
		return invoiceMap;
	}

	/**
	 * @param invoiceMap the invoiceMap to set
	 */
	public void setInvoiceMap(Map<String, InvoiceDetailVO> invoiceMap) {
		this.invoiceMap = invoiceMap;
	}

}
