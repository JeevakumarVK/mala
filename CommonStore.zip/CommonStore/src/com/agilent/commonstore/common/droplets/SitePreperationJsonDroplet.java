/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.common.droplets;

import static com.agilent.base.commerce.Constants.CXSITE_ERROR;
import static com.agilent.base.commerce.Constants.CXSITE_ERRORMSG;
import static com.agilent.base.commerce.Constants.CXSITE_MAPOFPARTNUM_PRODNAMEURL;
import static com.agilent.base.commerce.Constants.CXSITE_MAPOFPRODNAME_URL;
import static com.agilent.base.commerce.Constants.CXSITE_NUMOFRECORDS;
import static com.agilent.base.commerce.Constants.CXSITE_QUOTEDITEMS;
import static com.agilent.base.commerce.Constants.CXSITE_SAPNOTAVAIABLE_MSG;
import static com.agilent.base.commerce.Constants.EMPTY;
import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.agilent.base.common.ChinaConfiguration;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.platform.CountryUtils;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This is used for creating SITE prepation JSON data to be dispalyed on front end.
 */
@SuppressWarnings({"unchecked", "cast"})
public class SitePreperationJsonDroplet extends DynamoServlet {

    private boolean caseSensitive;
    private String cxSiteRequestUrl;
    private String cxSiteDimensionLength;
    private String cxSiteUrlReturnedFromSearch;
    private String cxSiteBaseUrl;
    private String cxSiteBaseResponseUrl;
    private String cxSiteRequestUrlFormat;
    private String cxSiteURLPartNumVar;
    private String cxSiteURLDimensionVar;
    private String cxSiteURLResponseVar;
    private List<String> skipCharacters;
    private boolean mEnableTesting;
    private ChinaConfiguration mChinaConfiguration;
    private CountryUtils mCountryUtils;
    

	
    /**
     * This method is used for creating SITE prepation JSON data to be dispalyed on front end.
     */
    public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes) throws ServletException, IOException, ClientProtocolException {
		Map<String, Map<String, String>> partNumandMapOfProductNameWithUrl = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> productNameAndUrlMap = new LinkedHashMap<String, String>();
		StringBuilder urlFromSearch;
		StringBuilder cxSearchQueryUrl;
		String domain = pReq.getServerName();
		List<LineItem> orderDetailItems = (List<LineItem>) pReq.getObjectParameter(CXSITE_QUOTEDITEMS);
		if (orderDetailItems != null && !orderDetailItems.isEmpty()) {
			for (LineItem partnumbers : orderDetailItems) {
				String updatedRefurbishedPart = checkAndUpdateRefurbishedPart(partnumbers.getCatId());
				cxSearchQueryUrl = new StringBuilder();
				cxSearchQueryUrl.append(getCxSiteBaseUrl()).append(getCxSiteRequestUrl())
						.append(getCxSiteURLDimensionVar()).append(getCxSiteDimensionLength())
						.append(getCxSiteRequestUrlFormat()).append(updatedRefurbishedPart);
				vlogDebug("request url send to search webservice:{0} ", cxSearchQueryUrl);
				vlogDebug("....request url successfully framed and is before httpclient....");
				HttpClient httpClient = HttpClientBuilder.create().build();
				vlogDebug("........After httpclient execution.........");
				try {
					HttpGet request = new HttpGet(cxSearchQueryUrl.toString());
					HttpResponse response = httpClient.execute(request);
					if (response != null) {
						productNameAndUrlMap = new LinkedHashMap<String, String>();
						String json = EntityUtils.toString(response.getEntity());
						// JSON parsing from search service
						JsonObject jsonObj = new JsonParser().parse(json).getAsJsonObject();
						JsonElement noOfRecords = jsonObj.get(CXSITE_NUMOFRECORDS);
						if (noOfRecords != null) {
							int val = noOfRecords.getAsInt();
							vlogDebug("value of noOfRecords:{0} ", val);
							if (val > 0) {
								urlFromSearch = new StringBuilder();
								 if(StringUtils.isNotBlank(domain)&&domain.contains(getCountryUtils().getChinaProfileCookieDomain())){
	                                	urlFromSearch.append(getChinaConfiguration().getChinaCxSiteBaseResponseUrl()).append(getCxSiteUrlReturnedFromSearch()).append(getCxSiteURLPartNumVar())
	                                    .append(updatedRefurbishedPart).append(getCxSiteURLResponseVar()).append(getCxSiteDimensionLength());
	                                }else{
	                                	urlFromSearch.append(getCxSiteBaseResponseUrl()).append(getCxSiteUrlReturnedFromSearch()).append(getCxSiteURLPartNumVar())
	                                    .append(updatedRefurbishedPart).append(getCxSiteURLResponseVar()).append(getCxSiteDimensionLength());
	                                }
								vlogDebug("url that is formed from search webservice:{0} ", urlFromSearch);
								productNameAndUrlMap.put(partnumbers.getProductName(), urlFromSearch.toString());
								partNumandMapOfProductNameWithUrl.put(partnumbers.getCatId(), productNameAndUrlMap);
							}
						}
					}
				} catch (ClientProtocolException e) {
					vlogError("ClientProtocolException while generating response {0}", e);
				} catch (IOException e1) {
					vlogError("IOException while generating response {0}", e1);
				} catch (JsonParseException e2) {
					vlogError("JsonParseException while generating response {0}", e2);
				} catch (IllegalStateException e3) {
					vlogError("IllegalStateException while generating response {0}", e3);
				} catch (Exception e4) {
					vlogError("Exception while generating response {0}", e4);
				}
			}
			if (partNumandMapOfProductNameWithUrl != null && !partNumandMapOfProductNameWithUrl.isEmpty()) {
				pReq.setParameter(CXSITE_MAPOFPRODNAME_URL, productNameAndUrlMap);
				pReq.setParameter(CXSITE_MAPOFPARTNUM_PRODNAMEURL, partNumandMapOfProductNameWithUrl);
				pReq.serviceLocalParameter(OUTPUT, pReq, pRes);
				vlogDebug("setting map to OUTPUT parameter for CXsitePreperation:{0}",
						partNumandMapOfProductNameWithUrl);
			} else {
				
					pReq.serviceLocalParameter(EMPTY, pReq, pRes);
					vlogDebug("setting map to EMPTY parameter for CXsitePreperation");
				
			}
		} else {
			if (isEnableTesting()) {
				urlFromSearch = new StringBuilder();
				String updatedRefurbishedPart = checkAndUpdateRefurbishedPart("123-BD01");
				urlFromSearch.append(getCxSiteBaseResponseUrl()).append(getCxSiteUrlReturnedFromSearch())
						.append(getCxSiteURLPartNumVar()).append(updatedRefurbishedPart)
						.append(getCxSiteURLResponseVar()).append(getCxSiteDimensionLength());

				productNameAndUrlMap.put("123-BD01", urlFromSearch.toString());
				partNumandMapOfProductNameWithUrl.put("123-BD01", productNameAndUrlMap);
				pReq.setParameter(CXSITE_MAPOFPRODNAME_URL, productNameAndUrlMap);
				pReq.setParameter(CXSITE_MAPOFPARTNUM_PRODNAMEURL, partNumandMapOfProductNameWithUrl);
				pReq.serviceLocalParameter(OUTPUT, pReq, pRes);
			} else {
				String sapNotVAilable = CXSITE_SAPNOTAVAIABLE_MSG;
				pReq.setParameter(CXSITE_ERRORMSG, sapNotVAilable);
				pReq.serviceParameter(CXSITE_ERROR, pReq, pRes);
				vlogDebug("setting map to ERROR parameter for CXsitePreperation");
			}
		}
    }

    /**
     * This method is used to check and update refurbished part number.
     * 
     * @param pPartNumber
     * @return
     */
    private String checkAndUpdateRefurbishedPart(String pPartNumber) {
        vlogDebug("Method processEnablement - start");
        vlogDebug("part number to check: {0}", pPartNumber);
        boolean isRefurbished = false;
        String partNumber = pPartNumber;
        StringBuilder updatedPartNumber = null; 
        List<String> skipCharacters = getSkipCharacters();
        if (StringUtils.isNotBlank(partNumber) && skipCharacters != null && !skipCharacters.isEmpty()) {
            updatedPartNumber = new StringBuilder(partNumber); 
            for (String skipCharacter : skipCharacters) {
                int position = Integer.valueOf(skipCharacter.split(":")[1]);
                String skipChar = skipCharacter.split(":")[0];
                if (updatedPartNumber.length() > 0) {
                    if (isCaseSensitive()) {
                        partNumber = partNumber.toUpperCase();
                        skipChar = skipChar.toUpperCase();
                    }
                    switch (position) {
                        case 1:
                            vlogDebug("checking start of part number.");
                            if (partNumber.startsWith(skipChar)) {
                                updatedPartNumber.deleteCharAt(0);
                                isRefurbished = true;
                            }
                            break;

                        case 2:
                            vlogDebug("checking end of part number.");
                            if (partNumber.endsWith(skipChar)) {
                                updatedPartNumber.deleteCharAt(partNumber.length() - 1);
                                isRefurbished = true;
                            }
                            break;

                        case 3:
                            vlogDebug("checking entire part number.");
                            if (partNumber.contains(skipChar)) {
                                String tempPartNumber = partNumber;
                                tempPartNumber.replace(skipChar, "");
                                updatedPartNumber.setLength(0);
                                updatedPartNumber.append(tempPartNumber);
                                isRefurbished = true;
                            }
                            break;

                        default:
                            vlogInfo("Wrong choice passed!!");
                            break;
                    }
                }
            }
        }
        vlogDebug("isRefurbishedPart: {0}", isRefurbished);
        if (isRefurbished && updatedPartNumber != null && updatedPartNumber.length() > 0) {
            partNumber = updatedPartNumber.toString();
        } else {
            partNumber = pPartNumber;
        }
        vlogDebug("Method processEnablement - end");
        return partNumber;
    }

    /**
     * Gets the value of property caseSensitive
     *
     * @return the value of property caseSensitive
     */
    public boolean isCaseSensitive() {
        return caseSensitive;
    }
    /**
     * Sets the value of property caseSensitive with value pCaseSensitive
     *
     * @param pCaseSensitive
     *            for setting property caseSensitive
     */
    public void setCaseSensitive(boolean pCaseSensitive) {
        caseSensitive = pCaseSensitive;
    }

    /**
     * Gets the value of property cxSiteRequestUrl
     *
     * @return the value of property cxSiteRequestUrl
     */
    public String getCxSiteRequestUrl() {
        return cxSiteRequestUrl;
    }
    /**
     * Sets the value of property cxSiteRequestUrl with value pCxSiteRequestUrl
     *
     * @param pCxSiteRequestUrl
     *            for setting property cxSiteRequestUrl
     */
    public void setCxSiteRequestUrl(String pCxSiteRequestUrl) {
        cxSiteRequestUrl = pCxSiteRequestUrl;
    }

    /**
     * Gets the value of property cxSiteDimensionLength
     *
     * @return the value of property cxSiteDimensionLength
     */
    public String getCxSiteDimensionLength() {
        return cxSiteDimensionLength;
    }
    /**
     * Sets the value of property cxSiteDimensionLength with value pCxSiteDimensionLength
     *
     * @param pCxSiteDimensionLength
     *            for setting property cxSiteDimensionLength
     */
    public void setCxSiteDimensionLength(String pCxSiteDimensionLength) {
        cxSiteDimensionLength = pCxSiteDimensionLength;
    }

    /**
     * Gets the value of property cxSiteUrlReturnedFromSearch
     *
     * @return the value of property cxSiteUrlReturnedFromSearch
     */
    public String getCxSiteUrlReturnedFromSearch() {
        return cxSiteUrlReturnedFromSearch;
    }
    /**
     * Sets the value of property cxSiteUrlReturnedFromSearch with value pCxSiteUrlReturnedFromSearch
     *
     * @param pCxSiteUrlReturnedFromSearch
     *            for setting property cxSiteUrlReturnedFromSearch
     */
    public void setCxSiteUrlReturnedFromSearch(String pCxSiteUrlReturnedFromSearch) {
        cxSiteUrlReturnedFromSearch = pCxSiteUrlReturnedFromSearch;
    }

    /**
     * Gets the value of property cxSiteBaseUrl
     *
     * @return the value of property cxSiteBaseUrl
     */
    public String getCxSiteBaseUrl() {
        return cxSiteBaseUrl;
    }
    /**
     * Sets the value of property cxSiteBaseUrl with value pCxSiteBaseUrl
     *
     * @param pCxSiteBaseUrl
     *            for setting property cxSiteBaseUrl
     */
    public void setCxSiteBaseUrl(String pCxSiteBaseUrl) {
        cxSiteBaseUrl = pCxSiteBaseUrl;
    }

    /**
     * Gets the value of property cxSiteBaseResponseUrl
     *
     * @return the value of property cxSiteBaseResponseUrl
     */
    public String getCxSiteBaseResponseUrl() {
        return cxSiteBaseResponseUrl;
    }
    /**
     * Sets the value of property cxSiteBaseResponseUrl with value pCxSiteBaseResponseUrl
     *
     * @param pCxSiteBaseResponseUrl
     *            for setting property cxSiteBaseResponseUrl
     */
    public void setCxSiteBaseResponseUrl(String pCxSiteBaseResponseUrl) {
        cxSiteBaseResponseUrl = pCxSiteBaseResponseUrl;
    }

    /**
     * Gets the value of property cxSiteRequestUrlFormat
     *
     * @return the value of property cxSiteRequestUrlFormat
     */
    public String getCxSiteRequestUrlFormat() {
        return cxSiteRequestUrlFormat;
    }
    /**
     * Sets the value of property cxSiteRequestUrlFormat with value pCxSiteRequestUrlFormat
     *
     * @param pCxSiteRequestUrlFormat
     *            for setting property cxSiteRequestUrlFormat
     */
    public void setCxSiteRequestUrlFormat(String pCxSiteRequestUrlFormat) {
        cxSiteRequestUrlFormat = pCxSiteRequestUrlFormat;
    }

    /**
     * Gets the value of property cxSiteURLPartNumVar
     *
     * @return the value of property cxSiteURLPartNumVar
     */
    public String getCxSiteURLPartNumVar() {
        return cxSiteURLPartNumVar;
    }
    /**
     * Sets the value of property cxSiteURLPartNumVar with value pCxSiteURLPartNumVar
     *
     * @param pCxSiteURLPartNumVar
     *            for setting property cxSiteURLPartNumVar
     */
    public void setCxSiteURLPartNumVar(String pCxSiteURLPartNumVar) {
        cxSiteURLPartNumVar = pCxSiteURLPartNumVar;
    }

    /**
     * Gets the value of property cxSiteURLDimensionVar
     *
     * @return the value of property cxSiteURLDimensionVar
     */
    public String getCxSiteURLDimensionVar() {
        return cxSiteURLDimensionVar;
    }
    /**
     * Sets the value of property cxSiteURLDimensionVar with value pCxSiteURLDimensionVar
     *
     * @param pCxSiteURLDimensionVar
     *            for setting property cxSiteURLDimensionVar
     */
    public void setCxSiteURLDimensionVar(String pCxSiteURLDimensionVar) {
        cxSiteURLDimensionVar = pCxSiteURLDimensionVar;
    }

    /**
     * Gets the value of property cxSiteURLResponseVar
     *
     * @return the value of property cxSiteURLResponseVar
     */
    public String getCxSiteURLResponseVar() {
        return cxSiteURLResponseVar;
    }
    /**
     * Sets the value of property cxSiteURLResponseVar with value pCxSiteURLResponseVar
     *
     * @param pCxSiteURLResponseVar
     *            for setting property cxSiteURLResponseVar
     */
    public void setCxSiteURLResponseVar(String pCxSiteURLResponseVar) {
        cxSiteURLResponseVar = pCxSiteURLResponseVar;
    }

    /**
     * Gets the value of property skipCharacters
     *
     * @return the value of property skipCharacters
     */
    public List<String> getSkipCharacters() {
        return skipCharacters;
    }
    /**
     * Sets the value of property skipCharacters with value pSkipCharacters
     *
     * @param pSkipCharacters
     *            for setting property skipCharacters
     */
    public void setSkipCharacters(List<String> pSkipCharacters) {
        skipCharacters = pSkipCharacters;
    }
    public boolean isEnableTesting() {
		return mEnableTesting;
	}

	public void setEnableTesting(boolean mEnableTesting) {
		this.mEnableTesting = mEnableTesting;
	}
	public ChinaConfiguration getChinaConfiguration() {
		return mChinaConfiguration;
	}

	public void setChinaConfiguration(ChinaConfiguration pChinaConfiguration) {
		this.mChinaConfiguration = pChinaConfiguration;
	}
	public CountryUtils getCountryUtils() {
	        return mCountryUtils;
	}
	public void setCountryUtils(CountryUtils pCountryUtils) {
	        mCountryUtils = pCountryUtils;
	}
}