/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.common.droplets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.droplets.bean.SubscriptionOrdersVO;
import com.agilent.base.commerce.order.AgilentOrderTools;

import atg.commerce.CommerceException;
import atg.commerce.order.Order;
import atg.commerce.order.scheduled.ScheduledOrderTools;

import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;


/**
 * This droplet is used for fetching Subscription orders.
 */
public class SubscriptionDroplet extends DynamoServlet implements Constants {

    private static final String SUBSCRIPTIONS_BY_PROFILE = "subscriptionsByProfile";
    private static final String SUBSCRIPTION_BY_ID = "subscriptionById";
    private static final String CLONE_ORDER = "cloneOrder";
    
    private static final ParameterName OPNAME = ParameterName.getParameterName("opName");
    private static final ParameterName SUBOPNAME = ParameterName.getParameterName("subOpName");

    private AgilentOrderTools mOrderTools;
    private ScheduledOrderTools mScheduledOrderTools;

    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        boolean output = false;
        String operation = pRequest.getParameter(OPNAME);
        String subOperation = pRequest.getParameter(SUBOPNAME);
        if (SUBSCRIPTIONS_BY_PROFILE.equalsIgnoreCase(operation) && pRequest.getObjectParameter(PROFILE_PARAM) != null && pRequest.getParameter(CURRENCYLOCALEVAL) != null) {
            Profile profile = (Profile) pRequest.getObjectParameter(PROFILE_PARAM);
            String profileId = (String) profile.getPropertyValue(ID);
            String userSalesOrg = (String) profile.getPropertyValue(SALES_ORG);
            String currencyLocaleVal = pRequest.getParameter(CURRENCYLOCALEVAL);
            vlogDebug("Subscription Profile ID {0}, userSalesOrg {1} ,currencyLocaleVal {2}", profileId, userSalesOrg, currencyLocaleVal);
            List<SubscriptionOrdersVO> subscriptions = null;
            if (StringUtils.isNotBlank(profileId) && StringUtils.isNotBlank(userSalesOrg) && StringUtils.isNotBlank(currencyLocaleVal)) {
                subscriptions = getOrderTools().fetchSubscriptionsByProfile(profileId, userSalesOrg, currencyLocaleVal);
            }
            if (subscriptions != null && !subscriptions.isEmpty()) {
                pRequest.setParameter(SUBSCRIPTIONS, subscriptions);
                output = true;
            }
        }
        if (SUBSCRIPTION_BY_ID.equalsIgnoreCase(operation) && pRequest.getParameter(SUBSCRIPTIONID) != null) {
            String subscriptionId = (String) pRequest.getParameter(SUBSCRIPTIONID);
            SubscriptionOrdersVO subscription = getOrderTools().fetchSubscriptionDetails(subscriptionId);
            if (subscription != null) {
                pRequest.setParameter(SUBSCRIPTION, subscription);
                output = true;
                if (CLONE_ORDER.equalsIgnoreCase(subOperation) && subscription.getSubscriptionOrderId() !=null) {
                    try{
                        Order clonedTemplateOrder = getScheduledOrderTools().cloneOrder(subscription.getSubscriptionOrderId());
                        pRequest.setParameter(CLONED_TEMPLATE_ORDER, clonedTemplateOrder);
                    } catch (CommerceException e) {
                        vlogError("Error happened while cloning template order for subscription id {0}. Error deatsils {1}", subscription.getSubscriptionId(), e);
                    }
                }
            }
        }
        if (output) {
            pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
        } else {
            pRequest.serviceParameter(EMPTY, pRequest, pResponse);
        }
    }

    /**
     * Gets the value of property orderTools
     *
     * @return the value of property orderTools
     */
    public AgilentOrderTools getOrderTools() {
        return mOrderTools;
    }
    /**
     * Sets the value of property orderTools with value pOrderTools
     *
     * @param pOrderTools
     *            for setting property orderTools
     */
    public void setOrderTools(AgilentOrderTools pOrderTools) {
        mOrderTools = pOrderTools;
    }

    /**
     * Gets the value of property mScheduledOrderTools
     *
     * @return the value of property mScheduledOrderTools
     */
    public ScheduledOrderTools getScheduledOrderTools() {
        return mScheduledOrderTools;
    }

    /**
     * Sets the value of property mScheduledOrderTools with value pScheduledOrderTools
     *
     * @param pScheduledOrderTools
     *            for setting property mScheduledOrderTools
     */
    public void setScheduledOrderTools(ScheduledOrderTools pScheduledOrderTools) {
        mScheduledOrderTools = pScheduledOrderTools;
    }
}