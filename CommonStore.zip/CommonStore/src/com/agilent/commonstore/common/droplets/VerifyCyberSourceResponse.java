/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.common.droplets;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.TimeZone;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.ServletException;

import org.apache.commons.lang3.LocaleUtils;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.order.SubscriptionConstants;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.common.ChinaConfiguration;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.profile.SessionBean;
import com.agilent.i18n.service.InternationalizationService;
import com.objectspace.jgl.HashMap;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;
import sun.misc.BASE64Encoder;

/**
 * Creates CyberSource Signed fields
 * 
 * @author Biseswar Choudhury
 * @project CyberSource PCI
 */
public class VerifyCyberSourceResponse extends DynamoServlet implements Constants {

    private static final String RESPONSE_CODE = "responseCode";
    private static final String CARD_EXPIRATION_YEAR = "card_expirationYear";
    private static final String SIGNATURE = "signature";
    private static final String INVALID_FIELDS = "invalid_fields";
    private static final String PAYMENT_TOKEN = "payment_token";
    private static final String REQ_LOCALE = "req_locale";
    private static final String REQ_CARD_NUMBER = "req_card_number";
    private static final String REQ_CARD_TYPE = "req_card_type";
    private static final String REASON_CODE = "reason_code";
    private static final String AUTH_CODE = "auth_code";
    private static final String AUTH_TIME = "auth_time";
    private static final String TRANSACTION_ID = "transaction_id";
    private static final String ORDERID = "req_merchant_defined_data2";
    private static final String REQ_CARD_EXPIRY_DATE = "req_card_expiry_date";
    private static final String USER_COUNTRY = "userCountry";
    private static final String SIGNED_FIELD_NAME = "signed_field_names";
    private static final String ERR_MSG_KEY = "cyberSourceErrorMsg.";
    private String mDefaultCountry = "US";
    private Map<String, String> responseValues = new java.util.HashMap<String, String>();
    private AgilentConfiguration mConfiguration;
    private static final String HMAC_SHA256 = "HmacSHA256";
    private String SECRET_KEY;
    private Profile mUserProfile;
    private Map<String, String> mCustomResponseMap;
    private AgilentConfigurationSecond mAgilentConfigurationSecond;
    private ChinaConfiguration mChinaConfiguration;
    private AgilentConfigurationSecond mConfigurationSecond;
    private SessionBean mSessionBean;
    private InternationalizationService mInternationalizationService;
    private CountryUtils mCountryUtils;
    private static final String CC_ERROR_CHECK="ccErrorCheck";
    private static final String FLOW = "req_merchant_defined_data8";
    private static final String EDIT_SUBSCRIPTION_FLOW="SUBSCRIPTIONORDER";

    /**
     * Service method of this droplet which holds logic to read CyberSource response
     */
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        boolean signatureVerified = false;

        // Veriry signature and read CyberSource response attributes
        signatureVerified = verifySignature(pRequest, responseValues);
        vlogDebug("Signature Verified Status: {0}", signatureVerified);
        pRequest.setParameter(VERIFIED_SIGNATURE, signatureVerified);
        if (signatureVerified) {
            pRequest.setParameter(VERIFIED_OUTPUT, responseValues);
        } else {
            vlogError("CyberSource signatureVerified = {0} ", signatureVerified);
        }

        // Update Dynamo Http Request and Response
        pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
    }

    /**
     * This method is used to read CyberSource response parameters and set approtiate values to output service parameter
     * 
     * @param pResponseSignature
     *            - CyberSource reponse
     * @param pResponseValues
     *            - Map to hold specific CyberSource response values
     * @return true if CyberSource signature is verfied, else return false
     */
private boolean verifySignature(DynamoHttpServletRequest pResponseSignature, Map<String, String> pResponseValues) {

        boolean isSignVerified = false;
        HashMap responseMap = null;

        try {
            // Below two are mandatory response fields.
            String decision = pResponseSignature.getParameter(DECISION);
            String message = pResponseSignature.getParameter(MESSAGE);
            boolean isValidResponse = true;
            // Set custom response code
            vlogInfo("Current decision: " + decision);
            if(StringUtils.isNotBlank(decision) && StringUtils.isNotBlank(getCustomResponseMap().get(decision))){
            	pResponseSignature.setParameter(RESPONSE_CODE, getCustomResponseMap().get(decision));
            } else{
            	vlogError("Invalid decision coming from cybersourse. Current decision: " + decision);
            	pResponseSignature.setParameter(RESPONSE_CODE, ERROR);
            	isValidResponse = false;
            }

            // Perform below operations in case of ACCEPT
            if (RESPONSEDECISION.equalsIgnoreCase(decision)) {
                vlogDebug("Response message from CyberSource " + message + EMPTY_STRING, MESSAGE);

                // Read CyberSource response parameters
                String reasoncode = pResponseSignature.getParameter(REASON_CODE);
                String authCode = pResponseSignature.getParameter(AUTH_CODE);
                vlogDebug("Auth Code: {0}", authCode);
                String authDate = pResponseSignature.getParameter(AUTH_TIME);
                vlogDebug("Auth Date: {0}", authDate);
                String transactionId = pResponseSignature.getParameter(TRANSACTION_ID);
                String orderId = pResponseSignature.getParameter(ORDERID);
                String cardNumber = pResponseSignature.getParameter(REQ_CARD_NUMBER);
                String cardExpDate = pResponseSignature.getParameter(REQ_CARD_EXPIRY_DATE);
                String cardType = pResponseSignature.getParameter(REQ_CARD_TYPE);
                String paymentToken = validateAndSetString(pResponseSignature.getParameter(PAYMENT_TOKEN), EMPTY_STRING);
                String signature = validateAndSetString(pResponseSignature.getParameter(SIGNATURE), EMPTY_STRING);

                // Create Response Map and sign
                Enumeration<?> postParametes = pResponseSignature.getPostParameterNames();
                responseMap = new HashMap();
                while (postParametes.hasMoreElements()) {
                    String key = postParametes.nextElement().toString();
                    if (!(UTF8.equalsIgnoreCase(key))) {
                        responseMap.put(key, pResponseSignature.getParameter(key));
                    }
                }
                
                String result = sign(responseMap);
                vlogDebug("Result:"+result);
                vlogDebug("Response signature and verification signature : ", signature + " and " + result);

                // Check if CyberSource sent sugnature is same as configured at our end.
                if (signature.equals(result)) {
                    pResponseValues.put(DECISION, decision);
                    pResponseValues.put(ORDERID_PARAM, orderId);
                    pResponseValues.put(TRANSACTION_SIGNATURE, signature);
                    pResponseValues.put(CREDITCARDNUMBER, cardNumber);
                    pResponseValues.put(CREDITCARDTYPE, findCardName(cardType));
                    pResponseValues.put(REASONCODE, reasoncode);
                    pResponseValues.put(AUTHCODE, authCode);
                    pResponseValues.put(AUTHDATE, authDate);
                    pResponseValues.put(SUBSCRIPTIONID, paymentToken);
                    pResponseValues.put(VERIFIED_SIGNATURE, VERIFIED);
                    pResponseValues.put(REQUEST_ID, transactionId);
                    pResponseValues.put(CREDITCARDEXPIRYDATE, cardExpDate);
                    // For ACCEPT decision this is a mandatory response field. Hence, no NULL check here.
                    String[] cardYear = cardExpDate.split(SYMBOL_HYPHEN);
                    pResponseValues.put(CARD_EXPIRATION_YEAR, cardYear[1]);
                    isSignVerified = true;
                    if (null != getSessionBean()
							&& StringUtils.isNotBlank(getSessionBean().getSubscriptionVO().getFrequencyCode())
							&& !getSessionBean().getSubscriptionVO().getFrequencyCode().equalsIgnoreCase(ZERO)
							&& checkCardExpireBeforeEndDate(cardExpDate)
							&& null != pResponseSignature.getParameter(FLOW)
							&& !pResponseSignature.getParameter(FLOW)
									.equalsIgnoreCase(EDIT_SUBSCRIPTION_FLOW)) {
						vlogDebug("Credit card expires in a year hence error response redirection", cardExpDate);
						pResponseSignature.setParameter(CC_ERROR_CHECK, SUB_CHECK_CARD_EXPIRATION);
						pResponseSignature.setParameter(RESPONSE_CODE, ERROR);
						isSignVerified = false;
					}
                    vlogDebug("CyberSournce Subscrition Id: {0}", paymentToken);
                    vlogDebug("Response Map {0}:", pResponseValues);
                    vlogDebug("Response Map Auth Code {0}:", pResponseValues.get(AUTHCODE));
                    vlogDebug("Response Map Auth Date {0}:", pResponseValues.get(AUTHDATE));
                    if(isSignVerified){
                    vlogDebug("CyberSournce Signature Verfication is successful.");
                    }
                    else if(StringUtils.isNotBlank(getSessionBean().getSubscriptionVO().getFrequencyCode()) && !isSignVerified){
                    	  vlogDebug("Subscription flow and credit card expires in a year");	
                    }
                } else {
                    String invalidFields = pResponseSignature.getParameter(INVALID_FIELDS);
                    vlogError("Error response message from CyberSource {0}" + message + EMPTY_STRING, MESSAGE);
                    vlogError("Error in doing CyberSource payment: Response Signature not verified. Please check input fields for any error: {0}", invalidFields);
                }
            } else if (!CANCEL.equalsIgnoreCase(decision)) {
                // Perform below operations in case of ERROR scenario
            	vlogDebug("Response Map {0}:", pResponseValues);
            	vlogDebug("pResponseSignature {0}:", pResponseSignature);
            	
                String invalidFields = pResponseSignature.getParameter(INVALID_FIELDS);
                vlogDebug("invalidFields {0}:", invalidFields);
                vlogError("Error response message from CyberSource {0}" + message + EMPTY_STRING, MESSAGE);
                vlogError("Error in doing CyberSource payment. Please check input fields for any error: {0}", invalidFields);

                // Set user friendly error message when CyberSource decision is not ACCEPT and CANCEL
                String reasoncode = pResponseSignature.getParameter(REASON_CODE);
                vlogDebug("reasoncode {0}:", reasoncode);
                String reqLocale = LOCALE_US;
                if(StringUtils.isNotBlank(pResponseSignature.getParameter(REQ_LOCALE))){
                    reqLocale = StringUtils.replace(pResponseSignature.getParameter(REQ_LOCALE), SYMBOL_HYPHEN, SYMBOL_UNDERSCORE);
                }
                Locale locale = LocaleUtils.toLocale(reqLocale);
                ResourceBundle bundle = ResourceBundle.getBundle("com.agilent.checkout.LabelResources", locale);
                // Localizing the CyberSource user friendly error message.
                String errorMessage = bundle.getString(ERR_MSG_KEY + DEFAULT);
                String ccErrorCheck = ERR_MSG_KEY + DEFAULT; 
                vlogDebug("ccErrorCheck {0}:", ccErrorCheck);
                vlogDebug("CyberSource errorMessage: {0}", errorMessage);
                if (bundle.containsKey(ERR_MSG_KEY + reasoncode)) {
                    errorMessage = bundle.getString(ERR_MSG_KEY + reasoncode);
                    ccErrorCheck = ERR_MSG_KEY + reasoncode;
                    vlogDebug("CyberSource errorMessage inside if loop: {0}", ccErrorCheck);
                    vlogDebug("CyberSource errorMessage inside if loop: {0}", errorMessage);

                }
               
                if(StringUtils.isBlank(reasoncode) || !isValidResponse){
                	errorMessage = getInternationalizationService().getLocalizeMessage(Constants.CC_NULL_RESPONSE_ERROR_MSG, null);
                	populateCCParamDetails(pResponseSignature);
                }
                String domain=pResponseSignature.getServerName();
                if(StringUtils.isNotBlank(domain)&&domain.contains(getAgilentConfigurationSecond().getChinaProfileCookieDomain())){
                	errorMessage = MessageFormat.format(errorMessage, getChinaConfiguration().getChinaContactUs());
                }else{
                	errorMessage = MessageFormat.format(errorMessage, getConfiguration().getContactUs());
                }
                pResponseSignature.setParameter(ERROR_MESSAGE, errorMessage);
                pResponseSignature.setParameter("ccErrorCheck", ccErrorCheck);
            } else {
                vlogInfo("The customer cancelled the transaction.");
            }
        } catch (Exception exception) {
        	
         vlogError("Error in doing CyberSource payment: {0}", exception);
        }

        return isSignVerified;
    }

	private void populateCCParamDetails(DynamoHttpServletRequest pResponseSignature) {
		pResponseSignature.setParameter("req_merchant_defined_data8", getSessionBean().getCreditCardCheckoutFlow());
		vlogDebug("populateCCParamDetails:: req_merchant_defined_data8: {0}", pResponseSignature.getParameter("req_merchant_defined_data8"));
		if(getSessionBean().getCcDetails()!=null && !getSessionBean().getCcDetails().isEmpty()){
			for(Entry<String,String> data : getSessionBean().getCcDetails().entrySet()){
				pResponseSignature.setParameter("req_merchant_defined_"+data.getKey(), data.getValue());
				vlogDebug("populateCCParamDetails:: key: {0} value: {1}" , "req_merchant_defined_"+data.getKey(), data.getValue());
			}
		}
	}

    /**
     * CyberSource method to sign passed parameters.
     * 
     * @param params
     * @return
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     */
    private String sign(HashMap params) throws InvalidKeyException, NoSuchAlgorithmException {
        SECRET_KEY = getConfiguration().getCyberSourceSecretKey().get(getUserProfile().getPropertyValue(USER_COUNTRY));
        vlogDebug("Key Used to verify signature:" + SECRET_KEY + EMPTY_STRING, SECRET_KEY);
        return sign(buildDataToSign(params), SECRET_KEY);
    }

    /**
     * Method to sign data using secret key passed.
     * 
     * @param data
     * @param secretKey
     * @return
     * @throws InvalidKeyException
     * @throws NoSuchAlgorithmException
     */
    private String sign(String data, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), HMAC_SHA256);
        Mac mac = Mac.getInstance(HMAC_SHA256);
        mac.init(secretKeySpec);
        byte[] rawHmac = mac.doFinal(data.getBytes());
        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encodeBuffer(rawHmac).trim();
    }

    /**
     * Method to build data for signing.
     * 
     * @param params
     * @return
     */
    private String buildDataToSign(HashMap params) {
        String[] signedFieldNames = String.valueOf(params.get(SIGNED_FIELD_NAME)).split(COMMA);
        ArrayList<String> dataToSign = new ArrayList<String>();
        for (String signedFieldName : signedFieldNames) {
            dataToSign.add(signedFieldName + EQUAL_SIGN + String.valueOf(params.get(signedFieldName)));
        }

        vlogDebug("Data used for creating response signature:", dataToSign);
        return commaSeparate(dataToSign);
    }

    /**
     * Method to create comman separated data.
     * 
     * @param dataToSign
     * @return string value containing commma separated data
     */
    private String commaSeparate(ArrayList<String> dataToSign) {
        StringBuilder csv = new StringBuilder();
        for (Iterator<String> it = dataToSign.iterator(); it.hasNext();) {
            csv.append(it.next());
            if (it.hasNext()) {
                csv.append(COMMA);
            }
        }
        return csv.toString();
    }

    /**
     * This method validates pCardType passed and return card name.
     * 
     * @param pCardType
     *            - Holds the card type.
     * @return - Retruns the card name.
     */
    private String findCardName(String pCardType) {
        String cardName = null;
        String cardType = validateAndSetString(pCardType, ZERO);

        switch (Integer.valueOf(cardType).intValue()) {
            case 1:
                cardName = VISA;
                break;
            case 2:
                cardName = MC;
                break;
            case 3:
                cardName = AMEX;
                break;
            case 4:
                cardName = DISC;
                break;
            case 5:
                cardName = DINR;
                break;
            case 7:
                cardName = JCB;
                break;
            default:
                cardName = UNKNOWN;
                break;
        }

        return cardName;
    }
    /**
     * This method checks whether card expiry date is prior to the selected Subscription End Date and returns flag
     * 
     * @return creditCardExpireBeforeEndDate
     */
	private boolean checkCardExpireBeforeEndDate(String cardExpDate) {
		String creditCardExpiryDate = null;
		Date expiryDate = null;
		boolean creditCardExpireBeforeEndDate = false;
		SimpleDateFormat dateFormater = new SimpleDateFormat(SubscriptionConstants.DATE_FORMAT_DDMMYYYY,
				Locale.ENGLISH);
		String countryCode = (String) getUserProfile().getPropertyValue(USERCOUNTRY);
		String converttoTimezone = getCountryUtils().getDefaultTimeZoneForCountry(countryCode);
		vlogDebug("Method constructDateMap Country Code of user {0} and timezone {1}", countryCode, converttoTimezone);
		TimeZone tzone = TimeZone.getTimeZone(converttoTimezone);
		Calendar calendarEndDate = Calendar.getInstance(tzone);
		calendarEndDate.add(Calendar.YEAR, 1);
		try {
			if (StringUtils.isNotBlank(cardExpDate)) {
				SimpleDateFormat expDateFormatter = new SimpleDateFormat(SubscriptionConstants.DATE_FORMAT_MMYYYY,
						Locale.ENGLISH);
				expiryDate = expDateFormatter
						.parse(SubscriptionConstants.ONE + SubscriptionConstants.HYPHEN + cardExpDate);
				Calendar cal = Calendar.getInstance();
				cal.setTime(expiryDate);
				vlogDebug("Expiry Date of Credit Card " + cal.getTime());
				cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
				creditCardExpiryDate = dateFormater.format(cal.getTime());
				vlogDebug("Expiry Date of Credit Card " + expiryDate);

			}
			String subscriptionEndDate = dateFormater.format(calendarEndDate.getTime());
			if (StringUtils.isNotBlank(subscriptionEndDate) && StringUtils.isNotBlank(creditCardExpiryDate)) {
				Date formattedEndDate = dateFormater.parse(subscriptionEndDate);
				Date cardExpireDate = dateFormater.parse(creditCardExpiryDate);
				if (cardExpireDate.before(formattedEndDate)) {
					creditCardExpireBeforeEndDate = SubscriptionConstants.BOOLEAN_TRUE;
				}
			}
		} catch (ParseException e) {
			vlogError("ParseException", e);
		}
		return creditCardExpireBeforeEndDate;
	}

    /**
     * This method validates pMainString passed and return same string if it is not NULL or empty, else return the
     * pReplaceString passed.
     * 
     * @param pMainString
     *            - Holds the main string.
     * @param pReplaceString
     *            - Holds the replace string.
     * @return - Retruns the final string.
     */
    private String validateAndSetString(String pMainString, String pReplaceString) {
        String finalString = pReplaceString;

        if (StringUtils.isNotBlank(pMainString)) {
            finalString = pMainString;
        }

        return finalString;
    }

    /**
     * Gets the value of property configuration
     *
     * @return the value of property configuration
     */
    public AgilentConfiguration getConfiguration() {
        return mConfiguration;
    }
    /**
     * Sets the value of property configuration with value pConfiguration
     *
     * @param pConfiguration
     *            for setting property configuration
     */
    public void setConfiguration(AgilentConfiguration pConfiguration) {
        mConfiguration = pConfiguration;
    }

    /**
     * Gets the value of property userProfile
     *
     * @return the value of property userProfile
     */
    public Profile getUserProfile() {
        return mUserProfile;
    }
    /**
     * Sets the value of property userProfile with value pUserProfile
     *
     * @param pUserProfile
     *            for setting property userProfile
     */
    public void setUserProfile(Profile pUserProfile) {
        mUserProfile = pUserProfile;
    }

    /**
     * Gets the value of property defaultCountry
     *
     * @return the value of property defaultCountry
     */
    public String getDefaultCountry() {
        return mDefaultCountry;
    }
    /**
     * Sets the value of property defaultCountry with value pDefaultCountry
     *
     * @param pDefaultCountry
     *            for setting property defaultCountry
     */
    public void setDefaultCountry(String pDefaultCountry) {
        mDefaultCountry = pDefaultCountry;
    }

    /**
     * Gets the value of property customResponseMap
     *
     * @return the value of property customResponseMap
     */
    public Map<String, String> getCustomResponseMap() {
        return mCustomResponseMap;
    }
    /**
     * Sets the value of property customResponseMap with value pCustomResponseMap
     *
     * @param pCustomResponseMap
     *            for setting property customResponseMap
     */
    public void setCustomResponseMap(Map<String, String> pCustomResponseMap) {
        mCustomResponseMap = pCustomResponseMap;
    }
    
    /**
     * Gets the value of property configurationSecond
     *
     * @return the value of property configurationSecond
     */
    public AgilentConfigurationSecond getConfigurationSecond() {
        return mConfigurationSecond;
    }

    /**
     * Sets the value of property configurationSecond with value pConfigurationSecond
     *
     * @param pConfigurationSecond
     *            for setting property configurationSecond
     */
    public void setConfigurationSecond(AgilentConfigurationSecond pConfigurationSecond) {
        mConfigurationSecond = pConfigurationSecond;
    }
    
    /**
     * Gets the value of property mSessionBean
     *
     * @return the value of property mSessionBean
     */
    public SessionBean getSessionBean() {
        return mSessionBean;
    }
    /**
     * Sets the value of property mSessionBean with value pSessionBean
     *
     * @param pSessionBean
     *            for setting property mSessionBean
     */
    public void setSessionBean(SessionBean pSessionBean) {
        mSessionBean = pSessionBean;
    }
    /**
     * Gets the value of property mInternationalizationService
     *
     * @return the value of property mInternationalizationService
     */
    public InternationalizationService getInternationalizationService() {
        return mInternationalizationService;
    }
    /**
     * Sets the value of property mInternationalizationService with value pInternationalizationService
     *
     * @param pInternationalizationService
     *            for setting property mInternationalizationService
     */
    public void setInternationalizationService(InternationalizationService pInternationalizationService) {
        mInternationalizationService = pInternationalizationService;
    }
    public AgilentConfigurationSecond getAgilentConfigurationSecond() {
        return mAgilentConfigurationSecond;
    }

    public void setAgilentConfigurationSecond(AgilentConfigurationSecond agilentConfigurationSecond) {
        this.mAgilentConfigurationSecond = agilentConfigurationSecond;
    }

	public ChinaConfiguration getChinaConfiguration() {
		return mChinaConfiguration;
	}

	public void setChinaConfiguration(ChinaConfiguration pChinaConfiguration) {
		this.mChinaConfiguration = pChinaConfiguration;
	}

	public CountryUtils getCountryUtils() {
		return mCountryUtils;
	}

	public void setCountryUtils(CountryUtils mCountryUtils) {
		this.mCountryUtils = mCountryUtils;
	}
}
