package com.agilent.commonstore.crm.bean;

import com.agilent.base.platform.util.AgilentAddressVO;

public class ContractHistoryBean {

	
	private String contractId;
	private String encyContractId;
	private String name;
	private String subscriptionStartDate;
	private String subscriptionEndDate;
	private String renewalID;
	private String encyptRenewalID;
	private String status;
	private int totalQuotes;
	private String statusMessage;
	private boolean renewStatus;
	private boolean coverageButton = false; 
	private boolean activeContractFlag = false;
	private boolean expiringContractFlag =false;
	private boolean reviewQuoteAndexpMessg =false;
	private int expiringDays;
	private boolean mExpiringInFlag=false;
	private AgilentAddressVO address = new AgilentAddressVO();
	private String mExpContractId;
	private String encyptExpContractId;
	private String mNewContractId;
	private String encyptNewContractId;
	private String mNewContractDate;
	private Boolean mDisplayFlag =false;
	private String mContactName;

	private String mContactEmail;
	private String mContactPhone;
	private String mContactCountry;
	private String mContactRegion;
	private String mSalesName;
	private String mSalesPhone;
	private String mSalesEmail;
	private String quoteId;
	private String mErrorMsg=null;
	//Added as part of Lynx Phase2 Story - DCCOM-35 - To set Account Id 
	private String mPartnerAccountId;
	
	private String mProcessTypeContract;	
	private String mContractStatus;	
	private String mRepairOrderStatus;	
	private boolean mAutoRenewFlag;
	private String mPurchaseOrderNum;
	private boolean mDisplayOldContractId=true;
	private String mContractCreationDate;
	private String mPreProcessType;
		
	private String mAdjustedQuoteId;
	private String mEncryptedAdjustedQuoteId;
	private String mOriginalQuoteId;
	private String mEncryptedOriginalQuoteId;
    private String mContractGrossValue;
    private String mContractNetValue;
    private String mQuoteValidDate;
    private boolean mAddOnQuote;

    public boolean isAddOnQuote() {
        return mAddOnQuote;
    }

    public void setAddOnQuote(boolean pAddOnQuote) {
        mAddOnQuote = pAddOnQuote;
    }

    /**
	 * @return the errorMsg
	 */
	public String getErrorMsg() {
		return mErrorMsg;
	}
	
	/**
	 * @param errorMsg the errorMsg to set
	 */
	public void setErrorMsg(String errorMsg) {
		mErrorMsg = errorMsg;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}
	
	public boolean isActiveContractFlag() {
		return activeContractFlag;
	}
	public void setActiveContractFlag(boolean activeContractFlag) {
		this.activeContractFlag = activeContractFlag;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public AgilentAddressVO getAddress() {
		return address;
	}
	public void setAddress(AgilentAddressVO address) {
		this.address = address;
	}

	public String getSubscriptionStartDate() {
		return subscriptionStartDate;
	}
	public void setSubscriptionStartDate(String mSubscriptionStartDate) {
		subscriptionStartDate = mSubscriptionStartDate;
	}
	public String getSubscriptionEndDate() {
		return subscriptionEndDate;
	}
	public void setSubscriptionEndDate(String mSubscriptionEndDate) {
		subscriptionEndDate = mSubscriptionEndDate;
	}
	public boolean isRenewStatus() {
		return renewStatus;
	}
	public void setRenewStatus(boolean renewStatus) {
		this.renewStatus = renewStatus;
	}
	public boolean isCoverageButton() {
		return coverageButton;
	}
	public void setCoverageButton(boolean coverageButton) {
		this.coverageButton = coverageButton;
	}
	public boolean isExpiringContractFlag() {
		return expiringContractFlag;
	}
	public void setExpiringContractFlag(boolean expiringContractFlag) {
		this.expiringContractFlag = expiringContractFlag;
	}
	public String getEncyptRenewalID() {
		return encyptRenewalID;
	}
	public void setEncyptRenewalID(String encyptRenewalID) {
		this.encyptRenewalID = encyptRenewalID;
	}
	public String getEncyptExpContractId() {
		return encyptExpContractId;
	}
	public void setEncyptExpContractId(String encyptExpContractId) {
		this.encyptExpContractId = encyptExpContractId;
	}
	public String getEncyptNewContractId() {
		return encyptNewContractId;
	}
	public void setEncyptNewContractId(String encyptNewContractId) {
		this.encyptNewContractId = encyptNewContractId;
	}
	public boolean isReviewQuoteAndexpMessg() {
		return reviewQuoteAndexpMessg;
	}
	public void setReviewQuoteAndexpMessg(boolean reviewQuoteAndexpMessg) {
		this.reviewQuoteAndexpMessg = reviewQuoteAndexpMessg;
	}
	public int getExpiringDays() {
		return expiringDays;
	}
	public void setExpiringDays(int expiringDays) {
		this.expiringDays = expiringDays;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getTotalQuotes() {
		return totalQuotes;
	}
	public void setTotalQuotes(int totalQuotes) {
		this.totalQuotes = totalQuotes;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getRenewalID() {
		return renewalID;
	}
	public void setRenewalID(String mRenewalID) {
		renewalID = mRenewalID;
	}
	/**
	 * @return the expiringInFlag
	 */
	public boolean isExpiringInFlag() {
		return mExpiringInFlag;
	}
	/**
	 * @param pExpiringInFlag the expiringInFlag to set
	 */
	public void setExpiringInFlag(boolean pExpiringInFlag) {
		mExpiringInFlag = pExpiringInFlag;
	}
	public String getExpContractId() {
		return mExpContractId;
	}
	public void setExpContractId(String mExpContractId) {
		this.mExpContractId = mExpContractId;
	}
	public String getNewContractId() {
		return mNewContractId;
	}
	public void setNewContractId(String mNewContractId) {
		this.mNewContractId = mNewContractId;
	}
	public Boolean getDisplayFlag() {
		return mDisplayFlag;
	}
	public void setDisplayFlag(Boolean mDisplayFlag) {
		this.mDisplayFlag = mDisplayFlag;
	}
	public String getNewContractDate() {
		return mNewContractDate;
	}
	public void setNewContractDate(String mNewContractDate) {
		this.mNewContractDate = mNewContractDate;
	}
	public String getContactName() {
		return mContactName;
	}
	public void setContactName(String mContactName) {
		this.mContactName = mContactName;
	}
	public String getContactEmail() {
		return mContactEmail;
	}
	public void setContactEmail(String mContactEmail) {
		this.mContactEmail = mContactEmail;
	}
	public String getContactPhone() {
		return mContactPhone;
	}
	public void setContactPhone(String mContactPhone) {
		this.mContactPhone = mContactPhone;
	}
	public String getSalesName() {
		return mSalesName;
	}
	public void setSalesName(String mSalesName) {
		this.mSalesName = mSalesName;
	}
	public String getSalesPhone() {
		return mSalesPhone;
	}
	public void setSalesPhone(String mSalesPhone) {
		this.mSalesPhone = mSalesPhone;
	}
	public String getSalesEmail() {
		return mSalesEmail;
	}
	public void setSalesEmail(String mSalesEmail) {
		this.mSalesEmail = mSalesEmail;
	}
	public String getContactCountry() {
		return mContactCountry;
	}
	public void setContactCountry(String mContactCountry) {
		this.mContactCountry = mContactCountry;
	}
	public String getContactRegion() {
		return mContactRegion;
	}
	public void setContactRegion(String mContactRegion) {
		this.mContactRegion = mContactRegion;
	}
	public String getQuoteId() {
		return quoteId;
	}
	public void setQuoteId(String mQuoteId) {
		quoteId = mQuoteId;
	}
	public String getEncyContractId() {
		return encyContractId;
	}
	public void setEncyContractId(String encyContractId) {
		this.encyContractId = encyContractId;
	}
	
	/**
	 * @return the mPartnerAccountId
	 */
	public String getPartnerAccountId() {
		return mPartnerAccountId;
	}
	/**
	 * @param mPartnerAccountId the mPartnerAccountId to set
	 */
	public void setPartnerAccountId(String mPartnerAccountId) {
		this.mPartnerAccountId = mPartnerAccountId;
	}
	/**
	 * @return the mProcessTypeContract
	 */
	
	public String getProcessTypeContract() {
		return mProcessTypeContract;
	}

	/**
	 * @param mPartnerAccountId the mProcessTypeContract to set
	 */
	public void setProcessTypeContract(String mProcessTypeContract) {
		this.mProcessTypeContract = mProcessTypeContract;
	}
	
	/**
	 * @return the mContractStatus
	 */

	public String getContractStatus() {
		return mContractStatus;
	}

	/**
	 * @param mContractStatus the mContractStatus to set
	 */
	public void setContractStatus(String mContractStatus) {
		this.mContractStatus = mContractStatus;
	}
	
	/**
	 * @return the mRepairOrderStatus
	 */

	public String getRepairOrderStatus() {
		return mRepairOrderStatus;
	}
	
	/**
	 * @param mRepairOrderStatus the mRepairOrderStatus to set
	 */

	public void setRepairOrderStatus(String mRepairOrderStatus) {
		this.mRepairOrderStatus = mRepairOrderStatus;
	}
	
	/**
	 * @return the mAutoRenewFlag
	 */
	public boolean isAutoRenewFlag() {
		return mAutoRenewFlag;
	}
	
	/**
	 * @param pAutoRenewFlag the mAutoRenewFlag to set
	 */

	public void setAutoRenewFlag(boolean pAutoRenewFlag) {
		this.mAutoRenewFlag = pAutoRenewFlag;
	}
    
	public String getPurchaseOrderNum() {
		return mPurchaseOrderNum;
	}

	public void setPurchaseOrderNum(String pPurchaseOrderNum) {
		this.mPurchaseOrderNum = pPurchaseOrderNum;
	}
	

    /**
     * Gets the value of property displayOldContractId
     *
     * @return the value of property displayOldContractId
     */
    public boolean isDisplayOldContractId() {
        return mDisplayOldContractId;
    }

    /**
     * Sets the value of property displayOldContractId with value pDisplayOldContractId
     *
     * @param pDisplayOldContractId
     *            for setting property displayOldContractId
     */
    public void setDisplayOldContractId(boolean pDisplayOldContractId) {
        mDisplayOldContractId = pDisplayOldContractId;
    }
		
    

    /**
     * Gets the value of property contractCreationDate
     *
     * @return the value of property contractCreationDate
     */
    public String getContractCreationDate() {
        return mContractCreationDate;
    }

    /**
     * Sets the value of property contractCreationDate with value pContractCreationDate
     *
     * @param pContractCreationDate
     *            for setting property contractCreationDate
     */
    public void setContractCreationDate(String pContractCreationDate) {
        mContractCreationDate = pContractCreationDate;
    }
	

    @Override
	public String toString() {
		return "ContractHistoryBean [contractId=" + contractId + ", encyContractId=" + encyContractId + ", name=" + name
		        + ", subscriptionStartDate=" + subscriptionStartDate + ", subscriptionEndDate=" + subscriptionEndDate
                + ", renewalID=" + renewalID + ", encyptRenewalID=" + encyptRenewalID + ", status=" + status
                + ", totalQuotes=" + totalQuotes + ", statusMessage=" + statusMessage + ", renewStatus=" + renewStatus
                + ", coverageButton=" + coverageButton + ", activeContractFlag=" + activeContractFlag
                + ", expiringContractFlag=" + expiringContractFlag + ", reviewQuoteAndexpMessg="
                + reviewQuoteAndexpMessg + ", expiringDays=" + expiringDays + ", mExpiringInFlag=" + mExpiringInFlag
                + ", address=" + address + ", mExpContractId=" + mExpContractId + ", encyptExpContractId="
                + encyptExpContractId + ", mNewContractId=" + mNewContractId + ", encyptNewContractId="
                + encyptNewContractId + ", mNewContractDate=" + mNewContractDate + ", mDisplayFlag=" + mDisplayFlag
                + ", mContactName=" + mContactName + ", mContactEmail=" + mContactEmail + ", mContactPhone="
                + mContactPhone + ", mContactCountry=" + mContactCountry + ", mContactRegion=" + mContactRegion
                + ", mSalesName=" + mSalesName + ", mSalesPhone=" + mSalesPhone + ", mSalesEmail=" + mSalesEmail
                + ", quoteId=" + quoteId + ", mErrorMsg=" + mErrorMsg + ", mPartnerAccountId=" + mPartnerAccountId
                + ", mProcessTypeContract=" + mProcessTypeContract + ", mContractStatus=" + mContractStatus
                + ", mRepairOrderStatus=" + mRepairOrderStatus + ", mAutoRenewFlag=" + mAutoRenewFlag
                + ", mPurchaseOrderNum=" + mPurchaseOrderNum + ",mDisplayOldContractId=" + mDisplayOldContractId + "]";
	}

    public String getAdjustedQuoteId() {
        return mAdjustedQuoteId;
    }

    public void setAdjustedQuoteId(String pAdjustedQuoteId) {
        mAdjustedQuoteId = pAdjustedQuoteId;
    }

    public String getEncryptedAdjustedQuoteId() {
        return mEncryptedAdjustedQuoteId;
    }

    public void setEncryptedAdjustedQuoteId(String pEncryptedAdjustedQuoteId) {
        mEncryptedAdjustedQuoteId = pEncryptedAdjustedQuoteId;
    }

    public String getOriginalQuoteId() {
        return mOriginalQuoteId;
    }

    public void setOriginalQuoteId(String pOriginalQuoteId) {
        mOriginalQuoteId = pOriginalQuoteId;
    }

    public String getEncryptedOriginalQuoteId() {
        return mEncryptedOriginalQuoteId;
    }

    public void setEncryptedOriginalQuoteId(String pEncryptedOriginalQuoteId) {
        mEncryptedOriginalQuoteId = pEncryptedOriginalQuoteId;
    }

    /**
     * Gets the value of property contractGrossValue
     *
     * @return the value of property contractGrossValue
     */
    public String getContractGrossValue() {
        return mContractGrossValue;
    }

    /**
     * Sets the value of property contractGrossValue with value pContractGrossValue
     *
     * @param pContractGrossValue
     *            for setting property contractGrossValue
     */
    public void setContractGrossValue(String pContractGrossValue) {
        mContractGrossValue = pContractGrossValue;
    }

    /**
     * Gets the value of property contractNetValue
     *
     * @return the value of property contractNetValue
     */
    public String getContractNetValue() {
        return mContractNetValue;
    }

    /**
     * Sets the value of property contractNetValue with value pContractNetValue
     *
     * @param pContractNetValue
     *            for setting property contractNetValue
     */
    public void setContractNetValue(String pContractNetValue) {
        mContractNetValue = pContractNetValue;
    }

    /**
     * Gets the value of property quoteValidDate
     *
     * @return the value of property quoteValidDate
     */
    public String getQuoteValidDate() {
        return mQuoteValidDate;
    }

    /**
     * Sets the value of property quoteValidDate with value pQuoteValidDate
     *
     * @param pQuoteValidDate
     *            for setting property quoteValidDate
     */
    public void setQuoteValidDate(String pQuoteValidDate) {
        mQuoteValidDate = pQuoteValidDate;
    }

	/**
	 * @return the preProcessType
	 */
	public String getPreProcessType() {
		return this.mPreProcessType;
	}

	/**
	 * @param pPreProcessType the preProcessType to set
	 */
	public void setPreProcessType(String pPreProcessType) {
		this.mPreProcessType = pPreProcessType;
	}

    

}
