package com.agilent.commonstore.crm.bean;

import java.util.Date;


public class CrmContractFormBean {
	
	private String mName;
	private String mPhoneNumber;
	private String mEmail;
	private String mContactMethod;
	private String mCrmEnquiry;
	private String mMessage;
	private String mContractId;
	private String mQuoteId;
	private String mSalesName;
	private String mSalesEmail;
	private String mContactCountry;
	private String mContactRegion;
	private String mContactDate;
	
	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return mName;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		mName = name;
	}
	/**
	 * @return the phoneNumber
	 */
	public String getPhoneNumber() {
		return mPhoneNumber;
	}
	/**
	 * @param phoneNumber the phoneNumber to set
	 */
	public void setPhoneNumber(String phoneNumber) {
		mPhoneNumber = phoneNumber;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return mEmail;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		mEmail = email;
	}
	/**
	 * @return the contactMethod
	 */
	public String getContactMethod() {
		return mContactMethod;
	}
	/**
	 * @param contactMethod the contactMethod to set
	 */
	public void setContactMethod(String contactMethod) {
		mContactMethod = contactMethod;
	}
	/**
	 * @return the crmEnquiry
	 */
	public String getCrmEnquiry() {
		return mCrmEnquiry;
	}
	/**
	 * @param crmEnquiry the crmEnquiry to set
	 */
	public void setCrmEnquiry(String crmEnquiry) {
		mCrmEnquiry = crmEnquiry;
	}
	/**
	 * @return the message
	 */
	public String getMessage() {
		return mMessage;
	}
	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		mMessage = message;
	}
	/**
	 * @return the contactDate
	 */
	
	public String getContractId() {
		return mContractId;
	}


	public void setContractId(String mContractId) {
		this.mContractId = mContractId;
	}
	public String getContactDate() {
		return mContactDate;
	}
	public void setContactDate(String mContactDate) {
		this.mContactDate = mContactDate;
	}
	public String getQuoteId() {
		return mQuoteId;
	}
	public void setQuoteId(String mQuoteId) {
		this.mQuoteId = mQuoteId;
	}
	public String getSalesName() {
		return mSalesName;
	}
	public void setSalesName(String mSalesName) {
		this.mSalesName = mSalesName;
	}
	public String getSalesEmail() {
		return mSalesEmail;
	}
	public void setSalesEmail(String mSalesEmail) {
		this.mSalesEmail = mSalesEmail;
	}
	public String getContactCountry() {
		return mContactCountry;
	}
	public void setContactCountry(String mContactCountry) {
		this.mContactCountry = mContactCountry;
	}
	public String getContactRegion() {
		return mContactRegion;
	}
	public void setContactRegion(String mContactRegion) {
		this.mContactRegion = mContactRegion;
	}
	
	
	
	
}
