package com.agilent.commonstore.crm.bean;

public class InstrumentDetailsBean {

    private String instrumentId;
    private String instrumentName;
    private String opportunityId;
    private String expiredDate;
    private String price;
    
    public String getInstrumentId() {
        return instrumentId;
    }
    public void setInstrumentId(String pInstrumentId) {
        instrumentId = pInstrumentId;
    }
    public String getInstrumentName() {
        return instrumentName;
    }
    public void setInstrumentName(String pInstrumentName) {
        instrumentName = pInstrumentName;
    }
    public String getOpportunityId() {
        return opportunityId;
    }
    public void setOpportunityId(String pOpportunityId) {
        opportunityId = pOpportunityId;
    }
    public String getExpiredDate() {
        return expiredDate;
    }
    public void setExpiredDate(String pExpiredDate) {
        expiredDate = pExpiredDate;
    }
    public String getPrice() {
        return price;
    }
    public void setPrice(String pPrice) {
        price = pPrice;
    }
    
}
