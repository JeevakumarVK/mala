package com.agilent.commonstore.crm.bean;

import java.util.Date;

import com.agilent.base.platform.util.AgilentAddressVO;

public class NewAspenQuoteBean {

	private String mContactId;
	private String mSoldTo;
	private String mQuoteId;
	private String mProcessTypeContract;
	private String mQuoteGuid;
	private String mQuoteValidFrom;
	private String mQuoteValidTo;
	private String mContractRenewed;
	private String mQuoteStatus;
	private String mPartnerNo;
	private String mPartnerFct;
	
	private String mContactName;
	private String mContactEmail;
	private String mContactPhone;
	private String mContactStreet;
	private String mContactCity;
	private String mContactCountry;
	private String mContactRegion;
	private String mContactPostCode;
	private String mSalesName;
	private String mSalesPhone;
	private String mSalesEmail;
	private String mErrorMsg=null;
	
	private String mName;
	private String mAddrNo;
	private String mHouseNum;
	private String mEncQuoteId;
	private int mExpiringDays;
	private String mStatusMessage;
	private String mQuoteCreationDate;
	private String mCreatedByWeb;
	private String mAdjustedQuoteId;
	private String mEncryptedAdjustedQuoteId;
    private String mOriginalQuoteId;
    private String mEncryptedOriginalQuoteId;
    private boolean mWarrantyQuote;
    private Date mCreatedOnDate;
    private boolean mAddOnQuote;
	
    private AgilentAddressVO mAddress = new AgilentAddressVO();
	
	
	public String getContactId() {
		return mContactId;
	}
	public void setContactId(String contactId) {
		this.mContactId = contactId;
	}
	public String getSoldTo() {
		return mSoldTo;
	}
	public void setSoldTo(String soldTo) {
		this.mSoldTo = soldTo;
	}
	public String getQuoteId() {
		return mQuoteId;
	}
	public void setQuoteId(String quoteId) {
		this.mQuoteId = quoteId;
	}
	public String getProcessTypeContract() {
		return mProcessTypeContract;
	}
	public void setProcessTypeContract(String processTypeContract) {
		this.mProcessTypeContract = processTypeContract;
	}
	public String getQuoteGuid() {
		return mQuoteGuid;
	}
	public void setQuoteGuid(String quoteGuid) {
		this.mQuoteGuid = quoteGuid;
	}
	public String getQuoteValidFrom() {
		return mQuoteValidFrom;
	}
	public void setQuoteValidFrom(String quoteValidFrom) {
		this.mQuoteValidFrom = quoteValidFrom;
	}
	public String getQuoteValidTo() {
		return mQuoteValidTo;
	}
	public void setQuoteValidTo(String quoteValidTo) {
		this.mQuoteValidTo = quoteValidTo;
	}
	public String getContractRenewed() {
		return mContractRenewed;
	}
	public void setContractRenewed(String contractRenewed) {
		this.mContractRenewed = contractRenewed;
	}
	public String getQuoteStatus() {
		return mQuoteStatus;
	}
	public void setQuoteStatus(String quoteStatus) {
		this.mQuoteStatus = quoteStatus;
	}
	public String getPartnerNo() {
		return mPartnerNo;
	}
	public void setPartnerNo(String partnerNo) {
		this.mPartnerNo = partnerNo;
	}
	public String getPartnerFct() {
		return mPartnerFct;
	}
	public void setPartnerFct(String partnerFct) {
		this.mPartnerFct = partnerFct;
	}
	public String getName() {
		return mName;
	}
	public void setName(String name) {
		this.mName = name;
	}
	public String getAddrNo() {
		return mAddrNo;
	}
	public void setAddrNo(String addrNo) {
		this.mAddrNo = addrNo;
	}
	public String getHouseNum() {
		return mHouseNum;
	}
	public void setHouseNum(String houseNum) {
		this.mHouseNum = houseNum;
	}
	public String getEncQuoteId() {
		return mEncQuoteId;
	}
	public void setEncQuoteId(String encQuoteId) {
		this.mEncQuoteId = encQuoteId;
	}
	public String getContactName() {
		return mContactName;
	}
	public void setContactName(String contactName) {
		this.mContactName = contactName;
	}
	public String getContactPhone() {
		return mContactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.mContactPhone = contactPhone;
	}
	public String getContactStreet() {
		return mContactStreet;
	}
	public void setContactStreet(String contactStreet) {
		this.mContactStreet = contactStreet;
	}
	public String getContactCity() {
		return mContactCity;
	}
	public void setContactCity(String contactCity) {
		this.mContactCity = contactCity;
	}
	public String getContactCountry() {
		return mContactCountry;
	}
	public void setContactCountry(String contactCountry) {
		this.mContactCountry = contactCountry;
	}
	public String getContactRegion() {
		return mContactRegion;
	}
	public void setContactRegion(String contactRegion) {
		this.mContactRegion = contactRegion;
	}
	public String getContactPostCode() {
		return mContactPostCode;
	}
	public void setContactPostCode(String contactPostCode) {
		this.mContactPostCode = contactPostCode;
	}
	public String getSalesName() {
		return mSalesName;
	}
	public void setSalesName(String salesName) {
		this.mSalesName = salesName;
	}
	public String getSalesPhone() {
		return mSalesPhone;
	}
	public void setSalesPhone(String salesPhone) {
		this.mSalesPhone = salesPhone;
	}
	public String getSalesEmail() {
		return mSalesEmail;
	}
	public void setSalesEmail(String salesEmail) {
		this.mSalesEmail = salesEmail;
	}
	public String getErrorMsg() {
		return mErrorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.mErrorMsg = errorMsg;
	}
	public String getContactEmail() {
		return mContactEmail;
	}
	public void setContactEmail(String contactEmail) {
		this.mContactEmail = contactEmail;
	}
	
	public int getExpiringDays() {
		return mExpiringDays;
	}
	public void setExpiringDays(int expiringDays) {
		this.mExpiringDays = expiringDays;
	}
	public AgilentAddressVO getAddress() {
		return mAddress;
	}
	public void setmAddress(AgilentAddressVO address) {
		this.mAddress = address;
	}
	public String getStatusMessage() {
		return mStatusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.mStatusMessage = statusMessage;
	}
	/**
     * Gets the value of property quoteCreationDate
     *
     * @return the value of property quoteCreationDate
     */
    public String getQuoteCreationDate() {
        return mQuoteCreationDate;
    }
    /**
     * Sets the value of property quoteCreationDate with value pQuoteCreationDate
     *
     * @param pQuoteCreationDate
     *            for setting property quoteCreationDate
     */
    public void setQuoteCreationDate(String pQuoteCreationDate) {
        mQuoteCreationDate = pQuoteCreationDate;
    }
    
  
    /**
     * Sets the value of property mCreatedByWeb with value pCreatedByWeb
     *
     * @param pQuoteCreationDate
     *            for setting property mCreatedByWeb
     */
   

	public void setCreatedByWeb(String pCreatedByWeb) {
		this.mCreatedByWeb = pCreatedByWeb;
	}

	
	/**
     * Gets the value of property mCreatedByWeb
     *
     * @return the value of property mCreatedByWeb
     */
    
    
    public String getCreatedByWeb() {
		return mCreatedByWeb;
	}
    public String getAdjustedQuoteId() {
        return mAdjustedQuoteId;
    }
    public void setAdjustedQuoteId(String pAdjustedQuoteId) {
        mAdjustedQuoteId = pAdjustedQuoteId;
    }
    public String getOriginalQuoteId() {
        return mOriginalQuoteId;
    }
    public void setOriginalQuoteId(String pOriginalQuoteId) {
        mOriginalQuoteId = pOriginalQuoteId;
    }
    public String getEncryptedOriginalQuoteId() {
        return mEncryptedOriginalQuoteId;
    }
    public void setEncryptedOriginalQuoteId(String pEncryptedOriginalQuoteId) {
        mEncryptedOriginalQuoteId = pEncryptedOriginalQuoteId;
    }
    public String getEncryptedAdjustedQuoteId() {
        return mEncryptedAdjustedQuoteId;
    }
    public void setEncryptedAdjustedQuoteId(String pEncryptedAdjustedQuoteId) {
        mEncryptedAdjustedQuoteId = pEncryptedAdjustedQuoteId;
    }
	public boolean isWarrantyQuote() {
		return mWarrantyQuote;
	}
	public void setWarrantyQuote(boolean pWarrantyQuote) {
		this.mWarrantyQuote = pWarrantyQuote;	
	}
    public Date getCreatedOnDate() {
        return mCreatedOnDate;
    }
    public void setCreatedOnDate(Date pCreatedOnDate) {
        mCreatedOnDate = pCreatedOnDate;
    }
    
    public boolean isAddOnQuote() {
        return mAddOnQuote;
    }

    public void setAddOnQuote(boolean pAddOnQuote) {
        mAddOnQuote = pAddOnQuote;
    }
}
