/**
 * @author avneetkaur.m
 * @project Agilent.ServiceRequest
 * 
 */
package com.agilent.commonstore.crm.bean;

public class ServiceRequestBean {
	
	private String mCompanyName;
	private String mSiteAddress;
	private String mModelNo;
	private String mCustomerTag;
	private String mServiceReqNo;
	private String mServiceOrderNo;
	private String mContactName;
	private String mSrNotes;
	private String mSrCreatedDate;
	private String mServiceEngineer;
	private String mCommittedDate;
	private String mErrorMsg=null;
	
	/**
	 * @return the mCompanyName
	 */
	public String getCompanyName() {
		return mCompanyName;
	}
	/**
	 * @param mCompanyName the mCompanyName to set
	 */
	public void setCompanyName(String mCompanyName) {
		this.mCompanyName = mCompanyName;
	}
	/**
	 * @return the mSiteAddress
	 */
	public String getSiteAddress() {
		return mSiteAddress;
	}
	/**
	 * @param mSiteAddress the mSiteAddress to set
	 */
	public void setSiteAddress(String mSiteAddress) {
		this.mSiteAddress = mSiteAddress;
	}
	/**
	 * @return the mModelNo
	 */
	public String getModelNo() {
		return mModelNo;
	}
	/**
	 * @param mModelNo the mModelNo to set
	 */
	public void setModelNo(String mModelNo) {
		this.mModelNo = mModelNo;
	}
	/**
	 * @return the mCustomerTag
	 */
	public String getCustomerTag() {
		return mCustomerTag;
	}
	/**
	 * @param mCustomerTag the mCustomerTag to set
	 */
	public void setCustomerTag(String mCustomerTag) {
		this.mCustomerTag = mCustomerTag;
	}
	/**
	 * @return the mServiceReqNo
	 */
	public String getServiceReqNo() {
		return mServiceReqNo;
	}
	/**
	 * @param mServiceReqNo the mServiceReqNo to set
	 */
	public void setServiceReqNo(String mServiceReqNo) {
		this.mServiceReqNo = mServiceReqNo;
	}
	/**
	 * @return the mServiceOrderNo
	 */
	public String getServiceOrderNo() {
		return mServiceOrderNo;
	}
	/**
	 * @param mServiceOrderNo the mServiceOrderNo to set
	 */
	public void setServiceOrderNo(String mServiceOrderNo) {
		this.mServiceOrderNo = mServiceOrderNo;
	}
	/**
	 * @return the mContactName
	 */
	public String getContactName() {
		return mContactName;
	}
	/**
	 * @param mContactName the mContactName to set
	 */
	public void setContactName(String mContactName) {
		this.mContactName = mContactName;
	}
	/**
	 * @return the mSrNotes
	 */
	public String getSrNotes() {
		return mSrNotes;
	}
	/**
	 * @param mSrNotes the mSrNotes to set
	 */
	public void setSrNotes(String mSrNotes) {
		this.mSrNotes = mSrNotes;
	}
	/**
	 * @return the mSrCreatedDate
	 */
	public String getSrCreatedDate() {
		return mSrCreatedDate;
	}
	/**
	 * @param mSrCreatedDate the mSrCreatedDate to set
	 */
	public void setSrCreatedDate(String mSrCreatedDate) {
		this.mSrCreatedDate = mSrCreatedDate;
	}
	/**
	 * @return the mServiceEngineer
	 */
	public String getServiceEngineer() {
		return mServiceEngineer;
	}
	/**
	 * @param mServiceEngineer the mServiceEngineer to set
	 */
	public void setServiceEngineer(String mServiceEngineer) {
		this.mServiceEngineer = mServiceEngineer;
	}
	/**
	 * @return the mCommittedDate
	 */
	public String getCommittedDate() {
		return mCommittedDate;
	}
	/**
	 * @param mCommittedDate the mCommittedDate to set
	 */
	public void setCommittedDate(String mCommittedDate) {
		this.mCommittedDate = mCommittedDate;
	}
	/**
	 * @return the mErrorMsg
	 */
	public String getErrorMsg() {
		return mErrorMsg;
	}
	/**
	 * @param mErrorMsg the mErrorMsg to set
	 */
	public void setErrorMsg(String mErrorMsg) {
		this.mErrorMsg = mErrorMsg;
	}

}
