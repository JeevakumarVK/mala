/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.checkout.formhandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.http.client.ClientProtocolException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.droplets.bean.ForwardQuoteDetails;
import com.agilent.base.commerce.formhandlers.AgilentCommitOrderFormHandler;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.CyberSourcePaymentGroup;
import com.agilent.base.commerce.order.FlexibleSpendPlanPaymentGroup;
import com.agilent.base.commerce.order.PurchaseOrderPaymentGroup;
import com.agilent.base.commerce.payment.CyberSourcePaymentStatusImpl;
import com.agilent.base.commerce.quote.QuoteManager;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.SAPUser;
import com.agilent.base.crm.bean.ReviewQuoteDetailsInfo;
import com.agilent.base.crm.bean.ReviewQuotesBean;
import com.agilent.base.platform.IErrorId;
import com.agilent.base.platform.ValidationExceptions;
import com.agilent.base.platform.util.AgilentAddressVO;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.pricing.AgilentItemPriceInfo;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.base.rest.lms.RestClient;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;
import com.agilent.i18n.service.InternationalizationService;

import atg.commerce.CommerceException;
import atg.commerce.order.CommerceItem;
import atg.commerce.order.DuplicateShippingGroupException;
import atg.commerce.order.ElectronicShippingGroup;
import atg.commerce.order.HardgoodShippingGroup;
import atg.commerce.order.InvalidParameterException;
import atg.commerce.order.PaymentGroup;
import atg.commerce.pricing.ItemPriceInfo;
import atg.commerce.pricing.OrderPriceInfo;
import atg.commerce.states.OrderStates;
import atg.commerce.states.StateDefinitions;
import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.ServletUtil;
import atg.userprofiling.Profile;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;

/**
 * This class is used for processing service contract orders.
 */
public class AgilentCRMCommitOrderFormHandler extends AgilentCommitOrderFormHandler {

    private String renewContract;
    private String preventiveMaintenanceMonth;
    private String contractNo;
    private String renewContractSuccessURL;
    private String renewContractErrorURL;
    private AgilentOrder webOrder;
    private boolean isPayWithCC;
    private boolean isPayWithPO;
    private String mCreditCardType;
    private String cvv;
    private String month;
    private String purchaseOrderNumber;
    //DCCOM-3129 Starts
    private String mInvoiceType;
    private String contractAutoRenew;
    private String autoRenewalCancelSuccessURL;
    private Double orderTotal;
    private String discountPercentage;
	private String fspPaymentErrorURL;
	private Map<String, String> submitRenewalOrderFailureErrorCodeMapping;
    private InternationalizationService internationalizationService;    
   
	private AgilentContractHistoryHelper agilentContractHistoryHelper;
	private AgilentConfigurationSecond mAgilentConfigurationSecond;
    private QuoteManager mQuoteManager;    
    private boolean forwardQuoteFlag;
	
	public AgilentContractHistoryHelper getAgilentContractHistoryHelper() {
		return agilentContractHistoryHelper;
	}

	public void setAgilentContractHistoryHelper(AgilentContractHistoryHelper agilentContractHistoryHelper) {
		this.agilentContractHistoryHelper = agilentContractHistoryHelper;
	}

	public String getAutoRenewalCancelSuccessURL() {
		return autoRenewalCancelSuccessURL;
	}

	public void setAutoRenewalCancelSuccessURL(String autoRenewalCancelSuccessURL) {
		this.autoRenewalCancelSuccessURL = autoRenewalCancelSuccessURL;
	}

	public String getContractAutoRenew() {
		return contractAutoRenew;
	}

	public void setContractAutoRenew(String contractAutoRenew) {
		this.contractAutoRenew = contractAutoRenew;
	}

	public String getInvoiceType() {
		return mInvoiceType;
	}

	public void setInvoiceType(String pInvoiceType) {
		this.mInvoiceType = pInvoiceType;
	}
	//DCCOM-3129 Ends
	
    private String purchaseOrderCCNumber;
    private String renewalOrderSuccessURL;
    private String renewalOrderErrorURL;
    private String selectedPaymentMethod;
    private List<String> paymentMethods;
    private AgilentCatalogTools agilentCatalogTools;
    private AgilentCatalogTools mCatalogTools;
    private String deliveryMethod;
    private String ccErrURL;
    private String contractID;
    private ElectronicShippingGroup shippingGroup;
    private SAPCRMAPIManager sapcrmapiManager;
    private RestClient restClient;
    private String paymentVerificationURL;
    private String subId;
    private StringBuilder redirectURL;
    private String sapOrderServiceValidationToken;
    private AgilentContractHistoryHelper agilentServiceHistoryHelper;
    private boolean isError;

    private TemplateEmailInfoImpl mAgilentCRMCSREmailTemplateInfo;
    private String mCrmOrderCSRMessageSubject;
    private String mCrmOrderMessageFrom;
    private double totalAmount = 0;
    private String mEmailIdCSRAgent;
    private TemplateEmailSender mCrmTemplateEmailSender;
    private EncryptDecryptHelper encryptDecryptHelper;
    private String mCyberSourceReturnMsg = null;

    // Changes for DCCOM-1027 starts
    private String customerName1;
    private String companyTaxCode1;
    private String address1;
    private String bankName1;
    private String bankAccount1;
    private String customerName2;
    private String city2;
    private String shippingAdrress2;
    private String postCode2;
    private String contactorName2;
    private String contactorPhNum2;
	private String invoiceEmail;
    // Changes for DCCOM-1027 starts
    private String mBillingFrequencyType;

    @SuppressWarnings("unused")
    public boolean handleRenewContract(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws CommerceException, ServletException, IOException {
        redirectURL = new StringBuilder();
        if (!getProfile().isTransient()) {
            List<ReviewQuotesBean> quoteBean = getSessionBean().getQuoteItems();
            if (quoteBean == null || quoteBean.isEmpty()) {
                quoteBean = getAgilentServiceHistoryHelper().fetchQuoteDetails(getQuoteId(), false, "");

            }
            for (ReviewQuotesBean quoteBeanInfo : quoteBean) {
                if (getPreventiveMaintenanceMonth() != null && !getPreventiveMaintenanceMonth().equalsIgnoreCase("0")) {
                    getSessionBean().setPreventiveMaintenanceMonth(getPreventiveMaintenanceMonth());
                }
                setError(false);
                redirectURL.append(getRenewContractSuccessURL());
            }
        } else {
            setError(true);
            vlogError("Profile Not Found", getProfile().getRepositoryId());
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.INVALID_USERNAME, new String[] {}, new Object[] {});
        }

        if (isError && redirectURL != null) {
            return checkFormRedirect(getRedirectURL().toString(), getRedirectURL().toString(), request, response);
        }
        return checkFormRedirect(getRedirectURL().toString(), getRedirectURL().toString(), request, response);
    }

    public boolean handleCommitContractOrder(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        try {
            Profile profile = (Profile) getProfile();
            if (profile.isTransient()) {
                vlogError("Profile Not Found", getProfile().getRepositoryId());
                ValidationExceptions validationExceptions = new ValidationExceptions();
                validationExceptions.addValidationError(IErrorId.INVALID_USERNAME, new String[] {}, new Object[] {});
                return checkFormRedirect("", getRenewalOrderErrorURL(), request, response);
            }
            if (getFormError()) {
                return checkFormRedirect("", getRenewalOrderErrorURL(), request, response);
            }
            commitContactOrder(profile, request);
        } catch (ValidationExceptions valExceptions) {
            getErrorHandler().handleValidationException(valExceptions, "renewal contract", this);
            return checkFormRedirect("", getRenewalOrderErrorURL(), request, response);
        }
        if (isError) {
        	  	if(request.getAttribute("fspPaymentError") != null  ){
        	  			Boolean  fspError = (Boolean) request.getAttribute("fspPaymentError");
        	  			if(fspError)
        	  				return true;
        	}
            return checkFormRedirect("", getRenewalOrderErrorURL(), request, response);
        }
        return checkFormRedirect(getRenewalOrderSuccessURL(), getRenewalOrderErrorURL(), request, response);
    }

    public boolean commitContactOrder(Profile profile, DynamoHttpServletRequest request) throws ValidationExceptions {
        String orderId = null;

        try {
            vlogDebug("QuoteId:: {0}", getQuoteId());
            vlogDebug("getContractID():: {0}", getContractID());
            vlogDebug("AutoRenew status ::{0}", getContractAutoRenew());
            if (getQuoteId() != null && !getQuoteId().isEmpty()) {
                String quoteID = getEncryptDecryptHelper().decrypt(getQuoteId(), "");
                setQuoteId(quoteID);
            }
            List<ReviewQuotesBean> reviewQuoteItems = getSessionBean().getQuoteItems();
            if (reviewQuoteItems == null) {
                SessionBean sessionBean = (SessionBean) request.resolveName("/com/agilent/profile/SessionBean");
                reviewQuoteItems = sessionBean.getQuoteItems();
            }
            vlogDebug("reviewQuoteItems:: {0}", reviewQuoteItems);
            List<LineItem> productLineItems = getCommerceItemDetails(request, reviewQuoteItems);
            if (!StringUtils.isEmpty(getSessionBean().getPreventiveMaintenanceMonth())) {
                setPreventiveMaintenanceMonth(getSessionBean().getPreventiveMaintenanceMonth());
            }
            vlogDebug("productLineItems:: {0}", productLineItems);
            if (!StringUtils.isEmpty(getQuoteId())) {
                String profileId = getProfile().getRepositoryId();
                AgilentOrder webOrder = (AgilentOrder) getOrderManager().createOrder(profileId);
                vlogDebug("webOrder created:: {0}", webOrder);
                orderId = webOrder.getId();
                webOrder.setQuoteId(getQuoteId());
                webOrder.setContractId(getContractID());
                webOrder.setOrderType("SAPCRM_ORDER");
                webOrder.setDescription("Quote No. " + getQuoteId());
                HashMap<String, String> pSpecialInstructionsMap = new HashMap<String, String>();
                pSpecialInstructionsMap.put(RENEWAL_CONTRACT_SPECIALINTRUCTIONS, "Contract No. " + getQuoteId());
                webOrder.setSpecialInstructions(pSpecialInstructionsMap);
                vlogDebug("orderId:: {0}", orderId);

                if (productLineItems == null) {
                    vlogError("Could find line items so did not process your order" + orderId);
                    ValidationExceptions validationExceptions = new ValidationExceptions();
                    validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
                }
                String orderHeaderInfo = "";
                double total = 0;
                int count = 1;
                for (LineItem item : productLineItems) {
                    CommerceItem commerceItem = getCommerceItemManager().createCommerceItem(item.getCatId(), item.getCatId(), item.getQuantity());
                    ItemPriceInfo itemPriceInfo = new AgilentItemPriceInfo();
                    itemPriceInfo.setListPrice(item.getUnitPrice());
                    itemPriceInfo.setAmount(item.getYourPrice());
                    commerceItem.setPriceInfo(itemPriceInfo);
                    // commerceItem.setDesignName(item.getProductName());
                    webOrder.addCommerceItem(commerceItem);
                    total = total + item.getYourPrice();
                    orderHeaderInfo = orderHeaderInfo + "<tr><td>" + count + "</td><td>" + item.getCatId() + "&nbsp;</td><td>" + item.getProductName() + "&nbsp;</td><td>"
                            + item.getQuantity() + "&nbsp;</td><td>" + item.getYourPrice()
                            + "&nbsp;</td><td>&ndash;&nbsp;&ndash;</td><td>&ndash;&nbsp;&ndash;</td><td>&ndash;&nbsp;&ndash;</td></tr>";
                    count++;
                }
                vlogDebug("getContractID():: {0}", getContractID());
                OrderPriceInfo orderPriceInfo = new OrderPriceInfo();
                orderPriceInfo.setAmount(getTotalAmount());
                webOrder.setPriceInfo(orderPriceInfo);
                webOrder.setOrderProcessedBy(ORDER_PROCESSED_BY_SYSTEM);
                webOrder.setOrderHeaderInfo(ORDER_HEADER_INFO_REDEEM_QUOTE + orderHeaderInfo + "</table>");
                AgilentPropertyManager propertyManager = (AgilentPropertyManager) profile.getProfileTools().getPropertyManager();
                Date date = new Date();
                String salesOrg = (String) getProfile().getPropertyValue(propertyManager.getSapSalesOrgPropertyName());
                // date format need to be changed
                webOrder.setCreationDate(date);
                webOrder.setSubmittedDate(date);
                webOrder.setProfileId(getProfile().getRepositoryId());
                SAPUser sapUser = getSessionBean().getSAPUser();
                vlogDebug("sapUser:: {0}", sapUser);
                if (sapUser != null) {
                    String sapContactNo = (String) getProfile().getPropertyValue("sapContactNumber");
                    webOrder.setSoldToNumber(sapUser.getSoldToNumber());
                    webOrder.setPayToNumber(sapUser.getPayToNumber());
                    webOrder.setSalesOrg(salesOrg);
                    webOrder.setSapContactNumber(sapContactNo);
                    vlogDebug("sapContactNo:: {0}", sapContactNo);
                }
                
                String firstName = (String) getProfile().getPropertyValue(propertyManager.getFirstNamePropertyName());
                String lastName = (String) getProfile().getPropertyValue(propertyManager.getLastNamePropertyName());
                String email = (String) getProfile().getPropertyValue(propertyManager.getEmailAddressPropertyName());
                webOrder.setSoldToName(firstName);
                /* Set Payment Information */
                RepositoryItem billingAddress = (RepositoryItem) profile.getPropertyValue(propertyManager.getBillingAddressPropertyName());
                PaymentGroup payGroup = (PaymentGroup) webOrder.getPaymentGroups().get(0);
                PaymentGroup newPg = null;
                vlogDebug("getSelectedPaymentMethod():: {0}", getSelectedPaymentMethod());
                vlogDebug("payGroup:: {0}", payGroup);
                if (getSelectedPaymentMethod().equalsIgnoreCase("paynow")) {
                    newPg = getPaymentGroupManager().createPaymentGroup(CYBERSOURCEPAYMENTGROUP);
                } else if (getSelectedPaymentMethod().equalsIgnoreCase("fsp")) {
                    newPg = getPaymentGroupManager().createPaymentGroup(FLEXIBLE_SPLEND_PLAN_PAYMENT_GROUP);
                } else {
                    newPg = getPaymentGroupManager().createPaymentGroup(PURCHASEORDERPAYMENTGROUP);
                }
                if (payGroup != null) {
                    getPaymentGroupManager().removePaymentGroupFromOrder(webOrder, payGroup.getId());
                }
                vlogDebug("newPg:: {0}", newPg);
                getPaymentGroupManager().addPaymentGroupToOrder(webOrder, newPg);
                payGroup = newPg;
                for (ReviewQuotesBean reviewQuoteBean : reviewQuoteItems) {
                    if (payGroup instanceof PurchaseOrderPaymentGroup) {
                        vlogDebug("instance of purchase order group:: {0}", payGroup);
                        ((PurchaseOrderPaymentGroup) payGroup).setPurchaseOrderNumber(getPurchaseOrderNumber());
                        PurchaseOrderPaymentGroup poPG = (PurchaseOrderPaymentGroup) payGroup;
                        poPG.setPayerFirstName(firstName);
                        poPG.setPayerLastName(lastName);
                        poPG.setPayerCompanyName((String) reviewQuoteBean.getBillToName());
                        poPG.setPayerAddress1((String) reviewQuoteBean.getBillToStreet());
                        poPG.setPayerCity((String) reviewQuoteBean.getBillToCity());
                        poPG.setPayerCountry((String) reviewQuoteBean.getBillToCountry());
                        poPG.setPayerState((String) reviewQuoteBean.getBillToRegion());
                        poPG.setPayerPostalCode((String) reviewQuoteBean.getBillToPostCode());
                        poPG.setPayerEmail(email);
                        // AMS-50 Changes
                        if (billingAddress != null) {
                        poPG.setPayerPhoneNumber((String) billingAddress.getPropertyValue(propertyManager.getPhoneNumberPropertyName()));
                        }

                    } else if (payGroup instanceof FlexibleSpendPlanPaymentGroup) {
                        vlogDebug("instance of purchase order group:: {0}", payGroup);
                        if(getFspPlan().equalsIgnoreCase(Constants.FSP_OPTION_OTHER)) {
                        	((FlexibleSpendPlanPaymentGroup) payGroup).setFSPAccountNumber(getFspAccountNumber());
		        		} 
		        		else {
		        			((FlexibleSpendPlanPaymentGroup) payGroup).setFSPAccountNumber(getFspPlan());
		        		}
                        FlexibleSpendPlanPaymentGroup poPG = (FlexibleSpendPlanPaymentGroup) payGroup;
                        poPG.setPayerFirstName(firstName);
                        poPG.setPayerLastName(lastName);
                        poPG.setPayerCompanyName((String) reviewQuoteBean.getBillToName());
                        poPG.setPayerAddress1((String) reviewQuoteBean.getBillToStreet());
                        poPG.setPayerCity((String) reviewQuoteBean.getBillToCity());
                        poPG.setPayerCountry((String) reviewQuoteBean.getBillToCountry());
                        poPG.setPayerState((String) reviewQuoteBean.getBillToRegion());
                        poPG.setPayerPostalCode((String) reviewQuoteBean.getBillToPostCode());
                        poPG.setPayerEmail(email);
                        // AMS-50 Changes
                        if (billingAddress != null) {
                        poPG.setPayerPhoneNumber((String) billingAddress.getPropertyValue(propertyManager.getPhoneNumberPropertyName()));
                        }
                    } else if (payGroup instanceof CyberSourcePaymentGroup) {
                        vlogDebug("instance of CyberSourcePaymentGroup:: {0}", payGroup);
                        CyberSourcePaymentGroup ccPg = (CyberSourcePaymentGroup) payGroup;
                        CyberSourcePaymentStatusImpl cyberSourPaymentStatus = new CyberSourcePaymentStatusImpl();
                        cyberSourPaymentStatus.setCardType(getCreditCardType());
                        cyberSourPaymentStatus.setSubscriptionId(getSubId());
                        ccPg.addAuthorizationStatus(cyberSourPaymentStatus);
                        ccPg.setPayerFirstName(firstName);
                        ccPg.setPayerLastName(lastName);
                        ccPg.setPayerCompanyName((String) reviewQuoteBean.getBillToName());
                        ccPg.setPayerAddress1((String) reviewQuoteBean.getBillToStreet());
                        ccPg.setPayerCity((String) reviewQuoteBean.getBillToCity());
                        ccPg.setPayerCountry((String) reviewQuoteBean.getBillToCountry());
                        ccPg.setPayerState((String) reviewQuoteBean.getBillToRegion());
                        ccPg.setPayerPostalCode((String) reviewQuoteBean.getBillToPostCode());
                        // AMS-50 Changes
                        if (billingAddress != null) {
                        ccPg.setPayerPhoneNumber((String) billingAddress.getPropertyValue(propertyManager.getPhoneNumberPropertyName()));
                        }
                        ccPg.setPayerEmail(email);
                    }
                    // AMS-50 Changes
                    if (billingAddress != null) {
                    webOrder.setBillToNumber(billingAddress.getRepositoryId());
                    }
                    vlogDebug("webOrder.getShippingGroupCount():: {0}", webOrder.getShippingGroupCount());
                    if (webOrder.getShippingGroupCount() > 0) {
                        HardgoodShippingGroup shipGroup = (HardgoodShippingGroup) webOrder.getShippingGroups().get(0);
                        shipGroup.setPropertyValue("email", profile.getPropertyValue("email"));
                        shipGroup.setShippingMethod((String) getProfile().getPropertyValue("defaultShippingMethod"));
                        AgilentAddressVO shippingAddress = new AgilentAddressVO();
                        RepositoryItem shipAddress = (RepositoryItem) profile.getPropertyValue(propertyManager.getShippingAddressPropertyName());
                        shippingAddress.setFirstName(firstName);
                        shippingAddress.setLastName(lastName);
                        shippingAddress.setAddress1((String) reviewQuoteBean.getPayerStreet());
                        shippingAddress.setCompanyName((String) reviewQuoteBean.getPayerName());
                        shippingAddress.setState((String) reviewQuoteBean.getPayerRegion());
                        shippingAddress.setCity((String) reviewQuoteBean.getPayerCity());
                        shippingAddress.setCountry((String) reviewQuoteBean.getPayerCountry());
                        shippingAddress.setPostalCode((String) reviewQuoteBean.getPayerPostCode());
                        shipGroup.setShippingAddress(shippingAddress);
                        // AMS-50 Changes
                        if (shipAddress != null) {
                        webOrder.setSoldToNumber((String) shipAddress.getPropertyValue(propertyManager.getPhoneNumberPropertyName()));
                        }
                    }
                }
                // If there is error in SAP Order webservice,no problem,order should be placed in ATG.
                int statevalue = StateDefinitions.ORDERSTATES.getStateValue(OrderStates.SUBMITTED);
                vlogDebug("statevalue:: {0}", statevalue);
                webOrder.setState(statevalue);
                
                //DCCOM-3129 Starts
                vlogDebug("Invoice Type::{0}", getInvoiceType());
                if(StringUtils.isNotBlank(getInvoiceType())){
                	webOrder.setInvoiceType(getInvoiceType());
                }
                //DCCOM-3129 Ends
                
                vlogDebug("AutoRenew status ::{0}", getContractAutoRenew());
                if(StringUtils.isNotBlank(getContractAutoRenew())){
                	webOrder.setContractAutoRenew(getContractAutoRenew());
                }
                

                if(!callSAPCRMToPostOrder(firstName, payGroup, webOrder, lastName , email)){
                	setError(true);
                	request.setAttribute("fspPaymentError", true);
                	return false;
                }
                
                getOrderManager().addOrder(webOrder);
                getShoppingCart().setLast(webOrder);
                vlogDebug("getShoppingCart():: {0}", getShoppingCart());
                vlogDebug("getShoppingCart():: {0}", getShoppingCart().getLast());
                vlogDebug("Contract Renewal Order created Successfully {0} " + orderId);

                setError(false);
            } else {
                setError(true);
                vlogError("Quote Id Not Found");
                ValidationExceptions validationExceptions = new ValidationExceptions();
                validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
            }
        } catch (CommerceException exception) {
            setError(true);
            vlogError(exception, "Some Commerce Exception occured");
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
        } catch (Exception exception) {
            setError(true);
            vlogError("There was an exception while updating order" + exception);
            exception.printStackTrace();
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
        }
        return isError;
    }

    private List<LineItem> getCommerceItemDetails(DynamoHttpServletRequest request, List<ReviewQuotesBean> reviewQuoteItems) throws ClientProtocolException, IOException {

        List<LineItem> lineitems = new ArrayList<LineItem>();
        if (reviewQuoteItems != null) {
            for (ReviewQuotesBean items : reviewQuoteItems) {
                if (items.getQuoteId() != null)
                    setQuoteId(items.getQuoteId());

                if (getContractID() != null) {
                    setContractID(getContractID());
                } else if (items.getContrID() != null) {
                    setContractID(items.getContrID());
                }
                //setPreventiveMaintenanceMonth(items.getPreventiveMaintenanceMonth());
                List<ReviewQuoteDetailsInfo> itemsInfo = items.getQuoteItems();
                setTotalAmount(Double.parseDouble(items.getTotalAmount()));

                for (ReviewQuoteDetailsInfo itemInfo : itemsInfo) {
                    LineItem lineItem = new LineItem();
                    lineItem.setCatId(itemInfo.getQuoteSystemId());
                    lineItem.setProductName(itemInfo.getQuoteSystemHandle());
                    lineItem.setQuantity(1);
                    lineItem.setUnitPrice(Double.parseDouble(itemInfo.getQuoteSystemGrossValue()));
                    lineItem.setYourPrice(Double.parseDouble(itemInfo.getQuoteSystemGrossValue()));
                    lineitems.add(lineItem);
                }
            }
        } else {
            setError(true);
            vlogError("Quote Not FOund In Session");
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
        }
        return lineitems;
    }

    public boolean handleAutoRenewalCancel(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
    	Map<String, String> resquestMap = new LinkedHashMap<String, String>();
    	resquestMap.put(SAP_AUTORENEWAL_INDICATOR,EMPTY_STRING);
    	resquestMap.put(AUTO_RENEWAL_CONTRACTID, getQuoteId());
    	resquestMap.put(AUTO_RENEWAL_CANCEL, EMPTY_STRING);
    	
    	boolean successCode = getSapcrmapiManager().createQuoteService(getQuoteId(), getRestClient(), resquestMap);
    	if(successCode && getAgilentContractHistoryHelper() != null) {
	    		String orderId = getAgilentContractHistoryHelper().findOrderIdForContractIdInOrder(getQuoteId());
        		try {
        			if(StringUtils.isNotBlank(orderId)) {
        				AgilentOrder agilentOrder = (AgilentOrder) getOrderManager().loadOrder(orderId);
        				if(agilentOrder != null) {
        					agilentOrder.setContractId(agilentOrder.getContractId() + "_Cancelled");
        					agilentOrder.setOrderType("AUTO_RENEWAL_CANCEL");
        					agilentOrder.setContractAutoRenew("false");
    						getOrderManager().updateOrder(agilentOrder);
        				}
        			} else {
        				vlogInfo("The matching order id for the contract id is :: {0} ", orderId);
        			}
    			} catch (CommerceException commExp) {
    				 vlogError("CommerceException occurred while updating commerce order.", commExp);
    			}
        }
    	return checkFormRedirect(getAutoRenewalCancelSuccessURL(), getAutoRenewalCancelSuccessURL(), request, response);
    }
    
    private boolean callSAPCRMToPostOrder(String firstName, PaymentGroup payGroup, AgilentOrder webOrder, String lastName, String email) {
        try {
            Map<String, String> resquestMap = new LinkedHashMap<String, String>();
            String purchaserName = firstName + " " + lastName;
            vlogDebug("AutoRenew status ::{0}", getContractAutoRenew());
            
            if(StringUtils.isNotBlank(getContractAutoRenew()) && TRUE.equals(getContractAutoRenew())){
            	vlogDebug("Setting the status to x for order placement");
            	resquestMap.put(SAP_AUTORENEWAL_INDICATOR,STRING_X);
            } else if(StringUtils.isNotBlank(getContractAutoRenew()) && FALSE.equals(getContractAutoRenew())) {
            	vlogDebug("Setting the status to empty for order placement");
            	resquestMap.put(SAP_AUTORENEWAL_INDICATOR,EMPTY_STRING);
            } else{
            	vlogDebug("Not Setting the status since autorenwal flag is set to null");
            }
          
            String invoiceDetailsAttribute=null;
         
           invoiceDetailsAttribute=populateInvoiceAttributes();
            // Change for DCCOM-1027 Starts
          
            vlogDebug("invoiceDetailsAttribute:: {0}", invoiceDetailsAttribute);
            vlogDebug("payGroup:: {0}", payGroup);
            if(StringUtils.isNotBlank(getPreventiveMaintenanceMonth())){                
                resquestMap.put("Prev_maint_month", getPreventiveMaintenanceMonth());                
            }else{
                resquestMap.put("Prev_maint_month", EMPTY_STRING);
            }            
            if(StringUtils.isBlank(getBillingFrequencyType())){
             	resquestMap.put(CRM_BILLING_FREQUENCY_TYPE,EMPTY_STRING);
            }
           
            String fileAttachments = getSessionBean().getUploadFileContent();
            if(StringUtils.isNotBlank(fileAttachments)){
             	resquestMap.put(ATTACHMENT_SET,fileAttachments);
             	 getSessionBean().setUploadFileContent(EMPTY_STRING);
            }else {
            	resquestMap.put(ATTACHMENT_SET,ATTACHMENT_SET_EMPTY);
            }
            
            String onlineWebDiscountPct = null;
            if(getSessionBean().getValues() != null && getSessionBean().getValues().get(LynxConstants.ONLINE_WEB_DISCOUNT_PCT) != null) {
            	onlineWebDiscountPct = (String) getSessionBean().getValues().get(LynxConstants.ONLINE_WEB_DISCOUNT_PCT);
            }   
            vlogInfo("ForwardQuoteFlag  :: {0} ", isForwardQuoteFlag());            
            if (getSessionBean() != null && getSessionBean().isFwdQuoteFlow() && getSessionBean().getFwdQuoteDetails() != null) {
				ForwardQuoteDetails forwardQuoteDetails = getSessionBean().getFwdQuoteDetails();
				StringBuilder recieverEmailId = new StringBuilder();
				RepositoryItem[] forwardQuoteItems = getQuoteManager().getForwardQuoteDetailsFromRep(
						getQuoteId(), forwardQuoteDetails.getSenderEmail());
				if (forwardQuoteItems != null) {					
					for (RepositoryItem repositoryItem : forwardQuoteItems) {
						String recipientEmail = (String) repositoryItem.getPropertyValue(RECIPIENT_EMAIL);
						if (StringUtils.isNotBlank(recipientEmail)&& !recieverEmailId.toString().contains(recipientEmail)) {
								recieverEmailId.append(recipientEmail).append(SEMI_COLON);							
						}

					}
				}				
				vlogInfo("recieverEmailId  :: {0} ", recieverEmailId);
				String finalrecieverEmail = recieverEmailId.toString();
				if (StringUtils.isNotBlank(finalrecieverEmail)) {
					int lastIndex = finalrecieverEmail.lastIndexOf(SEMI_COLON);
					finalrecieverEmail = recieverEmailId.toString().substring(0, lastIndex);
				}
				vlogInfo("finalrecieverEmail  :: {0} ", finalrecieverEmail);
				resquestMap.put(LynxConstants.FORWARD_QUOTE_FLAG, TRUE);
				resquestMap.put(LynxConstants.QUOTE_PURCHASER_NAME, purchaserName);
				resquestMap.put(LynxConstants.QUOTE_PURCHASER_EMAIL, email);
				resquestMap.put(LynxConstants.SENDER_CONTACTID, forwardQuoteDetails.getSenderCrmContactId());
				resquestMap.put(LynxConstants.QUOTE_FORWARD_EMAILS, finalrecieverEmail);

			}
			 if(!getAgilentConfigurationSecond().isEnableCRMDiscountCalc()){
            	if (getAgilentConfigurationSecond().isEnableOnlineWebDiscount()) {
            		if (StringUtils.isNotBlank(onlineWebDiscountPct)) {
            			resquestMap.put(LynxConstants.ONLINE_DISCOUNT, onlineWebDiscountPct);
            		} else {
            			resquestMap.put(LynxConstants.ONLINE_DISCOUNT, EMPTY_STRING);
            		}
            	}
            }
            if (getAgilentConfigurationSecond().isEnableOnlineWebDiscount() && StringUtils.isNotBlank(onlineWebDiscountPct)) {
    			resquestMap.put(LynxConstants.DISCOUNT_PERCENTAGE, onlineWebDiscountPct);
    		}
            if (payGroup instanceof PurchaseOrderPaymentGroup) {
                resquestMap.put("PoNum", getPurchaseOrderNumber());
                resquestMap.put("QuoteId", getQuoteId());
               // resquestMap.put("Prev_maint_month", getPreventiveMaintenanceMonth());
                
                if(StringUtils.isNotBlank(invoiceDetailsAttribute)){
                	  vlogDebug("about to set invoice details for china users");
                resquestMap.put(LynxConstants.LYNX_INVOICE_DETAILS, invoiceDetailsAttribute);
                }
                if(StringUtils.isNotBlank(getBillingFrequencyType())){
                	vlogDebug("Setting the value for billing frequency type" , getBillingFrequencyType());
                	resquestMap.put(CRM_BILLING_FREQUENCY_TYPE,getBillingFrequencyType());
                }
                if (checkResponseMap(resquestMap)) {
                    resquestMap.put("CreditcardType", "");
                    resquestMap.put("SubscriptionId", " ");
                    resquestMap.put("ORDER_TOTAL", "");
                    resquestMap.put("PAYMENT_TERMS", "");
                    vlogDebug("Requestmap {0}", resquestMap);
                    boolean successCode = getSapcrmapiManager().createQuoteService(getQuoteId(), getRestClient(), resquestMap);
                    vlogInfo("successCode {0}", successCode);
                    if (successCode) {
                        return true;
                    } else {
                        try {
                            vlogInfo("Email code started");
                            sendCRMOrderErrorMail(webOrder);
                        } catch (TemplateEmailException exception) {
                            vlogError(exception, "Exception while trying to send email to Customer");
                        }
                    }
                }
            }

            if (payGroup instanceof CyberSourcePaymentGroup) {
                resquestMap.put("CreditcardType", getCreditCardType());
                String customerName = firstName + " " + lastName;
                if (getPurchaseOrderCCNumber() != null && !getPurchaseOrderCCNumber().isEmpty())
                    resquestMap.put("PoNum", getPurchaseOrderCCNumber());
                else
                    resquestMap.put("PoNum", customerName);
                resquestMap.put("QuoteId", getQuoteId());
                resquestMap.put("SubscriptionId", getSubId());
                resquestMap.put("ORDER_TOTAL", "");
                resquestMap.put("PAYMENT_TERMS", "");
               // resquestMap.put("Prev_maint_month", getPreventiveMaintenanceMonth());
                resquestMap.put("InvoiceDet", invoiceDetailsAttribute);
                resquestMap.put(CRM_BILLING_FREQUENCY_TYPE, EMPTY_STRING);

                if (checkResponseMap(resquestMap)) {
                    vlogDebug("Responsemap", resquestMap);
                    boolean successCode = getSapcrmapiManager().createQuoteService(getQuoteId(), getRestClient(), resquestMap);
                    vlogInfo("successCode {0}", successCode);
                    if (successCode) {
                        return true;
                    } else {
                        try {
                            vlogInfo("Email code started");
                            sendCRMOrderErrorMail(webOrder);
                        } catch (TemplateEmailException exception) {
                            vlogError(exception, "Exception while trying to send email to Customer");
                        }
                    }
                }
            }
            
            if (payGroup instanceof FlexibleSpendPlanPaymentGroup) {
                resquestMap.put("PoNum", getFspAccountNumber());
                resquestMap.put("QuoteId", getQuoteId());
                if(StringUtils.isNotBlank(invoiceDetailsAttribute)){
                	vlogDebug("about to set invoice details for china users");
                	resquestMap.put(LynxConstants.LYNX_INVOICE_DETAILS, invoiceDetailsAttribute);
                }

                if (checkResponseMap(resquestMap)) {
                    resquestMap.put("CreditcardType", "");
                    resquestMap.put("SubscriptionId", " ");
                    resquestMap.put("ORDER_TOTAL", String.valueOf(getOrderTotal()));
                    resquestMap.put("PAYMENT_TERMS", "FLSP");
                    resquestMap.put(CRM_BILLING_FREQUENCY_TYPE, EMPTY_STRING);
                    vlogDebug("Responsemap", resquestMap);
                    boolean successCode = getSapcrmapiManager().createQuoteService(getQuoteId(), getRestClient(), resquestMap);
                   vlogInfo("successCode {0}", successCode);
                    int index =0 ;
                    
                    while(resquestMap.containsKey("REST_SERVICE_ERROR_RESPONSE_HEADERS."+index)){
                    	 String errCode  = resquestMap.get("REST_SERVICE_ERROR_RESPONSE_HEADERS."+index);
                    	 if(null != errCode  && getSubmitRenewalOrderFailureErrorCodeMapping().containsKey(errCode.trim())){
		                		vlogDebug("Stop redeemquote due to FSP Plan failure : Error Code: ", errCode);	
		                		Map<String, Object> params = new HashMap<String,Object>();
		                		String formattedMessage = getInternationalizationService().getLocalizeMessage(getSubmitRenewalOrderFailureErrorCodeMapping().get(errCode), params);
		                		addFormException(new DropletException(formattedMessage));
		                		//return without saving the weborder and show error to the user.
		                		return false;
		                	}
                    }
                    if (successCode) {
                        return true;
                    } else {
                        try {
                            vlogInfo("Email code started");
                            sendCRMOrderErrorMail(webOrder);
                        } catch (TemplateEmailException exception) {
                            vlogError(exception, "Exception while trying to send email to Customer");
                        }
                    }
                }
            }            
        } catch (ClientProtocolException e) {
            vlogError("There was error sending the order to SAP CRM");
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
        } catch (IOException e) {
            vlogError("There was error sending the order to SAP CRM");
            ValidationExceptions validationExceptions = new ValidationExceptions();
            validationExceptions.addValidationError(IErrorId.REDEEM_QUOTE_ERROR, new String[] {}, new Object[] {});
        }
        return false;
    }
 /*
  * To populate invoice attribute details only when they are not-null/not-empty . The final string is populated in reverse order i.e the last attribute is inserted first
  */
    private String populateInvoiceAttributes() {
    	
    	String finalInvoiceDetails=null;
    	  vlogInfo("invoice type is {0}",getInvoiceType());
    	//populate invoice type first
    	 if (StringUtils.isNotBlank(getInvoiceType())){
      		  finalInvoiceDetails=getInvoiceType();
            }
    	//This was the actual order of attributes. Needs to be followed
    	  //invoiceDetailsAttribute = customerName1 + "$@$" + companyTaxCode1 + "$@$" + address1 + "$@$" + bankName1 + "$@$" 
             //     + bankAccount1 + "$@$" + customerName2 + "$@$" + city2 + "$@$" + shippingAdrress2 + "$@$" + postCode2 + "$@$" 
               //   + contactorName2 + "$@$" + contactorPhNum2 + "$@$" + getInvoiceType();
		
		
		 String customerName1 = (String) getProfile().getPropertyValue("customerName1");
			String customerName2 = (String) getProfile().getPropertyValue("customerName2");
			String city2 = (String) getProfile().getPropertyValue("city2");
			String postCode2 = (String) getProfile().getPropertyValue("postCode2");
			String bankName1 = (String) getProfile().getPropertyValue("bankName1");
			String bankAccount1 = (String) getProfile().getPropertyValue("bankAccount1");
			String address1 = (String) getProfile().getPropertyValue("address1");
			String shippingAdrress2 = (String) getProfile().getPropertyValue("shippingAdrress2");
			String companyTaxCode1 = (String) getProfile().getPropertyValue("companyTaxCode1");
			String contactorName2 = (String) getProfile().getPropertyValue("contactorName2");
			String contactorPhNum2 = (String) getProfile().getPropertyValue("contactorPhNum2");
			String invoiceEmail = (String) getProfile().getPropertyValue("invoiceEmail");
			
			vlogInfo(
					"Individual invoice attributes in final order to be populated {0} , {1} , {2} , {3} , {4}, {5} ,{6}, {7}, {8}, {9},{10} ",
					customerName1, companyTaxCode1, address1, bankName1, bankAccount1, customerName2, city2,
					shippingAdrress2, postCode2, contactorName2, contactorPhNum2);
			
    	 if (StringUtils.isNotBlank(invoiceEmail)){
	    		  finalInvoiceDetails=invoiceEmail+"$@$"+finalInvoiceDetails;
	          }
		 if (StringUtils.isNotBlank(contactorPhNum2)){
    		  finalInvoiceDetails=contactorPhNum2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(contactorName2)){
    		  finalInvoiceDetails=contactorName2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(postCode2)){
    		  finalInvoiceDetails=postCode2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(shippingAdrress2)){
    		  finalInvoiceDetails=shippingAdrress2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(city2)){
    		  finalInvoiceDetails=city2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(customerName2)){
    		  finalInvoiceDetails=customerName2+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(bankAccount1)){
    		  finalInvoiceDetails=bankAccount1+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(bankName1)){
    		  finalInvoiceDetails=bankName1+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(address1)){
    		  finalInvoiceDetails=address1+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(companyTaxCode1)){
    		  finalInvoiceDetails=companyTaxCode1+"$@$"+finalInvoiceDetails;
          }
    	  if (StringUtils.isNotBlank(customerName1)){
    		  finalInvoiceDetails=customerName1+"$@$"+finalInvoiceDetails;
          }
		return finalInvoiceDetails;
	}


	private boolean checkResponseMap(Map<String, String> resquestMap) {
        Iterator<String> keySetIterator = resquestMap.keySet().iterator();
        Iterator<String> valueSetIterator = resquestMap.values().iterator();

        while (keySetIterator.hasNext()) {
            String key = keySetIterator.next();
            String value = valueSetIterator.next();
            if ("CreditcardType".equals(key)) {
                if (StringUtils.isEmpty(value)) {
                    vlogError("We didnot get response for " + key);
                    return false;
                }
            }
        }
        return true;
    }

    private void sendCRMOrderErrorMail(AgilentOrder order) throws TemplateEmailException {

        getAgilentCRMCSREmailTemplateInfo().setMessageFrom(getCrmOrderMessageFrom());
        getAgilentCRMCSREmailTemplateInfo().setMessageSubject(getCrmOrderCSRMessageSubject() + order.getId());
        getAgilentCRMCSREmailTemplateInfo().setMessageTo(getEmailIdCSRAgent());

        Map<String, Object> templateParameters = new HashMap<String, Object>();
        templateParameters.put(ORDERID, order.getId());
        templateParameters.put(CONTRACTID, order.getContractId());
        templateParameters.put(QUOTEID, order.getQuoteId());
        templateParameters.put(ORDER, order);
        templateParameters.put(PROFILE_PARAM, getProfile());
        templateParameters.put("shipFirstName", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getFirstName());
        templateParameters.put("shipLastName", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getLastName());
        templateParameters.put("shipCompanyName", ((AgilentAddressVO) ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress()).getCompanyName());
        templateParameters.put("shipAddress1", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getAddress1());
        templateParameters.put("shipAddress2", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getAddress2());
        templateParameters.put("shipAddress3", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getAddress3());
        templateParameters.put("shipcity", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getCity());
        templateParameters.put("shipState", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getState());
        templateParameters.put("shipCountry", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getCountry());
        templateParameters.put("shipPostalCode", ((HardgoodShippingGroup) order.getShippingGroups().get(0)).getShippingAddress().getPostalCode());

        if (order.getPaymentGroups().get(0) instanceof PurchaseOrderPaymentGroup) {
            templateParameters.put("billFirstName", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerFirstName());
            templateParameters.put("billLastName", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerLastName());
            templateParameters.put("billCompanyName", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerCompanyName());
            templateParameters.put("billAddress1", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress1());
            templateParameters.put("billAddress2", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress2());
            templateParameters.put("billAddress3", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress3());
            templateParameters.put("billcity", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerCity());
            templateParameters.put("billState", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerState());
            templateParameters.put("billCountry", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerCountry());
            templateParameters.put("billPostalCode", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerPostalCode());
            templateParameters.put("billPhoneNumber", ((PurchaseOrderPaymentGroup) order.getPaymentGroups().get(0)).getPayerPhoneNumber());
            templateParameters.put("paymentType", "PO");
        } else if (order.getPaymentGroups().get(0) instanceof FlexibleSpendPlanPaymentGroup) {
            templateParameters.put("billFirstName", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerFirstName());
            templateParameters.put("billLastName", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerLastName());
            templateParameters.put("billCompanyName", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerCompanyName());
            templateParameters.put("billAddress1", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress1());
            templateParameters.put("billAddress2", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress2());
            templateParameters.put("billAddress3", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress3());
            templateParameters.put("billcity", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerCity());
            templateParameters.put("billState", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerState());
            templateParameters.put("billCountry", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerCountry());
            templateParameters.put("billPostalCode", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerPostalCode());
            templateParameters.put("billPhoneNumber", ((FlexibleSpendPlanPaymentGroup) order.getPaymentGroups().get(0)).getPayerPhoneNumber());
            templateParameters.put("paymentType", "FSP");
        } else {
            templateParameters.put("billFirstName", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerFirstName());
            templateParameters.put("billLastName", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerLastName());
            templateParameters.put("billCompanyName", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerCompanyName());
            templateParameters.put("billAddress1", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress1());
            templateParameters.put("billAddress2", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress2());
            templateParameters.put("billAddress3", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerAddress3());
            templateParameters.put("billcity", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerCity());
            templateParameters.put("billState", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerState());
            templateParameters.put("billCountry", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerCountry());
            templateParameters.put("billPostalCode", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerPostalCode());
            templateParameters.put("billPhoneNumber", ((CyberSourcePaymentGroup) order.getPaymentGroups().get(0)).getPayerPhoneNumber());
            templateParameters.put("paymentType", "Credit Card");
        }
        templateParameters.put(LOCALE, getUserLocale());
        getAgilentCRMCSREmailTemplateInfo().setTemplateParameters(templateParameters);
        vlogInfo("Email send to CSE agents {0}", getEmailIdCSRAgent());
        getCrmTemplateEmailSender().sendEmailMessage(getAgilentCRMCSREmailTemplateInfo(), new String[] {getEmailIdCSRAgent()}, Boolean.FALSE, false);
    }

    public boolean handleCCError(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
    	if (StringUtils.isNotEmpty(getCyberSourceReturnMsg())) {
            addFormException(new DropletException(getCyberSourceReturnMsg()));
        }
    	return checkFormRedirect(getCcErrURL(), getCcErrURL(), pRequest, pResponse);
    }
    
    /**
     * This method is used to save the invoice information to the user profile.
     * @param pRequest
     * @param pResponse
     * @throws ServletException
     * @throws IOException
     */
    public void handleSaveInvoiceInfo(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
    	vlogDebug("--------- Entering into AgilentCRMCommitOrderFormHandler.handleSaveInvoiceInfo  ---------");
        AgilentProfile pProfile = (AgilentProfile) getProfile();
		try {
			Dictionary<String,Object> userInvoiceInfo = new Hashtable<String,Object>();
			if(getCustomerName1()!=null) {
				userInvoiceInfo.put(Constants.CUSTOMER_NAME1, getCustomerName1());
	        }
			if(getCustomerName2()!=null) {
				userInvoiceInfo.put(Constants.CUSTOMER_NAME2, getCustomerName2());
			}
			if(getCity2()!=null) {
				userInvoiceInfo.put(Constants.CITY2, getCity2());			
			}
			if(getPostCode2()!=null) {
				userInvoiceInfo.put(Constants.POST_CODE2, getPostCode2());
			}
			if(getBankName1()!=null) {
				 userInvoiceInfo.put(Constants.BANK_NAME1, getBankName1());
			}
			if(getBankAccount1()!=null) {
				 userInvoiceInfo.put(Constants.BANK_ACCOUNT1, getBankAccount1());
			}
			if(getAddress1()!=null) {
				 userInvoiceInfo.put(Constants.ADDRESS1, getAddress1());
			}
			if(getShippingAdrress2()!=null) {
				userInvoiceInfo.put(Constants.SHIPPING_ADDRESS2, getShippingAdrress2());
			}
			if(getCompanyTaxCode1()!=null) {
				 userInvoiceInfo.put(Constants.COMPANY_TAX_CODE1, getCompanyTaxCode1());
			}
			if(getContactorName2()!=null) {
				userInvoiceInfo.put(Constants.CONTACTOR_NAME2, getContactorName2());
			}
			if(getContactorPhNum2()!=null) {
				userInvoiceInfo.put(Constants.CONTACTOR_PHNUM2, getContactorPhNum2());
			}
	        if(getInvoiceEmail()!=null) {
				userInvoiceInfo.put(Constants.INVOICE_EMAIL , getInvoiceEmail());
			}
			if(!userInvoiceInfo.isEmpty()){
	        	getCommerceProfileTools().updateProperties(userInvoiceInfo, pProfile);
	        	vlogDebug("AgilentCRMCommitOrderFormHandler.handleSaveInvoiceInfo ::: Invoice Info Updated");
			}
		} catch (RepositoryException e) {
			vlogError(e,"Exception occured while updating invoice information to profile :: {0}", e.getMessage());
		}
		vlogDebug("--------- Existing from AgilentCRMCommitOrderFormHandler.handleSaveInvoiceInfo  ---------");
    }

    /**
     * @return the crmTemplateEmailSender
     */
    public TemplateEmailSender getCrmTemplateEmailSender() {
        return mCrmTemplateEmailSender;
    }

    /**
     * @param crmTemplateEmailSender
     *            the crmTemplateEmailSender to set
     */
    public void setCrmTemplateEmailSender(TemplateEmailSender crmTemplateEmailSender) {
        mCrmTemplateEmailSender = crmTemplateEmailSender;
    }

    /**
     * @return the crmOrderMessageFrom
     */
    public String getCrmOrderMessageFrom() {
        return mCrmOrderMessageFrom;
    }

    /**
     * @param crmOrderMessageFrom
     *            the crmOrderMessageFrom to set
     */
    public void setCrmOrderMessageFrom(String crmOrderMessageFrom) {
        mCrmOrderMessageFrom = crmOrderMessageFrom;
    }

    /**
     * @return the crmOrderCSRMessageSubject
     */
    public String getCrmOrderCSRMessageSubject() {
        return mCrmOrderCSRMessageSubject;
    }

    /**
     * @param crmOrderCSRMessageSubject
     *            the crmOrderCSRMessageSubject to set
     */
    public void setCrmOrderCSRMessageSubject(String crmOrderCSRMessageSubject) {
        mCrmOrderCSRMessageSubject = crmOrderCSRMessageSubject;
    }

    /**
     * @return the agilentCRMCSREmailTemplateInfo
     */
    public TemplateEmailInfoImpl getAgilentCRMCSREmailTemplateInfo() {
        return mAgilentCRMCSREmailTemplateInfo;
    }

    /**
     * @param agilentCRMCSREmailTemplateInfo
     *            the agilentCRMCSREmailTemplateInfo to set
     */
    public void setAgilentCRMCSREmailTemplateInfo(TemplateEmailInfoImpl agilentCRMCSREmailTemplateInfo) {
        mAgilentCRMCSREmailTemplateInfo = agilentCRMCSREmailTemplateInfo;
    }

    /**
     * @return the agilentServiceHistoryHelper
     */
    public AgilentContractHistoryHelper getAgilentServiceHistoryHelper() {
        return agilentServiceHistoryHelper;
    }

    /**
     * @param agilentServiceHistoryHelper
     *            the agilentServiceHistoryHelper to set
     */
    public void setAgilentServiceHistoryHelper(AgilentContractHistoryHelper agilentServiceHistoryHelper) {
        this.agilentServiceHistoryHelper = agilentServiceHistoryHelper;
    }

    public AgilentCatalogTools getAgilentCatalogTools() {
        return agilentCatalogTools;
    }

    public void setAgilentCatalogTools(AgilentCatalogTools agilentCatalogTools) {
        this.agilentCatalogTools = agilentCatalogTools;
    }

    public String getRenewContract() {
        return renewContract;
    }

    public void setRenewContract(String renewContract) {
        this.renewContract = renewContract;
    }

    public String getPreventiveMaintenanceMonth() {
        return preventiveMaintenanceMonth;
    }

    public void setPreventiveMaintenanceMonth(String preventiveMaintenanceMonth) {
        this.preventiveMaintenanceMonth = preventiveMaintenanceMonth;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getRenewContractSuccessURL() {
        return renewContractSuccessURL;
    }

    public String getPaymentVerificationURL() {
        return paymentVerificationURL;
    }

    public void setPaymentVerificationURL(String paymentVerificationURL) {
        this.paymentVerificationURL = paymentVerificationURL;
    }

    public AgilentCatalogTools getmCatalogTools() {
        return mCatalogTools;
    }

    public void setmCatalogTools(AgilentCatalogTools mCatalogTools) {
        this.mCatalogTools = mCatalogTools;
    }

    public String getDeliveryMethod() {
        return deliveryMethod;
    }

    public void setDeliveryMethod(String deliveryMethod) {
        this.deliveryMethod = deliveryMethod;
    }

    public void setRenewContractSuccessURL(String renewContractSuccessURL) {
        this.renewContractSuccessURL = renewContractSuccessURL;
    }

    public String getRenewContractErrorURL() {
        return renewContractErrorURL;
    }

    public void setRenewContractErrorURL(String renewContractErrorURL) {
        this.renewContractErrorURL = renewContractErrorURL;
    }

    public AgilentOrder getWebOrder() {
        return webOrder;
    }

    public void setWebOrder(AgilentOrder webOrder) {
        this.webOrder = webOrder;
    }

    public String getContractID() {
        return contractID;
    }

    public void setContractID(String contractID) {
        this.contractID = contractID;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    @Override
    public String getPurchaseOrderNumber() {
        return purchaseOrderNumber;
    }

    @Override
    public void setPurchaseOrderNumber(String purchaseOrderNumber) {
        this.purchaseOrderNumber = purchaseOrderNumber;
    }

    public boolean isPayWithCC() {
        return isPayWithCC;
    }

    public void setPayWithCC(boolean isPayWithCC) {
        this.isPayWithCC = isPayWithCC;
    }

    public boolean isPayWithPO() {
        return isPayWithPO;
    }

    public void setPayWithPO(boolean isPayWithPO) {
        this.isPayWithPO = isPayWithPO;
    }

    public String getRenewalOrderSuccessURL() {
        return renewalOrderSuccessURL;
    }

    public void setRenewalOrderSuccessURL(String renewalOrderSuccessURL) {
        this.renewalOrderSuccessURL = renewalOrderSuccessURL;
    }

    public String getRenewalOrderErrorURL() {
        return renewalOrderErrorURL;
    }

    public void setRenewalOrderErrorURL(String renewalOrderErrorURL) {
        this.renewalOrderErrorURL = renewalOrderErrorURL;
    }

    public String getSelectedPaymentMethod() {
        return selectedPaymentMethod;
    }

    public void setSelectedPaymentMethod(String selectedPaymentMethod) {
        this.selectedPaymentMethod = selectedPaymentMethod;
    }

    public List<String> getPaymentMethods() {
        return paymentMethods;
    }

    public void setPaymentMethods(List<String> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    public ElectronicShippingGroup getShippingGroup() {
        return shippingGroup;
    }

    public void setShippingGroup(ElectronicShippingGroup shippingGroup) throws DuplicateShippingGroupException, InvalidParameterException {
        webOrder.removeAllShippingGroups();
        webOrder.addShippingGroup(shippingGroup);
        this.shippingGroup = shippingGroup;
    }

    public SAPCRMAPIManager getSapcrmapiManager() {
        return sapcrmapiManager;
    }

    public void setSapcrmapiManager(SAPCRMAPIManager sapcrmapiManager) {
        this.sapcrmapiManager = sapcrmapiManager;
    }

    public RestClient getRestClient() {
        return restClient;
    }

    public void setRestClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public String getSubId() {
        return subId;
    }

    public void setSubId(String subId) {
        this.subId = subId;
    }

    /**
     * Gets the value of property creditCardType
     *
     * @return the value of property creditCardType
     */
    public String getCreditCardType() {
        return mCreditCardType;
    }
    /**
     * Sets the value of property creditCardType with value pCreditCardType
     *
     * @param pCreditCardType
     *            for setting property creditCardType
     */
    public void setCreditCardType(String pCreditCardType) {
        mCreditCardType = pCreditCardType;
    }

    public String getCcErrURL() {
        return ccErrURL;
    }

    public void setCcErrURL(String ccErrURL) {
        this.ccErrURL = ccErrURL;
    }

    public String getSapOrderServiceValidationToken() {
        return sapOrderServiceValidationToken;
    }

    public void setSapOrderServiceValidationToken(String sapOrderServiceValidationToken) {
        this.sapOrderServiceValidationToken = sapOrderServiceValidationToken;
    }

    public boolean isError() {
        return isError;
    }

    public void setError(boolean isError) {
        this.isError = isError;
    }

    public StringBuilder getRedirectURL() {
        return redirectURL;
    }

    public void setRedirectURL(StringBuilder redirectURL) {
        this.redirectURL = redirectURL;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double mTotalAmount) {
        totalAmount = mTotalAmount;
    }

    public String getPurchaseOrderCCNumber() {
        return purchaseOrderCCNumber;
    }

    public void setPurchaseOrderCCNumber(String purchaseOrderCCNumber) {
        this.purchaseOrderCCNumber = purchaseOrderCCNumber;
    }

    public String getEmailIdCSRAgent() {
        return mEmailIdCSRAgent;
    }

    public void setEmailIdCSRAgent(String mEmailIdCSRAgent) {
        this.mEmailIdCSRAgent = mEmailIdCSRAgent;
    }

    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return encryptDecryptHelper;
    }

    public void setEncryptDecryptHelper(EncryptDecryptHelper mEncryptDecryptHelper) {
        encryptDecryptHelper = mEncryptDecryptHelper;
    }

    /**
     * Gets the value of property cyberSourceReturnMsg
     *
     * @return the value of property cyberSourceReturnMsg
     */
    public String getCyberSourceReturnMsg() {
        return mCyberSourceReturnMsg;
    }
    /**
     * Sets the value of property cyberSourceReturnMsg with value pCyberSourceReturnMsg
     *
     * @param pCyberSourceReturnMsg
     *            for setting property cyberSourceReturnMsg
     */
    public void setCyberSourceReturnMsg(String pCyberSourceReturnMsg) {
        mCyberSourceReturnMsg = pCyberSourceReturnMsg;
    }

    // Changes for DCCOM-1027 starts
    /**
     * @return the customerName1
     */
    public String getCustomerName1() {
        return customerName1;
    }

    /**
     * @param customerName1
     *            the customerName1 to set
     */
    public void setCustomerName1(String customerName1) {
        this.customerName1 = customerName1;
    }

    /**
     * @return the companyTaxCode1
     */
    public String getCompanyTaxCode1() {
        return companyTaxCode1;
    }

    /**
     * @param companyTaxCode1
     *            the companyTaxCode1 to set
     */
    public void setCompanyTaxCode1(String companyTaxCode1) {
        this.companyTaxCode1 = companyTaxCode1;
    }

    /**
     * @return the address1
     */
    public String getAddress1() {
        return address1;
    }

    /**
     * @param address1
     *            the address1 to set
     */
    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    /**
     * @return the bankName1
     */
    public String getBankName1() {
        return bankName1;
    }

    /**
     * @param bankName1
     *            the bankName1 to set
     */
    public void setBankName1(String bankName1) {
        this.bankName1 = bankName1;
    }

    /**
     * @return the bankAccount1
     */
    public String getBankAccount1() {
        return bankAccount1;
    }

    /**
     * @param bankAccount1
     *            the bankAccount1 to set
     */
    public void setBankAccount1(String bankAccount1) {
        this.bankAccount1 = bankAccount1;
    }

    /**
     * @return the customerName2
     */
    public String getCustomerName2() {
        return customerName2;
    }

    /**
     * @param customerName2
     *            the customerName2 to set
     */
    public void setCustomerName2(String customerName2) {
        this.customerName2 = customerName2;
    }

    /**
     * @return the city2
     */
    public String getCity2() {
        return city2;
    }

    /**
     * @param city2
     *            the city2 to set
     */
    public void setCity2(String city2) {
        this.city2 = city2;
    }

    /**
     * @return the shippingAdrress2
     */
    public String getShippingAdrress2() {
        return shippingAdrress2;
    }

    /**
     * @param shippingAdrress2
     *            the shippingAdrress2 to set
     */
    public void setShippingAdrress2(String shippingAdrress2) {
        this.shippingAdrress2 = shippingAdrress2;
    }

    /**
     * @return the postCode2
     */
    public String getPostCode2() {
        return postCode2;
    }

    /**
     * @param postCode2
     *            the postCode2 to set
     */
    public void setPostCode2(String postCode2) {
        this.postCode2 = postCode2;
    }

    /**
     * @return the contactorName2
     */
    public String getContactorName2() {
        return contactorName2;
    }

    /**
     * @param contactorName2
     *            the contactorName2 to set
     */
    public void setContactorName2(String contactorName2) {
        this.contactorName2 = contactorName2;
    }

    /**
     * @return the contactorPhNum2
     */
    public String getContactorPhNum2() {
        return contactorPhNum2;
    }

    /**
     * @param contactorPhNum2
     *            the contactorPhNum2 to set
     */
    public void setContactorPhNum2(String contactorPhNum2) {
        this.contactorPhNum2 = contactorPhNum2;
    }
    // Changes for DCCOM-1027 ends
     public String getInvoiceEmail() {
        return invoiceEmail;
    }

    public void setInvoiceEmail(String invoiceEmail) {
        this.invoiceEmail = invoiceEmail;
    }

    /**
   	 * @return the orderTotal
   	 */
   	public Double getOrderTotal() {
   		return orderTotal;
   	}

   	/**
   	 * @param orderTotal the orderTotal to set
   	 */
   	public void setOrderTotal(Double orderTotal) {
   		this.orderTotal = orderTotal;
   	}
    /**
	 * @return the submitOrderFailureErrorCodeMapping
	 */
	public Map<String, String> getSubmitRenewalOrderFailureErrorCodeMapping() {
		return submitRenewalOrderFailureErrorCodeMapping;
	}

	/**
	 * @param submitOrderFailureErrorCodeMapping the submitOrderFailureErrorCodeMapping to set
	 */
	public void setSubmitRenewalOrderFailureErrorCodeMapping(
			Map<String, String> submitRenewalOrderFailureErrorCodeMapping) {
		this.submitRenewalOrderFailureErrorCodeMapping = submitRenewalOrderFailureErrorCodeMapping;
	}

	/**
	 * @return the internationalizationService
	 */
	public InternationalizationService getInternationalizationService() {
		return internationalizationService;
	}

	/**
	 * @param internationalizationService the internationalizationService to set
	 */
	public void setInternationalizationService(
			InternationalizationService internationalizationService) {
		this.internationalizationService = internationalizationService;
	}

	/**
	 * @return the fspPaymentErrorURL
	 */
	public String getFspPaymentErrorURL() {
		return fspPaymentErrorURL;
	}

	/**
	 * @param fspPaymentErrorURL the fspPaymentErrorURL to set
	 */
	public void setFspPaymentErrorURL(String fspPaymentErrorURL) {
		this.fspPaymentErrorURL = fspPaymentErrorURL;
	}

	/**
	 * @return the billingFrequencyType
	 */
	public String getBillingFrequencyType() {
		return this.mBillingFrequencyType;
	}

	/**
	 * @param PBillingFrequencyType the billingFrequencyType to set
	 */
	public void setBillingFrequencyType(String PBillingFrequencyType) {
		this.mBillingFrequencyType = PBillingFrequencyType;
	}
	
	public String getDiscountPercentage() {
		return discountPercentage;
	}

	public void setDiscountPercentage(String discountPercentage) {
		this.discountPercentage = discountPercentage;
	}
	
	public AgilentConfigurationSecond getAgilentConfigurationSecond() {
		return mAgilentConfigurationSecond;
	}

	public void setAgilentConfigurationSecond(AgilentConfigurationSecond pAgilentConfigurationSecond) {
		this.mAgilentConfigurationSecond = pAgilentConfigurationSecond;
	}

	
	
	/**
	 * @return the forwardQuoteFlag
	 */
	public boolean isForwardQuoteFlag() {
		return forwardQuoteFlag;
	}

	/**
	 * @param forwardQuoteFlag the forwardQuoteFlag to set
	 */
	public void setForwardQuoteFlag(boolean forwardQuoteFlag) {
		this.forwardQuoteFlag = forwardQuoteFlag;
	}

	/**
	 * @return the mQuoteManager
	 */
	public QuoteManager getQuoteManager() {
		return mQuoteManager;
	}

	/**
	 * @param mQuoteManager the pQuoteManager to set
	 */
	public void setQuoteManager(QuoteManager pQuoteManager) {
		this.mQuoteManager = pQuoteManager;
	}
	
	

		
	
}
