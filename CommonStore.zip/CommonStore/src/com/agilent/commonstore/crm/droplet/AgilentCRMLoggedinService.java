/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import java.io.IOException;

import javax.servlet.ServletException;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.crm.AgilentCRMProfileCreationManager;
import com.agilent.base.profile.crm.CRMProfileBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.okta.OktaHttpConnectionManager;
import com.agilent.base.util.AgilentUtil;

import atg.core.util.StringUtils;
import atg.repository.Repository;
import atg.repository.RepositoryImpl;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;
import atg.userprofiling.CookieManager;
import atg.userprofiling.Profile;

/**
 * This class is used for processing auto registration flow for SAP CRM users.
 */
public class AgilentCRMLoggedinService extends DynamoServlet implements LynxConstants {

    private boolean mCrmUser;
    private EncryptDecryptHelper mEnDecryptHelper;
    private String mLoginURL;
    private String mContractDetailsURL;
    private String mResetPassWordURL;
    private String warrantyQuestionsURL;
    private AgilentCRMProfileCreationManager mCrmProfileManager;
    private AgilentProfileTools mProfileTools = null;
    private CookieManager mCookieManager;
    private OktaHttpConnectionManager mOktaHttpConnectionManager;
    private Repository mProfileAdapterRepository;
    private String mLogoutURL;
    private String mReturnURL;   
    private String mQuoteDetailsRedirectURL;
    private String mOnDemandQuoteRedirectURL;
    private AgilentConfigurationSecond mAgilentConfigurationSecond;
    
    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        boolean isMigratedUser = false;
        String contractId = null;
        String crmContactId = null;
        String decryptedEmailId = null;
        String emailId = null;
        String encryptedContractID = null;
        String sapContactId = null;
        String optId = null;
        String quoteId=null;
        String encryptedQuoteId = null;
        String quoteType=null;   
        String quoteIdFromReq = null;
        String quoteIdParam = null;
        StringBuilder redirectURL = new StringBuilder();      
        String redirectUrl="";
        String encWarrantyFlag = null;
        try {
            vlogInfo("Inputs-> email(eid): {0}, SAPContactId(scid): {1}, ContractId(cid): {2}, OpportunityId(optid): {3} , "
            		+ "quoteId(qid): {4}, quoteType : {5}", pRequest.getParameter(LYNX_EMAIL_ID),
                    pRequest.getParameter(SAP_CONTACT_ID), pRequest.getParameter(LYNX_CONTRACT_ID), pRequest.getParameter(OPTID),
                    pRequest.getParameter(LYNX_QUOTE_ID),pRequest.getParameter(LYNX_QUOTE_TYPE));
            // Email id is mandatory
            emailId = pRequest.getParameter(LYNX_EMAIL_ID);
            decryptedEmailId = getEnDecryptHelper().decrypt(emailId, "be");
            if (StringUtils.isNotBlank(pRequest.getParameter(SAP_CONTACT_ID))) {            	
                sapContactId = AgilentUtil.removeLeadingZeros(getEnDecryptHelper().decrypt(pRequest.getParameter(SAP_CONTACT_ID), "be"));
            }
            if (StringUtils.isNotBlank(pRequest.getParameter(LYNX_CONTRACT_ID))) {
                contractId = getEnDecryptHelper().decrypt(pRequest.getParameter(LYNX_CONTRACT_ID), "be");
                encryptedContractID = encyptTransaction(contractId);               
            }
            if (StringUtils.isNotBlank(pRequest.getParameter(LYNX_CRM_CONTACT_ID))) {
                crmContactId = AgilentUtil.removeLeadingZeros(getEnDecryptHelper().decrypt(pRequest.getParameter(LYNX_CRM_CONTACT_ID), "be"));               
            }
            if (StringUtils.isNotBlank(pRequest.getParameter(OPTID))) {
                optId = getEnDecryptHelper().decrypt(pRequest.getParameter(OPTID), "be");
                optId = getEnDecryptHelper().encrypt(optId);
            }          
            if (StringUtils.isNotBlank(pRequest.getParameter(LYNX_QUOTE_ID))) {
            	quoteIdFromReq = pRequest.getParameter(LYNX_QUOTE_ID);
                quoteId = getEnDecryptHelper().decrypt(pRequest.getParameter(LYNX_QUOTE_ID), "be");
                vlogDebug("quoteId->quoteId : {0}", quoteId);
                encryptedQuoteId = encyptTransaction(quoteId); 	

            }            
            if (StringUtils.isNotBlank(pRequest.getParameter(LYNX_QUOTE_TYPE))) {
            	quoteType = pRequest.getParameter(LYNX_QUOTE_TYPE);
                vlogDebug("quoteType->quoteType : {0}", quoteType);    
            }
            vlogInfo("User is landing on Store throgh renew button link where emailId=[{0}] and decryptedEmailId=[{1}] and sapContactId=[{2}] and contractId=[{3}] "
                    + "and encrytedContractID=[{4}] and crmContactId=[{5}]", emailId, decryptedEmailId, sapContactId, contractId, encryptedContractID, crmContactId);
        } catch (ApplicationException e) {
            vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt in service method of AgilentCRMLoggedinService class");
        }
        if (StringUtils.isNotBlank(pRequest.getParameter(OPTID))) {
            vlogDebug("OpportunityId->optid : {0}", optId);
            if (StringUtils.isNotBlank(optId)) {
                redirectURL.append(getWarrantyQuestionsURL()).append(OPT_ID).append(optId);
            } else {
                redirectURL.append(getWarrantyQuestionsURL()).append(OPT_ID);
            }
        } else {
            Profile profile = (Profile) ServletUtil.getCurrentUserProfile();
            setCrmUser(true);
            //Start AMS-782 - Deactivation of users
			//cache clear
			RepositoryImpl rep = (RepositoryImpl) getProfileAdapterRepository();
			vlogDebug("invalidating ProfileAdapterRepository cache");
			rep.invalidateCaches();
			//End AMS-782 - Deactivation of users
            RepositoryItem userItem = getProfileTools().getItemFromEmail(decryptedEmailId);
            if (userItem != null) {
                isMigratedUser = (Boolean) userItem.getPropertyValue("migratedUser");
                // Added for DCCOM-2346 - Ability to use CRM contact Id
                updateCRMContactDetails(userItem, sapContactId, crmContactId, decryptedEmailId);
            }
            if(StringUtils.isNotBlank(quoteIdFromReq) && StringUtils.isNotBlank(quoteType)){
            	if(getAgilentConfigurationSecond().getOnDemandQuoteTypes() != null && !getAgilentConfigurationSecond().getOnDemandQuoteTypes().isEmpty() 
            			&& getAgilentConfigurationSecond().getOnDemandQuoteTypes().contains(quoteType)){ 
            		quoteIdParam=pRequest.getParameter(LYNX_QUOTE_ID);    
            		redirectUrl = getOnDemandQuoteRedirectURL();
            	}
            	else if(getAgilentConfigurationSecond().getCrmQuoteTypes() != null && !getAgilentConfigurationSecond().getCrmQuoteTypes().isEmpty()
            			&& getAgilentConfigurationSecond().getCrmQuoteTypes().contains(quoteType) ){            		
            		quoteIdParam=encryptedQuoteId;  
            		if(quoteType.equalsIgnoreCase(WARRANTY_QUOTE_TYPE)){
            		  encWarrantyFlag=encyptTransaction(STRING_TRUE);
            		  vlogInfo("encWarrantyFlag {0} ", encWarrantyFlag);
            		}
            		redirectUrl = getQuoteDetailsRedirectURL();
            	}
            }  
            if (profile != null && !profile.isTransient()) {
            	vlogDebug("Profile is already logged in with repositoryId  {0}", profile.getRepositoryId());
            	if (profile.getPropertyValue(LynxConstants.EMAIL).equals(decryptedEmailId)) {
            		vlogInfo("CRM user is already  logged in {0} and going to redirect on service contract page", decryptedEmailId);
            		if(getAgilentConfigurationSecond().isEnableRedirectCRMAutoReg()){            			
            			getRedirectUrl(redirectURL,quoteType,quoteIdParam,encryptedContractID);     
            			if(StringUtils.isNotBlank(encWarrantyFlag)){
        					redirectURL.append(WARRANTY_FLAG_PARAM).append(encWarrantyFlag);            				
            			}

            		}else{            			
            			redirectURL.append(getContractDetailsURL());
            		}
            		vlogInfo("Redirect Url for user is already  logged {0} ", redirectURL.toString());
            	} else {
            		vlogInfo("Different user is already  logged,need to be logout first  that user whose  Id  is {0}", profile.getRepositoryId());
            		getCookieManager().expireProfileCookies(profile, pRequest, pResponse);
            		if(getAgilentConfigurationSecond().isEnableRedirectCRMAutoReg()){
            			redirectURL.append(getLogoutURL()).append(RETURN_URL).append(redirectUrl).append(LYNX_QUOTE_TYPE_PARAM)
            			.append(quoteType).append("&").append(LYNX_QUOTE_ID_PARAM).append(quoteIdParam);
            		}else{
            			redirectURL.append(getLoginURL()).append(CRM_USER).append(isCrmUser()).append(EMAIL_ID_PARAM).append(emailId).append("&contractId=")
            			.append(encryptedContractID);
            		}
            		vlogInfo("Redirect Url for Different user already logged {0} ", redirectURL.toString());
            	}
            } else if (userItem == null) {
            	if (StringUtils.isNotBlank(sapContactId) || StringUtils.isNotBlank(crmContactId)) {
            		vlogInfo("New user account is going to create whose email id is {0}", decryptedEmailId);
            		if (StringUtils.isBlank(sapContactId)) {
            			sapContactId = crmContactId;
            		}
            		if (getCrmProfileManager().createUser(sapContactId, contractId, decryptedEmailId, null)) {  
            			if(getAgilentConfigurationSecond().isEnableRedirectCRMAutoReg()){ 
            				if(StringUtils.isBlank(quoteType)){
            					quoteType=LYNX_OTHER_QUOTE_TYPE;            					
            				}            				   
            				redirectURL.append(getResetPassWordURL()).append(SET_EMAIL_ID).append(emailId).append("&").append(LYNX_QUOTE_TYPE_PARAM)
            				.append(quoteType).append("&").append(LYNX_QUOTE_ID_PARAM).append(quoteIdParam);
            				if(StringUtils.isNotBlank(encryptedContractID)){
            					redirectURL.append("&contractId=").append(encryptedContractID);            				
                			}            				
            			}else{
            				redirectURL.append(getResetPassWordURL()).append(SET_EMAIL_ID).append(emailId).append("&contractId=").append(encryptedContractID);
            			}

            		}
            		vlogInfo("Redirect Url for new user {0} ", redirectURL.toString());
            	}
            } else if (userItem != null && isMigratedUser) {
            	vlogInfo("User is already exist and going to redirect on reset password page whose email id {0} and migrated status={1}", decryptedEmailId, isMigratedUser);
            	redirectURL.append(getResetPassWordURL()).append(LynxConstants.SET_EMAIL_ID).append(emailId).append("&contractId=").append(encryptedContractID);
            	vlogInfo("Redirect Url for reset password case ", redirectURL.toString());
            } else {
            	vlogInfo("User is going to redirect on login Page with email Id {0}", emailId);
            	if(getAgilentConfigurationSecond().isEnableRedirectCRMAutoReg()){             		
            		getRedirectUrl(redirectURL,quoteType,quoteIdParam,encryptedContractID); 
            		if(StringUtils.isNotBlank(encWarrantyFlag)){
    					redirectURL.append(WARRANTY_FLAG_PARAM).append(encWarrantyFlag);            				
        			}
            	}else{
            		redirectURL.append(getLoginURL()).append(CRM_USER).append(isCrmUser()).append(EMAIL_ID_PARAM).append(emailId).append("&contractId=")
            		.append(encryptedContractID);
            	}    
            	vlogInfo("Redirect Url for else case {0}", redirectURL.toString());
            }
        }
        pResponse.sendRedirect(redirectURL.toString());
    }

    /**
     * This method is used to update CRM contact id and Secondary Ecc id(s) in repository.
     * 
     * @param pUserItem
     * @param pReqEccId
     * @param pReqCrmId
     * @param pReqEmailId
     */
    private void updateCRMContactDetails(RepositoryItem pUserItem, String pReqEccId, String pReqCrmId, String pReqEmailId) {
        CRMProfileBean lCrmProfileBean = new CRMProfileBean();
        lCrmProfileBean.setEmailId(pReqEmailId);
        lCrmProfileBean.setEccContactId(pReqEccId);
        lCrmProfileBean.setCrmContactId(pReqCrmId);
        AgilentPropertyManager property = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        String lUserEccId = (String) pUserItem.getPropertyValue(property.getSapContactNumberPropertyName());
        if (StringUtils.isBlank(lUserEccId) && StringUtils.isNotBlank(pReqEccId)) {
            // Below call is required in order to make CRM aware that this user has been e-Enabled at ATG side.
            lCrmProfileBean = getCrmProfileManager().getCRMUserDetails(pReqEccId, null, pReqEmailId);
        }
        getProfileTools().checkAndUpdateUserDetails(pUserItem, lCrmProfileBean);
        //OKTA Integration Changes
        getOktaHttpConnectionManager().createOrUpdateUserForAutoRegInOkta(lCrmProfileBean);
        
    }

    private String encyptTransaction(String transactionId) {
        String encryptKey = "";
        try {
            if (StringUtils.isNotBlank(transactionId)) {
                encryptKey = getEnDecryptHelper().encrypt(transactionId);
            }
        } catch (ApplicationException e) {
            vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt");
        }
        return encryptKey;
    }
    
    private void getRedirectUrl(StringBuilder pRedirectURL,String pQuoteType,String pQuoteIdParam,String pEncryptedContractId){ 
    	if(StringUtils.isNotBlank(pQuoteType)){
    		if(getAgilentConfigurationSecond().getOnDemandQuoteTypes() != null && !getAgilentConfigurationSecond().getOnDemandQuoteTypes().isEmpty() 
    				&& getAgilentConfigurationSecond().getOnDemandQuoteTypes().contains(pQuoteType)){    	
    			pRedirectURL.append(getOnDemandQuoteRedirectURL()).append(LYNX_QUOTE_TYPE_PARAM)
    			.append(pQuoteType).append("&").append(LYNX_QUOTE_ID_PARAM).append(pQuoteIdParam);    		
    		}else if(getAgilentConfigurationSecond().getCrmQuoteTypes() != null && !getAgilentConfigurationSecond().getCrmQuoteTypes().isEmpty()
    				&& getAgilentConfigurationSecond().getCrmQuoteTypes().contains(pQuoteType) ){    		
    			pRedirectURL.append(getQuoteDetailsRedirectURL()).append(LYNX_QUOTE_ID_PARAM)
    			.append(pQuoteIdParam);
    			if(StringUtils.isNotBlank(pEncryptedContractId)){
    				pRedirectURL.append(LYNX_CONTRACT_ID_PARAM).append(pEncryptedContractId);            				
    			}    			
    		}
    	}else{    			
    		pRedirectURL.append(getOnDemandQuoteRedirectURL()).append(LYNX_QUOTE_TYPE_PARAM).append(LYNX_OTHER_QUOTE_TYPE);
    	}   	    
    }    
   
    /**
     * Gets the value of property crmUser
     *
     * @return the value of property crmUser
     */
    public boolean isCrmUser() {
        return mCrmUser;
    }
    /**
     * Sets the value of property crmUser with value pCrmUser
     *
     * @param pCrmUser
     *            for setting property crmUser
     */
    public void setCrmUser(boolean pCrmUser) {
        mCrmUser = pCrmUser;
    }

    /**
     * Gets the value of property enDecryptHelper
     *
     * @return the value of property enDecryptHelper
     */
    public EncryptDecryptHelper getEnDecryptHelper() {
        return mEnDecryptHelper;
    }
    /**
     * Sets the value of property enDecryptHelper with value pEnDecryptHelper
     *
     * @param pEnDecryptHelper
     *            for setting property enDecryptHelper
     */
    public void setEnDecryptHelper(EncryptDecryptHelper pEnDecryptHelper) {
        mEnDecryptHelper = pEnDecryptHelper;
    }

    /**
     * Gets the value of property loginURL
     *
     * @return the value of property loginURL
     */
    public String getLoginURL() {
        return mLoginURL;
    }
    /**
     * Sets the value of property loginURL with value pLoginURL
     *
     * @param pLoginURL
     *            for setting property loginURL
     */
    public void setLoginURL(String pLoginURL) {
        mLoginURL = pLoginURL;
    }

    /**
     * Gets the value of property contractDetailsURL
     *
     * @return the value of property contractDetailsURL
     */
    public String getContractDetailsURL() {
        return mContractDetailsURL;
    }
    /**
     * Sets the value of property contractDetailsURL with value pContractDetailsURL
     *
     * @param pContractDetailsURL
     *            for setting property contractDetailsURL
     */
    public void setContractDetailsURL(String pContractDetailsURL) {
        mContractDetailsURL = pContractDetailsURL;
    }

    /**
     * Gets the value of property resetPassWordURL
     *
     * @return the value of property resetPassWordURL
     */
    public String getResetPassWordURL() {
        return mResetPassWordURL;
    }
    /**
     * Sets the value of property resetPassWordURL with value pResetPassWordURL
     *
     * @param pResetPassWordURL
     *            for setting property resetPassWordURL
     */
    public void setResetPassWordURL(String pResetPassWordURL) {
        mResetPassWordURL = pResetPassWordURL;
    }

    /**
     * Gets the value of property crmProfileManager
     *
     * @return the value of property crmProfileManager
     */
    public AgilentCRMProfileCreationManager getCrmProfileManager() {
        return mCrmProfileManager;
    }
    /**
     * Sets the value of property crmProfileManager with value pCrmProfileManager
     *
     * @param pCrmProfileManager
     *            for setting property crmProfileManager
     */
    public void setCrmProfileManager(AgilentCRMProfileCreationManager pCrmProfileManager) {
        mCrmProfileManager = pCrmProfileManager;
    }

    /**
     * Gets the value of property profileTools
     *
     * @return the value of property profileTools
     */
    public AgilentProfileTools getProfileTools() {
        return mProfileTools;
    }
    /**
     * Sets the value of property profileTools with value pProfileTools
     *
     * @param pProfileTools
     *            for setting property profileTools
     */
    public void setProfileTools(AgilentProfileTools pProfileTools) {
        mProfileTools = pProfileTools;
    }

    /**
     * Gets the value of property cookieManager
     *
     * @return the value of property cookieManager
     */
    public CookieManager getCookieManager() {
        return mCookieManager;
    }
    /**
     * Sets the value of property cookieManager with value pCookieManager
     *
     * @param pCookieManager
     *            for setting property cookieManager
     */
    public void setCookieManager(CookieManager pCookieManager) {
        mCookieManager = pCookieManager;
    }

    /**
     * @return the warrantyQuestionsURL
     */
    public String getWarrantyQuestionsURL() {
        return warrantyQuestionsURL;
    }

    /**
     * @param warrantyQuestionsURL the warrantyQuestionsURL to set
     */
    public void setWarrantyQuestionsURL(String warrantyQuestionsURL) {
        this.warrantyQuestionsURL = warrantyQuestionsURL;
    }

    /**
     * Gets the value of property mOktaHttpConnectionManager
     *
     * @return the value of property mOktaHttpConnectionManager
     */
    public OktaHttpConnectionManager getOktaHttpConnectionManager() {
        return mOktaHttpConnectionManager;
    }

    /**
     * Sets the value of property mOktaHttpConnectionManager with value mOktaHttpConnectionManager
     *
     * @param mOktaHttpConnectionManager
     *            for setting property mOktaHttpConnectionManager
     */
    public void setOktaHttpConnectionManager(OktaHttpConnectionManager mOktaHttpConnectionManager) {
        this.mOktaHttpConnectionManager = mOktaHttpConnectionManager;
    }
    //Start AMS-782 - Deactivation of users
  	/**
  	 * Gets the value of property profileAdapterRepository
  	 *
  	 * @return the value of property profileAdapterRepository
  	 */
  	public Repository getProfileAdapterRepository() {
  		return mProfileAdapterRepository;
  	}
  	/**
  	 * Sets the value of property profileAdapterRepository with value pProfileAdapterRepository
  	 *
  	 * @param pProfileAdapterRepository
  	 *            for setting property profileAdapterRepository
  	 */
  	public void setProfileAdapterRepository(Repository pProfileAdapterRepository) {
  		mProfileAdapterRepository = pProfileAdapterRepository;
  	}
  	//End AMS-782 - Deactivation of users

	/**
	 * @return the mLogoutURL
	 */
	public String getLogoutURL() {
		return mLogoutURL;
	}

	/**
	 * @param mLogoutURL the mLogoutURL to set
	 */
	public void setLogoutURL(String pLogoutURL) {
		this.mLogoutURL = pLogoutURL;
	}

	/**
	 * @return the mReturnURL
	 */
	public String getReturnURL() {
		return mReturnURL;
	}

	/**
	 * @param pReturnURL the mReturnURL to set
	 */
	public void setReturnURL(String pReturnURL) {
		this.mReturnURL = pReturnURL;
	}

	/**
	 * @return the mQuoteDetailsRedirectURL
	 */
	public String getQuoteDetailsRedirectURL() {
		return mQuoteDetailsRedirectURL;
	}

	/**
	 * @param pQuoteDetailsRedirectURL the mQuoteDetailsRedirectURL to set
	 */
	public void setQuoteDetailsRedirectURL(String pQuoteDetailsRedirectURL) {
		this.mQuoteDetailsRedirectURL = pQuoteDetailsRedirectURL;
	}

	
	/**
	 * @return the mOnDemandQuoteRedirectURL
	 */
	public String getOnDemandQuoteRedirectURL() {
		return mOnDemandQuoteRedirectURL;
	}

	/**
	 * @param pOnDemandQuoteRedirectURL the mOnDemandQuoteRedirectURL to set
	 */
	public void setOnDemandQuoteRedirectURL(String pOnDemandQuoteRedirectURL) {
		this.mOnDemandQuoteRedirectURL = pOnDemandQuoteRedirectURL;
	}

	/**
	 * @return the mAgilentConfigurationSecond
	 */
	public AgilentConfigurationSecond getAgilentConfigurationSecond() {
		return mAgilentConfigurationSecond;
	}

	/**
	 * @param pAgilentConfigurationSecond the mAgilentConfigurationSecond to set
	 */
	public void setAgilentConfigurationSecond(AgilentConfigurationSecond pAgilentConfigurationSecond) {
		this.mAgilentConfigurationSecond = pAgilentConfigurationSecond;
	}
	
	
    
}
