/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.crm.bean.ActiveContractBean;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.bean.ContractHistoryBean;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;

import atg.adapter.gsa.GSAItemDescriptor;
import atg.core.util.StringUtils;
import atg.repository.ItemDescriptorImpl;
import atg.repository.RepositoryException;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.ServletUtil;
import atg.userprofiling.Profile;

/**
 * This droplet is used for fetching contract history.
 */
public class AgilentContractHistoryDroplet extends DynamoServlet {

    private AgilentContractHistoryHelper mContractHistoryHelper;
    private String mTriggerProfileCache;  
    private AgilentConfigurationSecond mConfiguration;
    private static final String CLASSNAME = "AgilentContractHistoryDroplet";
    public static final String FETCH_ACTIVE_CONTRACTS = "fetchActiveContracts";
        

    /*
     * (non-Javadoc)
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest, atg.servlet.DynamoHttpServletResponse)
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        Profile profile = null;
        try {
            if (getTriggerProfileCache() != null && getTriggerProfileCache().equalsIgnoreCase("true")) {
                profile = (Profile) pRequest.getObjectParameter("profile");
                invalidateCacheProfile(profile);
            }
            profile = (Profile) pRequest.getObjectParameter("profile");
            SessionBean sessionBean = (SessionBean) pRequest.resolveName("/com/agilent/profile/SessionBean");
            List<ContractHistoryBean> contractInfo = null;         
            List<ContractHistoryBean> contractInfoAsc = new ArrayList<ContractHistoryBean>();
            // DCCOM-2341 changes start
            String sapContactID = null;
            if (!profile.isTransient()) {
                sapContactID = (String) profile.getPropertyValue(LynxConstants.LYNX_PROFILE_CRM_CONTACT_ID);
                if (StringUtils.isBlank(sapContactID)) {
                    sapContactID = (String) profile.getPropertyValue(LynxConstants.SAP_CONTACT_NUMBER);
                }
            }
            // Send CRM contact number to the CRM service if it is available, else send ECC Contact Id.
            if (StringUtils.isNotBlank(sapContactID)) {
                contractInfo = getContractHistoryHelper().fetchContractDetails(sapContactID);                
                setActiveContractBean(contractInfo,sessionBean);            
                if (getConfiguration().isContractSortingEnabled()) {
                    Collections.sort(contractInfo, new ContractCreationDateComparator());
                    contractInfoAsc.addAll(contractInfo);
                    Collections.reverse(contractInfoAsc);
                    pRequest.setParameter(LynxConstants.CONTRACT_INFO_ASC, contractInfoAsc);
                }
                pRequest.setParameter(LynxConstants.CONTRACT_INFO, contractInfo);
                pRequest.serviceParameter(OUTPUT, pRequest, pResponse);

            }
            // DCCOM-2341 changes end
        } catch (RepositoryException e) {
            vlogError("Profile Not Found", profile.getRepositoryId());
        }
    }
    
    
    
    /**
     * This service method returns the active contracts available for warranty quote
     * 
     * @param warrantyQuoteStartDate
     * @return ActiveContractBean List JSON 
     */

    public List<ActiveContractBean> fetchActiveContracts(String pWarrantyQuoteStartDate) {
        vlogDebug("Entering the method :: {0} in class: {1}", FETCH_ACTIVE_CONTRACTS, CLASSNAME);
        List<ActiveContractBean> contractHistoryList = new ArrayList<ActiveContractBean>();
        List<ActiveContractBean> activeContractList = new ArrayList<ActiveContractBean>();
        DynamoHttpServletRequest request = ServletUtil.getCurrentRequest();
        SessionBean sessionBean = null;
        AgilentProfile profile = null;
        String sapContactID = null;
        List<ContractHistoryBean> contractInfo = null;
        if (null != request) {
            request.getResponse().addHeader("Access-Control-Allow-Origin", "*.agilent.com");
            request.getResponse().setContentType("application/json");
            profile = (AgilentProfile) ServletUtil.getCurrentRequest().resolveName("/atg/userprofiling/Profile");
            if (null == profile) {
                vlogError("Profile is null");
            } else if (profile.isTransient()) {
                vlogDebug("Profile is transient");
            } else {
                sessionBean = profile.getSessionBean();
                if (sessionBean != null && sessionBean.getActiveContractList() != null ) {
                    vlogDebug("Active Contract List available in the Session");
                    contractHistoryList = sessionBean.getActiveContractList();
                    if (!contractHistoryList.isEmpty() && StringUtils.isNotBlank(pWarrantyQuoteStartDate)) {
                        activeContractList = getContractHistoryHelper().filterActiveContractsForWarrantyQuote(contractHistoryList, pWarrantyQuoteStartDate);
                        if(activeContractList != null && !activeContractList.isEmpty()){                            
                            vlogDebug("Active Contract List Count in session :{0} ", activeContractList.size());
                        }else{                      
                            vlogDebug("No Active Contracts available for the Warranty Quote");
                        }

                    }
                } else {
                    vlogDebug("Contract List not available in the Session hence calling ZLYNX_SERVICE_CONTRACT_HIST_SRV");
                    sapContactID = (String) profile.getPropertyValue(LynxConstants.LYNX_PROFILE_CRM_CONTACT_ID);
                    if (StringUtils.isBlank(sapContactID)) {
                        sapContactID = (String) profile.getPropertyValue(LynxConstants.SAP_CONTACT_NUMBER);
                    }
                
                // Send CRM contact number to the CRM service if it is available, else send ECC Contact Id.
                if (StringUtils.isNotBlank(sapContactID)) {
                    contractInfo = getContractHistoryHelper().fetchContractDetails(sapContactID);
                    setActiveContractBean(contractInfo, sessionBean);
                    contractHistoryList = sessionBean.getActiveContractList();
                    activeContractList = getContractHistoryHelper().filterActiveContractsForWarrantyQuote(contractHistoryList, pWarrantyQuoteStartDate);
                    if(activeContractList != null && !activeContractList.isEmpty()){                            
                        vlogDebug("Active Contract List Count after calling CRM Service ZLYNX_SERVICE_CONTRACT_HIST_SRV :{0} ", activeContractList.size());
                    }else{                      
                        vlogDebug("No Active Contracts available for the Warranty Quote");
                    }

                }
               }

            }

        }
        vlogDebug("Exiting from the method: {0} in class: {1}", FETCH_ACTIVE_CONTRACTS, CLASSNAME);
        return activeContractList;
    }
    
    /**
     * This method is used for set the Active Contract Bean
     * 
     * @param pContractHistoryList
     * @param pSessionBean
     *
     */

    private void setActiveContractBean(List<ContractHistoryBean> pContractHistoryList, SessionBean pSessionBean) {
        List<ActiveContractBean> activeContractHistList = new ArrayList<ActiveContractBean>();
        if(pSessionBean.getActiveContractList() != null){   
        	vlogDebug("set the existing activeContractList in the session to null");
            pSessionBean.setActiveContractList(null);
        }
        for (ContractHistoryBean contractHistBean : pContractHistoryList) {
            if (!contractHistBean.isAutoRenewFlag() && !contractHistBean.isExpiringContractFlag() && contractHistBean.isReviewQuoteAndexpMessg()) {
                vlogDebug("Setting the ActiveContractBean from Contract History Bean");
                ActiveContractBean activeContractBean = new ActiveContractBean();
                activeContractBean.setContractId(contractHistBean.getContractId());
                activeContractBean.setPrice(contractHistBean.getContractGrossValue());
                activeContractBean.setSubscriptionStartDate(contractHistBean.getSubscriptionStartDate());
                activeContractBean.setSubscriptionEndDate(contractHistBean.getSubscriptionEndDate());
                activeContractBean.setQuoteValidDate(contractHistBean.getQuoteValidDate());
                activeContractBean.setErenewalQuoteId(contractHistBean.getEncyptRenewalID());
                activeContractBean.setEncryptedContractId(contractHistBean.getEncyContractId());
                activeContractHistList.add(activeContractBean);
            }

        }
        pSessionBean.setActiveContractList(activeContractHistList);
    }


    /**
     * This method is used for invalidate profile repository cache.
     * 
     * @param profile
     * @throws RepositoryException
     */
    private void invalidateCacheProfile(Profile profile) throws RepositoryException {
        ItemDescriptorImpl descriptorImpl = (ItemDescriptorImpl) profile.getProfileTools().getProfileRepository().getItemDescriptor("user");
        if (descriptorImpl instanceof GSAItemDescriptor) {
            GSAItemDescriptor gsaItemDescriptor = (GSAItemDescriptor) descriptorImpl;
            vlogDebug("GSAItemDescriptor : " + gsaItemDescriptor);
            gsaItemDescriptor.invalidateCachedItem(profile.getRepositoryId());
            vlogDebug("Item invalidated in cache::::::::::::::" + profile.getRepositoryId());
        } else {
            vlogDebug("Not able to invalidate item in cache::::::::::::::" + profile.getRepositoryId());
        }
    }
    

       
    /**
     * This Class is used to sort Contract list based on creation date in descending order
     */
    
    public class ContractCreationDateComparator implements Comparator<ContractHistoryBean> {

        @Override
        public int compare(ContractHistoryBean o1, ContractHistoryBean o2) {
            DateFormat format = new SimpleDateFormat(LynxConstants.RESPONSE_DATE_FORMAT,Locale.ENGLISH);
            try {
                if (StringUtils.isBlank(o1.getContractCreationDate())) {
                    return (StringUtils.isBlank(o2.getContractCreationDate())) ? 0 : -1;
                }
                if (StringUtils.isBlank(o2.getContractCreationDate())) {
                    return 1;
                }
                Date date1 = format.parse(o1.getContractCreationDate());
                Date date2 = format.parse(o2.getContractCreationDate());
                return date2.compareTo(date1);
            } catch (ParseException e) {
                return 0;
            }

        }

    }
    

    /**
     * Gets the value of property contractHistoryHelper
     *
     * @return the value of property contractHistoryHelper
     */
    public AgilentContractHistoryHelper getContractHistoryHelper() {
        return mContractHistoryHelper;
    }
    /**
     * Sets the value of property contractHistoryHelper with value pContractHistoryHelper
     *
     * @param pContractHistoryHelper
     *            for setting property contractHistoryHelper
     */
    public void setContractHistoryHelper(AgilentContractHistoryHelper pContractHistoryHelper) {
        mContractHistoryHelper = pContractHistoryHelper;
    }

    /**
     * Gets the value of property triggerProfileCache
     *
     * @return the value of property triggerProfileCache
     */
    public String getTriggerProfileCache() {
        return mTriggerProfileCache;
    }
    /**
     * Sets the value of property triggerProfileCache with value pTriggerProfileCache
     *
     * @param pTriggerProfileCache
     *            for setting property triggerProfileCache
     */
    public void setTriggerProfileCache(String pTriggerProfileCache) {
        mTriggerProfileCache = pTriggerProfileCache;
    }

    /**
     * Gets the value of property configuration
     *
     * @return the value of property configuration
     */
    public AgilentConfigurationSecond getConfiguration() {
        return mConfiguration;
    }

    /**
     * Sets the value of property configuration with value pConfiguration
     *
     * @param pConfiguration
     *            for setting property configuration
     */
    public void setConfiguration(AgilentConfigurationSecond pConfiguration) {
        mConfiguration = pConfiguration;
    }





    
   

}