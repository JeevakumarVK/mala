/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.http.HttpResponse;

import com.agilent.base.crm.bean.ContactDetailsBean;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.profile.crm.ContactPersonBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.profile.crm.LynxContactConstants;
import com.agilent.base.profile.crm.LynxContactConstants.UpdateModes;
import com.agilent.commonstore.crm.helper.AgilentLynxContactServicesHelper;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
* The AgilentLynxContactUpdatesDroplet is used to add a secondary contact to a particular contract/quote

* @version 1.0
* @author Cognizant
* @project Lynx-Phase2
 
*/
public class AgilentLynxContactUpdatesDroplet extends DynamoServlet implements LynxContactConstants {

	public static final ParameterName OUTPUT = ParameterName.getParameterName("output");
	private AgilentLynxContactServicesHelper mLynxUpdatesHelper;
	private ErrorHandlerImpl mErrorHandler;
	

	@SuppressWarnings("unchecked")
	@Override
	public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes)
			throws ServletException, IOException {
		HttpResponse lynxUpdateContactResponse = null;
		Gson gson = new Gson();
		String serviceType = pReq.getParameter(AgilentLynxContactUpdatesDroplet.SERVICE_TYPE);
		vlogInfo("serviceType from Request {0}", serviceType);
		ContactPersonBean contactPersonBean = gson.fromJson(pReq.getReader(), ContactPersonBean.class);
		if(!StringUtils.isBlank(serviceType) && validate(contactPersonBean)){
			try{
				lynxUpdateContactResponse = this.getLynxUpdatesHelper().updateContact(contactPersonBean, serviceType);
				Map<String, Object> lynxAddResponsePayload = (Map<String, Object>) this.getLynxUpdatesHelper().genertePostResponse(lynxUpdateContactResponse);
				boolean isSuccessfulResponse = validateResponse(lynxAddResponsePayload, contactPersonBean.getMode());
				if(!isSuccessfulResponse || DynamoHttpServletResponse.SC_ACCEPTED != lynxUpdateContactResponse.getStatusLine().getStatusCode()){
					logFailureMessage(contactPersonBean.getMode());
					contactPersonBean.setMessage(getFailureMessage(contactPersonBean.getMode()));
					pRes.setStatus( DynamoHttpServletResponse.SC_INTERNAL_SERVER_ERROR);
				}else{
					if(isSuccessfulResponse){
						logSuccessMessage(contactPersonBean.getMode());
						pRes.setStatus(lynxUpdateContactResponse.getStatusLine().getStatusCode());
						contactPersonBean.setMessage(getSuccessMessage(contactPersonBean.getMode()));
						contactPersonBean.setContactDetails(this.getContactDetils(lynxAddResponsePayload));
						if(null != contactPersonBean.getContactDetails()){
							contactPersonBean.getContactDetails()
									.setContactName(contactPersonBean.getContactDetails().getContactFirstName() + " "
											+ contactPersonBean.getContactDetails().getContactLastName());
						}
					}
				}
			}catch (Exception e){	
				vlogError(e, "Error in calling the Add contact Service");				
				contactPersonBean.setMessage(getFailureMessage(contactPersonBean.getMode()));
				pRes.setStatus( DynamoHttpServletResponse.SC_BAD_REQUEST);
			}
		}else{
			pRes.setStatus( DynamoHttpServletResponse.SC_BAD_REQUEST);
		}
		pReq.setParameter(AgilentLynxContactUpdatesDroplet.SERVICE_RESPONSE, contactPersonBean);
		pReq.serviceParameter(OUTPUT, pReq, pRes);
	}

	private String getSuccessMessage(String mode) {
		String message = null;
		if(UpdateModes.I.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.SUCCESS_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_ADD_CONTACT_SUCCESS,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();
		}else if(UpdateModes.S.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.SUCCESS_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_SWITCH_CONTACT_SUCCESS,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();	
		}else if(UpdateModes.D.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.SUCCESS_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_REMOVE_CONTACT_SUCCESS,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();
		}
		return message;
	}

	private String getFailureMessage(String mode) {
		String message = null;
		if(UpdateModes.I.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.ERROR_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_ADD_CONTACT_ERROR,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();
		}else if(UpdateModes.S.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.ERROR_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_SWITCH_CONTACT_ERROR,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();	
		}else if(UpdateModes.D.toString().equalsIgnoreCase(mode)){
			message = new StringBuffer(AgilentLynxContactUpdatesDroplet.ERROR_WITH_HYPHEN).append(
					getErrorHandler().getFormattedErrorMessage(LynxContactConstants.LYNX_UPDATE_REMOVE_CONTACT_ERROR,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL))
					.toString();
		}
		return message;
	}

	private void logSuccessMessage(String mode) {
		if(UpdateModes.I.toString().equalsIgnoreCase(mode)){
			vlogInfo("Contact Added Successfully");	
		}else if(UpdateModes.S.toString().equalsIgnoreCase(mode)){
			vlogInfo("Contact Updated Successfully");	
		}else if(UpdateModes.D.toString().equalsIgnoreCase(mode)){
			vlogInfo("Contact Removed Successfully");	
		}
		
	}

	private void logFailureMessage(String mode) {
		if(UpdateModes.I.toString().equalsIgnoreCase(mode)){
			vlogInfo("Failed to add contact");
		}else if(UpdateModes.S.toString().equalsIgnoreCase(mode)){
			vlogInfo("Failed to update contact");
		}else if(UpdateModes.D.toString().equalsIgnoreCase(mode)){
			vlogInfo("Failed to remove contact");
		}
		
	}

	@SuppressWarnings("unchecked")
	private boolean validateResponse(Map<String, Object> lynxAddResponsePayload, String mode) {
		boolean isValidResponse = Boolean.FALSE;
		List<Map<String, Object>> lynxResponseResult=null;
		Map<String, Object> serviceDetailsMap = null;
		if(UpdateModes.D.toString().equalsIgnoreCase(mode) && null != lynxAddResponsePayload && !lynxAddResponsePayload.isEmpty()){
			isValidResponse = Boolean.TRUE;
		}else if(!UpdateModes.D.toString().equalsIgnoreCase(mode) && null != lynxAddResponsePayload && !lynxAddResponsePayload.isEmpty()){
			serviceDetailsMap = (Map<String, Object>) lynxAddResponsePayload.get(LynxConstants.SERVICE_DETAILS);
			lynxResponseResult = (List<Map<String, Object>>) serviceDetailsMap.get(LynxConstants.RESULTS);
			if(null != lynxAddResponsePayload && !lynxResponseResult.isEmpty()){
				isValidResponse = Boolean.TRUE;
			}
		}
		return isValidResponse;
	}

	private boolean validate(ContactPersonBean contactBean) {
		if (null != contactBean && !StringUtils.isBlank(contactBean.getContactId()) && !StringUtils.isBlank(contactBean.getMode())
				&& !StringUtils.isBlank(contactBean.getTransactionNo())) {
			return true;
		}
		return false;
	}
	

	private ContactDetailsBean getContactDetils(Map<String, Object> serviceResponse) {
		ContactDetailsBean contactDetBean = null;
		Map<String, Object> responseMap = (Map<String, Object>) serviceResponse.get(LynxConstants.SERVICE_DETAILS);		
		if(null != responseMap && !responseMap.isEmpty())
		{
			List<Map<String, Object>> contactResultsList = (List<Map<String, Object>>) responseMap.get(LynxConstants.RESULTS);
			if (contactResultsList != null && !contactResultsList.isEmpty()) {				
				for (Map<String, Object> contactRefItem : contactResultsList) {
					contactDetBean = new ContactDetailsBean();
					this.getLynxUpdatesHelper().setContactBean(contactDetBean, contactRefItem);					
				}
			}
		}
		
		return contactDetBean;
	}
	
	public AgilentLynxContactServicesHelper getLynxUpdatesHelper() {
		return mLynxUpdatesHelper;
	}


	public void setLynxUpdatesHelper(AgilentLynxContactServicesHelper mLynxUpdatesHelper) {
		this.mLynxUpdatesHelper = mLynxUpdatesHelper;
	}
	/**
   	 * @return the errorHandler
   	 */
   	public ErrorHandlerImpl getErrorHandler() {
   		return mErrorHandler;
   	}

   	/**
   	 * @param errorHandler the errorHandler to set
   	 */
   	public void setErrorHandler(ErrorHandlerImpl errorHandler) {
   		this.mErrorHandler = errorHandler;
   	}
}
