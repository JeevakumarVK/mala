/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import static com.agilent.base.commerce.Constants.EMPTY;
import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.base.crm.bean.ContactDetailsBean;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.crm.LynxContactConstants;
import com.agilent.commonstore.crm.helper.AgilentLynxContactServicesHelper;

import atg.core.util.StringUtils;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * The AgilentLynxFetchContactsDroplet fetches the list of contacts associated
 * with Partner Number
 * 
 * @version 1.0
 * @author Cognizant
 * @project Lynx-Phase2
 * 
 */

public class AgilentLynxFetchContactsDroplet extends DynamoServlet implements LynxContactConstants {

	private AgilentLynxContactServicesHelper mAgilentLynxContactServicesHelper;

	private EncryptDecryptHelper mEncryptDecryptHelper;

	@Override
	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
			throws ServletException, IOException {
		List<ContactDetailsBean> contactDetailItems = null;
		String accountId = pRequest.getParameter(AgilentLynxFetchContactsDroplet.ACCOUNT_ID);
		boolean errorMsgFlag = false;
		vlogDebug("AccountId coming from Page {0}", accountId);
		PerformanceMonitor.startOperation("Agilent Fetch Contacts Droplet call starts");
		if (StringUtils.isEmpty(accountId)) {
			pRequest.serviceParameter(EMPTY, pRequest, pResponse);
		} else {
			contactDetailItems = getAgilentLynxContactServicesHelper().fetchContactDetails(accountId);
			if (null != contactDetailItems && !contactDetailItems.isEmpty()) {
				for (ContactDetailsBean cb : contactDetailItems) {
					if (cb.getErrorMsg() != null) {

						errorMsgFlag = true;
						break;
					}
				}
				if (errorMsgFlag) {

					pRequest.setParameter(AgilentLynxFetchContactsDroplet.CONTACT_DETAILS_ITEM, contactDetailItems);
					pRequest.serviceParameter(EMPTY, pRequest, pResponse);
				} else {
					pRequest.setParameter(AgilentLynxFetchContactsDroplet.CONTACT_DETAILS_ITEM, contactDetailItems);
					pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
				}

			}
		}
		PerformanceMonitor.endOperation("Agilent Quote review Droplet call ends");

	}

	/**
	 * @return the mAgilentLynxContactServicesHelper
	 */
	public AgilentLynxContactServicesHelper getAgilentLynxContactServicesHelper() {
		return mAgilentLynxContactServicesHelper;
	}

	/**
	 * @param mAgilentLynxContactServicesHelper
	 *            the mAgilentLynxContactServicesHelper to set
	 */
	public void setAgilentLynxContactServicesHelper(
			AgilentLynxContactServicesHelper mAgilentLynxContactServicesHelper) {
		this.mAgilentLynxContactServicesHelper = mAgilentLynxContactServicesHelper;
	}

	/**
	 * @return the mEncryptDecryptHelper
	 */
	public EncryptDecryptHelper getEncryptDecryptHelper() {
		return mEncryptDecryptHelper;
	}

	/**
	 * @param mEncryptDecryptHelper
	 *            the mEncryptDecryptHelper to set
	 */
	public void setEncryptDecryptHelper(EncryptDecryptHelper mEncryptDecryptHelper) {
		this.mEncryptDecryptHelper = mEncryptDecryptHelper;
	}

}
