/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.profile.crm.LynxContactConstants;
import com.agilent.commonstore.crm.bean.NewAspenQuoteBean;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;


import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
* The AgilentLynxNewQuotesDroplet is used to fetch quotes for a user/contact.

* @version 1.0
* @author Cognizant
* @project Lynx-Phase2
 
*/
public class AgilentLynxNewQuotesDroplet extends DynamoServlet implements LynxContactConstants {

	public static final ParameterName OUTPUT = ParameterName.getParameterName("output");
	private AgilentContractHistoryHelper mContractHistoryHelper;
	private AgilentConfigurationSecond mConfiguration;

	@Override
	public void service(DynamoHttpServletRequest pReq, DynamoHttpServletResponse pRes)
			throws ServletException, IOException {
		String sapAccountId = pReq.getParameter(ACCOUNT_ID);
		List<NewAspenQuoteBean> aspenQuoteDetails = null;
		List<NewAspenQuoteBean> aspenQuoteDetailsAsc = null;
        if (StringUtils.isNotEmpty(sapAccountId)) {
            aspenQuoteDetails = this.getContractHistoryHelper().fetchNewAspenQuoteDetails(sapAccountId);
            if (getConfiguration().isContractSortingEnabled()) {
                Collections.sort(aspenQuoteDetails, new QuoteCreationDateComparator());
                aspenQuoteDetailsAsc = new ArrayList<NewAspenQuoteBean>();
                aspenQuoteDetailsAsc.addAll(aspenQuoteDetails);
                Collections.reverse(aspenQuoteDetailsAsc);
                pReq.setParameter(AgilentLynxNewQuotesDroplet.SERVICE_RESPONSE_ASC, aspenQuoteDetailsAsc);
            }
        }
        pReq.setParameter(AgilentLynxNewQuotesDroplet.SERVICE_RESPONSE, aspenQuoteDetails);
        pReq.serviceParameter(OUTPUT, pReq, pRes);
	}
    
     /**
      * This Class is used to sort Quote list based on creation date in descending order
      */
	
	 public class QuoteCreationDateComparator implements Comparator<NewAspenQuoteBean> {

	        @Override
	        public int compare(NewAspenQuoteBean o1, NewAspenQuoteBean o2) {
	            DateFormat format = new SimpleDateFormat(LynxConstants.RESPONSE_DATE_FORMAT,Locale.ENGLISH);
	            try {
	                if (StringUtils.isBlank(o1.getQuoteCreationDate())) {
	                    return (StringUtils.isBlank(o2.getQuoteCreationDate())) ? 0 : -1;
	                }
	                if (StringUtils.isBlank(o2.getQuoteCreationDate())) {
	                    return 1;
	                }
	                Date date1 = format.parse(o1.getQuoteCreationDate());
	                Date date2 = format.parse(o2.getQuoteCreationDate());
	                return date2.compareTo(date1);
	            } catch (ParseException e) {
	                return 0;
	            }

	        }

	    }
	
	public AgilentContractHistoryHelper getContractHistoryHelper() {
		return mContractHistoryHelper;
	}

	public void setContractHistoryHelper(AgilentContractHistoryHelper contractHistoryHelper) {
		this.mContractHistoryHelper = contractHistoryHelper;
	}
	
	  /**
     * Gets the value of property configuration
     *
     * @return the value of property configuration
     */
    public AgilentConfigurationSecond getConfiguration() {
        return mConfiguration;
    }

    /**
     * Sets the value of property configuration with value pConfiguration
     *
     * @param pConfiguration
     *            for setting property configuration
     */
    public void setConfiguration(AgilentConfigurationSecond pConfiguration) {
        mConfiguration = pConfiguration;
    }
    
    
    
}
