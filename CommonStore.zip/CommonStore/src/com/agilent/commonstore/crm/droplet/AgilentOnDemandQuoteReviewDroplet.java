/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import static com.agilent.base.commerce.Constants.EMPTY;
import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.crm.bean.ReviewQuotesBean;
import com.agilent.base.droplet.AgilentDateTagConverter;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This droplet is used for fetching on-demand quote details.
 */
public class AgilentOnDemandQuoteReviewDroplet extends DynamoServlet {

    private EncryptDecryptHelper mEncryptDecryptHelper;
    private AgilentContractHistoryHelper mAgilentServiceHistoryHelper;
    private Map<String, String> countryToDateFormatMap;
    private boolean mResetRepairQuotePriceDesc;
    private AgilentConfigurationSecond mAgilentConfigurationSecond;

    /**
     * This service method is used for fetching on-demand quote details.
     * 
     * @param pRequest
     * @param pResponse
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        List<ReviewQuotesBean> reviewQuoteItems = null;
        String userCountry = pRequest.getParameter("userCountry");
        String pageParam = pRequest.getParameter("pageParam");
        String quoteId = pRequest.getParameter(LynxConstants.QUOTEID);
        String contrID = pRequest.getParameter("contrID");
        String contractId = pRequest.getParameter(LynxConstants.CONTRACT_ID);
        SessionBean sessionBean = (SessionBean) pRequest.resolveName("/com/agilent/profile/SessionBean");
        reviewQuoteItems = sessionBean.getQuoteItems();
        boolean isEditContact = Boolean.valueOf(pRequest.getParameter("editPage"));
        vlogDebug("reviewQuoteItems present in session {0}", reviewQuoteItems);
        vlogDebug("QuoteId coming from Page {0}", quoteId);
        vlogDebug("contractId coming from Page {0}", contractId);
        vlogDebug("contrID coming from Page {0}", contrID);
        PerformanceMonitor.startOperation("Agilent Quote review Droplet call starts");
        try {
            if (StringUtils.isNotBlank(quoteId)) {
                quoteId = getEncryptDecryptHelper().decrypt(quoteId, "");
            }
            if (StringUtils.isNotBlank(contractId)) {
                contractId = getEncryptDecryptHelper().decrypt(contractId, "");
            }
        } catch (ApplicationException e) {
            vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt");
        }
        Gson gson = new Gson();
        pResponse.setContentType("text/html");
        pResponse.setCharacterEncoding("UTF-8");
        String transactionId = "";
        transactionId = (StringUtils.isNotBlank(contractId)) ? contractId : quoteId;      
        if (StringUtils.isBlank(quoteId) && ("quoteDetails").equalsIgnoreCase(pageParam)) {
            pRequest.serviceParameter(EMPTY, pRequest, pResponse);
        } else if (isEditContact
                || (reviewQuoteItems == null || (reviewQuoteItems != null && reviewQuoteItems.isEmpty()) || (StringUtils.isNotBlank(contractId))
                        || (reviewQuoteItems != null && (StringUtils.isNotBlank(quoteId) && !(quoteId.equalsIgnoreCase(reviewQuoteItems.get(0).getQuoteId()))
                                && ("quoteDetails").equalsIgnoreCase(pageParam)))
                        || (reviewQuoteItems != null && (StringUtils.isNotBlank(contractId) && !(contractId.equalsIgnoreCase(reviewQuoteItems.get(0).getContractId())))))) {
            if (StringUtils.isNotBlank(transactionId)) {
                if (StringUtils.isNotBlank(quoteId) && transactionId.equalsIgnoreCase(quoteId)) {
                    reviewQuoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(transactionId, false, contrID);                   
                    vlogInfo("isCreatedByWeb {0}", sessionBean.isCreatedByWeb());
                    if (sessionBean.isCreatedByWeb()) {
                        getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(reviewQuoteItems);
                    }  
                    sessionBean.setQuoteItems(reviewQuoteItems);
                    vlogInfo("Request is for contract Id {0}", transactionId);
                } else if (StringUtils.isNotBlank(contractId) && transactionId.equalsIgnoreCase(contractId)) {
                    reviewQuoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(transactionId, true, "");
                    vlogInfo("isCreatedByWeb {0}", sessionBean.isCreatedByWeb());
                    if (sessionBean.isCreatedByWeb()) {
                        getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(reviewQuoteItems);
                    }
                    sessionBean.setQuoteItems(reviewQuoteItems);
                    vlogInfo("Request is for Quote Id {0}", transactionId);
                }
                formatQuoteExpireDate(reviewQuoteItems,userCountry);
            }
            setObjectInJson(pResponse, reviewQuoteItems, gson);
            pRequest.setParameter(LynxConstants.QUOTES_LIST, reviewQuoteItems);
            pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
        } else {
         	formatQuoteExpireDate(reviewQuoteItems,userCountry);  
        	boolean createdByWeb=false;
        	String processTypeCode = null;
        	boolean pmOrderFlag=false;
        	boolean repairQuoteFlag=false;
        	if (reviewQuoteItems !=null && reviewQuoteItems.get(0)!=null){           
        		processTypeCode = reviewQuoteItems.get(0).getProcessType(); 
        		pmOrderFlag=reviewQuoteItems.get(0).isPmOrderFlag();
        		if(reviewQuoteItems.get(0).getCreatedByWeb() != null && reviewQuoteItems.get(0).getCreatedByWeb().equalsIgnoreCase(LynxConstants.Y)){
        			createdByWeb=true;
        		}
        	} 
        	if(StringUtils.isNotBlank(processTypeCode) && getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(processTypeCode) && !pmOrderFlag){
        		repairQuoteFlag=true;
        	}
        	if (sessionBean.isCreatedByWeb() || createdByWeb) {    
        		getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(reviewQuoteItems);
        		if(repairQuoteFlag){
        			getAgilentServiceHistoryHelper().resetPriceDescForRepairQuote(reviewQuoteItems);      
        		}
        	} else if(!createdByWeb && repairQuoteFlag){            	
        		getAgilentServiceHistoryHelper().setBudgetQuoteLabelsWithServiceCharge(reviewQuoteItems);
        	}   
        	
        	setObjectInJson(pResponse, reviewQuoteItems, gson);
            pRequest.setParameter(LynxConstants.QUOTES_LIST, reviewQuoteItems);
            pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
        
    }
        PerformanceMonitor.endOperation("Agilent Quote review Droplet call ends");
    }

    /**
     * This method is used set object in JSON format.
     * 
     * @param pResponse
     * @param reviewQuoteItems
     * @param gson
     * @throws IOException
     */
    private void setObjectInJson(DynamoHttpServletResponse pResponse, List<ReviewQuotesBean> reviewQuoteItems, Gson gson) throws IOException {
        if (!reviewQuoteItems.isEmpty()) {
            vlogDebug("Returning the list Items " + reviewQuoteItems);
            pResponse.getWriter().write(gson.toJson(reviewQuoteItems));
        } 
    }
    
    /**
     * This method is used format Expiry Date for Repair Quote and Order.
     * 
     * @param pReviewQuoteItems
     * @param pUserCountry     
     */
    private void formatQuoteExpireDate(List<ReviewQuotesBean> pReviewQuoteItems, String pUserCountry) {
        for (ReviewQuotesBean reviewQuoteBean : pReviewQuoteItems) {
            if (reviewQuoteBean.getQuoteExpireDate() != null) {
                try {
                    String quoteExpireDate = AgilentDateTagConverter.formatDate(reviewQuoteBean.getQuoteExpireDate(), pUserCountry, getCountryToDateFormatMap());
                    reviewQuoteBean.setQuoteExpireDate(quoteExpireDate);
                } catch (ParseException e) {
                    reviewQuoteBean.setQuoteExpireDate(reviewQuoteBean.getQuoteExpireDate());
                }
            }
        }

    }


    /**
     * Gets the value of property encryptDecryptHelper
     *
     * @return the value of property encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }
    /**
     * Sets the value of property encryptDecryptHelper with value pEncryptDecryptHelper
     *
     * @param pEncryptDecryptHelper
     *            for setting property encryptDecryptHelper
     */
    public void setEncryptDecryptHelper(EncryptDecryptHelper pEncryptDecryptHelper) {
        mEncryptDecryptHelper = pEncryptDecryptHelper;
    }

    /**
     * Gets the value of property agilentServiceHistoryHelper
     *
     * @return the value of property agilentServiceHistoryHelper
     */
    public AgilentContractHistoryHelper getAgilentServiceHistoryHelper() {
        return mAgilentServiceHistoryHelper;
    }
    /**
     * Sets the value of property agilentServiceHistoryHelper with value pAgilentServiceHistoryHelper
     *
     * @param pAgilentServiceHistoryHelper
     *            for setting property agilentServiceHistoryHelper
     */
    public void setAgilentServiceHistoryHelper(AgilentContractHistoryHelper pAgilentServiceHistoryHelper) {
        mAgilentServiceHistoryHelper = pAgilentServiceHistoryHelper;
    }

    public Map<String, String> getCountryToDateFormatMap() {
        return countryToDateFormatMap;
    }

    public void setCountryToDateFormatMap(Map<String, String> countryToDateFormatMap) {
        this.countryToDateFormatMap = countryToDateFormatMap;
    }
    
    public boolean isResetRepairQuotePriceDesc() {
		return mResetRepairQuotePriceDesc;
    }

    public void setResetRepairQuotePriceDesc(boolean pResetRepairQuotePriceDesc) {
		this.mResetRepairQuotePriceDesc = pResetRepairQuotePriceDesc;
    }

	/**
	 * @return the agilentConfigurationSecond
	 */
	public AgilentConfigurationSecond getAgilentConfigurationSecond() {
		return this.mAgilentConfigurationSecond;
	}

	/**
	 * @param pAgilentConfigurationSecond the agilentConfigurationSecond to set
	 */
	public void setAgilentConfigurationSecond(AgilentConfigurationSecond pAgilentConfigurationSecond) {
		this.mAgilentConfigurationSecond = pAgilentConfigurationSecond;
	}
    
    
    
}