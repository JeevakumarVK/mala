package com.agilent.commonstore.crm.droplet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;

import atg.core.util.StringUtils;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class AgilentQuoteForwardUrlDroplet extends DynamoServlet implements Constants {

    private EncryptDecryptHelper encryptDecryptHelper;
   
    /* 
     * This service will concatenate the input passed ,encrypt and encode and pass
     * (non-Javadoc)
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest, atg.servlet.DynamoHttpServletResponse)
     */
	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse)
			throws ServletException, IOException {
		vlogInfo("Start--  AgilentQuoteForwardUrlDroplet Service");
		RepositoryItem profile = null;
		String concatenatedPayLoad = null;
		StringBuffer concatenatedInput = new StringBuffer();
		String encryptedPayLoad = null;
		StringBuilder requestURL = new StringBuilder();
		String requestUrlWithQuery = null;
		String crmContactId = null;
		if (StringUtils.isNotBlank(pRequest.getRequestURL().toString())) {
			requestURL = new StringBuilder(pRequest.getRequestURL().toString());
			String queryString = pRequest.getQueryString();
			vlogDebug("AgilentQuoteForwardUrlDroplet RequestUrl {0} QueryString {1}", requestURL, queryString);
			if (StringUtils.isBlank(queryString)) {
				requestUrlWithQuery = requestURL.toString();
			} else {
				requestUrlWithQuery = requestURL.append(QUESTION_MARK).append(queryString).toString();
			}

		}
		if (null != pRequest.getObjectParameter(PROFILE_PARAM)) {
			profile = (RepositoryItem) pRequest.getObjectParameter(PROFILE_PARAM);
			if (null != profile.getPropertyValue(CRM_CONTACT_ID)) {
				crmContactId = (String) profile.getPropertyValue(CRM_CONTACT_ID);
			}
			String quoteId = pRequest.getParameter(QUOTEID);
			String source = pRequest.getParameter(SOURCE);
			vlogDebug("CRM ContactId {0} QuoteId {1} source {2}", crmContactId, quoteId, source);
			if (StringUtils.isNotBlank(crmContactId) && StringUtils.isNotBlank(quoteId)
					&& StringUtils.isNotBlank(source)) {

				concatenatedPayLoad = concatenatedInput.append(quoteId).append(SEMI_COLON).append(crmContactId)
						.append(SEMI_COLON).append(source).toString();
				vlogDebug("CRM ContactId {0} QuoteId {1} source {2}", crmContactId, quoteId, source);
				try {
					encryptedPayLoad = getEncryptDecryptHelper()
							.baseEncrypt(getEncryptDecryptHelper().javascriptAmicableEncrypt(concatenatedPayLoad));
					vlogDebug("EncryptedPayLoad {0}", encryptedPayLoad);
					if (StringUtils.isNotBlank(encryptedPayLoad)) {
						pRequest.setParameter(PAYLOAD, encryptedPayLoad);
						if (StringUtils.isNotBlank(requestUrlWithQuery)) {
							pRequest.setParameter(REQUEST_URL,
									getEncryptDecryptHelper().encrypt(URLEncoder.encode(requestUrlWithQuery, UTF_8)));
						}
						pRequest.serviceLocalParameter(Constants.OUTPUT, pRequest, pResponse);
					} else {
						pRequest.serviceLocalParameter(Constants.EMPTY, pRequest, pResponse);
					}

				} catch (ApplicationException e) {
					vlogError("ApplicationException in AgilentQuoteForwardUrlDroplet {0}", e);
				}
			}
		}
		vlogInfo("End--  AgilentQuoteForwardUrlDroplet Service");
	}

   
    /**
     * @return the encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return encryptDecryptHelper;
    }

    /**
     * @param encryptDecryptHelper
     *            the encryptDecryptHelper to set
     */
    public void setEncryptDecryptHelper(EncryptDecryptHelper encryptDecryptHelper) {
        this.encryptDecryptHelper = encryptDecryptHelper;
    }

  
}