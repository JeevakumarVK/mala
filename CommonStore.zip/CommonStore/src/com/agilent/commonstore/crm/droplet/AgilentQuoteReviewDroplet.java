/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;

import static com.agilent.base.commerce.Constants.EMPTY;
import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


import javax.servlet.ServletException;

import com.agilent.base.crm.bean.ReviewQuoteDetailsInfo;
import com.agilent.base.crm.bean.ReviewQuotesBean;
import com.agilent.base.crm.bean.SecondaryContactsBean;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;


import atg.core.util.StringUtils;
import atg.service.perfmonitor.PerformanceMonitor;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This is a droplet is used to handle service quote review.
 */
public class AgilentQuoteReviewDroplet extends DynamoServlet {

    private AgilentContractHistoryHelper mAgilentServiceHistoryHelper;
    private EncryptDecryptHelper mEncryptDecryptHelper;

    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        List<ReviewQuotesBean> reviewQuoteItems = null;
        List<SecondaryContactsBean> secContactItems = null;
        String showPopup = pRequest.getParameter("showPopup");
        String pageParam = pRequest.getParameter("pageParam");
        String quoteId = pRequest.getParameter(LynxConstants.QUOTEID);
        String contrID = pRequest.getParameter("contrID");
        String plainText = pRequest.getParameter("plainText");
        String contractId = pRequest.getParameter(LynxConstants.CONTRACT_ID);
        String discountPercentage = pRequest.getParameter(LynxConstants.DISCOUNT_PERCENTAGE);
        SessionBean sessionBean = (SessionBean) pRequest.resolveName("/com/agilent/profile/SessionBean");
        reviewQuoteItems = sessionBean.getQuoteItems();
        boolean isEditContact = Boolean.valueOf(pRequest.getParameter("editPage"));
        vlogInfo("reviewQuoteItems present in session {0}", reviewQuoteItems);
        vlogInfo("QuoteId coming from Page {0}", quoteId);
        vlogInfo("contractId coming from Page {0}", contractId);
        vlogInfo("contrID coming from Page {0}", contrID);
        vlogInfo("discountPercentage from page {0}", discountPercentage);
        PerformanceMonitor.startOperation("Agilent Quote review Droplet call starts");
        Map<String,String> additionalReqParams=new HashMap<String,String>();;
        if (StringUtils.isBlank(plainText)) {
            try {
                if (quoteId != null) {
                    quoteId = getEncryptDecryptHelper().decrypt(quoteId, "");
                }
                if (contractId != null) {
                    contractId = getEncryptDecryptHelper().decrypt(contractId, "");
                }
            } catch (ApplicationException e) {
                vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt");
            }
        }
        String transactionId = "";
        Set <String> popupShownSet= sessionBean.getQuoteAdjusted();
        transactionId = (!StringUtils.isEmpty(contractId)) ? contractId : quoteId;
        if ((quoteId == null || quoteId.isEmpty()) && ("quoteDetails").equalsIgnoreCase(pageParam)) {
            pRequest.serviceParameter(EMPTY, pRequest, pResponse);
        } else if (isEditContact || (reviewQuoteItems == null || (reviewQuoteItems != null && reviewQuoteItems.isEmpty()) || (!StringUtils.isEmpty(contractId)) 
                || (reviewQuoteItems != null && (!StringUtils.isEmpty(quoteId) && !(quoteId.equalsIgnoreCase(reviewQuoteItems.get(0).getQuoteId()) 
                        && ("quoteDetails").equalsIgnoreCase(pageParam)))) || (reviewQuoteItems != null && (!StringUtils.isEmpty(contractId) 
                                && !(contractId.equalsIgnoreCase(reviewQuoteItems.get(0).getContractId())))))) {
            if (!StringUtils.isEmpty(transactionId)) {
                if (!StringUtils.isEmpty(quoteId) && transactionId.equalsIgnoreCase(quoteId)) {
                	if(getAgilentServiceHistoryHelper().getAgilentConfigurationSecond().isEnableCRMDiscountCalc() && StringUtils.isNotBlank(discountPercentage)){
                		vlogInfo("discountPercentage is not blank {0}", discountPercentage);
                		additionalReqParams.put(LynxConstants.ONLINE_DISCOUNT, discountPercentage);
                		reviewQuoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(transactionId, false, contrID,additionalReqParams);
                	}
                	else{                		
                		reviewQuoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(transactionId, false, contrID);
                	}
                	vlogInfo("isCreatedByWeb {0}", sessionBean.isCreatedByWeb());
                    if (sessionBean.isCreatedByWeb()) {
                        getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(reviewQuoteItems);
                    }
                    sessionBean.setQuoteItems(reviewQuoteItems);
                    vlogInfo("show popup value for quote {0}  {1}",showPopup,quoteId);
                    if(!StringUtils.isBlank(showPopup) && (showPopup.equalsIgnoreCase("createWarranty")|| (showPopup.equalsIgnoreCase(LynxConstants.CREATE_ERENEWAL)))){
                    popupShownSet.add(quoteId);
                    sessionBean.setQuoteAdjusted(popupShownSet);
                    vlogInfo("adjusted quote list {0}",sessionBean.getQuoteAdjusted());
                    }
                    vlogInfo("Request is for contract Id {0}", transactionId);
                } else if (!StringUtils.isEmpty(contractId) && transactionId.equalsIgnoreCase(contractId)) {
                    reviewQuoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(transactionId, true, "");
                    vlogInfo("isCreatedByWeb {0}", sessionBean.isCreatedByWeb());
                    if (sessionBean.isCreatedByWeb()) {
                        getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(reviewQuoteItems);
                    }
                    sessionBean.setQuoteItems(reviewQuoteItems);
                    vlogInfo("Request is for Quote Id {0}", transactionId);
                }
               
                
                for (ReviewQuotesBean reviewQuoteBean : reviewQuoteItems) {
                    if (secContactItems != null && !secContactItems.isEmpty()) {
                        List<SecondaryContactsBean> contactItems = reviewQuoteBean.getSecContactsList();
                        secContactItems.addAll(contactItems);
                    } else {
                        secContactItems = reviewQuoteBean.getSecContactsList();
                    }
                    List <String> systemIdList=new ArrayList<String>();
                    if(reviewQuoteBean.getQuoteItems() !=null && !reviewQuoteBean.getQuoteItems().isEmpty()){
                    for(ReviewQuoteDetailsInfo details:reviewQuoteBean.getQuoteItems()){
                        systemIdList.add(details.getInstrumentId());
                        vlogInfo("added system id {0}", details.getInstrumentId());
                    }
                    }
                    reviewQuoteBean.setAllSystemIds(systemIdList);
					if (StringUtils.isNotBlank(discountPercentage) && reviewQuoteBean.getGrossAmount()>0) {
						String formattedOnlineDiscountAmt = getAgilentServiceHistoryHelper().fetchOnlineDiscountAmount(
								reviewQuoteBean.getGrossAmount(), new Double(discountPercentage.trim()), reviewQuoteBean.getCurrency());
						reviewQuoteBean.setOnlineDiscountAmount(formattedOnlineDiscountAmt);
					}
                }
            }
            pRequest.setParameter(LynxConstants.QUOTES_LIST, reviewQuoteItems);
            pRequest.setParameter("secondaryContactsList", secContactItems);
            pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
        } else {
            pRequest.setParameter(LynxConstants.QUOTES_LIST, reviewQuoteItems);
            pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
        }
        PerformanceMonitor.endOperation("Agilent Quote review Droplet call ends");
    }

    /**
     * Gets the value of property agilentServiceHistoryHelper
     *
     * @return the value of property agilentServiceHistoryHelper
     */
    public AgilentContractHistoryHelper getAgilentServiceHistoryHelper() {
        return mAgilentServiceHistoryHelper;
    }
    /**
     * Sets the value of property agilentServiceHistoryHelper with value pAgilentServiceHistoryHelper
     *
     * @param pAgilentServiceHistoryHelper
     *            for setting property agilentServiceHistoryHelper
     */
    public void setAgilentServiceHistoryHelper(AgilentContractHistoryHelper pAgilentServiceHistoryHelper) {
        mAgilentServiceHistoryHelper = pAgilentServiceHistoryHelper;
    }

    /**
     * Gets the value of property encryptDecryptHelper
     *
     * @return the value of property encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }
    /**
     * Sets the value of property encryptDecryptHelper with value pEncryptDecryptHelper
     *
     * @param pEncryptDecryptHelper
     *            for setting property encryptDecryptHelper
     */
    public void setEncryptDecryptHelper(EncryptDecryptHelper pEncryptDecryptHelper) {
        mEncryptDecryptHelper = pEncryptDecryptHelper;
    }

   
}
