package com.agilent.commonstore.crm.droplet;

import static com.agilent.base.commerce.Constants.OUTPUT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.bean.ServiceRequestBean;
import com.agilent.commonstore.crm.helper.AgilentServiceRequestHelper;

import atg.core.util.StringUtils;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;
/**
 * @author avneetkaur.m
 * @project Agilent.ServiceRequest
 * 
 */

public class AgilentServiceRequestDroplet extends DynamoServlet {

	private AgilentServiceRequestHelper mServiceRequestHelper;
	@Override
	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
		Profile profile = null;
		profile = (Profile) pRequest.getObjectParameter(Constants.PROFILE_PARAM);
		
		List<ServiceRequestBean> serviceRequestBeanList = null;
		String sapContactID =  null;
		if (!profile.isTransient()) {
				 sapContactID = (String) profile.getPropertyValue(LynxConstants.SAP_CONTACT_NUMBER);
		}
		if (!StringUtils.isEmpty(sapContactID)) {
				serviceRequestBeanList = getServiceRequestHelper().fetchServiceRequestDetails(sapContactID);
				
				pRequest.setParameter(LynxConstants.SERVICE_REQUESTS, serviceRequestBeanList);
				pRequest.serviceParameter(OUTPUT, pRequest, pResponse);
		}
	}
	/**
	 * @return the mServiceRequestHelper
	 */
	public AgilentServiceRequestHelper getServiceRequestHelper() {
		return mServiceRequestHelper;
	}
	/**
	 * @param mServiceRequestHelper the mServiceRequestHelper to set
	 */
	public void setServiceRequestHelper(AgilentServiceRequestHelper mServiceRequestHelper) {
		this.mServiceRequestHelper = mServiceRequestHelper;
	}

}