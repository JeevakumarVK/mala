/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.droplet;



import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * This class is used for processing multiple file upload
 */
public class FileUploadService extends DynamoServlet {
    private File file ;
    /*
     * (non-Javadoc)
     * 
     * @see atg.servlet.DynamoServlet#service(atg.servlet.DynamoHttpServletRequest,
     * atg.servlet.DynamoHttpServletResponse)
     */
    @Override
    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        pResponse.setContentType("application/json");
        java.io.PrintWriter out = pResponse.getWriter();
        DiskFileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);
        ///email id needs to be get from service request
        String email = "naveen@gmail.com";
        StringBuffer strbuf=new StringBuffer("C:\\Users\\564469\\Desktop\\File Upload\\");
        strbuf.append(email).append("\\");
        String filePath=strbuf.toString();
        new File(filePath).mkdirs();
        try {
            List fileItems = upload.parseRequest(pRequest);
            Iterator i =  (Iterator) fileItems.iterator();
            while (((java.util.Iterator) i).hasNext()) {
                FileItem fi = (FileItem) ((java.util.Iterator) i).next();
                if (!fi.isFormField()) {
                    String fileName = fi.getName();
                    if (fileName.lastIndexOf("\\") >= 0) {
                        file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\")));
                    } else {
                        file = new File(filePath + fileName.substring(fileName.lastIndexOf("\\") + 1));
                    }
                    int addFileSize = (int) (file.length() / (1024 * 1024));
                    double fileSizeinMB = 1;
                    if (addFileSize > fileSizeinMB) {
                        out.println(fileName+" file size is more than 1mb");
                    } else {
                        fi.write(file);
                        out.println("Uploaded Filename: " + fileName);
                    }
                }
                
            }
        } catch (Exception ex) {
            out.println("File Upload is not happening due to " + ex);
        }

    }

}
