package com.agilent.commonstore.crm.droplet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.commons.lang3.ArrayUtils;

import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.base.rest.instrumentDetails.LynxInstrumentDetailsResponse;
import com.agilent.base.rest.instrumentDetails.Results;
import com.agilent.base.rest.instrumentDetails.ResultsOuter;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

public class LynxInstrumentDetailsDroplet extends DynamoServlet{
    private static final ParameterName PROFILE = ParameterName.getParameterName("profile");    
    private static final ParameterName OUTPUT = ParameterName.getParameterName("output");
    private static final ParameterName QUOTE_END_DATE = ParameterName.getParameterName("endDate");
    private static final String INSTRUMENT_DETAILS = "LynxInstrumentDetails";
    private static final String CONTACT_KEY="contactId";
    private static final String SYSTEM_IDS="systemIds";
    private static final String PROFILE_COMPONENT="/atg/userprofiling/Profile";
    private static final String INSTRUMENT_NAME="InstrumentName";
    private static final String INSTRUMENT_ID="InstrumentId";
    private static final String EXPIRE_DATE="ExpiredDate";
    private static final String OPPORTUNITY_ID="OpportunityId";
    private static final String SELECTED="Selected";
    private SAPCRMAPIManager mSapCRMAPIManager;
    private String allowedDateFormat;
    private String quoteEndDate;
    private int instrumentDateLowerLimit;
    private int instrumentDateUpperLimit;


    public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        List <Map<String, String>> serviceResponseList=new ArrayList<Map<String, String>>();
        Map<String, String> requestDetailMap = new HashMap<String, String>();
        Map<String, Map<?, ?>> responseDetailMap = new HashMap<String, Map<?, ?>>();
        List<Results> instrumentDetailsList = new ArrayList<Results>();
        List<ResultsOuter> resultOuterList = new ArrayList<ResultsOuter>();
        List<String> existingIdList = new ArrayList<String>();
        String contactId = null;
        LynxInstrumentDetailsResponse resultResponse=null;        
        AgilentProfile profile = null;
        SessionBean sessionBean = null;
        String quoteExpireDate = pRequest.getParameter(QUOTE_END_DATE);
        Locale pLocale = pRequest.getLocale();
        String allSystemIds = pRequest.getParameter(SYSTEM_IDS);
        existingIdList = populateExistingIdList(allSystemIds);
        profile = (AgilentProfile) pRequest.getObjectParameter(PROFILE);
        if (null == profile) {
            profile = (AgilentProfile) pRequest.resolveName(PROFILE_COMPONENT);
        }
        if (null == profile) {
            vlogDebug("Profile is null");
        } else {
            sessionBean = profile.getSessionBean();
            if (sessionBean != null && sessionBean.getValues().containsKey(INSTRUMENT_DETAILS)) {
                
                resultResponse = (LynxInstrumentDetailsResponse) sessionBean.getValues().get(INSTRUMENT_DETAILS);
                vlogDebug("CRM instrument details service response present in session {0} ", resultResponse);
                
            }
            // if No Instrument details is present in session, invoke CRM service and populate instrument details.
            // if Instrument details is already present, return the same as output
            if (resultResponse == null) {
               AgilentPropertyManager propManager = (AgilentPropertyManager) profile.getProfileTools().getPropertyManager();
                if (profile.getPropertyValue(propManager.getCrmContactNumberPropertyName()) != null
                        && !((String) profile.getPropertyValue(propManager.getCrmContactNumberPropertyName())).isEmpty()) {
                    contactId = (String) profile.getPropertyValue(propManager.getCrmContactNumberPropertyName());
                } else if (profile.getPropertyValue(propManager.getSapContactNumberPropertyName()) != null
                        && !((String) profile.getPropertyValue(propManager.getSapContactNumberPropertyName())).isEmpty()) {
                    contactId = (String) profile.getPropertyValue(propManager.getSapContactNumberPropertyName());
                }
                if (!StringUtils.isBlank(contactId)) {
                    requestDetailMap.put(CONTACT_KEY, contactId);
                    vlogDebug("about to invoke CRM instrument details service for {0}", contactId);
                    String crmResponseJson = getSapCRMAPIManager().getLynxInstrumentDetails(requestDetailMap);
                    if (!StringUtils.isBlank(crmResponseJson)) {
                       resultResponse = new Gson().fromJson(crmResponseJson, LynxInstrumentDetailsResponse.class);
                        vlogDebug("Received  response for CRM instrument details service {0} ", resultResponse);
                        sessionBean.getValues().put(INSTRUMENT_DETAILS,resultResponse);
                    }
                }
            } 
                        if (resultResponse != null && resultResponse.getD() != null && resultResponse.getD().getResults() != null
                                && !ArrayUtils.isEmpty(resultResponse.getD().getResults())) {
                            
                            resultOuterList = Arrays.asList(resultResponse.getD().getResults());
                            vlogDebug("resultOuterList {0} ", resultOuterList);

                            for (ResultsOuter rsltOuter : resultOuterList) {
                                vlogDebug("rsltOuter element {0} ", rsltOuter);
                                vlogDebug("rsltOuter element instrument details {0} ", rsltOuter.getInstrumentDetailsSet());
                                if (rsltOuter.getInstrumentDetailsSet().getResults() != null && !ArrayUtils.isEmpty(rsltOuter.getInstrumentDetailsSet().getResults())) {
                                    instrumentDetailsList = Arrays.asList(rsltOuter.getInstrumentDetailsSet().getResults());

                        for (Results nxtResult : instrumentDetailsList) {
                            Map<String, String> lineDetailMap = new HashMap<String, String>();
                            if (instrumentInsideDateRange(quoteExpireDate, pLocale, nxtResult.getExpiredDate(), nxtResult.getInstrumentId())) {
                                // filter instrument with a combination of IbaseId and opportunity id
                                String filterInstrumentKey = nxtResult.getOpportunityId() ;
                                if (!responseDetailMap.containsKey(filterInstrumentKey)) {
                                    lineDetailMap.put(INSTRUMENT_NAME, nxtResult.getInstrumentName());
                                    lineDetailMap.put(INSTRUMENT_ID, nxtResult.getInstrumentId());
                                    lineDetailMap.put(EXPIRE_DATE, nxtResult.getExpiredDate());
                                    lineDetailMap.put(OPPORTUNITY_ID, nxtResult.getOpportunityId());
                                    lineDetailMap.put(SELECTED, String.valueOf(instrumentExists(existingIdList, nxtResult.getInstrumentId())));
                                    vlogDebug("Instrument details {0}", lineDetailMap);
                                    responseDetailMap.put(filterInstrumentKey, lineDetailMap);
                                    vlogDebug("Response details Map {0}", responseDetailMap);
                                    serviceResponseList.add(lineDetailMap);
                                } else {
                                    vlogDebug("Instrument Key {0} already exists", filterInstrumentKey);
                                }
                            }
                        }
                                }
                            }
                           
                        }

                    
               
           
        }
        pRequest.setParameter(INSTRUMENT_DETAILS, serviceResponseList);
        pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
    }

    /**
     * Create existing instrument id list from request parameter
     * @param systemIdList
     * @param allSystemIds
     * @return 
     */
    private List<String> populateExistingIdList(String allSystemIds) {
        List <String> systemIdList=new ArrayList<String>();
        if(!StringUtils.isBlank(allSystemIds)){
            String[] systemIdArray=allSystemIds.split(",");
            for(int idCount=0;idCount<systemIdArray.length;idCount++){
                String nxtId=systemIdArray[idCount];
                nxtId=nxtId.trim();
                systemIdList.add(nxtId);
            }
            
        }
        return systemIdList;
    }
   /**
    * returns true if instrument exists in the existing instrument list
    * @param pSystemIdList
    * @param pInstrumentId
    * @return
    */
    private boolean instrumentExists(List<String> pSystemIdList, String pInstrumentId) {
        boolean instrumentexist = false;
        if (null != pSystemIdList && !pSystemIdList.isEmpty()) {
            vlogDebug("system Id list {0} and instrumeId in context {1} ",pSystemIdList,pInstrumentId);
            if (pSystemIdList.contains(pInstrumentId))
                instrumentexist = true;
          }
        vlogDebug("instrument exists {0}  ",instrumentexist);
        return instrumentexist;
    }
   /**
    * Checks if Instrument expiry date falls after (quote end date -12 months) and before (quote end date- 3 months)
    * @param pQuoteExpireDate
    * @param pLocale
    * @param instrumentEndDate
    * @param pInstrumentId
    * @return
    */
    private boolean instrumentInsideDateRange(String pQuoteExpireDate,Locale pLocale, String instrumentEndDate, String pInstrumentId) {
        boolean inSideDateRange=false;
        try {
           
            SimpleDateFormat sdf = new SimpleDateFormat(getAllowedDateFormat(),pLocale);
            Date quoteDate =sdf.parse(pQuoteExpireDate);
            vlogDebug("quote end date {0} and instrument under context {1}  ",quoteDate,pInstrumentId);
            //define start and end range based on quote end date
            //end date is 12 months before quote end date and start date is 3 months before quote end date
            Date dateRangeEnd=null, dateRangeStart=null;
            Calendar endDateClaender = Calendar.getInstance(pLocale);
            Calendar startdateClaender = Calendar.getInstance(pLocale);
            endDateClaender.setTime(quoteDate);
            startdateClaender.setTime(quoteDate);
            endDateClaender.add(Calendar.MONTH, getInstrumentDateLowerLimit());
            endDateClaender.add(Calendar.DATE,-1);
            startdateClaender.add(Calendar.MONTH, getInstrumentDateUpperLimit());
            startdateClaender.add(Calendar.DATE, +1);
            dateRangeEnd=endDateClaender.getTime();
            dateRangeStart=startdateClaender.getTime();
            //Instrument expiration date has to be incremented by 1 day
            Date instrumentExpDate=sdf.parse(instrumentEndDate); 
            Calendar instrumentDateClaender = Calendar.getInstance(pLocale);
            instrumentDateClaender.setTime(instrumentExpDate);
            instrumentDateClaender.add(Calendar.DATE, +1);
            instrumentExpDate=instrumentDateClaender.getTime();
            vlogDebug("date range for filtering {0} to {1} and instrument expiry date {2}  ",dateRangeStart,dateRangeEnd,instrumentExpDate);
            //check if instrument expire date is after end date and instrument expire date is before start date
            //dateRangeStart: 10/15/18 12:00 AM to dateRangeEnd: 1/15/18 12:00 AM and instrument expiry date 7/28/18 12:00 AM: will be inside date range
            if(instrumentExpDate.after(dateRangeEnd) && instrumentExpDate.before(dateRangeStart)){
                inSideDateRange=true;
            }
            
        } catch (ParseException e) {
            vlogError("unable to parse date for date range filtering" + e);
        }
        vlogDebug("inSideDateRange is {0}  ",inSideDateRange);
        return inSideDateRange;
    }

    public SAPCRMAPIManager getSapCRMAPIManager() {
        return mSapCRMAPIManager;
    }

    public void setSapCRMAPIManager(SAPCRMAPIManager pSapCRMAPIManager) {
        mSapCRMAPIManager = pSapCRMAPIManager;
    }


    public String getAllowedDateFormat() {
        return allowedDateFormat;
    }

    public void setAllowedDateFormat(String pAllowedDateFormat) {
        allowedDateFormat = pAllowedDateFormat;
    }

    public int getInstrumentDateLowerLimit() {
        return instrumentDateLowerLimit;
    }

    public void setInstrumentDateLowerLimit(int pInstrumentDateLowerLimit) {
        instrumentDateLowerLimit = pInstrumentDateLowerLimit;
    }
    
    public int getInstrumentDateUpperLimit() {
        return instrumentDateUpperLimit;
    }

    public void setInstrumentDateUpperLimit(int pInstrumentDateUpperLimit) {
        instrumentDateUpperLimit = pInstrumentDateUpperLimit;
    }
    
    public String getQuoteEndDate() {
        return quoteEndDate;
    }

    public void setQuoteEndDate(String pQuoteEndDate) {
        quoteEndDate = pQuoteEndDate;
    }

}
