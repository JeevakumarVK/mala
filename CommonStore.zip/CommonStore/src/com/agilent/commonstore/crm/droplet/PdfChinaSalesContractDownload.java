package com.agilent.commonstore.crm.droplet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Locale;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.AgilentOrderHolder;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.common.services.OrderDetails;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.commonstore.crm.helper.PdfChinaOrderDownloadHelper;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfDestination;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.servlet.RequestLocale;


public class PdfChinaSalesContractDownload  extends DynamoServlet {


    private AgilentProfile mProfile;
    private PdfChinaOrderDownloadHelper pdfChinaOrderDownloadHelper;
    private String stampImagePath;
    public static String stampImage;
    public static final String USER_COUNTRY="userCountry";
    private AgilentOrderHolder shoppingCart = null;
    public static String footerImage;
    private String footerTextOne;
    private String footerTextTwo;
    public static String CHINESE_FONT_LIGHT = "STSong-Light";
    public static String CHINESE_FONT_STD = "STSongStd-Light";
    public static String CHINESE_ENCODING = "UniGB-UCS2-H";
    private static final ParameterName OUTPUT = ParameterName.getParameterName("output");
    private static final String PARAM_ERROR_MESSAGE="errorMsg";
    private static final String OPARAM_ERROR ="error";
    private AgilentConfigurationSecond configurationSecond;
    private String mFooterTextOneForC9;
    private String mFooterTextTwoForC9;
    private String mStampImageForATTS;
        
        
    /*   private static final String FILENETACCESS_ERROR = "invoice.pdfdownload.error";
   private InternationalizationService mInternationalizationService;*/

	/**
	 * @return the configurationSecond
	 */
	public AgilentConfigurationSecond getConfigurationSecond() {
		return configurationSecond;
	}

	/**
	 * @param configurationSecond the configurationSecond to set
	 */
	public void setConfigurationSecond(AgilentConfigurationSecond configurationSecond) {
		this.configurationSecond = configurationSecond;
	}


	public void service(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        vlogInfo("PdfChinaSalesContractDownload.MYA --START--");
        Document document = null;
        PdfPTable pdfTable1 = null;
        PdfPTable pdfTable2 = null;
        String fontPath = "";
        PdfWriter writer = null;
        String FILE_NAME =null;
        String salesOrg = null;
        OrderDetails orderDetails = (OrderDetails) pRequest.getObjectParameter("orderDetails");
        String pageName = pRequest.getParameter("pageName");
        String orderId = pRequest.getParameter("orderId");
        String invoiceType = pRequest.getParameter("invoiceType");
        String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
        String imageOutputPath = pRequest.getRealPath("") + File.separator + "images";
        String finalImagePath=null;
        AgilentOrder lastOrder = (AgilentOrder) getShoppingCart().getLast();
        footerImage = imageOutputPath + File.separator + "sureFooterImage.jpg";
        footerImage = getPath(footerImage);
        try {   
        	    vlogDebug("PdfChinaSalesContractDownload. --orderDetails-- {0}", orderDetails);
            if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
                fontPath = pRequest.getRealPath("");
                fontPath = getPath(fontPath);
               // ByteArrayOutputStream baos = new ByteArrayOutputStream();
               // document = new Document(PageSize.A4, 50, 50, 50, 50);
               //  PdfDocument pdfDoc =((PdfWriter)writter.getInstance(document, baos)).getPD;
               //  writer = PdfWriter.getInstance(document, pResponse.getOutputStream());
                 
                RequestLocale requestLocale = pRequest.getRequestLocale();
                Locale locale = requestLocale.getLocale();
                salesOrg =orderDetails.getSalesOrg().toString();
                if(StringUtils.isNotBlank(salesOrg)&& getPdfChinaOrderDownloadHelper().getSalesOrgListForRUO()!=null &&
                		getPdfChinaOrderDownloadHelper().getSalesOrgListForRUO().contains(salesOrg)){
                	pdfTable1 = this.getPdfChinaOrderDownloadHelper().getChinaOrderforC9AsPDF(
                    		fontPath, locale, orderDetails, lastOrder, orderId,
                    		getProfile(), invoiceType, pageName);
                }else{
                	pdfTable1 = this.getPdfChinaOrderDownloadHelper().getChinaOrderAsPDF(
                    		fontPath, locale, orderDetails, lastOrder,
                    		orderId,
                    		getProfile(), invoiceType, pageName);
                }
                document = new Document(PageSize.A4, 50, 50, 50, 50);
                pResponse.reset();
                pResponse.setContentType("application/pdf");
                pResponse.setHeader("Content-disposition", "attachment; filename=\"OrderDetails-" + orderId + ".pdf\"");
                FILE_NAME="OrderDetails-" + orderId + ".pdf";
                writer = PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
                if(StringUtils.isNotBlank(salesOrg)&& getPdfChinaOrderDownloadHelper().getSalesOrgListForRUO()!=null &&
                		getPdfChinaOrderDownloadHelper().getSalesOrgListForRUO().contains(salesOrg)){
                	document.open();
                    writer.setPageEvent(new HeaderFooterForC9());
                    document.add(pdfTable1);
                    document.newPage();
                    pdfTable2 = this.getPdfChinaOrderDownloadHelper().staticSection(orderDetails, lastOrder, pageName);
                    document.add(pdfTable2);
                    int yCoordinate = (int) writer.getVerticalPosition(false);
                    PdfDestination pdfDest = new PdfDestination(PdfDestination.XYZ, 0, document.getPageSize().getHeight(), 1f);
                    PdfAction action = PdfAction.gotoLocalPage(1, pdfDest, writer);
                    writer.setOpenAction(action);
                    vlogDebug("PdfChinaSalesContractDownload.MYA --END--");
                    document.close();
                    /** add stamp Image start**/
                    PdfReader reader= new PdfReader(FILE_NAME); 
                    PdfStamper stamper = new PdfStamper(reader, pResponse.getOutputStream());
                    stampImage = imageOutputPath + File.separator + getStampImageForATTS();
                    finalImagePath = getPath(stampImage);
                    addStampImageOnChinaPDF(reader, stamper, finalImagePath, yCoordinate);
                    stamper.close();
                    reader.close();
                	
                }else{
                	document.open();
                    writer.setPageEvent(new HeaderFooter());
                    document.add(pdfTable1);
                    document.newPage();
                    pdfTable2 = this.getPdfChinaOrderDownloadHelper().staticSection(orderDetails, lastOrder,
                    		pageName);
                    document.add(pdfTable2);
                    PdfDestination pdfDest = new PdfDestination(PdfDestination.XYZ, 0, document.getPageSize().getHeight(), 1f);
                    PdfAction action = PdfAction.gotoLocalPage(1, pdfDest, writer);
                    writer.setOpenAction(action);
                    vlogDebug("PdfChinaSalesContractDownload.MYA --END--");
                    document.close();
                    /** add stamp Image start**/
                    PdfReader reader= new PdfReader(FILE_NAME); 
                    PdfStamper stamper = new PdfStamper(reader, pResponse.getOutputStream());
                    stampImage = imageOutputPath + File.separator + getStampImagePath();
                    finalImagePath = getPath(stampImage);
                    addStampImageOnPDF(reader, stamper, finalImagePath, userCountry);
                    stamper.close();
                    reader.close();	
                }
                /** add stamp Image End**/
                vlogInfo("PdfChinaSalesContractDownload --End Successfully--");
                if(getConfigurationSecond().isAddStampCheck()){
                   pRequest.serviceLocalParameter(OUTPUT, pRequest, pResponse);
            	}}
        } catch (DocumentException de) {
            vlogError("DocumentException while downloading PDF", de);
           
        } catch (Exception e) {
            vlogError("Error while downloading PDF. Refer the trace for details.", e);
            if(getConfigurationSecond().isAddStampCheck()){
               pRequest.serviceLocalParameter(OPARAM_ERROR, pRequest, pResponse);
            }
        }
    }


	/**
     * Adds China stamp image on the PDF.
     * 
     * @param reader the reader
     * @param stamper the stamper
     * @param finalImagePath the finalImagePath
     * @param userCountry the userCountry
     * @throws BadElementException
     * @throws MalformedURLException
     * @throws IOException
     * @throws DocumentException
     */
    public void addStampImageOnPDF(final PdfReader reader, final PdfStamper stamper, final String finalImagePath, final String userCountry)
            throws BadElementException, MalformedURLException, IOException, DocumentException {

        getPdfChinaOrderDownloadHelper().addStampImageOnPDF(reader, stamper, finalImagePath, userCountry);
        getPdfChinaOrderDownloadHelper().addConnectiveStampOnPDF(reader, stamper, finalImagePath);
    }
    
    public void addStampImageOnChinaPDF(final PdfReader reader, final PdfStamper stamper, final String finalImagePath, final Integer yCoordinate)
            throws BadElementException, MalformedURLException, IOException, DocumentException {

        getPdfChinaOrderDownloadHelper().addStampImageOnChinaPDF(reader, stamper, finalImagePath,yCoordinate);
        getPdfChinaOrderDownloadHelper().addConnectiveStampOnPDF(reader, stamper, finalImagePath);
    }

 
    /**
     * Sanitizing string.
     * 
     * @param pStr the pStr
     * @return String
     */
    public String getPath(String pStr) {
        pStr = pStr.replace("\\", "/");
        return pStr;
    }

    /**
     * Header Footer
     */
    class HeaderFooter extends PdfPageEventHelper {

        public void onEndPage(PdfWriter writer, Document document) {
            writer.getDirectContent();
            String currentPage = String.valueOf(writer.getCurrentPageNumber());
            Image imageHeader = null;
            try {
                BaseFont robotoFont = getRoboFont();
                Font footerFont = new Font(robotoFont, 7);
                imageHeader = Image.getInstance(footerImage);

                imageHeader.scaleAbsolute(140f, 32f);
                imageHeader.setAbsolutePosition(20f, 20f);

                vlogDebug("inside inner class...");
                Chunk headerChunk = new Chunk(imageHeader, 0, 0);
                if (!currentPage.equals("1")) {
                    ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                            new Phrase(headerChunk), 
                            document.leftMargin() + 5, document.top() , 0);
                }            
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(currentPage),
                        document.leftMargin() + 250, document.bottomMargin() -20, 0);
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(getFooterTextOne(), footerFont),
                        document.leftMargin() + 20, document.bottomMargin() - 8, 0);            
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(getFooterTextTwo(), footerFont),
                        document.leftMargin() + 20, document.bottomMargin() - 23, 0);
            } catch (BadElementException e) {
                vlogError("BadElementException while adding HeaderFooter", e);
            } catch (MalformedURLException e) {
                vlogError("MalformedURLException while adding HeaderFooter", e);
            } catch (IOException e) {
                vlogError("IOException while adding HeaderFooter", e);
            } catch (DocumentException e) {
                vlogError("DocumentException while adding HeaderFooter", e);
            }
        }
    }
    class HeaderFooterForC9 extends PdfPageEventHelper {

        public void onEndPage(PdfWriter writer, Document document) {
            writer.getDirectContent();
            String currentPage = String.valueOf(writer.getCurrentPageNumber());
            Image imageHeader = null;
            try {
                BaseFont robotoFont = getRoboFont();
                Font footerFont = new Font(robotoFont, 5);
                imageHeader = Image.getInstance(footerImage);

                imageHeader.scaleAbsolute(140f, 32f);
                imageHeader.setAbsolutePosition(20f, 20f);

                vlogDebug("inside inner class...");
                Chunk headerChunk = new Chunk(imageHeader, 0, 0);
                if (!currentPage.equals("1")) {
                    ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                            new Phrase(headerChunk), 
                            document.leftMargin() + 5, document.top() , 0);
                }   
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(currentPage),
                        document.leftMargin() + 250, document.bottomMargin() -20, 0);
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(getFooterTextOneForC9(), footerFont),
                        document.leftMargin() + 20, document.bottomMargin() - 8, 0);            
                ColumnText.showTextAligned(writer.getDirectContent(), 0, 
                        new Phrase(getFooterTextTwoForC9(), footerFont),
                        document.leftMargin() + 20, document.bottomMargin() - 23, 0);
            } catch (BadElementException e) {
                vlogError("BadElementException while adding HeaderFooter", e);
            } catch (MalformedURLException e) {
                vlogError("MalformedURLException while adding HeaderFooter", e);
            } catch (IOException e) {
                vlogError("IOException while adding HeaderFooter", e);
            } catch (DocumentException e) {
                vlogError("DocumentException while adding HeaderFooter", e);
            }
        }
    }
    
    /**
     * Returns chinese font.
     * 
     * @return BaseFont
     * @throws DocumentException
     * @throws IOException
     */
    public BaseFont getRoboFont() throws DocumentException, IOException {
        BaseFont robotoFont = BaseFont.createFont(CHINESE_FONT_STD, CHINESE_ENCODING, BaseFont.NOT_EMBEDDED);
        return robotoFont;
    }
    
    /**
     * Gets the value of property profile
     *
     * @return the value of property profile
     */
    public AgilentProfile getProfile() {
        return mProfile;
    }
    
    /**
     * Sets the value of property profile with value pProfile
     *
     * @param pProfile
     *            for setting property profile
     */
    public void setProfile(AgilentProfile pProfile) {
        mProfile = pProfile;
    }


    /**
	 * @return the pdfChinaOrderDownloadHelper
	 */
	public PdfChinaOrderDownloadHelper getPdfChinaOrderDownloadHelper() {
		return pdfChinaOrderDownloadHelper;
	}


	/**
	 * @param pdfChinaOrderDownloadHelper the pdfChinaOrderDownloadHelper to set
	 */
	public void setPdfChinaOrderDownloadHelper(
			PdfChinaOrderDownloadHelper pdfChinaOrderDownloadHelper) {
		this.pdfChinaOrderDownloadHelper = pdfChinaOrderDownloadHelper;
	}



    /**
	 * @return the stampImagePath
	 */
	public String getStampImagePath() {
		return stampImagePath;
	}


	/**
	 * @param stampImagePath the stampImagePath to set
	 */
	public void setStampImagePath(String stampImagePath) {
		this.stampImagePath = stampImagePath;
	}


	/**
	 * @return the shoppingCart
	 */
	public AgilentOrderHolder getShoppingCart() {
		return shoppingCart;
	}


	/**
	 * @param shoppingCart the shoppingCart to set
	 */
	public void setShoppingCart(AgilentOrderHolder shoppingCart) {
		this.shoppingCart = shoppingCart;
	}

	/**
	 * @return the footerImage
	 */
	public static String getFooterImage() {
		return footerImage;
	}


	/**
	 * @param footerImage the footerImage to set
	 */
	public static void setFooterImage(String footerImage) {
		PdfChinaSalesContractDownload.footerImage = footerImage;
	}


	/**
	 * @return the footerTextOne
	 */
	public String getFooterTextOne() {
		return footerTextOne;
	}


	/**
	 * @param footerTextOne the footerTextOne to set
	 */
	public void setFooterTextOne(String footerTextOne) {
		this.footerTextOne = footerTextOne;
	}


	/**
	 * @return the footerTextTwo
	 */
	public String getFooterTextTwo() {
		return footerTextTwo;
	}


	/**
	 * @param footerTextTwo the footerTextTwo to set
	 */
	public void setFooterTextTwo(String footerTextTwo) {
		this.footerTextTwo = footerTextTwo;
	}


	/**
	 * @return the mFooterTextTwoForC9
	 */
	public String getFooterTextTwoForC9() {
		return mFooterTextTwoForC9;
	}


	/**
	 * @param mFooterTextTwoForC9 the mFooterTextTwoForC9 to set
	 */
	public void setFooterTextTwoForC9(String pFooterTextTwoForC9) {
		this.mFooterTextTwoForC9 = pFooterTextTwoForC9;
	}


	/**
	 * @return the mFooterTextOneForC9
	 */
	public String getFooterTextOneForC9() {
		return mFooterTextOneForC9;
	}


	/**
	 * @param mFooterTextOneForC9 the mFooterTextOneForC9 to set
	 */
	public void setFooterTextOneForC9(String pFooterTextOneForC9) {
		this.mFooterTextOneForC9 = pFooterTextOneForC9;
	}
	
    /**
     * @return the stampImageForATTS
     */
    public String getStampImageForATTS() {
        return mStampImageForATTS;
    }


    /**
     * @param stampImageForATTS the stampImageForATTS to set
     */
    public void setStampImageForATTS(String stampImageForATTS) {
        this.mStampImageForATTS = stampImageForATTS;
    }
	
}
