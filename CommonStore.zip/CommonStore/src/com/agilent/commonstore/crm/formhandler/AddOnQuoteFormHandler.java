package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;

import javax.servlet.ServletException;

import com.agilent.base.crm.bean.RequestForAddOnQuoteBean;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

public class AddOnQuoteFormHandler extends GenericFormHandler {

    private SAPCRMAPIManager mSapCRMAPIManager;
    private EncryptDecryptHelper mEncryptDecryptHelper;
    private SessionBean mSessionBean;
    private String mRequestAddOnQuoteSuccessUrl;
    private String mRequestAddOnQuoteErrorUrl;
    private String postData;

    public boolean handleRequestAddOnQuote(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {

        vlogDebug("AddOnQuoteFormHandler.handleRequestAddOnQuote Entering");
        vlogDebug("Post Data = {0}", getPostData());

        Gson gson = new Gson();

        if (StringUtils.isNotBlank(getPostData())) {
            try {
                RequestForAddOnQuoteBean requestBean = gson.fromJson(getPostData(), RequestForAddOnQuoteBean.class);
                if (requestBean != null) {
                    vlogDebug("RequestForAddOnQuoteBean ContactId = " + requestBean.getContactId());
                    vlogDebug("RequestForAddOnQuoteBean QuoteId = " + requestBean.getQuoteId());
                    vlogDebug("RequestForAddOnQuoteBean AdjustedQuote = " + requestBean.getAdjustedQuote());
                }

                int responseCode = getSapCRMAPIManager().requestForAddOnQuote(requestBean);
                if (responseCode != 201) {
                    addFormException(new DropletException("Error Response in RequestAddOnQuote CRM Service"));
                }
                vlogDebug("Success responseJson from CRM Service responseCode = {0}", responseCode);
                vlogDebug("AddOnQuoteFormHandler.handleRequestAddOnQuote Exiting");
            } catch (JsonSyntaxException ex) {
                addFormException(new DropletException("Invalid Input data"));
                vlogError(ex, "JsonSyntaxException found in the input data");
            }
        } else {
            addFormException(new DropletException("Missing input data"));
            vlogError("Missing required input data");
        }
        return checkFormRedirect(getRequestAddOnQuoteSuccessUrl(), getRequestAddOnQuoteErrorUrl(), request, response);
    }

    /**
     * @return the sapCRMAPIManager
     */
    public SAPCRMAPIManager getSapCRMAPIManager() {
        return mSapCRMAPIManager;
    }

    /**
     * @param sapCRMAPIManager
     *            the sapCRMAPIManager to set
     */
    public void setSapCRMAPIManager(SAPCRMAPIManager sapCRMAPIManager) {
        this.mSapCRMAPIManager = sapCRMAPIManager;
    }

    /**
     * @return the encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }

    /**
     * @param encryptDecryptHelper
     *            the encryptDecryptHelper to set
     */
    public void setEncryptDecryptHelper(EncryptDecryptHelper encryptDecryptHelper) {
        this.mEncryptDecryptHelper = encryptDecryptHelper;
    }

    public void setSessionBean(SessionBean pSessionBean) {
        mSessionBean = pSessionBean;
    }

    /**
     * @return the requestAddOnQuoteSuccessUrl
     */
    public String getRequestAddOnQuoteSuccessUrl() {
        return mRequestAddOnQuoteSuccessUrl;
    }

    /**
     * @param requestAddOnQuoteSuccessUrl
     *            the requestAddOnQuoteSuccessUrl to set
     */
    public void setRequestAddOnQuoteSuccessUrl(String requestAddOnQuoteSuccessUrl) {
        this.mRequestAddOnQuoteSuccessUrl = requestAddOnQuoteSuccessUrl;
    }

    /**
     * @return the requestAddOnQuoteErrorUrl
     */
    public String getRequestAddOnQuoteErrorUrl() {
        return mRequestAddOnQuoteErrorUrl;
    }

    /**
     * @param requestAddOnQuoteErrorUrl
     *            the requestAddOnQuoteErrorUrl to set
     */
    public void setRequestAddOnQuoteErrorUrl(String requestAddOnQuoteErrorUrl) {
        this.mRequestAddOnQuoteErrorUrl = requestAddOnQuoteErrorUrl;
    }

    /**
     * @return the postData
     */
    public String getPostData() {
        return postData;
    }

    /**
     * @param postData
     *            the postData to set
     */
    public void setPostData(String postData) {
        this.postData = postData;
    }

}
