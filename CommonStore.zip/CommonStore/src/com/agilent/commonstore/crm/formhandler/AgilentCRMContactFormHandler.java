package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import org.apache.commons.lang3.StringUtils;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.platform.util.AgilentEmailTools;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.rest.addOnProducts.PartnerResultSet;
import com.agilent.base.rest.addOnProducts.ProductAddOnsResponse;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.profile.idm.functions.IdmServiceConstants;
import com.google.gson.Gson;

import atg.droplet.GenericFormHandler;
import atg.nucleus.naming.ParameterName;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.ServletUtil;
import atg.userprofiling.Profile;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;


/********This class is used for saving contact Info of user and sending email to sales rep*************/

public class AgilentCRMContactFormHandler extends GenericFormHandler {
    private static final ParameterName PROFILE = ParameterName.getParameterName("profile");  
    private static final String PROFILE_COMPONENT="/atg/userprofiling/Profile";
    private static final String PARTNERSET="00000014";
    private static final String PARTNERSET_PARTNO="00000001";
	private String userName;
	private String phoneNumber;
	private String email;
	private String contactMethod;
	private String crmInquiry;
	private String message;
	private SAPCRMAPIManager sapCRMAPIManager;
	private MutableRepository requestQuoteRepository;
	private TemplateEmailSender templateEmailSender;
	private TemplateEmailInfoImpl agilentContactFormTemplateInfo;
	private String subject;
	private String messageFrom;
	private String messageCc;
	private String messageTo;
	private String contractId;
	private String salesEmail;
	private String subscriptionStartDate;
	private String subscriptionEndDate;
	private String salesName;
	private String quoteId;
	private String contactCountry;
	private String contactRegion;
	private boolean noEmailTosalesRep;
	private AgilentEmailTools mEmailTools; 
	private SessionBean mSessionBean;
	private String[] productArray;
	private AgilentConfigurationSecond agilentConfigurationSecond;
	

	
	/****saving contact information of user into repository *********/
	public void handleCRMcontactForm(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException, TemplateEmailException {
        boolean rollback=false;
		try {
			Profile profile = (Profile) ServletUtil.getCurrentUserProfile();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
            Calendar cal = Calendar.getInstance();
            try {
				Date currentDate = dateFormat.parse(dateFormat.format(cal.getTime()));
			
			final MutableRepositoryItem contactFormRepoItem = getRequestQuoteRepository().createItem("CRMContactForm");
			Map<String, String> contactInfo = new HashMap<String, String>();
			contactInfo.put("name", getUserName());
			contactInfo.put("phoneNumber", getPhoneNumber());
			contactInfo.put("email", getEmail());
			contactInfo.put("contactMethod", getContactMethod());
			contactInfo.put("crmInquiry", getCrmInquiry());
			contactInfo.put("message", getMessage());
			if(!profile.isTransient()){
				contactFormRepoItem.setPropertyValue("profileId", profile.getRepositoryId());	
				contactFormRepoItem.setPropertyValue("loginName", profile.getPropertyValue("adLoginName"));
			}
			contactFormRepoItem.setPropertyValue("name", getUserName());
			contactFormRepoItem.setPropertyValue("phoneNumber", getPhoneNumber());
			contactFormRepoItem.setPropertyValue("email", getEmail());
			contactFormRepoItem.setPropertyValue("contactMethod", getContactMethod());
			contactFormRepoItem.setPropertyValue("crmInquiry", getCrmInquiry());
			contactFormRepoItem.setPropertyValue("message", getMessage());
			contactFormRepoItem.setPropertyValue("contactDate", currentDate);
			contactFormRepoItem.setPropertyValue("contractId", getContractId());
			contactFormRepoItem.setPropertyValue("quoteId", getQuoteId());
			contactFormRepoItem.setPropertyValue("salesName", getSalesName());
			contactFormRepoItem.setPropertyValue("salesEmail", getSalesEmail());
			contactFormRepoItem.setPropertyValue("contactCountry", getContactCountry());
			contactFormRepoItem.setPropertyValue("contactRegion", getContactRegion());
			getRequestQuoteRepository().addItem(contactFormRepoItem);
			vlogDebug("Contact Information of user and sales represntative saved into repo with User Name {0}",getUserName());
			sendEmailToUser(contactInfo);
            } catch (ParseException e) {
				e.printStackTrace();
				rollback=true;
			}
		} catch (RepositoryException e) {
			e.printStackTrace();
			rollback=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			rollback=true;
		}
		finally{
			if(rollback)
			{
				final String json = new Gson().toJson(rollback);
				vlogDebug("Json in String {0} ", json);
				pResponse.setContentType("application/json");
				pResponse.setCharacterEncoding("UTF-8");
				pResponse.getWriter().write(json);
			}
		}
	}
	
	/****sending  email to sales representative*********/
	private void sendEmailToUser(Map<String, String> contactInfo) {

		Map<String, Object> templateParameters = new HashMap<String, Object>();
		templateParameters.put("name", getUserName());
		templateParameters.put("phoneNumber", getPhoneNumber());
		templateParameters.put("email", getEmail());
		templateParameters.put("contactMethod",getContactMethod());
		templateParameters.put("crmInquiry", getCrmInquiry());
		templateParameters.put("message", getMessage());
		templateParameters.put("contractId", getContractId());
		templateParameters.put("salesName", getSalesName());
		templateParameters.put("subscriptionStartDate", getSubscriptionStartDate());
		templateParameters.put("subscriptionEndDate", getSubscriptionEndDate());
		getAgilentContactFormTemplateInfo().setTemplateParameters(templateParameters);
		getAgilentContactFormTemplateInfo().setMessageFrom(getEmail());
		getAgilentContactFormTemplateInfo().setMessageSubject("RegardingService Agreement #"+getContractId()+" (coverage from "+getSubscriptionStartDate()+" to "+getSubscriptionEndDate()+" )");
		if(isNoEmailTosalesRep())
		getAgilentContactFormTemplateInfo().setMessageTo(getMessageCc());
		else
		getAgilentContactFormTemplateInfo().setMessageTo(getSalesEmail());
		getAgilentContactFormTemplateInfo().setMessageCc(getMessageCc());
		try {
			if(isNoEmailTosalesRep())
			getTemplateEmailSender().sendEmailMessage(getAgilentContactFormTemplateInfo(), new String[] { getMessageCc() }, Boolean.FALSE, false);
			else
			getTemplateEmailSender().sendEmailMessage(getAgilentContactFormTemplateInfo(), new String[] { getSalesEmail() }, Boolean.FALSE, false);
			vlogDebug("Email sent succesfully to sales represntative {0}",getSalesEmail());
		} catch (TemplateEmailException e) {
			e.printStackTrace();
		}

	}
	
    public void handleSendEmail(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) {
        vlogInfo("Entering inside the send email method for sale services");
        AgilentProfile profile = null;
        SessionBean sessionBean = null;
        String toAddress = "";
        String quoteId = "";
        String accountId = "";
        String phone="";
        Map<Integer, String> specailSaleFinalMap = new HashMap<>();
        Map<Integer, String> specialSaleMap1 = getAgilentConfigurationSecond().getContactMeSpecialistLeftMap();
        Map<Integer, String> specialSaleMap2 = getAgilentConfigurationSecond().getContactMeSpecialistRightMap();
        specailSaleFinalMap.putAll(specialSaleMap1);
        specailSaleFinalMap.putAll(specialSaleMap2);
        Set<Integer> keyList = new HashSet<Integer>(specailSaleFinalMap.keySet());
        List<String> customSalelist = new ArrayList<>();
	    List<ProductAddOnsResponse> finalResponse = new ArrayList<ProductAddOnsResponse>();
        if (getProductArray() != null) {
            for (String productId : getProductArray()) {
	     for (Object productKeyList : keyList) {
                    if (productKeyList != null) {
	            String productKey = new String(productKeyList.toString());
                        if (StringUtils.isNotEmpty(productKey) && productKey.equals(productId)) {
                            customSalelist.add(specailSaleFinalMap.get(productKey));
                        }
                    }
                }
            }
        }
        profile = (AgilentProfile) pRequest.getObjectParameter(PROFILE);
        if (null == profile) {
            profile = (AgilentProfile) pRequest.resolveName(PROFILE_COMPONENT);
        }
        if (null == profile) {
            vlogDebug("Profile is null");
        } else if (!profile.isTransient()) {
            sessionBean = profile.getSessionBean();
            finalResponse = sessionBean.getProductAddOnsList();
            if (finalResponse != null && !finalResponse.isEmpty()) {
                for (ProductAddOnsResponse productAddOnsResponse : finalResponse) {
                    quoteId = productAddOnsResponse.getQuoteId();
                    List<PartnerResultSet> mPartnerResultSet = productAddOnsResponse.getPartnerResultSet();
                    if (mPartnerResultSet != null && !mPartnerResultSet.isEmpty()) {
                        for (PartnerResultSet partnerResultSet : mPartnerResultSet) {
                            String partnerFact = partnerResultSet.getPartnerFct();
                            if (partnerFact.equalsIgnoreCase(PARTNERSET)) {
                                toAddress = partnerResultSet.getEmailId();
                            } else if (partnerFact.equalsIgnoreCase(PARTNERSET_PARTNO)) {
                                accountId = partnerResultSet.getPartnerNo();
                            }
                        }
                    }
                }

                vlogDebug("Passing the list of selected options   {0}" + customSalelist);
                int returnCode = getSapCRMAPIManager().notesUpdateInCRM(customSalelist, quoteId);
                vlogInfo("Return code for Notes Update {0} ", returnCode);

            } else {
                vlogInfo("No response obtained from add on service from session");
            }

        }
	    Map<String, Object> templateParameters = new HashMap<String, Object>();
        TemplateEmailInfoImpl emailInfo = prepareServiceSelectionEmailInfo(toAddress);
        AgilentPropertyManager propManager = (AgilentPropertyManager) profile.getProfileTools().getPropertyManager();
        String adLoginName = (String) profile.getPropertyValue(propManager.getAdLoginNamePropertyName());
        /*String accountId = (String) profile.getPropertyValue(propManager.getCrmContactNumberPropertyName());*/
        String email = (String) profile.getPropertyValue(propManager.getEmailAddressPropertyName());
        RepositoryItem userShippingAddress = (RepositoryItem) profile.getPropertyValue(IdmServiceConstants.USER_SHIPPING_ADDRESS);
	    if(userShippingAddress!=null){
        phone = userShippingAddress.getPropertyValue(IdmServiceConstants.USER_PHONE_NUMBER) != null
                ? (String) userShippingAddress.getPropertyValue(IdmServiceConstants.USER_PHONE_NUMBER) : IdmServiceConstants.USER_EMPTY;
	    }
        templateParameters.put(IdmServiceConstants.LOGIN_NAME, adLoginName);
        templateParameters.put(IdmServiceConstants.ACCOUNTID, accountId);
        templateParameters.put(IdmServiceConstants.USER_EMAIL_ID, email);
        templateParameters.put(IdmServiceConstants.USER_PHONE_NUMBER, phone);
        templateParameters.put(IdmServiceConstants.QUOTEID, quoteId);
        templateParameters.put(IdmServiceConstants.SPECIALPDT, customSalelist);
	    emailInfo.setTemplateParameters(templateParameters);
	    List recipents = getEmailTools().addRecipients(emailInfo);
	    try {
	        if (finalResponse != null && !finalResponse.isEmpty()) {
            vlogInfo("Preparing to send sale service email");
            getEmailTools().getEmailSender().sendEmailMessage(emailInfo, recipents);
            vlogInfo("Email sent succesfully to sales represntative {0}", toAddress);
            getSessionBean().getProductAddOnsList().clear();
            }else{
                vlogInfo("No response obtained from add on service from session, no email triggered to sales rep");  
            }
        } catch (TemplateEmailException e) {
            vlogError("Template Exception while sending an email");
        }
    }

    private TemplateEmailInfoImpl prepareServiceSelectionEmailInfo(String toAddress) {
        TemplateEmailInfoImpl emailInfo = (TemplateEmailInfoImpl) getEmailTools().getDefaultEmailInfo().copy();
        if (StringUtils.isNotBlank(toAddress)) {
            emailInfo.setMessageTo(toAddress);
        }else{
            emailInfo.setMessageTo("");
        }
        if (StringUtils.isNotBlank(getEmailTools().getSaleServiceEmailMessageCC())) {
            emailInfo.setMessageCc(getEmailTools().getSaleServiceEmailMessageCC());
        }
        emailInfo.setMessageSubject(getEmailTools().getSaleServiceEmailMessageSubject());
        emailInfo.setTemplateURL(getEmailTools().getSaleServiceEmailTemplateUrl());
        emailInfo.setMessageFrom(getEmailTools().getSaleServiceEmailMessageFrom());
        return emailInfo;
    }
	
	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessageFrom() {
		return messageFrom;
	}

	public void setMessageFrom(String messageFrom) {
		this.messageFrom = messageFrom;
	}

	public String getMessageCc() {
		return messageCc;
	}

	public void setMessageCc(String messageCc) {
		this.messageCc = messageCc;
	}
	public MutableRepository getRequestQuoteRepository() {
		return requestQuoteRepository;
	}

	public void setRequestQuoteRepository(MutableRepository requestQuoteRepository) {
		this.requestQuoteRepository = requestQuoteRepository;
	}

	public TemplateEmailSender getTemplateEmailSender() {
		return templateEmailSender;
	}

	public void setTemplateEmailSender(TemplateEmailSender templateEmailSender) {
		this.templateEmailSender = templateEmailSender;
	}

	public TemplateEmailInfoImpl getAgilentContactFormTemplateInfo() {
		return agilentContactFormTemplateInfo;
	}

	public void setAgilentContactFormTemplateInfo(TemplateEmailInfoImpl agilentContactFormTemplateInfo) {
		this.agilentContactFormTemplateInfo = agilentContactFormTemplateInfo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactMethod() {
		return contactMethod;
	}

	public void setContactMethod(String contactMethod) {
		this.contactMethod = contactMethod;
	}

	public String getCrmInquiry() {
		return crmInquiry;
	}

	public void setCrmInquiry(String crmInquiry) {
		this.crmInquiry = crmInquiry;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMessageTo() {
		return messageTo;
	}

	public void setMessageTo(String messageTo) {
		this.messageTo = messageTo;
	}
	public String getContractId() {
		return contractId;
	}
	public void setContractId(String mContractId) {
		contractId = mContractId;
	}
	public String getSalesEmail() {
		return salesEmail;
	}
	public void setSalesEmail(String mSalesEmail) {
		salesEmail = mSalesEmail;
	}
	public String getSubscriptionStartDate() {
		return subscriptionStartDate;
	}
	public void setSubscriptionStartDate(String mSubscriptionStartDate) {
		subscriptionStartDate = mSubscriptionStartDate;
	}
	public String getSubscriptionEndDate() {
		return subscriptionEndDate;
	}
	public void setSubscriptionEndDate(String mSubscriptionEndDate) {
		subscriptionEndDate = mSubscriptionEndDate;
	}
	public String getSalesName() {
		return salesName;
	}
	public void setSalesName(String mSalesName) {
		if(mSalesName==null){
			mSalesName="";
		}
		salesName = mSalesName;
	}
	public String getQuoteId() {
		return quoteId;
	}
	public void setQuoteId(String mQuoteId) {
		quoteId = mQuoteId;
	}
	public String getContactCountry() {
		return contactCountry;
	}
	public void setContactCountry(String mContactCountry) {
		contactCountry = mContactCountry;
	}
	public String getContactRegion() {
		return contactRegion;
	}
	public void setContactRegion(String mContactRegion) {
		contactRegion = mContactRegion;
	}

	public boolean isNoEmailTosalesRep() {
		return noEmailTosalesRep;
	}

	public void setNoEmailTosalesRep(boolean mNoEmailTosalesRep) {
		noEmailTosalesRep = mNoEmailTosalesRep;
	}
	
	public AgilentEmailTools getEmailTools() {
        return mEmailTools;
    }

    public void setEmailTools( AgilentEmailTools pEmailTools) {
        mEmailTools = pEmailTools;
    }
	
    public SessionBean getSessionBean() {
        return mSessionBean;
    }

 
    public void setSessionBean(SessionBean pSessionBean) {
        mSessionBean = pSessionBean;
    }

    public AgilentConfigurationSecond getAgilentConfigurationSecond() {
        return agilentConfigurationSecond;
    }

    public void setAgilentConfigurationSecond(AgilentConfigurationSecond agilentConfigurationSecond) {
        this.agilentConfigurationSecond = agilentConfigurationSecond;
    }

    public String[] getProductArray() {
        return productArray;
    }

    public void setProductArray(String[] productArray) {
        this.productArray = productArray;
    }

    /**
     * @return the sapCRMAPIManager
     */
    public SAPCRMAPIManager getSapCRMAPIManager() {
        return sapCRMAPIManager;
    }

    /**
     * @param sapCRMAPIManager the sapCRMAPIManager to set
     */
    public void setSapCRMAPIManager(SAPCRMAPIManager sapCRMAPIManager) {
        this.sapCRMAPIManager = sapCRMAPIManager;
    }

}
