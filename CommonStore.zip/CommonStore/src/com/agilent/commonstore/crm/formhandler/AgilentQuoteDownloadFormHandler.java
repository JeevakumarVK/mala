/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.formhandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.common.services.QuoteDetails;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.commonstore.crm.helper.AgilentQuoteDownloadHelper;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfDestination;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import atg.core.util.StringUtils;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.RequestLocale;

/**
 * This Form Handler class is used for handling quote download functionality.
 */
public class AgilentQuoteDownloadFormHandler extends GenericFormHandler {

    private String mQuoteId;
    private AgilentProfile mProfile;
    private AgilentQuoteDownloadHelper mAgilentQuoteDownloadHelper;
    private SapFunctions mSapManager;
    private Map<String, String> mStampImageMap;
    public static String stampImage;
    public static final String USER_COUNTRY="userCountry";
    private List <String> storeQuoteStampCountry;

    /**
     * Responsible to accept request and handle PDF download
     * 
     * @param pRequest
     * @param pResponse
     * @throws ServletException
     * @throws IOException
     */
    public void handleDownloadQuoteAsPdf(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        vlogInfo("AgilentQuoteDownloadFormHandler.handleDownloadQuoteAsPdf --START--");
        Document document = null;
        PdfPTable pdfTable = null;
        QuoteDetails quoteDetails = null;
        String fontPath = "";
        PdfWriter writer = null;
        String FILE_NAME =null;
        String salesOrg=(String) getProfile().getPropertyValue("sapSalesOrg");
        String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
        String imageOutputPath = pRequest.getRealPath("") + File.separator + "images";
        String finalImagePath=null;
        try {
            if (StringUtils.isNotBlank(getQuoteId())) {
                quoteDetails = getSapManager().getDocDetails(getQuoteId().trim());
                vlogDebug("AgilentQuoteDownloadFormHandler.handleDownloadQuoteAsPdf --quoteDetails-- {0}", quoteDetails);
            }
            if (null != quoteDetails) {
                fontPath = pRequest.getRealPath("");
                fontPath = getPath(fontPath);
                RequestLocale requestLocale = pRequest.getRequestLocale();
                Locale locale = requestLocale.getLocale();
                pdfTable = this.getAgilentQuoteDownloadHelper().getQuoteAsPDF(fontPath, locale, quoteDetails);
                document = new Document(PageSize.A4, 50, 50, 50, 50);
                pResponse.reset();
                pResponse.setContentType("application/pdf");
                pResponse.setHeader("Content-disposition", "attachment; filename=\"Quote-" + getQuoteId() + ".pdf\"");
                FILE_NAME="Quote-" + getQuoteId() + ".pdf";
                writer = PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
                document.open();
                document.add(pdfTable);
                PdfDestination pdfDest = new PdfDestination(PdfDestination.XYZ, 0, document.getPageSize().getHeight(), 1f);
                PdfAction action = PdfAction.gotoLocalPage(1, pdfDest, writer);
                writer.setOpenAction(action);
                vlogDebug("AgilentQuoteDownloadFormHandler.handleDownloadQuoteAsPdf --END--");
                document.close();
                /** add stamp Image start**/
                PdfReader reader= new PdfReader(FILE_NAME); 
                PdfStamper stamper = new PdfStamper(reader, pResponse.getOutputStream());
                if (getStoreQuoteStampCountry().contains(userCountry)) {
                    if (getStampImageMap().containsKey(salesOrg)) {
                        stampImage = imageOutputPath + File.separator + getStampImageMap().get(salesOrg);
                        finalImagePath = getPath(stampImage);
                        addStampImageOnPDF(reader, stamper, finalImagePath,userCountry);
                    } else {
                        vlogDebug("No Stamp Image found for user country and sales org");
                    }
                }
                stamper.close();
                reader.close();
                /** add stamp Image End**/
                vlogInfo("AgilentQuoteDownloadFormHandler.handleDownloadQuoteAsPdf --End Successfully--");
            }
        } catch (DocumentException de) {
            vlogError("DocumentException while downloading PDF", de);
        } catch (Exception e) {
            vlogError("Error while downloading PDF. Refer the trace for details.", e);
        }
    }

    
    public void addStampImageOnPDF(PdfReader reader, PdfStamper stamper, String finalImagePath, String userCountry)
            throws BadElementException, MalformedURLException, IOException, DocumentException {
        getAgilentQuoteDownloadHelper().addStampImageOnPDF(reader, stamper, finalImagePath, userCountry);
    }

 
    /**
     * Sanitizing string
     * 
     * @param pStr
     * @return
     */
    public String getPath(String pStr) {
        pStr = pStr.replace("\\", "/");
        return pStr;
    }

    /**
     * Gets the value of property quoteId
     *
     * @return the value of property quoteId
     */
    public String getQuoteId() {
        return mQuoteId;
    }
    /**
     * Sets the value of property quoteId with value pQuoteId
     *
     * @param pQuoteId
     *            for setting property quoteId
     */
    public void setQuoteId(String pQuoteId) {
        mQuoteId = pQuoteId;
    }

    /**
     * Gets the value of property profile
     *
     * @return the value of property profile
     */
    public AgilentProfile getProfile() {
        return mProfile;
    }
    /**
     * Sets the value of property profile with value pProfile
     *
     * @param pProfile
     *            for setting property profile
     */
    public void setProfile(AgilentProfile pProfile) {
        mProfile = pProfile;
    }

    /**
     * Gets the value of property agilentQuoteDownloadHelper
     *
     * @return the value of property agilentQuoteDownloadHelper
     */
    public AgilentQuoteDownloadHelper getAgilentQuoteDownloadHelper() {
        return mAgilentQuoteDownloadHelper;
    }
    /**
     * Sets the value of property agilentQuoteDownloadHelper with value pAgilentQuoteDownloadHelper
     *
     * @param pAgilentQuoteDownloadHelper
     *            for setting property agilentQuoteDownloadHelper
     */
    public void setAgilentQuoteDownloadHelper(AgilentQuoteDownloadHelper pAgilentQuoteDownloadHelper) {
        mAgilentQuoteDownloadHelper = pAgilentQuoteDownloadHelper;
    }

    /**
     * Gets the value of property sapManager
     *
     * @return the value of property sapManager
     */
    public SapFunctions getSapManager() {
        return mSapManager;
    }
    /**
     * Sets the value of property sapManager with value pSapManager
     *
     * @param pSapManager
     *            for setting property sapManager
     */
    public void setSapManager(SapFunctions pSapManager) {
        mSapManager = pSapManager;
    }


    public Map<String, String> getStampImageMap() {
        return mStampImageMap;
    }

    public void setStampImageMap(Map<String, String> pStampImageMap) {
        mStampImageMap = pStampImageMap;
    }


    public List <String> getStoreQuoteStampCountry() {
        return storeQuoteStampCountry;
    }


    public void setStoreQuoteStampCountry(List <String> pStoreQuoteStampCountry) {
        storeQuoteStampCountry = pStoreQuoteStampCountry;
    }

}
