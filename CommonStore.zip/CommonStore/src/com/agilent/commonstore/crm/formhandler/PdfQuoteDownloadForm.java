/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.formhandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import org.apache.commons.lang3.LocaleUtils;

import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.common.ChinaConfiguration;
import com.agilent.base.crm.bean.ReviewQuoteComponentsInfo;
import com.agilent.base.crm.bean.ReviewQuoteDetailsInfo;
import com.agilent.base.crm.bean.ReviewQuotesBean;
import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.droplet.AgilentDateTagConverter;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.helper.AgilentContractHistoryHelper;
import com.agilent.i18n.service.InternationalizationService;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.TextMarginFinder;

import atg.core.util.StringUtils;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.RequestLocale;

/**
 * This form handler is used to handle PDF of service quote.
 */
public class PdfQuoteDownloadForm extends GenericFormHandler {

    private AgilentContractHistoryHelper agilentServiceHistoryHelper;
    private AgilentProfile profile;
    private CountryUtils mCountryUtils;
    private ErrorHandlerImpl mErrorHandler;
    private SessionBean mSessionBean;
    private Map<String, String> mCountryToDateFormatMap;
    private List<String> mCountryToAddStamp;
    private Map<String, String> mStampImageMap;
    private Map<String, String> mImageHorizontalPositionMap;
    private Map<String, String> mImageScaleSizeMap;
	private List<String> mAFOCountries;
	private List<String> mEMEAICountries;
	private List<String> mSAPKCountries;
	private String mTermsLinkForAFO;
    private String mTermsLinkForEMAEAI;
    private String mTermsLinkForSAPK;
    private String domain;

    public static String FONTAWESOME = "/agilent_fonts/icomoon.ttf";
    public static String ROBOTOREGULAR = "/agilent_fonts/roboto-regular/roboto-regular.ttf";
    public static String ROBOTOMEDIUM = "/agilent_fonts/roboto-medium/roboto-medium.ttf";
    public static String ROBOTO_CONDENSEDLIGHT = "/agilent_fonts/roboto-light/robotocondensed-light.ttf";
    public static String ROBOTO_CONDENSEDBOLD = "/agilent_fonts/roboto-condensed/robotocondensed-bold.ttf";
    public static String ROBOTO_CONDENSEDREGULAR = "/agilent_fonts/roboto-condensed-regular/robotocondensed-regular.ttf";
    public static String CHINESE_FONT_LIGHT = "STSong-Light";
    public static String CHINESE_FONT_STD = "STSongStd-Light";
    public static String KOREAN_FONT_MEDIUM = "HYSMyeongJo-Medium";
    public static String KOREAN_FONT_THICK = "HYGoThic-Medium";
    public static String KOREAN_FONT_STD_MEDIUM = "HYSMyeongJoStd-Medium";
    public static String JAPANESE_FONT_REGULAR = "KozMinPro-Regular";
    public static String JAPANESE_FONT_REGULAR_TYPE1 = "HeiseiKakuGo-W5";
    public static String JAPANESE_FONT_REGULAR_TYPE2 = "HeiseiMin-W3";
    public static String CHINESE_ENCODING = "UniGB-UCS2-H";
    public static String KOREAN_ENCODING = "UniKS-UCS2-H";
    public static String JAPANESE_ENCODING = "UniJIS-UCS2-H";
    public static String footerIamge;
    public BaseFont awesomeBaseFont;
    public BaseFont robotoregularBaseFont;
    public BaseFont robotomediumBaseFont;
    public BaseFont condensedlightBaseFont;
    public BaseFont condensedboldeBaseFont;
    public BaseFont condensedregularBaseFont;
    private AgilentConfiguration mConfiguration;
    private AgilentConfigurationSecond agilentConfigurationSecond;
    public static String stampImage;
    private static String USER_COUNTRY="userCountry";
    private InternationalizationService mInternationalizationService;
    private ChinaConfiguration mChinaConfiguration;

    public void handleDownloadPdf(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        Document document = null;
        PdfPTable outerTable = null;
        List<ReviewQuotesBean> quoteItems = null;
        String fontPath = "";
        PdfWriter writer = null;
        String FILE_NAME =null;
        String salesOrg=(String) getProfile().getPropertyValue("sapSalesOrg");
        boolean isCNHost = false;
	   	if(StringUtils.isNotBlank(domain)&&domain.contains(getAgilentConfigurationSecond().getChinaProfileCookieDomain())){
	   		isCNHost = true;
	   	}

        try {
           
            quoteItems = this.getSessionBean().getQuoteItems();
            if (quoteItems == null) {
                String quoteId = (String) pRequest.getParameter("quoteId");
                quoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(quoteId, false, "");
            }
            String imageOutputPath = pRequest.getRealPath("") + File.separator + "images";
            fontPath = pRequest.getRealPath("");
            fontPath = getPath(fontPath);
            RequestLocale requestLocale = pRequest.getRequestLocale();
            Locale locale = requestLocale.getLocale();
            footerIamge = imageOutputPath + File.separator + "sureFooterImage.jpg";
            footerIamge = getPath(footerIamge);
            awesomeBaseFont = getRoboFont(fontPath + FONTAWESOME, locale);
            robotoregularBaseFont = getRoboFont(fontPath + ROBOTOREGULAR, locale);
            robotomediumBaseFont = getRoboFont(fontPath + ROBOTOMEDIUM, locale);
            condensedlightBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDLIGHT, locale);
            condensedboldeBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDBOLD, locale);
            condensedregularBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDREGULAR, locale);
            outerTable = generatePdfFile(quoteItems, locale, isCNHost);
            document = new Document(PageSize.A4, 50, 50, 50, 50);
            pResponse.reset();
            pResponse.setContentType("application/pdf");
            if (quoteItems == null || quoteItems.isEmpty()) {
                pResponse.setHeader("Content-disposition", "attachment; filename=\"QuoteDetails.pdf\"");
                FILE_NAME="QuoteDetails.pdf";
            } else {
                for (ReviewQuotesBean quoteItem : quoteItems) {
                    pResponse.setHeader("Content-disposition",
                            "attachment; filename=\"Quote-" + quoteItem.getQuoteId() + ".pdf\"");
                    FILE_NAME="Quote-"+ quoteItem.getQuoteId() + ".pdf";
                     vlogInfo("downloading PDF for quote {0}", quoteItem.getQuoteId());
                }

            }
            
            writer = PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
            document.open();
            writer.setPageEvent(new HeaderFooter());
            document.add(outerTable);
            document.close();
            
            /** add stamp Image start**/
            String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
            PdfReader reader = new PdfReader(FILE_NAME);
            PdfStamper stamper = new PdfStamper(reader, pResponse.getOutputStream());
            if (getCountryToAddStamp().contains(userCountry))  {
                if (getStampImageMap().containsKey(salesOrg)) {
                    stampImage = imageOutputPath + File.separator + getStampImageMap().get(salesOrg);
                    stampImage = getPath(stampImage);
                    addStampImage(reader, stamper, userCountry);
               }
                else {
                    vlogInfo("No Stamp image found for user country/sales org {0}", salesOrg);
                }
            }
            else {
                vlogInfo("User country {0} does not require stamp image in PDF download", userCountry);
            }
            /** add stamp Image End**/
        
            stamper.close();
            reader.close();
           
        } catch (final Exception e) {
            this.vlogError("", e);
        }
    }

    /**
     * @param pResponse
     * @param FILE_NAME
     * @throws IOException
     * @throws DocumentException
     * @throws BadElementException
     * @throws MalformedURLException
     */
    private void addStampImage(PdfReader reader, PdfStamper stamper, String userCountry) throws IOException, DocumentException, BadElementException, MalformedURLException {
        
        String ImageScalesize= "";
        String ImageHorizontalPosition= "";
        vlogInfo("about to add stamp image for service Quotes for country {0}",userCountry);
        if (getCountryToAddStamp().contains(userCountry)) {
            Image image = Image.getInstance(stampImage);
            for (int i = 1; i <= reader.getNumberOfPages(); i++) {
                PdfContentByte contentByte = stamper.getOverContent(i);
                PdfReaderContentParser parser = new PdfReaderContentParser(reader);
                TextMarginFinder finder = parser.processContent(i, new TextMarginFinder());
                vlogInfo("adding image for page {0}", i);
                if (getImageHorizontalPositionMap().containsKey(userCountry) && getImageScaleSizeMap().containsKey(userCountry)) {
                    ImageScalesize=getImageScaleSizeMap().get(userCountry);
                    ImageHorizontalPosition=getImageHorizontalPositionMap().get(userCountry);
                    
                }
                image.scalePercent(Integer.parseInt(ImageScalesize));

                vlogInfo("X axis " + finder.getLlx() + " actual x axis position " + Integer.parseInt(ImageHorizontalPosition) + " Y axis " + finder.getLly());

                image.setAbsolutePosition(Integer.parseInt(ImageHorizontalPosition), finder.getLly());
                contentByte.addImage(image);
            }
        }
     
    }
    
    public void handleRepairQuoteDownloadPdf(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        Document document = null;
        PdfPTable outerTable = null;
        List<ReviewQuotesBean> quoteItems = null;
        String fontPath = "";
        PdfWriter writer = null;
        String FILE_NAME =null;
        String salesOrg=(String) getProfile().getPropertyValue("sapSalesOrg");
        domain=pRequest.getServerName();
        try {
            if (quoteItems == null) {
                String quoteId = (String) pRequest.getParameter("quoteId");
                quoteItems = getAgilentServiceHistoryHelper().fetchQuoteDetails(quoteId, false, "");
            	if(getSessionBean() != null && getSessionBean().isCreatedByWeb()){
                    getAgilentServiceHistoryHelper().populateCreatedByWebQuoteValues(quoteItems);                    
                }
            }
            String imageOutputPath = pRequest.getRealPath("") + File.separator + "images";
            fontPath = pRequest.getRealPath("");
            fontPath = getPath(fontPath);
            RequestLocale requestLocale = pRequest.getRequestLocale();
            Locale locale = requestLocale.getLocale();
            footerIamge = imageOutputPath + File.separator + "sureFooterImage.jpg";
            footerIamge = getPath(footerIamge);
            awesomeBaseFont = getRoboFont(fontPath + FONTAWESOME, locale);
            robotoregularBaseFont = getRoboFont(fontPath + ROBOTOREGULAR, locale);
            robotomediumBaseFont = getRoboFont(fontPath + ROBOTOMEDIUM, locale);
            condensedlightBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDLIGHT, locale);
            condensedboldeBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDBOLD, locale);
            condensedregularBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDREGULAR, locale);
            outerTable = generateRepairQuotePdfFile(quoteItems);
            document = new Document(PageSize.A4, 50, 50, 50, 50);
            pResponse.reset();
            pResponse.setContentType("application/pdf");
            if (quoteItems != null && !quoteItems.isEmpty()) {
                for (ReviewQuotesBean quoteItem : quoteItems) {
                    pResponse.setHeader("Content-disposition", "attachment; filename=\"Quote-" + quoteItem.getQuoteId() + ".pdf\"");
                    FILE_NAME="Quote-"+ quoteItem.getQuoteId() + ".pdf";
                    vlogInfo("downloading PDF for quote {0}", quoteItem.getQuoteId());
                }
            } else {
                pResponse.setHeader("Content-disposition", "attachment; filename=\"QuoteDetails.pdf\"");
                FILE_NAME="QuoteDetails.pdf";
                
            }
            
            writer = PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
            document.open();
            writer.setPageEvent(new HeaderFooter());
            document.add(outerTable);
            document.close();
            
            /** add stamp Image start**/
            String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
            PdfReader reader= new PdfReader(FILE_NAME); 
            PdfStamper stamper = new PdfStamper(reader, pResponse.getOutputStream());
            if (getCountryToAddStamp().contains(userCountry))  {
                if (getStampImageMap().containsKey(salesOrg)) {
                    stampImage = imageOutputPath + File.separator + getStampImageMap().get(salesOrg);
                    stampImage = getPath(stampImage);
                    addStampImage(reader, stamper, userCountry);
               }
                else {
                    vlogInfo("No Stamp image found for user country/sales org {0}", salesOrg);
                }
            }
            else {
                vlogInfo("User country {0} does not require stamp image in PDF download", userCountry);
            }
            /** add stamp Image End**/
            stamper.close();
            reader.close();
        } catch (final Exception e) {
            this.vlogError("", e);
        }
    }

    private PdfPTable generatePdfFile(List<ReviewQuotesBean> quoteItems, Locale locale, boolean isCNHost) {
        PdfPTable outerTable = null;
        PdfPTable innterTable1 = null;
        PdfPTable innerTable2 = null;
        PdfPTable innerTable3 = null;
        List<ReviewQuoteDetailsInfo> reviewQuoteDetailsList = null;
        String componentText = "";
        PdfPTable contactTable = null;
        PdfPTable equipTable = null;
        PdfPTable outerContactTable = null;
        String totalLabel = "";
        Map<String, Object> extraParams;
        Phrase cover = null;
        String hostName="";
		if(isCNHost){
			hostName = getAgilentConfigurationSecond().getCnDiscountRedirectionLink();
		}else{
			hostName = getAgilentConfigurationSecond().getDiscountRedirectionLink();
		}
        try {
            if (quoteItems != null && !quoteItems.isEmpty()) {
                Locale currencyLocale = LocaleUtils.toLocale(getCountryUtils().getCurrencyLocaleFromSalesOrg(getProfile(), getProfile().getUserCountry(), null));
                for (ReviewQuotesBean quoteItem : quoteItems) {
                    extraParams = quoteItem.getExtraParams();
                    if (null != extraParams && !extraParams.isEmpty() && null != extraParams.get(LynxConstants.TOTAL)) {
                        totalLabel = extraParams.get(LynxConstants.TOTAL).toString();
                    }
                    outerTable = new PdfPTable(1);
                    outerTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    outerTable.setWidthPercentage(100f);
                    innterTable1 = new PdfPTable(1);
                    innterTable1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    innterTable1.setWidthPercentage(100f);
                    
                    PdfPCell innertable1Cell1 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.LABEL_RENEWALQUOTEREF, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL) + quoteItem.getQuoteId(), new Font(robotomediumBaseFont, 16)));
                    try {
                        cover = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_COVERAGE, 
                                new Object[] {AgilentDateTagConverter.formatDate(quoteItem.getSubscriptionStartDate(), getProfile().getUserCountry(), getCountryToDateFormatMap()), 
                                        AgilentDateTagConverter.formatDate(quoteItem.getSubscriptionEndDate(), getProfile().getUserCountry(), getCountryToDateFormatMap())}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(condensedlightBaseFont, 12));
                    } catch (Exception e) {
                        cover = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_COVERAGE, 
                                new Object[] {quoteItem.getSubscriptionStartDate(), quoteItem.getSubscriptionEndDate()}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), 
                                new Font(condensedlightBaseFont, 12));
                    }
                    Paragraph coverageFor = new Paragraph();
                    coverageFor.add(cover);
                    PdfPCell innertable1Cell2 = new PdfPCell(coverageFor);
                    innertable1Cell1.setBorder(PdfPCell.NO_BORDER);
                    innertable1Cell2.setBorder(PdfPCell.NO_BORDER);
                    innertable1Cell1.setPaddingTop(10);
                    innertable1Cell2.setPaddingBottom(10);
                    innterTable1.addCell(innertable1Cell1);
                    innterTable1.addCell(innertable1Cell2);
                    
                    String salesName = quoteItem.getSalesName();
                    String phone = quoteItem.getSalesPhone();
                    String email = quoteItem.getSalesEmail();
                    if(StringUtils.isNotBlank(salesName) || StringUtils.isNotBlank(phone) || StringUtils.isNotBlank(email)) {
                        Phrase assistanace = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_SALESREP, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(condensedlightBaseFont, 9));

                        Phrase salesNamePharse = new Phrase(salesName, new Font(robotomediumBaseFont, 9));
                        Paragraph salesRep = new Paragraph();
                        salesRep.add(assistanace);
                        salesRep.add(LynxConstants.WHITE_SPACE);
                        salesRep.add(salesNamePharse);
                        if(StringUtils.isNotBlank(phone)) {
                             Phrase salesPhone = new Phrase(LynxConstants.PLUS_SYMBOL + phone, new Font(condensedlightBaseFont, 9));
                             salesRep.add(LynxConstants.WHITE_SPACE);
                             salesRep.add(salesPhone);
                        }
                        if(StringUtils.isNotBlank(email)) {
                             Phrase salesEmail = new Phrase(email, new Font(condensedlightBaseFont, 9));
                             salesRep.add(LynxConstants.WHITE_SPACE);
                             salesRep.add(salesEmail);
                        }
                        PdfPCell intertablelCell3 = new PdfPCell(salesRep);
                        intertablelCell3.setBorder(PdfPCell.NO_BORDER);
                        intertablelCell3.setPadding(10);
                        intertablelCell3.setPaddingBottom(10);
                        intertablelCell3.setBackgroundColor(WebColors.getRGBColor("#EEF7FC"));
                        innterTable1.addCell(intertablelCell3);
                    }
                    PdfPCell blankCell = new PdfPCell();
                    blankCell.setBorder(PdfPCell.NO_BORDER);
                    blankCell.setPadding(10);
                    innterTable1.addCell(blankCell);
                    // contact start
                    float[] columnWidths = {6, 1, 6, 3};
                    outerContactTable = new PdfPTable(columnWidths);
                    outerContactTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    outerContactTable.setWidthPercentage(100f);
                    contactTable = new PdfPTable(1);
                    contactTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    contactTable.setWidthPercentage(100f);
                    equipTable = new PdfPTable(1);
                    equipTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    equipTable.setWidthPercentage(100f);
                    PdfPCell contactCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERV_CONTINFO, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedlightBaseFont, 10)));

                    PdfPCell contactCell1 = new PdfPCell(new Phrase(quoteItem.getContactName(), new Font(robotomediumBaseFont, 13, Font.BOLD)));
                    PdfPCell contactCell11 = new PdfPCell(new Phrase(quoteItem.getCompanyName(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell2 = new PdfPCell(new Phrase(quoteItem.getContactPhone(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell3 = new PdfPCell(new Phrase(quoteItem.getContactEmail(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell4 = new PdfPCell();
                    contactCell.setBorder(PdfPCell.NO_BORDER);
                    contactCell.setBackgroundColor(WebColors.getRGBColor("#F5F5F5"));
                    contactCell.setPaddingLeft(10);
                    contactCell1.setPaddingLeft(10);
                    contactCell11.setPaddingLeft(10);
                    contactCell2.setPaddingLeft(10);
                    contactCell3.setPaddingLeft(10);
                    contactCell4.setPaddingLeft(10);
                    contactCell1.setPaddingTop(10);
                    contactCell1.setBorder(PdfPCell.NO_BORDER);
                    contactCell11.setBorder(PdfPCell.NO_BORDER);
                    contactCell2.setBorder(PdfPCell.NO_BORDER);
                    contactCell3.setBorder(PdfPCell.NO_BORDER);
                    contactCell4.setBorder(PdfPCell.NO_BORDER);
                    PdfPCell equipCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERV_EQUIPLOCATION, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell1 = new PdfPCell(new Phrase(quoteItem.getEquipName(), new Font(robotomediumBaseFont, 13, Font.BOLD)));
                    PdfPCell equipCell2 = new PdfPCell(new Phrase(quoteItem.getEquipStreet(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell3 = new PdfPCell(new Phrase(quoteItem.getEquipCity() + LynxConstants.WHITE_SPACE + quoteItem.getEquipRegion() + LynxConstants.WHITE_SPACE
                            + quoteItem.getEquipCountry() + LynxConstants.WHITE_SPACE + quoteItem.getEquipPostCode(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell44 = new PdfPCell();
                    PdfPCell equipCell4 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERVICE_COVERSUMMARY, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotomediumBaseFont, 12)));
                    PdfPCell equipCell41 = new PdfPCell();
                    PdfPCell equipCell42 = new PdfPCell();
                    equipCell.setPaddingLeft(10);
                    equipCell1.setPaddingLeft(10);
                    equipCell2.setPaddingLeft(10);
                    equipCell3.setPaddingLeft(10);
                    equipCell41.setBorder(PdfPCell.NO_BORDER);
                    equipCell42.setBorder(PdfPCell.NO_BORDER);
                    equipCell4.setBorder(PdfPCell.NO_BORDER);
                    equipCell.setColspan(4);
                    equipCell.setBackgroundColor(WebColors.getRGBColor("#F5F5F5"));
                    equipCell1.setColspan(4);
                    equipCell1.setPaddingTop(10);
                    equipCell2.setColspan(4);
                    equipCell3.setColspan(4);
                    equipCell44.setColspan(4);
                    equipCell.setBorder(PdfPCell.NO_BORDER);
                    equipCell1.setBorder(PdfPCell.NO_BORDER);
                    equipCell2.setBorder(PdfPCell.NO_BORDER);
                    equipCell3.setBorder(PdfPCell.NO_BORDER);
                    equipCell44.setBorder(PdfPCell.NO_BORDER);
                    contactTable.addCell(contactCell);
                    contactTable.addCell(contactCell1);
                    contactTable.addCell(contactCell11);
                    contactTable.addCell(contactCell2);
                    contactTable.addCell(contactCell3);
                    contactTable.addCell(contactCell4);
                    equipTable.addCell(equipCell);
                    equipTable.addCell(equipCell1);
                    equipTable.addCell(equipCell2);
                    equipTable.addCell(equipCell3);
                    equipTable.addCell(equipCell44);
                    outerContactTable.addCell(new PdfPCell(contactTable));
                    PdfPCell col3 = new PdfPCell();
                    col3.setBorder(0);
                    outerContactTable.addCell(col3);
                    outerContactTable.addCell(new PdfPCell(equipTable));
                    PdfPCell col4 = new PdfPCell();
                    col4.setBorder(0);
                    outerContactTable.addCell(col4);
                    innterTable1.addCell(outerContactTable);
                    innterTable1.addCell(blankCell);
                    // contact end
                    if( quoteItem.getComments() != null) {
                        String comments = quoteItem.getComments();
                        Phrase commentpharse = new Phrase(comments, new Font(condensedlightBaseFont, 12));
                        Paragraph commentsRep = new Paragraph();
                        commentsRep.add(commentpharse);
                        PdfPCell commentCell = new PdfPCell(commentsRep);
                        commentCell.setPaddingBottom(10);
                        //commentCell.setBorder(PdfPCell.NO_BORDER);
                        float[] commentTableWidth = new float[] {2f,98f};
                        PdfPTable commentTable = new PdfPTable(commentTableWidth); 
                        commentTable.setWidthPercentage(100); 
                        commentTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                        PdfPCell lineCell1 = new PdfPCell();
                        lineCell1.setBackgroundColor(WebColors.getRGBColor("#F5F5F5"));
                        lineCell1.setBorderWidthRight(0);
                        commentTable.addCell(lineCell1);
                        commentCell.setBorderWidthLeft(0);
                        commentTable.addCell(commentCell);
                        PdfPCell commetCell = new PdfPCell(commentTable);
                        commetCell.setBorder(PdfPCell.NO_BORDER);
                        PdfPCell blankComment = new PdfPCell();
                        blankComment.setBorder(PdfPCell.NO_BORDER);
                        blankComment.setPaddingTop(15);
                        innterTable1.addCell(commetCell);
                        innterTable1.addCell(blankComment);
                    }
                    PdfPCell ServiceCoverage = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERVICE_COVERSUMMARY, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotomediumBaseFont, 12)));
                    ServiceCoverage.setBorder(PdfPCell.NO_BORDER);
                    ServiceCoverage.setPaddingBottom(10);
                    innterTable1.addCell(ServiceCoverage);
                    PdfPCell innerTable1Cell = new PdfPCell(innterTable1);
                    innerTable1Cell.setBorder(PdfPCell.NO_BORDER);
                    //innerTable1Cell.setBorder(Rectangle.BOTTOM);
                    outerTable.addCell(innerTable1Cell);
                    reviewQuoteDetailsList = quoteItem.getQuoteItems();
                    int quoteComponentSize = 0;

                    int indexData = 0;
                    boolean isEgsShow = quoteItem.isEgsShow();
                    float[] tabColumnWidths;
                    if (isEgsShow) {
                        tabColumnWidths = new float[] {4, 3, 2, 4};
                    } else {
                        tabColumnWidths = new float[] {4, 4, 3};
                    }
                    int lineCount = 0;
                    for (ReviewQuoteDetailsInfo reviewQuoteDetailsInfo : reviewQuoteDetailsList) {
                        if(lineCount >= 1) {
                             PdfPCell lineCell = new PdfPCell();
                             lineCell.setBorder(PdfPCell.NO_BORDER);
                             lineCell.setBorderColorBottom(WebColors.getRGBColor("#51504F")); 
                             lineCell.setBorderWidthBottom(1);
                             lineCell.setPaddingTop(10);
                             outerTable.addCell(lineCell);
                        }
                        innerTable2 = new PdfPTable(tabColumnWidths);
                        innerTable2.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                        innerTable2.setWidthPercentage(100f);
                        quoteComponentSize = reviewQuoteDetailsInfo.getQuoteComponents().size();
                        componentText = getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_VIEWCOMPONENTS, new Object[] {quoteComponentSize}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL);
                        PdfPCell innerTable2Cell1 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getQuoteSystemId(), new Font(robotoregularBaseFont, 10)));
                        PdfPCell innerTable2Cell2 = new PdfPCell();
                        PdfPCell innerTable2Cell22 = new PdfPCell();
                        PdfPCell innerTable2Cell23 = new PdfPCell();
                        Phrase systemHandle = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SYSTEM_NAME, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(condensedlightBaseFont, 8));
                        Phrase systemValue = null;
                        if (null != reviewQuoteDetailsInfo.getQuoteSystemHandle() && reviewQuoteDetailsInfo.getQuoteSystemHandle().isEmpty()) {
                            systemValue = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_NOSYSTEMPROVIDE, new Object[] {}, 
                                    LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotomediumBaseFont, 8));
                        } else {
                            systemValue = new Phrase(reviewQuoteDetailsInfo.getQuoteSystemHandle(), new Font(robotomediumBaseFont, 8));
                        }
                        Paragraph systemDetails = new Paragraph();
                        systemDetails.add(systemHandle);
                        systemDetails.add(systemValue);
                        PdfPCell innerTable2Cell3 = new PdfPCell(systemDetails);
                        PdfPCell innerTable2Cell33 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getServicePlan(), new Font(robotoregularBaseFont, 9)));
                        PdfPCell innerTable2Cell4 = new PdfPCell(
                                new Paragraph(AgilentCurrencyTagConverter.formatCurrency(Double.parseDouble(reviewQuoteDetailsInfo.getQuoteSystemGrossValue().trim()), currencyLocale),
                                        new Font(robotoregularBaseFont, 9, Font.BOLD)));
                        PdfPCell innerTable2Cell551 = new PdfPCell();
                        PdfPCell innerTable2Cell5 = new PdfPCell();
                        if (quoteComponentSize > 0) {
                            innerTable2Cell5.addElement(new Paragraph(componentText, new Font(robotoregularBaseFont, 10)));
                        }

                        PdfPCell innerTable2Cell552 = new PdfPCell();
                        PdfPCell innerTable2Cell553 = new PdfPCell();
                        PdfPCell innerTable2Cell554 = new PdfPCell();
                        PdfPCell innerTable2Cell7 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_COMPONENT, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotoregularBaseFont, 6, 0, WebColors.getRGBColor("#B0B1B4"))));
                        PdfPCell innerTable2Cell8 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_PART, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotoregularBaseFont, 6, 0, WebColors.getRGBColor("#B0B1B4"))));
                        PdfPCell innerTable2Cell9 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_SERIAL, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotoregularBaseFont, 6, 0, WebColors.getRGBColor("#B0B1B4"))));
                        PdfPCell innerTable2Cell21 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_EGSDATE, new Object[] {}, 
                                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotoregularBaseFont, 6, 0, WebColors.getRGBColor("#B0B1B4"))));
                        if (indexData != 0) {
                            innerTable2Cell1.setPaddingTop(52);
                        }
                        innerTable2Cell1.setPaddingLeft(7);
                        innerTable2Cell3.setPaddingLeft(7);
                        innerTable2Cell4.setPaddingLeft(10);
                        innerTable2Cell5.setPaddingLeft(7);
                        innerTable2Cell1.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell2.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell22.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell23.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell3.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell33.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell4.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell5.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell551.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell551.setPadding(10);
                        innerTable2Cell552.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell553.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell554.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell7.setPaddingLeft(20);
                        innerTable2Cell8.setPaddingLeft(20);
                        innerTable2Cell9.setPaddingLeft(20);
                        innerTable2Cell21.setPaddingLeft(20);
                        innerTable2Cell33.setPaddingLeft(20);
                        innerTable2Cell7.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell8.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell9.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell21.setBorder(PdfPCell.NO_BORDER);
                        innerTable2Cell1.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell2.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell22.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell23.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell3.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell33.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell4.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell5.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell551.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell552.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell553.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell554.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell7.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell8.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell9.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell9.setPaddingBottom(5);
                        innerTable2Cell21.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                        innerTable2Cell21.setPaddingBottom(5);
                        innerTable2.addCell(innerTable2Cell1);
                        innerTable2.addCell(innerTable2Cell2);
                        innerTable2.addCell(innerTable2Cell22);
                        if (isEgsShow) {
                            innerTable2.addCell(innerTable2Cell23);
                        }
                        innerTable2.addCell(innerTable2Cell3);
                        innerTable2.addCell(innerTable2Cell33);
                        if (isEgsShow) {
                            innerTable2.addCell(innerTable2Cell551);
                        }
                        innerTable2.addCell(innerTable2Cell4);
                        innerTable2.addCell(innerTable2Cell5);
                        innerTable2.addCell(innerTable2Cell553);
                        innerTable2.addCell(innerTable2Cell554);
                        if (isEgsShow) {
                            innerTable2.addCell(innerTable2Cell552);
                        }
                        if (quoteComponentSize > 0) {
                            innerTable2.addCell(innerTable2Cell7);
                            innerTable2.addCell(innerTable2Cell8);
                            innerTable2.addCell(innerTable2Cell9);
                            if (isEgsShow) {
                                innerTable2.addCell(innerTable2Cell21);
                            }
                        }
                        indexData++;
                        PdfPCell innerTable2Cell13 = null;
                        for (ReviewQuoteComponentsInfo components : reviewQuoteDetailsInfo.getQuoteComponents()) {
                            PdfPCell innerTable2Cell10 = new PdfPCell(new Paragraph(components.getComponent(), new Font(condensedregularBaseFont, 8)));
                            PdfPCell innerTable2Cell11 = new PdfPCell(new Paragraph(components.getPart(), new Font(condensedregularBaseFont, 8)));
                            PdfPCell innerTable2Cell12 = new PdfPCell(new Paragraph(components.getSerial(), new Font(condensedregularBaseFont, 8)));
                            try {
                                innerTable2Cell13 = new PdfPCell(
                                        new Paragraph(AgilentDateTagConverter.formatDate(components.getEgsDate(), getProfile().getUserCountry(), getCountryToDateFormatMap()),
                                                new Font(condensedregularBaseFont, 8)));
                            } catch (Exception e) {
                                innerTable2Cell13 = new PdfPCell(new Paragraph(components.getEgsDate(), new Font(condensedregularBaseFont, 8)));
                            }
                            innerTable2Cell10.setBorder(PdfPCell.NO_BORDER);
                            innerTable2Cell11.setBorder(PdfPCell.NO_BORDER);
                            innerTable2Cell12.setBorder(PdfPCell.NO_BORDER);
                            innerTable2Cell13.setBorder(PdfPCell.NO_BORDER);
                            innerTable2Cell10.setPaddingLeft(20);
                            innerTable2Cell11.setPaddingLeft(20);
                            innerTable2Cell12.setPaddingLeft(20);
                            innerTable2Cell13.setPaddingLeft(20);
                            innerTable2Cell10.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                            innerTable2Cell11.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                            innerTable2Cell12.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                            innerTable2Cell13.setBackgroundColor(WebColors.getRGBColor("#F9F9F9"));
                            innerTable2.addCell(innerTable2Cell10);
                            innerTable2.addCell(innerTable2Cell11);
                            innerTable2.addCell(innerTable2Cell12);
                            if (isEgsShow) {
                                innerTable2.addCell(innerTable2Cell13);
                            }
                        }
                        PdfPCell innertTable2Cell = new PdfPCell(innerTable2);
                        innertTable2Cell.setBorder(PdfPCell.NO_BORDER);
                        outerTable.addCell(innertTable2Cell);
                        lineCount++;
                    }
                    float[] innerTable3TabColumnWidth;
                    if (isEgsShow) {
                        innerTable3TabColumnWidth = new float[] {10f, 10f, 10f, 40f, 20f};
                    } else {
                        innerTable3TabColumnWidth = new float[] {10f, 10f, 40f, 20f};
                    }
                    innerTable3 = new PdfPTable(innerTable3TabColumnWidth);
                    innerTable3.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    innerTable3.setWidthPercentage(100f);
                    for (Map<String, String> priceListMap : quoteItem.getPriceListMap()) {
                                  Map.Entry<String, String> entry = priceListMap.entrySet().iterator().next();
                                  PdfPCell innerTable3Cell1 = new PdfPCell();
                                  PdfPCell innerTable3Cell2 = new PdfPCell();
                                  PdfPCell innerTable3Cell33 = new PdfPCell();
                                  PdfPCell innerTable3Cell3 = null;
                                  PdfPCell innerTable3Cell4 = null;
                                  if (entry.getKey().equals(totalLabel)) {
                                      innerTable3Cell3 = new PdfPCell(new Paragraph(entry.getKey(), new Font(condensedboldeBaseFont, 12, Font.BOLD)));
                                      innerTable3Cell4 = new PdfPCell(new Paragraph(AgilentCurrencyTagConverter.formatCurrency(Double.parseDouble(entry.getValue().trim()), currencyLocale),
                                              new Font(condensedboldeBaseFont, 12, Font.BOLD)));
                                      innerTable3Cell3.setPaddingTop(37);
                                      innerTable3Cell4.setPaddingTop(37);
                                  } else {
                                      innerTable3Cell3 = new PdfPCell(new Paragraph(entry.getKey(), new Font(robotoregularBaseFont, 12, Font.BOLD)));
                                      innerTable3Cell4 = new PdfPCell(new Paragraph(AgilentCurrencyTagConverter.formatCurrency(Double.parseDouble(entry.getValue().trim()), currencyLocale),
                                              new Font(robotoregularBaseFont, 12, Font.BOLD)));
                                  }
                                  innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);
                                  innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);
                                  innerTable3Cell33.setBorder(PdfPCell.NO_BORDER);
                                  innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);
                                  innerTable3Cell4.setBorder(PdfPCell.NO_BORDER);
                                  innerTable3Cell3.setPaddingLeft(0);
                                  innerTable3.addCell(innerTable3Cell1);
                                  innerTable3.addCell(innerTable3Cell2);
                                  if (isEgsShow) {
                                      innerTable3.addCell(innerTable3Cell33);
                                  }
                                  innerTable3.addCell(innerTable3Cell3);
                                  innerTable3.addCell(innerTable3Cell4);

                              }
                  
                    if (StringUtils.isNotBlank(quoteItem.getPaymentTerms())) {
                        PdfPCell innerTable3Cell1 = new PdfPCell();
                        PdfPCell innerTable3Cell2 = new PdfPCell();
                        PdfPCell innerTable3Cell33 = new PdfPCell();
                        PdfPCell innerTable3Cell3 = null;
                        PdfPCell innerTable3Cell4 = null;
                        
                        innerTable3Cell3 = new PdfPCell(new Paragraph(getInternationalizationService().getLocalizeMessage(LynxConstants.PAYMENT_TERMS_LABEL, null), new Font(condensedboldeBaseFont, 12, Font.BOLD)));
                        innerTable3Cell4 = new PdfPCell(new Paragraph(quoteItem.getPaymentTerms(),
                                new Font(condensedboldeBaseFont, 12, Font.BOLD)));
                        innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell33.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell4.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell3.setPaddingLeft(0);
                        innerTable3.addCell(innerTable3Cell1);
                        innerTable3.addCell(innerTable3Cell2);
                        if (isEgsShow) {
                            innerTable3.addCell(innerTable3Cell33);
                        }
                        innerTable3.addCell(innerTable3Cell3);
                        innerTable3.addCell(innerTable3Cell4);
                    }
                    
                    if (StringUtils.isNotBlank(quoteItem.getBillingFreq())) {
                        PdfPCell innerTable3Cell1BF = new PdfPCell();
                        PdfPCell innerTable3Cell2BF = new PdfPCell();
                        PdfPCell innerTable3Cell33BF = new PdfPCell();
                        PdfPCell innerTable3Cell3BF = null;
                        PdfPCell innerTable3Cell4BF = null;
                        
                        innerTable3Cell3BF = new PdfPCell(new Paragraph(quoteItem.getBillingFreq(), new Font(condensedboldeBaseFont, 12, Font.BOLD)));
                        innerTable3Cell4BF = new PdfPCell();
                        innerTable3Cell1BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell2BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell33BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell3BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell4BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable3Cell3BF.setPaddingLeft(0);
                        innerTable3.addCell(innerTable3Cell1BF);
                        innerTable3.addCell(innerTable3Cell2BF);
                        if (isEgsShow) {
                            innerTable3.addCell(innerTable3Cell33BF);
                        }
                        innerTable3.addCell(innerTable3Cell3BF);
                        innerTable3.addCell(innerTable3Cell4BF);
                    }
                    
                    if (getAgilentConfigurationSecond().isEnablePdfOnlineDiscountDisclaimer() && quoteItem.isDisplayPDFListPrice()) {
                    	Paragraph paragraphDiscount = new Paragraph();
                        PdfPCell innerTable4Cell1BF = new PdfPCell();
                        PdfPCell innerTable4Cell2BF = new PdfPCell();
                        PdfPCell innerTable4Cell33BF = new PdfPCell();
                        PdfPCell innerTable4Cell3BF = null;
                        PdfPCell innerTable4Cell4BF = null;
                        Anchor anchorDiscount = new Anchor(LynxConstants.DICOUNT_DISCLAIMER_LABEL2, new Font(condensedboldeBaseFont, 12, Font.BOLD, WebColors.getRGBColor("#0000FF")));
                        anchorDiscount.setReference(hostName);
                        Phrase n1 = new Phrase(getInternationalizationService().getLocalizeMessage(LynxConstants.DICOUNT_DISCLAIMER_LABEL1,null), new Font(condensedboldeBaseFont, 12, Font.BOLD));
                        paragraphDiscount.add(n1);
                        paragraphDiscount.add(anchorDiscount);
                        Phrase n2 = new Phrase(getInternationalizationService().getLocalizeMessage(LynxConstants.DICOUNT_DISCLAIMER_LABEL3,null), new Font(condensedboldeBaseFont, 12, Font.BOLD));
                        if (null != locale) {
                            if (locale.toString().equals(Locale.CHINA.toString())) {
                            	paragraphDiscount.add(n2);
                            } else if (locale.toString().equals(Locale.JAPAN.toString())) {
                            	paragraphDiscount.add(n2);
                            }
                        }
                        innerTable4Cell3BF=new PdfPCell();
                        innerTable4Cell3BF.addElement(paragraphDiscount);
                        innerTable4Cell4BF = new PdfPCell();
                        innerTable4Cell1BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable4Cell2BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable4Cell33BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable4Cell3BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable4Cell4BF.setBorder(PdfPCell.NO_BORDER);
                        innerTable4Cell3BF.setPaddingLeft(0);
                        innerTable3.addCell(innerTable4Cell1BF);
                        innerTable3.addCell(innerTable4Cell2BF);
                        if (isEgsShow) {
                            innerTable3.addCell(innerTable4Cell33BF);
                        }
                        innerTable3.addCell(innerTable4Cell3BF);
                        innerTable3.addCell(innerTable4Cell4BF);
                    }
                    
                    
                    
                    PdfPCell blankCell1 = new PdfPCell();
                    blankCell1.setBorder(PdfPCell.NO_BORDER);
                    blankCell1.setPadding(10);
                    outerTable.addCell(blankCell1);
                    PdfPCell innertTableCell = new PdfPCell(innerTable3);
                    innertTableCell.setBorder(PdfPCell.NO_BORDER);
                    innerTable3.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    innerTable3.setWidthPercentage(100f);
                    
                    outerTable.addCell(innertTableCell);
                    
					String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
                     
                    String termsAndConditionLink = null;
                    if (getAFOCountries().contains(userCountry))  {
                    	termsAndConditionLink=getTermsLinkForAFO();
                    }
                    else if(getEMEAICountries().contains(userCountry)){
                    	termsAndConditionLink=getTermsLinkForEMAEAI();
                    }
                    else if(getSAPKCountries().contains(userCountry)){
                    	termsAndConditionLink=getTermsLinkForSAPK();
                    }
                    else{
                    	termsAndConditionLink = getErrorHandler().getFormattedErrorMessage(LynxConstants.TERM_CONDITION_TWO, new Object[] {}, 
                                 LynxConstants.LYNX_CONTRACT_SERVICES_LABEL);
                    }
                    vlogDebug("User country {0} and Link {1}in PDF download", userCountry,termsAndConditionLink);     
					
                    Paragraph paragraph1 = new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.TERM_CONDITION_ONE, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotoregularBaseFont, 8));
                    paragraph1.setAlignment(Element.ALIGN_JUSTIFIED);
                    Anchor anchor = new Anchor(termsAndConditionLink, new Font(robotoregularBaseFont, 8, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
                    anchor.setReference(termsAndConditionLink);
                    paragraph1.add(anchor);
                    Chunk lineThree = new Chunk(getErrorHandler().getFormattedErrorMessage(LynxConstants.TERM_CONDITION_THREE, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    paragraph1.add(lineThree);
                    anchor = new Anchor(termsAndConditionLink, new Font(robotoregularBaseFont, 8, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
                    anchor.setReference(termsAndConditionLink);
                    paragraph1.add(anchor);
                    Chunk lineFive = new Chunk(getErrorHandler().getFormattedErrorMessage(LynxConstants.TERM_CONDITION_FIVE, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    paragraph1.add(lineFive);
                    anchor = new Anchor(termsAndConditionLink, new Font(robotoregularBaseFont, 8, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
                    anchor.setReference(termsAndConditionLink);
                    paragraph1.add(anchor);
                    Chunk lineSeven = new Chunk(getErrorHandler().getFormattedErrorMessage(LynxConstants.TERM_CONDITION_SEVEN, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    paragraph1.add(lineSeven);
                    PdfPCell tAndC = new PdfPCell();
                    tAndC.addElement(paragraph1);
                    tAndC.setBorder(PdfPCell.NO_BORDER);
                    tAndC.setPaddingTop(40);
                    
                    outerTable.addCell(tAndC);
                   
                }
            }
        } catch (Exception e) {
            vlogError("Exception caught during pdf genration", e);
        }
        return outerTable;
    }

    private PdfPTable generateRepairQuotePdfFile(List<ReviewQuotesBean> quoteItems) {
        PdfPTable outerTable = null;
        PdfPTable innterTable1 = null;
        List<ReviewQuoteDetailsInfo> reviewQuoteDetailsList = null;
        PdfPTable contactTable = null;
        PdfPTable equipTable = null;
        PdfPTable outerContactTable = null;
        String totalLabel = "";
        Map<String, Object> extraParams;
        boolean createdByWeb = getSessionBean().isCreatedByWeb();
        try {
            if (quoteItems != null && !quoteItems.isEmpty()) {
                for (ReviewQuotesBean quoteItem : quoteItems) {
                    extraParams = quoteItem.getExtraParams();
                    if (null != extraParams && !extraParams.isEmpty() && null != extraParams.get(LynxConstants.TOTAL)) {
                        totalLabel = extraParams.get(LynxConstants.TOTAL).toString();
                    }
                    outerTable = new PdfPTable(1);
                    outerTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    outerTable.setWidthPercentage(100f);
                    innterTable1 = new PdfPTable(1);
                    innterTable1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    innterTable1.setWidthPercentage(100f);
                    PdfPCell blankCell = setCoverageDetails(innterTable1, quoteItem);
                    // contact start
                    float[] columnWidths = {6, 1, 6, 3};
                    outerContactTable = new PdfPTable(columnWidths);
                    outerContactTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    outerContactTable.setWidthPercentage(100f);
                    contactTable = new PdfPTable(1);
                    contactTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    contactTable.setWidthPercentage(100f);
                    equipTable = new PdfPTable(1);
                    equipTable.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
                    equipTable.setWidthPercentage(100f);
                    PdfPCell contactCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERV_CONTINFO, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell1 = new PdfPCell(new Phrase(quoteItem.getContactName(), new Font(robotomediumBaseFont, 13, Font.BOLD)));
                    PdfPCell contactCell11 = new PdfPCell(new Phrase(quoteItem.getCompanyName(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell2 = new PdfPCell(new Phrase(quoteItem.getContactPhone(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell3 = new PdfPCell(new Phrase(quoteItem.getContactEmail(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell contactCell4 = new PdfPCell();
                    contactCell.setBorder(PdfPCell.NO_BORDER);
                    contactCell.setBackgroundColor(WebColors.getRGBColor("#F5F5F5"));
                    contactCell.setPaddingLeft(10);
                    contactCell1.setPaddingLeft(10);
                    contactCell11.setPaddingLeft(10);
                    contactCell2.setPaddingLeft(10);
                    contactCell3.setPaddingLeft(10);
                    contactCell4.setPaddingLeft(10);
                    contactCell1.setPaddingTop(10);
                    contactCell1.setBorder(PdfPCell.NO_BORDER);
                    contactCell11.setBorder(PdfPCell.NO_BORDER);
                    contactCell2.setBorder(PdfPCell.NO_BORDER);
                    contactCell3.setBorder(PdfPCell.NO_BORDER);
                    contactCell4.setBorder(PdfPCell.NO_BORDER);
                    PdfPCell equipCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERV_EQUIPLOCATION, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell1 = new PdfPCell(new Phrase(quoteItem.getEquipName(), new Font(robotomediumBaseFont, 13, Font.BOLD)));
                    PdfPCell equipCell2 = new PdfPCell(new Phrase(quoteItem.getEquipStreet(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell3 = new PdfPCell(new Phrase(quoteItem.getEquipCity() + LynxConstants.WHITE_SPACE + quoteItem.getEquipRegion() + LynxConstants.WHITE_SPACE
                            + quoteItem.getEquipCountry() + LynxConstants.WHITE_SPACE + quoteItem.getEquipPostCode(), new Font(condensedlightBaseFont, 10)));
                    PdfPCell equipCell44 = new PdfPCell();
                    PdfPCell equipCell4 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.SERVICE_COVERSUMMARY, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(robotomediumBaseFont, 12)));
                    PdfPCell equipCell41 = new PdfPCell();
                    PdfPCell equipCell42 = new PdfPCell();
                    equipCell.setPaddingLeft(10);
                    equipCell1.setPaddingLeft(10);
                    equipCell2.setPaddingLeft(10);
                    equipCell3.setPaddingLeft(10);
                    equipCell41.setBorder(PdfPCell.NO_BORDER);
                    equipCell42.setBorder(PdfPCell.NO_BORDER);
                    equipCell4.setBorder(PdfPCell.NO_BORDER);
                    equipCell.setColspan(4);
                    equipCell.setBackgroundColor(WebColors.getRGBColor("#F5F5F5"));
                    equipCell1.setColspan(4);
                    equipCell1.setPaddingTop(10);
                    equipCell2.setColspan(4);
                    equipCell3.setColspan(4);
                    equipCell44.setColspan(4);
                    equipCell.setBorder(PdfPCell.NO_BORDER);
                    equipCell1.setBorder(PdfPCell.NO_BORDER);
                    equipCell2.setBorder(PdfPCell.NO_BORDER);
                    equipCell3.setBorder(PdfPCell.NO_BORDER);
                    equipCell44.setBorder(PdfPCell.NO_BORDER);
                    contactTable.addCell(contactCell);
                    contactTable.addCell(contactCell1);
                    contactTable.addCell(contactCell11);
                    contactTable.addCell(contactCell2);
                    contactTable.addCell(contactCell3);
                    contactTable.addCell(contactCell4);
                    equipTable.addCell(equipCell);
                    equipTable.addCell(equipCell1);
                    equipTable.addCell(equipCell2);
                    equipTable.addCell(equipCell3);
                    equipTable.addCell(equipCell44);
                    outerContactTable.addCell(new PdfPCell(contactTable));
                    PdfPCell col3 = new PdfPCell();
                    col3.setBorder(0);
                    outerContactTable.addCell(col3);
                    outerContactTable.addCell(new PdfPCell(equipTable));
                    PdfPCell col4 = new PdfPCell();
                    col4.setBorder(0);
                    outerContactTable.addCell(col4);
                    innterTable1.addCell(outerContactTable);
                    innterTable1.addCell(blankCell);
                    reviewQuoteDetailsList = quoteItem.getQuoteItems();
                    setModelDetails(outerTable, innterTable1, reviewQuoteDetailsList, blankCell);
                    float[] tabColumnWidths = new float[] {15f, 23f, 18f, 15f, 15f, 17f};
                    if(createdByWeb){                     
                      tabColumnWidths = new float[] {15f, 23f, 18f, 17f};
                    }
                    setQuoteTableDetails(outerTable, tabColumnWidths);
                    setQuoteTablevalueDetails(outerTable, reviewQuoteDetailsList, quoteItem, tabColumnWidths);
                    setBottomLine(outerTable);                    
                    setQuotePriceDetails(outerTable, totalLabel, quoteItem);                    
					if ((StringUtils.isNotBlank(quoteItem.getProcessType()) && getAgilentConfigurationSecond()
							.getRepairProcessTypeCode().contains(quoteItem.getProcessType())) || createdByWeb) {
						setAdditionalComments(outerTable, quoteItem);
					}
                    setCommentsandLineItems(outerTable, quoteItem);
                    setTermsAndConditionsLink(outerTable);
                }
            }
        } catch (Exception e) {
            vlogError("Exception caught during pdf genration", e);
        }
        return outerTable;
    }

    private void setModelDetails(PdfPTable outerTable, PdfPTable innterTable1, List<ReviewQuoteDetailsInfo> reviewQuoteDetailsList, PdfPCell blankCell) {
        for (ReviewQuoteDetailsInfo reviewQuoteDetailsInfo : reviewQuoteDetailsList) {
            PdfPCell innertableModelDesc = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getModelDesc(), new Font(robotomediumBaseFont, 14, Font.BOLD, WebColors.getRGBColor("#303030"))));
            Paragraph modelNumberPar = new Paragraph();
            Phrase modelNumPartOne = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_MODEL_NUMBER, new Object[] {}, 
                   LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotomediumBaseFont, 10, 0, WebColors.getRGBColor("#303030")));
            Phrase modelNumPartTwo = new Phrase(reviewQuoteDetailsInfo.getModelNumber(), new Font(robotomediumBaseFont, 10, Font.BOLD, WebColors.getRGBColor("#303030")));
            modelNumberPar.add(modelNumPartOne);
            modelNumberPar.add(LynxConstants.WHITE_SPACE);
            modelNumberPar.add(modelNumPartTwo);
            
            PdfPCell innertableModelNumber = new PdfPCell(modelNumberPar);
            Paragraph serialNumberPar = new Paragraph();
            Phrase serialNumPartOne = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_SERIAL_NUMBER, new Object[] {}, 
                   LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotomediumBaseFont, 10, 0, WebColors.getRGBColor("#303030")));
            Phrase serialNumPartTwo = new Phrase(reviewQuoteDetailsInfo.getSerialNumber(), new Font(robotomediumBaseFont, 10, Font.BOLD, WebColors.getRGBColor("#303030")));
            serialNumberPar.add(serialNumPartOne);
            serialNumberPar.add(LynxConstants.WHITE_SPACE);
            serialNumberPar.add(serialNumPartTwo);
            PdfPCell innertableSerialNumber = new PdfPCell(serialNumberPar);
            innertableModelDesc.setBorder(PdfPCell.NO_BORDER);
            innertableModelNumber.setBorder(PdfPCell.NO_BORDER);
            innertableSerialNumber.setBorder(PdfPCell.NO_BORDER);
            
            innterTable1.addCell(innertableModelDesc);
            innterTable1.addCell(innertableModelNumber);
            innterTable1.addCell(innertableSerialNumber);
            innterTable1.addCell(blankCell);
            break;
        }
        PdfPCell innerTable1Cell = new PdfPCell(innterTable1);
        innerTable1Cell.setBorder(PdfPCell.NO_BORDER);
        outerTable.addCell(innerTable1Cell);
    }

    private void setQuotePriceDetails(PdfPTable outerTable, String totalLabel, ReviewQuotesBean quoteItem) {
        float[] innerTable3TabColumnWidth = new float[] {30f, 27f, 30f, 20f};
        PdfPTable innerTable3 = new PdfPTable(innerTable3TabColumnWidth);
        innerTable3.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        innerTable3.setWidthPercentage(100f);

        for (Map<String, String> priceListMap : quoteItem.getFormattedPriceListMap()) {
            Map.Entry<String, String> entry = priceListMap.entrySet().iterator().next();
            PdfPCell innerTable3Cell1 = new PdfPCell();
            PdfPCell innerTable3Cell2 = new PdfPCell();
            PdfPCell innerTable3Cell33 = new PdfPCell();
            PdfPCell innerTable3Cell3 = null;
            PdfPCell innerTable3Cell4 = null;
            if (entry.getKey().equals(totalLabel)) {
                innerTable3Cell3 = new PdfPCell(new Paragraph(entry.getKey(), new Font(condensedboldeBaseFont, 12, Font.BOLD, WebColors.getRGBColor("#333"))));
                innerTable3Cell4 = new PdfPCell(new Paragraph(entry.getValue().trim(), new Font(condensedboldeBaseFont, 12, Font.BOLD, WebColors.getRGBColor("#333"))));
                innerTable3Cell3.setPaddingTop(37);
                innerTable3Cell4.setPaddingTop(37);
            } else {
                innerTable3Cell3 = new PdfPCell(new Paragraph(entry.getKey(), new Font(robotoregularBaseFont, 12, Font.BOLD, WebColors.getRGBColor("#333"))));
                innerTable3Cell4 = new PdfPCell(new Paragraph(entry.getValue().trim(), new Font(robotoregularBaseFont, 12, Font.BOLD, WebColors.getRGBColor("#333"))));
            }
            innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);
            innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);
            innerTable3Cell33.setBorder(PdfPCell.NO_BORDER);
            innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);
            innerTable3Cell4.setBorder(PdfPCell.NO_BORDER);
            innerTable3Cell3.setPaddingLeft(0);
            innerTable3Cell3.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
            innerTable3Cell4.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
            innerTable3.addCell(innerTable3Cell1);
            innerTable3.addCell(innerTable3Cell2);
            innerTable3.addCell(innerTable3Cell3);
            innerTable3.addCell(innerTable3Cell4);

        }
        PdfPCell blankCell1 = new PdfPCell();
        blankCell1.setBorder(PdfPCell.NO_BORDER);
        blankCell1.setPadding(10);
        outerTable.addCell(blankCell1);
        PdfPCell innertTableCell = new PdfPCell(innerTable3);
        innertTableCell.setBorder(PdfPCell.NO_BORDER);
        innerTable3.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        innerTable3.setWidthPercentage(100f);
        
        outerTable.addCell(innertTableCell);
       
    }

    private void setQuoteTablevalueDetails(PdfPTable outerTable, List<ReviewQuoteDetailsInfo> reviewQuoteDetailsList, ReviewQuotesBean quoteItem, float[] tabColumnWidths) {
    	   PdfPTable innerTable2 = null;
           List<String> itemNumberList = new ArrayList<String>();
           boolean createdByWeb = this.getSessionBean().isCreatedByWeb();
           for (ReviewQuoteDetailsInfo reviewQuoteDetailsInfo : reviewQuoteDetailsList) {
               if(!itemNumberList.isEmpty() && !itemNumberList.contains(reviewQuoteDetailsInfo.getItemNumber())) {
                   setBottomLine(outerTable);
               }
               String unitPrice="";
               String itemQuantity="";
     
               itemNumberList.add(reviewQuoteDetailsInfo.getItemNumber());
               
               innerTable2 = new PdfPTable(tabColumnWidths);
               innerTable2.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
               innerTable2.setWidthPercentage(100f);
               if(StringUtils.isNotBlank(reviewQuoteDetailsInfo.getUnitPrice())){            	
            	  // unitPrice=quoteItem.getCurrency() + LynxConstants.WHITE_SPACE + reviewQuoteDetailsInfo.getUnitPrice().trim();  
            	   unitPrice=reviewQuoteDetailsInfo.getFormattedUnitPrice();
               }
               if(reviewQuoteDetailsInfo.getItemQuantityValue() > 0){        		
            	   itemQuantity=String.valueOf(reviewQuoteDetailsInfo.getItemQuantityValue());            	   
               }

            PdfPCell innerTable2Cell10 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getOrderedProd(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
            PdfPCell innerTable2Cell11 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getServicePlan(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
            PdfPCell innerTable2Cell12 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getChargeType(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));        
            PdfPCell innerTable2Cell14 = new PdfPCell(new Paragraph(itemQuantity, new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));            
            PdfPCell innerTable2Cell15 = new PdfPCell(new Paragraph(unitPrice, new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));            
            PdfPCell innerTable2Cell16 = new PdfPCell(new Paragraph(reviewQuoteDetailsInfo.getFormattedQuoteSystemGrossValue(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
           
            innerTable2Cell10.setBorder(PdfPCell.NO_BORDER);
            innerTable2Cell11.setBorder(PdfPCell.NO_BORDER);
            innerTable2Cell12.setBorder(PdfPCell.NO_BORDER);
            innerTable2Cell14.setBorder(PdfPCell.NO_BORDER);
            innerTable2Cell15.setBorder(PdfPCell.NO_BORDER);
            innerTable2Cell16.setBorder(PdfPCell.NO_BORDER);
            
            innerTable2Cell14.setPaddingLeft(24);
            innerTable2Cell15.setHorizontalAlignment(PdfPCell.ALIGN_LEFT);
            innerTable2Cell16.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
            
            innerTable2.addCell(innerTable2Cell10);
            innerTable2.addCell(innerTable2Cell11);
            innerTable2.addCell(innerTable2Cell12);  
            if(!createdByWeb){
                innerTable2.addCell(innerTable2Cell14);
                innerTable2.addCell(innerTable2Cell15); 
            }
            innerTable2.addCell(innerTable2Cell16);
            
            PdfPCell innertTable2Cell = new PdfPCell(innerTable2);
            innertTable2Cell.setBorder(PdfPCell.NO_BORDER);
            innertTable2Cell.setPaddingTop(10);
            outerTable.addCell(innertTable2Cell);
        }
    }

    private void setQuoteTableDetails(PdfPTable outerTable, float[] tabColumnWidths) {
        PdfPTable innerTableHead = new PdfPTable(tabColumnWidths);
        boolean createdByWeb = this.getSessionBean().isCreatedByWeb();
        innerTableHead.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        innerTableHead.setWidthPercentage(100f);
    
        
        PdfPCell innerTable2Cell7 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_ITEM, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
        PdfPCell innerTable2Cell8 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_DESC, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
        PdfPCell innerTable2Cell9 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_CHARGE_TYPE, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));     
        PdfPCell innerTable2Cell21 = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_SERIAL_QUANTITY, new Object[] {}, 
            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
        PdfPCell innerTable2CellUnit = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_UNIT_PRICE, new Object[] {}, 
            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A")))); 
        PdfPCell innerTable2CellTotal = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_TOTAL_PRICE, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL).toUpperCase(), new Font(condensedregularBaseFont, 10, 0, WebColors.getRGBColor("#53565A"))));
        
        innerTable2Cell7.setBorder(PdfPCell.NO_BORDER);
        innerTable2Cell8.setBorder(PdfPCell.NO_BORDER);
        innerTable2Cell9.setBorder(PdfPCell.NO_BORDER);
        innerTable2Cell21.setBorder(PdfPCell.NO_BORDER);
        innerTable2CellUnit.setBorder(PdfPCell.NO_BORDER);
        innerTable2CellTotal.setBorder(PdfPCell.NO_BORDER);
        innerTable2CellTotal.setHorizontalAlignment(PdfPCell.ALIGN_RIGHT);
        
        innerTable2Cell7.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        innerTable2Cell8.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        innerTable2Cell9.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        innerTable2Cell21.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        innerTable2CellUnit.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        innerTable2CellTotal.setBackgroundColor(WebColors.getRGBColor("#f9f9f9"));
        
        innerTableHead.addCell(innerTable2Cell7);
        innerTableHead.addCell(innerTable2Cell8);
        innerTableHead.addCell(innerTable2Cell9);
        if (!createdByWeb) {
            innerTableHead.addCell(innerTable2Cell21);
            innerTableHead.addCell(innerTable2CellUnit);
        }
        innerTableHead.addCell(innerTable2CellTotal);
        
        PdfPCell innertTable2CellHead = new PdfPCell(innerTableHead);
        innertTable2CellHead.setBorder(PdfPCell.NO_BORDER);
        outerTable.addCell(innertTable2CellHead);
    }

    private PdfPCell setCoverageDetails(PdfPTable innterTable1, ReviewQuotesBean quoteItem) {
        Phrase cover = null;
        PdfPCell blankCell = new PdfPCell();
        blankCell.setBorder(PdfPCell.NO_BORDER);
        blankCell.setPadding(10);
        PdfPCell innertable1CellServReq = new PdfPCell();        
        String quoteHeading =getErrorHandler().getFormattedErrorMessage(LynxConstants.REPAIR_QUOTE_REFERENCE, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL);
       
        if (quoteItem !=null){
        	if(StringUtils.isNotBlank(quoteItem.getProcessType()) && quoteItem.getProcessType().equalsIgnoreCase(LynxConstants.PROCESS_TYPE_PM_QUOTE) ){   
        		quoteHeading=getInternationalizationService().getLocalizeMessage(LynxConstants.PM_QUOTE_HEADING, null);
        	}else {
        		innertable1CellServReq = new PdfPCell(new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_SERVICE_REQ_NUMBER, new Object[] {}, 
        				LynxConstants.LYNX_CONTRACT_SERVICES_LABEL) + quoteItem.getServiceReqNum(), new Font(robotomediumBaseFont, 10, 0, WebColors.getRGBColor("#333"))));
        	}
        }    
        
        PdfPCell innertable1Cell1 = new PdfPCell(new Paragraph(quoteHeading + quoteItem.getQuoteId(), new Font(robotomediumBaseFont, 16)));
        try {
            String quoteExpireDate = AgilentDateTagConverter.formatDate(quoteItem.getSubscriptionEndDate(), getProfile().getUserCountry(), getCountryToDateFormatMap());
            cover = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_EXPIRATION_DATE, 
                    new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL) + LynxConstants.WHITE_SPACE + quoteExpireDate, new Font(condensedlightBaseFont, 12));
        } catch (Exception e) {
            cover = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_EXPIRATION_DATE, 
                    new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL) + LynxConstants.WHITE_SPACE + quoteItem.getSubscriptionEndDate(), new Font(condensedlightBaseFont, 12));
        }
        Paragraph coverageFor = new Paragraph();
        coverageFor.add(cover);
        PdfPCell innertable1Cell2 = new PdfPCell(coverageFor);
        innertable1CellServReq.setBorder(PdfPCell.NO_BORDER);
        innertable1Cell1.setBorder(PdfPCell.NO_BORDER);
        innertable1Cell2.setBorder(PdfPCell.NO_BORDER);
        innertable1Cell1.setPaddingTop(5);
        innertable1Cell2.setPaddingBottom(10);
        innterTable1.addCell(innertable1CellServReq);
        innterTable1.addCell(innertable1Cell1);
        innterTable1.addCell(innertable1Cell2);
        
        String salesPhone = quoteItem.getSalesRepPhone();
        String salesEmail = quoteItem.getSalesRepEmail();
        if(StringUtils.isNotBlank(salesPhone) || StringUtils.isNotBlank(salesEmail)) {
            Phrase assistanace = new Phrase(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_PDF_SALES_REP_NOTE, new Object[] {}, 
                    LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(condensedlightBaseFont, 9));
            
            Paragraph salesRep = new Paragraph();
            salesRep.add(assistanace);
            salesRep.add(LynxConstants.WHITE_SPACE);
            
            if (StringUtils.isNotBlank(salesPhone)) {
                String phone = LynxConstants.PLUS_SYMBOL + salesPhone;
                Phrase salesPhonePhrase = new Phrase(phone, new Font(condensedlightBaseFont, 9));
                salesRep.add(salesPhonePhrase);
                salesRep.add(LynxConstants.WHITE_SPACE);
            }
            if (StringUtils.isNotBlank(salesEmail)) {
                Phrase salesEmailPharse = new Phrase(salesEmail, new Font(condensedlightBaseFont, 9));
                salesRep.add(salesEmailPharse);
            }
            
            PdfPCell intertablelCell3 = new PdfPCell(salesRep);
            intertablelCell3.setBorder(PdfPCell.NO_BORDER);
            intertablelCell3.setPadding(10);
            intertablelCell3.setPaddingBottom(10);
            intertablelCell3.setBackgroundColor(WebColors.getRGBColor("#EEF7FC"));
            innterTable1.addCell(intertablelCell3);
        }
        innterTable1.addCell(blankCell);
        return blankCell;
    }
    
    
    
    private void setTermsAndConditionsLink(PdfPTable outerTable) {
        String termsandLinkurl= null;
        Paragraph paragraphNote = new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_PDF_NOTE, new Object[] {}, 
                LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotoregularBaseFont, 8));
        if(StringUtils.isNotBlank(domain)&&domain.contains(getCountryUtils().getChinaProfileCookieDomain())){
        	termsandLinkurl = getChinaConfiguration().getChinaTermsAndConditionLink();
        }else{
        	termsandLinkurl = getConfiguration().getTermsAndConditionLink();
        }
        Anchor anchor = new Anchor(LynxConstants.QUOTE_REPAIR_NEW_LINE + termsandLinkurl, new Font(robotoregularBaseFont, 8, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
        anchor.setReference(termsandLinkurl);
        paragraphNote.add(anchor);
        PdfPCell tAndCLink = new PdfPCell();
        tAndCLink.addElement(paragraphNote);
        tAndCLink.setBorder(PdfPCell.NO_BORDER);
        tAndCLink.setPaddingTop(20);
        outerTable.addCell(tAndCLink);
    }

 
    
    /**
     * Adding additional information in the Quote PDF
     * 
     * @param outerTable
     * @param quoteItem
     */
    private void setAdditionalComments(PdfPTable outerTable, ReviewQuotesBean quoteItem) {
        Phrase headerInfoPhrase;
      if (StringUtils.isNotBlank(quoteItem.getHeaderAdditionalInfo())) {
            Paragraph paragraphNote = new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_PDF_ADDITIONAL_INFO, new Object[]
                    {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL), new Font(robotoregularBaseFont, 8));
            if(StringUtils.isNotBlank(quoteItem.getProcessType()) && getAgilentConfigurationSecond().getPmProcessTypeCode().contains(quoteItem.getProcessType())){
            	headerInfoPhrase= new Phrase(LynxConstants.QUOTE_REPAIR_NEW_LINE + getInternationalizationService().getLocalizeMessage(LynxConstants.PM_PDF_ADDITIONAL_INFO,null), new Font(condensedlightBaseFont, 8));
            }
            else{
            	String additionalNote= quoteItem.getHeaderAdditionalInfo();
            	String referenceText=getAgilentConfigurationSecond().getReferenceText();
            	if(additionalNote.contains(referenceText)){
            		headerInfoPhrase = new Phrase(LynxConstants.QUOTE_REPAIR_NEW_LINE + getInternationalizationService().getLocalizeMessage(LynxConstants.QUOTE_REPAIR_PDF_ADDITIONAL_TEXT1,null), new Font(condensedlightBaseFont, 8));
            	}else{
            		headerInfoPhrase = new Phrase(LynxConstants.QUOTE_REPAIR_NEW_LINE + getInternationalizationService().getLocalizeMessage(LynxConstants.QUOTE_REPAIR_PDF_ADDITIONAL_TEXT2,null), new Font(condensedlightBaseFont, 8));
            	}
            }
            paragraphNote.add(headerInfoPhrase);
            PdfPCell additionalCommentsSection = new PdfPCell();
            additionalCommentsSection.addElement(paragraphNote);
            additionalCommentsSection.setBorder(PdfPCell.NO_BORDER);
            additionalCommentsSection.setPaddingTop(20);
            outerTable.addCell(additionalCommentsSection);
        }
    }
    
    private void setCommentsandLineItems(PdfPTable outerTable, ReviewQuotesBean quoteItem) {

        boolean commentAvailable = false;
        boolean itemAvailable = false;

        if (StringUtils.isNotBlank(quoteItem.getComments()) || (quoteItem.getItemAdditionalInfo() != null && !quoteItem.getItemAdditionalInfo().isEmpty())) {
            Paragraph paragraphNote = new Paragraph(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_PDF_NOTE, new Object[]
                {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL)+LynxConstants.WHITE_SPACE, new Font(condensedlightBaseFont, 8));
          
            if (StringUtils.isNotBlank(quoteItem.getComments())) {
                Phrase commentPhrase = new Phrase(quoteItem.getComments().trim(), new Font(condensedlightBaseFont, 8));
                paragraphNote.add(commentPhrase);
                commentAvailable = true;
            }
            if (quoteItem.getItemAdditionalInfo() != null && !quoteItem.getItemAdditionalInfo().isEmpty()) {
                if (commentAvailable) {
                    for (String itemInfo : quoteItem.getItemAdditionalInfo()) {
                        Phrase headerInfoPhrase = new Phrase(LynxConstants.QUOTE_REPAIR_NEW_LINE + itemInfo.trim(), new Font(condensedlightBaseFont, 8));
                        paragraphNote.add(headerInfoPhrase);

                    }

                } else {

                    for (String itemInfo : quoteItem.getItemAdditionalInfo()) {
                        if (itemAvailable) {
                            Phrase headerInfoPhrase = new Phrase(LynxConstants.QUOTE_REPAIR_NEW_LINE + itemInfo.trim(), new Font(condensedlightBaseFont, 8));
                            paragraphNote.add(headerInfoPhrase);
                        } else {
                            Phrase headerInfoPhrase = new Phrase(itemInfo.trim(), new Font(condensedlightBaseFont, 8));
                            paragraphNote.add(headerInfoPhrase);
                            itemAvailable = true;
                        }

                    }

                }

            }

            if (paragraphNote != null) {
                PdfPCell commentsSection = new PdfPCell();
                commentsSection.addElement(paragraphNote);
                commentsSection.setBorder(PdfPCell.NO_BORDER);
                commentsSection.setPaddingTop(3);
                outerTable.addCell(commentsSection);
            }

        }

    }
    private void setBottomLine(PdfPTable outerTable) {
        PdfPCell blankCell2 = new PdfPCell();
        blankCell2.setBorder(PdfPCell.NO_BORDER);
        blankCell2.setPaddingTop(10);
        blankCell2.setBorderWidthBottom(1);
        blankCell2.setBorderColorBottom(WebColors.getRGBColor("#e5e5e5"));
        outerTable.addCell(blankCell2);
    }
    
    class HeaderFooter extends PdfPageEventHelper {
        public void onEndPage(PdfWriter writer, Document document) {
            writer.getDirectContent();
            Image imageFooter = null;
            try {
                imageFooter = Image.getInstance(footerIamge);
            } catch (BadElementException e) {
                vlogDebug("BadElementException :: ", e.getMessage());
            } catch (MalformedURLException e) {
                 vlogDebug("MalformedURLException :: ", e.getMessage());
            } catch (IOException e) {
                vlogDebug("IOException :: ", e.getMessage());
            }
            imageFooter.scaleAbsolute(140f, 32f);
            imageFooter.setAbsolutePosition(20f, 20f);

            vlogDebug("inside inner class...");
            Chunk footerChunk = new Chunk(imageFooter, 0, 0);
            ColumnText.showTextAligned(writer.getDirectContent(), 0, new Phrase(footerChunk), document.leftMargin() + 5, document.top() + 10, 0);
        }
    }

    public String getPath(String s) {
        s = s.replace("\\", "/");
        return s;
    }

    public BaseFont getRoboFont(String font, Locale locale) throws DocumentException, IOException {
        BaseFont robotoFont = BaseFont.createFont(font, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        // Lynx Phase2 Story - DCCOM-835 - Apply CJK localization to Pdf generation -Start
        if (null != locale) {
            if (locale.toString().equals(Locale.CHINA.toString())) {
                robotoFont = BaseFont.createFont(CHINESE_FONT_STD, CHINESE_ENCODING, BaseFont.NOT_EMBEDDED);
            } else if (locale.toString().equals(Locale.KOREA.toString())) {
                robotoFont = BaseFont.createFont(KOREAN_FONT_STD_MEDIUM, KOREAN_ENCODING, BaseFont.NOT_EMBEDDED);
            } else if (locale.toString().equals(Locale.JAPAN.toString())) {
                robotoFont = BaseFont.createFont(JAPANESE_FONT_REGULAR, JAPANESE_ENCODING, BaseFont.NOT_EMBEDDED);
            }
        }
        // Lynx Phase2 Story - DCCOM-835 - Apply CJK localization to Pdf generation -End
        return robotoFont;
    }

    /**
     * Gets the value of property agilentServiceHistoryHelper
     *
     * @return the value of property agilentServiceHistoryHelper
     */
    public AgilentContractHistoryHelper getAgilentServiceHistoryHelper() {
        return agilentServiceHistoryHelper;
    }
    /**
     * Sets the value of property agilentServiceHistoryHelper with value pAgilentServiceHistoryHelper
     *
     * @param pAgilentServiceHistoryHelper
     *            for setting property agilentServiceHistoryHelper
     */
    public void setAgilentServiceHistoryHelper(AgilentContractHistoryHelper pAgilentServiceHistoryHelper) {
        agilentServiceHistoryHelper = pAgilentServiceHistoryHelper;
    }

    /**
     * Gets the value of property profile
     *
     * @return the value of property profile
     */
    public AgilentProfile getProfile() {
        return profile;
    }
    /**
     * Sets the value of property profile with value pProfile
     *
     * @param pProfile
     *            for setting property profile
     */
    public void setProfile(AgilentProfile pProfile) {
        profile = pProfile;
    }

    /**
     * Gets the value of property countryUtils
     *
     * @return the value of property countryUtils
     */
    public CountryUtils getCountryUtils() {
        return mCountryUtils;
    }
    /**
     * Sets the value of property countryUtils with value pCountryUtils
     *
     * @param pCountryUtils
     *            for setting property countryUtils
     */
    public void setCountryUtils(CountryUtils pCountryUtils) {
        mCountryUtils = pCountryUtils;
    }

    /**
     * Gets the value of property errorHandler
     *
     * @return the value of property errorHandler
     */
    public ErrorHandlerImpl getErrorHandler() {
        return mErrorHandler;
    }
    /**
     * Sets the value of property errorHandler with value pErrorHandler
     *
     * @param pErrorHandler
     *            for setting property errorHandler
     */
    public void setErrorHandler(ErrorHandlerImpl pErrorHandler) {
        mErrorHandler = pErrorHandler;
    }

    /**
     * Gets the value of property sessionBean
     *
     * @return the value of property sessionBean
     */
    public SessionBean getSessionBean() {
        return mSessionBean;
    }
    /**
     * Sets the value of property sessionBean with value pSessionBean
     *
     * @param pSessionBean
     *            for setting property sessionBean
     */
    public void setSessionBean(SessionBean pSessionBean) {
        mSessionBean = pSessionBean;
    }

    /**
     * Gets the value of property countryToDateFormatMap
     *
     * @return the value of property countryToDateFormatMap
     */
    public Map<String, String> getCountryToDateFormatMap() {
        return mCountryToDateFormatMap;
    }
    /**
     * Sets the value of property countryToDateFormatMap with value pCountryToDateFormatMap
     *
     * @param pCountryToDateFormatMap
     *            for setting property countryToDateFormatMap
     */
    public void setCountryToDateFormatMap(Map<String, String> pCountryToDateFormatMap) {
        mCountryToDateFormatMap = pCountryToDateFormatMap;
    }

    /**
     * Gets the value of property footerIamge
     *
     * @return the value of property footerIamge
     */
    public static String getFooterIamge() {
        return footerIamge;
    }
    /**
     * Sets the value of property footerIamge with value pFooterIamge
     *
     * @param pFooterIamge
     *            for setting property footerIamge
     */
    public static void setFooterIamge(String pFooterIamge) {
        footerIamge = pFooterIamge;
    }

    /**
     * Gets the value of property awesomeBaseFont
     *
     * @return the value of property awesomeBaseFont
     */
    public BaseFont getAwesomeBaseFont() {
        return awesomeBaseFont;
    }
    /**
     * Sets the value of property awesomeBaseFont with value pAwesomeBaseFont
     *
     * @param pAwesomeBaseFont
     *            for setting property awesomeBaseFont
     */
    public void setAwesomeBaseFont(BaseFont pAwesomeBaseFont) {
        awesomeBaseFont = pAwesomeBaseFont;
    }

    /**
     * Gets the value of property robotoregularBaseFont
     *
     * @return the value of property robotoregularBaseFont
     */
    public BaseFont getRobotoregularBaseFont() {
        return robotoregularBaseFont;
    }
    /**
     * Sets the value of property robotoregularBaseFont with value pRobotoregularBaseFont
     *
     * @param pRobotoregularBaseFont
     *            for setting property robotoregularBaseFont
     */
    public void setRobotoregularBaseFont(BaseFont pRobotoregularBaseFont) {
        robotoregularBaseFont = pRobotoregularBaseFont;
    }

    /**
     * Gets the value of property robotomediumBaseFont
     *
     * @return the value of property robotomediumBaseFont
     */
    public BaseFont getRobotomediumBaseFont() {
        return robotomediumBaseFont;
    }
    /**
     * Sets the value of property robotomediumBaseFont with value pRobotomediumBaseFont
     *
     * @param pRobotomediumBaseFont
     *            for setting property robotomediumBaseFont
     */
    public void setRobotomediumBaseFont(BaseFont pRobotomediumBaseFont) {
        robotomediumBaseFont = pRobotomediumBaseFont;
    }

    /**
     * Gets the value of property condensedlightBaseFont
     *
     * @return the value of property condensedlightBaseFont
     */
    public BaseFont getCondensedlightBaseFont() {
        return condensedlightBaseFont;
    }
    /**
     * Sets the value of property condensedlightBaseFont with value pCondensedlightBaseFont
     *
     * @param pCondensedlightBaseFont
     *            for setting property condensedlightBaseFont
     */
    public void setCondensedlightBaseFont(BaseFont pCondensedlightBaseFont) {
        condensedlightBaseFont = pCondensedlightBaseFont;
    }

    /**
     * Gets the value of property condensedboldeBaseFont
     *
     * @return the value of property condensedboldeBaseFont
     */
    public BaseFont getCondensedboldeBaseFont() {
        return condensedboldeBaseFont;
    }
    /**
     * Sets the value of property condensedboldeBaseFont with value pCondensedboldeBaseFont
     *
     * @param pCondensedboldeBaseFont
     *            for setting property condensedboldeBaseFont
     */
    public void setCondensedboldeBaseFont(BaseFont pCondensedboldeBaseFont) {
        condensedboldeBaseFont = pCondensedboldeBaseFont;
    }

    /**
     * Gets the value of property condensedregularBaseFont
     *
     * @return the value of property condensedregularBaseFont
     */
    public BaseFont getCondensedregularBaseFont() {
        return condensedregularBaseFont;
    }
    /**
     * Sets the value of property condensedregularBaseFont with value pCondensedregularBaseFont
     *
     * @param pCondensedregularBaseFont
     *            for setting property condensedregularBaseFont
     */
    public void setCondensedregularBaseFont(BaseFont pCondensedregularBaseFont) {
        condensedregularBaseFont = pCondensedregularBaseFont;
    }

    /**
     * @return the mConfiguration
     */
    public AgilentConfiguration getConfiguration() {
        return mConfiguration;
    }

    /**
     * @param mConfiguration the mConfiguration to set
     */
    public void setConfiguration(AgilentConfiguration mConfiguration) {
        this.mConfiguration = mConfiguration;
    }

    public List<String> getCountryToAddStamp() {
        return mCountryToAddStamp;
    }

    public void setCountryToAddStamp(List<String> pCountryToAddStamp) {
        mCountryToAddStamp = pCountryToAddStamp;
    }

    public Map<String, String> getStampImageMap() {
        return mStampImageMap;
    }

    public void setStampImageMap(Map<String, String> pStampImageMap) {
        mStampImageMap = pStampImageMap;
    }
    public Map<String, String> getImageHorizontalPositionMap() {
        return mImageHorizontalPositionMap;
    }
    
    public void setImageHorizontalPositionMap(Map<String, String> pImageHorizontalPositionMap) {
        this.mImageHorizontalPositionMap = pImageHorizontalPositionMap;
    }
   
    public Map<String, String> getImageScaleSizeMap() {
        return mImageScaleSizeMap;
    }
    
    public void setImageScaleSizeMap(Map<String, String> pImageScaleSizeMap) {
        this.mImageScaleSizeMap = pImageScaleSizeMap;
    }

    public InternationalizationService getInternationalizationService() {
        return mInternationalizationService;
    }

    public void setInternationalizationService(InternationalizationService pInternationalizationService) {
        mInternationalizationService = pInternationalizationService;
    }
  

	public List<String> getAFOCountries() {
        return mAFOCountries;
    }

    public void setAFOCountries(List<String> pAFOCountries) {
        mAFOCountries = pAFOCountries;
    }

	public List<String> getEMEAICountries() {
        return mEMEAICountries;
    }

    public void setEMEAICountries(List<String> pEMEAICountries) {
        mEMEAICountries = pEMEAICountries;
    }
	
	public List<String> getSAPKCountries() {
        return mSAPKCountries;
    }

    public void setSAPKCountries(List<String> pSAPKCountries) {
        mSAPKCountries = pSAPKCountries;
    }
	
	public String getTermsLinkForAFO() {
        return mTermsLinkForAFO;
    }
 
    public void setTermsLinkForAFO(String pTermsLinkForAFO) {
        mTermsLinkForAFO = pTermsLinkForAFO;
    }
    
	public String getTermsLinkForEMAEAI() {
        return mTermsLinkForEMAEAI;
    }
 
    public void setTermsLinkForEMAEAI(String pTermsLinkForEMAEAI) {
        mTermsLinkForEMAEAI = pTermsLinkForEMAEAI;
    }
    
	public String getTermsLinkForSAPK() {
        return mTermsLinkForSAPK;
    }
 
    public void setTermsLinkForSAPK(String pTermsLinkForSAPK) {
        mTermsLinkForSAPK = pTermsLinkForSAPK;
    }

    public AgilentConfigurationSecond getAgilentConfigurationSecond() {
        return agilentConfigurationSecond;
    }

    public void setAgilentConfigurationSecond(AgilentConfigurationSecond agilentConfigurationSecond) {
        this.agilentConfigurationSecond = agilentConfigurationSecond;
    }
    public ChinaConfiguration getChinaConfiguration() {
  		return mChinaConfiguration;
  	}

  	public void setChinaConfiguration(ChinaConfiguration pChinaConfiguration) {
  		this.mChinaConfiguration = pChinaConfiguration;
  	}
    
}
