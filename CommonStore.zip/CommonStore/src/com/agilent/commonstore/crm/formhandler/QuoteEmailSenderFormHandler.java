/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.formhandler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.formhandlers.AgilentEmailSenderFormHandler;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.QuoteDetails;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.base.platform.IErrorId;
import com.agilent.base.platform.SystemException;
import com.agilent.base.platform.ValidationExceptions;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.commonstore.crm.helper.AgilentQuoteDownloadHelper;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfAction;
import com.itextpdf.text.pdf.PdfDestination;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;

import atg.commerce.util.RepeatingRequestMonitor;
import atg.core.util.StringUtils;
import atg.repository.RepositoryException;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.RequestLocale;
import atg.userprofiling.email.TemplateEmailException;

/**
 * This form handler is used to handle the email.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class QuoteEmailSenderFormHandler extends AgilentEmailSenderFormHandler {

    private String mAgilentLogoImageName;
    private String emailQuoteSuccessURL;
    private String emailQuoteErrorURL;
    private String quoteId;
    private String uploadDirectory;
    private AgilentQuoteDownloadHelper mAgilentQuoteDownloadHelper;
    private SapFunctions mSapManager;
    private Map<String, String> mStampImageMap;
    public static String stampImage;
    
    public static String agilentLogo;
    public static final String USER_COUNTRY="userCountry";
    private List <String> storeQuoteStampCountry;
    private String encryptQuoteId;
    private String customQuote;
    private String acsQuoteDetailURL;
    


    /**
     * This method is invoked when the user tries to email his quote details. This sends email to intended recipient in
     * which quote will be attached as as a pdf file Quote details will be retrieved by making call to SAP.
     * 
     * @param pRequest,pResponse
     */
    public boolean handleEmailQuote(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {

        RepeatingRequestMonitor rrm = null;

        try {
            rrm = getRepeatingRequestMonitor();
            vlogInfo("Entering handle Email Quote PDF Functionality");
            if ((rrm == null) || (rrm.isUniqueRequestEntry("AgilentEmailSenderFormHandler.handleEmailQuote"))) {

            	if(StringUtils.isBlank(getQuoteId())){
            		setQuoteId(pRequest.getPostParameter("quoteId"));
            		setCcSender(pRequest.getPostParameter("ccSender"));
            		setMessage(pRequest.getPostParameter("message"));
            		setRecipientEmail(pRequest.getPostParameter("recipientEmail"));
            		setSubject(pRequest.getPostParameter("subject"));
            		setEncryptQuoteId(pRequest.getPostParameter("encryptQuoteId"));
            		setCustomQuote(pRequest.getPostParameter("customQuote"));
            	}
                if (StringUtils.isNotBlank(getQuoteId())) {
                    File file = null;
                    File dir;
                    Document document = null;
                    PdfPTable pdfTable = null;
                    QuoteDetails quoteDetails = null;
                    String fontPath = "";
                    PdfWriter writer = null;
                    FileOutputStream fop = null;
                    String FILE_NAME=null;
                    String salesOrg=(String) getProfile().getPropertyValue("sapSalesOrg");
                    String userCountry=(String) getProfile().getPropertyValue(USER_COUNTRY);
                    String imageOutputPath = pRequest.getRealPath("") + File.separator + "images";
                    String finalImagePath=null;
                    String fromPage = pRequest.getPostParameter("from_page");
                    vlogInfo("{0}", getQuoteId());
                    vlogDebug("{0}", getEmailQuoteSuccessURL());
                    vlogDebug("{0}", getMessage());
                    vlogDebug("{0}", getCcSender());
                    vlogInfo("{0}", getRecipientEmail());
                    vlogDebug("{0}", getSubject());
                    vlogDebug("{0}", getUploadDirectory());
                    vlogDebug("{0}", getConfiguration().getStaticFileLocation());
                    vlogDebug("{0}", fromPage);
                    vlogDebug("{0}", getEncryptQuoteId());
                    vlogDebug("{0}", getCustomQuote());
                    
                    if(StringUtils.isNotBlank(fromPage)){
                    	setEmailQuoteSuccessURL(fromPage);
                    	setEmailQuoteErrorURL(fromPage);
                    }

                    try {
                        getValidator().validate(Constants.EMAIL_CART, this);
                    } catch (SystemException exception) {
                        getErrorHandler().handleSystemException(exception, Constants.CART_VALIDATION, this);
                        vlogError(exception, "");
                    } catch (ValidationExceptions exception) {
                        getErrorHandler().handleValidationException(exception, Constants.CART_VALIDATION, this);

                    }
                    if (!checkFormRedirect(null, getEmailCartErrorURL(), pRequest, pResponse)) {
                        return false;
                    }

                    String completePath = getConfiguration().getStaticFileLocation() + File.separator + getUploadDirectory();
                    vlogDebug("Complete File location : {0}", completePath);
                    dir = new File(completePath);
                    if (!dir.exists()) {
                        dir.mkdirs();
                        vlogDebug("Directory location not found and hence creating the new directory location");
                    } else {
                        vlogDebug("Directory location found and hence reusing the existing directory location");
                    }

                    if (StringUtils.isNotBlank(getQuoteId())) {
                        try {
                            vlogDebug("Making sap call to retrieve the quoted details");
                            quoteDetails = getSapManager().getDocDetails(getQuoteId().trim());
                            vlogDebug("Data retrieved from sap sucessfully without any exceptions");
                        } catch (Exception e) {
                            vlogError(e, "Exception occured :: {0}", e.getMessage());
                            SystemException syseException = new SystemException(IErrorId.QUOTE_SYSTEM_ERROR);
                            getErrorHandler().handleSystemException(syseException, Constants.GENERAL, this);
                            return checkFormRedirect(getEmailQuoteSuccessURL(), getEmailQuoteErrorURL(), pRequest, pResponse);
                        }
                    }

                    try {
                        file = new File(completePath + File.separator + getQuoteId().trim() + ".pdf");
                        fop = new FileOutputStream(file);
                        FILE_NAME=getQuoteId().trim() + ".pdf";
                        if (!file.exists()) {
                            file.createNewFile();
                            vlogDebug("File creation has been done");
                        }
                        if (null != quoteDetails) {
                            vlogDebug("pdf generation is about to start");
                            fontPath = pRequest.getRealPath("");
                            fontPath = getPath(fontPath);
                            RequestLocale requestLocale = pRequest.getRequestLocale();
                            Locale locale = requestLocale.getLocale();
                            pdfTable = this.getAgilentQuoteDownloadHelper().getQuoteAsPDF(fontPath, locale, quoteDetails);
                            document = new Document(PageSize.A4, 50, 50, 50, 50);
                           // writer = PdfWriter.getInstance(document, fop);
                            writer = PdfWriter.getInstance(document, new FileOutputStream(new File(FILE_NAME)));
                            document.open();
                            document.add(pdfTable);
                            PdfDestination pdfDest = new PdfDestination(PdfDestination.XYZ, 0, document.getPageSize().getHeight(), 1f);
                            PdfAction action = PdfAction.gotoLocalPage(1, pdfDest, writer);
                            writer.setOpenAction(action);
                            document.close();
                            /** add stamp Image start**/
                            PdfReader reader= new PdfReader(FILE_NAME); 
                            PdfStamper stamper = new PdfStamper(reader, fop);
                            if (getStoreQuoteStampCountry().contains(userCountry)) {
                                if (getStampImageMap().containsKey(salesOrg)) {
                                    stampImage = imageOutputPath + File.separator + getStampImageMap().get(salesOrg);
                                    finalImagePath = getPath(stampImage);
                                    addStampImageOnPDF(reader, stamper, finalImagePath, userCountry);
                                } else {
                                    vlogDebug("No Stamp Image found for user country and sales org");
                                }
                            }
                            stamper.close();
                            reader.close();
                            /** add stamp Image End**/
                            vlogInfo("pdf generation has been successful for Quote Email");
                        }
                    } catch (DocumentException de) {
                        vlogError(de, "DocumentException occured :: {0}", de.getMessage());
                        SystemException syseException = new SystemException(IErrorId.QUOTE_SYSTEM_ERROR);
                        getErrorHandler().handleSystemException(syseException, Constants.GENERAL, this);
                        return checkFormRedirect(getEmailQuoteSuccessURL(), getEmailQuoteErrorURL(), pRequest, pResponse);

                    } catch (Exception e) {

                        vlogError(e, "Exception occured :: {0}", e.getMessage());
                        SystemException syseException = new SystemException(IErrorId.QUOTE_SYSTEM_ERROR);
                        getErrorHandler().handleSystemException(syseException, Constants.GENERAL, this);
                        return checkFormRedirect(getEmailQuoteSuccessURL(), getEmailQuoteErrorURL(), pRequest, pResponse);
                    } finally {
                        fop.close();
                    }

                    try {
                        File[] files = new File[1];
                        files[0] = file;
                        vlogDebug("Sending the pdf as a email attachment to customer");
                        getEmailTools().sendQuoteEmail(getProfile(), collectRequiredParams(), files);
                        vlogInfo("Quote Email has been sent Successfully");
                    } catch (TemplateEmailException e) {
                        SystemException syseException = new SystemException(IErrorId.SYSTEM_ERROR);
                        getErrorHandler().handleSystemException(syseException, Constants.EMAIL_TEMPLATE_EXCEPTION, this);
                        vlogError(e, "Temaplate Exception:{0}", e);
                    } catch (RepositoryException re) {
                        SystemException syseException = new SystemException(IErrorId.SYSTEM_ERROR);
                        getErrorHandler().handleSystemException(syseException, Constants.EMAIL_TEMPLATE_REPO_EXCEPTION, this);
                        vlogError(re, "Repository Exception:{0}", re);
                    }
                    setActionResult(Constants.MSG_ACTION_SUCCESS);
                    if (!checkFormRedirect(null, getEmailCartErrorURL(), pRequest, pResponse)) {
                        return false;
                    }
                } else {
                    vlogError("Quote ID is empty and hence cannot send email");
                    SystemException syseException = new SystemException(IErrorId.QUOTE_SYSTEM_ERROR);
                    getErrorHandler().handleSystemException(syseException, Constants.GENERAL, this);
                }
            }
        } catch (Exception e) {
            vlogError(e, "Exception occured :: {0}", e.getMessage());
            SystemException syseException = new SystemException(IErrorId.QUOTE_SYSTEM_ERROR);
            getErrorHandler().handleSystemException(syseException, Constants.GENERAL, this);
        } finally {
            if (rrm != null)
                rrm.removeRequestEntry("AgilentEmailSenderFormHandler.handleEmailQuote");

        }
        return checkFormRedirect(getEmailQuoteSuccessURL(), getEmailQuoteErrorURL(), pRequest, pResponse);
    }

    public String getPath(String s) {
        s = s.replace("\\", "/");
        return s;
    }

    public Map collectRequiredParams() {
        Map emailParams = new HashMap();
        AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfile().getProfileTools().getPropertyManager();
        DateFormat df = new SimpleDateFormat("EEEE ,MMMMM dd ,yyyy");
        Calendar cal = Calendar.getInstance();
        String date = df.format(cal.getTime());
        emailParams.put(getProfileParamNames(), getProfile());
        emailParams.put(getUserCountryParamName(), getProfile().getPropertyValue(propertyManager.getUserCountryPropertyName()));
        emailParams.put(getTemplateUrlName(), getTemplateUrl());
        emailParams.put(getSenderEmailParamName(), getSenderEmail());
        emailParams.put(getRecipientEmailParamName(), getRecipientEmail());
        emailParams.put(getMessageParamName(), getMessage());
        emailParams.put(getSubjectParamName(), getSubject());
        emailParams.put(getSkuIdParamName(), getSkuId());
        emailParams.put(getTypeParamName(), getType());
        emailParams.put(getDateParamName(), date);
        emailParams.put(getCcParamName(), getCcSender());
        if(getCustomQuote() != null && Constants.CUSTOM_QUOTE.equalsIgnoreCase(getCustomQuote())) {
	        String url = getAcsQuoteDetailURL() + getEncryptQuoteId();
	        emailParams.put("acsParamURL", url);
        }
        
        return emailParams;
    }

    
    public void addStampImageOnPDF(PdfReader reader, PdfStamper stamper, String finalImagePath, String userCountry)
            throws BadElementException, MalformedURLException, IOException, DocumentException {
        getAgilentQuoteDownloadHelper().addStampImageOnPDF(reader, stamper, finalImagePath, userCountry);
    }
    /**
     * Gets the value of property agilentLogoImageName
     *
     * @return the value of property agilentLogoImageName
     */
    public String getAgilentLogoImageName() {
        return mAgilentLogoImageName;
    }
    /**
     * Sets the value of property agilentLogoImageName with value pAgilentLogoImageName
     *
     * @param pAgilentLogoImageName
     *            for setting property agilentLogoImageName
     */
    public void setAgilentLogoImageName(String pAgilentLogoImageName) {
        mAgilentLogoImageName = pAgilentLogoImageName;
    }

    /**
     * Gets the value of property emailQuoteSuccessURL
     *
     * @return the value of property emailQuoteSuccessURL
     */
    public String getEmailQuoteSuccessURL() {
        return emailQuoteSuccessURL;
    }
    /**
     * Sets the value of property emailQuoteSuccessURL with value pEmailQuoteSuccessURL
     *
     * @param pEmailQuoteSuccessURL
     *            for setting property emailQuoteSuccessURL
     */
    public void setEmailQuoteSuccessURL(String pEmailQuoteSuccessURL) {
        emailQuoteSuccessURL = pEmailQuoteSuccessURL;
    }

    /**
     * Gets the value of property emailQuoteErrorURL
     *
     * @return the value of property emailQuoteErrorURL
     */
    public String getEmailQuoteErrorURL() {
        return emailQuoteErrorURL;
    }
    /**
     * Sets the value of property emailQuoteErrorURL with value pEmailQuoteErrorURL
     *
     * @param pEmailQuoteErrorURL
     *            for setting property emailQuoteErrorURL
     */
    public void setEmailQuoteErrorURL(String pEmailQuoteErrorURL) {
        emailQuoteErrorURL = pEmailQuoteErrorURL;
    }

    /**
     * Gets the value of property quoteId
     *
     * @return the value of property quoteId
     */
    public String getQuoteId() {
        return quoteId;
    }
    /**
     * Sets the value of property quoteId with value pQuoteId
     *
     * @param pQuoteId
     *            for setting property quoteId
     */
    public void setQuoteId(String pQuoteId) {
        quoteId = pQuoteId;
    }

    /**
     * Gets the value of property uploadDirectory
     *
     * @return the value of property uploadDirectory
     */
    public String getUploadDirectory() {
        return uploadDirectory;
    }
    /**
     * Sets the value of property uploadDirectory with value pUploadDirectory
     *
     * @param pUploadDirectory
     *            for setting property uploadDirectory
     */
    public void setUploadDirectory(String pUploadDirectory) {
        uploadDirectory = pUploadDirectory;
    }

    /**
     * Gets the value of property configuration
     *
     * @return the value of property configuration
     */
   
    /**
     * Gets the value of property agilentQuoteDownloadHelper
     *
     * @return the value of property agilentQuoteDownloadHelper
     */
    public AgilentQuoteDownloadHelper getAgilentQuoteDownloadHelper() {
        return mAgilentQuoteDownloadHelper;
    }
    /**
     * Sets the value of property agilentQuoteDownloadHelper with value pAgilentQuoteDownloadHelper
     *
     * @param pAgilentQuoteDownloadHelper
     *            for setting property agilentQuoteDownloadHelper
     */
    public void setAgilentQuoteDownloadHelper(AgilentQuoteDownloadHelper pAgilentQuoteDownloadHelper) {
        mAgilentQuoteDownloadHelper = pAgilentQuoteDownloadHelper;
    }

    /**
     * Gets the value of property sapManager
     *
     * @return the value of property sapManager
     */
    public SapFunctions getSapManager() {
        return mSapManager;
    }
    /**
     * Sets the value of property sapManager with value pSapManager
     *
     * @param pSapManager
     *            for setting property sapManager
     */
    public void setSapManager(SapFunctions pSapManager) {
        mSapManager = pSapManager;
    }

    public Map<String, String> getStampImageMap() {
        return mStampImageMap;
    }

    public void setStampImageMap(Map<String, String> pStampImageMap) {
        mStampImageMap = pStampImageMap;
    }

    public List <String> getStoreQuoteStampCountry() {
        return storeQuoteStampCountry;
    }

    public void setStoreQuoteStampCountry(List <String> pStoreQuoteStampCountry) {
        storeQuoteStampCountry = pStoreQuoteStampCountry;
    }

	/**
	 * @return the encryptQuoteId
	 */
	public String getEncryptQuoteId() {
		return encryptQuoteId;
	}

	/**
	 * @param encryptQuoteId the encryptQuoteId to set
	 */
	public void setEncryptQuoteId(String encryptQuoteId) {
		this.encryptQuoteId = encryptQuoteId;
	}

	/**
	 * @return the customQuote
	 */
	public String getCustomQuote() {
		return customQuote;
	}

	/**
	 * @param customQuote the customQuote to set
	 */
	public void setCustomQuote(String customQuote) {
		this.customQuote = customQuote;
	}

	/**
	 * @return the acsQuoteDetailURL
	 */
	public String getAcsQuoteDetailURL() {
		return acsQuoteDetailURL;
	}

	/**
	 * @param acsQuoteDetailURL the acsQuoteDetailURL to set
	 */
	public void setAcsQuoteDetailURL(String acsQuoteDetailURL) {
		this.acsQuoteDetailURL = acsQuoteDetailURL;
	}


}
