package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;

import javax.servlet.ServletException;

import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.commonstore.crm.bean.ServiceRequestBean;
import com.agilent.commonstore.crm.helper.AgilentServiceRequestHelper;

import atg.core.util.StringUtils;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.userprofiling.Profile;

/**
 * @author avneetkaur.m
 * @project Agilent.ServiceRequest
 * 
 */

/********This class is used for saving service request info of the user and sending email to CSR team*************/

public class SRSearchFormhandler extends GenericFormHandler {
	
	private String	mServiceRequestNo;	
	private ServiceRequestBean mSearchResultBean;
	private AgilentServiceRequestHelper mServiceRequestHelper;
	
	
	
	public void handleSRsearch(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {		
			
			/**** Sending serviceRequestNo to REST call for fetching the results *********/
			ServiceRequestBean serviceRequestBean = null;
			String searchRequestNo = null;
			
			Profile profile = null;
			profile = (Profile) pRequest.resolveName("atg/userprofiling/Profile");
			
			String sapContactID =  null;
			if (!profile.isTransient()) {
					 sapContactID = (String) profile.getPropertyValue(LynxConstants.SAP_CONTACT_NUMBER);
			}
			
			if (!StringUtils.isEmpty(getServiceRequestNo()) && !StringUtils.isEmpty(sapContactID)) {
				searchRequestNo = getServiceRequestNo();
				serviceRequestBean = getServiceRequestHelper().fetchSearchRequestDetails(searchRequestNo, sapContactID);
				setSearchResultBean(serviceRequestBean);
			}
			
	}

	
	/**
	 * @return the mServiceRequestNo
	 */
	public String getServiceRequestNo() {
		return mServiceRequestNo;
	}

	/**
	 * @param mServiceRequestNo the mServiceRequestNo to set
	 */
	public void setServiceRequestNo(String mServiceRequestNo) {
		this.mServiceRequestNo = mServiceRequestNo;
	}

	/**
	 * @return the mServiceRequestHelper
	 */
	public AgilentServiceRequestHelper getServiceRequestHelper() {
		return mServiceRequestHelper;
	}

	/**
	 * @param mServiceRequestHelper the mServiceRequestHelper to set
	 */
	public void setServiceRequestHelper(AgilentServiceRequestHelper mServiceRequestHelper) {
		this.mServiceRequestHelper = mServiceRequestHelper;
	}


	/**
	 * @return the mSearchResultBean
	 */
	public ServiceRequestBean getSearchResultBean() {
		return mSearchResultBean;
	}


	/**
	 * @param mSearchResultBean the mSearchResultBean to set
	 */
	public void setSearchResultBean(ServiceRequestBean mSearchResultBean) {
		this.mSearchResultBean = mSearchResultBean;
	}

}
