package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.profile.crm.LynxConstants;

import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;

/**
 * @author avneetkaur.m
 * @project Agilent.ServiceRequest
 * 
 */
/********This class is used for saving service request info of the user and sending email to CSR team*************/

public class SRSubmissionFormhandler extends GenericFormHandler {
	
	private String physicalAddress;	
	private String room;
	private String userName;
	private String contactName;
	private String contactPhone;
	private String contactEmail;
	private String aGLNumber;
	private String checkAGLNumber;
	private String unknownAGL;
	private String manufacturer;
	private String modelNumber;
	private String serialNumber;
	private String problem;
	private TemplateEmailInfoImpl  agilentSRSubmissionTemplateInfo;
	private String srTo;
	private String srSubject;
	private TemplateEmailSender templateEmailSender;
	private String mServiceRequestSuccessURL;
	private String mServiceRequestErrorURL;
	
	
	
	public boolean handleSRsubmissionForm(DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException, TemplateEmailException {		
			
			/****Sending  email to sales representative*********/
			Map<String, Object> templateParameters = new HashMap<String, Object>();
			templateParameters.put(LynxConstants.PHYSICAL_ADDRESS, getPhysicalAddress());
			templateParameters.put(LynxConstants.ROOM,getRoom());
			templateParameters.put(LynxConstants.CONTACT_NAME, getContactName());
			templateParameters.put(LynxConstants.CONTACT_PHONE,getContactPhone());
			templateParameters.put(LynxConstants.CONTACT_EMAIL, getContactEmail());
			templateParameters.put(LynxConstants.AGL_NUMBER, getaGLNumber());
			templateParameters.put(LynxConstants.CHECK_AGL_NUMBER, getCheckAGLNumber());
			if(Constants.TRUE.equalsIgnoreCase(getCheckAGLNumber())){
			templateParameters.put(LynxConstants.MANUFACTURER, getManufacturer());
			templateParameters.put(LynxConstants.MODEL_NUMBER, getModelNumber());
			templateParameters.put(LynxConstants.SERIAL_NUMBER, getSerialNumber());
			}
			templateParameters.put(LynxConstants.PROBLEM, getProblem());
			getAgilentSRSubmissionTemplateInfo().setTemplateParameters(templateParameters);
			getAgilentSRSubmissionTemplateInfo().setMessageFrom(getContactEmail());
			getAgilentSRSubmissionTemplateInfo().setMessageSubject(getSrSubject());
			getAgilentSRSubmissionTemplateInfo().setMessageTo(getSrTo());
			try {
				getTemplateEmailSender().sendEmailMessage(getAgilentSRSubmissionTemplateInfo(), new String[] { getSrTo() }, Boolean.FALSE, false);
			} catch (TemplateEmailException e) {
				e.printStackTrace();
			}
			return checkFormRedirect(getServiceRequestSuccessURL(), getServiceRequestErrorURL(), pRequest, pResponse);
	}

	
	
	public String getPhysicalAddress() {
		return physicalAddress;
	}
	
	public void setPhysicalAddress(String mPhysicalAddress) {
		physicalAddress = mPhysicalAddress;
	}
	
	public String getRoom() {
		return room;
	}
	
	public void setRoom(String mRoom) {
		room = mRoom;
	}
	
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String mUserName) {
		userName = mUserName;
	}
	
	public String getContactName() {
		return contactName;
	}
	
	public void setContactName(String mContactName) {
		contactName = mContactName;
	}
	
	public String getContactPhone() {
		return contactPhone;
	}
	
	public void setContactPhone(String mContactPhone) {
		contactPhone = mContactPhone;
	}
	
	public String getContactEmail() {
		return contactEmail;
	}
	
	public void setContactEmail(String mContactEmail) {
		contactEmail = mContactEmail;
	}

	public String getaGLNumber() {
		return aGLNumber;
	}
	
	public void setaGLNumber(String mAGLNumber) {
		aGLNumber = mAGLNumber;
	}

	public String getUnknownAGL() {
		return unknownAGL;
	}
	
	public void setUnknownAGL(String mUnknownAGL) {
		unknownAGL = mUnknownAGL;
	}
	
	public String getManufacturer() {
		return manufacturer;
	}
	
	public void setManufacturer(String mManufacturer) {
		manufacturer = mManufacturer;
	}
	
	public String getModelNumber() {
		return modelNumber;
	}
	
	public void setModelNumber(String mModelNumber) {
		modelNumber = mModelNumber;
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}
	
	public void setSerialNumber(String mSerialNumber) {
		serialNumber = mSerialNumber;
	}
	
	public String getProblem() {
		return problem;
	}
	
	public void setProblem(String mProblem) {
		problem = mProblem;
	}

	public String getSrTo() {
		return srTo;
	}

	public void setSrTo(String mSrTo) {
		srTo = mSrTo;
	}

	public TemplateEmailSender getTemplateEmailSender() {
		return templateEmailSender;
	}

	public void setTemplateEmailSender(TemplateEmailSender mTemplateEmailSender) {
		templateEmailSender = mTemplateEmailSender;
	}

	public String getCheckAGLNumber() {
		return checkAGLNumber;
	}

	public void setCheckAGLNumber(String mCheckAGLNumber) {
		checkAGLNumber = mCheckAGLNumber;
	}

	public TemplateEmailInfoImpl getAgilentSRSubmissionTemplateInfo() {
		return agilentSRSubmissionTemplateInfo;
	}

	public void setAgilentSRSubmissionTemplateInfo(
			TemplateEmailInfoImpl mAgilentSRSubmissionTemplateInfo) {
		agilentSRSubmissionTemplateInfo = mAgilentSRSubmissionTemplateInfo;
	}
	
	public String getSrSubject() {
		return srSubject;
	}
	
	public void setSrSubject(String mSrSubject) {
		srSubject = mSrSubject;
	}

	/**
	 * @return the mServiceRequestSuccessURL
	 */
	public String getServiceRequestSuccessURL() {
		return mServiceRequestSuccessURL;
	}

	/**
	 * @param mServiceRequestSuccessURL the mServiceRequestSuccessURL to set
	 */
	public void setServiceRequestSuccessURL(String mServiceRequestSuccessURL) {
		this.mServiceRequestSuccessURL = mServiceRequestSuccessURL;
	}

	/**
	 * @return the mServiceRequestErrorURL
	 */
	public String getServiceRequestErrorURL() {
		return mServiceRequestErrorURL;
	}

	/**
	 * @param mServiceRequestErrorURL the mServiceRequestErrorURL to set
	 */
	public void setServiceRequestErrorURL(String mServiceRequestErrorURL) {
		this.mServiceRequestErrorURL = mServiceRequestErrorURL;
	}
		
}
