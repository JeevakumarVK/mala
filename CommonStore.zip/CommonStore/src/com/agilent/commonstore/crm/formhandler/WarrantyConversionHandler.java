/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.crm.SAPCRMAPIManager;

import atg.core.util.StringUtils;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.droplet.DropletException;

import com.agilent.base.profile.SessionBean;

/**
 * This form handler is used for processing warranty page.
 */
public class WarrantyConversionHandler extends GenericFormHandler {

    private final String FULL_DEPENDANT = "fullyDependant";
    private final String SEMI_DEPENDANT = "semiDependant";
    private final String INDEPENDANT = "inDependant";

    private String mOpportunityId;
    private String mOriginalQuote;
    private String mCurrentService;
    private String mPreventiveDetail;
    private String mOpQualification;
    private String mWarrantyQAErrorURL;
    private String mWarrantyQASuccessURL;
    private String mWarrantyQARetryURL;
    private SAPCRMAPIManager mSapCRMAPIManager;

    private String mSerialNumber;
    private String mModelNumber;
    private String mZipCode;
    private String mEmail;
    private String mTelephone;
    private String mPrefContMet;
    private String mContactID;
    private String mResponseTime;
    private String mInstrumentType;
    private String mDescription;
    private String mProfilePostalCode;
    private String mProfilePhoneNumber;
    private String mProfileEmail;
    private String mRepairReqFormErrorURL;
    private String mRepairReqFormSuccessURL;
    private SessionBean mSessionBean;
    private String mOpportunityIds;
    private String mMoveToCreateAdjustedQuoteErrorURL;
    private String mMoveToCreateAdjustedQuoteSuccessURL;
    private String mShowPopup;
    private String mAdjustedQuote;
    private String mProcessType;
    private String mInstrumentAddress;
    private String mRepairCity;
    private String mRepairState;

    private String mRepairCountry;
    private Map<String, String> repairRequestResponse;
    private List<String> warrantyQuoteResponseErrorList;

    /**
     * This method is used to handle warranty question and answers.
     * 
     * @param request
     * @param response
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleConversionAnswers(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {

        vlogInfo("handleConversionAnswers starts with input values-> [currentService: {0}, preventiveDetail: {1}, opQualification: {2}, opportunityId: {3}]", getCurrentService(),
                getPreventiveDetail(), getOpQualification(), getOpportunityId());

        Map<String, String> requestDetailMap = new LinkedHashMap<String, String>();
        if (isWarrantyQARetry()) {
            vlogInfo("Warranty QA retry option selected.");
            setWarrantyQASuccessURL(getWarrantyQARetryURL());
        } else {
            requestDetailMap.put(LynxConstants.OPPORTUNITY_ID, getOpportunityId());
            if (StringUtils.isNotBlank(getOriginalQuote())) {
                requestDetailMap.put(LynxConstants.ORIGINAL_QUOTE, getOriginalQuote());
            }
            if (FULL_DEPENDANT.equalsIgnoreCase(getCurrentService())) {
                requestDetailMap.put(LynxConstants.REPAIR_ANSWER, LynxConstants.Y);
            } else {
                requestDetailMap.put(LynxConstants.REPAIR_ANSWER, LynxConstants.N);
            }
            if (LynxConstants.YES.equalsIgnoreCase(getPreventiveDetail())) {
                requestDetailMap.put(LynxConstants.PM, LynxConstants.Y);
            } else {
                requestDetailMap.put(LynxConstants.PM, LynxConstants.N);
            }
            if (LynxConstants.YES.equalsIgnoreCase(getOpQualification())) {
                requestDetailMap.put(LynxConstants.OP_QUALIFICATION, LynxConstants.Y);
            } else {
                requestDetailMap.put(LynxConstants.OP_QUALIFICATION, LynxConstants.N);
            }
            vlogInfo("about to invoke SAP CRM call with {0}", requestDetailMap.entrySet());
            if (requestDetailMap == null || requestDetailMap.isEmpty()) {
                vlogInfo("The Values are Empty in Answers so it don't invoke CRM {0}", requestDetailMap);
                addFormException(new DropletException("Empty Values Passed"));
            } else {
                vlogInfo("about to invoke SAP CRM call with {0}", requestDetailMap.entrySet());
                getSapCRMAPIManager().requestWarrantyQuoteCreation(requestDetailMap);
            }
            if (StringUtils.isNotBlank(getOpportunityId()) && StringUtils.isNotBlank(getOriginalQuote())) {
                getSessionBean().setOpportunityIdList(null);
                getSessionBean().setOriginalQuote(null);
            }
        }
        vlogInfo("handleConversionAnswers ends");
        return checkFormRedirect(getWarrantyQASuccessURL(), getWarrantyQAErrorURL(), request, response);
    }

    public boolean handleRepairRequestForm(DynamoHttpServletRequest request, DynamoHttpServletResponse response)
            throws ServletException, IOException, ParserConfigurationException, SAXException {
        String describeIssue = request.getParameter(LynxConstants.DESCRIBE_ISSUE_PARAM);
        String responseTime = request.getParameter("resType");
        repairRequestResponse = new LinkedHashMap<String, String>();
        getSessionBean().setRepairQuoteEmail(getEmail());

        Map<String, String> requestDetailMap = new LinkedHashMap<String, String>();
        requestDetailMap.put(LynxConstants.OPPORTUNITY_ID, LynxConstants.EMPTY);
        requestDetailMap.put(LynxConstants.REPAIR_ANSWER, LynxConstants.EMPTY);
        requestDetailMap.put(LynxConstants.PM, LynxConstants.EMPTY);
        requestDetailMap.put(LynxConstants.OP_QUALIFICATION, LynxConstants.EMPTY);
        requestDetailMap.put(LynxConstants.PRODUCT, LynxConstants.EMPTY);
        requestDetailMap.put(LynxConstants.SERIAL_NUM, getSerialNumber());
        requestDetailMap.put(LynxConstants.MODEL_NUM, getModelNumber());
        requestDetailMap.put(LynxConstants.RESPONSE_TIME, responseTime);
        requestDetailMap.put(LynxConstants.ZIP_CODE, getZipCode());
        requestDetailMap.put(LynxConstants.EMAIL_PARAM, getEmail());
        requestDetailMap.put(LynxConstants.TELEPHONE, getTelephone());
        requestDetailMap.put(LynxConstants.PERF_CONT_MET, getPrefContMet());
        requestDetailMap.put(LynxConstants.DESCRIPTION_PARAM, describeIssue);
        requestDetailMap.put(LynxConstants.CONTACT_ID_PARAM, getContactID());
        requestDetailMap.put(LynxConstants.PROCESS_TYPE, getProcessType());
        requestDetailMap.put(LynxConstants.STREET, getInstrumentAddress());
        requestDetailMap.put(LynxConstants.REGION, getRepairState());
        requestDetailMap.put(LynxConstants.COUNTRY, getRepairCountry());
        requestDetailMap.put(LynxConstants.CITY, getRepairCity());
        requestDetailMap.put(LynxConstants.INSTRUMENT_TYPE, getInstrumentType());

        vlogInfo("About to invoke SAP CRM call with {0}", requestDetailMap);
        //HttpResponse httpResponse = getSapCRMAPIManager().createWarrantyQuote(requestDetailMap);
        //Only the below if condition line added for AMS 52 Budgetary Quote Fallout 
        if (getInstrumentType() != null && getSerialNumber() != null && getModelNumber() != null && getEmail() != null) {
          HttpResponse httpResponse = getSapCRMAPIManager().createWarrantyQuote(requestDetailMap);
          if (httpResponse != null) {
            HttpEntity entity = httpResponse.getEntity();
            String responseXML = EntityUtils.toString(entity);
            vlogInfo("Response {0}", responseXML);
            if (StringUtils.isNotBlank(responseXML)) {
                InputSource is = new InputSource();
                is.setCharacterStream(new StringReader(responseXML));
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder;
                dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.parse(is);
                doc.getDocumentElement().normalize();
                NodeList nodes = doc.getElementsByTagName(LynxConstants.XML_TAG_PROPERTIES);

                if (nodes != null) {
                    Node node = nodes.item(0);
                    NodeList nodeList = node.getChildNodes();
                    if (nodeList != null) {
                        for (int i = 0; i < nodeList.getLength(); i++) {
                            Node nodeItem = nodeList.item(i);
                            if (nodeItem != null) {
                            if (nodeItem.getNodeType() == Node.ELEMENT_NODE && LynxConstants.XML_TAG_ERRORCODE.equalsIgnoreCase(nodeItem.getNodeName())) {
                                String errorCode = nodeItem.getTextContent();
                                vlogInfo("Error code in response {0}", errorCode);                               
                                if (StringUtils.isNotBlank(errorCode) && !getWarrantyQuoteResponseErrorList().isEmpty() && getWarrantyQuoteResponseErrorList().contains(errorCode)){                               
                                    repairRequestResponse.put(LynxConstants.STATUS, LynxConstants.FAILURE);
                                    repairRequestResponse.put(LynxConstants.ERROR_CODE_TXT, errorCode);
                                } else {
                                    repairRequestResponse.put(LynxConstants.STATUS, LynxConstants.SUCCESS);
                                    repairRequestResponse.put(LynxConstants.ERROR_CODE_TXT, "");
                                }
                                vlogInfo("Repair Request Response {0}", repairRequestResponse);
                            }
                        }
                        }
                    }
                }
            }
          }else{
            repairRequestResponse.put(LynxConstants.ERROR_CODE_TXT,"999");
        }
      }else{
          vlogInfo("The Values are Empty so it don't invoke CRM {0}", requestDetailMap);
          addFormException(new DropletException("Empty Values Passed"));
        }
        return checkFormRedirect(getRepairReqFormSuccessURL(), getRepairReqFormErrorURL(), request, response);
    }

    public boolean handleMoveToCreateAdjustedQuote(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        if (StringUtils.isNotBlank(getOpportunityIds()) && StringUtils.isNotBlank(getOriginalQuote())) {
            getSessionBean().setOpportunityIdList(getOpportunityIds());
            getSessionBean().setOriginalQuote(getOriginalQuote());
        }
        if (StringUtils.isNotBlank(getShowPopup()) && getShowPopup().equalsIgnoreCase(LynxConstants.CREATE_ERENEWAL) && StringUtils.isNotBlank(getOriginalQuote())) {
            Set<String> popupShownSet = getSessionBean().getQuoteAdjusted();
            popupShownSet.add(getOriginalQuote());
            getSessionBean().setQuoteAdjusted(popupShownSet);
            vlogInfo("adjusted quote list {0}", getSessionBean().getQuoteAdjusted());
        }
        return checkFormRedirect(getMoveToCreateAdjustedQuoteSuccessURL(), getMoveToCreateAdjustedQuoteErrorURL(), request, response);
    }

    public boolean handleSubmitAdjustedQuote(DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        Map<String, String> requestDetailMap = new LinkedHashMap<String, String>();
        if (StringUtils.isNotBlank(getOpportunityIds())) {
            requestDetailMap.put(LynxConstants.OPPORTUNITY_ID, getOpportunityIds());
        }
        if (StringUtils.isNotBlank(getOriginalQuote())) {
            requestDetailMap.put(LynxConstants.ORIGINAL_QUOTE, getOriginalQuote());
        }
        if (StringUtils.isNotBlank(getAdjustedQuote())) {
            requestDetailMap.put(LynxConstants.ADJUST_QUOTE, getAdjustedQuote());
        }

        if (requestDetailMap == null || requestDetailMap.isEmpty()) {
            vlogInfo("handleSubmitAdjustedQuote The Values are Empty so it don't invoke CRM {0}", requestDetailMap);
            addFormException(new DropletException("Empty Values Passed"));
        } else {
            vlogInfo("about to invoke CRM to create adjusted quote with {0}", requestDetailMap.entrySet());
            getSapCRMAPIManager().requestWarrantyQuoteCreation(requestDetailMap);
        }
        return checkFormRedirect(getWarrantyQASuccessURL(), getWarrantyQAErrorURL(), request, response);
    }

    /**
     * Returns true if currentService is semiDependant or inDependant, preventive detail is No, operation Qualification
     * is No. If True is returned no CRM call is done
     * 
     * @return
     */
    private boolean isWarrantyQARetry() {
        boolean isWarrantyQARetry = false;

        if ((SEMI_DEPENDANT.equalsIgnoreCase(getCurrentService()) || INDEPENDANT.equalsIgnoreCase(getCurrentService()))
                && (LynxConstants.NO.equalsIgnoreCase(getPreventiveDetail())) && (LynxConstants.NO.equalsIgnoreCase(getOpQualification()))) {
            isWarrantyQARetry = true;
        }

        return isWarrantyQARetry;
    }

    /**
     * Gets the value of property opportunityId
     *
     * @return the value of property opportunityId
     */
    public String getOpportunityId() {
        return mOpportunityId;
    }

    /**
     * Sets the value of property opportunityId with value pOpportunityId
     *
     * @param pOpportunityId
     *            for setting property opportunityId
     */
    public void setOpportunityId(String pOpportunityId) {
        mOpportunityId = pOpportunityId;
    }

    /**
     * Gets the value of property currentService
     *
     * @return the value of property currentService
     */
    public String getCurrentService() {
        return mCurrentService;
    }

    /**
     * Sets the value of property currentService with value pCurrentService
     *
     * @param pCurrentService
     *            for setting property currentService
     */
    public void setCurrentService(String pCurrentService) {
        mCurrentService = pCurrentService;
    }

    /**
     * Gets the value of property preventiveDetail
     *
     * @return the value of property preventiveDetail
     */
    public String getPreventiveDetail() {
        return mPreventiveDetail;
    }

    /**
     * Sets the value of property preventiveDetail with value pPreventiveDetail
     *
     * @param pPreventiveDetail
     *            for setting property preventiveDetail
     */
    public void setPreventiveDetail(String pPreventiveDetail) {
        mPreventiveDetail = pPreventiveDetail;
    }

    /**
     * Gets the value of property opQualification
     *
     * @return the value of property opQualification
     */
    public String getOpQualification() {
        return mOpQualification;
    }

    /**
     * Gets the value of property warrantyQAErrorURL
     *
     * @return the value of property warrantyQAErrorURL
     */
    public String getWarrantyQAErrorURL() {
        return mWarrantyQAErrorURL;
    }

    /**
     * Sets the value of property warrantyQAErrorURL with value pWarrantyQAErrorURL
     *
     * @param pWarrantyQAErrorURL
     *            for setting property warrantyQAErrorURL
     */
    public void setWarrantyQAErrorURL(String pWarrantyQAErrorURL) {
        mWarrantyQAErrorURL = pWarrantyQAErrorURL;
    }

    /**
     * Sets the value of property opQualification with value pOpQualification
     *
     * @param pOpQualification
     *            for setting property opQualification
     */
    public void setOpQualification(String pOpQualification) {
        mOpQualification = pOpQualification;
    }

    /**
     * Gets the value of property warrantyQASuccessURL
     *
     * @return the value of property warrantyQASuccessURL
     */
    public String getWarrantyQASuccessURL() {
        return mWarrantyQASuccessURL;
    }

    /**
     * Sets the value of property warrantyQASuccessURL with value pWarrantyQASuccessURL
     *
     * @param pWarrantyQASuccessURL
     *            for setting property warrantyQASuccessURL
     */
    public void setWarrantyQASuccessURL(String pWarrantyQASuccessURL) {
        mWarrantyQASuccessURL = pWarrantyQASuccessURL;
    }

    /**
     * Gets the value of property warrantyQARetryURL
     *
     * @return the value of property warrantyQARetryURL
     */
    public String getWarrantyQARetryURL() {
        return mWarrantyQARetryURL;
    }

    /**
     * Sets the value of property warrantyQARetryURL with value pWarrantyQARetryURL
     *
     * @param pWarrantyQARetryURL
     *            for setting property warrantyQARetryURL
     */
    public void setWarrantyQARetryURL(String pWarrantyQARetryURL) {
        mWarrantyQARetryURL = pWarrantyQARetryURL;
    }

    /**
     * Gets the value of property sapCRMAPIManager
     *
     * @return the value of property sapCRMAPIManager
     */
    public SAPCRMAPIManager getSapCRMAPIManager() {
        return mSapCRMAPIManager;
    }

    /**
     * Sets the value of property sapCRMAPIManager with value pSapCRMAPIManager
     *
     * @param pSapCRMAPIManager
     *            for setting property sapCRMAPIManager
     */
    public void setSapCRMAPIManager(SAPCRMAPIManager pSapCRMAPIManager) {
        mSapCRMAPIManager = pSapCRMAPIManager;
    }

    public String getSerialNumber() {
        return mSerialNumber;
    }

    public void setSerialNumber(String pSerialNumber) {
        mSerialNumber = pSerialNumber;
    }

    public String getModelNumber() {
        return mModelNumber;
    }

    public void setModelNumber(String pModelNumber) {
        mModelNumber = pModelNumber;
    }

    public String getResponseTime() {
        return mResponseTime;
    }

    public void setResponseTime(String pResponseTime) {
        mResponseTime = pResponseTime;
    }

    public String getZipCode() {
        return mZipCode;
    }

    public void setZipCode(String pZipCode) {
        mZipCode = pZipCode;
    }

    public String getEmail() {
        return mEmail;
    }

    public void setEmail(String pEmail) {
        mEmail = pEmail;
    }

    public String getTelephone() {
        return mTelephone;
    }

    public void setTelephone(String pTelephone) {
        mTelephone = pTelephone;
    }

    public String getPrefContMet() {
        return mPrefContMet;
    }

    public void setPrefContMet(String pPrefContMet) {
        mPrefContMet = pPrefContMet;
    }

    public String getDescription() {
        return mDescription;
    }

    public void setDescription(String pDescription) {
        mDescription = pDescription;
    }

    public String getContactID() {
        return mContactID;
    }

    public void setContactID(String pContactID) {
        mContactID = pContactID;
    }

    public String getInstrumentType() {
        return mInstrumentType;
    }

    public void setInstrumentType(String pInstrumentType) {
        mInstrumentType = pInstrumentType;
    }

    public String getRepairReqFormErrorURL() {
        return mRepairReqFormErrorURL;
    }

    public void setRepairReqFormErrorURL(String pRepairReqFormErrorURL) {
        mRepairReqFormErrorURL = pRepairReqFormErrorURL;
    }

    public String getRepairReqFormSuccessURL() {
        return mRepairReqFormSuccessURL;
    }

    public void setRepairReqFormSuccessURL(String pRepairReqFormSuccessURL) {
        mRepairReqFormSuccessURL = pRepairReqFormSuccessURL;
    }

    public String getProfilePostalCode() {
        return mProfilePostalCode;
    }

    public void setProfilePostalCode(String pProfilePostalCode) {
        mProfilePostalCode = pProfilePostalCode;
    }

    public String getProfilePhoneNumber() {
        return mProfilePhoneNumber;
    }

    public void setProfilePhoneNumber(String pProfilePhoneNumber) {
        mProfilePhoneNumber = pProfilePhoneNumber;
    }

    public String getProfileEmail() {
        return mProfileEmail;
    }

    public void setProfileEmail(String pProfileEmail) {
        mProfileEmail = pProfileEmail;
    }

    public SessionBean getSessionBean() {
        return mSessionBean;
    }

    public void setSessionBean(SessionBean pSessionBean) {
        this.mSessionBean = pSessionBean;
    }

    public String getOriginalQuote() {
        return mOriginalQuote;
    }

    public void setOriginalQuote(String pOriginalQuote) {
        mOriginalQuote = pOriginalQuote;
    }

    public String getOpportunityIds() {
        return mOpportunityIds;
    }

    public void setOpportunityIds(String pOpportunityIds) {
        mOpportunityIds = pOpportunityIds;
    }

    public String getMoveToCreateAdjustedQuoteErrorURL() {
        return mMoveToCreateAdjustedQuoteErrorURL;
    }

    public void setMoveToCreateAdjustedQuoteErrorURL(String pMoveToCreateAdjustedQuoteErrorURL) {
        mMoveToCreateAdjustedQuoteErrorURL = pMoveToCreateAdjustedQuoteErrorURL;
    }

    public String getMoveToCreateAdjustedQuoteSuccessURL() {
        return mMoveToCreateAdjustedQuoteSuccessURL;
    }

    public void setMoveToCreateAdjustedQuoteSuccessURL(String pMoveToCreateAdjustedQuoteSuccessURL) {
        mMoveToCreateAdjustedQuoteSuccessURL = pMoveToCreateAdjustedQuoteSuccessURL;
    }

    public String getShowPopup() {
        return mShowPopup;
    }

    public void setShowPopup(String pShowPopup) {
        mShowPopup = pShowPopup;
    }

    public String getAdjustedQuote() {
        return mAdjustedQuote;
    }

    public void setAdjustedQuote(String pAdjustedQuote) {
        mAdjustedQuote = pAdjustedQuote;
    }

    public String getProcessType() {
        return mProcessType;
    }

    public void setProcessType(String pProcessType) {
        this.mProcessType = pProcessType;
    }

    public String getRepairState() {
        return mRepairState;
    }

    public void setRepairState(String pRepairState) {
        this.mRepairState = pRepairState;
    }

    public String getRepairCountry() {
        return mRepairCountry;
    }

    public void setRepairCountry(String pRepairCountry) {
        this.mRepairCountry = pRepairCountry;
    }

    public String getInstrumentAddress() {
        return mInstrumentAddress;
    }

    public void setInstrumentAddress(String pInstrumentAddress) {
        this.mInstrumentAddress = pInstrumentAddress;
    }

    public String getRepairCity() {
        return mRepairCity;
    }

    public void setRepairCity(String pRepairCity) {
        this.mRepairCity = pRepairCity;
    }

    public Map<String, String> getRepairRequestResponse() {
        return repairRequestResponse;
    }

    public void setRepairRequestResponse(Map<String, String> repairRequestResponse) {
        this.repairRequestResponse = repairRequestResponse;
    }

    public List<String> getWarrantyQuoteResponseErrorList() {
        return warrantyQuoteResponseErrorList;
    }

    public void setWarrantyQuoteResponseErrorList(List<String> warrantyQuoteResponseErrorList) {
        this.warrantyQuoteResponseErrorList = warrantyQuoteResponseErrorList;
    }

}
