package com.agilent.commonstore.crm.formhandler;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;

import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.crm.SAPCRMAPIManager;

import atg.core.util.StringUtils;
import atg.droplet.DropletException;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

public class WarrantyQuoteAdjustFormHandler extends GenericFormHandler {

	private SAPCRMAPIManager mSapCRMAPIManager;
	private EncryptDecryptHelper mEncryptDecryptHelper;
	private String warrantyAdjustmentSuccessURL;
	private String warrantyAdjustmentErrorURL;
	private String warrantyQuote;
	private String contractId;
	private String eRenewalQuoteId;
	 private String mShowPopup;
	 private SessionBean mSessionBean;

	public static final String WARRANTY_QUOTE = "WarrantyQuote";
	public static final String CONTRACT_ID = "ContractId";
	public static final String E_RENEWAL_QUOTEID = "ErenewalQuoteId";

	public boolean handleMoveToAdjustQuoteService(DynamoHttpServletRequest request, DynamoHttpServletResponse response)
            throws ServletException, IOException {

        vlogDebug("WarrantyQuoteAdjustFormHandler.handleMoveToAdjustQuoteService Entering");

        Map<String, String> inputParameters = new HashMap<String, String>();
        String plainWarrantyQuote = null;
        String plainContractId = null;
        String plainERenewalQuoteId = null;
        try {
            if (StringUtils.isNotEmpty(getWarrantyQuote()) && StringUtils.isNotEmpty(getContractId())) {
                plainWarrantyQuote = getEncryptDecryptHelper().decrypt(getWarrantyQuote(), LynxConstants.EMPTY);
                plainContractId = getEncryptDecryptHelper().decrypt(getContractId(), LynxConstants.EMPTY);
                if (StringUtils.isNotEmpty(geteRenewalQuoteId())) {
                    plainERenewalQuoteId = getEncryptDecryptHelper().decrypt(geteRenewalQuoteId(), LynxConstants.EMPTY);
                }
                if(StringUtils.isNotBlank(getShowPopup()) && getShowPopup().equalsIgnoreCase("createWarranty") && StringUtils.isNotBlank(plainWarrantyQuote)){
                    Set <String> popupShownSet= getSessionBean().getQuoteAdjusted();
                    popupShownSet.add(plainWarrantyQuote);
                    getSessionBean().setQuoteAdjusted(popupShownSet);
                    vlogInfo("adjusted quote list {0}",getSessionBean().getQuoteAdjusted());
                }
                inputParameters.put(WARRANTY_QUOTE, plainWarrantyQuote);
                inputParameters.put(CONTRACT_ID, plainContractId);
                inputParameters.put(E_RENEWAL_QUOTEID, plainERenewalQuoteId);
                vlogDebug("Decrypted Input Parameter to Service = {0}", inputParameters);
                int responseCode = getSapCRMAPIManager().adjustedQuoteService(inputParameters);
                if (responseCode != 201) {
                    addFormException(new DropletException("Exception occured in adjustedQuoteService"));
                }
                vlogDebug("responseJson from CRM Service = {0}", responseCode);
            } else {
                vlogDebug("Mandatory input parameters null or empty");
                addFormException(new DropletException("Mandatory input parameters missing in the request"));
            }
        } catch (ApplicationException e) {
            vlogError(e, "ApplicationException got while trying to Decrypt");
        }

        vlogDebug("WarrantyQuoteAdjustFormHandler.handleMoveToAdjustQuoteService Exiting");

        return checkFormRedirect(getWarrantyAdjustmentSuccessURL(), getWarrantyAdjustmentErrorURL(), request, response);
    }

	/**
	 * @return the sapCRMAPIManager
	 */
	public SAPCRMAPIManager getSapCRMAPIManager() {
		return mSapCRMAPIManager;
	}

	/**
	 * @param sapCRMAPIManager
	 *            the sapCRMAPIManager to set
	 */
	public void setSapCRMAPIManager(SAPCRMAPIManager sapCRMAPIManager) {
		this.mSapCRMAPIManager = sapCRMAPIManager;
	}

	/**
     * @return the encryptDecryptHelper
     */
    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return mEncryptDecryptHelper;
    }

    /**
     * @param encryptDecryptHelper the encryptDecryptHelper to set
     */
    public void setEncryptDecryptHelper(EncryptDecryptHelper encryptDecryptHelper) {
        this.mEncryptDecryptHelper = encryptDecryptHelper;
    }

    /**
	 * @return the warrantyAdjustmentSuccessURL
	 */
	public String getWarrantyAdjustmentSuccessURL() {
		return warrantyAdjustmentSuccessURL;
	}

	/**
	 * @param warrantyAdjustmentSuccessURL
	 *            the warrantyAdjustmentSuccessURL to set
	 */
	public void setWarrantyAdjustmentSuccessURL(String warrantyAdjustmentSuccessURL) {
		this.warrantyAdjustmentSuccessURL = warrantyAdjustmentSuccessURL;
	}

	/**
	 * @return the warrantyAdjustmentErrorURL
	 */
	public String getWarrantyAdjustmentErrorURL() {
		return warrantyAdjustmentErrorURL;
	}

	/**
	 * @param warrantyAdjustmentErrorURL
	 *            the warrantyAdjustmentErrorURL to set
	 */
	public void setWarrantyAdjustmentErrorURL(String warrantyAdjustmentErrorURL) {
		this.warrantyAdjustmentErrorURL = warrantyAdjustmentErrorURL;
	}

	/**
	 * @return the warrantyQuote
	 */
	public String getWarrantyQuote() {
		return warrantyQuote;
	}

	/**
	 * @param warrantyQuote
	 *            the warrantyQuote to set
	 */
	public void setWarrantyQuote(String warrantyQuote) {
		this.warrantyQuote = warrantyQuote;
	}

	/**
	 * @return the contractId
	 */
	public String getContractId() {
		return contractId;
	}

	/**
	 * @param contractId
	 *            the contractId to set
	 */
	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	/**
	 * @return the eRenewalQuoteId
	 */
	public String geteRenewalQuoteId() {
		return eRenewalQuoteId;
	}

	/**
	 * @param eRenewalQuoteId
	 *            the eRenewalQuoteId to set
	 */
	public void seteRenewalQuoteId(String eRenewalQuoteId) {
		this.eRenewalQuoteId = eRenewalQuoteId;
	}

    public String getShowPopup() {
        return mShowPopup;
    }

    public void setShowPopup(String pShowPopup) {
        mShowPopup = pShowPopup;
    }

    public SessionBean getSessionBean() {
        return mSessionBean;
    }

    public void setSessionBean(SessionBean pSessionBean) {
        mSessionBean = pSessionBean;
    }

}
