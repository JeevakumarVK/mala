/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.helper;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;

import com.agilent.base.commerce.Constants;
import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.crm.bean.ActiveContractBean;
import com.agilent.base.crm.bean.ContactDetailsBean;
import com.agilent.base.crm.bean.ExihibitBean;
import com.agilent.base.crm.bean.RenewalQuoteRefBean;
import com.agilent.base.crm.bean.ReviewQuoteComponentsInfo;
import com.agilent.base.crm.bean.ReviewQuoteDetailsInfo;
import com.agilent.base.crm.bean.ReviewQuotesBean;
import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.base.rest.lms.RestClient;
import com.agilent.base.util.AgilentUtil;
import com.agilent.base.util.crm.CRMUtil;
import com.agilent.commonstore.crm.bean.ContractHistoryBean;
import com.agilent.commonstore.crm.bean.NewAspenQuoteBean;
import com.agilent.i18n.service.InternationalizationService;

import atg.commerce.order.OrderManager;
import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.repository.MutableRepository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryItemDescriptor;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;
import atg.servlet.RequestLocale;
import atg.servlet.ServletUtil;

/**
 * This is class process service contracts.
 */
@SuppressWarnings({"unchecked", "cast"})
public class AgilentContractHistoryHelper extends GenericService {

    private SAPCRMAPIManager sapcrmapiManager;
    private RestClient restClient;
    private CRMUtil crmUtil;
    private EncryptDecryptHelper encryptDecryptHelper;
    private String mRqlContractQuery;
    private OrderManager mOrderManager;
    private ErrorHandlerImpl errorHandler;
    private List<String> repairOrderOpenStatusList;
    private List<String> repairOrderClosedStatusList;    
    private Integer mPrevMainDropdownSkipMonths;
    private Integer mOldContractExpiredDaysDisplay;
    private List<String> mInternationalLocaleList;
    private Integer mExpiredContractRenewalDays;
    private InternationalizationService mInternationalizationService; 
    private Map<String, String> mCurrencyCodeToLocaleMap;
    private String mAdjustedQuoteDateFormat;
    private Integer mMinWarrantyDays;
    private Integer mMaxWarrantyDays;
    private String mQuoteDateFormat;
    private AgilentConfigurationSecond agilentConfigurationSecond;
    
    public List<ContractHistoryBean> fetchContractDetails(String sapContactID) {
        RestClient client = getRestClient();
        ContractHistoryBean contractBean = null;
        String agilentLocale=null;
        try {
            List<ContractHistoryBean> contractInfomration = new ArrayList<ContractHistoryBean>();   
            Map<String, Object> contractDetails = getSapcrmapiManager().getContractHistoryCall(client, sapContactID);
            if (contractDetails != null && contractDetails.containsKey("errorCode") && contractDetails.get("errorCode").equals("500")) {
                contractBean = new ContractHistoryBean();
                contractBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NETWORK, new Object[] {}, 
                        LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                contractInfomration.add(contractBean);
            } else {
                List<Map<String, Object>> contractResultsList = (List<Map<String, Object>>) contractDetails.get(LynxConstants.RESULTS);
                if (contractResultsList != null && contractResultsList.size() > 0) {
                    for (Map<String, Object> contractInfo : contractResultsList) {
                        contractBean = new ContractHistoryBean();
                        setContractInfo(contractInfo, contractBean, contractResultsList);
                        Map<String, Object> partnerResults = (Map<String, Object>) contractInfo.get(LynxConstants.PARTNERS_SET);
                        List<Map<String, Object>> partnerResultsList = (List<Map<String, Object>>) partnerResults.get(LynxConstants.RESULTS);
                        agilentLocale = determineUserLocale();
                        boolean populateSoldTo=true;
                        for (Map<String, Object> partnerInfo : partnerResultsList) {
                            if ((LynxConstants.SOLD_TO_PARTY_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                    vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                    setPartnerInfo(contractBean, partnerInfo);
                                    populateSoldTo = false;
                                } else if (populateSoldTo && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                    vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                    setPartnerInfo(contractBean, partnerInfo);
                                }
                            }
                        }                       
                            contractInfomration.add(contractBean);                       
                    }                  
                    
                } else {
                    vlogInfo("No data found from transaction Id {0}", sapContactID);
                    contractBean = new ContractHistoryBean();
                    contractBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    contractInfomration.add(contractBean);
                }
            }
            return contractInfomration;
        } catch (ClientProtocolException e) {
            vlogError(e, "Error in calling the profile call");
        } catch (IOException e) {
            vlogError(e, "IOException data");
        }
        return null;
    }

    private void setPartnerInfo(ContractHistoryBean contractBean, Map<String, Object> partnerInfo) {
        contractBean.getAddress().setAddress1((String) partnerInfo.get(LynxConstants.HOUSE_NO));
        contractBean.getAddress().setAddress2((String) partnerInfo.get(LynxConstants.STREET));
        contractBean.getAddress().setAddress3((String) partnerInfo.get(LynxConstants.REGION));
        contractBean.getAddress().setCity((String) partnerInfo.get(LynxConstants.CITY));
        contractBean.getAddress().setPostalCode((String) partnerInfo.get(LynxConstants.POSTAL_CODE));
        contractBean.getAddress().setCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
        contractBean.getAddress().setPhoneNumber((String) partnerInfo.get(LynxConstants.PHONE));
        contractBean.setName((String) partnerInfo.get(LynxConstants.NAME));
        contractBean.setPartnerAccountId((String) partnerInfo.get(LynxConstants.PARTNER_NO));
    }

    private void setContractInfo(Map<String, Object> contractInfo, ContractHistoryBean contractBean, List<Map<String, Object>> contractResultsList) {
        String quoteCurrency=null;
        Locale currencyLocale = Locale.US;
        contractBean.setContractId((String) contractInfo.get(LynxConstants.CONTRACT_Id));
        vlogDebug("Setting Contract info for:{0} ", contractBean.getContractId());
        String encContractId = encyptTransaction((String) contractInfo.get(LynxConstants.CONTRACT_Id));
        contractBean.setEncyContractId(encContractId);
        contractBean.setSubscriptionStartDate((String) contractInfo.get(LynxConstants.CONTRACT_START_DATE));
        contractBean.setSubscriptionEndDate((String) contractInfo.get(LynxConstants.CONTRACT_END_DATE));
        contractBean.setPurchaseOrderNum((String) contractInfo.get(LynxConstants.PURCHASE_ORDER_NUM));
        
		
        //DCCOM-4945-Display on-demand order on landing page-Start
    	contractBean.setProcessTypeContract((String) contractInfo.get(LynxConstants.PROCESS_TYPE_CONTRACT));       
        contractBean.setContractStatus((String) contractInfo.get(LynxConstants.CONTRACT_STATUS));
        //DCCOM-4945-Display on-demand order on landing page-End
        contractBean.setContractCreationDate((String) contractInfo.get(LynxConstants.CREATION_DATE));
        contractBean.setContractGrossValue((String) contractInfo.get(LynxConstants.CONTRACT_GROSS_VALUE));
        contractBean.setContractNetValue((String) contractInfo.get(LynxConstants.CONTRACT_NET_VALUE));
        contractBean.setPreProcessType((String) contractInfo.get(LynxConstants.PRE_PROCESS_TYPE));
        if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.EXP_CONT_ID))
                && !LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            contractBean.setExpContractId((String) contractInfo.get(LynxConstants.EXP_CONT_ID));
            String encExpContractId = encyptTransaction((String) contractInfo.get(LynxConstants.EXP_CONT_ID));
            contractBean.setEncyptExpContractId(encExpContractId);
            contractBean.setDisplayFlag(true);
            int oldContractExpiredDays = getCrmUtil().calculateDaysLeft((String) contractInfo.get(LynxConstants.CONTRACT_START_DATE));
            if (oldContractExpiredDays < 0 && Math.abs(oldContractExpiredDays) > getOldContractExpiredDaysDisplay()){
                contractBean.setDisplayOldContractId(false);
            }
        }
        if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.NEW_CONT_ID))
                && !LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            for (Map<String, Object> newContractMap : contractResultsList) {
                String contID = (String) newContractMap.get(LynxConstants.CONTRACT_Id);
                if (contID.equalsIgnoreCase((String) contractInfo.get(LynxConstants.NEW_CONT_ID)))
                    contractBean.setNewContractDate((String) newContractMap.get(LynxConstants.CONTRACT_START_DATE));
            }
            contractBean.setNewContractId((String) contractInfo.get(LynxConstants.NEW_CONT_ID));
            String encNewContractId = encyptTransaction((String) contractInfo.get(LynxConstants.NEW_CONT_ID));
            contractBean.setEncyptNewContractId(encNewContractId);
            contractBean.setDisplayFlag(true);
        }
        Map<String, Object> quoteSetResults = (Map<String, Object>) contractInfo.get(LynxConstants.QUOTES_SET);
        List<Map<String, Object>> quoteSetList = (List<Map<String, Object>>) quoteSetResults.get(LynxConstants.RESULTS);
        Map<String, Object> partnerSetResult = (Map<String, Object>) contractInfo.get(LynxConstants.QUOTE_PARTNER_SET);
        List<Map<String, Object>> partnerResultsList = (List<Map<String, Object>>) partnerSetResult.get(LynxConstants.RESULTS);

        contactFormData(partnerResultsList, contractBean);
        int totalQuotes = quoteSetList.size();
        contractBean.setTotalQuotes(totalQuotes);
        if (totalQuotes == 1) {
            for (Map<String, Object> quote : quoteSetList) {
                String renewalID = (String) quote.get(LynxConstants.QUOTE_ID);
                String encQuoteId = encyptTransaction((String) quote.get(LynxConstants.QUOTE_ID));                
                contractBean.setRenewalID(renewalID);
                contractBean.setEncyptRenewalID(encQuoteId);
                quoteCurrency= (String) quote.get(LynxConstants.CURRENCY);
                contractBean.setQuoteValidDate((String) quote.get(LynxConstants.QUOTE_VALID_TO));
            }
        } else {
            Date latestCreationDate = null;
            Date quoteCreationDate = new Date();
            for (Map<String, Object> quote : quoteSetList) {
                String originalQuoteId = (String) quote.get(LynxConstants.ORIGINAL_QUOTE);
                String quoteId = (String) quote.get(LynxConstants.QUOTE_ID);
                String quotCreateDate = (String) quote.get(LynxConstants.CREATED_ON);
                if (quoteCurrency == null) {
                    quoteCurrency = (String) quote.get(LynxConstants.CURRENCY);
                }  
                contractBean.setQuoteValidDate((String) quote.get(LynxConstants.QUOTE_VALID_TO));
                contractBean.setRenewalID(quoteId);
                contractBean.setEncyptRenewalID(encyptTransaction(quoteId));
                vlogDebug("QuoteId: {0} OriginalQuoteId: {1} Quote CreatedOn: {2}", quoteId, originalQuoteId, quotCreateDate);
                if (StringUtils.isNotBlank(quotCreateDate)) {
                    try {
                        SimpleDateFormat sdf = new SimpleDateFormat(getAdjustedQuoteDateFormat());
                        quoteCreationDate = sdf.parse(quotCreateDate);
                    } catch (ParseException e) {
                        vlogError("CreatedOn Date parsing error for quoteId {0}", quoteId);
                        continue;
                    }
                }
                if (StringUtils.isNotBlank(originalQuoteId) && StringUtils.isNotBlank(quoteId)
                        && (latestCreationDate == null || quoteCreationDate.after(latestCreationDate))) {
                    vlogDebug("Setting AdjustedQuoteId: {0} OriginalQuoteId: {1}", quoteId, originalQuoteId);
                    contractBean.setAdjustedQuoteId(quoteId);
                    contractBean.setEncryptedAdjustedQuoteId(encyptTransaction(quoteId));
                    contractBean.setOriginalQuoteId(originalQuoteId);
                    contractBean.setEncryptedOriginalQuoteId(encyptTransaction(originalQuoteId));
                    if ("X".equals((String) quote.get(LynxConstants.ADD_ON_QUOTE))) {
                        contractBean.setAddOnQuote(true);
                    } else{
                        contractBean.setAddOnQuote(false);
                    }
                    latestCreationDate = quoteCreationDate;
                }
            }
        }                
        int daysLeft = 0;
        if(StringUtils.isNotBlank(contractBean.getSubscriptionEndDate())){
	         daysLeft = getCrmUtil().calculateDaysLeft(contractBean.getSubscriptionEndDate());
			 vlogDebug("Days Left:{0} ", daysLeft);
	        if (daysLeft == 0) {
	            contractBean.setExpiringDays(1);
	        } else {
	            contractBean.setExpiringDays(daysLeft + 1);
	        }
       }
        
        if(StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.SAP_AUTORENEWAL_INDICATOR)) && 
        		LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.SAP_AUTORENEWAL_INDICATOR))){
        	vlogDebug("Auto Renewal Contract:{0} ", contractBean.getContractId());
        	contractBean.setAutoRenewFlag(true);        	   	       	    	
        	if (daysLeft <= 120 && daysLeft >= 0) {
        		if(totalQuotes != 0){  
        			contractBean.setReviewQuoteAndexpMessg(true);
        		}
        		contractBean.setExpiringInFlag(true);
        	}	        	           	    
        }           
        
        else{
	
	        if (StringUtils.isEmpty((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
	            if (StringUtils.isEmpty((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
	                int futureDate = getCrmUtil().calculateDaysLeft(contractBean.getSubscriptionStartDate());
					vlogDebug("Future Date:{0} ", futureDate);
	                if (futureDate > 0) {
	                    contractBean.setStatusMessage(LynxConstants.FUTURE_CONTRACT);
	                }
	                if (daysLeft < 0) {
	                    contractBean.setExpiringContractFlag(true);
	                    if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.NEW_CONT_ID))) {
	                        contractBean.setNewContractId((String) contractInfo.get(LynxConstants.NEW_CONT_ID));
	                        String encNewContractId = encyptTransaction((String) contractInfo.get(LynxConstants.NEW_CONT_ID));
	                        contractBean.setEncyptNewContractId(encNewContractId);
	                    }
	                }
	                if (daysLeft <= 120 && daysLeft > 0) {
	                    contractBean.setExpiringInFlag(true);
	                }
	            } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
	                    && LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
	                contractBean.setStatusMessage(LynxConstants.PENDING);
	                if (daysLeft < 0) {
	                    contractBean.setExpiringContractFlag(true);
	                }
	            }
	
	        } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))
	                && StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
						vlogDebug("AspenQuoteCreated and ContractRenewed not empty ");
	            if (LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
	                    && LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
	                contractBean.setStatusMessage(LynxConstants.PENDING);
	                if (daysLeft < 0) {
	                    contractBean.setExpiringContractFlag(true);
	                }
	            }
	            if (LynxConstants.CONTRACT_RENEWED_R.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
	                    && LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
	                if (daysLeft < 0) {
	                    contractBean.setExpiringContractFlag(true);
	                }
	            }
	        } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))
	                && StringUtils.isEmpty((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
						vlogDebug("AspenQuoteCreated is not empty and ContractRenewed is empty ");
	            if (LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED)) && totalQuotes != 0) {
	                if (daysLeft <= 120 && daysLeft >= 0) {
	                    if (findContractIdInOrder((String) contractInfo.get(LynxConstants.CONTRACT_Id))) {
	                        contractBean.setStatusMessage(LynxConstants.PENDING);
	                    } else {
	                        contractBean.setReviewQuoteAndexpMessg(true);
	                        contractBean.setExpiringInFlag(true);
	                    }
						vlogDebug("Expiring Flag:{0} ", contractBean.isExpiringInFlag());
	                } else if (daysLeft < 0) {
	                    contractBean.setExpiringContractFlag(true);
						vlogDebug("Expire Contract Flag:{0} ", contractBean.isExpiringContractFlag());
						if (Math.abs(daysLeft) <= getExpiredContractRenewalDays()) {
                            contractBean.setReviewQuoteAndexpMessg(true);
                        }
	                    if (daysLeft > 0) {
	                        contractBean.setReviewQuoteAndexpMessg(true);
	                    }
	                }
	            } else {
	                if (daysLeft <= 120 && daysLeft > 0) {
	                    contractBean.setExpiringInFlag(true);
						vlogDebug("Expiring Flag:{0} ", contractBean.isExpiringInFlag());
	                }
	            }            
	          
	        }
       }
        
       if (!StringUtils.isEmpty(contractBean.getProcessTypeContract()) && contractBean.getProcessTypeContract().equals(LynxConstants.REPAIR_ORDER_CONTRACT)) {			
				contractBean.setRepairOrderStatus(getRepairOrderStatus(contractBean.getContractStatus()));			
	   }
    
       if (StringUtils.isNotBlank(quoteCurrency) && StringUtils.isNotBlank(contractBean.getContractGrossValue())) {
           Double contractGrossPriceDouble = new Double(contractBean.getContractGrossValue().trim());
           if (getCurrencyCodeToLocaleMap().containsKey(quoteCurrency)) {
               currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(quoteCurrency));
           }
           String formattedGrossPrice = formatCurrency(contractGrossPriceDouble, currencyLocale.toString(), quoteCurrency);
           contractBean.setContractGrossValue(formattedGrossPrice);

       }
       
        vlogDebug("Updated ContractInfo {0} ",contractBean); 
		vlogDebug("Exiting out of method setContractInfo"); 
    }

    public boolean findContractIdInOrder(String contractId) {
        MutableRepository orderImpl = (MutableRepository) getOrderManager().getOrderTools().getOrderRepository();
        RepositoryItem[] orderItems = null;
        String contractIdRep = "";
        boolean isContractIdExist = false;
        try {
            Object[] params = new Object[1];
            RepositoryItemDescriptor orderDescriptor = orderImpl.getItemDescriptor("order");
            RepositoryView orderView = orderDescriptor.getRepositoryView();

            params[0] = contractId;
            RqlStatement statement = RqlStatement.parseRqlStatement(getRqlContractQuery());
            orderItems = statement.executeQuery(orderView, params);
            if (orderItems != null) {
                for (RepositoryItem orderItem : orderItems) {
                    contractIdRep = (String) orderItem.getPropertyValue("contractId");
                    if (contractId != null && contractId.equalsIgnoreCase(contractIdRep)) {
                        isContractIdExist = true;
                        break;
                    }
                }
            }
        } catch (RepositoryException e) {
            if (isLoggingError()) {
                logError("Repository Exception in finding contractId in order repository:" + contractId, e);
            }
        }
        return isContractIdExist;
    }
    
    public String findOrderIdForContractIdInOrder(String contractId) {
        MutableRepository orderImpl = (MutableRepository) getOrderManager().getOrderTools().getOrderRepository();
        RepositoryItem[] orderItems = null;
        String contractAutoRenew = null;
        String matchedContractId = "";
        String orderId = null;
        try {
            Object[] params = new Object[1];
            RepositoryItemDescriptor orderDescriptor = orderImpl.getItemDescriptor("order");
            RepositoryView orderView = orderDescriptor.getRepositoryView();

            params[0] = contractId;
            RqlStatement statement = RqlStatement.parseRqlStatement(getRqlContractQuery());
            orderItems = statement.executeQuery(orderView, params);
            if (orderItems != null) {
                for (RepositoryItem orderItem : orderItems) {
                	matchedContractId = (String) orderItem.getPropertyValue("contractId");
                    contractAutoRenew = (String) orderItem.getPropertyValue("contractAutoRenew");
                    if (contractId != null && contractId.equalsIgnoreCase(matchedContractId) && LynxConstants.STRING_TRUE.equals(contractAutoRenew)) {
                    	orderId = orderItem.getRepositoryId();
                        break;
                    }
                }
            }
        } catch (RepositoryException e) {
            if (isLoggingError()) {
                logError("Repository Exception in finding contractId in order repository:" + contractId, e);
            }
        }
        vlogDebug("The order id for the selected contract id :: {0} and contractAutoRenew value is {1} ", orderId, contractAutoRenew);
        return orderId;
    }

    private void contactFormData(List<Map<String, Object>> partnerResultsList, ContractHistoryBean contractInfo) {
        for (Map<String, Object> partnerInfo : partnerResultsList) {
            if ((LynxConstants.SOLD_TO_CONTACT_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                contractInfo.setContactName((String) partnerInfo.get(LynxConstants.NAME));
                contractInfo.setContactEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
                contractInfo.setContactPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
                contractInfo.setContactRegion((String) partnerInfo.get(LynxConstants.REGION));
                contractInfo.setContactCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
            }
            if ((LynxConstants.SOLD_TO_SALES_REP).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                contractInfo.setSalesName((String) partnerInfo.get(LynxConstants.NAME));
                contractInfo.setSalesPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
                contractInfo.setSalesEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
            }
        }
    }

    private String encyptTransaction(String transactionId) {
        String encryptKey = "";
        try {
            if (StringUtils.isNotBlank(transactionId)) {
                encryptKey = getEncryptDecryptHelper().encrypt(transactionId);
            }
        } catch (ApplicationException e) {
            vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt");
        }
        return encryptKey;
    }

    public void populateCreatedByWebQuoteValues(List<ReviewQuotesBean> reviewQuoteItems) {
    	  List<ReviewQuoteDetailsInfo> quoteItemList = new ArrayList<ReviewQuoteDetailsInfo>();
          if (reviewQuoteItems != null && reviewQuoteItems.get(0) != null && reviewQuoteItems.get(0).getQuoteItems() != null && !reviewQuoteItems.get(0).getQuoteItems().isEmpty()) {
              vlogDebug("QuoteItems size before alteration for CreatedByWeb quotes logic " + reviewQuoteItems.get(0).getQuoteItems().size());
              for (ReviewQuoteDetailsInfo quoteItem : reviewQuoteItems.get(0).getQuoteItems()) {
            	  String processTypeCode = reviewQuoteItems.get(0).getProcessType();
            	  boolean pmOrderFlag = reviewQuoteItems.get(0).isPmOrderFlag(); 
            	  if (quoteItem !=null && StringUtils.isNotBlank(processTypeCode)){
            		  if(getAgilentConfigurationSecond().getPmProcessTypeCode().contains(processTypeCode) || pmOrderFlag){
            			  quoteItem.setServicePlan(getInternationalizationService().getLocalizeMessage(LynxConstants.PM_ORDER_DESCRIPTION, null));
            			  quoteItem.setChargeType(getInternationalizationService().getLocalizeMessage(LynxConstants.PM_CHARGE_TYPE, null));
            		  }else if (getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(processTypeCode)){ 
            			  quoteItem.setServicePlan(getInternationalizationService().getLocalizeMessage(LynxConstants.EXTIMATED_REPAIR_SERVICE, null));
            			  quoteItem.setChargeType(getInternationalizationService().getLocalizeMessage(LynxConstants.REPAIR_PARTS_LABOR, null));
            			  quoteItem.setOrderedProd(getInternationalizationService().getLocalizeMessage(LynxConstants.ORDERED_TYPE_REPAIR, null));            
            			  quoteItem.setUnitPrice("");
            			  quoteItem.setItemQuantityValue(0); 
            		  } 
            		  if(StringUtils.isNotBlank(quoteItem.getProcessType()) && quoteItem.getProcessType().equalsIgnoreCase(LynxConstants.PROCESS_TYPE_REPAIR_QUOTE)){ 
            			  if (reviewQuoteItems.get(0).getPriceListMap() != null && reviewQuoteItems.get(0).getPriceListMap().get(0) != null
            					  && reviewQuoteItems.get(0).getPriceListMap().get(0).entrySet() != null && reviewQuoteItems.get(0).getPriceListMap().get(0).entrySet().iterator() != null) {
            				  quoteItem.setQuoteSystemGrossValue(reviewQuoteItems.get(0).getPriceListMap().get(0).entrySet().iterator().next().getValue());                  
            			  }
            			  if (reviewQuoteItems.get(0).getFormattedPriceListMap() != null && reviewQuoteItems.get(0).getFormattedPriceListMap().get(0) != null
            					  && reviewQuoteItems.get(0).getFormattedPriceListMap().get(0).entrySet() != null && reviewQuoteItems.get(0).getFormattedPriceListMap().get(0).entrySet().iterator() != null) {
            				  quoteItem.setFormattedQuoteSystemGrossValue(reviewQuoteItems.get(0).getFormattedPriceListMap().get(0).entrySet().iterator().next().getValue());                    
            			  }
            		  }
            		  vlogDebug("QuoteItems details : ServicePlan: {0}, ChargeType: {1}, UnitPrice: {2}, ItemQuantityValue: {3}, QuoteSystemGrossValue: {4}", quoteItem.getServicePlan(),
            				  quoteItem.getChargeType(), quoteItem.getUnitPrice(), quoteItem.getItemQuantityValue(), quoteItem.getQuoteSystemGrossValue());
            		  quoteItemList.add(quoteItem);
            		  break;
            	  }
                
            }
              
              if(quoteItemList!=null && !quoteItemList.isEmpty()){
            	  reviewQuoteItems.get(0).setQuoteItems(quoteItemList);
              }
            vlogDebug("QuoteItems size after alteration for CreatedByWeb quotes logic " + reviewQuoteItems.get(0).getQuoteItems().size());
        }
       
    }
    /*
     *  This method takes quote's gross amount, online discount percentage, currency as input 
     *  and calculates and returns formatted discount amount allowed for that quote if user place online SSD quote order. 
     */
	public String fetchOnlineDiscountAmount(Double grossAmount, Double discountPercentage, String currency) {
		vlogDebug("getOnlineDiscountAmount:: grossAmount: {0} discountPercentage: {1} currency: {2}", grossAmount, discountPercentage, currency);
		Locale currencyLocale = Locale.US;
		if (getCurrencyCodeToLocaleMap().containsKey(currency)) {
			currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(currency));
			vlogDebug("getOnlineDiscountAmount:: currencyLocale: {0}", currencyLocale);
		}
		Double onlineDiscountAmt = grossAmount * discountPercentage / 100;
		String formattedOnlineDiscountAmt = formatCurrency(onlineDiscountAmt, currencyLocale.toString(), currency);
		vlogDebug("getOnlineDiscountAmount:: onlineDiscountAmt: {0} formattedOnlineDiscountAmt: {1} ", onlineDiscountAmt, formattedOnlineDiscountAmt);
		return formattedOnlineDiscountAmt;
	}
	
	
	 public List<ReviewQuotesBean> fetchQuoteDetails(String quoteId, boolean isContractFlag, String contrID) {		 
		 return fetchQuoteDetails(quoteId,isContractFlag,contrID,null);			 
	 }
	    
    public List<ReviewQuotesBean> fetchQuoteDetails(String quoteId, boolean isContractFlag, String contrID,Map<String,String> additionalReqParams) {
    	List<ReviewQuotesBean> quotesList = null;
        ReviewQuotesBean reviewQuoteBean = null;
        List<Map<String, Object>> quoteItems = null;
        List<Map<String, Object>> quoteResultsList = null;
        ReviewQuoteDetailsInfo quoteItemsInfo = null;
        List<Map<String, Object>> quoteSystemSets = null;
        List<ReviewQuoteDetailsInfo> reviewQuoteDetailsList = null;
        ReviewQuoteComponentsInfo reviewQuoteComponentsInfo = null;
        List<ReviewQuoteComponentsInfo> reviewQuoteComponentsList = null;
        String quoteComponentItemName = "";
        String quoteItemName = "";
        List<Map<String, Object>> partnerResultsList = null;
        List<Map<String, Object>> exihibitSet = null;
        List<Map<String, Object>> pricesSet = null;
        List<Map<String, Object>> multipleQuoteSets = null;
        List<RenewalQuoteRefBean> quoteItemsList = null;
        RenewalQuoteRefBean renewalQuoteRefBean = null;
        String priceDesc = "";
        String totalAmount = "";
        String formattedtotalAmount = "";
        Map<String, String> priceMap = null;         
        Map<String, String> formattedPriceMap = null;
        List<Map<String, String>> listPriceMap = new LinkedList<Map<String, String>>();
        List<Map<String, String>> formattedListPriceMap = new LinkedList<Map<String, String>>();
        List<ExihibitBean> exihibitList = new ArrayList<ExihibitBean>();
        ExihibitBean exihibitBean = null;
        List<String> newList =new ArrayList<>();
        int count = 0;
        String agilentLocale = null;
        boolean showCoverageDate=true;
        Locale currencyLocale = Locale.US;
        boolean serviceChargeFlag = true;
        boolean isCreatedByWeb = false;   
        boolean isCreatedByWebRepairQuote = false;
        boolean isCreatedByWebPMQuote = false;
        boolean p2WRepairQuote=false;
        try {
            quotesList = new ArrayList<ReviewQuotesBean>();
            RestClient client = getRestClient();            
            Map<String, Object> quoteDetails = getSapcrmapiManager().getQuoteDetailsCall(client, quoteId ,additionalReqParams);
            if (quoteDetails != null && quoteDetails.containsKey("errorCode") && quoteDetails.get("errorCode").equals("500")) {
                reviewQuoteBean = new ReviewQuotesBean();
                reviewQuoteBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NETWORK, new Object[] {}, 
                        LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                quotesList.add(reviewQuoteBean);
                vlogInfo("We're sorry,There is problem in Network Connection QuoteId {0}", quoteId);
            } else {
                quoteResultsList = (List<Map<String, Object>>) quoteDetails.get(LynxConstants.RESULTS);
                if (quoteResultsList != null && quoteResultsList.size() > 0) {
                    vlogInfo("getting results from Sap web service for QuoteId {0}", quoteId);
                    if (quoteDetails.containsKey("csrfToken")) {
                        Map<String, Object> tokenMap = new HashMap<String, Object>();
                        tokenMap.put("csrfToken", quoteDetails.get("csrfToken"));
                        quoteResultsList.add(tokenMap);
                    }

                    for (Map<String, Object> quoteRefItem : quoteResultsList) {
                        if (!quoteRefItem.containsKey("csrfToken")) {
                            reviewQuoteBean = new ReviewQuotesBean();
                            if (!isContractFlag) {
                                reviewQuoteBean.setQuoteId(quoteId);
                                if (StringUtils.isNotBlank(contrID))
                                    reviewQuoteBean.setContrID(contrID);
                                String encContractId = encyptTransaction(quoteId);
                                reviewQuoteBean.setEncryptQuoteId(encContractId);
                            }
                            if (isContractFlag) {
                                reviewQuoteBean.setContractId(quoteId);
                                String encContractId = encyptTransaction(quoteId);
                                reviewQuoteBean.setEncryptContractId(encContractId);
                            }
                            reviewQuoteBean.setTransactionId((String) quoteRefItem.get(LynxConstants.TRANSACTION_ID));
                            reviewQuoteBean.setSubscriptionStartDate((String) quoteRefItem.get(LynxConstants.START_DATE));
                            reviewQuoteBean.setQuoteExpireDate((String) quoteRefItem.get(LynxConstants.End_Date));
                            reviewQuoteBean.setSubscriptionEndDate((String) quoteRefItem.get(LynxConstants.End_Date));
                            reviewQuoteBean.setBillingFreq((String) quoteRefItem.get(LynxConstants.Bill_Freq));
                            reviewQuoteBean.setServiceReqNum((String) quoteRefItem.get(LynxConstants.SERVICE_REQ_NUM));
                            reviewQuoteBean.setPaymentTerms((String) quoteRefItem.get(LynxConstants.PAYMENT_TERMS));
                            reviewQuoteBean.setCurrency((String) quoteRefItem.get(LynxConstants.CURRENCY));
                            reviewQuoteBean.setRenewContId((String) quoteRefItem.get(LynxConstants.RENEW_CONT_ID));
                            reviewQuoteBean.setExpContId((String) quoteRefItem.get(LynxConstants.EXPD_CONT_ID));
                            reviewQuoteBean.setEncryptRenewContId(encyptTransaction((String) quoteRefItem.get(LynxConstants.RENEW_CONT_ID)));
                            reviewQuoteBean.setEncryptExpContId(encyptTransaction((String) quoteRefItem.get(LynxConstants.EXPD_CONT_ID)));
                            reviewQuoteBean.setContractEndDate((String) quoteRefItem.get(LynxConstants.CONTR_END_DATE)); 
                            reviewQuoteBean.setProcessType((String) quoteRefItem.get(LynxConstants.PROCESS_TYPE));
                            reviewQuoteBean.setCombinedContractId((String) quoteRefItem.get(LynxConstants.CONTRACT_Id));
                            reviewQuoteBean.setPreProcessType((String) quoteRefItem.get(LynxConstants.PRE_PROCESS_TYPE));                           
                            if(StringUtils.isNotBlank(reviewQuoteBean.getPreProcessType()) && getAgilentConfigurationSecond().getPmProcessTypeCode().contains(reviewQuoteBean.getPreProcessType())){                            	
                            	reviewQuoteBean.setPmOrderFlag(true);
                            }
                            
                            if(quoteRefItem.get(LynxConstants.COMMENTS) == null || StringUtils.isBlank((String) quoteRefItem.get(LynxConstants.COMMENTS))){
                            	vlogDebug("Comments retrieved for quoteid{0} from sap system is null or empty and hence setting empty to it", quoteId);
                            	reviewQuoteBean.setComments((String) quoteRefItem.get(Constants.EMPTY_STRING));
                            } else{
                            	vlogDebug("Comments retrieved for quoteid{0} from sap system is {1}", quoteId, quoteRefItem.get(LynxConstants.COMMENTS));
                                reviewQuoteBean.setComments((String) quoteRefItem.get(LynxConstants.COMMENTS));	
                            }
                            if(quoteRefItem.get(LynxConstants.HEADERNOTES) == null || StringUtils.isBlank((String) quoteRefItem.get(LynxConstants.HEADERNOTES))){
                                vlogDebug("HeaderNotes retrieved for quoteid{0} from sap system is null or empty and hence setting empty to it", quoteId);
                                reviewQuoteBean.setHeaderAdditionalInfo((String) quoteRefItem.get(Constants.EMPTY_STRING));
                                reviewQuoteBean.setResponseType((String) quoteRefItem.get(Constants.EMPTY_STRING));
                            } else{
                                vlogDebug("HeaderNotes retrieved for quoteid{0} from sap system is {1}", quoteId, quoteRefItem.get(LynxConstants.HEADERNOTES));
                                reviewQuoteBean.setHeaderAdditionalInfo((String) quoteRefItem.get(LynxConstants.HEADERNOTES));
                                String additionalNote= quoteRefItem.get(LynxConstants.HEADERNOTES).toString().toLowerCase();
                                String referenceText=getAgilentConfigurationSecond().getReferenceText();
                                if(additionalNote.contains(referenceText)){
                                    reviewQuoteBean.setResponseType(LynxConstants.PRIORTITY);
                                }else{
                                    reviewQuoteBean.setResponseType(LynxConstants.STANDARD);
                                }
                                
                           }
                            if (StringUtils.isNotBlank((String)quoteRefItem.get(LynxConstants.CREATED_FROM_WEB))) {
                            	reviewQuoteBean.setCreatedByWeb((String) quoteRefItem.get(LynxConstants.CREATED_FROM_WEB));
                            	if(reviewQuoteBean.getCreatedByWeb().equalsIgnoreCase(LynxConstants.Y)){
                            		isCreatedByWeb=true;
                            		if(StringUtils.isNotBlank(reviewQuoteBean.getProcessType()) && getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(reviewQuoteBean.getProcessType()) && !reviewQuoteBean.isPmOrderFlag()){
                            			isCreatedByWebRepairQuote=true;
                            		}else if((StringUtils.isNotBlank(reviewQuoteBean.getProcessType()) && reviewQuoteBean.getProcessType().equalsIgnoreCase(LynxConstants.PROCESS_TYPE_PM_QUOTE))
                            				|| StringUtils.isNotBlank(reviewQuoteBean.getPreProcessType()) && reviewQuoteBean.getPreProcessType().equalsIgnoreCase(LynxConstants.PROCESS_TYPE_PM_QUOTE)){
                            			isCreatedByWebPMQuote= true;
                            		}
                            	}
                            }
                            
                            if(!isCreatedByWeb && StringUtils.isNotBlank(reviewQuoteBean.getProcessType()) && getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(reviewQuoteBean.getProcessType()) && !reviewQuoteBean.isPmOrderFlag()){
                            	p2WRepairQuote=true;
                        	}
                            
                            String transactionStatus = (String) quoteRefItem.get(LynxConstants.TRANSACTION_STATUS);
                            if (transactionStatus != null) {
                            	String repairOrderStatus = getRepairOrderStatus(transactionStatus);
                            	if(LynxConstants.ORDER_STATUS_OPEN.equals(repairOrderStatus)) {
                            		reviewQuoteBean.setRepairOrderStatus(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_ORDER_OPEN_STATUS, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                            	} else if (LynxConstants.ORDER_STATUS_CLOSED.equals(repairOrderStatus)) {
                            		reviewQuoteBean.setRepairOrderStatus(getErrorHandler().getFormattedErrorMessage(LynxConstants.QUOTE_REPAIR_ORDER_CLOSED_STATUS, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                            	} else {
                            		reviewQuoteBean.setRepairOrderStatus(LynxConstants.ORDER_STATUS_EMPTY);
                            	}
                            }
                            reviewQuoteBean.setService_plan_active((String) quoteRefItem.get(LynxConstants.SERVICE_PLAN_ACTIVE));
                            if(StringUtils.isNotBlank((String) quoteRefItem.get(LynxConstants.SAP_AUTORENEWAL_INDICATOR)) && 
                                    LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) quoteRefItem.get(LynxConstants.SAP_AUTORENEWAL_INDICATOR))){                                
                                reviewQuoteBean.setAutoRenewFlag(true); 
                                vlogDebug("Auto Renewal Contract:{0} ", reviewQuoteBean.isAutoRenewFlag());
                            }
                            if(StringUtils.isNotBlank((String) quoteRefItem.get(LynxConstants.SAP_PREVIEW_INDICATOR)) && 
                                    LynxConstants.PREVIEW_ONLY_X.equalsIgnoreCase((String) quoteRefItem.get(LynxConstants.SAP_PREVIEW_INDICATOR))){                                
                                reviewQuoteBean.setPreviewOnlyFlag(true); 
                                vlogDebug("Preview only flag:{0} ", reviewQuoteBean.isPreviewOnlyFlag());
                            }
                            if(StringUtils.isNotBlank((String) quoteRefItem.get(LynxConstants.CATEGORY)) && 
                                    LynxConstants.MULTI_YEAR_CONTRACT.equalsIgnoreCase((String) quoteRefItem.get(LynxConstants.CATEGORY))){                                
                                reviewQuoteBean.setMultiYearOrder(true); 
                                vlogDebug("MultiYearOrder Flag:{0} ", reviewQuoteBean.isMultiYearOrder());
                            }
                            
                            if(StringUtils.isNotBlank((String) quoteRefItem.get(LynxConstants.PO_NUMBER))){                                
                                reviewQuoteBean.setPoNumber((String) quoteRefItem.get(LynxConstants.PO_NUMBER)); 
                                vlogDebug("PO Number:{0} ", reviewQuoteBean.getPoNumber());
                            }
                            String singlePaymentType = (String) quoteRefItem.get(LynxConstants.SINGLE_PAY_TYPE);
                            vlogDebug("single Payment type from CRM :{0} ", singlePaymentType );                            
                            if(StringUtils.isNotBlank(singlePaymentType) && singlePaymentType.equalsIgnoreCase(LynxConstants.PREVIEW_ONLY_X)){                                
                                reviewQuoteBean.setSinglePayType(true); 
                                vlogDebug("single Payment type after setting in bean :{0} ", reviewQuoteBean.isSinglePayType());
                            }                          
                            
                            reviewQuoteBean.setPurchaserEmailid((String) quoteRefItem.get(LynxConstants.PURCHASER_EMAILID));
                            reviewQuoteBean.setPurchaserName((String) quoteRefItem.get(LynxConstants.PURCHASER_NAME));
                            vlogDebug("Purchaser EmailId and Name from CRM is :{0} and {1} ", reviewQuoteBean.getPurchaserEmailid(),reviewQuoteBean.getPurchaserName()); 
                            
                            multipleQuoteSets = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.QUOTES_SET)).get(LynxConstants.RESULTS);
                            setQuoteStausDetails(quoteRefItem, reviewQuoteBean, multipleQuoteSets);
                            if (quoteRefItem.containsKey(LynxConstants.QUOTE_ITEMS_SET)) {
                                quoteItems = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.QUOTE_ITEMS_SET)).get(LynxConstants.RESULTS);
                            }
                            exihibitSet = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.EXIHIBIT_SET)).get(LynxConstants.RESULTS);
                            partnerResultsList = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.QUOTE_PARTNER_SET)).get(LynxConstants.RESULTS);
                            quoteSystemSets = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.QUOTE_SYSTEMS_SET)).get(LynxConstants.RESULTS);
                            pricesSet = (List<Map<String, Object>>) ((Map<String, Object>) quoteRefItem.get(LynxConstants.PRICES_SET)).get(LynxConstants.RESULTS);
                            reviewQuoteDetailsList = new ArrayList<ReviewQuoteDetailsInfo>();
                            if(getCurrencyCodeToLocaleMap().containsKey(reviewQuoteBean.getCurrency())){
                                currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(reviewQuoteBean.getCurrency()));
                                vlogDebug("currencyLocale in Fetch Quote {0}", currencyLocale);                                
                            }
                            
                            if (quoteItems != null) {                            	
                                for (Map<String, Object> quoteItem : quoteItems) {
                                    reviewQuoteComponentsList = new ArrayList<ReviewQuoteComponentsInfo>();
                                    quoteItemsInfo = new ReviewQuoteDetailsInfo();
                                    quoteItemName = (String) quoteItem.get(LynxConstants.ITEM_NO);
                                    String ItemInfo=(String) quoteItem.get(LynxConstants.ITEMNOTES);
                                    //ItemInfo ="Item information in quote";
                                    if(StringUtils.isNotBlank(ItemInfo)){
                                    quoteItemsInfo.setItemAdditionalInfo(ItemInfo);
                                    newList.add(ItemInfo);
                                    }
                                    for(Map<String, Object> quoteComponent : quoteSystemSets) {
                                        quoteComponentItemName = (String) quoteComponent.get(LynxConstants.ITEM_NO);
                                        reviewQuoteComponentsInfo = new ReviewQuoteComponentsInfo();

                                        quoteItemsInfo.setModelNumber((String) quoteComponent.get(LynxConstants.QUOTE_COMP_MOD));
                                        quoteItemsInfo.setSerialNumber((String) quoteComponent.get(LynxConstants.QUOTE_COMP_SERIAL));
                                        quoteItemsInfo.setModelDesc((String) quoteComponent.get(LynxConstants.QUOTE_COMP_NAME));
                                        
                                        if (quoteComponentItemName.equalsIgnoreCase(quoteItemName)) {
                                            reviewQuoteComponentsInfo.setComponent((String) quoteComponent.get(LynxConstants.QUOTE_COMP_NAME));
                                            reviewQuoteComponentsInfo.setPart((String) quoteComponent.get(LynxConstants.QUOTE_COMP_MOD));
                                            reviewQuoteComponentsInfo.setSerial((String) quoteComponent.get(LynxConstants.QUOTE_COMP_SERIAL));
                                            String egsDate = (String) quoteComponent.get(LynxConstants.EGS_DATE);
                                            if (StringUtils.isNotBlank(egsDate) && !egsDate.equals(LynxConstants.EGS_DATE_BLANK_DATE)) {
                                                reviewQuoteComponentsInfo.setEgsDate((String) quoteComponent.get(LynxConstants.EGS_DATE));
                                                reviewQuoteBean.setEgsShow(true);
                                                boolean egsStatus = getCrmUtil().calculateEgsDate(((String) quoteComponent.get(LynxConstants.EGS_DATE)));
                                                if (egsStatus) {
                                                    count++;
                                                    reviewQuoteBean.setEgsdateCount(count);
                                                }
                                            }
                                            reviewQuoteComponentsList.add(reviewQuoteComponentsInfo);
                                        }
                                    }
                                    quoteItemsInfo.setInstrumentId((String) quoteItem.get("SystemId"));
                                    quoteItemsInfo.setQuoteComponents(reviewQuoteComponentsList);
                                    quoteItemsInfo.setQuoteSystemId((String) quoteItem.get(LynxConstants.Quote_SYSTEM_ID));
                                    quoteItemsInfo.setQuoteSystemHandle((String) quoteItem.get(LynxConstants.Quote_SYSTEM_HANDLE));
                                    quoteItemsInfo.setQuoteSystemGrossValue((String) quoteItem.get(LynxConstants.TOTALPRICE));
                                    quoteItemsInfo.setWarrantyDate((String) quoteItem.get(LynxConstants.WARRENTY_DATE));
                                    quoteItemsInfo.setWarrantyDateBetweenQuote(getCrmUtil().warrantyDateBetweenQuote(quoteItemsInfo.getWarrantyDate(),
                                            reviewQuoteBean.getSubscriptionStartDate(), reviewQuoteBean.getSubscriptionEndDate()));
                                    quoteItemsInfo.setItemStartDate((String) quoteItem.get(LynxConstants.START_DATE));
                                    quoteItemsInfo.setItemEndDate((String) quoteItem.get(LynxConstants.End_Date));
                                    if (showCoverageDate && !getCrmUtil().compareLineItemCoverageDates(reviewQuoteBean.getSubscriptionStartDate(),
                                            reviewQuoteBean.getSubscriptionEndDate(), quoteItemsInfo.getItemStartDate(), quoteItemsInfo.getItemEndDate())) {
                                        reviewQuoteBean.setShowCoverageDate(true);
                                        showCoverageDate = false;
                                    }
                                    String quantity = (String) quoteItem.get(LynxConstants.QUANTITY);
                                    if (StringUtils.isNotBlank(quantity)) {
                                        double quantityValue = Double.parseDouble(quantity);
                                        quoteItemsInfo.setItemQuantityValue(Math.round(quantityValue));
                                    }
                                    quoteItemsInfo.setItemQuantity(quantity);
                                    quoteItemsInfo.setServicePlan((String) quoteItem.get(LynxConstants.PROD_DESC));
                                    quoteItemsInfo.setOrderedProd((String) quoteItem.get(LynxConstants.ORDERED_PROD));
                                    quoteItemsInfo.setChargeType((String) quoteItem.get(LynxConstants.CHARGE_TYPE));
                                    quoteItemsInfo.setUnitPrice((String) quoteItem.get(LynxConstants.UNIT_PRICE));
                                    if (getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(reviewQuoteBean.getProcessType()) ||
                                    		getAgilentConfigurationSecond().getPmProcessTypeCode().contains(reviewQuoteBean.getProcessType())) {                                    	
                                        if (StringUtils.isNotBlank(quoteItemsInfo.getUnitPrice())) {
                                            Double unitPriceDouble = new Double(quoteItemsInfo.getUnitPrice().trim());
                                            String formattedUnitPrice = formatCurrency(unitPriceDouble, currencyLocale.toString(), reviewQuoteBean.getCurrency());
                                            quoteItemsInfo.setFormattedUnitPrice(formattedUnitPrice);
                                        }
                                        if (StringUtils.isNotBlank(quoteItemsInfo.getQuoteSystemGrossValue())) {
                                            Double quoteSystemTotalPrice = new Double(quoteItemsInfo.getQuoteSystemGrossValue().trim());
                                            String formattedQuoteSystemTotalPrice = formatCurrency(quoteSystemTotalPrice, currencyLocale.toString(), reviewQuoteBean.getCurrency());
                                            quoteItemsInfo.setFormattedQuoteSystemGrossValue(formattedQuoteSystemTotalPrice);
                                        }
                                        
                                        String chargeType = quoteItemsInfo.getChargeType();                                     	
                                        if ((p2WRepairQuote && StringUtils.isNotBlank(chargeType) && chargeType.equalsIgnoreCase(LynxConstants.SERVICE_CHARGE)) || isCreatedByWebRepairQuote ) { 
                                        	vlogDebug("Inside Charge Type Service Charge");
                                        	quoteItemsInfo.setRepairServiceChargeType(chargeType);
                                        	quoteItemsInfo.setServicePlan(getInternationalizationService().getLocalizeMessage(LynxConstants.EXTIMATED_REPAIR_SERVICE, null));
                                        	quoteItemsInfo.setChargeType(getInternationalizationService().getLocalizeMessage(LynxConstants.REPAIR_PARTS_LABOR, null));
                                        	quoteItemsInfo.setOrderedProd(getInternationalizationService().getLocalizeMessage(LynxConstants.ORDERED_TYPE_REPAIR, null));            
                                        	quoteItemsInfo.setUnitPrice("");
                                        	quoteItemsInfo.setItemQuantityValue(0);                                       	
                                        	
                                        }else{                                        	
                                        	serviceChargeFlag=false;
                                        }
                                        if(isCreatedByWebPMQuote){                                        	
                                        	quoteItemsInfo.setUnitPrice("");
                                        	quoteItemsInfo.setItemQuantityValue(0);  
                                        	quoteItemsInfo.setServicePlan(getInternationalizationService().getLocalizeMessage(LynxConstants.PM_ORDER_DESCRIPTION, null));
                                        	quoteItemsInfo.setChargeType(getInternationalizationService().getLocalizeMessage(LynxConstants.PM_CHARGE_TYPE, null));
                                        }
                                   }
                                    quoteItemsInfo.setItemNumber((String) quoteItem.get(LynxConstants.ITEM_NO));
                                    quoteItemsInfo.setPrevMaintenance((String) quoteItem.get(LynxConstants.PREVENTIVE_MAINTENENCE));  
									if (StringUtils.isNotBlank(quoteItemsInfo.getPrevMaintenance())) {									
										quoteItemsInfo.setPMMonthAsNumber(getCrmUtil().convertMonthNameToNumber(quoteItemsInfo.getPrevMaintenance()));
									}
                                    reviewQuoteDetailsList.add(quoteItemsInfo);
                                }
                            }
                            
                            if(newList!=null && !newList.isEmpty()){
                                reviewQuoteBean.setItemAdditionalInfo(newList);
                            
                            }else{
                                reviewQuoteBean.setItemAdditionalInfo(newList);   
                            }
							if (StringUtils.isNotBlank(reviewQuoteBean.getSubscriptionStartDate())) {
								reviewQuoteBean.setPrevMaintMonthsDisplay(getCrmUtil().sortPMMonthsBasedOnStartMonth(
										reviewQuoteBean.getSubscriptionStartDate(), getPrevMainDropdownSkipMonths()));
							}
							boolean populateSoldTo=true;
							boolean populateEquipMent=true;
							boolean populateSalesRepresnt=true;
							boolean populateBill=true;
							boolean populatePayTo=true;
							boolean populatesoldParty=true;
							boolean populateSecondery=true;
							boolean populateRepair=true;
							 agilentLocale = determineUserLocale();
                            for (Map<String, Object> partnerInfo : partnerResultsList) {
                               if ((LynxConstants.SOLD_TO_CONTACT_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populateSoldToContact(reviewQuoteBean, partnerInfo);
                                        populateSoldTo = false;
                                    } else if (populateSoldTo && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateSoldToContact(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                if ((LynxConstants.SOLD_TO_EQUIPMENT_LOCATION).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populateEquipmentLocation(reviewQuoteBean, partnerInfo);
                                        populateEquipMent = false;

                                    } else if (populateEquipMent && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateEquipmentLocation(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                if ((LynxConstants.SOLD_TO_SALES_REP).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populateSalesRep(reviewQuoteBean, partnerInfo);
                                        populateSalesRepresnt = false;

                                    } else if (populateSalesRepresnt && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateSalesRep(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                if ((LynxConstants.BILL_TO).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populateBillTo(reviewQuoteBean, partnerInfo);
                                        populateBill = false;

                                    } else if (populateBill && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateBillTo(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                if ((LynxConstants.PAYER_TO).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populatePayerTo(reviewQuoteBean, partnerInfo);
                                        populatePayTo = false;

                                    } else if (populatePayTo && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populatePayerTo(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                if ((LynxConstants.SOLD_TO_PARTY_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        reviewQuoteBean.setPartnerAccountId((String) partnerInfo.get(LynxConstants.PARTNER_NO));
                                        reviewQuoteBean.setCompanyName((String) partnerInfo.get(LynxConstants.NAME));
                                        populatesoldParty = false;
                                    } else if (populatesoldParty && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        reviewQuoteBean.setPartnerAccountId((String) partnerInfo.get(LynxConstants.PARTNER_NO));
                                        reviewQuoteBean.setCompanyName((String) partnerInfo.get(LynxConstants.NAME));
                                    }
                                }
                                // Added as part of Lynx Phase2 Story - DCCOM-35 - To set Account Id - Start
                                if ((LynxConstants.SECONDARY_CONTACT).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                            
                                        populateSeconderyContact(reviewQuoteBean, partnerInfo);
                                        populateSecondery = false;

                                    } else if (populateSecondery && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateSeconderyContact(reviewQuoteBean, partnerInfo);
                                    }
                                }

                                // DCCOM-5120 - To set Sales Rep Details for Repair Orders - Start
                                if (LynxConstants.SALES_REP_REPAIR_ORDER.equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                                    if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                                        vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                                        populateSalesRepRepairOrder(reviewQuoteBean, partnerInfo);
                                        populateRepair = false;
                                    } else if (populateRepair && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                                        vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                                        populateSalesRepRepairOrder(reviewQuoteBean, partnerInfo);
                                    }
                                }
                                // DCCOM-5120 - To set Sales Rep Details for Repair Orders - End

                            }
                            for (Map<String, Object> exhibitInfo : exihibitSet) {
                                exihibitBean = new ExihibitBean();
                                exihibitBean.setExihibitName((String) exhibitInfo.get(LynxConstants.EXIHIBIT_NAME));
                                exihibitBean.setExihibitLink((String) exhibitInfo.get(LynxConstants.EXIHIBIT_LINK));
                                exihibitBean.setExihibitPassword((String) exhibitInfo.get(LynxConstants.EXIHIBIT_PASSWORD));
                                exihibitList.add(exihibitBean);
                            }
                            Map<String, Double> snoPriceMap = new HashMap<String, Double> ();
                            Map<String,String> newPriceMap= new LinkedHashMap<String,String>();
                            String priceCondType=null;
                            String fromattedDiscountAmtFromCRM=null;
                            Double totalAmountBeforeDiscount = 0.0;
                            Double finalTotalAmount =0.0;
                            Double taxAmount=0.0;
                            Double onlineDiscountAmount=0.0;
                            
                            for (Map<String, Object> priceItem : pricesSet) {
                                priceDesc = (String) priceItem.get(LynxConstants.DESCRIPTION);
                                priceCondType=(String) priceItem.get(LynxConstants.PRIC_COND);                                
                                String localisedPriceDesc="";
                                totalAmount = (String) priceItem.get(LynxConstants.TOTAL_AMOUNT);   
                                if(StringUtils.isNotBlank(priceCondType) && priceCondType.equalsIgnoreCase(LynxConstants.DISCOUNT_PRICE_COND)&& StringUtils.isNotBlank(totalAmount)){
                                	Double onlinediscountAmtFromCRM = new Double(totalAmount.trim()); 
                                	if(onlinediscountAmtFromCRM < 0){
                                		onlinediscountAmtFromCRM=Math.abs(onlinediscountAmtFromCRM.doubleValue());
                                	}
                                	fromattedDiscountAmtFromCRM = formatCurrency(onlinediscountAmtFromCRM, currencyLocale.toString(), reviewQuoteBean.getCurrency());
                                	reviewQuoteBean.setDiscountAmountFromCRM(fromattedDiscountAmtFromCRM);                                	
                                }
                                if (StringUtils.isNotBlank((String) priceItem.get(LynxConstants.SNO))
                                        && LynxConstants.SNO_VALUE.equalsIgnoreCase((String) priceItem.get(LynxConstants.SNO))) {
                                    reviewQuoteBean.setTotalAmount(totalAmount);
                                    reviewQuoteBean.addToExtraParams(LynxConstants.TOTAL, priceDesc);
                                }
                               
                               
                                	if (StringUtils.isNotBlank((String) priceItem.get(LynxConstants.SNO))
                                            && LynxConstants.SNO_VALUE_PROMO_DISCOUNT.equalsIgnoreCase((String) priceItem.get(LynxConstants.SNO))
                                		&& (StringUtils.isNotBlank(priceCondType) && priceCondType.equalsIgnoreCase(LynxConstants.DISCOUNT_PRICE_COND)&& StringUtils.isNotBlank(totalAmount))){
                                		onlineDiscountAmount=Double.parseDouble(totalAmount.trim());
                                		reviewQuoteBean.setDisplayPDFListPrice(true);
                                		if(onlineDiscountAmount < 0){
                                			onlineDiscountAmount=Math.abs(onlineDiscountAmount.doubleValue());
                                    	}
                                	}else{
                                		newPriceMap.put(priceDesc, totalAmount);
                                		 if (StringUtils.isNotBlank((String) priceItem.get(LynxConstants.SNO))
                                                && LynxConstants.PRICE_BEFORE_TAX_SNO.equalsIgnoreCase((String) priceItem.get(LynxConstants.SNO))&& newPriceMap.containsKey(priceItem.get(LynxConstants.DESCRIPTION))) {
                                			totalAmountBeforeDiscount=Double.parseDouble(totalAmount.trim())+onlineDiscountAmount;
                                			newPriceMap.put(priceDesc, totalAmountBeforeDiscount.toString());
                                		}else if (StringUtils.isNotBlank((String) priceItem.get(LynxConstants.SNO))
                                                && LynxConstants.SNO_VALUE.equalsIgnoreCase((String) priceItem.get(LynxConstants.SNO))&& newPriceMap.containsKey(priceItem.get(LynxConstants.DESCRIPTION))) {
                                			finalTotalAmount=Double.parseDouble(totalAmount.trim())+onlineDiscountAmount;
                                			newPriceMap.put(priceDesc, finalTotalAmount.toString());
                                		}
                                		
                                	}
                                
                                priceMap = new HashMap<String, String>();
                                priceMap.put(priceDesc, totalAmount);
                                listPriceMap.add(priceMap);                               
                                formattedPriceMap = new HashMap<String, String>();
                                Double totalAmoutDouble = new Double(totalAmount.trim());        
                                String currency=LynxConstants.OPEN_BRACKET + reviewQuoteBean.getCurrency() + LynxConstants.CLOSE_BRACKET;
                                formattedtotalAmount = formatCurrency(totalAmoutDouble, currencyLocale.toString(), reviewQuoteBean.getCurrency());
                                 if (StringUtils.isNotBlank(totalAmount) && getAgilentConfigurationSecond().getRepairProcessTypeCode().contains(reviewQuoteBean.getProcessType()) && !reviewQuoteBean.isPmOrderFlag()) {                                  
                                    String priceItemSnoValue=(String)priceItem.get(LynxConstants.SNO);  
                                    if (StringUtils.isNotBlank((String) priceItem.get(LynxConstants.SNO))){
                                    	if(LynxConstants.PRICE_BEFORE_TAX_SNO.equalsIgnoreCase(priceItemSnoValue)){
                                    		localisedPriceDesc=getInternationalizationService().getLocalizeMessage(LynxConstants.ESTIMATED_TOTAL_BEFORE_TAX, null);                                    	
                                    		vlogDebug("Fetch all quote details - inside before tax localisedPriceDesc :: {0}", localisedPriceDesc);
                                    		if(StringUtils.isNotBlank(localisedPriceDesc)){                                    		
                                    			priceDesc=localisedPriceDesc + LynxConstants.WHITE_SPACE + currency ;   
                                    		}
                                    	}else if(LynxConstants.SNO_VALUE.equalsIgnoreCase(priceItemSnoValue)){                                    		
                                    		localisedPriceDesc=getInternationalizationService().getLocalizeMessage(LynxConstants.ESTIMATED_TOTAL_PRICE, null);                                    	
                                    		vlogDebug("Fetch all quote details - inside After tax localisedPriceDesc :: {0}", localisedPriceDesc);
                                    		if(StringUtils.isNotBlank(localisedPriceDesc)){                                    		
                                    			priceDesc=localisedPriceDesc + LynxConstants.WHITE_SPACE + currency ;   
                                    		}   
                                    	}                                    	
                                    }
                                 }

                                formattedPriceMap.put(priceDesc, formattedtotalAmount);    
                                formattedListPriceMap.add(formattedPriceMap);
								snoPriceMap.put((String) priceItem.get(LynxConstants.SNO), totalAmoutDouble);
                            }
                            vlogDebug("snoPriceMap :: {0}", snoPriceMap);
                            if(snoPriceMap.containsKey(LynxConstants.SNO_BEFORE_DISCOUNT)){
                            	reviewQuoteBean.setGrossAmount(snoPriceMap.get(LynxConstants.SNO_BEFORE_DISCOUNT));
                            } else if (snoPriceMap.containsKey(LynxConstants.PRICE_BEFORE_TAX_SNO)) {
                            	reviewQuoteBean.setGrossAmount(snoPriceMap.get(LynxConstants.PRICE_BEFORE_TAX_SNO));
                            }
                            vlogDebug("reviewQuoteBean.grossAmount :: {0}", reviewQuoteBean.getGrossAmount());
                            reviewQuoteBean.setPriceListMap(listPriceMap);
                            reviewQuoteBean.getPdfListPrice().putAll(newPriceMap);
                            reviewQuoteBean.setFormattedPriceListMap(formattedListPriceMap);                            
                            quoteItemsList = new ArrayList<RenewalQuoteRefBean>();
                            if (multipleQuoteSets != null && multipleQuoteSets.size() > 1) {
                                for (Map<String, Object> quoteItem : multipleQuoteSets) {
                                    renewalQuoteRefBean = new RenewalQuoteRefBean();
                                    renewalQuoteRefBean.setQuoteId((String) quoteItem.get(LynxConstants.OBJECT_ID));
                                    String encContractId = encyptTransaction((String) quoteItem.get(LynxConstants.OBJECT_ID));
                                    renewalQuoteRefBean.setEncryptQuoteId(encContractId);
                                    renewalQuoteRefBean.setQuoteCreationDate((String) quoteItem.get(LynxConstants.QUOTCREATEDATE));
                                    renewalQuoteRefBean.setQuoteCurrency((String) quoteItem.get(LynxConstants.CURRENCY));
                                    renewalQuoteRefBean.setQuoteTotalPrice((String) quoteItem.get(LynxConstants.QUOTNETVALUE));
                                    quoteItemsList.add(renewalQuoteRefBean);
                                }
                            } else if (multipleQuoteSets != null && !multipleQuoteSets.isEmpty() && multipleQuoteSets.size() > 0) {
                                reviewQuoteBean.setQuoteId((String) multipleQuoteSets.get(0).get(LynxConstants.OBJECT_ID));
                                String encContractId = encyptTransaction(reviewQuoteBean.getQuoteId());
                                reviewQuoteBean.setEncryptQuoteId(encContractId);
                            }
                            reviewQuoteBean.setQuoteList(quoteItemsList);
                            reviewQuoteBean.setQuoteItems(reviewQuoteDetailsList);
                            reviewQuoteBean.setExihibitBean(exihibitList);    
                            reviewQuoteBean.setServiceChargeOnly(serviceChargeFlag);
                            quotesList.add(reviewQuoteBean);
                        }
                    }
                } else {
                    vlogInfo("No data found from transaction Id {0}", quoteId);
                    reviewQuoteBean = new ReviewQuotesBean();
                    reviewQuoteBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    quotesList.add(reviewQuoteBean);
                }
                return quotesList;
            }
        } catch (ClientProtocolException e) {
            vlogError(e, "Error in calling the quote detail call");
            reviewQuoteBean = new ReviewQuotesBean();
            reviewQuoteBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_SERVICE_ISSUE, new Object[] {}, 
                    LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
            quotesList.add(reviewQuoteBean);
        } catch (IOException e) {
            vlogError(e, "IOException data");
        }

        return null;
    }

    /**
     * @return
     */
    private String determineUserLocale() {
        String agilentLocale=null;
        agilentLocale = (ServletUtil.getCurrentRequest().getCookieParameter(LynxConstants.AGILENT_LOCALE)) != null
                ? ServletUtil.getCurrentRequest().getCookieParameter(LynxConstants.AGILENT_LOCALE) : "en_US";
        vlogInfo("Agilent Locale cookie value {0}", agilentLocale);
        return agilentLocale;
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateSalesRepRepairOrder(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        reviewQuoteBean.setSalesRepName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setSalesRepPhone(getCrmUtil().trim((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE)));
        reviewQuoteBean.setSalesRepEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateSeconderyContact(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        ContactDetailsBean secContactBean=null;
        List<ContactDetailsBean> contractContactsList=null;
        List<ContactDetailsBean> quoteContactsList=null;
        vlogInfo("Partner FCT data from Response {0}", (String) partnerInfo.get(LynxConstants.PARTNER_FCT));
        secContactBean = new ContactDetailsBean();
        secContactBean.setContactName((String) partnerInfo.get(LynxConstants.NAME));
        secContactBean.setContactEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
        secContactBean.setContactPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
        secContactBean.setContactId((String) partnerInfo.get(LynxConstants.PARTNER_NO));
        secContactBean.setContactRegion((String) partnerInfo.get(LynxConstants.REGION));
        secContactBean.setContactCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
        secContactBean.setContactType(LynxConstants.LYNX_CONTACTTYPE_SECONDARY);
        if (StringUtils.isNotBlank(reviewQuoteBean.getContractId())) {
            if (reviewQuoteBean.getContractContactsList() != null && !reviewQuoteBean.getContractContactsList().isEmpty()) {
                contractContactsList = reviewQuoteBean.getContractContactsList();
                contractContactsList.add(secContactBean);
                reviewQuoteBean.setContractContactsList(contractContactsList);
            }
        } else if (StringUtils.isNotBlank(reviewQuoteBean.getQuoteId())) {
            if (reviewQuoteBean.getQuoteContactsList() != null && !reviewQuoteBean.getQuoteContactsList().isEmpty()) {
                quoteContactsList = reviewQuoteBean.getQuoteContactsList();
                quoteContactsList.add(secContactBean);
                reviewQuoteBean.setQuoteContactsList(quoteContactsList);
            }
        }
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populatePayerTo(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        reviewQuoteBean.setPayerName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setPayerStreet((String) partnerInfo.get(LynxConstants.STREET));
        reviewQuoteBean.setPayerCity((String) partnerInfo.get(LynxConstants.CITY));
        reviewQuoteBean.setPayerRegion((String) partnerInfo.get(LynxConstants.REGION));
        reviewQuoteBean.setPayerPostCode((String) partnerInfo.get(LynxConstants.POSTAL_CODE));
        reviewQuoteBean.setPayerCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateBillTo(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        reviewQuoteBean.setBillToName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setBillToStreet((String) partnerInfo.get(LynxConstants.STREET));
        reviewQuoteBean.setBillToCity((String) partnerInfo.get(LynxConstants.CITY));
        reviewQuoteBean.setBillToRegion((String) partnerInfo.get(LynxConstants.REGION));
        reviewQuoteBean.setBillToPostCode((String) partnerInfo.get(LynxConstants.POSTAL_CODE));
        reviewQuoteBean.setBillToCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateSalesRep(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        reviewQuoteBean.setSalesName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setSalesPhone(getCrmUtil().trim((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE)));
        reviewQuoteBean.setSalesEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateEquipmentLocation(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        reviewQuoteBean.setEquipName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setEquipStreet((String) partnerInfo.get(LynxConstants.STREET));
        reviewQuoteBean.setEquipCity((String) partnerInfo.get(LynxConstants.CITY));
        reviewQuoteBean.setEquipRegion((String) partnerInfo.get(LynxConstants.REGION));
        reviewQuoteBean.setEquipPostCode((String) partnerInfo.get(LynxConstants.POSTAL_CODE));
        reviewQuoteBean.setEquipCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
    }

    /**
     * @param reviewQuoteBean
     * @param partnerInfo
     */
    private void populateSoldToContact(ReviewQuotesBean reviewQuoteBean, Map<String, Object> partnerInfo) {
        ContactDetailsBean primaryContactBean=null;
        List<ContactDetailsBean> contractContactsList=null;
        List<ContactDetailsBean> quoteContactsList=null;
        reviewQuoteBean.setContactName((String) partnerInfo.get(LynxConstants.NAME));
        reviewQuoteBean.setContactEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
        String phoneNumber = (String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE);
                           
        reviewQuoteBean.setContactPhone(phoneNumber);
        reviewQuoteBean.setContactRegion((String) partnerInfo.get(LynxConstants.REGION));
        reviewQuoteBean.setContactCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
        reviewQuoteBean.setPrimaryContactId(AgilentUtil.removeLeadingZeros((String) partnerInfo.get(LynxConstants.PARTNER_NO)));
        
        primaryContactBean = new ContactDetailsBean();
        primaryContactBean.setContactId(AgilentUtil.removeLeadingZeros((String) partnerInfo.get(LynxConstants.PARTNER_NO)));
        primaryContactBean.setContactName((String) partnerInfo.get(LynxConstants.NAME));
        primaryContactBean.setContactEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
        primaryContactBean.setContactPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
        primaryContactBean.setContactRegion((String) partnerInfo.get(LynxConstants.REGION));
        primaryContactBean.setContactCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
        primaryContactBean.setContactType(LynxConstants.LYNX_CONTACTTYPE_PRIMARY);
        if (StringUtils.isNotBlank(reviewQuoteBean.getContractId())) {
            contractContactsList = new ArrayList<ContactDetailsBean>();
            contractContactsList.add(primaryContactBean);
            reviewQuoteBean.setContractContactsList(contractContactsList);
        } else if (StringUtils.isNotBlank(reviewQuoteBean.getQuoteId())) {
            quoteContactsList = new ArrayList<ContactDetailsBean>();
            quoteContactsList.add(primaryContactBean);
            reviewQuoteBean.setQuoteContactsList(quoteContactsList);
        }
    }

    private void setQuoteStausDetails(Map<String, Object> contractInfo, ReviewQuotesBean reviewQuoteBean, List<Map<String, Object>> multipleQuoteSets) {
        int daysLeft = getCrmUtil().calculateDaysLeft(reviewQuoteBean.getSubscriptionEndDate());
        if (daysLeft == 0) {
            reviewQuoteBean.setExpiringDays(1);
        } else {
            reviewQuoteBean.setExpiringDays(daysLeft + 1);
        }
        if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.EXPD_CONT_ID))
                && !LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            reviewQuoteBean.setExpContId((String) contractInfo.get(LynxConstants.EXPD_CONT_ID));
            if (Math.abs(daysLeft) > getExpiredContractRenewalDays()) {
                reviewQuoteBean.setDisplayFlag(true);
            }
            
        }
        if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.RENEW_CONT_ID))
                && !LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            reviewQuoteBean.setRenewContId((String) contractInfo.get(LynxConstants.RENEW_CONT_ID));
            reviewQuoteBean.setStatusMessage(LynxConstants.RENEWED);
            if (Math.abs(daysLeft) > getExpiredContractRenewalDays()) {
                reviewQuoteBean.setDisplayFlag(true);
            }
        }

        if (StringUtils.isEmpty((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
            if (StringUtils.isEmpty((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
                int futureDate = getCrmUtil().calculateDaysLeft(reviewQuoteBean.getSubscriptionStartDate());
                if (futureDate > 0) {
                    reviewQuoteBean.setStatusMessage(LynxConstants.FUTURE_CONTRACT);
                }
                if (daysLeft <= 120 && daysLeft > 0) {
                    reviewQuoteBean.setExpiringInFlag(true);
                }
                if (daysLeft < 0) {
                    reviewQuoteBean.setExpiringContractFlag(true);
                }
            } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
                    && LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {

                if (daysLeft < 0)
                    reviewQuoteBean.setExpiringContractFlag(true);
                    reviewQuoteBean.setStatusMessage(LynxConstants.PENDING);
            }
        } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))
                && StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            if (LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
                    && LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
                if (daysLeft < 0) {
                    reviewQuoteBean.setExpiringContractFlag(true);
                }
                reviewQuoteBean.setStatusMessage(LynxConstants.PENDING);
            }
            if (LynxConstants.CONTRACT_RENEWED_R.equalsIgnoreCase((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))
                    && LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))) {
                if (daysLeft < 0)
                    reviewQuoteBean.setExpiringContractFlag(true);
                    reviewQuoteBean.setRenewStatus(true);
                    reviewQuoteBean.setStatusMessage(LynxConstants.RENEWED);
            }
        } else if (StringUtils.isNotBlank((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))
                && StringUtils.isEmpty((String) contractInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            if (LynxConstants.ASPECT_QUOTE_X.equalsIgnoreCase((String) contractInfo.get(LynxConstants.ASPEN_QUOTE_CREATED))
                    && (multipleQuoteSets != null && !multipleQuoteSets.isEmpty() && multipleQuoteSets.size() != 0)) {
                if (!reviewQuoteBean.isDisplayFlag()) {
                    if (daysLeft <= 120 && daysLeft >= 0) {
                        reviewQuoteBean.setReviewQuoteAndexpMessg(true);
                        reviewQuoteBean.setExpiringInFlag(true);
                    } else if (daysLeft < 0) {
                        reviewQuoteBean.setExpiringContractFlag(true);
                        if (Math.abs(daysLeft) <= getExpiredContractRenewalDays()) {
                            reviewQuoteBean.setReviewQuoteAndexpMessg(true);
                            reviewQuoteBean.setRenewQuoteAfterExpiry(true);
                        }
                    }
                }
            } else {
                if (daysLeft <= 120 && daysLeft > 0) {
                    reviewQuoteBean.setExpiringInFlag(true);
                }

            }
        }

    }

    /**
     * Returns an List of New Aspen Quotes associated with the Sap Contact Id passed as method Argument
     * 
     * @param sapContactID
     * @return List of NewAspenQuoteBean
     */
    public List<NewAspenQuoteBean> fetchNewAspenQuoteDetails(String sapContactID) {
        NewAspenQuoteBean aspenQuoteBean = null;
        List<NewAspenQuoteBean> newQuoteDetailsList = null;
        Map<String, Object> newQuoteDetails = null;
        List<Map<String, Object>> quoteResultsList = null;
        RestClient client = getRestClient();
        newQuoteDetailsList = new ArrayList<NewAspenQuoteBean>();
        try {
            newQuoteDetails = getSapcrmapiManager().getNewAspenQuoteDetails(client, sapContactID);
            if (newQuoteDetails != null && newQuoteDetails.containsKey(LynxConstants.ERROR_CODE_TXT)
                    && newQuoteDetails.get(LynxConstants.ERROR_CODE_TXT).equals(LynxConstants.ERROR_CODE)) {
                aspenQuoteBean = new NewAspenQuoteBean();
                aspenQuoteBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NETWORK, new Object[] {}, 
                        LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                newQuoteDetailsList.add(aspenQuoteBean);
            } else {
                long startTime = System.currentTimeMillis();
                vlogDebug("Fetch all quote details - Start time :: {0}", startTime);
                quoteResultsList = (List<Map<String, Object>>) newQuoteDetails.get(LynxConstants.RESULTS);
                if (quoteResultsList != null && !quoteResultsList.isEmpty()) {
                    Map<String, NewAspenQuoteBean> latestAdjustedQuotes = new HashMap <String, NewAspenQuoteBean> ();
                    Map<String, NewAspenQuoteBean> nonAdjustedQuotes = new HashMap <String, NewAspenQuoteBean> ();
                    for (Map<String, Object> newQuoteInfo : quoteResultsList) {
                        aspenQuoteBean = new NewAspenQuoteBean();
                        setNewQuoteInfo(newQuoteInfo, aspenQuoteBean, quoteResultsList);
                        populateQuoteList(aspenQuoteBean,latestAdjustedQuotes,nonAdjustedQuotes);
                    }
                    vlogDebug("latestAdjustedQuotes map size {0}", latestAdjustedQuotes.size());
                    vlogDebug("nonAdjustedQuotes map size {0}", nonAdjustedQuotes.size());
                    nonAdjustedQuotes.keySet().removeAll(latestAdjustedQuotes.keySet());
                    vlogDebug("After removing all add-on original quotes : nonAdjustedQuotes map size {0}", nonAdjustedQuotes.size());
                    
                    newQuoteDetailsList.addAll(latestAdjustedQuotes.values());
                    newQuoteDetailsList.addAll(nonAdjustedQuotes.values());
                } else {
                    vlogInfo("No data found from transaction Id {0}", sapContactID);
                    aspenQuoteBean = new NewAspenQuoteBean();
                    aspenQuoteBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, 
                            LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
                    newQuoteDetailsList.add(aspenQuoteBean);
                }
                long endTime = System.currentTimeMillis();
                vlogDebug("Fetch all quote details - End time :: {0}", endTime);
                vlogDebug("Fetch all quote details - total time taken (milliseconds) :: {0}", (endTime - startTime));
            }
            return newQuoteDetailsList;
        } catch (ClientProtocolException clientProtocolException) {
            vlogError(clientProtocolException, "ClientProtocolException while calling  New Aspen Quote Service");
        } catch (IOException ioException) {
            vlogError(ioException, "IOException while calling  New Aspen Quote Service");
        }
        return null;
    }

    private void populateQuoteList(NewAspenQuoteBean aspenQuoteBean, Map<String, NewAspenQuoteBean> latestAdjustedQuotes, 
            Map<String, NewAspenQuoteBean> nonAdjustedQuotes) {
        /*If it is an adjusted quote or add-on quote*/
        if (StringUtils.isNotBlank(aspenQuoteBean.getOriginalQuoteId())) {
            NewAspenQuoteBean prevAdjQuote = latestAdjustedQuotes.get(aspenQuoteBean.getOriginalQuoteId());
            if (prevAdjQuote == null && aspenQuoteBean.getCreatedOnDate()!=null) {
                latestAdjustedQuotes.put(aspenQuoteBean.getOriginalQuoteId(), aspenQuoteBean);
                vlogDebug("Adding {0} as latest adjusted/add-on quote id for original quote {1}",aspenQuoteBean.getQuoteId(), aspenQuoteBean.getOriginalQuoteId());
            } else if(prevAdjQuote != null){
                Date prevAdjQuoteCreateDate = prevAdjQuote.getCreatedOnDate();
                Date currentAdjQuoteCreateDate = aspenQuoteBean.getCreatedOnDate();
                if (prevAdjQuoteCreateDate != null && currentAdjQuoteCreateDate!=null && currentAdjQuoteCreateDate.after(prevAdjQuoteCreateDate)) {
                    latestAdjustedQuotes.put(aspenQuoteBean.getOriginalQuoteId(), aspenQuoteBean);
                    vlogDebug("Adding {0} as latest adjusted/add-on quote id for original quote {1}",aspenQuoteBean.getQuoteId(), aspenQuoteBean.getOriginalQuoteId());
                }
            }
        }
        else if (StringUtils.isBlank(aspenQuoteBean.getAdjustedQuoteId())) {
            /*Not an adjusted quote or add-on quote*/
            nonAdjustedQuotes.put(aspenQuoteBean.getQuoteId(), aspenQuoteBean);
            vlogDebug("Adding {0} quote in nonAdjustedQuotes list",aspenQuoteBean.getQuoteId());
        }
    }

    private void setNewQuoteInfo(Map<String, Object> newQuoteInfo, NewAspenQuoteBean aspenQuoteBean, List<Map<String, Object>> quoteResultsList) {
        aspenQuoteBean.setQuoteId((String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
        String encQuoteId = encyptTransaction((String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
        aspenQuoteBean.setEncQuoteId(encQuoteId);
        aspenQuoteBean.setQuoteValidFrom((String) newQuoteInfo.get(LynxConstants.QUOTE_VALID_FROM));
        aspenQuoteBean.setQuoteValidTo((String) newQuoteInfo.get(LynxConstants.QUOTE_VALID_TO));
        aspenQuoteBean.setProcessTypeContract((String) newQuoteInfo.get(LynxConstants.PROCESS_TYPE_CONTRACT));
        aspenQuoteBean.setQuoteCreationDate((String) newQuoteInfo.get(LynxConstants.CREATION_DATE));
        String warrantyQuote=(String)newQuoteInfo.get(LynxConstants.WARRANTY_QUOTE);
		if (StringUtils.isNotBlank(warrantyQuote) && warrantyQuote.equalsIgnoreCase(LynxConstants.Y)) {
			aspenQuoteBean.setWarrantyQuote(true);
		} else {
			aspenQuoteBean.setWarrantyQuote(false);
		}
		if (StringUtils.isNotBlank((String)newQuoteInfo.get(LynxConstants.CREATED_FROM_WEB))) {      		
      		 aspenQuoteBean.setCreatedByWeb((String) newQuoteInfo.get(LynxConstants.CREATED_FROM_WEB));
		 }	
      	String originalQuote= (String)newQuoteInfo.get(LynxConstants.ORIGINAL_QUOTE);
      	String adjustedQuote= (String)newQuoteInfo.get(LynxConstants.ADJUSTED_QUOTE);
      	String createdOn= (String)newQuoteInfo.get(LynxConstants.CREATED_ON);
      	if ("X".equals((String) newQuoteInfo.get(LynxConstants.ADD_ON_QUOTE))) {
      	    aspenQuoteBean.setAddOnQuote(true);
        } else{
            aspenQuoteBean.setAddOnQuote(false);
        }
      	if (StringUtils.isNotBlank(originalQuote)) {  
      	    vlogDebug("Setting OriginalQuoteId: {0} for quoteId: {1}", originalQuote, (String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
            aspenQuoteBean.setOriginalQuoteId(originalQuote);
            aspenQuoteBean.setEncryptedOriginalQuoteId(encyptTransaction(originalQuote));
        }  
      	if (StringUtils.isNotBlank(adjustedQuote)) {   
      	    vlogDebug("Setting AdjustedQuoteId: {0} for quoteId: {1}", adjustedQuote, (String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
            aspenQuoteBean.setAdjustedQuoteId(adjustedQuote);
            aspenQuoteBean.setEncryptedAdjustedQuoteId(encyptTransaction(adjustedQuote));
        } 
      	if (StringUtils.isNotBlank(createdOn)) {   
            vlogDebug("Trying to set createdOn: {0} for quoteId: {1}", createdOn, (String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(getAdjustedQuoteDateFormat());
                Date quoteCreationDate = sdf.parse(createdOn);
                aspenQuoteBean.setCreatedOnDate(quoteCreationDate);
                vlogDebug("Setting CreatedOnDate: {0} for quoteId: {1}", quoteCreationDate, (String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
            } catch (ParseException e) {
                vlogError("CreatedOn Date parsing error for quoteId {0}", (String) newQuoteInfo.get(LynxConstants.QUOTE_ID));
            }
        } 
        Map<String, Object> partnerSetResult = (Map<String, Object>) newQuoteInfo.get(LynxConstants.QUOTE_PARTNER_SET);
        List<Map<String, Object>> partnerResultsList = (List<Map<String, Object>>) partnerSetResult.get(LynxConstants.RESULTS);
        setNewAspenQuoteContactDetails(partnerResultsList, aspenQuoteBean);
        int daysLeft = getCrmUtil().calculateDaysLeft(aspenQuoteBean.getQuoteValidTo());
        if (daysLeft == 0) {
            aspenQuoteBean.setExpiringDays(1);
        } else {
            aspenQuoteBean.setExpiringDays(daysLeft + 1);
        }
        if (StringUtils.isNotBlank((String) newQuoteInfo.get(LynxConstants.CONTRACT_RENEWED))
                && LynxConstants.CONTRACT_RENEWED_P.equalsIgnoreCase((String) newQuoteInfo.get(LynxConstants.CONTRACT_RENEWED))) {
            aspenQuoteBean.setStatusMessage(LynxConstants.PENDING);
        }
    }

    private void setNewAspenQuoteContactDetails(List<Map<String, Object>> partnerResultsList, NewAspenQuoteBean aspenQuoteBean) {
        String agilentLocale=determineUserLocale();
        boolean soldToContact=true;
        boolean soldToSalesRep=true;
        boolean soldToParty=true;
        for (Map<String, Object> partnerInfo : partnerResultsList) {
            if ((LynxConstants.SOLD_TO_CONTACT_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                    vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                    setPartnerSoldToContact(aspenQuoteBean, partnerInfo);
                    soldToContact = false;

                } else if (soldToContact && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                    vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                    setPartnerSoldToContact(aspenQuoteBean, partnerInfo);
                }
            }
            if ((LynxConstants.SOLD_TO_SALES_REP).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                    vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                    setPartnerSalesRep(aspenQuoteBean, partnerInfo);
                    soldToSalesRep = false;

                } else if (soldToSalesRep && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                    vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                    setPartnerSalesRep(aspenQuoteBean, partnerInfo);
                }
            }
            if ((LynxConstants.SOLD_TO_PARTY_VALUE).equalsIgnoreCase((String) partnerInfo.get(LynxConstants.PARTNER_FCT))) {
                if (getInternationalLocaleList().contains(agilentLocale) && checkNationFlag(partnerInfo, LynxConstants.INTERNATIONAL_CODE)) {
                    vlogDebug("English selected ,Using Partner Info map with international language {0}", partnerInfo);
                    setNewQuotePartnerInfo(aspenQuoteBean, partnerInfo);
                    soldToParty = false;

                } else if (soldToParty && checkNationFlag(partnerInfo, LynxConstants.LOCAL_CODE)) {
                    vlogDebug("Local language selected,Partner Info map with Local language {0}", partnerInfo);
                    setNewQuotePartnerInfo(aspenQuoteBean, partnerInfo);
                }
            }
        }
    }

    /**
     * @param aspenQuoteBean
     * @param partnerInfo
     */
    private void setPartnerSalesRep(NewAspenQuoteBean aspenQuoteBean, Map<String, Object> partnerInfo) {
        aspenQuoteBean.setSalesName((String) partnerInfo.get(LynxConstants.NAME));
        aspenQuoteBean.setSalesPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
        aspenQuoteBean.setSalesEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
    }

    /**
     * @param aspenQuoteBean
     * @param partnerInfo
     */
    private void setPartnerSoldToContact(NewAspenQuoteBean aspenQuoteBean, Map<String, Object> partnerInfo) {
        aspenQuoteBean.setContactName((String) partnerInfo.get(LynxConstants.NAME));
        aspenQuoteBean.setContactEmail((String) partnerInfo.get(LynxConstants.SERVICE_EMAIL_ID));
        aspenQuoteBean.setContactPhone((String) partnerInfo.get(LynxConstants.SERVICE_TEL_PHONE));
        aspenQuoteBean.setContactRegion((String) partnerInfo.get(LynxConstants.REGION));
        aspenQuoteBean.setContactCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
    }

    private void setNewQuotePartnerInfo(NewAspenQuoteBean aspenQuoteBean, Map<String, Object> partnerInfo) {
        aspenQuoteBean.getAddress().setAddress1((String) partnerInfo.get(LynxConstants.HOUSE_NO));
        aspenQuoteBean.getAddress().setAddress2((String) partnerInfo.get(LynxConstants.STREET));
        aspenQuoteBean.getAddress().setAddress3((String) partnerInfo.get(LynxConstants.REGION));
        aspenQuoteBean.getAddress().setCity((String) partnerInfo.get(LynxConstants.CITY));
        aspenQuoteBean.getAddress().setPostalCode((String) partnerInfo.get(LynxConstants.POSTAL_CODE));
        aspenQuoteBean.getAddress().setCountry((String) partnerInfo.get(LynxConstants.COUNTRY));
        aspenQuoteBean.getAddress().setPhoneNumber((String) partnerInfo.get(LynxConstants.PHONE));
        aspenQuoteBean.setName((String) partnerInfo.get(LynxConstants.NAME));
    }
    
    /**
     * DCCOM-4945-Display on-demand order on landing page
     * 
     * Returns the Order Status based on the List of Status Codes
     * 
     * @param Repair Order Status
     * @return String 
     */ 
    
    private String getRepairOrderStatus(String pRepairOrderStatus) {
        String repairOrderStatus = "";
        if (!StringUtils.isEmpty(pRepairOrderStatus)) {
            if (getRepairOrderOpenStatusList().contains(pRepairOrderStatus)) {
                repairOrderStatus = LynxConstants.ORDER_STATUS_OPEN;
            } else if (getRepairOrderClosedStatusList().contains(pRepairOrderStatus)) {
                repairOrderStatus = LynxConstants.ORDER_STATUS_CLOSED;
            }
        }
        return repairOrderStatus;
    }
    
    private boolean checkNationFlag(Map<String, Object> pPartnerInfo, String pNationCode) {
        boolean pNationFlag = false;
        if (pPartnerInfo.containsKey(LynxConstants.NATION) && pNationCode.equalsIgnoreCase((String) pPartnerInfo.get(LynxConstants.NATION))) {
            pNationFlag = true;
        }
        return pNationFlag;

    }
    
	private String formatCurrency(Object pCurrency, String localeString, String currencyCode) {
		if (StringUtils.isNotBlank(currencyCode) && currencyCode.equalsIgnoreCase(LynxConstants.MEXICO_CURRENCY_CODE)) {
			currencyCode = "";
		}
		return AgilentCurrencyTagConverter.formatCurrency(pCurrency, localeString, currencyCode);
	}
    
    public List<ActiveContractBean> filterActiveContractsForWarrantyQuote(List<ActiveContractBean> contractHistoryList, String pWarrantyQuoteStartDate) {
        List<ActiveContractBean> activeContractList = new ArrayList<ActiveContractBean>();
        for (ActiveContractBean activeContractBean : contractHistoryList) {
            if (StringUtils.isNotBlank(activeContractBean.getQuoteValidDate())) {
                int daysLeft = getCrmUtil().calculateDaysLeftForQuotes(pWarrantyQuoteStartDate, activeContractBean.getQuoteValidDate(), getQuoteDateFormat());
                if (daysLeft >= getMinWarrantyDays() && daysLeft <= getMaxWarrantyDays()) {
                    activeContractList.add(activeContractBean);
                }
            }

        }
        return activeContractList;
    }
    
    
    public void setBudgetQuoteLabelsWithServiceCharge(List<ReviewQuotesBean> reviewQuoteItems) {
        List<ReviewQuoteDetailsInfo> quoteItemList = new ArrayList<ReviewQuoteDetailsInfo>();
        if (reviewQuoteItems != null && reviewQuoteItems.get(0) != null && reviewQuoteItems.get(0).getQuoteItems() != null && !reviewQuoteItems.get(0).getQuoteItems().isEmpty()) {
            vlogDebug("QuoteItems size before resetting labels for BQ with Service charge only" + reviewQuoteItems.get(0).getQuoteItems().size());
            for (ReviewQuoteDetailsInfo quoteItem : reviewQuoteItems.get(0).getQuoteItems()) {    
            	String chargeType = quoteItem.getRepairServiceChargeType();
            	if ((StringUtils.isNotBlank(chargeType) && chargeType.equalsIgnoreCase(LynxConstants.SERVICE_CHARGE))) {
            		quoteItem.setServicePlan(getInternationalizationService().getLocalizeMessage(LynxConstants.EXTIMATED_REPAIR_SERVICE, null));
            		quoteItem.setChargeType(getInternationalizationService().getLocalizeMessage(LynxConstants.REPAIR_PARTS_LABOR, null));
            		quoteItem.setOrderedProd(getInternationalizationService().getLocalizeMessage(LynxConstants.ORDERED_TYPE_REPAIR, null));            
            		vlogDebug("QuoteItems details : ServicePlan: {0}, ChargeType: {1}, UnitPrice: {2}, ItemQuantityValue: {3}, QuoteSystemGrossValue: {4}", quoteItem.getServicePlan(),
            		quoteItem.getChargeType(), quoteItem.getUnitPrice(), quoteItem.getItemQuantityValue(), quoteItem.getQuoteSystemGrossValue());
            		
            	}
            	quoteItemList.add(quoteItem);  
            }
        	resetPriceDescForRepairQuote(reviewQuoteItems) ;
            if(quoteItemList!=null && !quoteItemList.isEmpty()){            
                reviewQuoteItems.get(0).setQuoteItems(quoteItemList);
            }
            
            vlogDebug("QuoteItems size after resetting labels for BQ with Service charge only " + reviewQuoteItems.get(0).getQuoteItems().size());
        }
    }
    
    public void resetPriceDescForRepairQuote(List<ReviewQuotesBean> reviewQuoteItems) {    	   
    	Map<String, String> formattedPriceMap = null;            
    	if (reviewQuoteItems != null && reviewQuoteItems.get(0) != null && reviewQuoteItems.get(0).getFormattedPriceListMap() != null) {
    		vlogDebug("Resetting Price Labels for Repair Quotes to Estimated Total " + reviewQuoteItems.get(0).getQuoteItems().size());
    		List<Map<String,String>> priceListMap= reviewQuoteItems.get(0).getFormattedPriceListMap();
    		String localisedPriceDesc=null;
    		String currency=LynxConstants.OPEN_BRACKET + reviewQuoteItems.get(0).getCurrency() + LynxConstants.CLOSE_BRACKET; 
    		if(priceListMap != null && !priceListMap.isEmpty()){
    			for(int i=0; i < priceListMap.size(); i++){
    				if(i!=1){ 
    					Map<String, String> priceMap= priceListMap.get(i);
    					for (Map.Entry<String, String> entry : priceMap.entrySet()) {  
    						formattedPriceMap = new HashMap<String, String>();;                					
    						localisedPriceDesc=getInternationalizationService().getLocalizeMessage(LynxConstants.ESTIMATED_TOTAL_PRICE, null);
    						if(StringUtils.isNotBlank(localisedPriceDesc)){
    							localisedPriceDesc=localisedPriceDesc + LynxConstants.WHITE_SPACE + currency ;  
    							formattedPriceMap.put(localisedPriceDesc,entry.getValue());
    							reviewQuoteItems.get(0).getFormattedPriceListMap().set(i, formattedPriceMap);
    						}
    					}

    				}
    			}
    		} 
    	}

    	vlogDebug("Resetting Price Labels for Repair Quotes to Estimated Total " + reviewQuoteItems.get(0).getQuoteItems().size());
    }
    

    public CRMUtil getCrmUtil() {
        return crmUtil;
    }

    public void setCrmUtil(CRMUtil crmUtil) {
        this.crmUtil = crmUtil;
    }

    public RestClient getRestClient() {
        return restClient;
    }

    public void setRestClient(RestClient restClient) {
        this.restClient = restClient;
    }

    public SAPCRMAPIManager getSapcrmapiManager() {
        return sapcrmapiManager;
    }

    public void setSapcrmapiManager(SAPCRMAPIManager sapcrmapiManager) {
        this.sapcrmapiManager = sapcrmapiManager;
    }

    public EncryptDecryptHelper getEncryptDecryptHelper() {
        return encryptDecryptHelper;
    }

    public void setEncryptDecryptHelper(EncryptDecryptHelper encryptDecryptHelper) {
        this.encryptDecryptHelper = encryptDecryptHelper;
    }

    public String getRqlContractQuery() {
        return mRqlContractQuery;
    }

    public void setRqlContractQuery(String mRqlContractQuery) {
        this.mRqlContractQuery = mRqlContractQuery;
    }

    public OrderManager getOrderManager() {
        return mOrderManager;
    }

    public void setOrderManager(OrderManager mOrderManager) {
        this.mOrderManager = mOrderManager;
    }

    /**
     * @return the errorHandler
     */
    public ErrorHandlerImpl getErrorHandler() {
        return errorHandler;
    }

    /**
     * @param errorHandler
     *            the errorHandler to set
     */
    public void setErrorHandler(ErrorHandlerImpl errorHandler) {
        this.errorHandler = errorHandler;
    }

    public List<String> getRepairOrderOpenStatusList() {
        return repairOrderOpenStatusList;
    }

    public void setRepairOrderOpenStatusList(List<String> repairOrderOpenStatusList) {
        this.repairOrderOpenStatusList = repairOrderOpenStatusList;
    }

    public List<String> getRepairOrderClosedStatusList() {
        return repairOrderClosedStatusList;
    }

    public void setRepairOrderClosedStatusList(List<String> repairOrderClosedStatusList) {
        this.repairOrderClosedStatusList = repairOrderClosedStatusList;
    }

 

    /**
     * Gets the value of property prevMainDropdownSkipMonths
     *
     * @return the value of property prevMainDropdownSkipMonths
     */
    public Integer getPrevMainDropdownSkipMonths() {
        return mPrevMainDropdownSkipMonths;
    }

    /**
     * Sets the value of property prevMainDropdownSkipMonths with value pPrevMainDropdownSkipMonths
     *
     * @param pPrevMainDropdownSkipMonths
     *            for setting property prevMainDropdownSkipMonths
     */
    public void setPrevMainDropdownSkipMonths(Integer pPrevMainDropdownSkipMonths) {
        mPrevMainDropdownSkipMonths = pPrevMainDropdownSkipMonths;
    }

    /**
     * Gets the value of property oldContractExpiredDaysDisplay
     *
     * @return the value of property oldContractExpiredDaysDisplay
     */
    public Integer getOldContractExpiredDaysDisplay() {
        return mOldContractExpiredDaysDisplay;
    }

    /**
     * Sets the value of property oldContractExpiredDaysDisplay with value pOldContractExpiredDaysDisplay
     *
     * @param pOldContractExpiredDaysDisplay
     *            for setting property oldContractExpiredDaysDisplay
     */
    public void setOldContractExpiredDaysDisplay(Integer pOldContractExpiredDaysDisplay) {
        mOldContractExpiredDaysDisplay = pOldContractExpiredDaysDisplay;
    }

    public List<String> getInternationalLocaleList() {
        return mInternationalLocaleList;
    }

    public void setInternationalLocaleList(List<String> pInternationalLocaleList) {
        mInternationalLocaleList = pInternationalLocaleList;
    }

    /**
     * Gets the value of property expiredContractRenewalDays
     *
     * @return the value of property expiredContractRenewalDays
     */
    public Integer getExpiredContractRenewalDays() {
        return mExpiredContractRenewalDays;
    }

    /**
     * Sets the value of property expiredContractRenewalDays with value pExpiredContractRenewalDays
     *
     * @param pExpiredContractRenewalDays
     *            for setting property expiredContractRenewalDays
     */
    public void setExpiredContractRenewalDays(Integer pExpiredContractRenewalDays) {
        mExpiredContractRenewalDays = pExpiredContractRenewalDays;
    }

    public InternationalizationService getInternationalizationService() {
        return mInternationalizationService;
    }

    public void setInternationalizationService(InternationalizationService pInternationalizationService) {
        mInternationalizationService = pInternationalizationService;
    }

    /**
     * Gets the value of property currencyCodeToLocaleMap
     *
     * @return the value of property currencyCodeToLocaleMap
     */
    public Map<String, String> getCurrencyCodeToLocaleMap() {
        return mCurrencyCodeToLocaleMap;
    }

    /**
     * Sets the value of property currencyCodeToLocaleMap with value pCurrencyCodeToLocaleMap
     *
     * @param pCurrencyCodeToLocaleMap
     *            for setting property currencyCodeToLocaleMap
     */
    public void setCurrencyCodeToLocaleMap(Map<String, String> pCurrencyCodeToLocaleMap) {
        mCurrencyCodeToLocaleMap = pCurrencyCodeToLocaleMap;
    }

    public String getAdjustedQuoteDateFormat() {
        return mAdjustedQuoteDateFormat;
    }

    public void setAdjustedQuoteDateFormat(String pAdjustedQuoteDateFormat) {
        mAdjustedQuoteDateFormat = pAdjustedQuoteDateFormat;
    }

    /**
     * Gets the value of property minWarrantyDays
     *
     * @return the value of property minWarrantyDays
     */
    public Integer getMinWarrantyDays() {
        return mMinWarrantyDays;
    }

    /**
     * Sets the value of property minWarrantyDays with value pMinWarrantyDays
     *
     * @param pMinWarrantyDays
     *            for setting property minWarrantyDays
     */
    public void setMinWarrantyDays(Integer pMinWarrantyDays) {
        mMinWarrantyDays = pMinWarrantyDays;
    }

    /**
     * Gets the value of property maxWarrantyDays
     *
     * @return the value of property maxWarrantyDays
     */
    public Integer getMaxWarrantyDays() {
        return mMaxWarrantyDays;
    }

    /**
     * Sets the value of property maxWarrantyDays with value pMaxWarrantyDays
     *
     * @param pMaxWarrantyDays
     *            for setting property maxWarrantyDays
     */
    public void setMaxWarrantyDays(Integer pMaxWarrantyDays) {
        mMaxWarrantyDays = pMaxWarrantyDays;
    }

    /**
     * Gets the value of property quoteDateFormat
     *
     * @return the value of property quoteDateFormat
     */
    public String getQuoteDateFormat() {
        return mQuoteDateFormat;
    }

    /**
     * Sets the value of property quoteDateFormat with value pQuoteDateFormat
     *
     * @param pQuoteDateFormat
     *            for setting property quoteDateFormat
     */
    public void setQuoteDateFormat(String pQuoteDateFormat) {
        mQuoteDateFormat = pQuoteDateFormat;
    }

    public AgilentConfigurationSecond getAgilentConfigurationSecond() {
        return agilentConfigurationSecond;
    }

    public void setAgilentConfigurationSecond(AgilentConfigurationSecond agilentConfigurationSecond) {
        this.agilentConfigurationSecond = agilentConfigurationSecond;
    }
    
   
   
}