/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;

import com.agilent.base.crm.bean.ContactDetailsBean;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.crm.ContactPersonBean;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.profile.crm.LynxContactConstants;
import com.agilent.base.profile.crm.LynxContactConstants.ServiceType;
import com.agilent.base.profile.crm.LynxContactConstants.UpdateModes;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.base.rest.lms.RestClient;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.nucleus.GenericService;

/**
 * The AgilentLynxContactServicesHelper contains the logic for invoking the CRM
 * Services for Fetch/Add/Update/Remove
 * 
 * @version 1.0
 * @author  Cognizant
 * @project Lynx-Phase2
 */

public class AgilentLynxContactServicesHelper extends GenericService implements LynxContactConstants {

	private SAPCRMAPIManager mSapcrmapiManager;
	private RestClient mRestClient;
	private EncryptDecryptHelper mEncryptDecryptHelper;
	private ErrorHandlerImpl mErrorHandler;
	private String mAddSuccessPayloadResHeader;

	/**
	 * Identifies and invokes contact update methods based on the serviceTypes contract/quote
	 * 
	 * @param contactPersonBean
	 * @param serviceType
	 * @return
	 */
	public HttpResponse updateContact(ContactPersonBean contactPersonBean, String serviceType) {
		HttpResponse response = null;
		if (ServiceType.CONTRACT.toString().equalsIgnoreCase(serviceType)) {
			response = updateContractContactInfo(contactPersonBean);
		} else if (ServiceType.QUOTE.toString().equalsIgnoreCase(serviceType)) {
			response = updateQuoteContactInfo(contactPersonBean);
		}
		return response;
	}

	/**
	 * Identifies the request type or mode and invokes the update method for contracts
	 * 
	 * @param contactPersonBean
	 * @return
	 */
	private HttpResponse updateContractContactInfo(ContactPersonBean contactPersonBean) {
		HttpResponse updateContractResponse = null;
		if (UpdateModes.I.toString().equals(contactPersonBean.getMode()) 
				|| UpdateModes.S.toString().equals(contactPersonBean.getMode()) 
				|| UpdateModes.D.toString().equals(contactPersonBean.getMode())) {
			updateContractResponse = update(contactPersonBean);
		}
		return updateContractResponse;
	}

	/**
	 * Identifies the request type or mode and invokes the update method for quotes
	 * 
	 * @param contactPersonBean
	 * @return
	 */
	private HttpResponse updateQuoteContactInfo(ContactPersonBean contactPersonBean) {
		HttpResponse updateQuoteResponse = null;
		if (UpdateModes.I.toString().equals(contactPersonBean.getMode()) 
				|| UpdateModes.S.toString().equals(contactPersonBean.getMode()) 
				|| UpdateModes.D.toString().equals(contactPersonBean.getMode())) {
			updateQuoteResponse = update(contactPersonBean);
		}
		return updateQuoteResponse;
	}

	/**
	 * Invokes the CRM update contact for both contracts and quotes
	 * 
	 * @param contactPersonBean
	 * @return
	 */
	private HttpResponse update(ContactPersonBean contactPersonBean) {
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		HttpResponse addContactResponse = null;
		Map<String, Object> response = this.getSapcrmapiManager().getXCSRFTokenForUpdatePerson(httpClient);
		if(response != null){
		 addContactResponse = this.getSapcrmapiManager().postUpdateContractRequest(response, httpClient, contactPersonBean);
		 vlogInfo("Response from Add CRM Service {0}", addContactResponse);
		}
		return addContactResponse;
	}

	/**
	 * Returns an List of Contacts associated with the Partner Number passed as
	 * method Argument
	 * 
	 * @param accountId
	 * @return List of ContactDetailsBean
	 */

	public List<ContactDetailsBean> fetchContactDetails(String accountId) {
		List<ContactDetailsBean> contactList = null;
		ContactDetailsBean contactDetailsBean = null;
		List<Map<String, Object>> contactResultsList = null;
		Map<String, Object> contactDetails = null;
		try {
			RestClient client = getRestClient();
			// account id null check
			contactList = new ArrayList<ContactDetailsBean>();
			if (!StringUtils.isEmpty(accountId)) {
				contactDetails = getSapcrmapiManager().getContactDetailsCall(client, accountId);
				if (null != contactDetails) {
					contactResultsList = (List<Map<String, Object>>) contactDetails.get(LynxConstants.RESULTS);
					if (contactResultsList != null && !contactResultsList.isEmpty()) {
						vlogInfo("getting results from Sap web service for accountId {0}", accountId);
						for (Map<String, Object> contactRefItem : contactResultsList) {
							contactDetailsBean = new ContactDetailsBean();
							setContactBean(contactDetailsBean, contactRefItem);
							contactList.add(contactDetailsBean);
						}
					}
					else{
						vlogInfo("No data found from transaction Id {0}", accountId);
						contactDetailsBean = new ContactDetailsBean();
						contactDetailsBean
								.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA,
										new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
						contactList.add(contactDetailsBean);
					}
				}

				else {
					vlogInfo("No data found from transaction Id {0}", accountId);
					contactDetailsBean = new ContactDetailsBean();
					contactDetailsBean
							.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA,
									new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
					contactList.add(contactDetailsBean);
				}
			} else {
				vlogInfo("No data found from transaction Id {0}", accountId);
				// contactDetailsBean = new ContactDetailsBean();
				contactDetailsBean = new ContactDetailsBean();
				contactDetailsBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(
						LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
				contactList.add(contactDetailsBean);
			}

			

		} catch (ClientProtocolException cpe) {
			vlogError(cpe, "Error in calling the fetch contact detail call/network issue");
			contactList = new ArrayList<ContactDetailsBean>();
			contactDetailsBean = new ContactDetailsBean();
			contactDetailsBean
					.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_SERVICE_ISSUE,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
			contactList.add(contactDetailsBean);
		}

		catch (IOException ioe) {
			vlogError(ioe, "Error in calling the fetch contact detail call while passing input");
			contactList = new ArrayList<ContactDetailsBean>();
			contactDetailsBean = new ContactDetailsBean();
			contactDetailsBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA,
					new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
			contactList.add(contactDetailsBean);
		} catch (Exception e) {
			vlogError(e, "Error in calling the fetch contact detail call");
			contactList = new ArrayList<ContactDetailsBean>();
			contactDetailsBean = new ContactDetailsBean();
			contactDetailsBean
					.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_SERVICE_ISSUE,
							new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
			contactList.add(contactDetailsBean);
		}
		return contactList;
	}

	/**
	 * Sets all the variables of ContactDetailsBean to values from service response
	 * 
	 * 
	 * @param contactDetailsBean,contactDetailsRefItem
	 * @return void
	 */
	public void setContactBean(ContactDetailsBean contactDetailsBean, Map<String, Object> contactDetailsRefItem) {
		if (!StringUtils.isEmpty((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_ID))) {
			contactDetailsBean
					.setContactId((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_ID));
		}
		if (!StringUtils.isEmpty((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_FNAME))) {
			contactDetailsBean.setContactFirstName(
					(String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_FNAME));
		}
		if (!StringUtils.isEmpty((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LNAME))) {
			contactDetailsBean.setContactLastName(
					(String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LNAME));
		}
		if (!StringUtils
				.isEmpty((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LYNX_EMAIL))) {
			contactDetailsBean.setContactEmail(
					(String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LYNX_EMAIL));
		}
		if (!StringUtils
				.isEmpty((String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LYNX_PHONE))) {
			contactDetailsBean.setContactPhone(
					(String) contactDetailsRefItem.get(AgilentLynxContactServicesHelper.CONTACT_LYNX_PHONE));
		}
	}
	
	public Object genertePostResponse(HttpResponse response) {
		String responseJson = null;
		String respPayloadJsonStr = null;
		Map fromJson = null;
		if(null != response){
			try {
				responseJson = IOUtils.toString(response.getEntity().getContent());
				vlogDebug("JSON response from web service {0}", responseJson);
			} catch (IllegalStateException e1) {
				// TODO Auto-generated catch block
				vlogError("IllegalStateException while generating response {0}", e1);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				vlogError("IOException while generating response {0}", e1);
			}
	
			if (!StringUtils.isEmpty(responseJson) && -1 != responseJson.lastIndexOf("}") && -1 != responseJson.indexOf("{") ) {
				Gson gson = new Gson();
				respPayloadJsonStr = responseJson.substring(responseJson.indexOf("{"), (responseJson.lastIndexOf("}") + 1));
				if(!respPayloadJsonStr.contains("error") && responseJson.contains(getAddSuccessPayloadResHeader())){
					fromJson = gson.fromJson((String) respPayloadJsonStr, Map.class);
				}
				vlogDebug("JSON response converting into Map {0}", fromJson);
			}
		}
		return fromJson;
	}

	/**
	 * @return the sapcrmapiManager
	 */
	public SAPCRMAPIManager getSapcrmapiManager() {
		return mSapcrmapiManager;
	}

	/**
	 * @param sapcrmapiManager
	 *            the sapcrmapiManager to set
	 */
	public void setSapcrmapiManager(SAPCRMAPIManager sapcrmapiManager) {
		this.mSapcrmapiManager = sapcrmapiManager;
	}

	/**
	 * @return the restClient
	 */
	public RestClient getRestClient() {
		return mRestClient;
	}

	/**
	 * @param restClient
	 *            the restClient to set
	 */
	public void setRestClient(RestClient restClient) {
		this.mRestClient = restClient;
	}

	/**
	 * @return the encryptDecryptHelper
	 */
	public EncryptDecryptHelper getEncryptDecryptHelper() {
		return mEncryptDecryptHelper;
	}

	/**
	 * @param encryptDecryptHelper
	 *            the encryptDecryptHelper to set
	 */
	public void setEncryptDecryptHelper(EncryptDecryptHelper encryptDecryptHelper) {
		this.mEncryptDecryptHelper = encryptDecryptHelper;
	}

	/**
	 * @return the errorHandler
	 */
	public ErrorHandlerImpl getErrorHandler() {
		return mErrorHandler;
	}

	/**
	 * @param errorHandler
	 *            the errorHandler to set
	 */
	public void setErrorHandler(ErrorHandlerImpl errorHandler) {
		this.mErrorHandler = errorHandler;
	}
	
	/**
	 * @return the addSuccessPayloadResHeader
	 */
	public String getAddSuccessPayloadResHeader() {
		return mAddSuccessPayloadResHeader;
	}

	/**
	 * @param addSuccessPayloadResHeader
	 *            the addSuccessPayloadResHeader to set
	 */
	public void setAddSuccessPayloadResHeader(String addSuccessPayloadResHeader) {
		this.mAddSuccessPayloadResHeader = addSuccessPayloadResHeader;
	}
}
