/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.commonstore.crm.helper;

import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.CHINESE_ENCODING;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.CHINESE_FONT_STD;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.FONTAWESOME;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.JAPANESE_ENCODING;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.JAPANESE_FONT_REGULAR;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.KOREAN_ENCODING;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.KOREAN_FONT_STD_MEDIUM;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.ROBOTOMEDIUM;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.ROBOTOREGULAR;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.ROBOTO_CONDENSEDBOLD;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.ROBOTO_CONDENSEDLIGHT;
import static com.agilent.commonstore.crm.formhandler.PdfQuoteDownloadForm.ROBOTO_CONDENSEDREGULAR;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.agilent.base.common.AgilentConfigurationSecond;
import com.agilent.base.common.ChinaConfiguration;
import com.agilent.base.commerce.Constants;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.QuoteDetails;
import com.agilent.base.common.services.SAPAddress;
import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.crm.LscaQuoteConstants;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPCellEvent;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.TextMarginFinder;

import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.RequestLocale;
import atg.servlet.ServletUtil;
import atg.repository.RepositoryItem;

/**
 * This Helper class is used for handling quote download functionality.
 */
public class AgilentQuoteDownloadHelper extends GenericService {

    private String contactUsURL;
    private String mAgilentLogoImageName;
    private ErrorHandlerImpl mErrorHandler;
    private AgilentConfiguration mConfiguration;

    public String agilentLogo;
    public String chinaContactUsURL;
    public String maxicoContactUsURL;
    public BaseFont awesomeBaseFont;
    public BaseFont robotoregularBaseFont;
    public BaseFont robotomediumBaseFont;
    public BaseFont condensedlightBaseFont;
    public BaseFont condensedboldeBaseFont;
    public BaseFont condensedregularBaseFont;
    private Map<String,String> pdfAddressLabelMap;
    private Map<String,String> pdfContactLabelMap;
    private Map<String, String> mCurrencyCodeToLocaleMap;
    private Map<String, String> mImageHorizontalPositionMap;
    private Map<String, String> mImageScaleSizeMap;
    private AgilentConfigurationSecond configurationSecond;
   	private ChinaConfiguration mChinaConfiguration;
    public static final String CURRENCY_PATTERN="##0.00";

	private List <String> customContactFmtSalesOrgList;
	private Map<String, String>  mCustomCountryMap;

    /**
     * Returns the quote as PDF represented by a table.
     * 
     * @param fontPath
     * @param locale
     * @param quoteDetails
     * @return
     * @throws DocumentException
     * @throws IOException
     * @throws ParseException
     */
    public PdfPTable getQuoteAsPDF(String fontPath, Locale locale, QuoteDetails quoteDetails) throws DocumentException, IOException, ParseException {
        vlogDebug("AgilentQuoteDownloadHelper.getQuoteAsPDF --START--");
        awesomeBaseFont = getRoboFont(fontPath + FONTAWESOME, locale, quoteDetails.getSalesOrg());
        robotoregularBaseFont = getRoboFont(fontPath + ROBOTOREGULAR, locale, quoteDetails.getSalesOrg());
        robotomediumBaseFont = getRoboFont(fontPath + ROBOTOMEDIUM, locale, quoteDetails.getSalesOrg());
        condensedlightBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDLIGHT, locale, quoteDetails.getSalesOrg());
        condensedboldeBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDBOLD, locale, quoteDetails.getSalesOrg());
        condensedregularBaseFont = getRoboFont(fontPath + ROBOTO_CONDENSEDREGULAR, locale, quoteDetails.getSalesOrg());
        agilentLogo = fontPath + File.separator + this.getAgilentLogoImageName();
        vlogDebug("AgilentQuoteDownloadHelper.getQuoteAsPDF --agilentLogo-- {0}", agilentLogo);
        vlogDebug("AgilentQuoteDownloadHelper.getQuoteAsPDF --quoteDetails-- {0}", quoteDetails);
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(this.getInnerTable0(quoteDetails));
        pdf.addCell(getInnerTable1(quoteDetails, locale));
        pdf.addCell(getInnerTable2(quoteDetails));
        //Condition for AMS-477
        if (StringUtils.isNotBlank(quoteDetails.getSalesOrg()) && quoteDetails.getSalesOrg().equalsIgnoreCase("04MX")) {        	
        } else {
        	pdf.addCell(getProductDetailsHeader());
        }
        pdf.addCell(getInnerTable3(quoteDetails));
        pdf.addCell(getOrderDetailTable(quoteDetails));
        vlogDebug("AgilentQuoteDownloadHelper.getQuoteAsPDF --END--");
        return pdf;
    }

    /**
     * Parent table holding header information.
     * 
     * @return
     * @throws DocumentException
     * @throws MalformedURLException
     * @throws IOException
     */
    private PdfPTable getInnerTable0(QuoteDetails quoteDetails) throws DocumentException, MalformedURLException, IOException {
        vlogDebug("AgilentQuoteDownloadHelper.getInnerTable0 --START--");
        PdfPTable innerTable1 = new PdfPTable(2);
        innerTable1.setWidthPercentage(100);
        innerTable1.setSpacingAfter(30);
        innerTable1.setWidths(new float[] {40, 60});
        PdfPCell innerTable1Cell1 = new PdfPCell(Image.getInstance(agilentLogo));
        innerTable1Cell1.setBorder(PdfPCell.NO_BORDER);
        PdfPCell innerTable1Cell2 = getInnerTable0Cell2(quoteDetails);
        innerTable1Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable1.addCell(innerTable1Cell1);
        innerTable1.addCell(innerTable1Cell2);
        return innerTable1;
    }

    /**
     * This method returns Agilent address and contact details as a PDF cell.
     * 
     * @return
     * @throws DocumentException
     */
    private PdfPCell getInnerTable0Cell2(QuoteDetails quoteDetails) throws DocumentException {
    	PdfPTable innerTable1 = new PdfPTable(2);
    	innerTable1.setWidths(new float[] { 3, 4 });
    	// Changes for DCCOM-2344 starts

    	String pdfAddressLabelKey = LscaQuoteConstants.PDF_ADDRESS;

    	if (StringUtils.isNotEmpty(quoteDetails.getSalesOrg())
    			&& this.getPdfAddressLabelMap().containsKey(quoteDetails.getSalesOrg())) {
    		pdfAddressLabelKey = this.getPdfAddressLabelMap().get(quoteDetails.getSalesOrg());
    	}

    	vlogDebug("pdfAddressLabelKey = {0}", pdfAddressLabelKey);

    	PdfPCell cell1 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(pdfAddressLabelKey, new Object[] {}, 
    			LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(robotoregularBaseFont, 8)));
    	cell1.setBorder(PdfPCell.NO_BORDER);
    	// Changes for DCCOM-2344 ends

    	PdfPCell innerTable1Cell2 = getInnerTableContactDetails(quoteDetails); 
    	innerTable1Cell2.setBorder(PdfPCell.NO_BORDER);

    	innerTable1.addCell(cell1);
    	innerTable1.addCell(innerTable1Cell2);
    	return new PdfPCell(innerTable1);
    }
    
    
    /**
     * Generate Contact Details Table
     * 
     * @param quoteDetails
     * @return
     * @throws DocumentException
     */
    private PdfPCell getInnerTableContactDetails(QuoteDetails quoteDetails) throws DocumentException {
    	PdfPTable innerTable1 = new PdfPTable(2);
    	innerTable1.setWidths(new float[] { 2, 3 });

    	String pdfContactLabelKey = LscaQuoteConstants.PDF_CONTACT;

    	if (StringUtils.isNotEmpty(quoteDetails.getSalesOrg())
    			&& this.getPdfContactLabelMap().containsKey(quoteDetails.getSalesOrg())) {
    		pdfContactLabelKey = this.getPdfContactLabelMap().get(quoteDetails.getSalesOrg());
    	}

    	vlogDebug("pdfContactLabelKey = {0}" , pdfContactLabelKey);

		String contactDetail = getErrorHandler().getFormattedErrorMessage(pdfContactLabelKey, new Object[] {},
				LscaQuoteConstants.LSCA_QUOTE_LABEL);

    	String[] splittedContactDetail = new String[4];

    	if(StringUtils.isNotBlank(contactDetail)){
    		splittedContactDetail = contactDetail.split(LscaQuoteConstants.NEWLINE);
    	}

    	String teleData = splittedContactDetail[0];
    	String faxData = splittedContactDetail[1];
    	String emailData = splittedContactDetail[2];
    	String webData = splittedContactDetail[3];
    	
		vlogDebug("teleData = {0}", teleData);
		vlogDebug("faxData = {0}", faxData);
		vlogDebug("emailData = {0}", emailData);
		vlogDebug("webData = {0}", webData);

    	if(StringUtils.isNotEmpty(teleData)){
    		PdfPCell telLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TELEPHONE,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    		PdfPCell telDataCell = new PdfPCell(new Phrase(teleData,new Font(robotoregularBaseFont, 8)));
    		telLabelCell.setBorder(PdfPCell.NO_BORDER);
    		telDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(telLabelCell);
    		innerTable1.addCell(telDataCell);
    	}

    	if(StringUtils.isNotEmpty(faxData)){
    		PdfPCell faxLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_FAX,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    		PdfPCell faxDataCell = new PdfPCell(new Phrase(faxData,new Font(robotoregularBaseFont, 8)));
    		faxLabelCell.setBorder(PdfPCell.NO_BORDER);
    		faxDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(faxLabelCell);
    		innerTable1.addCell(faxDataCell);
    	}

    	if(StringUtils.isNotEmpty(emailData)){
    		PdfPCell emailLabelCell= new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_EMAIL,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    		PdfPCell emailDataCell = new PdfPCell(new Phrase(emailData,new Font(robotoregularBaseFont, 8)));
    		emailLabelCell.setBorder(PdfPCell.NO_BORDER);
    		emailDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(emailLabelCell);
    		innerTable1.addCell(emailDataCell);
    	}

    	if(StringUtils.isNotEmpty(webData)){
    		PdfPCell webLabelCell= new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_WEBSITE,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    		PdfPCell webDataCell = new PdfPCell(new Phrase(webData,new Font(robotoregularBaseFont, 8)));
    		webLabelCell.setBorder(PdfPCell.NO_BORDER);
    		webDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(webLabelCell);
    		innerTable1.addCell(webDataCell);
    	}

    	return new PdfPCell(innerTable1);
    }
    
    

    /**
     * Parent table holding all the quote information.
     * 
     * @param quoteDetails
     * @param locale
     * @return
     */
    private PdfPTable getInnerTable1(QuoteDetails quoteDetails, Locale locale) throws DocumentException {
        PdfPTable innerTable1 = new PdfPTable(2);
        innerTable1.setWidthPercentage(100);
        PdfPCell innerTable1Cell1 = new PdfPCell();
        innerTable1Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable1Cell1.setFixedHeight(25);
        PdfPCell innerTable1Cell2 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTATIONS, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 15)));

        innerTable1Cell2.setCellEvent(new CellBackground());
        innerTable1Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable1Cell2.setFixedHeight(25);
        innerTable1Cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
        innerTable1Cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);

        PdfPCell innerTable1Cell3 = new PdfPCell();
		
		//AMS-797 START
		if (StringUtils.isNotEmpty(quoteDetails.getSalesOrg())
    			&& getCustomContactFmtSalesOrgList().contains(quoteDetails.getSalesOrg()))
		
		{
			
			innerTable1Cell3 = getInnerTable1CustomCell3(quoteDetails,locale);
			
		}//AMS-797 END
		else{

			Phrase customerContactTextPhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CUSTCONTACT, new Object[] {}, 
					LscaQuoteConstants.LSCA_QUOTE_LABEL) + "\n", new Font(condensedboldeBaseFont, 9));

			List<SAPAddress> pCustomerContactAddress = quoteDetails.getCustomerContactAddress();
			List<SAPAddress> pInternationalCustomerContactAddress = quoteDetails.getInternationalCustomerContactAddress();
			vlogDebug("CustomerContactAddress: {0} InternationalCustomerContactAddress: {1}", pCustomerContactAddress, pInternationalCustomerContactAddress);
			String customerAddress = null;
			if (null != locale) {
				if (locale.toString().equals(Locale.US.toString()) && pInternationalCustomerContactAddress.isEmpty()) {
					customerAddress = pCustomerContactAddress.get(0).getCompanyName() + "\n" + pCustomerContactAddress.get(0).getAddress1() + "\n"
							+ pCustomerContactAddress.get(0).getAddress2() + "\n" + pCustomerContactAddress.get(0).getCity() + "\n" + pCustomerContactAddress.get(0).getCountry() + "\n"
							+ pCustomerContactAddress.get(0).getAddress3() + "\n" + pCustomerContactAddress.get(0).getPostalCode() + "\n"
							+ pCustomerContactAddress.get(0).getPhoneNumber();
				} else {
					if (!(Constants.EN.equalsIgnoreCase(locale.getLanguage())) && !pInternationalCustomerContactAddress.isEmpty()) {
						customerAddress = pInternationalCustomerContactAddress.get(0).getCompanyName() + "\n" + pInternationalCustomerContactAddress.get(0).getAddress1() + "\n"
								+ pInternationalCustomerContactAddress.get(0).getAddress2() + "\n" + pInternationalCustomerContactAddress.get(0).getCity() + "\n"
								+ pInternationalCustomerContactAddress.get(0).getCountry() + "\n" + pInternationalCustomerContactAddress.get(0).getAddress3() + "\n"
								+ pInternationalCustomerContactAddress.get(0).getPostalCode() + "\n" + pInternationalCustomerContactAddress.get(0).getPhoneNumber();
					} else {
						customerAddress = pCustomerContactAddress.get(0).getCompanyName() + "\n" + pCustomerContactAddress.get(0).getAddress1() + "\n"
								+ pCustomerContactAddress.get(0).getAddress2() + "\n" + pCustomerContactAddress.get(0).getCity() + "\n" + pCustomerContactAddress.get(0).getCountry()
								+ "\n" + pCustomerContactAddress.get(0).getAddress3() + "\n" + pCustomerContactAddress.get(0).getPostalCode() + "\n"
								+ pCustomerContactAddress.get(0).getPhoneNumber();
					}
				}
				vlogDebug("Locale: {0} CustomerAddress: {1}", locale.toString(), customerAddress);
			}

			customerContactTextPhrase.add(new Phrase(customerAddress, new Font(condensedregularBaseFont, 9)));
			innerTable1Cell3.addElement(customerContactTextPhrase);
			innerTable1Cell3.setBorder(PdfPCell.NO_BORDER);
		
		}
		
        PdfPCell innerTable1Cell4 = getInnerTable1Cell4(quoteDetails);
        innerTable1.addCell(innerTable1Cell1);
        innerTable1.addCell(innerTable1Cell2);
        innerTable1.addCell(innerTable1Cell3);
        innerTable1.addCell(innerTable1Cell4);
        return innerTable1;
    }

	//AMS-797 START
	/**
     * Table holding quote meta information.
     * 
     * @param quoteDetails
     * @return
     */
    private PdfPCell getInnerTable1CustomCell3(QuoteDetails quoteDetails, Locale locale) throws DocumentException{
        PdfPCell innerTable1Cell3 = new PdfPCell();
        innerTable1Cell3.setBorder(PdfPCell.NO_BORDER);
        PdfPTable quoteCustomContactTable = new PdfPTable(2);
		quoteCustomContactTable.setWidthPercentage(100);
		quoteCustomContactTable.setWidths(new float[] { 2, 3 });
		
		List<SAPAddress> pCustomerShippingAddress = quoteDetails.getShippingAddress();
		List<SAPAddress> pInternationalShippingAddress = quoteDetails.getInternationalShipAddress();
		String customerAddress = null;
		String companyName = null;
		String telePhone = null;
		String customerName= null;	
		String email = null;
		String lastNameProfile = null;
		String firstNameProfile = null;
		RepositoryItem profileShipAddress = null;
		String userCountry = null;
		AgilentProfile profile = (AgilentProfile) ServletUtil.getCurrentRequest().resolveName("/atg/userprofiling/Profile");
		
			if (profile != null) {
					email = (String) profile.getPropertyValue("email");
					lastNameProfile = (String) profile.getPropertyValue("lastName");
					firstNameProfile = (String) profile.getPropertyValue("firstName");
					customerName = lastNameProfile + " " + firstNameProfile;
					profileShipAddress = (RepositoryItem) profile.getPropertyValue("shippingAddress");
					userCountry= (String) profile.getPropertyValue("userCountry");
			}
			
			if (null != locale) {
				if (locale.toString().equals(Locale.US.toString()) && pInternationalShippingAddress.isEmpty()) {
						companyName = pCustomerShippingAddress.get(0).getCompanyName();
						customerAddress=getAddress(pCustomerShippingAddress);
						telePhone = pCustomerShippingAddress.get(0).getPhoneNumber();
				} else {
					if (!(Constants.EN.equalsIgnoreCase(locale.getLanguage())) && !pInternationalShippingAddress.isEmpty()) {
						companyName = pInternationalShippingAddress.get(0).getCompanyName();
						customerAddress = getAddress(pInternationalShippingAddress);
						telePhone = pInternationalShippingAddress.get(0).getPhoneNumber();
					} else {
						companyName = pCustomerShippingAddress.get(0).getCompanyName();
						customerAddress = getAddress(pCustomerShippingAddress);
						telePhone = pCustomerShippingAddress.get(0).getPhoneNumber();
					}
				}
			}
		
			if (StringUtils.isEmpty(telePhone) && profileShipAddress != null) {
					telePhone= (String) profileShipAddress.getPropertyValue("phoneNumber");
			}
			
		vlogDebug("Locale: {0} CustomerAddress: {1} customerName : {2} email :{3} tel :{4} companyname: {5}", locale.toString(), customerAddress,customerName,email,telePhone,companyName);
		
		//Customer Contact:
		if(!"CN".equals(userCountry))
			{
				PdfPCell customerContactTextLabel = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CUSTCONTACT, new Object[] {}, 
							LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
				PdfPCell emptyCell = new PdfPCell();
				customerContactTextLabel.setBorder(PdfPCell.NO_BORDER);
				emptyCell.setBorder(PdfPCell.NO_BORDER);
				quoteCustomContactTable.addCell(customerContactTextLabel);
				quoteCustomContactTable.addCell(emptyCell);
			}
		//Contact Details
    	PdfPCell cmnyNameLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_COMPANY_NAME,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    	PdfPCell cmnyNameDataCell = new PdfPCell(new Phrase(companyName,new Font(robotoregularBaseFont, 8)));
		cmnyNameLabelCell.setBorder(PdfPCell.NO_BORDER);
		cmnyNameDataCell.setBorder(PdfPCell.NO_BORDER);
    	quoteCustomContactTable.addCell(cmnyNameLabelCell);
    	quoteCustomContactTable.addCell(cmnyNameDataCell);
		
		PdfPCell custNameLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CUSTOMER_NAME,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    	PdfPCell custNameDataCell = new PdfPCell(new Phrase(customerName,new Font(robotoregularBaseFont, 8)));
		custNameLabelCell.setBorder(PdfPCell.NO_BORDER);
		custNameDataCell.setBorder(PdfPCell.NO_BORDER);
    	quoteCustomContactTable.addCell(custNameLabelCell);
    	quoteCustomContactTable.addCell(custNameDataCell);
		
		PdfPCell addressLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CUST_SHIP_ADDRESS,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    	PdfPCell addressDataCell = new PdfPCell(new Phrase(customerAddress,new Font(robotoregularBaseFont, 8)));
		addressLabelCell.setBorder(PdfPCell.NO_BORDER);
		addressDataCell.setBorder(PdfPCell.NO_BORDER);
    	quoteCustomContactTable.addCell(addressLabelCell);
    	quoteCustomContactTable.addCell(addressDataCell);
		
		PdfPCell telPhnLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_PHONENUMEBR,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    	PdfPCell telPhnDataCell = new PdfPCell(new Phrase(telePhone,new Font(robotoregularBaseFont, 8)));
		telPhnLabelCell.setBorder(PdfPCell.NO_BORDER);
		telPhnDataCell.setBorder(PdfPCell.NO_BORDER);
    	quoteCustomContactTable.addCell(telPhnLabelCell);
    	quoteCustomContactTable.addCell(telPhnDataCell);
    	

		PdfPCell emailLabelCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CUST_EMAIL,
    				new Object[] {}, LscaQuoteConstants.LSCA_QUOTE_LABEL),new Font(robotoregularBaseFont, 8)));
    	PdfPCell emailDataCell = new PdfPCell(new Phrase(email,new Font(robotoregularBaseFont, 8)));
		emailLabelCell.setBorder(PdfPCell.NO_BORDER);
		emailDataCell.setBorder(PdfPCell.NO_BORDER);
    	quoteCustomContactTable.addCell(emailLabelCell);
    	quoteCustomContactTable.addCell(emailDataCell);
		
        
        innerTable1Cell3.addElement(quoteCustomContactTable);
        return innerTable1Cell3;
    }
	
	private String getAddress(List<SAPAddress> sapAddressList) {
      
	  StringBuilder concatedAddress = null;
	  String address = null;
	  String countryLabel = null;
	  SAPAddress sapAddress = sapAddressList.get(0);
		if (sapAddress != null) {
			concatedAddress = new StringBuilder();
			if (StringUtils.isNotBlank(sapAddress.getAddress1())) {
				concatedAddress.append(sapAddress.getAddress1());
			}
			if (StringUtils.isNotBlank(sapAddress.getAddress2())) {
				concatedAddress.append("\n" + sapAddress.getAddress2());
			}
			if (StringUtils.isNotBlank(sapAddress.getCity())) {
				concatedAddress.append("\n" + sapAddress.getCity());
			}
			if (StringUtils.isNotBlank(sapAddress.getAddress3()) && !"TW".equals(sapAddress.getCountry())) {
				concatedAddress.append("\n"+ sapAddress.getAddress3());
			}
			if (StringUtils.isNotBlank(sapAddress.getCountry())) {

				if (StringUtils.isNotEmpty(sapAddress.getCountry())
    			&& this.getCustomCountryMap().containsKey(sapAddress.getCountry())) {
					countryLabel = this.getCustomCountryMap().get(sapAddress.getCountry());
				}
				if(countryLabel != null)
				{
					concatedAddress.append("\n" + countryLabel);
				}
				else
				{
					concatedAddress.append("\n" + sapAddress.getCountry());
				}
			}
			if (StringUtils.isNotBlank(sapAddress.getPostalCode())) {
				concatedAddress.append("\n" + sapAddress.getPostalCode());
			}
		
			address =  concatedAddress.toString();
		}
		
		return address;	
    }
	
	//AMS-797 END
	
    /**
     * Table holding quote meta information.
     * 
     * @param quoteDetails
     * @return
     */
    private PdfPCell getInnerTable1Cell4(QuoteDetails quoteDetails) {
        PdfPCell innerTable1Cell4 = new PdfPCell();
        innerTable1Cell4.setBorder(PdfPCell.NO_BORDER);
        PdfPTable quoteDetailOuterTable = new PdfPTable(1);
        quoteDetailOuterTable.setWidthPercentage(100);
        quoteDetailOuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        PdfPTable quoteDetailInnerTable1 = getInnerTable1Cell4Table1(quoteDetails);
        PdfPCell c1 = new PdfPCell(quoteDetailInnerTable1);
        c1.setPadding(0);
        quoteDetailOuterTable.addCell(c1);
        innerTable1Cell4.addElement(quoteDetailOuterTable);
        return innerTable1Cell4;
    }

    /**
     * Methods returns quote metadata as PDF table.
     * 
     * @param quoteDetails
     * @return
     */
    private PdfPTable getInnerTable1Cell4Table1(QuoteDetails quoteDetails) {
    	DynamoHttpServletRequest lRequest=ServletUtil.getCurrentRequest();
    	String domain=lRequest.getServerName();
        PdfPTable quoteDetailInnerTable1 = new PdfPTable(2);
        PdfPCell innerTable1Cell1 = new PdfPCell();
        Phrase quoteNumPhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTATIONNUMBER, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        quoteNumPhrase.add(new Phrase("\n" + quoteDetails.getQuoteNumber(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell1.addElement(quoteNumPhrase);
        PdfPCell innerTable1Cell2 = new PdfPCell();
        Phrase quoteDatePhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTAIONDATE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        quoteDatePhrase.add(new Phrase("\n" + quoteDetails.getQuoteDate(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell2.addElement(quoteDatePhrase);
        PdfPCell innerTable1Cell3 = new PdfPCell();
        Phrase estdDlvTimePhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_ESTDDELDATE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        estdDlvTimePhrase.add(new Phrase("\n" + quoteDetails.getEstdDeliveryDate(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell3.addElement(estdDlvTimePhrase);
        PdfPCell innerTable1Cell4 = new PdfPCell();
        Phrase quoteExpDatePhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTEEXPDATE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        quoteExpDatePhrase.add(new Phrase("\n" + quoteDetails.getQuoteExpDate(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell4.addElement(quoteExpDatePhrase);
        PdfPCell innerTable1Cell7 = new PdfPCell();
        //Condition for AMS-477
        if (StringUtils.isNotBlank(quoteDetails.getSalesOrg()) && quoteDetails.getSalesOrg().equalsIgnoreCase("04MX")) {        	
        } else {
        Phrase purchasingAgreementNoPhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_PAN, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        purchasingAgreementNoPhrase.add(new Phrase("\n" + quoteDetails.getPurchaseAgreementNumber(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell7.addElement(purchasingAgreementNoPhrase);
        }
        PdfPCell innerTable1Cell8 = new PdfPCell();
        Phrase currencyPhrase = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_CURRENCY, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        currencyPhrase.add(new Phrase("\n" + quoteDetails.getCurrency(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell8.addElement(currencyPhrase);

        PdfPCell innerTable1Cell9 = new PdfPCell();
        innerTable1Cell9.setColspan(2);
        innerTable1Cell9.setBorder(PdfPCell.RIGHT | PdfPCell.LEFT | PdfPCell.TOP);
        Phrase directEnquiriesPhrase1 = new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_INQUIRY, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9));

        innerTable1Cell9.addElement(directEnquiriesPhrase1);

        PdfPCell innerTable1Cell10 = new PdfPCell();
        innerTable1Cell10.setColspan(2);
        innerTable1Cell10.setBorder(PdfPCell.BOTTOM | PdfPCell.RIGHT | PdfPCell.LEFT);
        Phrase directEnquiriesPhrase2 = new Phrase(" ", new Font(condensedboldeBaseFont, 9));
        //Condition for AMS-477
        if(StringUtils.isNotBlank(domain)&&domain.contains(getConfigurationSecond().getChinaProfileCookieDomain())){
        	if (quoteDetails.getCurrency().equalsIgnoreCase(LscaQuoteConstants.CHINA_CURRENCY)) {
                directEnquiriesPhrase2.add(new Phrase(getChinaConfiguration().getChinaContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }  else if (StringUtils.isNotBlank(quoteDetails.getSalesOrg()) && quoteDetails.getSalesOrg().equalsIgnoreCase("04MX")) {
            	directEnquiriesPhrase2.add(new Phrase(getMaxicoContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }else {
                directEnquiriesPhrase2.add(new Phrase(getChinaConfiguration().getContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }
        }else{
        	if (quoteDetails.getCurrency().equalsIgnoreCase(LscaQuoteConstants.CHINA_CURRENCY)) {
                directEnquiriesPhrase2.add(new Phrase(getChinaContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }  else if (StringUtils.isNotBlank(quoteDetails.getSalesOrg()) && quoteDetails.getSalesOrg().equalsIgnoreCase("04MX")) {
            	directEnquiriesPhrase2.add(new Phrase(getMaxicoContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }else {
                directEnquiriesPhrase2.add(new Phrase(getContactUsURL(), new Font(condensedregularBaseFont, 9)));
            }	
        }
        innerTable1Cell10.addElement(directEnquiriesPhrase2);

        quoteDetailInnerTable1.addCell(innerTable1Cell1);
        quoteDetailInnerTable1.addCell(innerTable1Cell2);
        quoteDetailInnerTable1.addCell(innerTable1Cell3);
        quoteDetailInnerTable1.addCell(innerTable1Cell4);

        quoteDetailInnerTable1.addCell(innerTable1Cell7);
        quoteDetailInnerTable1.addCell(innerTable1Cell8);
        quoteDetailInnerTable1.addCell(innerTable1Cell9);
        quoteDetailInnerTable1.addCell(innerTable1Cell10);
        return quoteDetailInnerTable1;
    }

    /**
     * Returns quote metadata summary (Quote Number and Quote Date)
     * 
     * @param quoteDetails
     * @return
     * @throws DocumentException
     */
    private PdfPTable getInnerTable2(QuoteDetails quoteDetails) throws DocumentException {
        PdfPTable innerTable2 = new PdfPTable(3);
        innerTable2.setSpacingBefore(50);
        innerTable2.setSplitLate(false);
        innerTable2.setWidthPercentage(100);
        // Changes for AMS-450
        innerTable2.setWidths(new float[] {5, 2, 2});
        PdfPCell emptyCell = new PdfPCell();
        emptyCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell quotationNumberTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTATIONNUMBER, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        quotationNumberTextCell.setBorder(PdfPCell.NO_BORDER);
        quotationNumberTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        PdfPCell quotationNumberCell = new PdfPCell(new Phrase(quoteDetails.getQuoteNumber(), new Font(condensedregularBaseFont, 9)));
        quotationNumberCell.setBorder(PdfPCell.NO_BORDER);
        quotationNumberCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

        PdfPCell quotationDateTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QUOTAIONDATE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        quotationDateTextCell.setBorder(PdfPCell.NO_BORDER);
        quotationDateTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        PdfPCell quotationDateCell = new PdfPCell(new Phrase(quoteDetails.getQuoteDate(), new Font(condensedregularBaseFont, 9)));
        quotationDateCell.setBorder(PdfPCell.NO_BORDER);
        quotationDateCell.setHorizontalAlignment(Element.ALIGN_RIGHT);

        innerTable2.addCell(emptyCell);
        innerTable2.addCell(quotationNumberTextCell);
        innerTable2.addCell(quotationNumberCell);
        innerTable2.addCell(emptyCell);
        innerTable2.addCell(quotationDateTextCell);
        innerTable2.addCell(quotationDateCell);
        return innerTable2;
    }

    /**
     * Adds product details section header.
     * 
     * @return
     */
    private PdfPTable getProductDetailsHeader() {
        PdfPTable productDetailsHeader = new PdfPTable(1);
        productDetailsHeader.setSplitLate(false);
        productDetailsHeader.setWidthPercentage(100);
        productDetailsHeader.setSpacingBefore(20);
        PdfPCell productDetailsHeaderCell1 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_PDTDETAILS, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        productDetailsHeaderCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        productDetailsHeaderCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        productDetailsHeaderCell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
        productDetailsHeaderCell1.setBorder(PdfPCell.NO_BORDER);
        productDetailsHeaderCell1.setFixedHeight(30);
        productDetailsHeader.addCell(productDetailsHeaderCell1);
        return productDetailsHeader;
    }

    /**
     * Adds product details table header and product details to the table.
     * 
     * @param quoteDetails
     * @return
     * @throws DocumentException
     */
    private PdfPTable getInnerTable3(QuoteDetails quoteDetails) throws DocumentException {
        /* DCCOM-3063 - Start */
        String quoteCurrency = quoteDetails.getCurrency();
        PdfPTable innerTable3 = null;
        if (StringUtils.isNotBlank(quoteCurrency) && "CNY".equals(quoteCurrency)) {
            innerTable3 = new PdfPTable(7);
        } else {
            innerTable3 = new PdfPTable(8);
        }
        innerTable3.setSplitLate(false);
        innerTable3.setWidthPercentage(100);
        innerTable3.setSpacingBefore(5);
        if (StringUtils.isNotBlank(quoteCurrency) && "CNY".equals(quoteCurrency)) {
            innerTable3.setWidths(new float[] {4, 24, 40, 6, 16, 18, 16});
        } else {
            innerTable3.setWidths(new float[] {4, 24, 40, 6, 16, 16, 16, 16});
        }
        /* DCCOM-3063 - End */

        PdfPCell innerTable3Cell1 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_ID, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        innerTable3Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell1.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable3Cell1.setFixedHeight(30);

        PdfPCell innerTable3Cell2 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_PRODUCT, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        innerTable3Cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable3Cell2.setFixedHeight(30);

        PdfPCell innerTable3Cell3 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_DESC, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
        innerTable3Cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell3.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);

        PdfPCell innerTable3Cell4 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_QTY, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
        innerTable3Cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell4.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell4.setBorder(PdfPCell.NO_BORDER);

        PdfPCell innerTable3Cell5 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_LISTPRICE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
        innerTable3Cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell5.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell5.setBorder(PdfPCell.NO_BORDER);

        PdfPCell innerTable3Cell6 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_DISCOUNT, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
        innerTable3Cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell6.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell6.setBorder(PdfPCell.NO_BORDER);

        PdfPCell innerTable3Cell7 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_NETPRICE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));
        innerTable3Cell7.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell7.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell7.setBorder(PdfPCell.NO_BORDER);

        PdfPCell innerTable3Cell8 = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_EXTDNETPRICE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL), new Font(condensedboldeBaseFont, 9)));

        innerTable3Cell8.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable3Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell8.setBackgroundColor(BaseColor.LIGHT_GRAY);
        innerTable3Cell8.setBorder(PdfPCell.NO_BORDER);

        innerTable3.addCell(innerTable3Cell1);
        innerTable3.addCell(innerTable3Cell2);
        innerTable3.addCell(innerTable3Cell3);
        innerTable3.addCell(innerTable3Cell4);
        innerTable3.addCell(innerTable3Cell5);
        /* DCCOM-3063 - Start */
        if (!(StringUtils.isNotBlank(quoteCurrency) && "CNY".equals(quoteCurrency))) {
            innerTable3.addCell(innerTable3Cell6);
        }
        /* DCCOM-3063 - End */
        innerTable3.addCell(innerTable3Cell7);
        innerTable3.addCell(innerTable3Cell8);
        List<LineItem> quoteLineItems = quoteDetails.getItems();
        /* DCCOM-3063 - Start */
        for (int i = 1; i <= quoteLineItems.size(); i++) {
            addProductDetailCells(innerTable3, i, quoteLineItems.get(i - 1), quoteCurrency);
        }
        /* DCCOM-3063 - End */
        return innerTable3;
    }

    /**
     * Adds individual product details to the table.
     * 
     * @param table
     * @param id
     * @param lineItem
     */
    private void addProductDetailCells(PdfPTable table, int id, LineItem lineItem, String pQuoteCurrency) {
        Locale currencyLocale = Locale.US;

        if(getCurrencyCodeToLocaleMap().containsKey(pQuoteCurrency)){
            currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(pQuoteCurrency));
        }

        if (lineItem != null) {
            int paddingValue = 10;
            PdfPCell idCell = new PdfPCell(new Phrase(String.valueOf(id), new Font(condensedregularBaseFont, 9)));
            idCell.setPaddingTop(paddingValue);
            idCell.setBorder(PdfPCell.NO_BORDER);
            idCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            Phrase partNumberPhrase = new Phrase(lineItem.getCatId(), new Font(condensedregularBaseFont, 9));

            if (lineItem.getDesignDetails() != null && StringUtils.isNotBlank(lineItem.getDesignDetails().getDesignId())) {
                partNumberPhrase.add(new Phrase(new Chunk(LscaQuoteConstants.NEWLINE + lineItem.getDesignDetails().getDesignId(), new Font(condensedregularBaseFont, 9))));
            }

            PdfPCell productCell = new PdfPCell(partNumberPhrase);
            productCell.setBorder(PdfPCell.NO_BORDER);
            productCell.setPaddingTop(paddingValue);
            productCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

            Phrase productPhrase = new Phrase(
                    new Chunk(String.valueOf(lineItem.getProductName()), new Font(condensedregularBaseFont, 9)));

            if (lineItem.getDesignDetails() != null && StringUtils.isNotBlank(lineItem.getDesignDetails().getDescription())) {
                productPhrase.add(new Phrase(new Chunk(LscaQuoteConstants.NEWLINE + lineItem.getDesignDetails().getDescription(), new Font(condensedregularBaseFont, 9))));
            }

            //DCCOM-3107 - Ready To Use Quote Print - Show Discount - Start		
            double ya9DiscountAmt = lineItem.getYa9Discount();
            if (ya9DiscountAmt < 0.0) {
                ya9DiscountAmt = Math.abs(ya9DiscountAmt);
                productPhrase.add(new Phrase(new Chunk(
                        LscaQuoteConstants.NEWLINE + getErrorHandler().getFormattedErrorMessage(
                                LscaQuoteConstants.PDF_YA9_DISCOUNT_STRING, new Object[] { ya9DiscountAmt, pQuoteCurrency },
                                LscaQuoteConstants.LSCA_QUOTE_LABEL),
                        new Font(condensedregularBaseFont, 9, Font.ITALIC))));			
            }
            //DCCOM-3107 - Ready To Use Quote Print - Show Discount - End		
            PdfPCell productDescriptionCell = new PdfPCell(productPhrase);
            productDescriptionCell.setBorder(PdfPCell.NO_BORDER);
            productDescriptionCell.setPaddingTop(paddingValue);
            productDescriptionCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell qtyCell = new PdfPCell(
                    new Phrase(String.valueOf(lineItem.getReqQuantity()), new Font(condensedregularBaseFont, 9)));
            qtyCell.setBorder(PdfPCell.NO_BORDER);
            qtyCell.setPaddingTop(paddingValue);
            qtyCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell unitListPriceCell = new PdfPCell(
                    new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(lineItem.getListPrice(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
            unitListPriceCell.setBorder(PdfPCell.NO_BORDER);
            unitListPriceCell.setPaddingTop(paddingValue);
            unitListPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell unitDiscountCell = new PdfPCell(
                    new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(lineItem.getDiscount(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
            unitDiscountCell.setBorder(PdfPCell.NO_BORDER);
            unitDiscountCell.setPaddingTop(paddingValue);
            unitDiscountCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell unitNetPriceCell = new PdfPCell(
                    new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(lineItem.getUnitPrice(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
            unitNetPriceCell.setBorder(PdfPCell.NO_BORDER);
            unitNetPriceCell.setPaddingTop(paddingValue);
            unitNetPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            PdfPCell extendedNetPriceCell = new PdfPCell(
                    new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(lineItem.getYourPrice(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
            extendedNetPriceCell.setBorder(PdfPCell.NO_BORDER);
            extendedNetPriceCell.setPaddingTop(paddingValue);
            extendedNetPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell emptyCell = new PdfPCell();
            emptyCell.setBorder(PdfPCell.NO_BORDER);

            PdfPCell emptyCellW5CS = new PdfPCell();
            emptyCellW5CS.setColspan(5);
            emptyCellW5CS.setBorder(PdfPCell.NO_BORDER);

            table.addCell(idCell);
            table.addCell(productCell);
            table.addCell(productDescriptionCell);
            // table.addCell(ya9DiscountAmountCell);
            table.addCell(qtyCell);
            table.addCell(unitListPriceCell);
            /* DCCOM-3063 - Start */
            if (!(StringUtils.isNotBlank(pQuoteCurrency) && "CNY".equals(pQuoteCurrency))) {
                table.addCell(unitDiscountCell);
            }
            /* DCCOM-3063 - End */
            table.addCell(unitNetPriceCell);
            table.addCell(extendedNetPriceCell);
        }

    }

    /**
     * Adds order details to the PDF.
     * 
     * @param quoteDetails
     * @return
     * @throws DocumentException
     */
    private PdfPTable getOrderDetailTable(QuoteDetails quoteDetails) throws DocumentException {
    	Locale currencyLocale = Locale.US;

		if(getCurrencyCodeToLocaleMap().containsKey(quoteDetails.getCurrency())){
			currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(quoteDetails.getCurrency()));
		}
        String currnecyPhrase = new StringBuffer(" (").append(quoteDetails.getCurrency()).append(")").toString();
        PdfPTable orderDetialsTable = new PdfPTable(3);
        orderDetialsTable.setSplitLate(true);
        orderDetialsTable.setWidthPercentage(100);
        orderDetialsTable.setSpacingBefore(50);
        orderDetialsTable.setWidths(new float[] {6,3, 1});
        
      
        PdfPCell emptyCell = new PdfPCell();
        emptyCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell totalListPriceTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TOTALLISTPRICE, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));

        totalListPriceTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalListPriceTextCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell totalListPriceCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getTotalListPrice(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        totalListPriceCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalListPriceCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell totalDiscountTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TOTALDISCOUNT, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));

        totalDiscountTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalDiscountTextCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell totalDiscountCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getTotalDiscount(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        totalDiscountCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalDiscountCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell subTotalTextCell;
        if (quoteDetails.getCurrency().equalsIgnoreCase(LscaQuoteConstants.CHINA_CURRENCY)) {
            subTotalTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_SUBTOTALWITHTAX, new Object[] {}, 
                    LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));
        } else {
            subTotalTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_SUBTOTAL, new Object[] {}, 
                    LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));
        }
        subTotalTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        subTotalTextCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell subTotalCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getQuotationSubtotal(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        subTotalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        subTotalCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell shippingAndHandlingTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_SHIPPING, new Object[] {}, 
                    LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));
        
        	shippingAndHandlingTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            shippingAndHandlingTextCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell shippingAndHandlingCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getTotalShippingCharges(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        shippingAndHandlingCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        shippingAndHandlingCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell totalTaxTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TAX, new Object[] {}, 
                LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));

        totalTaxTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalTaxTextCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell totalTaxCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getTotalTax(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        totalTaxCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        totalTaxCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell quotationTotalTextCell;
        if (quoteDetails.getCurrency().equalsIgnoreCase(LscaQuoteConstants.CHINA_CURRENCY)) {
            quotationTotalTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TOTALWITHTAX, new Object[] {}, 
                    LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));
        } else {
            quotationTotalTextCell = new PdfPCell(new Phrase(getErrorHandler().getFormattedErrorMessage(LscaQuoteConstants.PDF_TOTAL, new Object[] {}, 
                    LscaQuoteConstants.LSCA_QUOTE_LABEL) + currnecyPhrase, new Font(condensedregularBaseFont, 9)));
        }

        quotationTotalTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        quotationTotalTextCell.setBorder(PdfPCell.NO_BORDER);
        PdfPCell quotationTotalCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(quoteDetails.getQuotationTotal(), currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        quotationTotalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        quotationTotalCell.setBorder(PdfPCell.NO_BORDER);

        if (quoteDetails.getCurrency().equalsIgnoreCase(LscaQuoteConstants.CHINA_CURRENCY)) {
        	orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(subTotalTextCell);
            orderDetialsTable.addCell(subTotalCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(shippingAndHandlingTextCell);
            orderDetialsTable.addCell(shippingAndHandlingCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(quotationTotalTextCell);
            orderDetialsTable.addCell(quotationTotalCell);
            //Start-AMS-477 Update Mexico Quote PDF
        } else if (StringUtils.isNotBlank(quoteDetails.getSalesOrg()) && quoteDetails.getSalesOrg().equalsIgnoreCase("04MX")) { 
        	orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalListPriceTextCell);
            orderDetialsTable.addCell(totalListPriceCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalDiscountTextCell);
            orderDetialsTable.addCell(totalDiscountCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(subTotalTextCell);
            orderDetialsTable.addCell(subTotalCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalTaxTextCell);
            orderDetialsTable.addCell(totalTaxCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(quotationTotalTextCell);
            orderDetialsTable.addCell(quotationTotalCell);
          //End-AMS-477 Update Mexico Quote PDF
        } else {
        	orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalListPriceTextCell);
            orderDetialsTable.addCell(totalListPriceCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalDiscountTextCell);
            orderDetialsTable.addCell(totalDiscountCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(subTotalTextCell);
            orderDetialsTable.addCell(subTotalCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(shippingAndHandlingTextCell);
            orderDetialsTable.addCell(shippingAndHandlingCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(totalTaxTextCell);
            orderDetialsTable.addCell(totalTaxCell);
            orderDetialsTable.addCell(emptyCell);
            orderDetialsTable.addCell(quotationTotalTextCell);
            orderDetialsTable.addCell(quotationTotalCell);
        }

        return orderDetialsTable;
    }

    /**
     * Returns font per locale
     * 
     * @param font
     * @param locale
     * @return
     * @throws DocumentException
     * @throws IOException
     */
    public BaseFont getRoboFont(String font, Locale locale, String salesOrg) throws DocumentException, IOException {
        BaseFont robotoFont = BaseFont.createFont(font, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        if (null != locale) {
			vlogDebug("getRoboFont:: Locale: {0} salesOrg: {1} ", locale.toString(), salesOrg);
            if ((StringUtils.isNotBlank(salesOrg) && getConfiguration().getChinaSalesOrgs().contains(salesOrg)) || locale.toString().equals(Locale.CHINA.toString())) {
                robotoFont = BaseFont.createFont(CHINESE_FONT_STD, CHINESE_ENCODING, BaseFont.NOT_EMBEDDED);
            } else if (locale.toString().equals(Locale.KOREA.toString())) {
                robotoFont = BaseFont.createFont(KOREAN_FONT_STD_MEDIUM, KOREAN_ENCODING, BaseFont.NOT_EMBEDDED);
            } else if (locale.toString().equals(Locale.JAPAN.toString())) {
                robotoFont = BaseFont.createFont(JAPANESE_FONT_REGULAR, JAPANESE_ENCODING, BaseFont.NOT_EMBEDDED);
            }
        }
        return robotoFont;
    }

    /**
     * Inner class to add background for Quotation header cell.
     *
     */
    class CellBackground implements PdfPCellEvent {
        @Override
        public void cellLayout(PdfPCell cell, Rectangle rect, PdfContentByte[] canvas) {
            PdfContentByte cb = canvas[PdfPTable.BACKGROUNDCANVAS];
            cb.roundRectangle(rect.getLeft() + 1.5f, rect.getBottom() + 1.5f, rect.getWidth() - 3, rect.getHeight() - 3, 4);
            cb.setCMYKColorFill(100, 25, 0, 0);
            cb.fill();
        }
    }
    
    public void addStampImageOnPDF(PdfReader reader, PdfStamper stamper, String finalImagePath, String userCountry) throws MalformedURLException, IOException, DocumentException {
        vlogDebug("adding stamp image to PDF for country {0}", userCountry);
        String ImageScalesize = "";
        String ImageHorizontalPosition = "";
        Image image = Image.getInstance(finalImagePath);
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
            PdfContentByte contentByte = stamper.getOverContent(i);
            PdfReaderContentParser parser = new PdfReaderContentParser(reader);
            TextMarginFinder finder = parser.processContent(i, new TextMarginFinder());
            vlogDebug("adding image for page {0}", i);
            // determine image position based on country
            if (getImageHorizontalPositionMap().containsKey(userCountry) && getImageScaleSizeMap().containsKey(userCountry)) {
                ImageScalesize = getImageScaleSizeMap().get(userCountry);
                ImageHorizontalPosition = getImageHorizontalPositionMap().get(userCountry);
            }
            image.scalePercent(Integer.parseInt(ImageScalesize));
            vlogInfo("X axis " + finder.getLlx() + " actual x axis position " + Integer.parseInt(ImageHorizontalPosition) + " Y axis " + finder.getLly());
            image.setAbsolutePosition(Integer.parseInt(ImageHorizontalPosition), finder.getLly());
            contentByte.addImage(image);
        }

    }

    /**
     * Gets the value of property contactUsURL
     *
     * @return the value of property contactUsURL
     */
    public String getContactUsURL() {
        return contactUsURL;
    }
    /**
     * Sets the value of property contactUsURL with value pContactUsURL
     *
     * @param pContactUsURL
     *            for setting property contactUsURL
     */
    public void setContactUsURL(String pContactUsURL) {
        contactUsURL = pContactUsURL;
    }

    /**
     * Gets the value of property agilentLogoImageName
     *
     * @return the value of property agilentLogoImageName
     */
    public String getAgilentLogoImageName() {
        return mAgilentLogoImageName;
    }
    /**
     * Sets the value of property agilentLogoImageName with value pAgilentLogoImageName
     *
     * @param pAgilentLogoImageName
     *            for setting property agilentLogoImageName
     */
    public void setAgilentLogoImageName(String pAgilentLogoImageName) {
        mAgilentLogoImageName = pAgilentLogoImageName;
    }

    /**
     * Gets the value of property errorHandler
     *
     * @return the value of property errorHandler
     */
    public ErrorHandlerImpl getErrorHandler() {
        return mErrorHandler;
    }
    /**
     * Sets the value of property errorHandler with value pErrorHandler
     *
     * @param pErrorHandler
     *            for setting property errorHandler
     */
    public void setErrorHandler(ErrorHandlerImpl pErrorHandler) {
        mErrorHandler = pErrorHandler;
    }

    /**
     * Gets the value of property chinaContactUsURL
     *
     * @return the value of property chinaContactUsURL
     */
    public String getChinaContactUsURL() {
        return chinaContactUsURL;
    }
    /**
     * Sets the value of property chinaContactUsURL with value pChinaContactUsURL
     *
     * @param pChinaContactUsURL
     *            for setting property chinaContactUsURL
     */
    public void setChinaContactUsURL(String pChinaContactUsURL) {
        chinaContactUsURL = pChinaContactUsURL;
    }
    /**
     * Gets the value of property maxicoContactUsURL
     *
     * @return the value of property maxicoContactUsURL
     */
    public String getMaxicoContactUsURL() {
        return maxicoContactUsURL;
    }
    /**
     * Sets the value of property maxicoContactUsURL with value pMaxicoContactUsURL
     *
     * @param pMaxicoContactUsURL
     *            for setting property maxicoContactUsURL
     */
    public void setMaxicoContactUsURL(String pMaxicoContactUsURL) {
        maxicoContactUsURL = pMaxicoContactUsURL;
    }

	/**
	 * @return the pdfAddressLabelMap
	 */
	public Map<String, String> getPdfAddressLabelMap() {
		return pdfAddressLabelMap;
	}

	/**
	 * @param pdfAddressLabelMap the pdfAddressLabelMap to set
	 */
	public void setPdfAddressLabelMap(Map<String, String> pdfAddressLabelMap) {
		this.pdfAddressLabelMap = pdfAddressLabelMap;
	}

	/**
	 * @return the pdfContactLabelMap
	 */
	public Map<String, String> getPdfContactLabelMap() {
		return pdfContactLabelMap;
	}

	/**
	 * @param pdfContactLabelMap the pdfContactLabelMap to set
	 */
	public void setPdfContactLabelMap(Map<String, String> pdfContactLabelMap) {
		this.pdfContactLabelMap = pdfContactLabelMap;
	}

	/**
     * Gets the value of currencyCodeToLocaleMap
     *
     * @return returns the property currencyCodeToLocaleMap
     */
    public Map<String, String> getCurrencyCodeToLocaleMap() {
        return mCurrencyCodeToLocaleMap;
    }

    /**
     * Sets the value of property currencyCodeToLocaleMap with value currencyCodeToLocaleMap
     *
     * @param currencyCodeToLocaleMap
     *            the currencyCodeToLocaleMap to set
     */
    public void setCurrencyCodeToLocaleMap( Map<String, String> currencyCodeToLocaleMap) {
        mCurrencyCodeToLocaleMap = currencyCodeToLocaleMap;
    }
     
    public Map<String, String> getImageHorizontalPositionMap() {
        return mImageHorizontalPositionMap;
    }

    public void setImageHorizontalPositionMap(Map<String, String> pImageHorizontalPositionMap) {
        mImageHorizontalPositionMap = pImageHorizontalPositionMap;
    }

    public Map<String, String> getImageScaleSizeMap() {
        return mImageScaleSizeMap;
    }

    public void setImageScaleSizeMap(Map<String, String> pImageScaleSizeMap) {
        mImageScaleSizeMap = pImageScaleSizeMap;
    }
    
    /**
     * Gets the value of property configuration
     *
     * @return the value of property configuration
     */
    public AgilentConfiguration getConfiguration() {
        return mConfiguration;
    }
    /**
     * Sets the value of property configuration with value pConfiguration
     *
     * @param pConfiguration
     *            for setting property configuration
     */
    public void setConfiguration(AgilentConfiguration pConfiguration) {
        mConfiguration = pConfiguration;
    }
	
	/**
     * Gets the value of customContactFmtSalesOrgList
     * 
     * @return the property customContactFmtSalesOrgList
     */
	public List<String> getCustomContactFmtSalesOrgList() {
		return customContactFmtSalesOrgList;
	}

	 /**
     * Sets the value of property customContactFmtSalesOrgList with value customContactFmtSalesOrgList
     * 
     * @param customContactFmtSalesOrgList
     *            the customContactFmtSalesOrgList to set
     */
	public void setCustomContactFmtSalesOrgList(List<String> customContactFmtSalesOrgList) {
		this.customContactFmtSalesOrgList = customContactFmtSalesOrgList;
	}

	public Map<String, String> getCustomCountryMap() {
        return mCustomCountryMap;
    }

    public void setCustomCountryMap(Map<String, String> pCustomCountryMap) {
        mCustomCountryMap = pCustomCountryMap;
    }
    public AgilentConfigurationSecond getConfigurationSecond() {
 		return configurationSecond;
 	}
 	public void setConfigurationSecond(AgilentConfigurationSecond configurationSecond) {
 		this.configurationSecond = configurationSecond;
 	}
 	public ChinaConfiguration getChinaConfiguration() {
 		return mChinaConfiguration;
 	}

 	public void setChinaConfiguration(ChinaConfiguration pChinaConfiguration) {
 		this.mChinaConfiguration = pChinaConfiguration;
 	}
}
