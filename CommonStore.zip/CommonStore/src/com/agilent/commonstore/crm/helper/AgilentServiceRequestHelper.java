package com.agilent.commonstore.crm.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.client.ClientProtocolException;

import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.profile.crm.LynxConstants;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.agilent.commonstore.crm.bean.ServiceRequestBean;

import atg.nucleus.GenericService;
/**
 * @author avneetkaur.m
 * @project Agilent.ServiceRequest
 * 
 */

public class AgilentServiceRequestHelper extends GenericService {

	private SAPCRMAPIManager sapcrmapiManager;
	private ErrorHandlerImpl errorHandler;
	
	public List<ServiceRequestBean> fetchServiceRequestDetails(String sapContactId){
		ServiceRequestBean serviceRequestBean = null;
		List<ServiceRequestBean> serviceRequestBeanList = new ArrayList<ServiceRequestBean>();
		
		try {
			 Map<String, Object> serviceRequestDetails = getSapcrmapiManager().getRequestsFromSAPCRM(sapContactId);
			 if(serviceRequestDetails!=null && serviceRequestDetails.size()>0){
			 List<Map<String, Object>> serviceRequestDetailsList = (List<Map<String, Object>>) serviceRequestDetails.get(LynxConstants.RESULTS);
			 
				 if(serviceRequestDetailsList!=null && serviceRequestDetailsList.size()>0){
				 for (Map<String, Object> requestInfo : serviceRequestDetailsList) {
					 serviceRequestBean = new ServiceRequestBean();
					 serviceRequestBean.setCompanyName((String) requestInfo.get(LynxConstants.CONTACT_COMPANYNAME));
					 serviceRequestBean.setSiteAddress((String) requestInfo.get(LynxConstants.SITE_ADDRESS));
					 serviceRequestBean.setModelNo((String) requestInfo.get(LynxConstants.QUOTE_COMP_MOD));
					 serviceRequestBean.setCustomerTag((String) requestInfo.get(LynxConstants.CUSTOMER_TAG));
					 serviceRequestBean.setServiceReqNo((String) requestInfo.get(LynxConstants.SERVICE_REQ));
					 serviceRequestBean.setServiceOrderNo((String) requestInfo.get(LynxConstants.SERVICE_ORDER));
					 serviceRequestBean.setContactName((String) requestInfo.get(LynxConstants.CNTACT_NAME));
					 serviceRequestBean.setSrNotes((String) requestInfo.get(LynxConstants.SR_NOTES));
					 serviceRequestBean.setSrCreatedDate((String) requestInfo.get(LynxConstants.SR_CREATED_DATE));
					 serviceRequestBean.setServiceEngineer((String) requestInfo.get(LynxConstants.SERVICE_ENGINEER));
					 if(!requestInfo.get(LynxConstants.COMMITTED_DATE).equals(LynxConstants.EGS_DATE_BLANK_DATE))
					 serviceRequestBean.setCommittedDate((String) requestInfo.get(LynxConstants.COMMITTED_DATE));
					 serviceRequestBeanList.add(serviceRequestBean);	
				 }
				 vlogDebug("50 Service Requests for the current logged in user {0}", serviceRequestBeanList);
				}
			    else{
					vlogInfo("No data found from transaction Id {0}", sapContactId);
					serviceRequestBean=new ServiceRequestBean();
					//serviceRequestBean.setErrorMsg(LynxConstants.ERROR_MSG_NO_DATA);
					serviceRequestBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
					serviceRequestBeanList.add(serviceRequestBean);
				  }
		     }
		     else{
			  vlogInfo("No data found from transaction Id {0}", sapContactId);
			  serviceRequestBean=new ServiceRequestBean();
			  //serviceRequestBean.setErrorMsg(LynxConstants.ERROR_MSG_NO_DATA);
			  serviceRequestBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
			  serviceRequestBeanList.add(serviceRequestBean);
		     }
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceRequestBeanList;
	}

	public ServiceRequestBean fetchSearchRequestDetails(String searchRequestNo, String sapContactID){
		ServiceRequestBean serviceRequestBean = null;
		
		try {
			 Map<String, Object> searchRequestDetails = getSapcrmapiManager().getSearchRequestFromSAPCRM(searchRequestNo, sapContactID);
			 if(searchRequestDetails!=null && searchRequestDetails.size()>0){
			 List<Map<String, Object>> searchRequestDetailsList = (List<Map<String, Object>>) searchRequestDetails.get(LynxConstants.RESULTS);
			 
				 if(searchRequestDetailsList!=null && searchRequestDetailsList.size()>0){
				 for (Map<String, Object> searchRequestResult : searchRequestDetailsList) {
					 serviceRequestBean = new ServiceRequestBean();
					 serviceRequestBean.setCompanyName((String) searchRequestResult.get(LynxConstants.CONTACT_COMPANYNAME));
					 serviceRequestBean.setSiteAddress((String) searchRequestResult.get(LynxConstants.SITE_ADDRESS));
					 serviceRequestBean.setModelNo((String) searchRequestResult.get(LynxConstants.QUOTE_COMP_MOD));
					 serviceRequestBean.setCustomerTag((String) searchRequestResult.get(LynxConstants.CUSTOMER_TAG));
					 serviceRequestBean.setServiceReqNo((String) searchRequestResult.get(LynxConstants.SERVICE_REQ));
					 serviceRequestBean.setServiceOrderNo((String) searchRequestResult.get(LynxConstants.SERVICE_ORDER));
					 serviceRequestBean.setContactName((String) searchRequestResult.get(LynxConstants.CNTACT_NAME));
					 serviceRequestBean.setSrNotes((String) searchRequestResult.get(LynxConstants.SR_NOTES));
					 serviceRequestBean.setSrCreatedDate((String) searchRequestResult.get(LynxConstants.SR_CREATED_DATE));
					 serviceRequestBean.setServiceEngineer((String) searchRequestResult.get(LynxConstants.SERVICE_ENGINEER));
					 if(!searchRequestResult.get(LynxConstants.COMMITTED_DATE).equals(LynxConstants.EGS_DATE_BLANK_DATE))
					 serviceRequestBean.setCommittedDate((String) searchRequestResult.get(LynxConstants.COMMITTED_DATE));
				  }	 
				 vlogDebug("Search result for the current logged in user based on Service Request Number {0}", serviceRequestBean);
				 }
				 else{
					 vlogInfo("No data found from transaction Id {0}", sapContactID);
					 serviceRequestBean=new ServiceRequestBean();
					 //serviceRequestBean.setErrorMsg(LynxConstants.ERROR_MSG_NO_DATA);
					 serviceRequestBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
				 }
			}
			 else{
				 vlogInfo("No data found from transaction Id {0}", sapContactID);
				 serviceRequestBean=new ServiceRequestBean();
				 //serviceRequestBean.setErrorMsg(LynxConstants.ERROR_MSG_NO_DATA);
				 serviceRequestBean.setErrorMsg(getErrorHandler().getFormattedErrorMessage(LynxConstants.ERROR_MSG_NO_DATA, new Object[] {}, LynxConstants.LYNX_CONTRACT_SERVICES_LABEL));
			 }
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceRequestBean;
	}



	public SAPCRMAPIManager getSapcrmapiManager() {
		return sapcrmapiManager;
	}

	public void setSapcrmapiManager(SAPCRMAPIManager sapcrmapiManager) {
		this.sapcrmapiManager = sapcrmapiManager;
	}
	/**
	 * @return the errorHandler
	 */
	public ErrorHandlerImpl getErrorHandler() {
		return errorHandler;
	}

	/**
	 * @param errorHandler the errorHandler to set
	 */
	public void setErrorHandler(ErrorHandlerImpl errorHandler) {
		this.errorHandler = errorHandler;
	}

}