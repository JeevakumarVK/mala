package com.agilent.commonstore.crm.helper;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import javax.imageio.ImageIO;

import com.agilent.base.commerce.Constants;
import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.order.AgilentCommerceItem;
import com.agilent.base.commerce.order.AgilentHardGoodShippingGroup;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.order.AgilentOrderManager;
import com.agilent.base.commerce.order.AgilentOrderTools;
import com.agilent.base.commerce.order.PurchaseOrderPaymentGroup;
import com.agilent.base.common.helper.OrderManagerHelper;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.common.services.OrderDetails;
import com.agilent.base.common.services.SapFunctions;
import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.pricing.AgilentItemPriceInfo;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.crm.LscaQuoteConstants;
import com.agilent.datagrid.helper.DataGridRestHelper;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.parser.PdfReaderContentParser;
import com.itextpdf.text.pdf.parser.TextMarginFinder;

import atg.commerce.order.CommerceItem;
import atg.commerce.order.HardgoodShippingGroup;
import atg.commerce.order.PaymentGroup;
import atg.commerce.order.ShippingGroup;
import atg.core.util.ContactInfo;
import atg.core.util.StringUtils;
import atg.json.JSONException;
import atg.nucleus.GenericService;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;
import atg.servlet.RequestLocale;

/**
 * This Helper class is used for handling China order PDF download functionality.
 */
/**
 * @author avneetkaur.m
 *
 */
public class PdfChinaOrderDownloadHelper extends GenericService {
	
	public static final String VACUUM_PL = "VacuumPL";
    public static final String INSTRUMENT_PL= "InstrumentPL";
    public static final String SERVICE_PL = "ServicePL";
    public static final String XF_PL = "XfPL";
    private int paraCount=0;
    public static final String DGG_AND_LSAG="DGGandLSAG";
    public static final String DGG="DGG";
    public static final String LSAG="LSAG";
    /**
     * The mAgilentLogoImageName.
     */
    private String mAgilentLogoImageName;
    
    /**
     * The agilentLogo.
     */
    public String agilentLogo;
    
    /**
     * The chinaContactUsURL.
     */
    public String chinaContactUsURL;
    
    /**
     * The CHINESE_FONT_LIGHT.
     */
    public static String CHINESE_FONT_LIGHT = "STSong-Light";
    
    /**
     * The CHINESE_FONT_STD.
     */
    public static String CHINESE_FONT_STD = "STSongStd-Light";
    
    /**
     * The CHINESE_ENCODING.
     */
    public static String CHINESE_ENCODING = "UniGB-UCS2-H";
    
    /**
     * The condensedregularBaseFont.
     */
    public BaseFont condensedregularBaseFont;
    
    /**
     * The mCurrencyCodeToLocaleMap.
     */
    private Map<String, String> mCurrencyCodeToLocaleMap;
    
    /**
     * The imageHorizontalPosition.
     */
    private String imageHorizontalPosition;
    
    /**
     * The imageScaleSize.
     */
    private String imageScaleSize;
    
    /**
     * The imageVerticalPosition.
     */
    private String imageVerticalPosition;
    
    /**
     * The addressDetails.
     */
    public String addressDetails;
    
    /**
     * The contactDetails.
     */
    public String contactDetails;
    
    /**
     * The teleLabel.
     */
    public String teleLabel;
    
    /**
     * The faxLabel.
     */
    public String faxLabel;
    
    /**
     * The emailLabel.
     */
    public String emailLabel;
    
    /**
     * The webLabel.
     */
    public String webLabel;
    
    /**
	 * The salesOrderNumberKey.
	 */
	private String salesOrderNumberKey;

	/**
	 * The salesOrderDateKey.
	 */
	private String salesOrderDateKey;

	/**
	 * The poNumberKey.
	 */
	private String poNumberKey;
	
	/**
	 * The currencyKey.
	 */
	private String currencyKey;
	
	/**
	 * The currencyValue.
	 */
	private String currencyValue;

	/**
	 * The soldToAccountNameKey.
	 */
	private String soldToAccountNameKey;

	/**
	 * The soldToAccountAddressKey.
	 */
	private String soldToAccountAddressKey;

	/**
	 * The invoiceContactPersonNameKey.
	 */
	private String invoiceContactPersonNameKey;

	/**
	 * The invoiceContactPersonPhoneKey.
	 */
	private String invoiceContactPersonPhoneKey;

	/**
	 * The invoiceAddressKey.
	 */
	private String invoiceAddressKey;

	/**
	 * The customerBankNameKey.
	 */
	private String customerBankNameKey;

	/**
	 * The customerBankAccountKey.
	 */
	private String customerBankAccountKey;

	/**
	 * The customerTaxCodeKey.
	 */
	private String customerTaxCodeKey;
	private String customerInvoiceTypeSpecialEn;
	private String customerInvoiceTypeSpecialZh;
	private String customerInvoiceTypeNormalEn;
	private String customerInvoiceTypeNormalZh;

	/**
	 * The customerInvoiceTypeKey.
	 */
	private String customerInvoiceTypeKey;

	/**
	 * The salesRepresentativeNameKey.
	 */
	private String salesRepresentativeNameKey;

	/**
	 * The salesRepresentativePhoneKey.
	 */
	private String salesRepresentativePhoneKey;

	/**
	 * The salesRepresentativeMailKey.
	 */
	private String salesRepresentativeMailKey;

	/**
	 * The shipToAccountName.
	 */
	private String shipToAccountName;

	/**
	 * The shipToAccountAddress.
	 */
	private String shipToAccountAddress;

	/**
	 * The shippingContactPerson.
	 */
	private String shippingContactPerson;

	/**
	 * The shippingContactPersonPhone.
	 */
	private String shippingContactPersonPhone;

	/**
	 * The postalCode.
	 */
	private String postalCode;

	/**
	 * The mainHeading.
	 */
	private String mainHeading;
	
	/**
	 * The directInquiry.
	 */
	private String directInquiry;
	
	/**
	 * The supplierDetailsMap.
	 */
	private LinkedHashMap<String, String> supplierDetailsMap = new LinkedHashMap<String, String>();
	
	/**
	 * The lastLineText.
	 */
	private String lastLineText;
	
	/**
	 * The middleLineText.
	 */
	private String middleLineText;
	
	/**
	 * The paragraphOne.
	 */
	private String paragraphOne;
	
	/**
	 * The paragraphTwo.
	 */
	private String paragraphTwo;
	
	/**
	 * The paragraphThree.
	 */
	private String paragraphThree;
	
	/**
	 * The paragraphFour.
	 */
	private String paragraphFour;
	
	/**
	 * The paragraphFive.
	 */
	private String paragraphFive;
	
	/**
	 * The paragraphSix.
	 */
	private String paragraphSix;
	
	/**
	 * The paragraphSeven.
	 */
	private String paragraphSeven;
	
	/**
	 * The paragraphEight.
	 */
	private String paragraphEight;
	
	/**
	 * The paragraphNine.
	 */
	private String paragraphNine;
	
	/**
	 * The paragraphTen.
	 */
	private String paragraphTen;
	
	/**
	 * The paragraphEleven.
	 */
	private String paragraphEleven;
	
	/**
	 * The buyer; 
	 */
	private String buyer;
	
	/**
	 * The sellerKey. 
	 */
	private String sellerKey;
	
	/**
	 * The sellerValue. 
	 */
	private String sellerValue;
	/**
     * The sellerValue for 04C9. 
     */
    private String sellerValueForC9;
	/**
	 * The position. 
	 */
	private String position;
	
	/**
	 * The date. 
	 */
	private String date;
	
	/**
	 * The sealed.
	 */
	private String sealed;
	
	/**
	 * The lineNo.
	 */
	private String lineNo;
	
	/**
	 * The productNumber. 
	 */
	private String productNumber;
	
	/**
	 * The productDescEnglish. 
	 */
	private String productDescEnglish;
	
	/**
	 * The productDescChinese. 
	 */
	private String productDescChinese;
	
	/**
	 * The quantity. 
	 */
	private String quantity;
	
	/**
	 * The stockStatus. 
	 */
	private String stockStatus;
	
	/**
	 * The listPrice. 
	 */
	private String listPrice;
	
	/**
	 * The yourPrice. 
	 */
	private String yourPrice;
	
	/**
	 * The totalPrice. 
	 */
	private String totalPrice;
	
	/**
	 * The totalAmount. 
	 */
	private String totalAmount;
	
	/**
	 * The shippingHandling. 
	 */
	private String shippingHandling;
	
	/**
	 * The totalAmountWithTax. 
	 */
	private String totalAmountWithTax;
	
	/**
	 * The e16Heading. 
	 */
	private String e16Heading;

	/**
	 * The e16Paragraph. 
	 */
	private String e16Paragraph;
	
	/**
	 * The subHeadingOne. 
	 */
	private String subHeadingOne;
	
	/**
	 * The subParagraphOne. 
	 */
	private String subParagraphOne;
	
	/**
	 * The subHeadingTwo. 
	 */
	private String subHeadingTwo;
	
	/**
	 * The subParagraphTwo. 
	 */
	private String subParagraphTwo;
	
	/**
	 * The subHeadingThree. 
	 */
	private String subHeadingThree;
	
	/**
	 * The subParagraphThree. 
	 */
	private String subParagraphThree;
	
	/**
	 * The subHeadingFour. 
	 */
	private String subHeadingFour;
	
	/**
	 * The subParagraphFour. 
	 */
	private String subParagraphFour;
	
	/**
	 * The subHeadingFive. 
	 */
	private String subHeadingFive;
	
	/**
	 * The subParagraphFive. 
	 */
	private String subParagraphFive;
	
	/**
	 * The subHeadingSix. 
	 */
	private String subHeadingSix;
	
	/**
	 * The subParagraphSix. 
	 */
	private String subParagraphSix;
	
	/**
	 * The sapManager.
	 */
	private SapFunctions sapManager;
	//AMS-914 - Changes
	private String paymentTermLabel;
	private Repository mOrderRepository;
	private String mSapOrderRQL;
	//Fix for china pdf defects UAT-1091,1088,1185,1177
	private String paymentTermValue;
	private DataGridRestHelper mDataGridRestHelper;
	private String paymentTermValueSP;
	private String paymentTermValueNT1;
	private String paymentTermValueNT2;
	private String defaultLanguage;
	private String chineseLanguage;
	private AgilentOrderManager orderManager = null;
	private String mChinaTimeZone;
	private CountryUtils mCountryUtils;
	private String mAddressDetailsForC9;
	private String mContactDetailsForC9;
	private String mMainHeadingForC9;
	private String mInvoiceCustomerNameKey;
	private LinkedHashMap<String, String> mSupplierDetailsMap1ForC9 = new LinkedHashMap<String, String>();
	private LinkedHashMap<String, String> mSupplierDetailsMap2ForC9 = new LinkedHashMap<String, String>();
	private String mProductLineForC9;
	private String productLineForC9LSAG;
	private String mParagraphTwoForC9;
	private String paragraphTwoForC9Heading;
	private String paragraphTwoForC9LSAG;
	private String paragraphThreeForC9Heading;
	private String paragraphThreeForC9LSAG;
	private String mParagraphFiveForC9;
	private String paragraphFiveForCN;
	private String mParagraphSixForC9;
	private String paragraphSixForC9Heading;
	private String paragraphSixForC9LSAG;
	private String mParagraphSevenForC9;
	private String paragraphSevenForC9LSAG;
	private String paragraphSevenForC9DGGandLSAG;
	private String mSubPara1ForC9;
	private String mSubPara2ForC9;
	private String mSubPara3ForC9;
	private String mParagraphNineForC9;
	private String mParagraphFourForC9;
	private String mParagraphEightForC9;
	private String mParagraphTenForC9;
	private String mParagraphFourSub1ForC9;
	private String mParagraphFiveSub1ForC9;
	private String mParagraphFiveSub2ForC9;
	private String mParagraphEightSub1ForC9;
	private String mParagraphTenSub1ForC9;
	private String mParagraphTenSub2ForC9;
	private String mMiddleLineTextForC9;
	private String mImageScaleForC9;
	private String mParagraphTenSub3ForC9;
	public List<String> mSalesOrgListForRUO;
	private String mCopcEmailForChina;
    private OrderManagerHelper mOrderManagerHelper;
	   
		
	
	/**
	 * @return
	 */
	public OrderManagerHelper getOrderManagerHelper() {
		return mOrderManagerHelper;
	}


	/**
	 * @param mOrderManagerHelper
	 */
	public void setOrderManagerHelper(OrderManagerHelper mOrderManagerHelper) {
		this.mOrderManagerHelper = mOrderManagerHelper;
	}
	
	public CountryUtils getCountryUtils() {
			return mCountryUtils;
		}


		public void setCountryUtils(CountryUtils mCountryUtils) {
			this.mCountryUtils = mCountryUtils;
		}

	
	//DCCOM-21788 - Vacuum products
	private AgilentOrderTools mOrderTools;
	private String mVacuumProductContactNum;
	private String mProductLine;
	private AgilentCatalogTools mCatalogTools;
	private String mVacuumPL;
	private String mVacuumPLChinese;
	private String mServicePL;
	private String mServicePLChinese;
	private String mInstrumentPL;
	private String mInstrumentPLChinese;
	private String mSubHeadingSeven;
	private String mSubParagraphSeven;
	private String mXfPL;
	private String mXfPLChinese;
	private String mChinaHostName;
	private String mNonChinaHostName;
	private String mAttsHorizontalPosition;
	private String mAttsVerticalPosition;
	private String mImageScaleforConnectiveStamp;
	private String mAttsGenPL;
	private String productLineFor04C9LSAG;
	public List<String> mSalesOrgListForChina;
	private LinkedHashMap<String, String> mSupplierDetailsMap1ForCN = new LinkedHashMap<String, String>();
	private LinkedHashMap<String, String> mSupplierDetailsMap2ForCN = new LinkedHashMap<String, String>();
	private String mMiddleLineTextForCN;
	private String mMiddleLineTextForPL74;
	private String mParagraphTwoChina;
	private String mParagraphTwoChinaPL1;
	private String mParagraphTwoChinaPL2;
	private String mParagraphTwoChinaPL3;
	private String mParagraphFourForCN;
	private String mParagraphFourForPL1;
	private String mParagraphFourForPL2;
	private String mParagraphFourForPL3;
	private String mParagraphSevenForCN;
	private String mParagraphSevenForPL1;
	private String mParagraphSevenForPL2;
	private String mParagraphSevenForPL3;
	private Integer mCountForNewPage;
	private String mCustomerSpecialEinvoiceEn;
	private String mCustomerSpecialEinvoiceZh;
	private String mCustomerNormalPaperInvoiceEn;
	private String mCustomerNormalPaperInvoiceZh;
	private String mParagraphFourForPL5;
	private String mParagraphEightForCN;
	private String mParagraphNineForCN;
	private String mSubPara1ForCN;
	private String mSubPara2ForCN;
	private String mParagraphTenForCN;
	private String mParagraphThreeForCN;
	private String mConnectiveStampScaleSizeForCN;
	private String mImageScaleSizeForCN;
	
	
	
	
	
	
	
	
	/**
	 * @return the xfPL
	 */
	public String getXfPL() {
		return mXfPL;
	}


	/**
	 * @param xfPL the xfPL to set
	 */
	public void setXfPL(String xfPL) {
		this.mXfPL = xfPL;
	}


	/**
	 * @return the xfPLChinese
	 */
	public String getXfPLChinese() {
		return mXfPLChinese;
	}


	/**
	 * @param xfPLChinese the xfPLChinese to set
	 */
	public void setXfPLChinese(String xfPLChinese) {
		this.mXfPLChinese = xfPLChinese;
	}


	/**
	 * @return the subHeadingSeven
	 */
	public String getSubHeadingSeven() {
		return mSubHeadingSeven;
	}

	/**
	 * @param subHeadingSeven the subHeadingSeven to set
	 */
	public void setSubHeadingSeven(String subHeadingSeven) {
		this.mSubHeadingSeven = subHeadingSeven;
	}

	/**
	 * @return the subParagraphSeven
	 */
	public String getSubParagraphSeven() {
		return mSubParagraphSeven;
	}

	/**
	 * @param subParagraphSeven the subParagraphSeven to set
	 */
	public void setSubParagraphSeven(String subParagraphSeven) {
		this.mSubParagraphSeven = subParagraphSeven;
	}

	/**
	 * @return the vacuumPL
	 */
	public String getVacuumPL() {
		return mVacuumPL;
	}

	/**
	 * @param vacuumPL the vacuumPL to set
	 */
	public void setVacuumPL(String vacuumPL) {
		this.mVacuumPL = vacuumPL;
	}

	/**
	 * @return the vacuumPLChinese
	 */
	public String getVacuumPLChinese() {
		return mVacuumPLChinese;
	}

	/**
	 * @param vacuumPLChinese the vacuumPLChinese to set
	 */
	public void setVacuumPLChinese(String vacuumPLChinese) {
		this.mVacuumPLChinese = vacuumPLChinese;
	}

	/**
	 * @return the servicePL
	 */
	public String getServicePL() {
		return mServicePL;
	}

	/**
	 * @param servicePL the servicePL to set
	 */
	public void setServicePL(String servicePL) {
		this.mServicePL = servicePL;
	}

	/**
	 * @return the servicePLChinese
	 */
	public String getServicePLChinese() {
		return mServicePLChinese;
	}

	/**
	 * @param servicePLChinese the servicePLChinese to set
	 */
	public void setServicePLChinese(String servicePLChinese) {
		this.mServicePLChinese = servicePLChinese;
	}

	/**
	 * @return the instrumentPL
	 */
	public String getInstrumentPL() {
		return mInstrumentPL;
	}

	/**
	 * @param instrumentPL the instrumentPL to set
	 */
	public void setInstrumentPL(String instrumentPL) {
		this.mInstrumentPL = instrumentPL;
	}

	/**
	 * @return the instrumentPLChinese
	 */
	public String getInstrumentPLChinese() {
		return mInstrumentPLChinese;
	}

	/**
	 * @param instrumentPLChinese the instrumentPLChinese to set
	 */
	public void setInstrumentPLChinese(String instrumentPLChinese) {
		this.mInstrumentPLChinese = instrumentPLChinese;
	}

	/**
	 * @return the catalogTools
	 */
	public AgilentCatalogTools getCatalogTools() {
		return mCatalogTools;
	}

	/**
	 * @param catalogTools the catalogTools to set
	 */
	public void setCatalogTools(AgilentCatalogTools catalogTools) {
		this.mCatalogTools = catalogTools;
	}

	/**
	 * @return the productLine
	 */
	public String getProductLine() {
		return mProductLine;
	}

	/**
	 * @param productLine the productLine to set
	 */
	public void setProductLine(String productLine) {
		this.mProductLine = productLine;
	}

	/**
	 * @return the vacuumProductContactNum
	 */
	public String getVacuumProductContactNum() {
		return mVacuumProductContactNum;
	}

	/**
	 * @param vacuumProductContactNum the vaccumProductContactNum to set
	 */
	public void setVacuumProductContactNum(String vacuumProductContactNum) {
		this.mVacuumProductContactNum = vacuumProductContactNum;
	}

	/**
	 * @return the orderTools
	 */
	public AgilentOrderTools getOrderTools() {
		return mOrderTools;
	}

	/**
	 * @param orderTools the orderTools to set
	 */
	public void setOrderTools(AgilentOrderTools orderTools) {
		this.mOrderTools = orderTools;
	}

	public String getChinaTimeZone() {
		return mChinaTimeZone;
	}

	public void setChinaTimeZone(String mChinaTimeZone) {
		this.mChinaTimeZone = mChinaTimeZone;
	}

	/**
	 * @return the orderManager
	 */
	public AgilentOrderManager getOrderManager() {
		return orderManager;
	}

	/**
	 * @param orderManager the orderManager to set
	 */
	public void setOrderManager(AgilentOrderManager orderManager) {
		this.orderManager = orderManager;
	}
	
	/**
	 * @return the defaultLanguage
	 */
	public String getDefaultLanguage() {
		return defaultLanguage;
	}

	/**
	 * @param defaultLanguage the defaultLanguage to set
	 */
	public void setDefaultLanguage(String defaultLanguage) {
		this.defaultLanguage = defaultLanguage;
	}

	/**
	 * @return the chineseLanguage
	 */
	public String getChineseLanguage() {
		return chineseLanguage;
	}

	/**
	 * @param chineseLanguage the chineseLanguage to set
	 */
	public void setChineseLanguage(String chineseLanguage) {
		this.chineseLanguage = chineseLanguage;
	}

	/**
	 * @return the paymentTermValue
	 */
	public String getPaymentTermValue() {
		return paymentTermValue;
	}

	/**
	 * @param paymentTermValue the paymentTermValue to set
	 */
	public void setPaymentTermValue(String paymentTermValue) {
		this.paymentTermValue = paymentTermValue;
	}
	
	/**
	 * @return the paymentTermValueSP
	 */
	public String getPaymentTermValueSP() {
		return paymentTermValueSP;
	}

	/**
	 * @param paymentTermValueSP the paymentTermValueSP to set
	 */
	public void setPaymentTermValueSP(String paymentTermValueSP) {
		this.paymentTermValueSP = paymentTermValueSP;
	}

	/**
	 * @return the paymentTermValueNT1
	 */
	public String getPaymentTermValueNT1() {
		return paymentTermValueNT1;
	}

	/**
	 * @param paymentTermValueNT1 the paymentTermValueNT1 to set
	 */
	public void setPaymentTermValueNT1(String paymentTermValueNT1) {
		this.paymentTermValueNT1 = paymentTermValueNT1;
	}

	/**
	 * @return the paymentTermValueNT2
	 */
	public String getPaymentTermValueNT2() {
		return paymentTermValueNT2;
	}

	/**
	 * @param paymentTermValueNT2 the paymentTermValueNT2 to set
	 */
	public void setPaymentTermValueNT2(String paymentTermValueNT2) {
		this.paymentTermValueNT2 = paymentTermValueNT2;
	}


	 /**
     * Gets the value of property dataGridRestHelper
     *
     * @return the value of property dataGridRestHelper
     */
    public DataGridRestHelper getDataGridRestHelper() {
        return mDataGridRestHelper;
    }

    /**
     * Sets the value of property dataGridRestHelper with value dataGridRestHelper
     *
     * @param dataGridRestHelper
     *            for setting property dataGridRestHelper
     */
    public void setDataGridRestHelper(DataGridRestHelper dataGridRestHelper) {
        this.mDataGridRestHelper = dataGridRestHelper;
    }
	/**
     * Returns the order details as PDF represented by a table.
     * 
     * @param fontPath the fontPath
     * @param locale the locale
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param orderId the orderId
     * @param profile the profile
     * @param invoiceType the invoiceType
     * @param pageName the pageName
     * @return PdfPTable
     * @throws DocumentException
     * @throws IOException
     * @throws ParseException
     */
    public PdfPTable getChinaOrderAsPDF(final String fontPath, final Locale locale,
    		final OrderDetails orderDetails, final AgilentOrder lastOrder, final String orderId,
    		final AgilentProfile profile, String invoiceType, final String pageName)
    				throws DocumentException, IOException, ParseException {
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --START--");
        condensedregularBaseFont = getRoboFont();
        agilentLogo = fontPath + File.separator + this.getAgilentLogoImageName();
    	RepositoryItem sapOrderDetails=fetchSapOrderDetails(orderId);
    	String webOrderId = sapOrderDetails.getRepositoryId();
    	AgilentOrder webOrder = null;
    	
    	
    	webOrder = (AgilentOrder) getOrderManager().checkAndLoadOrder(webOrderId);
    	boolean vacuumProductInOrder = getOrderTools().checkOrderContainsVacuumParts(webOrder);
    	
    	invoiceType = Constants.EMPTY_STRING;
		if(null != sapOrderDetails && null != sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE)){
			invoiceType= (String) sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE);
		}
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --agilentLogo-- {0}", agilentLogo);
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --orderDetails-- {0}", orderDetails);
        
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(this.getInnerTable0(vacuumProductInOrder));
        pdf.addCell(getheadingTable());
        pdf.addCell(getInnerTable1(orderDetails, lastOrder, orderId, pageName));
        pdf.addCell(getInnerTable2(orderDetails, lastOrder, pageName, profile, invoiceType,webOrder));
        pdf.addCell(getOrderDetailsHeader());
        pdf.addCell(getInnerTable3(orderDetails, pageName, lastOrder));
        pdf.addCell(getTotalDetails(orderDetails, pageName, lastOrder));
        pdf.addCell(getInnerTable4());
        pdf.addCell(getShippingDetailsTable(orderDetails, lastOrder, pageName, webOrder));
        pdf.addCell(getInnerTable5(orderDetails, lastOrder, pageName));
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --Dynamic END--");
        return pdf;
    }
    
    public PdfPTable getChinaOrderPDFfor04CN(final String fontPath, final Locale locale,
    		final OrderDetails orderDetails, final AgilentOrder lastOrder, final String orderId,
    		final AgilentProfile profile, String invoiceType, final String pageName,final HashSet<String> productLineSet)
    				throws DocumentException, IOException, ParseException {
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --START--");
        condensedregularBaseFont = getRoboFont();
        agilentLogo = fontPath + File.separator + this.getAgilentLogoImageName();
    	RepositoryItem sapOrderDetails=fetchSapOrderDetails(orderId);
    	String webOrderId = sapOrderDetails.getRepositoryId();
    	AgilentOrder webOrder = null;
    	
    	
    	webOrder = (AgilentOrder) getOrderManager().checkAndLoadOrder(webOrderId);
    	boolean vacuumProductInOrder = getOrderTools().checkOrderContainsVacuumParts(webOrder);
    	boolean orderContainsOnlyVaccum = false;
    	if(vacuumProductInOrder){
    		if(productLineSet.size()==1){
    			orderContainsOnlyVaccum = true;
    		}
    	}
    	String salesOrg=evaluateSalesOrgForChinaPDF(orderDetails, lastOrder, pageName);
    	invoiceType = Constants.EMPTY_STRING;
		if(null != sapOrderDetails && null != sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE)){
			invoiceType= (String) sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE);
		}
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --agilentLogo-- {0}", agilentLogo);
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --orderDetails-- {0}", orderDetails);
        
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(this.getInnerTable0(vacuumProductInOrder,salesOrg,orderContainsOnlyVaccum));
        pdf.addCell(getheadingTable());
        pdf.addCell(getInnerTable1(orderDetails, lastOrder, orderId, pageName));
        pdf.addCell(getInnerTable2forC9(orderDetails, lastOrder, pageName, profile, invoiceType,webOrder));
        pdf.addCell(getInnerTable3forCN());
        pdf.addCell(getOrderDetailsHeader(salesOrg));
        pdf.addCell(getInnerTable3(orderDetails, pageName, lastOrder));
        pdf.addCell(getTotalDetails(orderDetails, pageName, lastOrder));
        pdf.addCell(getInnerTable4forCN(orderDetails, lastOrder, pageName, productLineSet));
        pdf.addCell(getInnerTable5forCN(orderDetails, lastOrder, pageName, productLineSet));
        pdf.addCell(getShippingDetailsTable(orderDetails, lastOrder, pageName, webOrder));
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --Dynamic END--");
        return pdf;
    }
    
    /**
     * Returns the order details as PDF represented by a table  for 04C9 Sales org.
     * 
     * @param fontPath the fontPath
     * @param locale the locale
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param orderId the orderId
     * @param profile the profile
     * @param invoiceType the invoiceType
     * @param pageName the pageName
     * @return PdfPTable
     * @throws DocumentException
     * @throws IOException
     * @throws ParseException
     */
    
    public PdfPTable getChinaOrderforC9AsPDF(final String fontPath, final Locale locale,
    		final OrderDetails orderDetails, final AgilentOrder lastOrder, final String orderId,
    		final AgilentProfile profile, String invoiceType, final String pageName)
    				throws DocumentException, IOException, ParseException {
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderforC9AsPDF --START--");
        condensedregularBaseFont = getRoboFont();
        agilentLogo = fontPath + File.separator + this.getAgilentLogoImageName();
    	RepositoryItem sapOrderDetails=fetchSapOrderDetails(orderId);
    	String webOrderId = sapOrderDetails.getRepositoryId();
    	AgilentOrder webOrder = null;
    	webOrder = (AgilentOrder) getOrderManager().checkAndLoadOrder(webOrderId);
    	String salesOrg=evaluateSalesOrgForChinaPDF(orderDetails, lastOrder, pageName);
		invoiceType = Constants.EMPTY_STRING;
		if(null != sapOrderDetails && null != sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE)){
			invoiceType= (String) sapOrderDetails.getPropertyValue(Constants.INVOICE_TYPE);
		}
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderForC9AsPDF --agilentLogo-- {0}", agilentLogo);
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderForC9AsPDF --orderDetails-- {0}", orderDetails);
        Boolean is04C9=true;
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(this.getInnerTable0(false,salesOrg));
        pdf.addCell(getheadingTable(salesOrg));
        pdf.addCell(getInnerTable1(orderDetails, lastOrder, orderId, pageName));
        pdf.addCell(getInnerTable2forC9(orderDetails, lastOrder, pageName, profile, invoiceType,webOrder));
        pdf.addCell(getInnerTable3forC9());
        pdf.addCell(getOrderDetailsHeader());
        pdf.addCell(getInnerTable3(orderDetails, pageName, lastOrder));
        pdf.addCell(getTotalDetails(orderDetails, pageName, lastOrder));
        pdf.addCell(middleLineTextfor04C9());
        pdf.addCell(getSeparateInnerTable4for04C9(salesOrg, lastOrder,  pageName, webOrder));
        
       // pdf.addCell(getInnerTable4(salesOrg, lastOrder));
        pdf.addCell(getShippingDetailsTable(orderDetails, lastOrder, pageName, webOrder));
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderforC9AsPDF --Dynamic END--");
        return pdf;
    }
    
    
    /**
     * Adds static sections to the PDF.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     * @throws DocumentException
     * @throws IOException
     * @throws ParseException
     */
    public PdfPTable staticSection(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName) throws DocumentException, IOException, ParseException {
        condensedregularBaseFont = getRoboFont();
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --in static section");
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(getInnerTable6());
        pdf.addCell(getInnerTable7(orderDetails, lastOrder, pageName));
        pdf.addCell(getInnerTable8());
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --static section END--");
        return pdf;
    }
    /**
     * Adds static sections to the PDF.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     * @throws DocumentException
     * @throws IOException
     * @throws ParseException
     */
    public PdfPTable staticFirstSectionforCN(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName ,final boolean isCNHost ,final HashSet<String> productLineSet) throws DocumentException, IOException, ParseException {
        condensedregularBaseFont = getRoboFont();
        vlogDebug("PdfChinaOrderDownloadHelper.getCNChinaOrderAsPDF -- Fisrt static section starts");
       
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(getInnerTable6ForCN(orderDetails, lastOrder, pageName,isCNHost,productLineSet));
        pdf.addCell(getInnerTable7ForCN(orderDetails, lastOrder, pageName,isCNHost,productLineSet));
        vlogDebug("PdfChinaOrderDownloadHelper.getCNChinaOrderAsPDF -- first static section END--");
        return pdf;
    }
    
    public PdfPTable staticSecondSectionforCN(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName) throws DocumentException, IOException, ParseException {
        condensedregularBaseFont = getRoboFont();
        vlogDebug("PdfChinaOrderDownloadHelper.getCNChinaOrderAsPDF --Second static section start");
       
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setKeepTogether(true);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(getInnerTable7(orderDetails, lastOrder, pageName));
        vlogDebug("PdfChinaOrderDownloadHelper.getCNChinaOrderAsPDF -- Second static section END--");
        return pdf;
    }

    /**
     * Adds section shipping details to the pdf.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     */
  

	private PdfPTable getInnerTable5forCN(OrderDetails orderDetails, AgilentOrder lastOrder, String pageName, HashSet<String> productLineSet) throws DocumentException {
       
		boolean isVacuumPartPresent = false;
		boolean isXPLPartPresent =false;
		boolean isInstrumentPartPresent = false;
	    
	    PdfPTable innerTable4 = new PdfPTable(2);
	    innerTable4.setSplitLate(false);
	    innerTable4.setWidthPercentage(100);
	    innerTable4.setSpacingBefore(5);
	    innerTable4.setWidths(new float[] { 3, 97 });
        PdfPCell innerTable4Cell1 = new PdfPCell();
        Paragraph paragraph2 = new Paragraph();
        Paragraph paragraph3 = new Paragraph();
        Phrase pl0=new Phrase();
        Phrase pl1=new Phrase();
        Phrase pl2=new Phrase();
        Phrase pl3=new Phrase();
        pl0=new Phrase(getParagraphTwoChina(), new Font(condensedregularBaseFont, 9));
        pl1=new Phrase(getParagraphTwoChinaPL1(), new Font(condensedregularBaseFont, 9));
        pl2=new Phrase(getParagraphTwoChinaPL2(), new Font(condensedregularBaseFont, 9));
        pl3=new Phrase(getParagraphTwoChinaPL3(), new Font(condensedregularBaseFont, 9));
        paragraph2.add(pl0);
        innerTable4Cell1= new PdfPCell(new Phrase("2.", new Font(condensedregularBaseFont, 9)));
        innerTable4Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell1.setPaddingTop(10);
        innerTable4Cell1.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable4Cell2 = new PdfPCell();
        innerTable4Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        for (String s1 : productLineSet) {
       	 if(s1.contains("XfPL")){
       		isXPLPartPresent=true;
           }else if (s1.contains("VacuumPL")){
        	   isVacuumPartPresent=true;
           }else if(s1.contains("InstrumentPL")){
        	   isInstrumentPartPresent=true;
       }
       }
        
        if(isInstrumentPartPresent){
        	paragraph3.add(pl1);
        }
        if(isVacuumPartPresent){
        	paragraph3.add(pl2);
        }
        if(isXPLPartPresent){
        	paragraph3.add(pl3);
        }
        innerTable4Cell2.addElement(paragraph2);
        innerTable4Cell2.addElement(paragraph3);
        innerTable4Cell2.setBorder(PdfPCell.NO_BORDER);
      //  innerTable4Cell2.setPaddingBottom(10);

        
        PdfPCell innerTable4Cell3 = new PdfPCell(new Phrase("3.", new Font(condensedregularBaseFont, 9)));
        innerTable4Cell3.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell3.setPaddingTop(10);
        innerTable4Cell3.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable4Cell4 = new PdfPCell(new Phrase(getParagraphThreeForCN(), new Font(condensedregularBaseFont, 9)));
        innerTable4Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell4.setPaddingTop(10);
        innerTable4Cell4.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell1);
        innerTable4.addCell(innerTable4Cell2);
        innerTable4.addCell(innerTable4Cell3);
        innerTable4.addCell(innerTable4Cell4);
        return innerTable4;
    }
    
    


	public PdfPTable staticSectionForC9(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName, final boolean isCNHost, final String orderId) throws DocumentException, IOException, ParseException {
        condensedregularBaseFont = getRoboFont();
        
        RepositoryItem sapOrderDetails=fetchSapOrderDetails(orderId);
        String webOrderId = sapOrderDetails.getRepositoryId();
        AgilentOrder webOrder = null;
        webOrder = (AgilentOrder) getOrderManager().checkAndLoadOrder(webOrderId);
        
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
        pdf.addCell(getInnerTable6ForC9(isCNHost,lastOrder, pageName, webOrder));
       // pdf.addCell(getInnerTable7(orderDetails, lastOrder, pageName));
        vlogDebug("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --static section for 04C9 END--");
        return pdf;
    }
	
	public PdfPTable staticSectionSecondForC9(final OrderDetails orderDetails, final AgilentOrder lastOrder,
            final String pageName) throws DocumentException, IOException, ParseException {
        condensedregularBaseFont = getRoboFont();
       
        PdfPTable pdf = new PdfPTable(1);
        pdf.setWidthPercentage(100);
        pdf.setKeepTogether(true);
       // pdf.setSplitLate(false);
        pdf.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
       // pdf.addCell(getInnerTable6ForC9(isCNHost,lastOrder));
        pdf.addCell(getInnerTable7(orderDetails, lastOrder, pageName));
        vlogInfo("PdfChinaOrderDownloadHelper.getChinaOrderAsPDF --Second static section END--");
        return pdf;
    }
	
    /**
     * Parent table holding header information.
     * 
     * @return PdfPTable
     * @throws DocumentException
     * @throws MalformedURLException
     * @throws IOException
     */
    private PdfPTable getInnerTable0(boolean vacuumProductInOrder) throws DocumentException, MalformedURLException, IOException {
    	return getInnerTable0(vacuumProductInOrder,null);
    }
    private PdfPTable getInnerTable0(boolean vacuumProductInOrder ,String salesOrg ) throws DocumentException, MalformedURLException, IOException {
    	return getInnerTable0(vacuumProductInOrder,salesOrg,false);
    }
    
    private PdfPTable getInnerTable0(boolean vacuumProductInOrder,String salesOrg , boolean orderContainsOnlyVaccum) throws DocumentException, MalformedURLException, IOException {
        vlogDebug("PdfChinaOrderDownloadHelper.getInnerTable0 --START--");
        PdfPTable innerTable1 = new PdfPTable(2);
        innerTable1.setWidthPercentage(100);
        innerTable1.setSpacingAfter(30);
        innerTable1.setWidths(new float[] {40 , 60});
        PdfPCell innerTable1Cell1 = new PdfPCell(Image.getInstance(agilentLogo));
        innerTable1Cell1.setBorder(PdfPCell.NO_BORDER);
        PdfPCell innerTable1Cell2 = getInnerTable0Cell2(vacuumProductInOrder,salesOrg,orderContainsOnlyVaccum);
        innerTable1Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable1.addCell(innerTable1Cell1);
        innerTable1.addCell(innerTable1Cell2);
        return innerTable1;
    }

    /**
     * This method returns Agilent address and contact details as a PDF cell.
     * 
     * @return PdfPCell
     * @throws DocumentException
     * 
     */
    private PdfPCell getInnerTable0Cell2(boolean vacuumProductInOrder,String salesOrg) throws DocumentException {
    	 return getInnerTable0Cell2(vacuumProductInOrder,salesOrg ,false);
    }
    private PdfPCell getInnerTable0Cell2(boolean vacuumProductInOrder,String salesOrg, boolean orderContainsOnlyVaccum) throws DocumentException {
    	PdfPTable innerTable1 = new PdfPTable(2);
    	innerTable1.setWidths(new float[] { 4, 4 });
    	PdfPCell cell1 = new PdfPCell();
    	PdfPCell innerTable1Cell2 = new PdfPCell();
    	if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
    	 cell1 = new PdfPCell(new Phrase(getAddressDetailsForC9(), new Font(condensedregularBaseFont, 7)));
    	 innerTable1Cell2 = getInnerTableContactDetails(vacuumProductInOrder,salesOrg);
    	}else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
    	cell1 = new PdfPCell(new Phrase(getAddressDetails(), new Font(condensedregularBaseFont, 7)));
       	 innerTable1Cell2 = getInnerTableContactDetails(vacuumProductInOrder,salesOrg, orderContainsOnlyVaccum);
    	}else{
    	  cell1 = new PdfPCell(new Phrase(getAddressDetails(), new Font(condensedregularBaseFont, 7)));
    	  innerTable1Cell2 = getInnerTableContactDetails(vacuumProductInOrder);
    	}
    	cell1.setBorder(PdfPCell.NO_BORDER);
    	innerTable1Cell2.setBorder(PdfPCell.NO_BORDER);

    	innerTable1.addCell(cell1);
    	innerTable1.addCell(innerTable1Cell2);
    	return new PdfPCell(innerTable1);
    }
    
    
    /**
     * Generate Contact Details Table.
     * 
     * @return PdfPCell
     * @throws DocumentException
     */
    private PdfPCell getInnerTableContactDetails(boolean vacuumProductInOrder) throws DocumentException {
    	return getInnerTableContactDetails(vacuumProductInOrder,null);
    }
    private PdfPCell getInnerTableContactDetails(boolean vacuumProductInOrder,String salesOrg) throws DocumentException {
    	return getInnerTableContactDetails(vacuumProductInOrder,salesOrg,false);
    }
    private PdfPCell getInnerTableContactDetails(boolean vacuumProductInOrder, String salesOrg, boolean orderContainsOnlyVacuum) throws DocumentException {
    	PdfPTable innerTable1 = new PdfPTable(2);
    	boolean isC9SalesOrg = false;
    	String contactDetail ="";
    	//innerTable1.setWidths(new float[] { 2, 5});
    	if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
    		contactDetail = getContactDetailsForC9();
    		//contactDetail = getContactDetails();
    		innerTable1.setWidths(new float[] { 2, 5});
    	}else{
    		contactDetail = getContactDetails();
    		innerTable1.setWidths(new float[] { 2, 5});
    	}
		

    	String[] splittedContactDetail = new String[4];

    	if(StringUtils.isNotBlank(contactDetail)){
    		splittedContactDetail = contactDetail.split(LscaQuoteConstants.NEWLINE);
    	}
    	//DCCOM-21788
    	String teleData;
    	
    	
    	if(StringUtils.isNotEmpty(salesOrg)&& salesOrg.equals("04C9")){
    		teleData = splittedContactDetail[0];
    		isC9SalesOrg=true;
    	}else if (StringUtils.isNotEmpty(salesOrg) && getSalesOrgListForChina().contains(salesOrg)) {
    		String teleData1 = splittedContactDetail[0].substring(0,splittedContactDetail[0].indexOf("#"));
        	String teleData2 = getVacuumProductContactNum();
        	String teleData3 = splittedContactDetail[0].substring(splittedContactDetail[0].indexOf("#")+1 ,splittedContactDetail[0].length());
        	if (orderContainsOnlyVacuum) {
        		teleData = teleData2;
        	}else if (vacuumProductInOrder){
        		teleData = teleData1 + LscaQuoteConstants.NEWLINE + teleData2 + LscaQuoteConstants.NEWLINE
						+ teleData3;
        	}else{
        		teleData = teleData1 + LscaQuoteConstants.NEWLINE + teleData3;
        	}
    	}
    	else{
    		String teleData1 = splittedContactDetail[0].substring(0,splittedContactDetail[0].indexOf("#"));
        	String teleData2 = getVacuumProductContactNum();
        	String teleData3 = splittedContactDetail[0].substring(splittedContactDetail[0].indexOf("#")+1 ,splittedContactDetail[0].length());
			if (vacuumProductInOrder) {
				if (StringUtils.isNotEmpty(salesOrg) && getSalesOrgListForChina().contains(salesOrg)) {
					teleData = teleData2;
				} else {
					teleData = teleData1 + LscaQuoteConstants.NEWLINE + teleData2 + LscaQuoteConstants.NEWLINE
							+ teleData3;
				}
			} else {
				teleData = teleData1 + LscaQuoteConstants.NEWLINE + teleData3;
			}
		}
    	
    	String faxData = splittedContactDetail[1];
    	String emailData = splittedContactDetail[2];
    	String webData = splittedContactDetail[3];
    	
		vlogDebug("teleData = {0}", teleData);
		vlogDebug("faxData = {0}", faxData);
		vlogDebug("emailData = {0}", emailData);
		vlogDebug("webData = {0}", webData);

    	if(StringUtils.isNotEmpty(teleData)){
    		PdfPCell telLabelCell = new PdfPCell(new Phrase(getTeleLabel(),new Font(condensedregularBaseFont, 7)));
    		PdfPCell telDataCell = new PdfPCell(new Phrase(teleData,new Font(condensedregularBaseFont, 7)));
    		telLabelCell.setBorder(PdfPCell.NO_BORDER);
    		telDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(telLabelCell);
    		innerTable1.addCell(telDataCell);
    	}

    	if(StringUtils.isNotEmpty(faxData)&& !isC9SalesOrg){
    		PdfPCell faxLabelCell = new PdfPCell(new Phrase(getFaxLabel(),new Font(condensedregularBaseFont, 7)));
    		PdfPCell faxDataCell = new PdfPCell(new Phrase(faxData,new Font(condensedregularBaseFont, 7)));
    		faxLabelCell.setBorder(PdfPCell.NO_BORDER);
    		faxDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(faxLabelCell);
    		innerTable1.addCell(faxDataCell);
    	}

    	if(StringUtils.isNotEmpty(emailData)){
    		if(isC9SalesOrg){
	    		Paragraph paragraphNote = new Paragraph();
	       		Anchor anchor = new Anchor(emailData, new Font(condensedregularBaseFont, 7, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
	       	    anchor.setReference("mailto:"+emailData);
	       	    paragraphNote.add(anchor);   
	       		PdfPCell emailLabelCell= new PdfPCell(new Phrase(getEmailLabel(),new Font(condensedregularBaseFont, 7)));
	       		PdfPCell emailDataCell = new PdfPCell();
	       		emailDataCell.setPhrase(paragraphNote);
	       		emailLabelCell.setBorder(PdfPCell.NO_BORDER);
	       		emailDataCell.setBorder(PdfPCell.NO_BORDER);
	       		innerTable1.addCell(emailLabelCell);
	       		innerTable1.addCell(emailDataCell);
    		}else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
    			Paragraph paragraphNote = new Paragraph();
	       		Anchor anchor = new Anchor(emailData, new Font(condensedregularBaseFont, 7, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
	       	    anchor.setReference("mailto:"+emailData);
	       	    paragraphNote.add(anchor); 
	       	    PdfPCell emailLabelCell= new PdfPCell(new Phrase(getEmailLabel(),new Font(condensedregularBaseFont, 7)));
    			PdfPCell emailDataCell = new PdfPCell();
	       		emailDataCell.setPhrase(paragraphNote);
    			emailLabelCell.setBorder(PdfPCell.NO_BORDER);
        		emailDataCell.setBorder(PdfPCell.NO_BORDER);
        		innerTable1.addCell(emailLabelCell);
        		innerTable1.addCell(emailDataCell);
    		}else {
    			PdfPCell emailLabelCell= new PdfPCell(new Phrase(getEmailLabel(),new Font(condensedregularBaseFont, 7)));
    			PdfPCell emailDataCell = new PdfPCell(new Phrase(emailData,new Font(condensedregularBaseFont, 7)));
    			emailLabelCell.setBorder(PdfPCell.NO_BORDER);
        		emailDataCell.setBorder(PdfPCell.NO_BORDER);
        		innerTable1.addCell(emailLabelCell);
        		innerTable1.addCell(emailDataCell);
    		}
    		
    	}

    	if(StringUtils.isNotEmpty(webData)){
    		PdfPCell webLabelCell= new PdfPCell(new Phrase(getWebLabel(),new Font(condensedregularBaseFont, 7)));
    		PdfPCell webDataCell = new PdfPCell(new Phrase(webData,new Font(condensedregularBaseFont, 7)));
    		webLabelCell.setBorder(PdfPCell.NO_BORDER);
    		webDataCell.setBorder(PdfPCell.NO_BORDER);
    		innerTable1.addCell(webLabelCell);
    		innerTable1.addCell(webDataCell);
    	}

    	return new PdfPCell(innerTable1);
    }
    
    /**
     * This method returns heading table.
     * 
     * @return PdfPTable
     */
    private PdfPTable getheadingTable() {
    	 return getheadingTable(null);
    }
    
    private PdfPTable getheadingTable(String salesOrg) {
        PdfPTable headingTable = new PdfPTable(1);
        headingTable.setWidthPercentage(100);
        Phrase heading;
        if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
        	heading = new Phrase(getMainHeadingForC9(), new Font(condensedregularBaseFont, 15));
        }else{
        	heading = new Phrase(getMainHeading(), new Font(condensedregularBaseFont, 15));
        }
        
        PdfPCell headingTableCell1 = new PdfPCell(heading);
        headingTableCell1.setBorder(PdfPCell.NO_BORDER);
        headingTableCell1.setFixedHeight(25);
        headingTableCell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        
        headingTable.addCell(headingTableCell1);
        return headingTable;
    }

    /**
     * Parent table holding all the order information.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param orderId the orderId
     * @param pageName the pageName
     * @return PdfPTable
     */
    private PdfPTable getInnerTable1(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String orderId, final String pageName) {
        PdfPTable innerTable1 = new PdfPTable(2);
        innerTable1.setWidthPercentage(100);
        
        PdfPCell innerTable1Cell3 = new PdfPCell();
        innerTable1Cell3.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable1Cell4 = getInnerTable1Cell4(orderDetails, lastOrder, orderId, pageName);
        
        innerTable1.addCell(innerTable1Cell3);
        innerTable1.addCell(innerTable1Cell4);
        return innerTable1;
    }

    /**
     * Table holding order meta information.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param orderId the orderId
     * @param pageName the pageName
     * @return PdfPCell
     */
    private PdfPCell getInnerTable1Cell4(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String orderId, final String pageName) {
        PdfPCell innerTable1Cell4 = new PdfPCell();
        innerTable1Cell4.setBorder(PdfPCell.NO_BORDER);
        PdfPTable quoteDetailOuterTable = new PdfPTable(1);
        quoteDetailOuterTable.setWidthPercentage(100);
        quoteDetailOuterTable.getDefaultCell().setBorder(Rectangle.NO_BORDER);
        PdfPTable quoteDetailInnerTable1 = getInnerTable1Cell4Table1(orderDetails, lastOrder, orderId, pageName);
        PdfPCell c1 = new PdfPCell(quoteDetailInnerTable1);
        c1.setPadding(0);
        quoteDetailOuterTable.addCell(c1);
        innerTable1Cell4.addElement(quoteDetailOuterTable);
        return innerTable1Cell4;
    }

    /**
     * Methods returns order metadata as PDF table.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param orderId the orderId
     * @param pageName the pageName
     * @return PdfPTable
     */
    private PdfPTable getInnerTable1Cell4Table1(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String orderId, final String pageName) {
    	String salesOrder = null;
    	String salesOrderDate = null;
    	String poNumber = null;
    	String formattedDate = null;
    	Locale locale = Locale.CHINA;
            if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
                salesOrder = orderId;
                poNumber = orderDetails.getItems().get(0).getPurchaseOrder();
                // salesOrderDate = orderDetails.getItems().get(0).getDocumentDate();
                salesOrderDate = orderDetails.getItems().get(0).getUnformattedDate();
                if (orderDetails.getItems().get(0).getUnformattedDate() != null && !orderDetails.getItems().get(0).getUnformattedDate().isEmpty()) {
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", locale);
                    try {
                        Date date = format.parse(salesOrderDate);
                        formattedDate = SimpleDateFormat.getDateInstance(SimpleDateFormat.LONG, locale).format(date);
                        // formattedDate = format.format(salesOrderDate);
                        salesOrderDate = formattedDate;
                    } catch (ParseException e) {
                        vlogDebug(e, "");
                    }
                }
        } else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			if ("SAP".equalsIgnoreCase(lastOrder.getOrderType())) {
				salesOrder = lastOrder.getSapOrderId();
			} else {
				salesOrder = lastOrder.getId();
			}
			PaymentGroup payGroup = (PaymentGroup) lastOrder.getPaymentGroups().get(0);
			if (payGroup instanceof PurchaseOrderPaymentGroup) {
				PurchaseOrderPaymentGroup poPG = (PurchaseOrderPaymentGroup) payGroup;
				poNumber = poPG.getPurchaseOrderNumber();
			}
			salesOrderDate = lastOrder.getSubmittedDate().toString();
			vlogInfo("salesOrderDate before Timezone set", salesOrderDate);
			if (StringUtils.isNotBlank(salesOrderDate)) {
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale);				
				TimeZone timezoneObj1 = TimeZone.getTimeZone(getCountryUtils().getDefaultTimeZoneSet());
				formatter.setTimeZone(timezoneObj1);
				try {
					Date date = formatter.parse(salesOrderDate);
					Calendar cal = Calendar.getInstance();
					cal.setTime(date);
					TimeZone timeZone = TimeZone.getTimeZone(getCountryUtils().getDefaultTimeZoneSet());
					cal.setTimeZone(timeZone);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",locale);
					sdf.setTimeZone(timeZone);
					vlogDebug("Formatted EST time = {0} ", sdf.format(cal.getTime()));

					// To CST
					DateFormat sdf2 = DateFormat.getDateInstance(DateFormat.LONG, Locale.CHINA);
					TimeZone cst = TimeZone.getTimeZone("Asia/Shanghai");
					sdf2.setTimeZone(cst);
					salesOrderDate = sdf2.format(cal.getTime());
					vlogDebug("FORMATTED CST DATE = {0} " , salesOrderDate);

				} catch (ParseException e) {
					vlogError("ParseException in Order Confirmation Page {0}", e);
				}
			}
		}
        PdfPTable quoteDetailInnerTable1 = new PdfPTable(2);
        
        PdfPCell innerTable1Cell1 = new PdfPCell();
        Phrase quoteNumPhrase = new Phrase(getSalesOrderNumberKey(), new Font(condensedregularBaseFont, 9));
        quoteNumPhrase.add(new Phrase("\n" + salesOrder, new Font(condensedregularBaseFont, 9)));
        innerTable1Cell1.addElement(quoteNumPhrase);
        
        PdfPCell innerTable1Cell2 = new PdfPCell();
        Phrase quoteDatePhrase = new Phrase(getSalesOrderDateKey(), new Font(condensedregularBaseFont, 9));
        quoteDatePhrase.add(new Phrase("\n" + salesOrderDate, new Font(condensedregularBaseFont, 9)));
        innerTable1Cell2.addElement(quoteDatePhrase);
        
        PdfPCell innerTable1Cell7 = new PdfPCell();
        Phrase purchasingAgreementNoPhrase = new Phrase(getPoNumberKey(), new Font(condensedregularBaseFont, 9));
        purchasingAgreementNoPhrase.add(new Phrase("\n" + poNumber, new Font(condensedregularBaseFont, 9)));
        innerTable1Cell7.addElement(purchasingAgreementNoPhrase);
        
        PdfPCell innerTable1Cell8 = new PdfPCell();
        Phrase currencyPhrase = new Phrase(getCurrencyKey(), new Font(condensedregularBaseFont, 9));
        currencyPhrase.add(new Phrase("\n" + getCurrencyValue(), new Font(condensedregularBaseFont, 9)));
        innerTable1Cell8.addElement(currencyPhrase);

        PdfPCell innerTable1Cell9 = new PdfPCell();
        innerTable1Cell9.setColspan(2);
        innerTable1Cell9.setBorder(PdfPCell.RIGHT | PdfPCell.LEFT | PdfPCell.TOP);
        Phrase directEnquiriesPhrase1 = new Phrase(getDirectInquiry(), new Font(condensedregularBaseFont, 9));
        innerTable1Cell9.addElement(directEnquiriesPhrase1);

        PdfPCell innerTable1Cell10 = new PdfPCell();
        innerTable1Cell10.setColspan(2);
        innerTable1Cell10.setBorder(PdfPCell.BOTTOM | PdfPCell.RIGHT | PdfPCell.LEFT);
        Phrase directEnquiriesPhrase2 = new Phrase(getChinaContactUsURL(), new Font(condensedregularBaseFont, 9));
        innerTable1Cell10.addElement(directEnquiriesPhrase2);

        quoteDetailInnerTable1.addCell(innerTable1Cell1);
        quoteDetailInnerTable1.addCell(innerTable1Cell2);
        quoteDetailInnerTable1.addCell(innerTable1Cell7);
        quoteDetailInnerTable1.addCell(innerTable1Cell8);
        quoteDetailInnerTable1.addCell(innerTable1Cell9);
        quoteDetailInnerTable1.addCell(innerTable1Cell10);
        return quoteDetailInnerTable1;
    }

    /**
     * Returns customer and supplier metadata summary
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @param profile the profile
     * @param invoiceType the invoiceType
     * @return PdfPTable
     * @throws DocumentException
     */
    private PdfPTable getInnerTable2(final OrderDetails orderDetails, final AgilentOrder lastOrder, final String pageName,
    		final AgilentProfile profile, final String invoiceType,AgilentOrder webOrder) 
    		throws DocumentException {
        PdfPTable innerTable2 = new PdfPTable(1);
        innerTable2.setWidthPercentage(100); 
        innerTable2.setSpacingBefore(10);
        RepositoryItem orderInvoiceItem = null;
        PdfPCell innerTable2Cell1 = new PdfPCell();    
        String soldToNum = null;
        if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName)) {
   			soldToNum = orderDetails.getOrderSoldToNumber();
   			orderInvoiceItem = webOrder.getOrderInvoiceItem();

   		} else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
   			soldToNum = lastOrder.getSoldToNumber();
   			orderInvoiceItem = webOrder.getOrderInvoiceItem();
   		}
        
        Map<String, String> invoiceDetailsMap = null;
        if(orderInvoiceItem == null) {
        	invoiceDetailsMap = getOrderManagerHelper().fetchInvoiceDetailsForSoldTo(soldToNum, profile);
        }
   		
   		String contactorName2 = null;
   		String contactorPhNum2 = null;
   		String address1 = null;
   		String bankName1 = null;
   		String bankAccount1 = null;
   		String companyTaxCode1 = null;
   		// Get invoice information from profile or order.
   		if (orderInvoiceItem != null) {
			companyTaxCode1 = (String) orderInvoiceItem.getPropertyValue(Constants.COMPANY_TAX_CODE1);
			address1 = (String) orderInvoiceItem.getPropertyValue(Constants.ADDRESS1);
			bankName1 = (String) orderInvoiceItem.getPropertyValue(Constants.BANK_NAME1);
			bankAccount1 = (String) orderInvoiceItem.getPropertyValue(Constants.BANK_ACCOUNT1);
			contactorName2 = (String) orderInvoiceItem.getPropertyValue(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = (String) orderInvoiceItem.getPropertyValue(Constants.CONTACTOR_PHNUM2);

		}
   		else if (invoiceDetailsMap != null && !invoiceDetailsMap.isEmpty()) {
			companyTaxCode1 = invoiceDetailsMap.get(Constants.COMPANY_TAX_CODE1);
			address1 = invoiceDetailsMap.get(Constants.ADDRESS1);
			bankName1 = invoiceDetailsMap.get(Constants.BANK_NAME1);
			bankAccount1 = invoiceDetailsMap.get(Constants.BANK_ACCOUNT1);
			contactorName2 = invoiceDetailsMap.get(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = invoiceDetailsMap.get(Constants.CONTACTOR_PHNUM2);

		} else {
			companyTaxCode1 = (String) profile.getPropertyValue(Constants.COMPANY_TAX_CODE1);
			address1 = (String) profile.getPropertyValue(Constants.ADDRESS1);
			bankName1 = (String) profile.getPropertyValue(Constants.BANK_NAME1);
			bankAccount1 = (String) profile.getPropertyValue(Constants.BANK_ACCOUNT1);
			contactorName2 = (String) profile.getPropertyValue(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = (String) profile.getPropertyValue(Constants.CONTACTOR_PHNUM2);
		}

        String orderInfo = null;
        if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
        	//Fix for UAT 1179 & UAT 1239 - appending city name to address
        	if(null!=orderDetails.getInternationalBillAddress() && !orderDetails.getInternationalBillAddress().isEmpty()){
         orderInfo = getSoldToAccountNameKey() + ": " + orderDetails.getInternationalBillAddress().get(0).getCompanyName() + "\n" +
        		 	 getSoldToAccountAddressKey() + ": " +  orderDetails.getInternationalBillAddress().get(0).getCity() + orderDetails.getInternationalBillAddress().get(0).getAddress1() + "\n" +
        		 	 getInvoiceContactPersonNameKey() + ": " + contactorName2 + "\n" +
        		 	 getInvoiceContactPersonPhoneKey() + ": " + contactorPhNum2 + "\n" +
        		 	 getInvoiceAddressKey() + ": " + address1 + "\n" +
        		 	 getCustomerBankNameKey() + ": " + bankName1 + "\n" +
        		 	 getCustomerBankAccountKey() + ": " + bankAccount1 + "\n" +
        		 	 getCustomerTaxCodeKey() + ": " + companyTaxCode1 + "\n" +
        		 	 getCustomerInvoiceTypeKey() + ": " + getZhInvoiceType(invoiceType.trim()) + "\n" + "\n";
        		 
					 for(Entry<String, String> entry : getSupplierDetailsMap().entrySet()) {
						 orderInfo = orderInfo.concat(entry.getKey() + ": " + entry.getValue() + "\n");
					 }
        	}
					 /*orderInfo = orderInfo.concat("Sales Representative Name: " + "Sales Representative Name" + "\n")
					 .concat("Sales Representative Tel. No: " + "Sales Representative Tel. No" + "\n")
					 .concat("Sales Representative E-mail: " + "Sales Representative E-mail");*/
        } else if("orderConfirmationPage".equalsIgnoreCase(pageName)) {
        	PurchaseOrderPaymentGroup poPG = null;
        	PaymentGroup payGroup = (PaymentGroup) lastOrder.getPaymentGroups().get(0);
        	if (payGroup instanceof PurchaseOrderPaymentGroup) {
        		poPG = (PurchaseOrderPaymentGroup) payGroup;
        	}
        	orderInfo = getSoldToAccountNameKey() + poPG.getPayerCompanyName() + "\n" +
        			 getSoldToAccountAddressKey() + poPG.getPayerCity() + poPG.getPayerAddress1() + "\n" +
        			 getInvoiceContactPersonNameKey() + ": " + contactorName2 + "\n" +
	       		 	 getInvoiceContactPersonPhoneKey() + ": " + contactorPhNum2 + "\n" +
	       		 	 getInvoiceAddressKey() + ": " + address1 + "\n" +
	       		 	 getCustomerBankNameKey() + ": " + bankName1 + "\n" +
	       		 	 getCustomerBankAccountKey() + ": " + bankAccount1 + "\n" +
	       		 	 getCustomerTaxCodeKey() + ": " + companyTaxCode1 + "\n" +
	       		 	 getCustomerInvoiceTypeKey() + ": " + getZhInvoiceType(lastOrder.getInvoiceType().trim()) + "\n" + "\n";
       		 	 
					 for(Entry<String, String> entry : getSupplierDetailsMap().entrySet()) {
						 orderInfo = orderInfo.concat(entry.getKey() + ": " + entry.getValue() + "\n");
					 }
					 /*orderInfo = orderInfo.concat("Ship To address: " + "Sales Representative Name" + "\n")
					 .concat("Ship To address: " + "Sales Representative Tel. No" + "\n")
					 .concat("Ship To address: " + "Sales Representative E-mail");*/
        }
        Phrase customerContactTextPhrase = new Phrase(orderInfo, new Font(condensedregularBaseFont, 9));

        innerTable2Cell1.addElement(customerContactTextPhrase);
        innerTable2Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable2Cell1.setPaddingLeft(50);
        
        PdfPCell innerTable2Cell2 = new PdfPCell(); 
        Phrase lastLineText = new Phrase(getLastLineText(), new Font(condensedregularBaseFont, 9));
        innerTable2Cell2.addElement(lastLineText);
        innerTable2Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable2Cell2.setPaddingLeft(50);
        innerTable2Cell2.setPaddingTop(10);
        
        innerTable2.addCell(innerTable2Cell1);
        innerTable2.addCell(innerTable2Cell2);
        innerTable2.setSpacingAfter(250);
        
        return innerTable2;
    }
    /**
     * Returns supplier metadata summary
     * 
     * @return PdfPTable
     * @throws DocumentException
     */
	private PdfPTable getInnerTable3forC9() throws DocumentException {
		PdfPTable innerTable3 = new PdfPTable(2);
		innerTable3.setWidths(new float[] { 55, 45 });
		String orderInfo1 = "";
		String orderInfo2 = "";
		PdfPCell innerTable3Cell1 = new PdfPCell();
		PdfPCell innerTable3Cell2 = new PdfPCell();
		for (Entry<String, String> entry : getSupplierDetailsMap1ForC9().entrySet()) {
			orderInfo1 = orderInfo1.concat(entry.getKey() + ": " + entry.getValue() + "\n");
		}
		for (Entry<String, String> entry : getSupplierDetailsMap2ForC9().entrySet()) {
			orderInfo2 = orderInfo2.concat(entry.getKey() + ": " + entry.getValue() + "\n");
		}
		Phrase customerContactTextPhrase1 = new Phrase(orderInfo1, new Font(condensedregularBaseFont, 9));

		innerTable3Cell1.addElement(customerContactTextPhrase1);
		innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);

		Phrase customerContactTextPhrase2 = new Phrase(orderInfo2, new Font(condensedregularBaseFont, 9));
		Phrase emptyPhrase = new Phrase(" ", new Font(condensedregularBaseFont, 9));
		innerTable3Cell2.addElement(emptyPhrase);
		innerTable3Cell2.addElement(customerContactTextPhrase2);
		innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable3Cell3 = new PdfPCell();
		innerTable3Cell3.setColspan(2);
		Phrase lastLineText = new Phrase(getLastLineText(), new Font(condensedregularBaseFont, 9));

		innerTable3Cell3.addElement(lastLineText);
		innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);
		innerTable3Cell3.setPaddingTop(10);

		innerTable3.addCell(innerTable3Cell1);
		innerTable3.addCell(innerTable3Cell2);
		innerTable3.addCell(innerTable3Cell3);
		return innerTable3;
	}
	/**
     * Returns CN supplier metadata summary
     * 
     * @return PdfPTable
     * @throws DocumentException
     */
	private PdfPTable getInnerTable3forCN() throws DocumentException {
		PdfPTable innerTable3 = new PdfPTable(2);
		innerTable3.setWidths(new float[]{55,45});
		innerTable3.setSpacingBefore(10);
		String orderInfo1 = "";
		String orderInfo2 = "";
		PdfPCell innerTable3Cell1 = new PdfPCell();
		PdfPCell innerTable3Cell2 = new PdfPCell();
		for (Entry<String, String> entry : getSupplierDetailsMap1ForCN().entrySet()) {
			orderInfo1 = orderInfo1.concat(entry.getKey() + ": " + entry.getValue() + "\n");
		}
		for (Entry<String, String> entry : getSupplierDetailsMap2ForCN().entrySet()) {
			orderInfo2 = orderInfo2.concat(entry.getKey() + ": " + entry.getValue() + "\n");
		}
		Phrase customerContactTextPhrase1 = new Phrase(orderInfo1, new Font(condensedregularBaseFont, 9));

		innerTable3Cell1.addElement(customerContactTextPhrase1);
		innerTable3Cell1.setBorder(PdfPCell.NO_BORDER);

		Phrase customerContactTextPhrase2 = new Phrase(orderInfo2, new Font(condensedregularBaseFont, 9));
		Phrase emptyPhrase = new Phrase(" ", new Font(condensedregularBaseFont, 9));
		innerTable3Cell2.addElement(emptyPhrase);
		innerTable3Cell2.addElement(customerContactTextPhrase2);
		innerTable3Cell2.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable3Cell3 = new PdfPCell();
		innerTable3Cell3.setColspan(2);
		Phrase lastLineText = new Phrase(getLastLineText(), new Font(condensedregularBaseFont, 9));

		innerTable3Cell3.addElement(lastLineText);
		innerTable3Cell3.setBorder(PdfPCell.NO_BORDER);
		innerTable3Cell3.setPaddingTop(20);

		innerTable3.addCell(innerTable3Cell1);
		innerTable3.addCell(innerTable3Cell2);
		innerTable3.addCell(innerTable3Cell3);
		return innerTable3;
	}
    /**
     * Returns customer metadata summary
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @param profile the profile
     * @param invoiceType the invoiceType
     * @return PdfPTable
     * @throws DocumentException
     */
	private PdfPTable getInnerTable2forC9(final OrderDetails orderDetails, final AgilentOrder lastOrder,
			final String pageName, final AgilentProfile profile, final String invoiceType, AgilentOrder webOrder) throws DocumentException {
		PdfPTable innerTable2 = new PdfPTable(2);
		innerTable2.setWidths(new float[] { 55, 45 });
		PdfPCell innerTable2Cell2 = new PdfPCell();
		String soldToNum = null;
		RepositoryItem orderInvoiceItem = null;
        if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName)) {
   			soldToNum = orderDetails.getOrderSoldToNumber();
   			 orderInvoiceItem = webOrder.getOrderInvoiceItem();

   		} else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
   			soldToNum = lastOrder.getSoldToNumber();
   			 orderInvoiceItem = lastOrder.getOrderInvoiceItem();
   		}
        
        
        Map<String, String> invoiceDetailsMap = null;
        if(orderInvoiceItem == null) {
        	invoiceDetailsMap = getOrderManagerHelper().fetchInvoiceDetailsForSoldTo(soldToNum, profile);
        }
  		
   		String contactorName2 = null;
   		String contactorPhNum2 = null;
   		String address1 = null;
   		String bankName1 = null;
   		String bankAccount1 = null;
   		String companyTaxCode1 = null;
   		String customerName1 = null;
   		// Get invoice information from profile.
   		if (orderInvoiceItem != null) {
			companyTaxCode1 = (String) orderInvoiceItem.getPropertyValue(Constants.COMPANY_TAX_CODE1);
			address1 = (String) orderInvoiceItem.getPropertyValue(Constants.ADDRESS1);
			bankName1 = (String) orderInvoiceItem.getPropertyValue(Constants.BANK_NAME1);
			bankAccount1 = (String) orderInvoiceItem.getPropertyValue(Constants.BANK_ACCOUNT1);
			contactorName2 = (String) orderInvoiceItem.getPropertyValue(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = (String) orderInvoiceItem.getPropertyValue(Constants.CONTACTOR_PHNUM2);
			customerName1 = (String) orderInvoiceItem.getPropertyValue(Constants.CUSTOMER_NAME1);

		}
   		else if (invoiceDetailsMap != null && !invoiceDetailsMap.isEmpty()) {
			companyTaxCode1 = invoiceDetailsMap.get(Constants.COMPANY_TAX_CODE1);
			address1 = invoiceDetailsMap.get(Constants.ADDRESS1);
			bankName1 = invoiceDetailsMap.get(Constants.BANK_NAME1);
			bankAccount1 = invoiceDetailsMap.get(Constants.BANK_ACCOUNT1);
			contactorName2 = invoiceDetailsMap.get(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = invoiceDetailsMap.get(Constants.CONTACTOR_PHNUM2);
			customerName1 = invoiceDetailsMap.get(Constants.CUSTOMER_NAME1);

		} else {
			companyTaxCode1 = (String) profile.getPropertyValue(Constants.COMPANY_TAX_CODE1);
			address1 = (String) profile.getPropertyValue(Constants.ADDRESS1);
			bankName1 = (String) profile.getPropertyValue(Constants.BANK_NAME1);
			bankAccount1 = (String) profile.getPropertyValue(Constants.BANK_ACCOUNT1);
			contactorName2 = (String) profile.getPropertyValue(Constants.CONTACTOR_NAME2);
			contactorPhNum2 = (String) profile.getPropertyValue(Constants.CONTACTOR_PHNUM2);
			customerName1 = (String) profile.getPropertyValue(Constants.CUSTOMER_NAME1);
			System.out.println("test34");
		}


		Phrase soldToPhrase = new Phrase(getSoldToAccountNameKey(), new Font(condensedregularBaseFont, 9));
		Phrase soldToAddressPhrase = new Phrase(getSoldToAccountAddressKey(), new Font(condensedregularBaseFont, 9));
		Phrase emptyPhrase = new Phrase(" ", new Font(condensedregularBaseFont, 9));
		Phrase bankNamePhrase = new Phrase(getCustomerBankNameKey(), new Font(condensedregularBaseFont, 9));
		Phrase invoiceTypePhrase = new Phrase(getCustomerInvoiceTypeKey(), new Font(condensedregularBaseFont, 9));
		if ("orderDetailsPage".equalsIgnoreCase(pageName) && (null != orderDetails.getInternationalBillAddress()) && !orderDetails.getInternationalBillAddress().isEmpty()) {
			soldToPhrase.add(new Phrase(
					":" + orderDetails.getInternationalBillAddress().get(0).getCompanyName()
							+ orderDetails.getInternationalBillAddress().get(0).getAddress3(),
					new Font(condensedregularBaseFont, 9)));
			soldToAddressPhrase.add(new Phrase(
					":" + orderDetails.getInternationalBillAddress().get(0).getCity()
							+ orderDetails.getInternationalBillAddress().get(0).getAddress1(),
					new Font(condensedregularBaseFont, 9)));
			invoiceTypePhrase
					.add(new Phrase(":" + getZhInvoiceType(invoiceType.trim()), new Font(condensedregularBaseFont, 9)));
		} else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			PurchaseOrderPaymentGroup poPG = null;
			PaymentGroup payGroup = (PaymentGroup) lastOrder.getPaymentGroups().get(0);

			if (payGroup instanceof PurchaseOrderPaymentGroup) {
				poPG = (PurchaseOrderPaymentGroup) payGroup;
			}
			soldToPhrase.add(new Phrase(":" + poPG.getPayerCompanyName() + poPG.getPayerAddress2(),
					new Font(condensedregularBaseFont, 9)));
			soldToAddressPhrase.add(new Phrase(":" + poPG.getPayerCity() + poPG.getPayerAddress1(),
					new Font(condensedregularBaseFont, 9)));
			invoiceTypePhrase.add(new Phrase(":" + getZhInvoiceType(lastOrder.getInvoiceType().trim()),
					new Font(condensedregularBaseFont, 9)));
		}

		PdfPCell innerTable2Cell3 = new PdfPCell();
		bankNamePhrase.add(new Phrase(":" + bankName1,
				new Font(condensedregularBaseFont, 9)));

		Phrase contactPersonPhrase = new Phrase(getInvoiceContactPersonNameKey() ,
				new Font(condensedregularBaseFont, 9));
		contactPersonPhrase.add(new Phrase(":" + contactorName2,
				new Font(condensedregularBaseFont, 9)));
		Phrase bankAccountPhrase = new Phrase(getCustomerBankAccountKey(), new Font(condensedregularBaseFont, 9));
		bankAccountPhrase.add(new Phrase(":" + bankAccount1,
				new Font(condensedregularBaseFont, 9)));

		Phrase contactPersonPhonePhrase = new Phrase(getInvoiceContactPersonPhoneKey(),
				new Font(condensedregularBaseFont, 9));
		contactPersonPhonePhrase.add(new Phrase(":" + contactorPhNum2,
				new Font(condensedregularBaseFont, 9)));
		Phrase taxCodePhrase = new Phrase(getCustomerTaxCodeKey(), new Font(condensedregularBaseFont, 9));
		taxCodePhrase.add(new Phrase(":" + companyTaxCode1,
				new Font(condensedregularBaseFont, 9)));

		Phrase invoiceCustomerNamePhrase = new Phrase(getInvoiceCustomerNameKey(),
				new Font(condensedregularBaseFont, 9));
		System.out.println("test454");
		invoiceCustomerNamePhrase.add(new Phrase(":" + customerName1,
				new Font(condensedregularBaseFont, 9)));

		Phrase invoiceAddressPhrase = new Phrase(getInvoiceAddressKey(), new Font(condensedregularBaseFont, 9));
		invoiceAddressPhrase
				.add(new Phrase(":" + address1, new Font(condensedregularBaseFont, 9)));

		innerTable2Cell2.addElement(soldToPhrase);
		innerTable2Cell2.addElement(soldToAddressPhrase);
		innerTable2Cell2.addElement(contactPersonPhrase);
		innerTable2Cell2.addElement(contactPersonPhonePhrase);
		innerTable2Cell2.addElement(invoiceCustomerNamePhrase);
		innerTable2Cell2.addElement(invoiceAddressPhrase);
		innerTable2Cell3.addElement(emptyPhrase);
		innerTable2Cell3.addElement(bankNamePhrase);
		innerTable2Cell3.addElement(bankAccountPhrase);
		innerTable2Cell3.addElement(taxCodePhrase);
		innerTable2Cell3.addElement(invoiceTypePhrase);
		innerTable2Cell2.setBorder(PdfPCell.NO_BORDER);
		innerTable2.addCell(innerTable2Cell2);
		innerTable2Cell3.setBorder(PdfPCell.NO_BORDER);
		innerTable2.addCell(innerTable2Cell3);

		return innerTable2;
	}

    private String getZhInvoiceType(String invoiceType) {
    	vlogDebug("getZhInvoiceType()- invoiceType: {0}", invoiceType);
    	if (invoiceType!=null && invoiceType.equalsIgnoreCase(getCustomerInvoiceTypeNormalEn())) {
    		vlogDebug("ZhInvoiceType: {0}", getCustomerInvoiceTypeNormalZh());
    		return getCustomerInvoiceTypeNormalZh();
    	}
    	if (invoiceType!=null && invoiceType.equalsIgnoreCase(getCustomerInvoiceTypeSpecialEn())) {
    		vlogDebug("ZhInvoiceType: {0}", getCustomerInvoiceTypeSpecialZh());
    		return getCustomerInvoiceTypeSpecialZh();
    	}
    	if (invoiceType!=null && invoiceType.equalsIgnoreCase(getCustomerNormalPaperInvoiceEn())) {
    		vlogDebug("ZhInvoiceType: {0}", getCustomerNormalPaperInvoiceZh());
    		return getCustomerNormalPaperInvoiceZh();
    	}
    	if (invoiceType!=null && invoiceType.equalsIgnoreCase(getCustomerSpecialEinvoiceEn())) {
    		vlogDebug("ZhInvoiceType: {0}", getCustomerSpecialEinvoiceZh());
    		return  getCustomerSpecialEinvoiceZh();
    	}
    	return invoiceType;
    }
    
    private PdfPTable getOrderDetailsHeader() {
    	return getOrderDetailsHeader (null);
    }
    
    /**
     * Adds order details section header.
     * 
     * @return PdfPTable
     */
    private PdfPTable getOrderDetailsHeader(String salesOrg) {
        PdfPTable orderDetailsHeader = new PdfPTable(1);
        orderDetailsHeader.setSplitLate(false);
        orderDetailsHeader.setWidthPercentage(100);
        orderDetailsHeader.setSpacingBefore(10);
        orderDetailsHeader.setSpacingAfter(10);
        
        PdfPCell orderDetailsHeaderCell1 = new PdfPCell(new Phrase(getParagraphOne(), new Font(condensedregularBaseFont, 9)));
        orderDetailsHeaderCell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        orderDetailsHeaderCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
        	//orderDetailsHeaderCell1.setPaddingLeft(5);
        }else{
            orderDetailsHeaderCell1.setPaddingLeft(5);
        }
        orderDetailsHeaderCell1.setFixedHeight(15);
        orderDetailsHeaderCell1.setBorder(PdfPCell.NO_BORDER);
       
        orderDetailsHeader.addCell(orderDetailsHeaderCell1);
        return orderDetailsHeader;
    }

    /**
     * Adds order details table header and order details to the table.
     * 
     * @param orderDetails the orderDetails
     * @param pageName the pageName
     * @param lastOrder the lastOrder
     * @return PdfPTable
     * @throws DocumentException
     */
    private PdfPTable getInnerTable3(final OrderDetails orderDetails, final String pageName,
    		final AgilentOrder lastOrder) throws DocumentException {
        PdfPTable innerTable3 = new PdfPTable(9);        
        innerTable3.setSplitLate(false);
        innerTable3.setWidthPercentage(100);
        innerTable3.setWidths(new float[] {8, 18, 33, 33,16, 12, 16, 16, 16});
        
        String salesOrg = evaluateSalesOrgForChinaPDF(orderDetails, lastOrder, pageName);

        PdfPCell innerTable3Cell1 = new PdfPCell(new Phrase(getLineNo(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell1.setFixedHeight(30);

        PdfPCell innerTable3Cell2 = new PdfPCell(new Phrase(getProductNumber(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable3Cell2.setFixedHeight(30);

        PdfPCell innerTable3Cell3 = new PdfPCell(new Phrase(getProductDescEnglish(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell3.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell innerTable3Cell4 = new PdfPCell(new Phrase(getProductDescChinese(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        //DCCOM-21788 - enhancements to PDF
       
    	PdfPCell innerTable3Cell10 = new PdfPCell(new Phrase(getProductLineForC9(), new Font(condensedregularBaseFont, 9)));
    	innerTable3Cell10.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        PdfPCell innerTable3Cell12 = new PdfPCell(new Phrase(getProductLine(), new Font(condensedregularBaseFont, 9)));
    	innerTable3Cell12.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell12.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell innerTable3Cell5 = new PdfPCell(new Phrase(getQuantity(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell5.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell5.setHorizontalAlignment(Element.ALIGN_LEFT);

//        PdfPCell innerTable3Cell6 = new PdfPCell(new Phrase(getStockStatus(), new Font(condensedregularBaseFont, 9)));
//        innerTable3Cell6.setVerticalAlignment(Element.ALIGN_TOP);
//        innerTable3Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell innerTable3Cell7 = new PdfPCell(new Phrase(getListPrice(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell7.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell innerTable3Cell8 = new PdfPCell(new Phrase(getYourPrice(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell8.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell innerTable3Cell9 = new PdfPCell(new Phrase(getTotalPrice(), new Font(condensedregularBaseFont, 9)));
        innerTable3Cell9.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable3Cell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        innerTable3.addCell(innerTable3Cell1);
        innerTable3.addCell(innerTable3Cell2);
        innerTable3.addCell(innerTable3Cell3);
        innerTable3.addCell(innerTable3Cell4);
        innerTable3.addCell(innerTable3Cell12);
        innerTable3.addCell(innerTable3Cell5);
//        innerTable3.addCell(innerTable3Cell6);
        innerTable3.addCell(innerTable3Cell7);
        innerTable3.addCell(innerTable3Cell8);
        innerTable3.addCell(innerTable3Cell9);
        ArrayList<String> partNumberList = new ArrayList<String>();
        if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
        	List<LineItem> orderLineItems = orderDetails.getItems();
        	Map<String, BigDecimal> stockStatusMap = new LinkedHashMap<String, BigDecimal>();
        	stockStatusMap = getSapManager().getStockStatus(orderLineItems);
        	
        	for (LineItem lItem : orderLineItems) {
				String partNumber = lItem.getCatId();
				if (StringUtils.isNotEmpty(partNumber)) {
					partNumberList.add(partNumber);
				}
			}
        	
            for (int i = 1; i <= orderLineItems.size(); i++) {
                addProductDetailCells(innerTable3, i, orderLineItems.get(i - 1), null, "CNY", stockStatusMap, salesOrg);
            }
            
            
		} else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			List<CommerceItem> orderLineItems = lastOrder.getCommerceItems();
			for (CommerceItem cItem : orderLineItems) {
				String partNumber = (String) ((RepositoryItem) cItem.getAuxiliaryData().getCatalogRef())
						.getPropertyValue(Constants.CATALOG_ID);
				if (StringUtils.isNotEmpty(partNumber)) {
					partNumberList.add(partNumber);
				}
			}
			
			for (int i = 1; i <= orderLineItems.size(); i++) {
				addProductDetailCells(innerTable3, i, null, orderLineItems.get(i - 1), "CNY", null, salesOrg);
			}

		}
        return innerTable3;
    }

    /**
     * Adds individual order details to the table.
     * 
     * @param table the table
     * @param id the id
     * @param lineItem the lineItem
     * @param commerceItem the commerceItem
     * @param pQuoteCurrency the pQuoteCurrency
     */
	private void addProductDetailCells(final PdfPTable table, final int id, 
			final LineItem lineItem, final CommerceItem commerceItem, final String pQuoteCurrency,
			final Map<String, BigDecimal> stockStatusMap, final String salesOrg) {
		Locale currencyLocale = Locale.US;
		int paddingValue = 10;
		String productNumber = null;
		String productENDescription = null;
		String productCNDescription = null;
		long quantity = 0;
		int stockStatus = 0;
		double listPrice = 0;
		double yourPrice = 0;
		double totalPrice = 0;
		vlogDebug("TotalPrice",totalPrice);
		String productLineChinese = null;
		
		if (getCurrencyCodeToLocaleMap().containsKey(pQuoteCurrency)) {
			currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(pQuoteCurrency));
		}

		if (null != lineItem) {
			productNumber = lineItem.getCatId();
			productENDescription = lineItem.getProductDescEN();
			productCNDescription = lineItem.getProductDescCN();
			// quantity = lineItem.getReqQuantity();
			// Fix for UAT-1177
			quantity = lineItem.getQuantity();
			stockStatus = stockStatusMap.get(lineItem.getCatId()).intValue();
			listPrice = lineItem.getListPrice();
			//DCCOM-21719 - fix for your price in order details page
			yourPrice = lineItem.getUnitPrice();
			//yourPrice = lineItem.getYourPrice();
			totalPrice = lineItem.getYourPrice();
			RepositoryItem skuItem = getCatalogTools().getSkuFromCatalogId(productNumber);
			productLineChinese = fetchTranslatedProductline(skuItem);
			
			
			
		} else if (null != commerceItem) {
			productNumber = (String) ((RepositoryItem) commerceItem.getAuxiliaryData().getCatalogRef())
					.getPropertyValue(Constants.CATALOG_ID);
			productENDescription = ((AgilentCommerceItem)commerceItem).getProductDescEN();
			productCNDescription = ((AgilentCommerceItem)commerceItem).getProductDescCN();
			RepositoryItem skuItem = (RepositoryItem) commerceItem.getAuxiliaryData().getCatalogRef();
			productLineChinese = fetchTranslatedProductline(skuItem);
			
			productLineChinese = fetchTranslatedProductline(skuItem);
			
			quantity = commerceItem.getQuantity();
			/*if (commerceItem instanceof AgilentCommerceItem) {
				stockStatus = ((AgilentCommerceItem) commerceItem).getStockStatus();
			} else if (commerceItem instanceof AgilentConfigurableCommerceItem) {
				stockStatus = ((AgilentConfigurableCommerceItem) commerceItem).getStockStatus();
			}*/
			listPrice = commerceItem.getPriceInfo().getListPrice();
			if (commerceItem.getPriceInfo().isDiscounted()) {
				yourPrice = ((AgilentItemPriceInfo) commerceItem.getPriceInfo()).getDiscountPrice();
			} else {
				yourPrice = ((AgilentItemPriceInfo) commerceItem.getPriceInfo()).getYourPrice();
			}
			//yourPrice = commerceItem.getPriceInfo().getAmount();
			totalPrice = commerceItem.getPriceInfo().getAmount();
		}
		PdfPCell lineNumberCell = new PdfPCell(new Phrase(String.valueOf(id), new Font(condensedregularBaseFont, 9)));
		lineNumberCell.setPaddingTop(paddingValue);
		lineNumberCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell productCell = new PdfPCell(new Phrase(productNumber, new Font(condensedregularBaseFont, 9)));
		productCell.setPaddingTop(paddingValue);
		productCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		Phrase productPhrase = new Phrase(
				new Chunk(String.valueOf(productENDescription), new Font(condensedregularBaseFont, 9)));
		PdfPCell productENDescriptionCell = new PdfPCell(productPhrase);
		productENDescriptionCell.setPaddingTop(paddingValue);
		productENDescriptionCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		Phrase productCNPhrase = new Phrase(
				new Chunk(String.valueOf(productCNDescription), new Font(condensedregularBaseFont, 9)));
		PdfPCell productCNDescriptionCell = new PdfPCell(productCNPhrase);
		productCNDescriptionCell.setPaddingTop(paddingValue);
		productCNDescriptionCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell productLineChineseCell = new PdfPCell(new Phrase(String.valueOf(productLineChinese), new Font(condensedregularBaseFont, 9)));
		productLineChineseCell.setPaddingTop(paddingValue);
		productLineChineseCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		
		PdfPCell qtyCell = new PdfPCell(new Phrase(String.valueOf(quantity), new Font(condensedregularBaseFont, 9)));
		qtyCell.setPaddingTop(paddingValue);
		qtyCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

//		PdfPCell stockCell = new PdfPCell(
//				new Phrase(String.valueOf(stockStatus), new Font(condensedregularBaseFont, 9)));
//		stockCell.setPaddingTop(paddingValue);
//		stockCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell listPriceCell = new PdfPCell(
				new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(listPrice, currencyLocale, true),
						new Font(condensedregularBaseFont, 9)));
		listPriceCell.setPaddingTop(paddingValue);
		listPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell yourPriceCell = new PdfPCell(
				new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(yourPrice, currencyLocale, true),
						new Font(condensedregularBaseFont, 9)));
		yourPriceCell.setPaddingTop(paddingValue);
		yourPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		PdfPCell totalPriceCell = new PdfPCell(
				new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(totalPrice, currencyLocale, true),
						new Font(condensedregularBaseFont, 9)));
		totalPriceCell.setPaddingTop(paddingValue);
		totalPriceCell.setVerticalAlignment(Element.ALIGN_MIDDLE);

		table.addCell(lineNumberCell);
		table.addCell(productCell);
		table.addCell(productENDescriptionCell);
		table.addCell(productCNDescriptionCell);
		table.addCell(productLineChineseCell);
		table.addCell(qtyCell);
//		table.addCell(stockCell);
		table.addCell(listPriceCell);
		table.addCell(yourPriceCell);
		table.addCell(totalPriceCell);
	}
	
	/**
     * Adds order total details to the PDF.
     * 
     * @param orderDetails the orderDetails
     * @param pageName the pageName
     * @param lastOrder the lastOrder
     * @return PdfPTable
     * @throws DocumentException
     */
    private PdfPTable getTotalDetails(final OrderDetails orderDetails, final String pageName,
    		final AgilentOrder lastOrder) throws DocumentException {
		Locale currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get("CNY"));
		
		double totalAmount = 0;
		double shippingHandling = 0;
		double totalAmountWithTax = 0;
		
		if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
			totalAmount = orderDetails.getSubTotal();
			shippingHandling = orderDetails.getShippingTotal();
			totalAmountWithTax = orderDetails.getOrderTotal();
        } else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
        	totalAmount = lastOrder.getPriceInfo().getAmount();
        	shippingHandling = lastOrder.getPriceInfo().getShipping();
        	totalAmountWithTax = lastOrder.getPriceInfo().getTotal();
        }
		
        PdfPTable orderDetialsTable = new PdfPTable(3);
        orderDetialsTable.setSplitLate(true);
        orderDetialsTable.setWidthPercentage(100);
        orderDetialsTable.setSpacingBefore(20);
        orderDetialsTable.setWidths(new float[] {6, 3, 1});
      
        PdfPCell emptyCell = new PdfPCell();
        emptyCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell subTotalTextCell = new PdfPCell(new Phrase(getTotalAmount(), new Font(condensedregularBaseFont, 9)));
        subTotalTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        subTotalTextCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell subTotalCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(totalAmount, currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        subTotalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        subTotalCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell shippingAndHandlingTextCell = new PdfPCell(new Phrase(getShippingHandling(), new Font(condensedregularBaseFont, 9)));
        shippingAndHandlingTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        shippingAndHandlingTextCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell shippingAndHandlingCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(shippingHandling, currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        shippingAndHandlingCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        shippingAndHandlingCell.setBorder(PdfPCell.NO_BORDER);

        PdfPCell quotationTotalTextCell = new PdfPCell(new Phrase(getTotalAmountWithTax(), new Font(condensedregularBaseFont, 9)));
        quotationTotalTextCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        quotationTotalTextCell.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell quotationTotalCell = new PdfPCell(new Phrase(AgilentCurrencyTagConverter.noSymbFormatCurrency(totalAmountWithTax, currencyLocale, true), new Font(condensedregularBaseFont, 9)));
        quotationTotalCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        quotationTotalCell.setBorder(PdfPCell.NO_BORDER);

    	orderDetialsTable.addCell(emptyCell);
        orderDetialsTable.addCell(subTotalTextCell);
        orderDetialsTable.addCell(subTotalCell);
        orderDetialsTable.addCell(emptyCell);
        orderDetialsTable.addCell(shippingAndHandlingTextCell);
        orderDetialsTable.addCell(shippingAndHandlingCell);
        orderDetialsTable.addCell(emptyCell);
        orderDetialsTable.addCell(quotationTotalTextCell);
        orderDetialsTable.addCell(quotationTotalCell);

        return orderDetialsTable;
    }

    /**
     * Adds shipping details to the PDF.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     * @throws DocumentException
     */
    private PdfPTable getShippingDetailsTable(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName, AgilentOrder webOrder) throws DocumentException {
    	
    	String shipToAccountName = null;
    	String shippingContactPerson = " ";
    	String shippingContactPersonPhone = " ";
    	String shipToAccountAddress = null;
    	String postalCode = null;
//		Fix for UAT-1184 
//    	if(profile != null){
//    		if(profile.getPropertyValue("firstName") != null) {
//    		shippingContactPerson = (String) profile.getPropertyValue("firstName");
//    		}
//    		if(profile.getPropertyValue("shippingAddress") != null) {
//    		RepositoryItem contactInfo = (RepositoryItem)profile.getPropertyValue("shippingAddress");
//    		if(contactInfo != null) {
//    			shippingContactPersonPhone = (String) contactInfo.getPropertyValue("phoneNumber");
//    		}
//    		}
//    	   
//    		}
    	
    	//Fix for UAT - 1184 && UAT-1298
		if(webOrder != null) {
			
			AgilentHardGoodShippingGroup ahgsg = (AgilentHardGoodShippingGroup) webOrder.getShippingGroups().get(0);
			if(ahgsg != null)
			{
				shippingContactPerson = ahgsg.getAttentionSP();
				shippingContactPersonPhone = ahgsg.getPhoneNumberSP();
			}
		}
    	if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
    		//Fix for UAT - 1185
//    		shipToAccountName = orderDetails.getShippingAddress().get(0).getCompanyName();
//    		shippingContactPerson = orderDetails.getShippingAddress().get(0).getFirstName();
//    		shippingContactPersonPhone = orderDetails.getShippingAddress().get(0).getPhoneNumber();
//    		shipToAccountAddress = orderDetails.getShippingAddress().get(0).getAddress1();
//    		postalCode = orderDetails.getShippingAddress().get(0).getPostalCode();
    		if(orderDetails.getInternationalShipAddress()!=null && !orderDetails.getInternationalShipAddress().isEmpty()){
    		shipToAccountName = orderDetails.getInternationalShipAddress().get(0).getCompanyName();
//    		shippingContactPerson = orderDetails.getInternationalShipAddress().get(0).getFirstName();
//    		shippingContactPersonPhone = orderDetails.getInternationalShipAddress().get(0).getPhoneNumber();
    		shipToAccountAddress = orderDetails.getInternationalShipAddress().get(0).getCity() + orderDetails.getInternationalShipAddress().get(0).getAddress1();
    		postalCode = orderDetails.getInternationalShipAddress().get(0).getPostalCode();
    		}
        } else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
        	ContactInfo orderAddress = null;
        	ShippingGroup shipGroup = (ShippingGroup) lastOrder.getShippingGroups().get(0);
        	if (shipGroup instanceof HardgoodShippingGroup) {
                HardgoodShippingGroup hgSG = (HardgoodShippingGroup) shipGroup;
                orderAddress = (ContactInfo) hgSG.getShippingAddress();
        	}
        	shipToAccountName = orderAddress.getCompanyName();
//        	shippingContactPerson = orderAddress.getFirstName();
//        	shippingContactPersonPhone = orderAddress.getPhoneNumber();
        	shipToAccountAddress = orderAddress.getCity() + orderAddress.getAddress1();
        	postalCode = orderAddress.getPostalCode();
        }
    	
        PdfPTable shippingDetialsTable = new PdfPTable(6);
        shippingDetialsTable.setSplitLate(false);
        shippingDetialsTable.setWidthPercentage(100);
        shippingDetialsTable.setSpacingBefore(5);
        shippingDetialsTable.setWidths(new float[] {8, 24, 8, 16, 8, 16});
        
        PdfPCell shippingDetialsTableCell1 = new PdfPCell(new Phrase(getShipToAccountName(), new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell1.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        PdfPCell shippingDetialsTableCell2 = new PdfPCell(new Phrase(shipToAccountName, new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell2.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell2.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell shippingDetialsTableCell3 = new PdfPCell(new Phrase(getShippingContactPerson(), new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell3.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        PdfPCell shippingDetialsTableCell4 = new PdfPCell(new Phrase(shippingContactPerson, new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell4.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell4.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell shippingDetialsTableCell5 = new PdfPCell(new Phrase(getShippingContactPersonPhone(), new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell5.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        
        PdfPCell shippingDetialsTableCell6 = new PdfPCell(new Phrase(shippingContactPersonPhone, new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell6.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell6.setHorizontalAlignment(Element.ALIGN_LEFT);

        PdfPCell shippingDetialsTableCell7 = new PdfPCell(new Phrase(getShipToAccountAddress(), new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell7.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        shippingDetialsTableCell7.setColspan(1);
        
        PdfPCell shippingDetialsTableCell8 = new PdfPCell(new Phrase(shipToAccountAddress, new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell8.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        shippingDetialsTableCell8.setColspan(3);
        
        PdfPCell shippingDetialsTableCell9 = new PdfPCell(new Phrase(getPostalCode(), new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell9.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        shippingDetialsTableCell9.setColspan(1);
        
        PdfPCell shippingDetialsTableCell10 = new PdfPCell(new Phrase(postalCode, new Font(condensedregularBaseFont, 9)));
        shippingDetialsTableCell10.setVerticalAlignment(Element.ALIGN_TOP);
        shippingDetialsTableCell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        shippingDetialsTableCell10.setColspan(1);
        
        shippingDetialsTable.addCell(shippingDetialsTableCell1);
        shippingDetialsTable.addCell(shippingDetialsTableCell2);
        shippingDetialsTable.addCell(shippingDetialsTableCell3);
        shippingDetialsTable.addCell(shippingDetialsTableCell4);
        shippingDetialsTable.addCell(shippingDetialsTableCell5);
        shippingDetialsTable.addCell(shippingDetialsTableCell6);
        shippingDetialsTable.addCell(shippingDetialsTableCell7);
        shippingDetialsTable.addCell(shippingDetialsTableCell8);
        shippingDetialsTable.addCell(shippingDetialsTableCell9);
        shippingDetialsTable.addCell(shippingDetialsTableCell10);
    	
    	
        return shippingDetialsTable;
    }

    /**
     * Returns chinese font.
     * 
     * @return BaseFont
     * @throws DocumentException
     * @throws IOException
     */
    public BaseFont getRoboFont() throws DocumentException, IOException {
        BaseFont robotoFont = BaseFont.createFont(CHINESE_FONT_STD, CHINESE_ENCODING, BaseFont.NOT_EMBEDDED);
        return robotoFont;
    }

    
    /**
     * Adds China stamp image on the PDF.
     * 
     * @param reader the reader
     * @param stamper the stamper
     * @param finalImagePath the finalImagePath
     * @param userCountry the userCountry
     * @throws MalformedURLException
     * @throws IOException
     * @throws DocumentException
     */
   
    public void addStampImageOnPDF(final PdfReader reader, final PdfStamper stamper,
    		final String finalImagePath, final String salesOrg ) throws MalformedURLException, IOException, DocumentException {
        vlogDebug("adding stamp image to PDF for country {0}", salesOrg);
        String ImageScalesize = "";
        String ImageHorizontalPosition = "";
        String ImageVerticalPosition = "";
        Image image = Image.getInstance(finalImagePath);
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
            if ((reader.getNumberOfPages() - 2) == i) {
            PdfContentByte contentByte = stamper.getOverContent(i);
            PdfReaderContentParser parser = new PdfReaderContentParser(reader);
            TextMarginFinder finder = parser.processContent(i, new TextMarginFinder());
            vlogDebug("adding image for page {0}", i);
            ImageScalesize = getImageScaleSize();
	        ImageHorizontalPosition = getImageHorizontalPosition();
	        ImageVerticalPosition = getImageVerticalPosition();
            image.scalePercent(Integer.parseInt(ImageScalesize));
            vlogInfo("X axis " + finder.getLlx() + " actual x axis position " + Integer.parseInt(ImageHorizontalPosition) + " Y axis " + finder.getLly());
            image.setAbsolutePosition(Integer.parseInt(ImageHorizontalPosition), Integer.parseInt(ImageVerticalPosition));
            contentByte.addImage(image);
            }
        }
    }
    
    public void addStampImageOnChinaPDF(final PdfReader reader, final PdfStamper stamper,
    		final String finalImagePath, final Integer yCoordinate) throws MalformedURLException, IOException, DocumentException {
        vlogDebug("adding stamp image to PDF for saleorg 04C9");
        String ImageScalesize = "";
        String ImageHorizontalPosition = "";
        //String ImageVerticalPosition = "";
        Image image = Image.getInstance(finalImagePath);
        for (int i = 1; i <= reader.getNumberOfPages(); i++) {
           if ((reader.getNumberOfPages()) == i) {
            PdfContentByte contentByte = stamper.getOverContent(i);
            PdfReaderContentParser parser = new PdfReaderContentParser(reader);
            TextMarginFinder finder = parser.processContent(i, new TextMarginFinder());
            vlogDebug("adding image for page {0}", i);
           // ImageHorizontalPosition = Integer.toString((Integer.parseInt(getImageHorizontalPosition())));
          //  ImageVerticalPosition = Integer.toString((Integer.parseInt(getImageVerticalPosition())-290));
            ImageHorizontalPosition = getAttsHorizontalPosition();
            //ImageVerticalPosition = getAttsVerticalPosition();
            ImageScalesize = getImageScaleForC9();
            image.scalePercent(Integer.parseInt(ImageScalesize));
            vlogInfo("X axis " + finder.getLlx() + " actual x axis position " + Integer.parseInt(ImageHorizontalPosition) + " Y axis " + finder.getLly());
            image.setAbsolutePosition(Integer.parseInt(ImageHorizontalPosition),yCoordinate);
            contentByte.addImage(image);
        	}
        }
    }
    
	public void addStampImageOnCNPDF(final PdfReader reader, final PdfStamper stamper, final String finalImagePath,
			final Integer yCoordinate) throws MalformedURLException, IOException, DocumentException {
		vlogDebug("adding stamp image to PDF for saleorg 04CN");
		String ImageScalesize = "";
		String ImageHorizontalPosition = "";
		Image image = Image.getInstance(finalImagePath);
		for (int i = 1; i <= reader.getNumberOfPages(); i++) {
			if ((reader.getNumberOfPages()) == i) {
				PdfContentByte contentByte = stamper.getOverContent(i);
				PdfReaderContentParser parser = new PdfReaderContentParser(reader);
				TextMarginFinder finder = parser.processContent(i, new TextMarginFinder());
				vlogDebug("adding image for page {0}", i);
				ImageHorizontalPosition = getImageHorizontalPosition();
				ImageScalesize = getImageScaleSizeForCN();
				image.scalePercent(Integer.parseInt(ImageScalesize));
				vlogInfo("X axis " + finder.getLlx() + " actual x axis position "
						+ Integer.parseInt(ImageHorizontalPosition) + " Y axis " + finder.getLly() + "actual y position"
						+ yCoordinate);
				image.setAbsolutePosition(Integer.parseInt(ImageHorizontalPosition), yCoordinate);
				contentByte.addImage(image);
			}
		}
	}

    /**
     * Adds static section between the tables.
     * 
     * @return PdfPTable
     * @throws DocumentException 
     */
    private PdfPTable getInnerTable4(){
    	return getInnerTable4(null,null);
    }
    /**
     * Adds static section between the tables for 04C9 salesorg.
     * @param salesOrg
     * @return PdfPTable
     * @throws DocumentException 
     */
    private PdfPTable getInnerTable4(String salesOrg, final AgilentOrder lastOrder) {
       vlogDebug("PdfChinaOrderDownloadHelper PdfPTable getInnerTable4 --START--");
        String orderType = null;
        int startCount = 1;
        orderType = orderTypeByProductLine(lastOrder);
        PdfPTable innerTable4 = new PdfPTable(1);
        innerTable4.setSplitLate(false);
        innerTable4.setWidthPercentage(100);

        PdfPCell innerTable4Cell1 = new PdfPCell(new Phrase(getMiddleLineTextForC9(), new Font(condensedregularBaseFont, 9)));
        innerTable4Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable4Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell1.setPaddingLeft(50);
        innerTable4Cell1.setFixedHeight(15);
        innerTable4Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell1);

        PdfPCell innerTable4Cell2 = new PdfPCell();
        Phrase paragraph2 = new Phrase();
        Phrase phrase1 = new Phrase(new Phrase(paragraphCount(startCount), new Font(condensedregularBaseFont, 9)));
        Phrase phrase2 = new Phrase();
        
        if (StringUtils.isNotBlank(salesOrg) && getSalesOrgListForRUO().contains(salesOrg)) {
            StringBuilder sb= new StringBuilder();
            if (DGG_AND_LSAG.equalsIgnoreCase(orderType)) {
                sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9()).append(getParagraphTwoForC9LSAG());
            } else if (DGG.equalsIgnoreCase(orderType)) {
                sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9());
            } else if (LSAG.equalsIgnoreCase(orderType)) {
                sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9LSAG());
            }
            phrase2 = new Phrase(sb.toString(), new Font(condensedregularBaseFont, 9));
        } else {
            phrase2 = new Phrase(getParagraphTwo(), new Font(condensedregularBaseFont, 9));
        }
        paragraph2.add(phrase1);
        
        paragraph2.add(phrase2);
        innerTable4Cell2.addElement(paragraph2);
        innerTable4Cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable4Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell2.setPaddingLeft(5);
        innerTable4Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell2);

        if (StringUtils.isNotBlank(salesOrg) && getSalesOrgListForRUO().contains(salesOrg)) {
            paraThreeFormationForC9(orderType, innerTable4);
        }

        PdfPCell innerTable4Cell3 = new PdfPCell();
        Phrase paragraph4 = new Phrase();
        Phrase phrase5 = new Phrase(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        Phrase phrase6 = new Phrase(new Phrase(getParagraphThree(), new Font(condensedregularBaseFont, 9)));
        paragraph4.add(phrase5);
        paragraph4.add(phrase6);
        innerTable4Cell3.addElement(paragraph4);
        innerTable4Cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable4Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell3.setPaddingLeft(5);
        innerTable4Cell3.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell3);

        return innerTable4;
  }

    
    
    /**
     * Adds static section between the tables for 04C9 salesorg.
     * @param salesOrg
     * @return PdfPTable
     * @throws DocumentException 
     */
    private PdfPTable middleLineTextfor04C9() {
        vlogDebug("PdfChinaOrderDownloadHelper PdfPTable getInnerTable4 --START--");
        
        PdfPTable innerTable4 = new PdfPTable(1);
        innerTable4.setSplitLate(false);
        innerTable4.setWidthPercentage(100);

        PdfPCell innerTable4Cell1 = new PdfPCell(new Phrase(getMiddleLineTextForC9(), new Font(condensedregularBaseFont, 9)));
        innerTable4Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable4Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell1.setPaddingLeft(50);
        innerTable4Cell1.setFixedHeight(15);
        innerTable4Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell1);
        
        return innerTable4;
    }
    
    /**
     * Adds static section between the tables for 04C9 salesorg.
     * @param salesOrg
     * @return PdfPTable
     * @throws DocumentException 
     */
    private PdfPTable getSeparateInnerTable4for04C9(String salesOrg, final AgilentOrder lastOrder, final String pageName, AgilentOrder webOrder) throws DocumentException {
       
    vlogDebug("PdfChinaOrderDownloadHelper PdfPTable getInnerTable4 --START--");
    String orderType = null;
    int startCount = 1;
    if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName)) {
        orderType = orderTypeByProductLine(webOrder);

    } else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
        orderType = orderTypeByProductLine(lastOrder);
    }
        
    PdfPTable innerTable4 = new PdfPTable(2);
    innerTable4.setSplitLate(false);
    innerTable4.setWidthPercentage(100);
    innerTable4.setWidths(new float[] { 3, 97 });
	
    innerTable4.setSpacingBefore(0);
   
    PdfPCell innerTable4Cell0 = new PdfPCell(new Phrase(paragraphCount(startCount), new Font(condensedregularBaseFont, 9)));
    innerTable4Cell0.setVerticalAlignment(Element.ALIGN_TOP);
    innerTable4Cell0.setHorizontalAlignment(Element.ALIGN_LEFT);
    innerTable4Cell0.setPaddingTop(8);
    innerTable4Cell0.setBorder(PdfPCell.NO_BORDER);
	innerTable4.addCell(innerTable4Cell0);
	
    PdfPCell innerTable4Cell2 = new PdfPCell();
    Phrase paragraph2 = new Phrase();
    //Phrase phrase1 = new Phrase(new Phrase(paragraphCount(startCount), new Font(condensedregularBaseFont, 9)));
    Phrase phrase2 = new Phrase();
    
    if (StringUtils.isNotBlank(salesOrg) && getSalesOrgListForRUO().contains(salesOrg)) {
        StringBuilder sb= new StringBuilder();
        if (DGG_AND_LSAG.equalsIgnoreCase(orderType)) {
            sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9()).append(getParagraphTwoForC9LSAG());
        } else if (DGG.equalsIgnoreCase(orderType)) {
            sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9());
        } else if (LSAG.equalsIgnoreCase(orderType)) {
            sb.append(getParagraphTwoForC9Heading()).append(getParagraphTwoForC9LSAG());
        }
        phrase2 = new Phrase(sb.toString(), new Font(condensedregularBaseFont, 9));
    } else {
        phrase2 = new Phrase(getParagraphTwo(), new Font(condensedregularBaseFont, 9));
    }
//    paragraph2.add(phrase1);
//    paragraph2.add(emptyPhrase);
    paragraph2.add(phrase2);
    innerTable4Cell2.addElement(paragraph2);
    innerTable4Cell2.setVerticalAlignment(Element.ALIGN_TOP);
    innerTable4Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
   // innerTable4Cell2.setPaddingLeft(5);
    innerTable4Cell2.setBorder(PdfPCell.NO_BORDER);
    innerTable4.addCell(innerTable4Cell2);

    if (StringUtils.isNotBlank(salesOrg) && getSalesOrgListForRUO().contains(salesOrg)) {
        paraThreeFormationForC9(orderType, innerTable4);
    }
    
    
    PdfPCell innerTable4Cell10 = new PdfPCell(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
    innerTable4Cell10.setVerticalAlignment(Element.ALIGN_TOP);
    innerTable4Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
    innerTable4Cell10.setPaddingTop(8);
    innerTable4Cell10.setBorder(PdfPCell.NO_BORDER);
	innerTable4.addCell(innerTable4Cell10);

    PdfPCell innerTable4Cell3 = new PdfPCell();
    Phrase paragraph4 = new Phrase();
   // Phrase phrase5 = new Phrase(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
    Phrase phrase6 = new Phrase(new Phrase(getParagraphThree(), new Font(condensedregularBaseFont, 9)));
   // paragraph4.add(phrase5);
    paragraph4.add(phrase6);
    innerTable4Cell3.addElement(paragraph4);
    innerTable4Cell3.setVerticalAlignment(Element.ALIGN_TOP);
    innerTable4Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
  //  innerTable4Cell3.setPaddingLeft(5);
    innerTable4Cell3.setBorder(PdfPCell.NO_BORDER);
    innerTable4.addCell(innerTable4Cell3);

    return innerTable4;}

    /**
     * @param orderType
     * @param innerTable4
     */
    private void paraThreeFormationForC9(String orderType, PdfPTable innerTable4) {
    	
    	PdfPCell innerTable4Cell0 = new PdfPCell(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        innerTable4Cell0.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell0.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell0.setPaddingTop(8);
        innerTable4Cell0.setBorder(PdfPCell.NO_BORDER);
		innerTable4.addCell(innerTable4Cell0);
    	
    	
        PdfPCell innerTable4Cell4 = new PdfPCell();
        Phrase paragraph3 = new Phrase();
       // Phrase phrase4 = new Phrase(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        Phrase phrase5 = new Phrase(new Phrase(getParagraphThreeForC9Heading(), new Font(condensedregularBaseFont, 9)));
        Phrase phrase6 = new Phrase(new Phrase(getParagraphFiveForC9(), new Font(condensedregularBaseFont, 9)));
        Anchor anchor2 = new Anchor(getCopcEmailForChina(), new Font(condensedregularBaseFont, 9, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
        anchor2.setReference("mailto:" + getCopcEmailForChina());
        Phrase phrase7 = new Phrase(new Phrase(getParagraphFiveSub2ForC9(), new Font(condensedregularBaseFont, 9)));
        Phrase phrase8 = new Phrase(new Phrase(getParagraphThreeForC9LSAG(), new Font(condensedregularBaseFont, 9)));

        if (DGG_AND_LSAG.equalsIgnoreCase(orderType)) {
           // paragraph3.add(phrase4);
            paragraph3.add(phrase5);
            paragraph3.add(phrase6);
            paragraph3.add(anchor2);
            paragraph3.add(phrase7);
            paragraph3.add(phrase8);
        } else if (DGG.equalsIgnoreCase(orderType)) {
           // paragraph3.add(phrase4);
            paragraph3.add(phrase5);
            paragraph3.add(phrase6);
            paragraph3.add(anchor2);
            paragraph3.add(phrase7);
        } else if (LSAG.equalsIgnoreCase(orderType)) {
            //paragraph3.add(phrase4);
            paragraph3.add(phrase5);
            paragraph3.add(phrase8);
        }
        innerTable4Cell4.addElement(paragraph3);
        innerTable4Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable4Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell4.setPaddingLeft(5);
        innerTable4Cell4.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell4);
    }
    

    /**
     * Adds middle line section to the pdf.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     */
    	private PdfPTable getInnerTable4forCN(final OrderDetails orderDetails, final AgilentOrder lastOrder,
        		final String pageName, HashSet<String> productLineSet) {
        PdfPTable innerTable4 = new PdfPTable(1);
        innerTable4.setSpacingBefore(20);
        innerTable4.setWidthPercentage(100);
        PdfPCell innerTable4Cell1 = new PdfPCell();
        Paragraph paragraph1 = new Paragraph();
        Phrase p1 =new Phrase();
        
        for (String string : productLineSet) {
        	if(!string.contains(SERVICE_PL)){
        			p1 =new Phrase(getMiddleLineTextForCN(), new Font(condensedregularBaseFont, 9));
		        }else{
		           p1 =new Phrase(getMiddleLineTextForPL74(), new Font(condensedregularBaseFont, 9));
		        }
        }
        paragraph1.add(p1);
        innerTable4Cell1.addElement(paragraph1);
        innerTable4Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable4Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable4Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable4.addCell(innerTable4Cell1);
        return innerTable4;
    	}
    
    /**
     * Adds section four to the pdf.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     */
    private PdfPTable getInnerTable5(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName) {
        PdfPTable innerTable5 = new PdfPTable(1);
        innerTable5.setSplitLate(false);
        innerTable5.setWidthPercentage(100);
        innerTable5.setSpacingBefore(10);
        
        
        String paymentTerm = null;
        if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
        	//paymentTerm = orderDetails.getZterm();
        	// Fix for UAT-1091 Translating payment terms
        	paymentTerm = orderDetails.getPaymentTerms();
        	PdfPCell innerTable5Cell1 = new PdfPCell(new Phrase(getParagraphFour() + " " + paymentTerm + " (" + getPaymentTermLabel() +")", new Font(condensedregularBaseFont, 9)));
            innerTable5Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
            innerTable5Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            innerTable5Cell1.setPaddingLeft(50);
            innerTable5Cell1.setFixedHeight(15);
            innerTable5Cell1.setBorder(PdfPCell.NO_BORDER);
            innerTable5.addCell(innerTable5Cell1);
            
        } 
        else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
        	//paymentTerm = lastOrder.getPaymentTerms();
        	// Fix for UAT-1091
        	paymentTerm = lastOrder.getPaymentTerms();
        	String orderPaymentTerm = "";
        	if(paymentTerm != null && !paymentTerm.isEmpty()){
        		if(paymentTerm.startsWith("SP")){
        			orderPaymentTerm = getPaymentTermValueSP();
        		}
        		else if(paymentTerm.startsWith("NT")){
        			String numberValueInPaymentTerm = paymentTerm.substring(2, 4);
        			orderPaymentTerm = getPaymentTermValueNT1()+numberValueInPaymentTerm+getPaymentTermValueNT2();
        		}
        		else {
        			orderPaymentTerm = paymentTerm;
        		}
        	}
        
            	PdfPCell innerTable5Cell1 = new PdfPCell(new Phrase(getParagraphFour() + " " + orderPaymentTerm + " (" + getPaymentTermLabel() +")", new Font(condensedregularBaseFont, 9)));
                innerTable5Cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
                innerTable5Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
                innerTable5Cell1.setPaddingLeft(50);
                innerTable5Cell1.setFixedHeight(15);
                innerTable5Cell1.setBorder(PdfPCell.NO_BORDER);
                innerTable5.addCell(innerTable5Cell1);
            
        }
        return innerTable5;
    }
    
   
    /**
     * Adds static sections 4 -10 to the pdf.
     * @param genomicsProductInOrder
     * @return PdfPTable
     */
	private PdfPTable getInnerTable6ForCN(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName, final boolean isCNHost ,final HashSet<String> productLineSet) throws DocumentException {
		String hostName = "";
		boolean isVacuumPartPresent = false;
		boolean isXPLPartPresent = false;
		boolean isInstrumentPartPresent = false;
		if (isCNHost) {
			hostName = getChinaHostName();
		} else {
			hostName = getNonChinaHostName();
		}
		for (String productLine : productLineSet) {
			if (productLine.contains(XF_PL)) {
				isXPLPartPresent = true;

			} else if (productLine.contains(VACUUM_PL)) {
				isVacuumPartPresent = true;

			} else if (productLine.contains(INSTRUMENT_PL)) {
				isInstrumentPartPresent = true;

			}
		}

		PdfPTable innerTable6 = new PdfPTable(2);
		innerTable6.setSplitLate(false);
		innerTable6.setWidthPercentage(100);
		innerTable6.setWidths(new float[] { 3, 97 });
		innerTable6.setSpacingBefore(0);

		String paymentTermCN = null;
		String paymentTerm = null;
		if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
			paymentTermCN = orderDetails.getPaymentTerms();
		} else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			// paymentTerm = lastOrder.getPaymentTerms();
			// Fix for UAT-1091
			paymentTerm = lastOrder.getPaymentTerms();
			// String orderPaymentTerm = "";
			if (paymentTerm != null && !paymentTerm.isEmpty()) {
				if (paymentTerm.startsWith("SP")) {
					paymentTermCN = getPaymentTermValueSP();
				} else if (paymentTerm.startsWith("NT")) {
					String numberValueInPaymentTerm = paymentTerm.substring(2, 4);
					paymentTermCN = getPaymentTermValueNT1() + numberValueInPaymentTerm + getPaymentTermValueNT2();
				} else {
					paymentTermCN = paymentTerm;
				}
			}

		}

		PdfPCell innerTable6Cell0 = new PdfPCell(new Phrase("4.", new Font(condensedregularBaseFont, 9)));
		innerTable6Cell0.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell0.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell0.setPaddingTop(10);
		innerTable6Cell0.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell01 = new PdfPCell();
		Paragraph paragraphNoteForFour = new Paragraph();
		Phrase phrase = new Phrase(new Phrase(getParagraphFourForCN(), new Font(condensedregularBaseFont, 9)));
		paragraphNoteForFour.add(phrase);
		Phrase phrasePL1 = new Phrase(new Phrase(getParagraphFourForPL1(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL2 = new Phrase(new Phrase(getParagraphFourForPL2(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL3 = new Phrase(new Phrase(getParagraphFourForPL3(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL4 = new Phrase(new Phrase(paymentTermCN, new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL5 = new Phrase(new Phrase(getParagraphFourForPL5(), new Font(condensedregularBaseFont, 9)));

		if (isInstrumentPartPresent) {
			paragraphNoteForFour.add(phrasePL1);
			vlogInfo("payment terms {0}", paymentTermCN);
			paragraphNoteForFour.add(phrasePL4);
			paragraphNoteForFour.add(phrasePL5);
		}
		if (isVacuumPartPresent) {
			paragraphNoteForFour.add(phrasePL2);
		}
		if (isXPLPartPresent) {
			paragraphNoteForFour.add(phrasePL3);
		}

		innerTable6Cell01.addElement(paragraphNoteForFour);
		innerTable6Cell01.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell01.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell01.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell1 = new PdfPCell(new Phrase("5.", new Font(condensedregularBaseFont, 9)));
		innerTable6Cell1.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell1.setPaddingTop(8);
		innerTable6Cell1.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell2 = new PdfPCell();
		Phrase n1 = new Phrase(getParagraphFourForC9(), new Font(condensedregularBaseFont, 9));
		Paragraph paragraphNote = new Paragraph();
		Anchor anchor = new Anchor(getParagraphFourSub1ForC9(),
				new Font(condensedregularBaseFont, 9, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
		anchor.setReference(getParagraphFourSub1ForC9() + "\n");
		paragraphNote.add(n1);
		paragraphNote.add(anchor);
		innerTable6Cell2.addElement(paragraphNote);
		innerTable6Cell2.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell2.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell3 = new PdfPCell(new Phrase("6.", new Font(condensedregularBaseFont, 9)));
		innerTable6Cell3.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell3.setPaddingTop(8);
		innerTable6Cell3.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell4 = new PdfPCell();
		Phrase phrase1 = new Phrase(new Phrase(getParagraphFiveForCN(), new Font(condensedregularBaseFont, 9)));
		Paragraph paragraphNoteForFive = new Paragraph();
		Anchor anchor2 = new Anchor(getCopcEmailForChina(),
				new Font(condensedregularBaseFont, 9, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
		anchor2.setReference("mailto:" + getCopcEmailForChina());
		Phrase phrase2 = new Phrase(new Phrase(getParagraphFiveSub2ForC9(), new Font(condensedregularBaseFont, 9)));
		paragraphNoteForFive.add(phrase1);
		paragraphNoteForFive.add(anchor2);
		paragraphNoteForFive.add(phrase2);
		innerTable6Cell4.addElement(paragraphNoteForFive);
		innerTable6Cell4.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell4.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell7 = new PdfPCell(new Phrase("7.", new Font(condensedregularBaseFont, 9)));
		innerTable6Cell7.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell7.setPaddingTop(10);
		innerTable6Cell7.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable6Cell8 = new PdfPCell();
		Paragraph paragraphNoteForSix = new Paragraph();
		Phrase phrase6 = new Phrase(new Phrase(getParagraphSevenForCN(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL11 = new Phrase(new Phrase(getParagraphSevenForPL1(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL12 = new Phrase(new Phrase(getParagraphSevenForPL2(), new Font(condensedregularBaseFont, 9)));
		Phrase phrasePL13 = new Phrase(new Phrase(getParagraphSevenForPL3(), new Font(condensedregularBaseFont, 9)));
		paragraphNoteForSix.add(phrase6);
		if (isInstrumentPartPresent) {
			paragraphNoteForSix.add(phrasePL11);
		}
		if (isVacuumPartPresent) {
			paragraphNoteForSix.add(phrasePL12);
		}
		if (isXPLPartPresent) {
			paragraphNoteForSix.add(phrasePL13);
		}

		innerTable6Cell8.addElement(paragraphNoteForSix);
		innerTable6Cell8.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable6Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable6Cell8.setBorder(PdfPCell.NO_BORDER);
		innerTable6.addCell(innerTable6Cell0);
		innerTable6.addCell(innerTable6Cell01);
		innerTable6.addCell(innerTable6Cell1);
		innerTable6.addCell(innerTable6Cell2);
		innerTable6.addCell(innerTable6Cell3);
		innerTable6.addCell(innerTable6Cell4);
		innerTable6.addCell(innerTable6Cell7);
		innerTable6.addCell(innerTable6Cell8);
		return innerTable6;

	}
	
	private PdfPTable getInnerTable7ForCN(final OrderDetails orderDetails, final AgilentOrder lastOrder,
			final String pageName, final boolean isCNHost, final HashSet<String> productLineSet)
			throws DocumentException {
		String hostName = "";
		if (isCNHost) {
			hostName = getChinaHostName();
		} else {
			hostName = getNonChinaHostName();
		}

		PdfPTable innerTable7 = new PdfPTable(2);
		innerTable7.setSplitLate(false);
		innerTable7.setWidthPercentage(100);
		innerTable7.setWidths(new float[] { 3, 97 });
		innerTable7.setSpacingBefore(0);

		PdfPCell innerTable7Cell1 = new PdfPCell(new Phrase("8.", new Font(condensedregularBaseFont, 9)));
		innerTable7Cell1.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell1.setPaddingTop(10);
		innerTable7Cell1.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable7Cell2 = new PdfPCell();
		Phrase pharse8 = new Phrase(new Phrase(getParagraphEightForC9(), new Font(condensedregularBaseFont, 9)));
		Paragraph paragraphNotefor8 = new Paragraph();
		Anchor anchor3 = new Anchor(getParagraphEightSub1ForC9(),
				new Font(condensedregularBaseFont, 9, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
		anchor3.setReference(hostName + getSubPara1ForC9());
		paragraphNotefor8.add(pharse8);
		paragraphNotefor8.add(anchor3);
		innerTable7Cell2.addElement(paragraphNotefor8);
		innerTable7Cell2.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell2.setBorder(PdfPCell.NO_BORDER);

		PdfPCell innerTable7Cell3 = new PdfPCell();
		PdfPCell innerTable7Cell4 = new PdfPCell();
		PdfPCell innerTable7Cell5 = new PdfPCell();
		PdfPCell innerTable7Cell6 = new PdfPCell();
		Phrase phrase10 = new Phrase("9.", new Font(condensedregularBaseFont, 9));
		innerTable7Cell3.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell3.addElement(phrase10);
		innerTable7Cell3.setPaddingTop(5);
		innerTable7Cell3.setBorder(PdfPCell.NO_BORDER);

		Phrase phrasevalue10 = new Phrase(new Phrase(getParagraphTenForC9(), new Font(condensedregularBaseFont, 9)));
		Font bold = new Font(condensedregularBaseFont, 10, Font.UNDERLINE | Font.BOLD,
				WebColors.getRGBColor("#0000FF"));
		// bold.setStyle(Font.BOLD);
		Paragraph paragraphNotefor10 = new Paragraph();
		Anchor anchor4 = new Anchor(getParagraphEightForCN(), new Font(bold));
		anchor4.setReference(hostName + getParagraphTenSub3ForC9());
		Phrase phraseSub1 = new Phrase(
				new Phrase(getParagraphNineForCN(), new Font(condensedregularBaseFont, 9, Font.BOLD)));
		Phrase phraseSub2 = new Phrase(new Phrase(getSubPara1ForCN(), new Font(condensedregularBaseFont, 9)));
		paragraphNotefor10.add(phrasevalue10);
		paragraphNotefor10.add(anchor4);
		paragraphNotefor10.add(phraseSub1);
		paragraphNotefor10.add(phraseSub2);
		innerTable7Cell4.addElement(paragraphNotefor10);
		innerTable7Cell4.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell4.setBorder(PdfPCell.NO_BORDER);

		Phrase phrase11 = new Phrase("10.", new Font(condensedregularBaseFont, 9));
		innerTable7Cell5.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell5.addElement(phrase11);
		innerTable7Cell5.setPaddingTop(10);
		innerTable7Cell5.setBorder(PdfPCell.NO_BORDER);

		Phrase phrasevalue11 = new Phrase(getParagraphTenForCN(), new Font(condensedregularBaseFont, 9));
		innerTable7Cell6.setVerticalAlignment(Element.ALIGN_TOP);
		innerTable7Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
		innerTable7Cell6.setPaddingTop(10);
		innerTable7Cell6.addElement(phrasevalue11);
		innerTable7Cell6.setBorder(PdfPCell.NO_BORDER);
		innerTable7.addCell(innerTable7Cell1);
		innerTable7.addCell(innerTable7Cell2);
		innerTable7.addCell(innerTable7Cell3);
		innerTable7.addCell(innerTable7Cell4);
		innerTable7.addCell(innerTable7Cell5);
		innerTable7.addCell(innerTable7Cell6);
        return innerTable7;

	}
	
    /**
     * Counts the paragraph number and increments it for C9.
     * 
     * @return paragraph number
     */
    private String paragraphCount(Integer counterStartValue) {
        if (counterStartValue != null) {
            paraCount = counterStartValue;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(++paraCount).append(".");

        return sb.toString();
    }
	
    /**
     * Adds static section from 5 in the tables.
     * 
     * @return PdfPTable
     */
	private PdfPTable getInnerTable6ForC9(final boolean isCNHost,final AgilentOrder lastOrder, final String pageName, AgilentOrder webOrder) throws DocumentException {
        String hostName = "";
        if (isCNHost) {
            hostName = getChinaHostName();
        } else {
            hostName = getNonChinaHostName();
        }

        String orderType = null;
        int startCount = 0;
        if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName)) {
            orderType = orderTypeByProductLine(webOrder);

        } else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
            orderType = orderTypeByProductLine(lastOrder);
        }

        PdfPTable innerTable6 = new PdfPTable(2);
        innerTable6.setSplitLate(false);
        innerTable6.setWidthPercentage(100);
        innerTable6.setWidths(new float[] {3, 97});
        innerTable6.setSpacingBefore(0);

        PdfPCell innerTable6Cell1 = new PdfPCell(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell1.setPaddingTop(8);
        innerTable6Cell1.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell1);

        PdfPCell innerTable6Cell2 = new PdfPCell();
        Phrase n1 = new Phrase(getParagraphFourForC9(), new Font(condensedregularBaseFont, 9));
        Paragraph paragraphNote = new Paragraph();
        Anchor anchor = new Anchor(getParagraphFourSub1ForC9(), new Font(condensedregularBaseFont, 9, Font.UNDERLINE, WebColors.getRGBColor("#0000FF")));
        anchor.setReference(getParagraphFourSub1ForC9() + "\n");
        paragraphNote.add(n1);
        paragraphNote.add(anchor);
        innerTable6Cell2.addElement(paragraphNote);
        innerTable6Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell2.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell2);

        PdfPCell innerTable6Cell7 = new PdfPCell(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell7.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell7.setPaddingTop(10);
        innerTable6Cell7.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell7);

        StringBuilder paraSixForC9= new StringBuilder();
        if (DGG_AND_LSAG.equalsIgnoreCase(orderType)) {
            paraSixForC9.append(getParagraphSixForC9Heading()).append(getParagraphSixForC9()).append(getParagraphSixForC9LSAG());
        } else if (DGG.equalsIgnoreCase(orderType)) {
            paraSixForC9.append(getParagraphSixForC9Heading()).append(getParagraphSixForC9());
        } else if (LSAG.equalsIgnoreCase(orderType)) {
            paraSixForC9.append(getParagraphSixForC9Heading()).append(getParagraphSixForC9LSAG());
        }
        PdfPCell innerTable6Cell8 = new PdfPCell();
        Paragraph paragraphNoteForSix = new Paragraph();
        Phrase phrase6 = new Phrase(new Phrase(paraSixForC9.toString(), new Font(condensedregularBaseFont, 9)));
        paragraphNoteForSix.add(phrase6);
        innerTable6Cell8.addElement(paragraphNoteForSix);
        innerTable6Cell8.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell8.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell8);

        PdfPCell innerTable6Cell9 = new PdfPCell(new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell9.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell9.setPaddingTop(10);
        innerTable6Cell9.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell9);

        String finalParaSevenForC9 = null;
        if (DGG_AND_LSAG.equalsIgnoreCase(orderType))
            finalParaSevenForC9 = getParagraphSevenForC9DGGandLSAG();
        else if (DGG.equalsIgnoreCase(orderType))
            finalParaSevenForC9 = getParagraphSevenForC9();
        else if (LSAG.equalsIgnoreCase(orderType))
            finalParaSevenForC9 = getParagraphSevenForC9LSAG();
        PdfPCell innerTable6Cell10 = new PdfPCell();
        Phrase phrase7 = new Phrase(finalParaSevenForC9, new Font(condensedregularBaseFont, 9));
        innerTable6Cell10.addElement(phrase7);
        innerTable6Cell10.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell10.setPaddingTop(5);
        innerTable6Cell10.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell10);

        PdfPCell innerTable6Cell13 = new PdfPCell();
        PdfPCell innerTable6Cell14 = new PdfPCell();
        PdfPCell innerTable6Cell15 = new PdfPCell();
        PdfPCell innerTable6Cell16 = new PdfPCell();
        PdfPCell innerTable6Cell17 = new PdfPCell();
        PdfPCell innerTable6Cell18 = new PdfPCell();

        if (DGG_AND_LSAG.equalsIgnoreCase(orderType) || DGG.equalsIgnoreCase(orderType)) {
            Phrase phrase9 = new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9));
            innerTable6Cell13.setVerticalAlignment(Element.ALIGN_TOP);
            innerTable6Cell13.addElement(phrase9);
            innerTable6Cell13.setHorizontalAlignment(Element.ALIGN_LEFT);
            // innerTable6Cell13.setPaddingLeft(48);
            innerTable6Cell13.setPaddingTop(10);
            innerTable6Cell13.setBorder(PdfPCell.NO_BORDER);
            innerTable6.addCell(innerTable6Cell13);

            Phrase phrasevalue9 = new Phrase(getParagraphNineForC9(), new Font(condensedregularBaseFont, 9));
            innerTable6Cell14.addElement(phrasevalue9);
            innerTable6Cell14.setVerticalAlignment(Element.ALIGN_TOP);
            innerTable6Cell14.setHorizontalAlignment(Element.ALIGN_LEFT);
            innerTable6Cell14.setPaddingTop(10);
            innerTable6Cell14.setBorder(PdfPCell.NO_BORDER);
            innerTable6.addCell(innerTable6Cell14);
        }

        Phrase phrase10 = new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9));
        innerTable6Cell15.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell15.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell15.addElement(phrase10);
        // innerTable6Cell15.setPaddingLeft(46);
        innerTable6Cell15.setPaddingTop(5);
        innerTable6Cell15.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell15);

        Phrase phrasevalue10 = new Phrase(new Phrase(getParagraphTenForC9(), new Font(condensedregularBaseFont, 9)));
        Paragraph paragraphNotefor10 = new Paragraph();
        Font bold = new Font(condensedregularBaseFont, 10, Font.UNDERLINE | Font.BOLD, WebColors.getRGBColor("#0000FF"));
        Anchor anchor4 = new Anchor(getParagraphEightForCN(), new Font(bold));
        anchor4.setReference(hostName + getParagraphTenSub3ForC9());
        Phrase phraseSub1 = new Phrase(new Phrase(getParagraphNineForCN(), new Font(condensedregularBaseFont, 9, Font.BOLD)));
        Phrase phraseSub2 = new Phrase(new Phrase(getSubPara1ForCN(), new Font(condensedregularBaseFont, 9)));
        paragraphNotefor10.add(phrasevalue10);
        paragraphNotefor10.add(anchor4);
        paragraphNotefor10.add(phraseSub1);
        paragraphNotefor10.add(phraseSub2);
        innerTable6Cell16.addElement(paragraphNotefor10);
        innerTable6Cell16.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell16.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell16.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell16);

        Phrase phrase11 = new Phrase(paragraphCount(null), new Font(condensedregularBaseFont, 9));
        innerTable6Cell17.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell17.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell17.addElement(phrase11);
        // innerTable6Cell17.setPaddingLeft(46);
        innerTable6Cell17.setPaddingTop(10);
        innerTable6Cell17.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell17);

        Phrase phrasevalue11 = new Phrase(getParagraphEleven(), new Font(condensedregularBaseFont, 9));
        innerTable6Cell18.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell18.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell18.setPaddingTop(10);
        innerTable6Cell18.addElement(phrasevalue11);
        innerTable6Cell18.setBorder(PdfPCell.NO_BORDER);
        innerTable6.addCell(innerTable6Cell18);

        return innerTable6;
            
    }


    /**
     * Checks the product line and returns the order type for C9
     * @param lastOrder
     */
    private String orderTypeByProductLine(final AgilentOrder order) {
        String orderType = null;
        int dggCounter = 0;
        int lsagCounter = 0;
        List<CommerceItem> orderLineItems = order.getCommerceItems();
        for (CommerceItem cItem : orderLineItems) {
            RepositoryItem skuItem = (RepositoryItem) cItem.getAuxiliaryData().getCatalogRef();
            if (skuItem != null && skuItem.getPropertyValue(Constants.PRODUCT_LINE_CODE) != null) {
                String productLine = (String) skuItem.getPropertyValue(Constants.PRODUCT_LINE_CODE);
                if (StringUtils.isNotBlank(productLine)) {
                    if (StringUtils.isNotBlank(getAttsGenPL()) && getAttsGenPL().contains(productLine)) {
                        dggCounter++;
                    } else if (StringUtils.isNotBlank(getProductLineFor04C9LSAG()) && getProductLineFor04C9LSAG().contains(productLine)) {
                        lsagCounter++;
                    }
                }
            }
        }
        if (dggCounter == orderLineItems.size()) {
            orderType = "DGG";
        } else if (lsagCounter == orderLineItems.size()) {
            orderType = "LSAG";
        } else if ((dggCounter > 0) && (lsagCounter > 0)) {
            orderType = "DGGandLSAG";
        }
        
        return orderType;
    }
	
	/**
     * Adds static section 5-11 in the tables.
     * 
     * @return PdfPTable
     */
    private PdfPTable getInnerTable6() throws DocumentException {
        PdfPTable innerTable6 = new PdfPTable(2);
        innerTable6.setSplitLate(false);
        innerTable6.setWidthPercentage(100);
        innerTable6.setWidths(new float[] {12, 88});
        innerTable6.setSpacingBefore(0);
        
        PdfPCell innerTable6Cell1 = new PdfPCell(new Phrase("5.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell1.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell1.setPaddingLeft(8);
        innerTable6Cell1.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell2 = new PdfPCell(new Phrase(getParagraphFive(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell2.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell3 = new PdfPCell(new Phrase("6.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell3.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell3.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell3.setPaddingLeft(8);
        innerTable6Cell3.setPaddingTop(10);
        innerTable6Cell3.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell4 = new PdfPCell(new Phrase(getParagraphSix(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell4.setPaddingTop(10);
        innerTable6Cell4.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell5 = new PdfPCell(new Phrase("7.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell5.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell5.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell5.setPaddingLeft(8);
        innerTable6Cell5.setPaddingTop(10);
        innerTable6Cell5.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell6 = new PdfPCell(new Phrase(getParagraphSeven(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell6.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell6.setPaddingTop(10);
        innerTable6Cell6.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell7 = new PdfPCell(new Phrase("8.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell7.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell7.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell7.setPaddingLeft(8);
        innerTable6Cell7.setPaddingTop(10);
        innerTable6Cell7.setPaddingBottom(10);
        innerTable6Cell7.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell8 = new PdfPCell(new Phrase(getParagraphEight(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell8.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell8.setPaddingTop(10);
        innerTable6Cell8.setPaddingBottom(350);
        innerTable6Cell8.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell9 = new PdfPCell(new Phrase("9.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell9.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell9.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell9.setPaddingLeft(8);
        innerTable6Cell9.setPaddingTop(10);
        innerTable6Cell9.setPaddingBottom(10);
        innerTable6Cell9.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell10 = new PdfPCell(new Phrase(getParagraphNine(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell10.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell10.setPaddingTop(10);
        innerTable6Cell10.setPaddingBottom(10);
        innerTable6Cell10.setBorder(PdfPCell.NO_BORDER);
        
      PdfPCell innerTable6Cell11 = new PdfPCell(new Phrase("10.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell11.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell11.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell11.setPaddingLeft(8);
        innerTable6Cell11.setPaddingTop(10);
        innerTable6Cell11.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell12 = new PdfPCell(new Phrase(getParagraphTen(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell12.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell12.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell12.setPaddingTop(10);
        innerTable6Cell12.setPaddingBottom(10);
        innerTable6Cell12.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell13 = new PdfPCell(new Phrase("11.", new Font(condensedregularBaseFont, 9)));
        innerTable6Cell13.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell13.setHorizontalAlignment(Element.ALIGN_RIGHT);
        innerTable6Cell13.setPaddingLeft(8);
        innerTable6Cell13.setPaddingTop(10);
        innerTable6Cell13.setPaddingBottom(10);
        innerTable6Cell13.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable6Cell14 = new PdfPCell(new Phrase(getParagraphEleven(), new Font(condensedregularBaseFont, 9)));
        innerTable6Cell14.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable6Cell14.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable6Cell14.setPaddingTop(10);
        innerTable6Cell14.setPaddingBottom(10);
        innerTable6Cell14.setBorder(PdfPCell.NO_BORDER);
        
        innerTable6.addCell(innerTable6Cell1);
        innerTable6.addCell(innerTable6Cell2);
        innerTable6.addCell(innerTable6Cell3);
        innerTable6.addCell(innerTable6Cell4);
        innerTable6.addCell(innerTable6Cell5);
        innerTable6.addCell(innerTable6Cell6);
        innerTable6.addCell(innerTable6Cell7);
        innerTable6.addCell(innerTable6Cell8);
        innerTable6.addCell(innerTable6Cell9);
        innerTable6.addCell(innerTable6Cell10);
        innerTable6.addCell(innerTable6Cell11);
        innerTable6.addCell(innerTable6Cell12);
        innerTable6.addCell(innerTable6Cell13);
        innerTable6.addCell(innerTable6Cell14); 
        
        return innerTable6;
    }

    /**
     * Adds seller/buyer details section to the pdf.
     * 
     * @param orderDetails the orderDetails
     * @param lastOrder the lastOrder
     * @param pageName the pageName
     * @return PdfPTable
     */
    private PdfPTable getInnerTable7(final OrderDetails orderDetails, final AgilentOrder lastOrder,
    		final String pageName) throws DocumentException {
    	String soldToAccountName = null;
    	String salesOrg = null;
		if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
			salesOrg = orderDetails.getSalesOrg();
			if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
				soldToAccountName = orderDetails.getInternationalBillAddress().get(0).getCompanyName()
						+ orderDetails.getInternationalBillAddress().get(0).getAddress3();
			} else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
				soldToAccountName = orderDetails.getInternationalBillAddress().get(0).getCompanyName()
						+ orderDetails.getInternationalBillAddress().get(0).getAddress3();
			} else {
				soldToAccountName = orderDetails.getInternationalBillAddress().get(0).getCompanyName();
			}
		} else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			PurchaseOrderPaymentGroup poPG = null;
			PaymentGroup payGroup = (PaymentGroup) lastOrder.getPaymentGroups().get(0);
			salesOrg = lastOrder.getCartSalesOrg();
			if (payGroup instanceof PurchaseOrderPaymentGroup) {
				poPG = (PurchaseOrderPaymentGroup) payGroup;
			}
			if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)
					&& StringUtils.isNotBlank(poPG.getPayerAddress2())) {
				soldToAccountName = poPG.getPayerCompanyName() + poPG.getPayerAddress2();
			} else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)
					&& StringUtils.isNotBlank(poPG.getPayerAddress2())) {
				soldToAccountName = poPG.getPayerCompanyName() + poPG.getPayerAddress2();
			} else {
				soldToAccountName = poPG.getPayerCompanyName();
			}
		}

	
		PdfPTable innerTable7 = new PdfPTable(4);
       
        innerTable7.setSplitLate(false);
		innerTable7.setKeepTogether(true);
        
        innerTable7.setWidthPercentage(100);
        //innerTable7.setSpacingBefore(25);
        if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
        innerTable7.setSpacingBefore(25);
        	innerTable7.setWidths(new float[] {10, 45, 10, 35});
       }else{
    	   innerTable7.setSpacingBefore(25);
        innerTable7.setWidths(new float[] {20, 35, 10, 35});
       }
        PdfPCell innerTable7Cell1 = new PdfPCell(new Phrase(getBuyer(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        if(StringUtils.isNotBlank(salesOrg)&& !getSalesOrgListForRUO().contains(salesOrg)){
        innerTable7Cell1.setPaddingLeft(50);
       }
        
        innerTable7Cell1.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell2 = new PdfPCell(new Phrase(soldToAccountName, new Font(condensedregularBaseFont, 7)));
        innerTable7Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell2.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell3 = new PdfPCell(new Phrase(getSellerKey(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell3.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell3.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell4=new PdfPCell();
        Phrase sellerValue = new Phrase();
        if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
            sellerValue = new Phrase(getSellerValueForC9(), new Font(condensedregularBaseFont, 7));
        }
        else{
            sellerValue = new Phrase(getSellerValue(), new Font(condensedregularBaseFont, 7));
        }
        innerTable7Cell4.addElement(sellerValue);
        innerTable7Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell4.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell5 = new PdfPCell(new Phrase(getSealed(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell5.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        if(StringUtils.isNotBlank(salesOrg)&& !getSalesOrgListForRUO().contains(salesOrg)){
        innerTable7Cell5.setPaddingLeft(50);
        }
       
        innerTable7Cell5.setPaddingTop(15);
        innerTable7Cell5.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell6 = new PdfPCell();
        innerTable7Cell6.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell6.setPaddingTop(15);
        innerTable7Cell6.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell7 = new PdfPCell(new Phrase(getSealed(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell7.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell7.setPaddingTop(15);
        innerTable7Cell7.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell8 = new PdfPCell();
        innerTable7Cell8.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell8.setPaddingTop(15);
        innerTable7Cell8.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell9 = new PdfPCell(new Phrase(getPosition(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell9.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        if(StringUtils.isNotBlank(salesOrg)&& !getSalesOrgListForRUO().contains(salesOrg)){
        innerTable7Cell9.setPaddingLeft(50);
        }
        
        innerTable7Cell9.setPaddingTop(20);
        innerTable7Cell9.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell10 = new PdfPCell();
        innerTable7Cell10.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell10.setPaddingTop(20);
        innerTable7Cell10.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell11 = new PdfPCell(new Phrase(getPosition(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell11.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell11.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell11.setPaddingTop(20);
        innerTable7Cell11.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell12 = new PdfPCell();
        innerTable7Cell12.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell12.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell12.setPaddingTop(20);
        innerTable7Cell12.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell13 = new PdfPCell(new Phrase(getDate(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell13.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell13.setHorizontalAlignment(Element.ALIGN_LEFT);
        if(StringUtils.isNotBlank(salesOrg)&& !getSalesOrgListForRUO().contains(salesOrg)){
        innerTable7Cell13.setPaddingLeft(50);
        }
        innerTable7Cell13.setPaddingTop(15);
        innerTable7Cell13.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell14 = new PdfPCell();
        innerTable7Cell14.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell14.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell14.setPaddingTop(15);
        innerTable7Cell14.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell15 = new PdfPCell(new Phrase(getDate(), new Font(condensedregularBaseFont, 7)));
        innerTable7Cell15.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell15.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell15.setPaddingTop(15);
        innerTable7Cell15.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable7Cell16 = new PdfPCell();
        innerTable7Cell16.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable7Cell16.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable7Cell16.setPaddingTop(15);
        innerTable7Cell16.setBorder(PdfPCell.NO_BORDER);    
        
        innerTable7.addCell(innerTable7Cell1);
        innerTable7.addCell(innerTable7Cell2);
        innerTable7.addCell(innerTable7Cell3);
        innerTable7.addCell(innerTable7Cell4);
        innerTable7.addCell(innerTable7Cell5);
        innerTable7.addCell(innerTable7Cell6);
        innerTable7.addCell(innerTable7Cell7);
        innerTable7.addCell(innerTable7Cell8);
        innerTable7.addCell(innerTable7Cell9);
        innerTable7.addCell(innerTable7Cell10);
        innerTable7.addCell(innerTable7Cell11);
        innerTable7.addCell(innerTable7Cell12);
        innerTable7.addCell(innerTable7Cell13);
        innerTable7.addCell(innerTable7Cell14);
        innerTable7.addCell(innerTable7Cell15);
        innerTable7.addCell(innerTable7Cell16);
        
        if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
        	innerTable7.setSpacingAfter(10);
        }
        else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
        	//innerTable7.setSpacingAfter(10);
        }else{
        	innerTable7.setSpacingAfter(360);
        }
        
       /* vlogInfo("Nesting table inside table to prevent splitting");
        PdfPTable nesting = new PdfPTable(1);
        nesting.setSplitLate(false);
       // nesting.setSplitRows(true);
        //nesting.setKeepTogether(true);
        PdfPCell cell = new PdfPCell(innerTable7);
       // cell.setBorder(PdfPCell.NO_BORDER);
        nesting.addCell(cell);*/
        
        return innerTable7;
    }
    
    /**
     * Adds E16 details section to the pdf.
     * 
     * @return PdfPTable
     */
    private PdfPTable getInnerTable8() {
        PdfPTable innerTable8 = new PdfPTable(1);
        innerTable8.setSplitLate(false);
        innerTable8.setWidthPercentage(100);
        innerTable8.setSpacingBefore(10);
        
        PdfPCell innerTable8Cell1 = new PdfPCell(new Phrase(getE16Heading(), new Font(condensedregularBaseFont, 10)));
        innerTable8Cell1.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell1.setPaddingLeft(50);
        innerTable8Cell1.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell2 = new PdfPCell(new Phrase(getE16Paragraph(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell2.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell2.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell2.setPaddingLeft(50);
        innerTable8Cell2.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell3 = new PdfPCell(new Phrase(getSubHeadingOne(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell3.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell3.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell3.setPaddingLeft(50);
        innerTable8Cell3.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell4 = new PdfPCell(new Phrase(getSubParagraphOne(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell4.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell4.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell4.setPaddingLeft(50);
        innerTable8Cell4.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell5 = new PdfPCell(new Phrase(getSubHeadingTwo(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell5.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell5.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell5.setPaddingLeft(50);
        innerTable8Cell5.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell6 = new PdfPCell(new Phrase(getSubParagraphTwo(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell6.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell6.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell6.setPaddingLeft(50);
        innerTable8Cell6.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell7 = new PdfPCell(new Phrase(getSubHeadingThree(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell7.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell7.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell7.setPaddingLeft(50);
        innerTable8Cell7.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell8 = new PdfPCell(new Phrase(getSubParagraphThree(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell8.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell8.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell8.setPaddingLeft(50);
        innerTable8Cell8.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell9 = new PdfPCell(new Phrase(getSubHeadingFour(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell9.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell9.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell9.setPaddingLeft(50);
        innerTable8Cell9.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell10 = new PdfPCell(new Phrase(getSubParagraphFour(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell10.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell10.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell10.setPaddingLeft(50);
        innerTable8Cell10.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell11 = new PdfPCell(new Phrase(getSubHeadingFive(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell11.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell11.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell11.setPaddingLeft(50);
        innerTable8Cell11.setPaddingTop(10);
        innerTable8Cell11.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell12 = new PdfPCell(new Phrase(getSubParagraphFive(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell12.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable8Cell12.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell12.setPaddingLeft(50);
        innerTable8Cell12.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell13 = new PdfPCell(new Phrase(getSubHeadingSix(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell13.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable8Cell13.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell13.setPaddingLeft(50);
        innerTable8Cell13.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell14 = new PdfPCell(new Phrase(getSubParagraphSix(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell14.setVerticalAlignment(Element.ALIGN_MIDDLE);
        innerTable8Cell14.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell14.setPaddingLeft(50);
        innerTable8Cell14.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell15 = new PdfPCell(new Phrase(getSubHeadingSeven(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell15.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell15.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell15.setPaddingLeft(50);
        innerTable8Cell15.setBorder(PdfPCell.NO_BORDER);
        
        PdfPCell innerTable8Cell16 = new PdfPCell(new Phrase(getSubParagraphSeven(), new Font(condensedregularBaseFont, 9)));
        innerTable8Cell16.setVerticalAlignment(Element.ALIGN_TOP);
        innerTable8Cell16.setHorizontalAlignment(Element.ALIGN_LEFT);
        innerTable8Cell16.setPaddingLeft(50);
        innerTable8Cell16.setBorder(PdfPCell.NO_BORDER);
        
        innerTable8.addCell(innerTable8Cell1);
        innerTable8.addCell(innerTable8Cell2);
        innerTable8.addCell(innerTable8Cell3);
        innerTable8.addCell(innerTable8Cell4);
        innerTable8.addCell(innerTable8Cell5);
        innerTable8.addCell(innerTable8Cell6);
        innerTable8.addCell(innerTable8Cell7);
        innerTable8.addCell(innerTable8Cell8);
        innerTable8.addCell(innerTable8Cell9);
        innerTable8.addCell(innerTable8Cell10);
        innerTable8.addCell(innerTable8Cell11);
        innerTable8.addCell(innerTable8Cell12);
        innerTable8.addCell(innerTable8Cell13);
        innerTable8.addCell(innerTable8Cell14);
        innerTable8.addCell(innerTable8Cell15);
        innerTable8.addCell(innerTable8Cell16);
        return innerTable8;
    }
    
    
    
	/**
	 * This method will fetch the orderDetails from ATG based on sapOrderId
	 * @param SAPOrderId
	 * @return
	 */
	public RepositoryItem  fetchSapOrderDetails(String SAPOrderId) {
		RepositoryItem[] sapOrder=null;
		try {
			RepositoryView view = getOrderRepository().getView(Constants.ORDER);
	         Object[] params = new Object[2];
	         params[0] = SAPOrderId;
	         RqlStatement statement = RqlStatement.parseRqlStatement(getSapOrderRQL());
	         sapOrder = statement.executeQuery(view, params);
	         if(sapOrder!=null)
	        	 	return sapOrder[0];
		} catch (RepositoryException e) {
				vlogError("PdfChinaOrderDetails class -Repository Exception Thrown ::{0}",e);
		}
       return null;
	}
	
	
	
	
	public Map<String, String> callingDataGridForDescription(List<String> partNumberList, String language) {

		String prodDataGridDesc = null;
		Map<String, Map<String, String>> partMaps = null;
		Map<String, String> finalpartsMap = null;
		Map<String, String> descriptionMap = new HashMap<String, String>();
		try {
			if (language != null && !language.isEmpty()) {
				long dataGridStartTime = System.currentTimeMillis();
				partMaps = (Map<String, Map<String, String>>) getDataGridRestHelper().getPartsDetails(partNumberList,
						language, null);
				long dataGridEndTime = System.currentTimeMillis();
				vlogInfo(
						"Pdf download helper method :: Calling Data Grid for partDetails :: partNumberList {0}:: Time taken(milliseconds) {1}",
						partNumberList, (dataGridEndTime - dataGridStartTime));
				for (String partNumber : partNumberList) {
					if (partMaps != null && partMaps.get(partNumber) != null) {
						finalpartsMap = partMaps.get(partNumber);
						// prodDataGridDesc = finalpartsMap.get(Constants.DESCRIPTION);
						prodDataGridDesc = finalpartsMap.get(Constants.DESCRIPTION);
						descriptionMap.put(partNumber, prodDataGridDesc);

					}
				}
				vlogDebug("Part Number Map : {0}", finalpartsMap);
			}
		} catch (JSONException jsonException) {
			vlogError(jsonException, "Exception while fetching data from datagrid ");
		}
		return descriptionMap;
	}
	
	public String fetchTranslatedProductline(RepositoryItem skuItem){
		
		String productLineChinese = "";
		if(skuItem != null && skuItem.getPropertyValue("productLine") != null) {
			String productLine = (String)skuItem.getPropertyValue("productLine");
			
		if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getVacuumPL()) && getVacuumPL().contains(productLine)) {
			productLineChinese = getVacuumPLChinese();
		}
		else if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getServicePL()) && getServicePL().contains(productLine)) {
			productLineChinese = getServicePLChinese();
		}
		else if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getInstrumentPL()) && getInstrumentPL().contains(productLine)) {
			productLineChinese = getInstrumentPLChinese();
		}
		else if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getXfPL()) && getXfPL().contains(productLine)) {
			productLineChinese = getXfPLChinese();
		}
		else if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getAttsGenPL()) && getAttsGenPL().contains(productLine)) {
			productLineChinese = getProductLineForC9();
		}
		else if(StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getProductLineFor04C9LSAG()) && getProductLineFor04C9LSAG().contains(productLine)) {
            productLineChinese = getProductLineForC9LSAG();
        }
		else {
			productLineChinese = productLine;
		}
		}
		return productLineChinese;
	}
	
	public HashSet<String> fetchProductLine(final OrderDetails orderDetails, final AgilentOrder lastOrder,
			final String pageName) {
		ArrayList<String> partNumberList = new ArrayList<String>();
		HashSet<String> productLineSet = new HashSet<>();
		if ("orderDetailsPage".equalsIgnoreCase(pageName)) {
			List<LineItem> orderLineItems = orderDetails.getItems();
			for (LineItem lItem : orderLineItems) {
				String partNumber = lItem.getCatId();
				RepositoryItem skuItem = getCatalogTools().getSkuFromCatalogId(partNumber);
				if (skuItem != null && skuItem.getPropertyValue("productLine") != null) {
					String productLine = (String) skuItem.getPropertyValue("productLine");

					if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getVacuumPL())
							&& getVacuumPL().contains(productLine)) {
						partNumberList.add(VACUUM_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getServicePL())
							&& getServicePL().contains(productLine)) {
						partNumberList.add(SERVICE_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getInstrumentPL())
							&& getInstrumentPL().contains(productLine)) {
						partNumberList.add(INSTRUMENT_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getXfPL())
							&& getXfPL().contains(productLine)) {
						partNumberList.add(XF_PL);
					} else {
						partNumberList.add(productLine);
					}

				}
			}
		} else if ("orderConfirmationPage".equalsIgnoreCase(pageName)) {
			List<CommerceItem> orderLineItems = lastOrder.getCommerceItems();
			for (CommerceItem cItem : orderLineItems) {
				String partNumber = (String) ((RepositoryItem) cItem.getAuxiliaryData().getCatalogRef())
						.getPropertyValue(Constants.CATALOG_ID);

				RepositoryItem skuItem = (RepositoryItem) cItem.getAuxiliaryData().getCatalogRef();
				if (skuItem != null && skuItem.getPropertyValue("productLine") != null) {
					String productLine = (String) skuItem.getPropertyValue("productLine");
					if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getVacuumPL())
							&& getVacuumPL().contains(productLine)) {
						partNumberList.add(VACUUM_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getServicePL())
							&& getServicePL().contains(productLine)) {
						partNumberList.add(SERVICE_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getInstrumentPL())
							&& getInstrumentPL().contains(productLine)) {
						partNumberList.add(INSTRUMENT_PL);
					} else if (StringUtils.isNotBlank(productLine) && StringUtils.isNotBlank(getXfPL())
							&& getXfPL().contains(productLine)) {
						partNumberList.add(XF_PL);
					} else {
						partNumberList.add(productLine);
					}
				}
			}

		}
		productLineSet.addAll(partNumberList);
		return productLineSet;
	}

		

	public void addConnectiveStampOnPDF(PdfReader readerOriginalDoc, PdfStamper stamper, String finalImagePath) throws IOException, DocumentException, BadElementException {

		addConnectiveStampOnPDF(readerOriginalDoc, stamper, finalImagePath, null);
		
	}
	/**
     * 
     * This method will add a connective stamp on right margin of PDF
     * 
     * @param readerOriginalDoc
     * @param stamper
     * @param finalImagePath
     * @param isC9SalesOrg 
     * @throws IOException
     * @throws DocumentException
     * @throws BadElementException
     */
    public void addConnectiveStampOnPDF(PdfReader readerOriginalDoc, PdfStamper stamper, String finalImagePath, String salesOrg) throws IOException, DocumentException, BadElementException {
        vlogDebug("PdfChinaOrderDownloadHelper.addConnectiveStampImage Start");
        if (readerOriginalDoc != null && stamper != null) {
            vlogDebug("Going to invoke split Image  for {0}", finalImagePath);
            Map<Integer, BufferedImage> imageFragments = splitImage(finalImagePath, readerOriginalDoc.getNumberOfPages());
            int pageNo = 1;
            int scalePercentage = 1;
            if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForRUO().contains(salesOrg)){
            	scalePercentage = Integer.parseInt(getImageScaleforConnectiveStamp());
            }else if(StringUtils.isNotBlank(salesOrg)&& getSalesOrgListForChina().contains(salesOrg)){
            	scalePercentage = Integer.parseInt(getConnectiveStampScaleSizeForCN());
            }else{
            	scalePercentage = Integer.parseInt(getImageScaleSize());
            }
            if (imageFragments != null && !imageFragments.isEmpty() && scalePercentage > 0) {
                for (Map.Entry<Integer, BufferedImage> imgFragmentEntry : imageFragments.entrySet()) {
                    PdfContentByte content = stamper.getOverContent(pageNo);
                    Image imageFragment = Image.getInstance(imgFragmentEntry.getValue(), null);
                    imageFragment.scalePercent(scalePercentage);
                    Rectangle rect = readerOriginalDoc.getPageSize(pageNo);
                    imageFragment.setAbsolutePosition(rect.getWidth() - imageFragment.getWidth() / (100 / scalePercentage), rect.getHeight() / 3);
                    content.addImage(imageFragment);
                    vlogDebug("Connective Stamp Added in page {0}", pageNo);
                    pageNo++;
                }
            } else {
                vlogError("Image Fragments Map is null or empty OR Scale Percent is Invalid {0}", scalePercentage);
            }
        }
        vlogDebug("PdfChinaOrderDownloadHelper.addConnectiveStampImage End");
    }

    /**
     * This method will split the given image to a given no of fragments and return the it in a map
     * 
     * @param finalImagePath
     * @param noOfFragments
     * @return
     * @throws IOException
     */
    private Map<Integer, BufferedImage> splitImage(String finalImagePath, int noOfFragments) throws IOException {
        vlogDebug("Start splitImage  Image Path = {0} noOfFragments = {1}", finalImagePath, noOfFragments);
        Map<Integer, BufferedImage> imageFragments = null;
        if (StringUtils.isNotBlank(finalImagePath) && noOfFragments > 0) {
            imageFragments = new HashMap<Integer, BufferedImage>();
            BufferedImage bufferedImg = ImageIO.read(new File(finalImagePath));
            int width = bufferedImg.getWidth();
            int height = bufferedImg.getHeight();
            int splitWidth = width / noOfFragments;
            for (int fragmentNo = 0; fragmentNo < noOfFragments; fragmentNo++) {
                BufferedImage buffImg = bufferedImg.getSubimage(fragmentNo * splitWidth, 0, splitWidth, height);
                imageFragments.put(fragmentNo, buffImg);
            }
        } else {
            vlogError("Error while splitting image {0} to {1} parts", finalImagePath, noOfFragments);
        }
        vlogDebug("End splitImage method, Image splitted to {0} fragments", imageFragments.size());
        return imageFragments;
    }
    
    /**
     * Method to evaluate salesOrg for Pdf.
     * @param orderdetails,lastOrder,pageName,orderId
     * @return salesOrg
     */

    public String evaluateSalesOrgForChinaPDF(OrderDetails orderDetails, AgilentOrder lastOrder, String pageName) {
    	String salesOrg="";
    	  if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName) && orderDetails!=null) {
  			salesOrg = orderDetails.getSalesOrg().toString();
          } else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
          	salesOrg = lastOrder.getCartSalesOrg();
          }
    	return salesOrg;
    	
	}
    
    public Integer evaluatePartNumberCountForChinaPDF(OrderDetails orderDetails, AgilentOrder lastOrder, String pageName) {
    	Integer partNumberCount=0;
    	  if (Constants.ORDER_DETAIL_PAGE.equalsIgnoreCase(pageName) && orderDetails!=null) {
    		  List<LineItem> orderLineItems = orderDetails.getItems();
    		  partNumberCount=orderLineItems.size();
          } else if (Constants.ORDER_CONFIRMATION_PAGE.equalsIgnoreCase(pageName)) {
        	  List<CommerceItem> orderLineItems = lastOrder.getCommerceItems();
        	  partNumberCount=orderLineItems.size();
          }
    	return partNumberCount;
    	
	}
    /**
     * Gets the value of property agilentLogoImageName
     *
     * @return the value of property agilentLogoImageName
     */
    public String getAgilentLogoImageName() {
        return mAgilentLogoImageName;
    }
    
    /**
     * Sets the value of property agilentLogoImageName with value pAgilentLogoImageName
     *
     * @param pAgilentLogoImageName
     *            for setting property agilentLogoImageName
     */
    public void setAgilentLogoImageName(String pAgilentLogoImageName) {
        mAgilentLogoImageName = pAgilentLogoImageName;
    }

    /**
     * Gets the value of property chinaContactUsURL
     *
     * @return the value of property chinaContactUsURL
     */
    public String getChinaContactUsURL() {
        return chinaContactUsURL;
    }
    
    /**
     * Sets the value of property chinaContactUsURL with value pChinaContactUsURL
     *
     * @param pChinaContactUsURL
     *            for setting property chinaContactUsURL
     */
    public void setChinaContactUsURL(String pChinaContactUsURL) {
        chinaContactUsURL = pChinaContactUsURL;
    }

	/**
     * Gets the value of currencyCodeToLocaleMap
     *
     * @return returns the property currencyCodeToLocaleMap
     */
    public Map<String, String> getCurrencyCodeToLocaleMap() {
        return mCurrencyCodeToLocaleMap;
    }

    /**
     * Sets the value of property currencyCodeToLocaleMap with value currencyCodeToLocaleMap
     *
     * @param currencyCodeToLocaleMap
     *            the currencyCodeToLocaleMap to set
     */
    public void setCurrencyCodeToLocaleMap( Map<String, String> currencyCodeToLocaleMap) {
        mCurrencyCodeToLocaleMap = currencyCodeToLocaleMap;
    }

	/**
	 * @return the imageHorizontalPosition
	 */
	public String getImageHorizontalPosition() {
		return imageHorizontalPosition;
	}

	/**
	 * @param imageHorizontalPosition the imageHorizontalPosition to set
	 */
	public void setImageHorizontalPosition(String imageHorizontalPosition) {
		this.imageHorizontalPosition = imageHorizontalPosition;
	}

	/**
	 * @return the imageScaleSize
	 */
	public String getImageScaleSize() {
		return imageScaleSize;
	}

	/**
	 * @param imageScaleSize the imageScaleSize to set
	 */
	public void setImageScaleSize(String imageScaleSize) {
		this.imageScaleSize = imageScaleSize;
	}

	/**
	 * @return the imageVerticalPosition
	 */
	public String getImageVerticalPosition() {
		return imageVerticalPosition;
	}

	/**
	 * @param imageVerticalPosition the imageVerticalPosition to set
	 */
	public void setImageVerticalPosition(String imageVerticalPosition) {
		this.imageVerticalPosition = imageVerticalPosition;
	}

	/**
	 * @return the addressDetails
	 */
	public String getAddressDetails() {
		return addressDetails;
	}

	/**
	 * @param addressDetails the addressDetails to set
	 */
	public void setAddressDetails(String addressDetails) {
		this.addressDetails = addressDetails;
	}

	/**
	 * @return the contactDetails
	 */
	public String getContactDetails() {
		return contactDetails;
	}

	/**
	 * @param contactDetails the contactDetails to set
	 */
	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}

	/**
	 * @return the teleLabel
	 */
	public String getTeleLabel() {
		return teleLabel;
	}

	/**
	 * @param teleLabel the teleLabel to set
	 */
	public void setTeleLabel(String teleLabel) {
		this.teleLabel = teleLabel;
	}

	/**
	 * @return the faxLabel
	 */
	public String getFaxLabel() {
		return faxLabel;
	}

	/**
	 * @param faxLabel the faxLabel to set
	 */
	public void setFaxLabel(String faxLabel) {
		this.faxLabel = faxLabel;
	}

	/**
	 * @return the emailLabel
	 */
	public String getEmailLabel() {
		return emailLabel;
	}

	/**
	 * @param emailLabel the emailLabel to set
	 */
	public void setEmailLabel(String emailLabel) {
		this.emailLabel = emailLabel;
	}

	/**
	 * @return the webLabel
	 */
	public String getWebLabel() {
		return webLabel;
	}

	/**
	 * @param webLabel the webLabel to set
	 */
	public void setWebLabel(String webLabel) {
		this.webLabel = webLabel;
	}

	/**
	 * @return the salesOrderNumberKey
	 */
	public String getSalesOrderNumberKey() {
		return salesOrderNumberKey;
	}

	/**
	 * @param salesOrderNumberKey the salesOrderNumberKey to set
	 */
	public void setSalesOrderNumberKey(String salesOrderNumberKey) {
		this.salesOrderNumberKey = salesOrderNumberKey;
	}

	/**
	 * @return the salesOrderDateKey
	 */
	public String getSalesOrderDateKey() {
		return salesOrderDateKey;
	}

	/**
	 * @param salesOrderDateKey the salesOrderDateKey to set
	 */
	public void setSalesOrderDateKey(String salesOrderDateKey) {
		this.salesOrderDateKey = salesOrderDateKey;
	}

	/**
	 * @return the poNumberKey
	 */
	public String getPoNumberKey() {
		return poNumberKey;
	}

	/**
	 * @param poNumberKey the poNumberKey to set
	 */
	public void setPoNumberKey(String poNumberKey) {
		this.poNumberKey = poNumberKey;
	}

	/**
	 * @return the currencyKey
	 */
	public String getCurrencyKey() {
		return currencyKey;
	}

	/**
	 * @param currencyKey the currencyKey to set
	 */
	public void setCurrencyKey(String currencyKey) {
		this.currencyKey = currencyKey;
	}

	/**
	 * @return the currencyValue
	 */
	public String getCurrencyValue() {
		return currencyValue;
	}

	/**
	 * @param currencyValue the currencyValue to set
	 */
	public void setCurrencyValue(String currencyValue) {
		this.currencyValue = currencyValue;
	}

	/**
	 * @return the soldToAccountNameKey
	 */
	public String getSoldToAccountNameKey() {
		return soldToAccountNameKey;
	}

	/**
	 * @param soldToAccountNameKey the soldToAccountNameKey to set
	 */
	public void setSoldToAccountNameKey(String soldToAccountNameKey) {
		this.soldToAccountNameKey = soldToAccountNameKey;
	}

	/**
	 * @return the soldToAccountAddressKey
	 */
	public String getSoldToAccountAddressKey() {
		return soldToAccountAddressKey;
	}

	/**
	 * @param soldToAccountAddressKey the soldToAccountAddressKey to set
	 */
	public void setSoldToAccountAddressKey(String soldToAccountAddressKey) {
		this.soldToAccountAddressKey = soldToAccountAddressKey;
	}

	/**
	 * @return the invoiceContactPersonNameKey
	 */
	public String getInvoiceContactPersonNameKey() {
		return invoiceContactPersonNameKey;
	}

	/**
	 * @param invoiceContactPersonNameKey the invoiceContactPersonNameKey to set
	 */
	public void setInvoiceContactPersonNameKey(String invoiceContactPersonNameKey) {
		this.invoiceContactPersonNameKey = invoiceContactPersonNameKey;
	}

	/**
	 * @return the invoiceContactPersonPhoneKey
	 */
	public String getInvoiceContactPersonPhoneKey() {
		return invoiceContactPersonPhoneKey;
	}

	/**
	 * @param invoiceContactPersonPhoneKey the invoiceContactPersonPhoneKey to set
	 */
	public void setInvoiceContactPersonPhoneKey(String invoiceContactPersonPhoneKey) {
		this.invoiceContactPersonPhoneKey = invoiceContactPersonPhoneKey;
	}

	/**
	 * @return the invoiceAddressKey
	 */
	public String getInvoiceAddressKey() {
		return invoiceAddressKey;
	}

	/**
	 * @param invoiceAddressKey the invoiceAddressKey to set
	 */
	public void setInvoiceAddressKey(String invoiceAddressKey) {
		this.invoiceAddressKey = invoiceAddressKey;
	}

	/**
	 * @return the customerBankNameKey
	 */
	public String getCustomerBankNameKey() {
		return customerBankNameKey;
	}

	/**
	 * @param customerBankNameKey the customerBankNameKey to set
	 */
	public void setCustomerBankNameKey(String customerBankNameKey) {
		this.customerBankNameKey = customerBankNameKey;
	}

	/**
	 * @return the customerBankAccountKey
	 */
	public String getCustomerBankAccountKey() {
		return customerBankAccountKey;
	}

	/**
	 * @param customerBankAccountKey the customerBankAccountKey to set
	 */
	public void setCustomerBankAccountKey(String customerBankAccountKey) {
		this.customerBankAccountKey = customerBankAccountKey;
	}

	/**
	 * @return the customerTaxCodeKey
	 */
	public String getCustomerTaxCodeKey() {
		return customerTaxCodeKey;
	}

	/**
	 * @param customerTaxCodeKey the customerTaxCodeKey to set
	 */
	public void setCustomerTaxCodeKey(String customerTaxCodeKey) {
		this.customerTaxCodeKey = customerTaxCodeKey;
	}

	/**
	 * @return the customerInvoiceTypeKey
	 */
	public String getCustomerInvoiceTypeKey() {
		return customerInvoiceTypeKey;
	}

	/**
	 * @param customerInvoiceTypeKey the customerInvoiceTypeKey to set
	 */
	public void setCustomerInvoiceTypeKey(String customerInvoiceTypeKey) {
		this.customerInvoiceTypeKey = customerInvoiceTypeKey;
	}

	/**
	 * @return the salesRepresentativeNameKey
	 */
	public String getSalesRepresentativeNameKey() {
		return salesRepresentativeNameKey;
	}

	/**
	 * @param salesRepresentativeNameKey the salesRepresentativeNameKey to set
	 */
	public void setSalesRepresentativeNameKey(String salesRepresentativeNameKey) {
		this.salesRepresentativeNameKey = salesRepresentativeNameKey;
	}

	/**
	 * @return the salesRepresentativePhoneKey
	 */
	public String getSalesRepresentativePhoneKey() {
		return salesRepresentativePhoneKey;
	}

	/**
	 * @param salesRepresentativePhoneKey the salesRepresentativePhoneKey to set
	 */
	public void setSalesRepresentativePhoneKey(String salesRepresentativePhoneKey) {
		this.salesRepresentativePhoneKey = salesRepresentativePhoneKey;
	}

	/**
	 * @return the salesRepresentativeMailKey
	 */
	public String getSalesRepresentativeMailKey() {
		return salesRepresentativeMailKey;
	}

	/**
	 * @param salesRepresentativeMailKey the salesRepresentativeMailKey to set
	 */
	public void setSalesRepresentativeMailKey(String salesRepresentativeMailKey) {
		this.salesRepresentativeMailKey = salesRepresentativeMailKey;
	}

	/**
	 * @return the mainHeading
	 */
	public String getMainHeading() {
		return mainHeading;
	}

	/**
	 * @param mainHeading the mainHeading to set
	 */
	public void setMainHeading(String mainHeading) {
		this.mainHeading = mainHeading;
	}

	/**
	 * @return the directInquiry
	 */
	public String getDirectInquiry() {
		return directInquiry;
	}

	/**
	 * @param directInquiry the directInquiry to set
	 */
	public void setDirectInquiry(String directInquiry) {
		this.directInquiry = directInquiry;
	}

	/**
	 * @return the supplierDetailsMap
	 */
	public LinkedHashMap<String, String> getSupplierDetailsMap() {
		return supplierDetailsMap;
	}

	/**
	 * @param supplierDetailsMap the supplierDetailsMap to set
	 */
	public void setSupplierDetailsMap(LinkedHashMap<String, String> supplierDetailsMap) {
		this.supplierDetailsMap = supplierDetailsMap;
	}

	/**
	 * @return the lastLineText
	 */
	public String getLastLineText() {
		return lastLineText;
	}

	/**
	 * @param lastLineText the lastLineText to set
	 */
	public void setLastLineText(String lastLineText) {
		this.lastLineText = lastLineText;
	}

	/**
	 * @return the middleLineText
	 */
	public String getMiddleLineText() {
		return middleLineText;
	}

	/**
	 * @param middleLineText the middleLineText to set
	 */
	public void setMiddleLineText(String middleLineText) {
		this.middleLineText = middleLineText;
	}

	/**
	 * @return the paragraphOne
	 */
	public String getParagraphOne() {
		return paragraphOne;
	}

	/**
	 * @param paragraphOne the paragraphOne to set
	 */
	public void setParagraphOne(String paragraphOne) {
		this.paragraphOne = paragraphOne;
	}

	/**
	 * @return the paragraphTwo
	 */
	public String getParagraphTwo() {
		return paragraphTwo;
	}

	/**
	 * @param paragraphTwo the paragraphTwo to set
	 */
	public void setParagraphTwo(String paragraphTwo) {
		this.paragraphTwo = paragraphTwo;
	}

	/**
	 * @return the paragraphThree
	 */
	public String getParagraphThree() {
		return paragraphThree;
	}

	/**
	 * @param paragraphThree the paragraphThree to set
	 */
	public void setParagraphThree(String paragraphThree) {
		this.paragraphThree = paragraphThree;
	}

	/**
	 * @return the paragraphFour
	 */
	public String getParagraphFour() {
		return paragraphFour;
	}

	/**
	 * @param paragraphFour the paragraphFour to set
	 */
	public void setParagraphFour(String paragraphFour) {
		this.paragraphFour = paragraphFour;
	}

	/**
	 * @return the paragraphFive
	 */
	public String getParagraphFive() {
		return paragraphFive;
	}

	/**
	 * @param paragraphFive the paragraphFive to set
	 */
	public void setParagraphFive(String paragraphFive) {
		this.paragraphFive = paragraphFive;
	}

	/**
	 * @return the paragraphSix
	 */
	public String getParagraphSix() {
		return paragraphSix;
	}

	/**
	 * @param paragraphSix the paragraphSix to set
	 */
	public void setParagraphSix(String paragraphSix) {
		this.paragraphSix = paragraphSix;
	}

	/**
	 * @return the paragraphSeven
	 */
	public String getParagraphSeven() {
		return paragraphSeven;
	}

	/**
	 * @param paragraphSeven the paragraphSeven to set
	 */
	public void setParagraphSeven(String paragraphSeven) {
		this.paragraphSeven = paragraphSeven;
	}

	/**
	 * @return the paragraphEight
	 */
	public String getParagraphEight() {
		return paragraphEight;
	}

	/**
	 * @param paragraphEight the paragraphEight to set
	 */
	public void setParagraphEight(String paragraphEight) {
		this.paragraphEight = paragraphEight;
	}

	/**
	 * @return the paragraphNine
	 */
	public String getParagraphNine() {
		return paragraphNine;
	}

	/**
	 * @param paragraphNine the paragraphNine to set
	 */
	public void setParagraphNine(String paragraphNine) {
		this.paragraphNine = paragraphNine;
	}

	/**
	 * @return the paragraphTen
	 */
	public String getParagraphTen() {
		return paragraphTen;
	}

	/**
	 * @param paragraphTen the paragraphTen to set
	 */
	public void setParagraphTen(String paragraphTen) {
		this.paragraphTen = paragraphTen;
	}

	/**
	 * @return the paragraphEleven
	 */
	public String getParagraphEleven() {
		return paragraphEleven;
	}

	/**
	 * @param paragraphEleven the paragraphEleven to set
	 */
	public void setParagraphEleven(String paragraphEleven) {
		this.paragraphEleven = paragraphEleven;
	}

	/**
	 * @return the buyer
	 */
	public String getBuyer() {
		return buyer;
	}

	/**
	 * @param buyer the buyer to set
	 */
	public void setBuyer(String buyer) {
		this.buyer = buyer;
	}

	/**
	 * @return the sellerKey
	 */
	public String getSellerKey() {
		return sellerKey;
	}

	/**
	 * @param sellerKey the sellerKey to set
	 */
	public void setSellerKey(String sellerKey) {
		this.sellerKey = sellerKey;
	}

	/**
	 * @return the sellerValue
	 */
	public String getSellerValue() {
		return sellerValue;
	}

	/**
	 * @param sellerValue the sellerValue to set
	 */
	public void setSellerValue(String sellerValue) {
		this.sellerValue = sellerValue;
	}

	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}

	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * @return the sealed
	 */
	public String getSealed() {
		return sealed;
	}

	/**
	 * @param sealed the sealed to set
	 */
	public void setSealed(String sealed) {
		this.sealed = sealed;
	}

	/**
	 * @return the lineNo
	 */
	public String getLineNo() {
		return lineNo;
	}

	/**
	 * @param lineNo the lineNo to set
	 */
	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}

	/**
	 * @return the productNumber
	 */
	public String getProductNumber() {
		return productNumber;
	}

	/**
	 * @param productNumber the productNumber to set
	 */
	public void setProductNumber(String productNumber) {
		this.productNumber = productNumber;
	}

	/**
	 * @return the productDescEnglish
	 */
	public String getProductDescEnglish() {
		return productDescEnglish;
	}

	/**
	 * @param productDescEnglish the productDescEnglish to set
	 */
	public void setProductDescEnglish(String productDescEnglish) {
		this.productDescEnglish = productDescEnglish;
	}

	/**
	 * @return the productDescChinese
	 */
	public String getProductDescChinese() {
		return productDescChinese;
	}

	/**
	 * @param productDescChinese the productDescChinese to set
	 */
	public void setProductDescChinese(String productDescChinese) {
		this.productDescChinese = productDescChinese;
	}

	/**
	 * @return the quantity
	 */
	public String getQuantity() {
		return quantity;
	}

	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	/**
	 * @return the stockStatus
	 */
	public String getStockStatus() {
		return stockStatus;
	}

	/**
	 * @param stockStatus the stockStatus to set
	 */
	public void setStockStatus(String stockStatus) {
		this.stockStatus = stockStatus;
	}

	/**
	 * @return the listPrice
	 */
	public String getListPrice() {
		return listPrice;
	}

	/**
	 * @param listPrice the listPrice to set
	 */
	public void setListPrice(String listPrice) {
		this.listPrice = listPrice;
	}

	/**
	 * @return the yourPrice
	 */
	public String getYourPrice() {
		return yourPrice;
	}

	/**
	 * @param yourPrice the yourPrice to set
	 */
	public void setYourPrice(String yourPrice) {
		this.yourPrice = yourPrice;
	}

	/**
	 * @return the totalPrice
	 */
	public String getTotalPrice() {
		return totalPrice;
	}

	/**
	 * @param totalPrice the totalPrice to set
	 */
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * @return the totalAmount
	 */
	public String getTotalAmount() {
		return totalAmount;
	}

	/**
	 * @param totalAmount the totalAmount to set
	 */
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	/**
	 * @return the shippingHandling
	 */
	public String getShippingHandling() {
		return shippingHandling;
	}

	/**
	 * @param shippingHandling the shippingHandling to set
	 */
	public void setShippingHandling(String shippingHandling) {
		this.shippingHandling = shippingHandling;
	}

	/**
	 * @return the totalAmountWithTax
	 */
	public String getTotalAmountWithTax() {
		return totalAmountWithTax;
	}

	/**
	 * @param totalAmountWithTax the totalAmountWithTax to set
	 */
	public void setTotalAmountWithTax(String totalAmountWithTax) {
		this.totalAmountWithTax = totalAmountWithTax;
	}

	/**
	 * @return the shipToAccountName
	 */
	public String getShipToAccountName() {
		return shipToAccountName;
	}

	/**
	 * @param shipToAccountName the shipToAccountName to set
	 */
	public void setShipToAccountName(String shipToAccountName) {
		this.shipToAccountName = shipToAccountName;
	}

	/**
	 * @return the shipToAccountAddress
	 */
	public String getShipToAccountAddress() {
		return shipToAccountAddress;
	}

	/**
	 * @param shipToAccountAddress the shipToAccountAddress to set
	 */
	public void setShipToAccountAddress(String shipToAccountAddress) {
		this.shipToAccountAddress = shipToAccountAddress;
	}

	/**
	 * @return the shippingContactPerson
	 */
	public String getShippingContactPerson() {
		return shippingContactPerson;
	}

	/**
	 * @param shippingContactPerson the shippingContactPerson to set
	 */
	public void setShippingContactPerson(String shippingContactPerson) {
		this.shippingContactPerson = shippingContactPerson;
	}

	/**
	 * @return the shippingContactPersonPhone
	 */
	public String getShippingContactPersonPhone() {
		return shippingContactPersonPhone;
	}

	/**
	 * @param shippingContactPersonPhone the shippingContactPersonPhone to set
	 */
	public void setShippingContactPersonPhone(String shippingContactPersonPhone) {
		this.shippingContactPersonPhone = shippingContactPersonPhone;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the e16Heading
	 */
	public String getE16Heading() {
		return e16Heading;
	}

	/**
	 * @param e16Heading the e16Heading to set
	 */
	public void setE16Heading(String e16Heading) {
		this.e16Heading = e16Heading;
	}

	/**
	 * @return the e16Paragraph
	 */
	public String getE16Paragraph() {
		return e16Paragraph;
	}

	/**
	 * @param e16Paragraph the e16Paragraph to set
	 */
	public void setE16Paragraph(String e16Paragraph) {
		this.e16Paragraph = e16Paragraph;
	}

	/**
	 * @return the subHeadingOne
	 */
	public String getSubHeadingOne() {
		return subHeadingOne;
	}

	/**
	 * @param subHeadingOne the subHeadingOne to set
	 */
	public void setSubHeadingOne(String subHeadingOne) {
		this.subHeadingOne = subHeadingOne;
	}

	/**
	 * @return the subParagraphOne
	 */
	public String getSubParagraphOne() {
		return subParagraphOne;
	}

	/**
	 * @param subParagraphOne the subParagraphOne to set
	 */
	public void setSubParagraphOne(String subParagraphOne) {
		this.subParagraphOne = subParagraphOne;
	}

	/**
	 * @return the subHeadingTwo
	 */
	public String getSubHeadingTwo() {
		return subHeadingTwo;
	}

	/**
	 * @param subHeadingTwo the subHeadingTwo to set
	 */
	public void setSubHeadingTwo(String subHeadingTwo) {
		this.subHeadingTwo = subHeadingTwo;
	}

	/**
	 * @return the subParagraphTwo
	 */
	public String getSubParagraphTwo() {
		return subParagraphTwo;
	}

	/**
	 * @param subParagraphTwo the subParagraphTwo to set
	 */
	public void setSubParagraphTwo(String subParagraphTwo) {
		this.subParagraphTwo = subParagraphTwo;
	}

	/**
	 * @return the subHeadingThree
	 */
	public String getSubHeadingThree() {
		return subHeadingThree;
	}

	/**
	 * @param subHeadingThree the subHeadingThree to set
	 */
	public void setSubHeadingThree(String subHeadingThree) {
		this.subHeadingThree = subHeadingThree;
	}

	/**
	 * @return the subParagraphThree
	 */
	public String getSubParagraphThree() {
		return subParagraphThree;
	}

	/**
	 * @param subParagraphThree the subParagraphThree to set
	 */
	public void setSubParagraphThree(String subParagraphThree) {
		this.subParagraphThree = subParagraphThree;
	}

	/**
	 * @return the subHeadingFour
	 */
	public String getSubHeadingFour() {
		return subHeadingFour;
	}

	/**
	 * @param subHeadingFour the subHeadingFour to set
	 */
	public void setSubHeadingFour(String subHeadingFour) {
		this.subHeadingFour = subHeadingFour;
	}

	/**
	 * @return the subParagraphFour
	 */
	public String getSubParagraphFour() {
		return subParagraphFour;
	}

	/**
	 * @param subParagraphFour the subParagraphFour to set
	 */
	public void setSubParagraphFour(String subParagraphFour) {
		this.subParagraphFour = subParagraphFour;
	}

	/**
	 * @return the subHeadingFive
	 */
	public String getSubHeadingFive() {
		return subHeadingFive;
	}

	/**
	 * @param subHeadingFive the subHeadingFive to set
	 */
	public void setSubHeadingFive(String subHeadingFive) {
		this.subHeadingFive = subHeadingFive;
	}

	/**
	 * @return the subParagraphFive
	 */
	public String getSubParagraphFive() {
		return subParagraphFive;
	}

	/**
	 * @param subParagraphFive the subParagraphFive to set
	 */
	public void setSubParagraphFive(String subParagraphFive) {
		this.subParagraphFive = subParagraphFive;
	}

	/**
	 * @return the subHeadingSix
	 */
	public String getSubHeadingSix() {
		return subHeadingSix;
	}

	/**
	 * @param subHeadingSix the subHeadingSix to set
	 */
	public void setSubHeadingSix(String subHeadingSix) {
		this.subHeadingSix = subHeadingSix;
	}

	/**
	 * @return the subParagraphSix
	 */
	public String getSubParagraphSix() {
		return subParagraphSix;
	}

	/**
	 * @param subParagraphSix the subParagraphSix to set
	 */
	public void setSubParagraphSix(String subParagraphSix) {
		this.subParagraphSix = subParagraphSix;
	}

	/**
	 * @return the sapManager
	 */
	public SapFunctions getSapManager() {
		return sapManager;
	}

	/**
	 * @param sapManager the sapManager to set
	 */
	public void setSapManager(SapFunctions sapManager) {
		this.sapManager = sapManager;
	}
	

    /**
     * @return OrderRepository
     */
    public Repository getOrderRepository() {
		return mOrderRepository;
	}

	/**
	 * @param mOrderRepository
	 */
	public void setOrderRepository(Repository mOrderRepository) {
		this.mOrderRepository = mOrderRepository;
	}

	/**
	 * @return mSapOrderRQL
	 */
	public String getSapOrderRQL() {
		return mSapOrderRQL;
	}

	/**
	 * @param mSapOrderRQL
	 */
	public void setSapOrderRQL(String mSapOrderRQL) {
		this.mSapOrderRQL = mSapOrderRQL;
	}

	/**
	 * @return the customerInvoiceTypeSpecialEn
	 */
	public String getCustomerInvoiceTypeSpecialEn() {
		return customerInvoiceTypeSpecialEn;
	}

	/**
	 * @param customerInvoiceTypeSpecialEn the customerInvoiceTypeSpecialEn to set
	 */
	public void setCustomerInvoiceTypeSpecialEn(String customerInvoiceTypeSpecialEn) {
		this.customerInvoiceTypeSpecialEn = customerInvoiceTypeSpecialEn;
	}

	/**
	 * @return the customerInvoiceTypeSpecialZh
	 */
	public String getCustomerInvoiceTypeSpecialZh() {
		return customerInvoiceTypeSpecialZh;
	}

	/**
	 * @param customerInvoiceTypeSpecialZh the customerInvoiceTypeSpecialZh to set
	 */
	public void setCustomerInvoiceTypeSpecialZh(String customerInvoiceTypeSpecialZh) {
		this.customerInvoiceTypeSpecialZh = customerInvoiceTypeSpecialZh;
	}

	/**
	 * @return the customerInvoiceTypeNormalEn
	 */
	public String getCustomerInvoiceTypeNormalEn() {
		return customerInvoiceTypeNormalEn;
	}

	/**
	 * @param customerInvoiceTypeNormalEn the customerInvoiceTypeNormalEn to set
	 */
	public void setCustomerInvoiceTypeNormalEn(String customerInvoiceTypeNormalEn) {
		this.customerInvoiceTypeNormalEn = customerInvoiceTypeNormalEn;
	}

	/**
	 * @return the customerInvoiceTypeNormalZh
	 */
	public String getCustomerInvoiceTypeNormalZh() {
		return customerInvoiceTypeNormalZh;
	}

	/**
	 * @param customerInvoiceTypeNormalZh the customerInvoiceTypeNormalZh to set
	 */
	public void setCustomerInvoiceTypeNormalZh(String customerInvoiceTypeNormalZh) {
		this.customerInvoiceTypeNormalZh = customerInvoiceTypeNormalZh;
	}


	/**
	 * @return the mAddressDetailsForC9
	 */
	public String getAddressDetailsForC9() {
		return mAddressDetailsForC9;
	}


	/**
	 * @param mAddressDetailsForC9 the mAddressDetailsForC9 to set
	 */
	public void setAddressDetailsForC9(String pAddressDetailsForC9) {
		this.mAddressDetailsForC9 = pAddressDetailsForC9;
	}


	/**
	 * @return the mContactDetailsForC9
	 */
	public String getContactDetailsForC9() {
		return mContactDetailsForC9;
	}


	/**
	 * @param mContactDetailsForC9 the mContactDetailsForC9 to set
	 */
	public void setContactDetailsForC9(String pContactDetailsForC9) {
		this.mContactDetailsForC9 = pContactDetailsForC9;
	}


	/**
	 * @return the mMainHeadingForC9
	 */
	public String getMainHeadingForC9() {
		return mMainHeadingForC9;
	}


	/**
	 * @param mMainHeadingForC9 the mMainHeadingForC9 to set
	 */
	public void setMainHeadingForC9(String pMainHeadingForC9) {
		this.mMainHeadingForC9 = pMainHeadingForC9;
	}


	/**
	 * @return the mInvoiceCustomerNameKey
	 */
	public String getInvoiceCustomerNameKey() {
		return mInvoiceCustomerNameKey;
	}


	/**
	 * @param mInvoiceCustomerNameKey the mInvoiceCustomerNameKey to set
	 */
	public void setInvoiceCustomerNameKey(String pInvoiceCustomerNameKey) {
		this.mInvoiceCustomerNameKey = pInvoiceCustomerNameKey;
	}


	/**
	 * @return the mSupplierDetailsMap1ForC9
	 */
	public LinkedHashMap<String, String> getSupplierDetailsMap1ForC9() {
		return mSupplierDetailsMap1ForC9;
	}


	/**
	 * @param mSupplierDetailsMap1ForC9 the mSupplierDetailsMap1ForC9 to set
	 */
	public void setSupplierDetailsMap1ForC9(LinkedHashMap<String, String> pSupplierDetailsMap1ForC9) {
		this.mSupplierDetailsMap1ForC9 = pSupplierDetailsMap1ForC9;
	}


	/**
	 * @return the mSupplierDetailsMap2ForC9
	 */
	public LinkedHashMap<String, String> getSupplierDetailsMap2ForC9() {
		return mSupplierDetailsMap2ForC9;
	}


	/**
	 * @param mSupplierDetailsMap2ForC9 the mSupplierDetailsMap2ForC9 to set
	 */
	public void setSupplierDetailsMap2ForC9(LinkedHashMap<String, String> pSupplierDetailsMap2ForC9) {
		this.mSupplierDetailsMap2ForC9 = pSupplierDetailsMap2ForC9;
	}


	/**
	 * @return the mProductLineForC9
	 */
	public String getProductLineForC9() {
		return mProductLineForC9;
	}


	/**
	 * @param mProductLineForC9 the mProductLineForC9 to set
	 */
	public void setProductLineForC9(String pProductLineForC9) {
		this.mProductLineForC9 = pProductLineForC9;
	}

	/**
	 * @return the mParagraphForC9
	 */
	public String getParagraphTwoForC9() {
		return mParagraphTwoForC9;
	}

	/**
	 * @param mParagraphForC9
	 *            the mParagraphForC9 to set
	 */
	public void setParagraphTwoForC9(String pParagraphTwoForC9) {
		this.mParagraphTwoForC9 = pParagraphTwoForC9;
	}

	/**
	 * @return the mParaGraphFiveForC9
	 */
	public String getParagraphFiveForC9() {
		return mParagraphFiveForC9;
	}

	/**
	 * @param mParaGraphFiveForC9
	 *            the mParaGraphFiveForC9 to set
	 */
	public void setParagraphFiveForC9(String pParagraphFiveForC9) {
		this.mParagraphFiveForC9 = pParagraphFiveForC9;
	}

	/**
	 * @return the mParagraphSixForC9
	 */
	public String getParagraphSixForC9() {
		return mParagraphSixForC9;
	}

	/**
	 * @param mParagraphSixForC9
	 *            the mParagraphSixForC9 to set
	 */
	public void setParagraphSixForC9(String pParagraphSixForC9) {
		this.mParagraphSixForC9 = pParagraphSixForC9;
	}

	/**
	 * @return the mParagraphSevenForC9
	 */
	public String getParagraphSevenForC9() {
		return mParagraphSevenForC9;
	}

	/**
	 * @param mParagraphSevenForC9
	 *            the mParagraphSevenForC9 to set
	 */
	public void setParagraphSevenForC9(String pParagraphSevenForC9) {
		this.mParagraphSevenForC9 = pParagraphSevenForC9;
	}

	/**
	 * @return the mSubPara1ForC9
	 */
	public String getSubPara1ForC9() {
		return mSubPara1ForC9;
	}

	/**
	 * @param mSubPara1ForC9
	 *            the mSubPara1ForC9 to set
	 */
	public void setSubPara1ForC9(String pSubPara1ForC9) {
		this.mSubPara1ForC9 = pSubPara1ForC9;
	}

	/**
	 * @return the mSubPara2ForC9
	 */
	public String getSubPara2ForC9() {
		return mSubPara2ForC9;
	}

	/**
	 * @param mSubPara2ForC9
	 *            the mSubPara2ForC9 to set
	 */
	public void setSubPara2ForC9(String pSubPara2ForC9) {
		this.mSubPara2ForC9 = pSubPara2ForC9;
	}

	/**
	 * @return the mSubPara3ForC9
	 */
	public String getSubPara3ForC9() {
		return mSubPara3ForC9;
	}

	/**
	 * @param mSubPara3ForC9
	 *            the mSubPara3ForC9 to set
	 */
	public void setSubPara3ForC9(String pSubPara3ForC9) {
		this.mSubPara3ForC9 = pSubPara3ForC9;
	}

	/**
	 * @return the mParagraphNineForC9
	 */
	public String getParagraphNineForC9() {
		return mParagraphNineForC9;
	}

	/**
	 * @param mParagraphNineForC9
	 *            the mParagraphNineForC9 to set
	 */
	public void setParagraphNineForC9(String pParagraphNineForC9) {
		this.mParagraphNineForC9 = pParagraphNineForC9;
	}

	/**
	 * @return the mParagraphTwoForC9
	 */
	public String getmParagraphTwoForC9() {
		return mParagraphTwoForC9;
	}

	/**
	 * @param mParagraphTwoForC9
	 *            the mParagraphTwoForC9 to set
	 */
	public void setmParagraphTwoForC9(String mParagraphTwoForC9) {
		this.mParagraphTwoForC9 = mParagraphTwoForC9;
	}

	/**
	 * @return the mParagraphFourForC9
	 */
	public String getParagraphFourForC9() {
		return mParagraphFourForC9;
	}

	/**
	 * @param mParagraphFourForC9
	 *            the mParagraphFourForC9 to set
	 */
	public void setParagraphFourForC9(String pParagraphFourForC9) {
		this.mParagraphFourForC9 = pParagraphFourForC9;
	}

	/**
	 * @return the mParagraphEightForC9
	 */
	public String getParagraphEightForC9() {
		return mParagraphEightForC9;
	}

	/**
	 * @param mParagraphEightForC9
	 *            the mParagraphEightForC9 to set
	 */
	public void setParagraphEightForC9(String pParagraphEightForC9) {
		this.mParagraphEightForC9 = pParagraphEightForC9;
	}

	/**
	 * @return the mParagraphTenForC9
	 */
	public String getParagraphTenForC9() {
		return mParagraphTenForC9;
	}


	/**
	 * @param mParagraphTenForC9 the mParagraphTenForC9 to set
	 */
	public void setParagraphTenForC9(String pParagraphTenForC9) {
		this.mParagraphTenForC9 = pParagraphTenForC9;
	}


	/**
	 * @return the mParagraphFourSub1ForC9
	 */
	public String getParagraphFourSub1ForC9() {
		return mParagraphFourSub1ForC9;
	}


	/**
	 * @param mParagraphFourSub1ForC9 the mParagraphFourSub1ForC9 to set
	 */
	public void setParagraphFourSub1ForC9(String pParagraphFourSub1ForC9) {
		this.mParagraphFourSub1ForC9 = pParagraphFourSub1ForC9;
	}


	/**
	 * @return the mParagraphFiveSub1ForC9
	 */
	public String getParagraphFiveSub1ForC9() {
		return mParagraphFiveSub1ForC9;
	}


	/**
	 * @param mParagraphFiveSub1ForC9 the mParagraphFiveSub1ForC9 to set
	 */
	public void setParagraphFiveSub1ForC9(String pParagraphFiveSub1ForC9) {
		this.mParagraphFiveSub1ForC9 = pParagraphFiveSub1ForC9;
	}


	/**
	 * @return the mParagraphFiveSub2ForC9
	 */
	public String getParagraphFiveSub2ForC9() {
		return mParagraphFiveSub2ForC9;
	}


	/**
	 * @param mParagraphFiveSub2ForC9 the mParagraphFiveSub2ForC9 to set
	 */
	public void setParagraphFiveSub2ForC9(String pParagraphFiveSub2ForC9) {
		this.mParagraphFiveSub2ForC9 = pParagraphFiveSub2ForC9;
	}


	/**
	 * @return the mParagraphEightSub1ForC9
	 */
	public String getParagraphEightSub1ForC9() {
		return mParagraphEightSub1ForC9;
	}


	/**
	 * @param mParagraphEightSub1ForC9 the mParagraphEightSub1ForC9 to set
	 */
	public void setParagraphEightSub1ForC9(String pParagraphEightSub1ForC9) {
		this.mParagraphEightSub1ForC9 = pParagraphEightSub1ForC9;
	}


	/**
	 * @return the mParagraphTenSub1ForC9
	 */
	public String getParagraphTenSub1ForC9() {
		return mParagraphTenSub1ForC9;
	}


	/**
	 * @param mParagraphTenSub1ForC9 the mParagraphTenSub1ForC9 to set
	 */
	public void setParagraphTenSub1ForC9(String pParagraphTenSub1ForC9) {
		this.mParagraphTenSub1ForC9 = pParagraphTenSub1ForC9;
	}


	/**
	 * @return the mParagraphTenSub2ForC9
	 */
	public String getParagraphTenSub2ForC9() {
		return mParagraphTenSub2ForC9;
	}


	/**
	 * @param mParagraphTenSub2ForC9 the mParagraphTenSub2ForC9 to set
	 */
	public void setParagraphTenSub2ForC9(String pParagraphTenSub2ForC9) {
		this.mParagraphTenSub2ForC9 = pParagraphTenSub2ForC9;
	}


	/**
	 * @return the mMiddleLineTextForC9
	 */
	public String getMiddleLineTextForC9() {
		return mMiddleLineTextForC9;
	}


	/**
	 * @param mMiddleLineTextForC9 the mMiddleLineTextForC9 to set
	 */
	public void setMiddleLineTextForC9(String pMiddleLineTextForC9) {
		this.mMiddleLineTextForC9 = pMiddleLineTextForC9;
	}


	/**
	 * @return the mImageScaleForC9
	 */
	public String getImageScaleForC9() {
		return mImageScaleForC9;
	}


	/**
	 * @param mImageScaleForC9 the mImageScaleForC9 to set
	 */
	public void setImageScaleForC9(String pImageScaleForC9) {
		this.mImageScaleForC9 = pImageScaleForC9;
	}


	/**
	 * @return the mParagraphTenSub3ForC9
	 */
	public String getParagraphTenSub3ForC9() {
		return mParagraphTenSub3ForC9;
	}


	/**
	 * @param mParagraphTenSub3ForC9 the mParagraphTenSub3ForC9 to set
	 */
	public void setParagraphTenSub3ForC9(String pParagraphTenSub3ForC9) {
		this.mParagraphTenSub3ForC9 = pParagraphTenSub3ForC9;
	}


	/**
	 * @return the mSalesOrgListForRUO
	 */
	public List<String> getSalesOrgListForRUO() {
		return mSalesOrgListForRUO;
	}


	/**
	 * @param mSalesOrgListForRUO the mSalesOrgListForRUO to set
	 */
	public void setSalesOrgListForRUO(List<String> pSalesOrgListForRUO) {
		this.mSalesOrgListForRUO = pSalesOrgListForRUO;
	}


	/**
	 * @return the mCopcEmailForChina
	 */
	public String getCopcEmailForChina() {
		return mCopcEmailForChina;
	}


	/**
	 * @param mCopcEmailForChina the mCopcEmailForChina to set
	 */
	public void setCopcEmailForChina(String pCopcEmailForChina) {
		this.mCopcEmailForChina = pCopcEmailForChina;
	}


	/**
	 * @return the mChinaHostName
	 */
	public String getChinaHostName() {
		return mChinaHostName;
	}
	

	/**
	 * @param mChinaHostName the mChinaHostName to set
	 */
	public void setChinaHostName(String pChinaHostName) {
		this.mChinaHostName = pChinaHostName;
	}


	/**
	 * @return the mNonChinaHostName
	 */
	public String getNonChinaHostName() {
		return mNonChinaHostName;
	}


	/**
	 * @param mNonChinaHostName the mNonChinaHostName to set
	 */
	public void setNonChinaHostName(String pNonChinaHostName) {
		this.mNonChinaHostName = pNonChinaHostName;
	}


	/**
	 * @return the mAttsHorizontalPosition
	 */
	public String getAttsHorizontalPosition() {
		return mAttsHorizontalPosition;
	}


	/**
	 * @param mAttsHorizontalPosition the mAttsHorizontalPosition to set
	 */
	public void setAttsHorizontalPosition(String pAttsHorizontalPosition) {
		this.mAttsHorizontalPosition = pAttsHorizontalPosition;
	}


	/**
	 * @return the mAttsVeriticalPosition
	 */
	public String getAttsVerticalPosition() {
		return mAttsVerticalPosition;
	}


	/**
	 * @param mAttsVeriticalPosition the mAttsVeriticalPosition to set
	 */
	public void setAttsVerticalPosition(String pAttsVerticalPosition) {
		this.mAttsVerticalPosition = pAttsVerticalPosition;
	}

	
	
	/**	
	 * @return the paymentTermLabel
	 */
	public String getPaymentTermLabel() {
		return paymentTermLabel;
	}

	/**
	 * @param paymentTermLabel the paymentTermLabel to set
	 */
	public void setPaymentTermLabel(String paymentTermLabel) {
		this.paymentTermLabel = paymentTermLabel;
	}


	/**
	 * @return the mImageScaleforConnectiveStamp
	 */
	public String getImageScaleforConnectiveStamp() {
		return mImageScaleforConnectiveStamp;
	}


	/**
	 * @param mImageScaleforConnectiveStamp the mImageScaleforConnectiveStamp to set
	 */
	public void setImageScaleforConnectiveStamp(String pImageScaleforConnectiveStamp) {
		this.mImageScaleforConnectiveStamp = pImageScaleforConnectiveStamp;
	}


	/**
	 * @return the mAttsGenPL
	 */
	public String getAttsGenPL() {
		return mAttsGenPL;
	}


	/**
	 * @param mAttsGenPL the mAttsGenPL to set
	 */
	public void setAttsGenPL(String pAttsGenPL) {
		this.mAttsGenPL = pAttsGenPL;
	}


	/**
	 * @return the mSalesOrgListForChina
	 */
	public List<String> getSalesOrgListForChina() {
		return mSalesOrgListForChina;
	}


	/**
	 * @param mSalesOrgListForChina the mSalesOrgListForChina to set
	 */
	public void setSalesOrgListForChina(List<String> pSalesOrgListForChina) {
		this.mSalesOrgListForChina = pSalesOrgListForChina;
	}


	/**
	 * @return the mSupplierDetailsMap1ForCN
	 */
	public LinkedHashMap<String, String> getSupplierDetailsMap1ForCN() {
		return mSupplierDetailsMap1ForCN;
	}


	/**
	 * @param mSupplierDetailsMap1ForCN the mSupplierDetailsMap1ForCN to set
	 */
	public void setSupplierDetailsMap1ForCN(LinkedHashMap<String, String> pSupplierDetailsMap1ForCN) {
		this.mSupplierDetailsMap1ForCN = pSupplierDetailsMap1ForCN;
	}


	/**
	 * @return the mSupplierDetailsMap2ForCN
	 */
	public LinkedHashMap<String, String> getSupplierDetailsMap2ForCN() {
		return mSupplierDetailsMap2ForCN;
	}


	/**
	 * @param mSupplierDetailsMap2ForCN the mSupplierDetailsMap2ForCN to set
	 */
	public void setSupplierDetailsMap2ForCN(LinkedHashMap<String, String> pSupplierDetailsMap2ForCN) {
		this.mSupplierDetailsMap2ForCN = pSupplierDetailsMap2ForCN;
	}


	/**
	 * @return the mMiddleLineTextForCN
	 */
	public String getMiddleLineTextForCN() {
		return mMiddleLineTextForCN;
	}


	/**
	 * @param mMiddleLineTextForCN the mMiddleLineTextForCN to set
	 */
	public void setMiddleLineTextForCN(String pMiddleLineTextForCN) {
		this.mMiddleLineTextForCN = pMiddleLineTextForCN;
	}


	/**
	 * @return the mMiddleLineTextForPL74
	 */
	public String getMiddleLineTextForPL74() {
		return mMiddleLineTextForPL74;
	}


	/**
	 * @param mMiddleLineTextForPL74 the mMiddleLineTextForPL74 to set
	 */
	public void setMiddleLineTextForPL74(String pMiddleLineTextForPL74) {
		this.mMiddleLineTextForPL74 = pMiddleLineTextForPL74;
	}


	/**
	 * @return the mParagraphTwoChina
	 */
	public String getParagraphTwoChina() {
		return mParagraphTwoChina;
	}


	/**
	 * @param mParagraphTwoChina the mParagraphTwoChina to set
	 */
	public void setParagraphTwoChina(String pParagraphTwoChina) {
		this.mParagraphTwoChina = pParagraphTwoChina;
	}


	/**
	 * @return the mParagraphTwoChinaPL1
	 */
	public String getParagraphTwoChinaPL1() {
		return mParagraphTwoChinaPL1;
	}


	/**
	 * @param mParagraphTwoChinaPL1 the mParagraphTwoChinaPL1 to set
	 */
	public void setParagraphTwoChinaPL1(String pParagraphTwoChinaPL1) {
		this.mParagraphTwoChinaPL1 = pParagraphTwoChinaPL1;
	}


	/**
	 * @return the mParagraphTwoChinaPL2
	 */
	public String getParagraphTwoChinaPL2() {
		return mParagraphTwoChinaPL2;
	}


	/**
	 * @param mParagraphTwoChinaPL2 the mParagraphTwoChinaPL2 to set
	 */
	public void setParagraphTwoChinaPL2(String pParagraphTwoChinaPL2) {
		this.mParagraphTwoChinaPL2 = pParagraphTwoChinaPL2;
	}


	/**
	 * @return the mParagraphTwoChinaPL3
	 */
	public String getParagraphTwoChinaPL3() {
		return mParagraphTwoChinaPL3;
	}


	/**
	 * @param mParagraphTwoChinaPL3 the mParagraphTwoChinaPL3 to set
	 */
	public void setParagraphTwoChinaPL3(String pParagraphTwoChinaPL3) {
		this.mParagraphTwoChinaPL3 = pParagraphTwoChinaPL3;
	}


	/**
	 * @return the mParagraphSevenForCN
	 */
	public String getParagraphSevenForCN() {
		return mParagraphSevenForCN;
	}


	/**
	 * @param mParagraphSevenForCN the mParagraphSevenForCN to set
	 */
	public void setParagraphSevenForCN(String pParagraphSevenForCN) {
		this.mParagraphSevenForCN = pParagraphSevenForCN;
	}


	/**
	 * @return the mParagraphSevenForPL1
	 */
	public String getParagraphSevenForPL1() {
		return mParagraphSevenForPL1;
	}


	/**
	 * @param mParagraphSevenForPL1 the mParagraphSevenForPL1 to set
	 */
	public void setParagraphSevenForPL1(String pParagraphSevenForPL1) {
		this.mParagraphSevenForPL1 = pParagraphSevenForPL1;
	}


	/**
	 * @return the mParagraphSevenForPL2
	 */
	public String getParagraphSevenForPL2() {
		return mParagraphSevenForPL2;
	}


	/**
	 * @param mParagraphSevenForPL2 the mParagraphSevenForPL2 to set
	 */
	public void setParagraphSevenForPL2(String pParagraphSevenForPL2) {
		this.mParagraphSevenForPL2 = pParagraphSevenForPL2;
	}


	/**
	 * @return the mParagraphSevenForPL3
	 */
	public String getParagraphSevenForPL3() {
		return mParagraphSevenForPL3;
	}


	/**
	 * @param mParagraphSevenForPL3 the mParagraphSevenForPL3 to set
	 */
	public void setParagraphSevenForPL3(String pParagraphSevenForPL3) {
		this.mParagraphSevenForPL3 = pParagraphSevenForPL3;
	}


	/**
	 * @return the mParagraphFourForCN
	 */
	public String getParagraphFourForCN() {
		return mParagraphFourForCN;
	}


	/**
	 * @param mParagraphFourForCN the mParagraphFourForCN to set
	 */
	public void setParagraphFourForCN(String pParagraphFourForCN) {
		this.mParagraphFourForCN = pParagraphFourForCN;
	}


	/**
	 * @return the mParagraphFourForPL1
	 */
	public String getParagraphFourForPL1() {
		return mParagraphFourForPL1;
	}


	/**
	 * @param mParagraphFourForPL1 the mParagraphFourForPL1 to set
	 */
	public void setParagraphFourForPL1(String pParagraphFourForPL1) {
		this.mParagraphFourForPL1 = pParagraphFourForPL1;
	}


	/**
	 * @return the mParagraphFourForPL2
	 */
	public String getParagraphFourForPL2() {
		return mParagraphFourForPL2;
	}


	/**
	 * @param mParagraphFourForPL2 the mParagraphFourForPL2 to set
	 */
	public void setParagraphFourForPL2(String pParagraphFourForPL2) {
		this.mParagraphFourForPL2 = pParagraphFourForPL2;
	}


	/**
	 * @return the mParagraphFourForPL3
	 */
	public String getParagraphFourForPL3() {
		return mParagraphFourForPL3;
	}


	/**
	 * @param mParagraphFourForPL3 the mParagraphFourForPL3 to set
	 */
	public void setParagraphFourForPL3(String pParagraphFourForPL3) {
		this.mParagraphFourForPL3 = pParagraphFourForPL3;
	}


	/**
	 * @return the mCountForNewPage
	 */
	public Integer getCountForNewPage() {
		return mCountForNewPage;
	}


	/**
	 * @param mCountForNewPage the mCountForNewPage to set
	 */
	public void setCountForNewPage(Integer pCountForNewPage) {
		this.mCountForNewPage = pCountForNewPage;
	}


	/**
	 * @return the mCustomerSpecialEinvoiceEn
	 */
	public String getCustomerSpecialEinvoiceEn() {
		return mCustomerSpecialEinvoiceEn;
	}


	/**
	 * @param mCustomerSpecialEinvoiceEn the mCustomerSpecialEinvoiceEn to set
	 */
	public void setCustomerSpecialEinvoiceEn(String pCustomerSpecialEinvoiceEn) {
		this.mCustomerSpecialEinvoiceEn = pCustomerSpecialEinvoiceEn;
	}


	/**
	 * @return the mCustomerSpecialEinvoiceZh
	 */
	public String getCustomerSpecialEinvoiceZh() {
		return mCustomerSpecialEinvoiceZh;
	}


	/**
	 * @param mCustomerSpecialEinvoiceZh the mCustomerSpecialEinvoiceZh to set
	 */
	public void setCustomerSpecialEinvoiceZh(String pCustomerSpecialEinvoiceZh) {
		this.mCustomerSpecialEinvoiceZh = pCustomerSpecialEinvoiceZh;
	}


	/**
	 * @return the mCustomerNormalPaperInvoiceEn
	 */
	public String getCustomerNormalPaperInvoiceEn() {
		return mCustomerNormalPaperInvoiceEn;
	}


	/**
	 * @param mCustomerNormalPaperInvoiceEn the mCustomerNormalPaperInvoiceEn to set
	 */
	public void setCustomerNormalPaperInvoiceEn(String pCustomerNormalPaperInvoiceEn) {
		this.mCustomerNormalPaperInvoiceEn = pCustomerNormalPaperInvoiceEn;
	}


	/**
	 * @return the mCustomerNormalPaperInvoiceZh
	 */
	public String getCustomerNormalPaperInvoiceZh() {
		return mCustomerNormalPaperInvoiceZh;
	}


	/**
	 * @param mCustomerNormalPaperInvoiceZh the mCustomerNormalPaperInvoiceZh to set
	 */
	public void setCustomerNormalPaperInvoiceZh(String pCustomerNormalPaperInvoiceZh) {
		this.mCustomerNormalPaperInvoiceZh = pCustomerNormalPaperInvoiceZh;
	}


	/**
	 * @return the mParagraphFourForPL5
	 */
	public String getParagraphFourForPL5() {
		return mParagraphFourForPL5;
	}


	/**
	 * @param mParagraphFourForPL5 the mParagraphFourForPL5 to set
	 */
	public void setParagraphFourForPL5(String pParagraphFourForPL5) {
		this.mParagraphFourForPL5 = pParagraphFourForPL5;
	}


	/**
	 * @return the mParagraphEightForCN
	 */
	public String getParagraphEightForCN() {
		return mParagraphEightForCN;
	}


	/**
	 * @param mParagraphEightForCN the mParagraphEightForCN to set
	 */
	public void setParagraphEightForCN(String pParagraphEightForCN) {
		this.mParagraphEightForCN = pParagraphEightForCN;
	}


	/**
	 * @return the mSubPara1ForCN
	 */
	public String getSubPara1ForCN() {
		return mSubPara1ForCN;
	}


	/**
	 * @param mSubPara1ForCN the mSubPara1ForCN to set
	 */
	public void setSubPara1ForCN(String pSubPara1ForCN) {
		this.mSubPara1ForCN = pSubPara1ForCN;
	}


	/**
	 * @return the mSubPara2ForCN
	 */
	public String getSubPara2ForCN() {
		return mSubPara2ForCN;
	}


	/**
	 * @param mSubPara2ForCN the mSubPara2ForCN to set
	 */
	public void setSubPara2ForCN(String pSubPara2ForCN) {
		this.mSubPara2ForCN = pSubPara2ForCN;
	}


	/**
	 * @return the mParagraphTenForCN
	 */
	public String getParagraphTenForCN() {
		return mParagraphTenForCN;
	}


	/**
	 * @param mParagraphTenForCN the mParagraphTenForCN to set
	 */
	public void setParagraphTenForCN(String pParagraphTenForCN) {
		this.mParagraphTenForCN = pParagraphTenForCN;
	}


	/**
	 * @return the mParagraphNineForCN
	 */
	public String getParagraphNineForCN() {
		return mParagraphNineForCN;
	}


	/**
	 * @param mParagraphNineForCN the mParagraphNineForCN to set
	 */
	public void setParagraphNineForCN(String pParagraphNineForCN) {
		this.mParagraphNineForCN = pParagraphNineForCN;
	}


	/**
	 * @return the mParagraphThreeForCN
	 */
	public String getParagraphThreeForCN() {
		return mParagraphThreeForCN;
	}


	/**
	 * @param mParagraphThreeForCN the mParagraphThreeForCN to set
	 */
	public void setParagraphThreeForCN(String pParagraphThreeForCN) {
		this.mParagraphThreeForCN = pParagraphThreeForCN;
	}


	/**
	 * @return the mConnectiveStampScaleSizeForCN
	 */
	public String getConnectiveStampScaleSizeForCN() {
		return mConnectiveStampScaleSizeForCN;
	}


	/**
	 * @param mConnectiveStampScaleSizeForCN the mConnectiveStampScaleSizeForCN to set
	 */
	public void setConnectiveStampScaleSizeForCN(String pConnectiveStampScaleSizeForCN) {
		this.mConnectiveStampScaleSizeForCN = pConnectiveStampScaleSizeForCN;
	}


	/**
	 * @return the mImageScaleSizeForCN
	 */
	public String getImageScaleSizeForCN() {
		return mImageScaleSizeForCN;
	}


	/**
	 * @param mImageScaleSizeForCN the mImageScaleSizeForCN to set
	 */
	public void setImageScaleSizeForCN(String pImageScaleSizeForCN) {
		this.mImageScaleSizeForCN = pImageScaleSizeForCN;
	}


    /**
     * @return the productLineFor04C9LSAG
     */
    public String getProductLineFor04C9LSAG() {
        return productLineFor04C9LSAG;
    }


    /**
     * @param productLineFor04C9LSAG the productLineFor04C9LSAG to set
     */
    public void setProductLineFor04C9LSAG(String productLineFor04C9LSAG) {
        this.productLineFor04C9LSAG = productLineFor04C9LSAG;
    }


    /**
     * @return the productLineForC9LSAG
     */
    public String getProductLineForC9LSAG() {
        return productLineForC9LSAG;
    }


    /**
     * @param productLineForC9LSAG the productLineForC9LSAG to set
     */
    public void setProductLineForC9LSAG(String productLineForC9LSAG) {
        this.productLineForC9LSAG = productLineForC9LSAG;
    }


    /**
     * @return the paragraphThreeForC9LSAG
     */
    public String getParagraphThreeForC9LSAG() {
        return paragraphThreeForC9LSAG;
    }


    /**
     * @param paragraphThreeForC9LSAG the paragraphThreeForC9LSAG to set
     */
    public void setParagraphThreeForC9LSAG(String paragraphThreeForC9LSAG) {
        this.paragraphThreeForC9LSAG = paragraphThreeForC9LSAG;
    }
    /**
     * @return the paragraphSixForC9LSAG
     */
    public String getParagraphSixForC9LSAG() {
        return paragraphSixForC9LSAG;
    }


    /**
     * @param paragraphSixForC9LSAG the paragraphSixForC9LSAG to set
     */
    public void setParagraphSixForC9LSAG(String paragraphSixForC9LSAG) {
        this.paragraphSixForC9LSAG = paragraphSixForC9LSAG;
    }


    /**
     * @return the paragraphSevenForC9LSAG
     */
    public String getParagraphSevenForC9LSAG() {
        return paragraphSevenForC9LSAG;
    }


    /**
     * @param paragraphSevenForC9LSAG the paragraphSevenForC9LSAG to set
     */
    public void setParagraphSevenForC9LSAG(String paragraphSevenForC9LSAG) {
        this.paragraphSevenForC9LSAG = paragraphSevenForC9LSAG;
    }


    /**
     * @return the paragraphSevenForC9DGGandLSAG
     */
    public String getParagraphSevenForC9DGGandLSAG() {
        return paragraphSevenForC9DGGandLSAG;
    }


    /**
     * @param paragraphSevenForC9DGGandLSAG the paragraphSevenForC9DGGandLSAG to set
     */
    public void setParagraphSevenForC9DGGandLSAG(String paragraphSevenForC9DGGandLSAG) {
        this.paragraphSevenForC9DGGandLSAG = paragraphSevenForC9DGGandLSAG;
    }


    /**
     * @return the paragraphTwoForC9LSAG
     */
    public String getParagraphTwoForC9LSAG() {
        return paragraphTwoForC9LSAG;
    }


    /**
     * @param paragraphTwoForC9LSAG the paragraphTwoForC9LSAG to set
     */
    public void setParagraphTwoForC9LSAG(String paragraphTwoForC9LSAG) {
        this.paragraphTwoForC9LSAG = paragraphTwoForC9LSAG;
    }


    /**
     * @return the paragraphThreeForC9Heading
     */
    public String getParagraphThreeForC9Heading() {
        return paragraphThreeForC9Heading;
    }


    /**
     * @param paragraphThreeForC9Heading the paragraphThreeForC9Heading to set
     */
    public void setParagraphThreeForC9Heading(String paragraphThreeForC9Heading) {
        this.paragraphThreeForC9Heading = paragraphThreeForC9Heading;
    }


    /**
     * @return the paragraphTwoForC9Heading
     */
    public String getParagraphTwoForC9Heading() {
        return paragraphTwoForC9Heading;
    }


    /**
     * @param paragraphTwoForC9Heading the paragraphTwoForC9Heading to set
     */
    public void setParagraphTwoForC9Heading(String paragraphTwoForC9Heading) {
        this.paragraphTwoForC9Heading = paragraphTwoForC9Heading;
    }


    /**
     * @return the paragraphSixForC9Heading
     */
    public String getParagraphSixForC9Heading() {
        return paragraphSixForC9Heading;
    }


    /**
     * @param paragraphSixForC9Heading the paragraphSixForC9Heading to set
     */
    public void setParagraphSixForC9Heading(String paragraphSixForC9Heading) {
        this.paragraphSixForC9Heading = paragraphSixForC9Heading;
    }


    /**
     * @return the sellerValueForC9
     */
    public String getSellerValueForC9() {
        return sellerValueForC9;
    }


    /**
     * @param sellerValueForC9 the sellerValueForC9 to set
     */
    public void setSellerValueForC9(String sellerValueForC9) {
        this.sellerValueForC9 = sellerValueForC9;
    }


    /**
     * @return the paragraphFiveForCN
     */
    public String getParagraphFiveForCN() {
        return paragraphFiveForCN;
    }


    /**
     * @param paragraphFiveForCN the paragraphFiveForCN to set
     */
    public void setParagraphFiveForCN(String paragraphFiveForCN) {
        this.paragraphFiveForCN = paragraphFiveForCN;
    }

}