/**
 * 
 */
package com.agilent.commonstore.crm.rest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.agilent.base.droplet.AgilentCurrencyTagConverter;
import com.agilent.base.platform.ApplicationException;
import com.agilent.base.platform.util.EncryptDecryptHelper;
import com.agilent.base.profile.AgilentProfile;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.SessionBean;
import com.agilent.base.rest.Constants;
import com.agilent.base.rest.addOnProducts.AddOnProductDetails;
import com.agilent.base.rest.addOnProducts.AddOnProductResults;
import com.agilent.base.rest.addOnProducts.AddOnProductsRoot;
import com.agilent.base.rest.addOnProducts.InstrumentResultSet;
import com.agilent.base.rest.addOnProducts.ItemsResultSet;
import com.agilent.base.rest.addOnProducts.ProductAddOnsResponse;
import com.agilent.base.rest.addOnProducts.SystemsSetResult;
import com.agilent.base.rest.crm.SAPCRMAPIManager;
import com.google.gson.Gson;

import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.RequestLocale;
import atg.servlet.ServletUtil;

/**
 * @author 292847
 *
 */
public class FetchAddOnProductsDetails extends GenericService implements Constants {   
    
    
    private static final String CLASSNAME = "FetchAddOnProductsDetails";
    public static final String GET_PRODUCT_ADDONS = "fetchAddOnProductsDetails";    
    private static final ParameterName PROFILE = ParameterName.getParameterName("profile");   
    private static final String PROFILE_COMPONENT="/atg/userprofiling/Profile";
    private SAPCRMAPIManager mSapCRMAPIManager = null;
    private EncryptDecryptHelper mEncryptDecryptHelper;
    private Map<String, String> mCurrencyCodeToLocaleMap;
    
    
   
	public List<ProductAddOnsResponse> fetchAddOnProductsDetails() {
        vlogDebug("Entering the method :: {0} in class: {1}", GET_PRODUCT_ADDONS, CLASSNAME);
        DynamoHttpServletRequest request = ServletUtil.getCurrentRequest();
        AgilentProfile profile = null;
        List<ProductAddOnsResponse> finalResponse = new ArrayList<ProductAddOnsResponse>();
        SessionBean sessionBean = null;
        String contactId = null;
        String quoteId = null;
        String encQuoteId = request.getParameter(QUOTE_ID);
        if (null != request && REQ_GET_METHOD.equalsIgnoreCase(request.getMethod())) {
            request.getResponse().addHeader("Access-Control-Allow-Origin", "*.agilent.com");
            request.getResponse().setContentType("application/json");
            profile = (AgilentProfile) request.getObjectParameter(PROFILE);
            if (null == profile) {
                profile = (AgilentProfile) request.resolveName(PROFILE_COMPONENT);
            }
            if (null == profile) {
                vlogDebug("Profile is null");
            } else if (!profile.isTransient()) {
                sessionBean = profile.getSessionBean();
                finalResponse = sessionBean.getProductAddOnsList();
                try {
                    if (StringUtils.isNotBlank(encQuoteId)) {
                        quoteId = getEncryptDecryptHelper().decrypt(encQuoteId, "");
                    }
                } catch (ApplicationException e) {
                    vlogError(e, "ApplicationException got while trying to Decrypt and Encrypt");
                    finalResponse = null;
                }
                if (sessionBean != null && finalResponse == null) { 
                	finalResponse = new ArrayList<ProductAddOnsResponse>();
                    AgilentPropertyManager propManager = (AgilentPropertyManager) profile.getProfileTools().getPropertyManager();
                    if (profile.getPropertyValue(propManager.getCrmContactNumberPropertyName()) != null
                            && !((String) profile.getPropertyValue(propManager.getCrmContactNumberPropertyName())).isEmpty()) {
                        contactId = (String) profile.getPropertyValue(propManager.getCrmContactNumberPropertyName());
                    } else if (profile.getPropertyValue(propManager.getSapContactNumberPropertyName()) != null
                            && !((String) profile.getPropertyValue(propManager.getSapContactNumberPropertyName())).isEmpty()) {
                        contactId = (String) profile.getPropertyValue(propManager.getSapContactNumberPropertyName());
                    }
                    if (StringUtils.isNotBlank(contactId) && StringUtils.isNotBlank(quoteId)) {
                        vlogInfo("Calling CRM service to fetch ProductAddOns");
                        String crmResponseJson = getSapCRMAPIManager().getProductAddons(contactId, quoteId);
                        vlogInfo("Received CRM service response for ProductAddOns");
                        AddOnProductsRoot resultResponse = new Gson().fromJson(crmResponseJson, AddOnProductsRoot.class);
                        if (resultResponse !=null && resultResponse.getD() != null && resultResponse.getD().getResults() != null && !resultResponse.getD().getResults().isEmpty()) {                            
                            populateAddOnProducts(finalResponse, resultResponse.getD().getResults());
                            vlogInfo("Populated final response for ProductAddOns");
                        }
                    }
                }
                sessionBean.setProductAddOnsList(finalResponse);
            } else {
                vlogDebug("Profile is Transient ");
            }
        }
        vlogDebug("Exiting the method :: {0} in class: {1}", GET_PRODUCT_ADDONS, CLASSNAME);
        return finalResponse;

    }

    private void populateAddOnProducts(List<ProductAddOnsResponse> pProductAddOns, List<AddOnProductResults> pResults) {
        Locale currencyLocale = Locale.US;
        for (AddOnProductResults result : pResults) {
            ProductAddOnsResponse addOnsResponse = new ProductAddOnsResponse();
            addOnsResponse.setQuoteId(result.getQuoteId());
            addOnsResponse.setQuoteGrossValue(result.getGrossValue());
            addOnsResponse.setContactId(result.getContactId());
            addOnsResponse.setAdjustedQuote(result.getAdjustedQuote());
            String quoteCurrency = null;
            List<InstrumentResultSet> instrumentList = new ArrayList<InstrumentResultSet>();
            if (result.getItemsSet() != null && result.getItemsSet().getResults() != null && !result.getItemsSet().getResults().isEmpty()) {
                for (ItemsResultSet itemsResultSet : result.getItemsSet().getResults()) {
                    String lItemNumber = itemsResultSet.getItemNo();
                    InstrumentResultSet instrumentResultSet = new InstrumentResultSet();
                    instrumentResultSet.setItemNo(itemsResultSet.getItemNo());
                    instrumentResultSet.setOrderedProd(itemsResultSet.getOrderedProd());
                    instrumentResultSet.setIbaseID(itemsResultSet.getIbase());
                    instrumentResultSet.setSystemId(itemsResultSet.getSystemId());
                    instrumentResultSet.setSystemDesc((itemsResultSet.getSystemDesc()));
                    instrumentResultSet.setProdDesc(itemsResultSet.getProdDesc());
                    instrumentResultSet.setItemGuid(itemsResultSet.getItemGuid());
                    if (result.getSystemsSet() != null && result.getSystemsSet().getResults() != null && !result.getSystemsSet().getResults().isEmpty()) {
                        List<SystemsSetResult> systemsSetResults = new ArrayList<SystemsSetResult>();
                        for (SystemsSetResult systemsSetResult : result.getSystemsSet().getResults()) {
                            String lSystemItemNumber = systemsSetResult.getItemNo();
                            if (StringUtils.isNotBlank(lItemNumber) && StringUtils.isNotBlank(lSystemItemNumber) && lItemNumber.equalsIgnoreCase(lSystemItemNumber)) {
                                vlogDebug("Component match found for Item Number :{0} ", lItemNumber);
                                systemsSetResults.add(systemsSetResult);
                            }

                        }
                        instrumentResultSet.setComponentSet(systemsSetResults);
                    }
                    if (itemsResultSet.getAddOnProductsSet() != null && itemsResultSet.getAddOnProductsSet().getResults() != null
                            && !itemsResultSet.getAddOnProductsSet().getResults().isEmpty()) {
                        for (AddOnProductDetails addOnProductResults : itemsResultSet.getAddOnProductsSet().getResults()) {
                            if (addOnProductResults != null && StringUtils.isNotBlank(addOnProductResults.getCurrency())) {
                                quoteCurrency = addOnProductResults.getCurrency();
                                if (getCurrencyCodeToLocaleMap().containsKey(quoteCurrency)) {
                                    currencyLocale = RequestLocale.getCachedLocale(getCurrencyCodeToLocaleMap().get(quoteCurrency));
                                }

                                if (StringUtils.isNotBlank(addOnProductResults.getPrice())) {
                                    Double priceDoubleValue = new Double(addOnProductResults.getPrice().trim());
                                    String formattedPrice = formatCurrency(priceDoubleValue, currencyLocale.toString(), quoteCurrency);
                                    addOnProductResults.setFormattedPrice(formattedPrice);
                                }
                            }
                            

                        }

                    }

                    instrumentResultSet.setAddOnProductsSet(itemsResultSet.getAddOnProductsSet());
                    instrumentList.add(instrumentResultSet);
                }
                addOnsResponse.setInstrumentDetails(instrumentList);

            }

            if (result.getAddontypesSet() != null && result.getAddontypesSet().getResults() != null && !result.getAddontypesSet().getResults().isEmpty()) {
                addOnsResponse.setProductAddOns(result.getAddontypesSet().getResults());
            }

            if (result.getPartnersSet() != null && result.getPartnersSet().getResults() != null && !result.getPartnersSet().getResults().isEmpty()) {
                addOnsResponse.setPartnerResultSet(result.getPartnersSet().getResults());
            }
            if (StringUtils.isNotBlank(result.getGrossValue()) && StringUtils.isNotBlank(quoteCurrency)) {
                Double quoteGrossDoubleValue = new Double(result.getGrossValue().trim());
                String formattedGrossValue = formatCurrency(quoteGrossDoubleValue, currencyLocale.toString(), quoteCurrency);
                addOnsResponse.setFormattedGrossValue(formattedGrossValue);
            }
            pProductAddOns.add(addOnsResponse);
        }

    }
    
    private String formatCurrency(Object pCurrency, String localeString, String currencyCode) {
        return AgilentCurrencyTagConverter.formatCurrency(pCurrency, localeString, currencyCode);
    }
    

    public SAPCRMAPIManager getSapCRMAPIManager() {
        return mSapCRMAPIManager;
    }

    public void setSapCRMAPIManager(SAPCRMAPIManager pSapCRMAPIManager) {
        mSapCRMAPIManager = pSapCRMAPIManager;
    }
    
    public EncryptDecryptHelper getEncryptDecryptHelper() {
		return mEncryptDecryptHelper;
	}

	public void setEncryptDecryptHelper(EncryptDecryptHelper mEncryptDecryptHelper) {
		this.mEncryptDecryptHelper = mEncryptDecryptHelper;
	}

    /**
     * Gets the value of property currencyCodeToLocaleMap
     *
     * @return the value of property currencyCodeToLocaleMap
     */
    public Map<String, String> getCurrencyCodeToLocaleMap() {
        return mCurrencyCodeToLocaleMap;
    }

    /**
     * Sets the value of property currencyCodeToLocaleMap with value pCurrencyCodeToLocaleMap
     *
     * @param pCurrencyCodeToLocaleMap
     *            for setting property currencyCodeToLocaleMap
     */
    public void setCurrencyCodeToLocaleMap(Map<String, String> pCurrencyCodeToLocaleMap) {
        mCurrencyCodeToLocaleMap = pCurrencyCodeToLocaleMap;
    }

	

}
