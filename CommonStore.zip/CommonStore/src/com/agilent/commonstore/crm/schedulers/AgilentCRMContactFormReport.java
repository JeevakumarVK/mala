package com.agilent.commonstore.crm.schedulers;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.agilent.commonstore.crm.bean.CrmContractFormBean;

import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryView;
import atg.repository.rql.RqlStatement;
import atg.service.scheduler.ScheduledJob;
import atg.service.scheduler.Scheduler;
import atg.service.scheduler.SingletonSchedulableService;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;
import atg.userprofiling.email.TemplateEmailSender;

/***************   This class is used to send weekly report of how
many users contacted crm sales representative
**********************/
		
		

public  class AgilentCRMContactFormReport extends SingletonSchedulableService {
	
	
	private RepositoryView mRepositoryView;
	private Repository     mRequestQuoteRepository;
	private RqlStatement         mDateRange;
	private TemplateEmailSender templateEmailSender;
	private TemplateEmailInfoImpl agilentContactReportTemplateInfo;
	private String subject;
	private String messageFrom;
	private String messageCc;
	private String messageTo;
	private String mreportColumns;
	
	  /**
	 * @return the mreportColumns
	 */
	public String getReportColumns() {
		return mreportColumns;
	}
	/**
	 * @param mreportColumns the mreportColumns to set
	 */
	public void setReportColumns(String mreportColumns) {
		this.mreportColumns = mreportColumns;
	}




	public void doScheduledTask( Scheduler scheduler, ScheduledJob job) {
		  CrmContractFormBean crmContactFormbean=null; 
		  List<CrmContractFormBean> contactList=new ArrayList<CrmContractFormBean>();
		  FileOutputStream fos = null;
		  File file=null;
		   //SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		  SimpleDateFormat dtFormat = new SimpleDateFormat("dd-MMM-yy");
		  
		
		  try {
			 
			  List<Map<String, Object>>  contactInfo = new ArrayList<Map<String,Object>>();
				RepositoryView view = getRequestQuoteRepository().getView("CRMContactForm");
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy hh:mm:ss a");
              Calendar cal = Calendar.getInstance();
              Calendar calendar = Calendar.getInstance();
              calendar.add(Calendar.DAY_OF_MONTH, -7);
              Date currentDate = dateFormat.parse(dateFormat.format(cal.getTime()));
              Date sevenDaysAgo = dateFormat.parse(dateFormat.format(calendar.getTime()));
				RqlStatement statement = getDateRange();
				   Object[] params = new Object[2];
		            params[0] = sevenDaysAgo;
		            params[1] = currentDate;
		            RepositoryItem[] results;
		            results = statement.executeQuery(view, params);
		            if (results != null && results.length > 0) {
		                for ( RepositoryItem result : results) {
		                	crmContactFormbean=new CrmContractFormBean();
		                	crmContactFormbean.setName((String)result.getPropertyValue("name"));
		                	crmContactFormbean.setPhoneNumber((String)result.getPropertyValue("phoneNumber"));
		                	crmContactFormbean.setEmail((String)result.getPropertyValue("email"));
		                	crmContactFormbean.setContactMethod((String)result.getPropertyValue("contactMethod"));
		                	crmContactFormbean.setContactDate(dtFormat.format(((Date)result.getPropertyValue("contactDate"))));
		                	crmContactFormbean.setCrmEnquiry((String)result.getPropertyValue("crmInquiry"));
		                	crmContactFormbean.setMessage((String)result.getPropertyValue("message"));
		                	crmContactFormbean.setContractId((String)result.getPropertyValue("contractId"));
		                	crmContactFormbean.setQuoteId((String)result.getPropertyValue("quoteId"));
		                	crmContactFormbean.setSalesName((String)result.getPropertyValue("salesName"));
		                	crmContactFormbean.setSalesEmail((String)result.getPropertyValue("salesEmail"));
		                	crmContactFormbean.setContactCountry((String)result.getPropertyValue("contactCountry"));
		                	crmContactFormbean.setContactRegion((String)result.getPropertyValue("contactRegion"));
		                	contactList.add(crmContactFormbean);
		                	
		                }
		            }
		            vlogDebug("Result set of users who contacted sales rep {0}", contactList);
		            file=new File("contactData.xls");
		            
					 fos = new FileOutputStream(file);
		         exportContactReport(contactList,fos);
				 File[] attachments={file};
		    	Map<String, Object> templateParameters = new HashMap<String, Object>();
				templateParameters.put("contactInfo",contactInfo);
				getAgilentContactReportTemplateInfo().setTemplateParameters(templateParameters);
				getAgilentContactReportTemplateInfo().setMessageFrom(getMessageFrom());
				getAgilentContactReportTemplateInfo().setMessageSubject("Weekly contact Form Report");
				getAgilentContactReportTemplateInfo().setMessageTo(getMessageTo());
				getAgilentContactReportTemplateInfo().setMessageCc(getMessageCc());
				getAgilentContactReportTemplateInfo().setMessageAttachments(attachments);
				
				
				try {
					getTemplateEmailSender().sendEmailMessage(getAgilentContactReportTemplateInfo(), new String[] {getMessageTo() }, Boolean.FALSE, false);
					 vlogDebug("Email sent successfully to sales rep");
				} catch (TemplateEmailException e) {
					e.printStackTrace();
				}
		            
			} catch (RepositoryException e) {
				 vlogError(e, "exception found while access the data Error:{0}", e);
			}
			//return Collections.emptyList();
		  catch (ParseException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
	  }
		  
		  
		  
		  
		  
	  private void exportContactReport(List<CrmContractFormBean> pList,FileOutputStream fos) {
			
				try {
					
					if (pList != null && pList.size() > 0) {
					HSSFWorkbook wb = new HSSFWorkbook();
					HSSFSheet sheet = wb.createSheet("Export Worksheet");

					HSSFRow row = sheet.createRow(0);
					String[] cols = getReportColumns().split(",");
					for (int i = 0; i < cols.length; i++) {
						String cellValue = cols[i];
						row.createCell(i).setCellValue(cellValue);
					}
					populateContactXL(pList, sheet);
					wb.write(fos);
					fos.close();
					}
					
					else {
						vlogDebug("No results returned");
						return;
					}
				} catch (FileNotFoundException e) {
					vlogError(e, "printing the Excel sheet error{0}", e);
				} catch (IOException e) {
					vlogError(e, "IO exception error:{0}", e);
				}
			}
		
	  private HSSFSheet populateContactXL(  List<CrmContractFormBean> contactList, HSSFSheet sheet) {
		  int rownum = 1;
		   try {
		   if (contactList != null) {
		   for ( CrmContractFormBean crmContractFormBean : contactList) {
           HSSFRow newRow = sheet.createRow(rownum);
           newRow.createCell(0).setCellValue(crmContractFormBean.getName() == null ? "" : crmContractFormBean.getName());
           newRow.createCell(1).setCellValue(crmContractFormBean.getPhoneNumber() == null ? "" : crmContractFormBean.getPhoneNumber());
           newRow.createCell(2).setCellValue(crmContractFormBean.getEmail() == null ? "" : crmContractFormBean.getEmail());
           newRow.createCell(3).setCellValue(crmContractFormBean.getContactMethod() == null ? "" : crmContractFormBean.getContactMethod());
           newRow.createCell(4).setCellValue(crmContractFormBean.getCrmEnquiry() == null ? "" : crmContractFormBean.getCrmEnquiry());
           newRow.createCell(5).setCellValue(crmContractFormBean.getMessage() == null ? "" : crmContractFormBean.getMessage());
           newRow.createCell(6).setCellValue(crmContractFormBean.getContactDate());
           newRow.createCell(7).setCellValue(crmContractFormBean.getContractId() == null ? "" : crmContractFormBean.getContractId());
           newRow.createCell(8).setCellValue(crmContractFormBean.getQuoteId() == null ? "" : crmContractFormBean.getQuoteId());
           newRow.createCell(9).setCellValue(crmContractFormBean.getSalesName() == null ? "" : crmContractFormBean.getSalesName());
           newRow.createCell(10).setCellValue(crmContractFormBean.getSalesEmail() == null ? "" : crmContractFormBean.getSalesEmail());
           newRow.createCell(11).setCellValue(crmContractFormBean.getContactCountry() == null ? "" : crmContractFormBean.getContactCountry());
           newRow.createCell(12).setCellValue(crmContractFormBean.getContactRegion() == null ? "" : crmContractFormBean.getContactRegion());
           
           rownum++;
		   		}
		   } 
		 else {
			 vlogDebug("No data found");
               }
		   } catch (Exception e) {
			 vlogError(e, "Registration report error{0}", e);
			 }
		   return sheet;
	  }



	public RepositoryView getRepositoryView() {
		return mRepositoryView;
	}

	public void setRepositoryView(RepositoryView mRepositoryView) {
		this.mRepositoryView = mRepositoryView;
	}

	public Repository getRequestQuoteRepository() {
		return mRequestQuoteRepository;
	}

	public void setRequestQuoteRepository(Repository mRequestQuoteRepository) {
		this.mRequestQuoteRepository = mRequestQuoteRepository;
	}

	public RqlStatement getDateRange() {
		return mDateRange;
	}


	public void setDateRange(RqlStatement mDateRange) {
		this.mDateRange = mDateRange;
	}
	public TemplateEmailSender getTemplateEmailSender() {
		return templateEmailSender;
	}

	public void setTemplateEmailSender(TemplateEmailSender mTemplateEmailSender) {
		templateEmailSender = mTemplateEmailSender;
	}

	public TemplateEmailInfoImpl getAgilentContactReportTemplateInfo() {
		return agilentContactReportTemplateInfo;
	}

	public void setAgilentContactReportTemplateInfo(
			TemplateEmailInfoImpl mAgilentContactReportTemplateInfo) {
		agilentContactReportTemplateInfo = mAgilentContactReportTemplateInfo;
	}





	public String getSubject() {
		return subject;
	}





	public void setSubject(String mSubject) {
		subject = mSubject;
	}





	public String getMessageFrom() {
		return messageFrom;
	}





	public void setMessageFrom(String mMessageFrom) {
		messageFrom = mMessageFrom;
	}





	public String getMessageCc() {
		return messageCc;
	}





	public void setMessageCc(String mMessageCc) {
		messageCc = mMessageCc;
	}





	public String getMessageTo() {
		return messageTo;
	}





	public void setMessageTo(String mMessageTo) {
		messageTo = mMessageTo;
	}
	



	
}
