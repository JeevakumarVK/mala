package com.agilent.commonstore.lms.droplets;

import static com.agilent.base.platform.Constants.EMPTY;
import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import atg.commerce.order.CommerceItem;
import atg.commerce.order.Order;
import atg.commerce.order.OrderHolder;
import atg.nucleus.naming.ParameterName;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.lms.services.AgilentLmsManager;

public class EstimatedTaxDroplet extends DynamoServlet {

	OrderHolder orderHolder;
	Double taxPercent;

	public void service( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
 		
		Double estimatedTax = null;
		Order order=null;
		order=(Order) request.getObjectParameter("order");
		if(null!=order){
				Double rawSubTotal= order.getPriceInfo().getRawSubtotal();
				estimatedTax=rawSubTotal*(getTaxPercent());
		}
		else{
		if(null!=getOrderHolder() && null!=getOrderHolder().getCurrent().getPriceInfo()){
			Double rawSubTotal= getOrderHolder().getCurrent().getPriceInfo().getRawSubtotal();
			estimatedTax=rawSubTotal*(getTaxPercent());
		}
		}
		request.setParameter("estimatedTax", estimatedTax);
		request.serviceLocalParameter(OUTPUT, request, response);
	}
	public OrderHolder getOrderHolder() {
		return orderHolder;
	}

	public void setOrderHolder(OrderHolder orderHolder) {
		this.orderHolder = orderHolder;
	}
	public Double getTaxPercent() {
		return taxPercent;
	}
	public void setTaxPercent(Double taxPercent) {
		this.taxPercent = taxPercent;
	}
}
