package com.agilent.commonstore.lms.droplets;

import static com.agilent.base.platform.Constants.EMPTY;
import static com.agilent.base.platform.Constants.OUTPUT;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import atg.commerce.order.CommerceItem;
import atg.nucleus.naming.ParameterName;
import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.LineItem;
import com.agilent.base.lms.services.AgilentLmsManager;

public class IsCreditProductIdentifierDroplet extends DynamoServlet {

	private static final String TRAINING_PRODUCT = "trainingProduct";
	private static final String CATALOGID = "catalogId";
	private static final String CREDITITEMONLY = "creditItemOnly";
	private AgilentLmsManager mAgilentLmsManager;
	


	ParameterName commerceItemParameter = ParameterName.getParameterName("commerceItem");
	ParameterName orderParamaeter = ParameterName.getParameterName("order");
	ParameterName creditItemOnlyParam = ParameterName.getParameterName("creditItemOnly");
	ParameterName redeempage = ParameterName.getParameterName("redeempage");
	ParameterName redeemItems = ParameterName.getParameterName("redeemItems");
	ParameterName redeemQuote = ParameterName.getParameterName("redeemQuote");
	private AgilentConfiguration mConfiguration;
	
	public void service( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
 		String catalogid="";
 		CommerceItem commerceItem=null;
 		Boolean creditItemOnlyFlag=false;
		 commerceItem=(CommerceItem)request.getObjectParameter(commerceItemParameter);
		AgilentOrder agilentOrder=(AgilentOrder)request.getObjectParameter(orderParamaeter);
		creditItemOnlyFlag= (Boolean.valueOf((String)request.getParameter(creditItemOnlyParam))) ;
	Boolean	redeemQuoteFlag	=(Boolean.valueOf((String)request.getParameter(redeemQuote))) ;
	List<LineItem> objectParameter = (List<LineItem>) request.getObjectParameter(redeemItems);
	List<LineItem> redeemItems= objectParameter;
	Boolean redeemOrderFlag = (Boolean.valueOf((String)request.getParameter(redeempage))) ; 
		vlogDebug("trainging product List: {0}", getConfiguration().getTrainingProdList());
		vlogDebug("creditItemOnlyParam flag : {0}", creditItemOnlyFlag);
		if(commerceItem!=null ){
			RepositoryItem catalogRef = (RepositoryItem)commerceItem.getAuxiliaryData().getCatalogRef();
			catalogid=(String) catalogRef.getPropertyValue(CATALOGID);
			request.setParameter(TRAINING_PRODUCT, getAgilentLmsManager().isCreditProduct(catalogid));
			request.serviceLocalParameter(OUTPUT, request, response);
		}else if(agilentOrder!=null && agilentOrder.getCommerceItems()!=null) {
				boolean isTrainingProd = getAgilentLmsManager().isOnlyLMSOrder(creditItemOnlyFlag,
						agilentOrder,redeemOrderFlag);
				request.setParameter(TRAINING_PRODUCT, isTrainingProd);
				request.serviceLocalParameter(OUTPUT, request, response);
		}else if(redeemQuoteFlag && redeemItems!=null){
			Boolean isTrainingProd =false;
			for(LineItem item: redeemItems ){
			 isTrainingProd = 	getAgilentLmsManager().isCreditProduct(item.getCatId());
			if(!isTrainingProd){
			break;
			}
			}
			request.setParameter(TRAINING_PRODUCT, isTrainingProd);
			request.serviceLocalParameter(OUTPUT, request, response);	
		}
		else{
			request.serviceLocalParameter(EMPTY, request, response);
		}
		
	}

	
	public AgilentLmsManager getAgilentLmsManager() {
		return mAgilentLmsManager;
	}

	public void setAgilentLmsManager(AgilentLmsManager pAgilentLmsManager) {
		mAgilentLmsManager = pAgilentLmsManager;
	}
	
	
	
	
	public AgilentConfiguration getConfiguration() {
		return mConfiguration;
	}

	public void setConfiguration(AgilentConfiguration mConfiguration) {
		this.mConfiguration = mConfiguration;
	}
	
	
}
