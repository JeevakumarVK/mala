package com.agilent.commonstore.lms.droplets;

import static com.agilent.base.platform.Constants.OUTPUT;

import java.beans.IntrospectionException;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import javax.transaction.NotSupportedException;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import com.agilent.base.commerce.order.AgilentHardGoodShippingGroup;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.SAPAddress;
import com.agilent.base.common.services.SAPUser;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.SessionBean;

import atg.commerce.CommerceException;
import atg.commerce.order.HardgoodShippingGroup;
import atg.commerce.order.OrderManager;
import atg.commerce.order.ShippingGroup;
import atg.core.util.Address;
import atg.core.util.ContactInfo;
import atg.nucleus.naming.ParameterName;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;
import atg.userprofiling.Profile;
import atg.userprofiling.address.AddressTools;

import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.common.services.SAPAddress;
import com.agilent.base.common.services.SAPUser;
import com.agilent.base.lms.services.AgilentLmsManager;
import com.agilent.base.profile.SessionBean;

public class ResetShippingAddressForLms extends DynamoServlet {

	public OrderManager getOrderManager() {
		return mOrderManager;
	}

	public void setOrderManager(OrderManager pOrderManager) {
		mOrderManager = pOrderManager;
	}

	private AgilentLmsManager mAgilentLmsManager;
	private AgilentConfiguration mConfiguration;
	private OrderManager mOrderManager;

	ParameterName orderParamaeter = ParameterName.getParameterName("order");

	public void service(DynamoHttpServletRequest request,
			DynamoHttpServletResponse response) throws ServletException,
			IOException {
		SessionBean sessionBean = (SessionBean) request
				.getObjectParameter(ParameterName
						.getParameterName("sessionBean"));
		SAPUser sapUser=new SAPUser();
		if(sessionBean!=null){
			sapUser= sessionBean.getSAPUser();
		}
		Profile profile = (Profile) request.getObjectParameter("profile");
		AgilentOrder agilentOrder = (AgilentOrder) request
				.getObjectParameter(orderParamaeter);

		if (agilentOrder != null && agilentOrder.getCommerceItems() != null) {
			boolean isTrainingProd = getAgilentLmsManager().isOnlyLMSOrder(
					true, agilentOrder,false);
			if (isTrainingProd) {
				
				if (profile != null && sessionBean != null && sessionBean.getSAPUser() != null
						) {
					List<SAPAddress> shippingAddresses = sapUser
					.getShippingAddresses();
					if (shippingAddresses != null
							&& shippingAddresses.size() > 0) {
						resetVerifiedShippingAddress(profile, agilentOrder,
								shippingAddresses);
					}

				}
			}

		}
	}

	private void resetVerifiedShippingAddress(Profile profile,
			AgilentOrder agilentOrder, List<SAPAddress> shippingAddresses) {
		SAPAddress sapAddress = shippingAddresses.get(0);
		AgilentHardGoodShippingGroup sg = (AgilentHardGoodShippingGroup) agilentOrder
				.getShippingGroups().get(0);
		AgilentPropertyManager propMgr = (AgilentPropertyManager) profile
				.getProfileTools().getPropertyManager();
		
		final Transaction transaction = getAgilentLmsManager().ensureTransaction();
		try {
			synchronized (agilentOrder) {
				ContactInfo orderAddress = (ContactInfo) sg
						.getShippingAddress();
				orderAddress.setFirstName((String) profile
						.getPropertyValue(propMgr.getFirstNamePropertyName()));
				orderAddress.setLastName((String) profile
						.getPropertyValue(propMgr.getLastNamePropertyName()));
				orderAddress.setEmail((String) profile.getPropertyValue(propMgr
						.getEmailAddressPropertyName()));
				orderAddress.setCompanyName(sapAddress.getCompanyName());
				orderAddress.setAddress1(sapAddress.getAddress1());
				orderAddress.setAddress2(sapAddress.getAddress2());
				orderAddress.setAddress3(sapAddress.getAddress3());
				orderAddress.setCountry(sapAddress.getCountry());
				orderAddress.setCity(sapAddress.getCity());
				orderAddress.setCounty(sapAddress.getCounty());
				orderAddress.setPostalCode(sapAddress.getPostalCode());
				orderAddress.setState(sapAddress.getState());
				sg.setShippingAddressId(sapAddress.getNumber());
				try {
					AddressTools.copyAddress(orderAddress,
							((HardgoodShippingGroup) sg).getShippingAddress());
				} catch (IntrospectionException e) {
					// TODO Auto-generated catch block
					vlogError("Error in Copy data");
				}
				((ContactInfo) (((HardgoodShippingGroup) sg))
						.getShippingAddress()).setPhoneNumber(orderAddress
						.getPhoneNumber());
				agilentOrder.setAllowPartialShipment(true);
				// agilentOrder.setShipToNumber(sapAddress.getNumber());
				getOrderManager().updateOrder(agilentOrder);

			}
		} catch (final Exception e) {
            this.vlogError(e, "Error");
        } finally {
                getAgilentLmsManager().commitTransaction(transaction);
        }
	}

	public AgilentConfiguration getConfiguration() {
		return mConfiguration;
	}

	public void setConfiguration(AgilentConfiguration pConfiguration) {
		mConfiguration = pConfiguration;
	}

	public AgilentLmsManager getAgilentLmsManager() {
		return mAgilentLmsManager;
	}

	public void setAgilentLmsManager(AgilentLmsManager pAgilentLmsManager) {
		mAgilentLmsManager = pAgilentLmsManager;
	}
}
