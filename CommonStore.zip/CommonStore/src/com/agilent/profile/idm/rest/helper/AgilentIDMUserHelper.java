package com.agilent.profile.idm.rest.helper;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.Constants;
import com.agilent.base.userprofiling.CountrySalesOrgProfilePropertySetter;
import com.agilent.profile.idm.rest.services.bean.IDMUserInputBean;
import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;

public class AgilentIDMUserHelper extends GenericService {

	private static final String DEFAULT_lOCALE_EN_US = "en_US";
	private static final String DEFAULT_SALES_ORG = "04US";
	private static final String DEFAULT_COUNTRY = "US";

	public static final String CUSTOMER_NAME1 = "customerName1";
	public static final String COMPANY_TAX_CODE1 = "companyTaxCode1";
	public static final String ADDRESS1 = "address1";
	public static final String BANK_NAME1 = "bankName1";
	public static final String BANK_ACCOUNT1 = "bankAccount1";
	public static final String CUSTOMER_NAME2 = "customerName2";
	public static final String CITY2 = "city2";
	public static final String SHIPPING_ADDRESS2 = "shippingAdrress2";
	public static final String POST_CODE2 = "postCode2";
	public static final String CONTACTOR_NAME2 = "contactorName2";
	public static final String CONTACTOR_PHNUM2 = "contactorPhNum2";
    
	public static final String B2BUSER = "b2bUser";
	public static final String DIRECTOR_ACCOUNT = "directorAccount";
	public static final String GROUP_ID = "groupId";
	public static final String SHOW_DUTY_FREE_PRICE = "showDutyFreePrice";
	public static final String ADD_FILE_UPLOADED = "isAddFileUploaded";
	public static final String PAYER_INVOICE_EMAIL = "payerInvoiceEmail";
	public static final String ADVANCE_SHIPDISABLE = "advShpDisable";


    
    
	
	private AgilentProfileTools profileTools = null;
	private CountrySalesOrgProfilePropertySetter countrySalesOrgProfilePropertySetter;
	
	public AgilentProfileTools getProfileTools() {
		return profileTools;
	}

	public void setProfileTools(AgilentProfileTools profileTools) {
		this.profileTools = profileTools;
	}


	public CountrySalesOrgProfilePropertySetter getCountrySalesOrgProfilePropertySetter() {
		return countrySalesOrgProfilePropertySetter;
	}

	public void setCountrySalesOrgProfilePropertySetter(
			CountrySalesOrgProfilePropertySetter countrySalesOrgProfilePropertySetter) {
		this.countrySalesOrgProfilePropertySetter = countrySalesOrgProfilePropertySetter;
	}

	public void createUserInRepo(MutableRepositoryItem userItem, IDMUserInputBean idmUserInputBean)
			throws IOException, RepositoryException {

		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();

		String encryptedNewPassword = getProfileTools().getPropertyManager().generatePassword(idmUserInputBean.getPassword(), "pa$$word");		
		userItem.setPropertyValue(propMgr.getLoginPropertyName(), idmUserInputBean.getEmail());
		userItem.setPropertyValue(propMgr.getPasswordPropertyName(), encryptedNewPassword);
		userItem.setPropertyValue(propMgr.getAdLoginNamePropertyName(), idmUserInputBean.getAdLoginName());
		userItem.setPropertyValue(propMgr.getFirstNamePropertyName(), idmUserInputBean.getFirstName());
		userItem.setPropertyValue(propMgr.getLastNamePropertyName(), idmUserInputBean.getLastName());
		userItem.setPropertyValue(propMgr.getEmailAddressPropertyName(), idmUserInputBean.getEmail());
		userItem.setPropertyValue(propMgr.getSapContactNumberPropertyName(), idmUserInputBean.getSapCustomerId());
		userItem.setPropertyValue(propMgr.getTitle(), idmUserInputBean.getTitle());
		userItem.setPropertyValue(propMgr.getDepartment(), idmUserInputBean.getDepartment());
		userItem.setPropertyValue(propMgr.getRegion(), idmUserInputBean.getRegion());

		if (StringUtils.isEmpty(idmUserInputBean.getBillCountry())) {
			userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), DEFAULT_COUNTRY);
		} else {
			userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());
		}

		if (!StringUtils.isEmpty(idmUserInputBean.getEcommerceStatus())) {
			userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(),
					idmUserInputBean.getEcommerceStatus().equals(Constants.VALUE_SAP) ? Constants.VALUE_SAP: Constants.VALUE_WEB);
		} else {
			userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
		}

		if (!StringUtils.isEmpty(idmUserInputBean.getMemberType())) {
			userItem.setPropertyValue(propMgr.getMemberTypePropertyName(),
					idmUserInputBean.getMemberType().equals(Constants.VALUE_DISTRIBUTOR) ? Constants.VALUE_DISTRIBUTOR : Constants.VALUE_MEMBER);
		} else {
			userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
		}

		userItem.setPropertyValue(propMgr.getDefaultShippingMethodPropertyName(), Constants.STANDARDSHIPPING);
		userItem.setPropertyValue(propMgr.getDefaultPaymentMethodPropertyName(), Constants.PAY_METHOD_PO);		
		userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
		userItem.setPropertyValue(propMgr.getLocalePropertyName(), DEFAULT_lOCALE_EN_US);
		//userItem.setPropertyValue(propMgr.getReceiveEmailPropertyName(),idmUserInputBean.getReceiveEmail() == 1 ? "yes" : "no");
		userItem.setPropertyValue(propMgr.getPlaceOnlineOrdersPropertyName(),idmUserInputBean.getEnableCommerce() == 0 ? false : true);
		//userItem.setPropertyValue(propMgr.getNewsOptInPropertyName(),idmUserInputBean.getNewsOptIn() == 1 ? true : false);
		userItem.setPropertyValue(propMgr.getTestAccountPropertyName(),idmUserInputBean.getTestAccount() == 1 ? true : false);
		userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(),idmUserInputBean.getDropShipment() == 0 ? false : true);
		userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(),idmUserInputBean.getIncludePunchoutShipping() == 1 ? true : false);
		userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(),idmUserInputBean.getIncludePunchoutTaxes() == 1 ? true : false);
		userItem.setPropertyValue(ADVANCE_SHIPDISABLE, idmUserInputBean.getAdvanceShippingDisabled() == 1 ? true : false);
		//userItem.setPropertyValue(propMgr.getAccessLibrayOptInPropertyName(),idmUserInputBean.getAccesLibraryOptIn() == 1 ? true : false);
		userItem.setPropertyValue(propMgr.getPartnerNamePropertyName(), idmUserInputBean.getPartnerName());
		userItem.setPropertyValue(propMgr.getPartnerIdentifierrPropertyName(), idmUserInputBean.getPartnerIdentifier());
		userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), idmUserInputBean.getPunchoutMember());
		userItem.setPropertyValue(propMgr.getShippAddTypeProppertyName(), idmUserInputBean.getDefaultShipAddressType());
		userItem.setPropertyValue(propMgr.getDefaultSAPBillToAddressPropertyName(),idmUserInputBean.getSapBillToAddress());
		userItem.setPropertyValue(propMgr.getDefaultSAPShipToAddressPropertyName(),idmUserInputBean.getSapShipToAddress());
		userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), idmUserInputBean.getPunchoutMember());
		userItem.setPropertyValue(propMgr.getTaxExemptedNumPropertyName(), idmUserInputBean.getTaxExemptNumber());
		userItem.setPropertyValue(propMgr.getTaxExemptCertPropertyName(),idmUserInputBean.getTaxExemptCertificatePath());
		userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(),idmUserInputBean.getTaxExempt() == 1 ? true : false);
		userItem.setPropertyValue(B2BUSER,idmUserInputBean.getB2bUser() == 1 ? true : false);
		userItem.setPropertyValue(GROUP_ID,idmUserInputBean.getB2bGroupId());
		
		if (!StringUtils.isEmpty(idmUserInputBean.getFedexCollectNumber())) {
			userItem.setPropertyValue(propMgr.getFedexUpsCollectNumber(), idmUserInputBean.getFedexCollectNumber());
		}

		if (!StringUtils.isEmpty(idmUserInputBean.getUpsCollectNumber())) {
			userItem.setPropertyValue(propMgr.getUPSCollectNumber(), idmUserInputBean.getUpsCollectNumber());
		}

		//userItem.setPropertyValue(propMgr.getPreferredLanguagesPropertyName(),getDefaultPreferenLanguage(idmUserInputBean.getPreferredLanguages()));
		userItem.setPropertyValue(Constants.PROP_BILLING_ADDRESS, createBillContatcInfo(idmUserInputBean));
		userItem.setPropertyValue(Constants.PROP_SHIPPING_ADDRESS, createShipContatcInfo(idmUserInputBean));
		createSecondaryAddress(userItem);

		String salesOrg = DEFAULT_SALES_ORG;
		if (this.getCountrySalesOrgProfilePropertySetter() != null && idmUserInputBean.getBillCountry() != null) {
			salesOrg = this.getCountrySalesOrgProfilePropertySetter().getSalesOrg(idmUserInputBean.getBillCountry());
			if (salesOrg == null) {
				salesOrg = DEFAULT_SALES_ORG;
				vlogDebug("Cannot retrieve SAP Sales Org for country :" + idmUserInputBean.getBillCountry());
			}

			userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
			userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());

		}

		//Invoice details insert
		
		userItem.setPropertyValue(CUSTOMER_NAME1, idmUserInputBean.getInvoice().getInvoiceCustomerName());
		userItem.setPropertyValue(COMPANY_TAX_CODE1, idmUserInputBean.getInvoice().getInvoiceCompanyTaxCode());
		userItem.setPropertyValue(ADDRESS1, idmUserInputBean.getInvoice().getInvoiceAddress());
		userItem.setPropertyValue(BANK_NAME1, idmUserInputBean.getInvoice().getInvoiceBankName());
		userItem.setPropertyValue(BANK_ACCOUNT1, idmUserInputBean.getInvoice().getInvoiceBankAccount());
		userItem.setPropertyValue(CUSTOMER_NAME2, idmUserInputBean.getInvoice().getInvoiceShipCustomerName());
		userItem.setPropertyValue(CITY2, idmUserInputBean.getInvoice().getInvoiceShipCity());
		userItem.setPropertyValue(SHIPPING_ADDRESS2, idmUserInputBean.getInvoice().getInvoiceShipShippingAddress());
		userItem.setPropertyValue(POST_CODE2, idmUserInputBean.getInvoice().getInvoiceShipPostCode());
		userItem.setPropertyValue(CONTACTOR_NAME2, idmUserInputBean.getInvoice().getInvoiceShipContactPerson());
		userItem.setPropertyValue(CONTACTOR_PHNUM2, idmUserInputBean.getInvoice().getInvoiceShipContactPhoneNumber());
		

		getProfileTools().getProfileRepository().addItem(userItem);

	}

	public void updateUserInRepo(MutableRepositoryItem userItem, IDMUserInputBean idmUserInputBean) throws RepositoryException {

		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();

		checkAndSetProperty(userItem,propMgr.getFirstNamePropertyName(),idmUserInputBean.getFirstName());			
		checkAndSetProperty(userItem,propMgr.getLastNamePropertyName(),idmUserInputBean.getLastName());			
		checkAndSetProperty(userItem,propMgr.getSapContactNumberPropertyName(),idmUserInputBean.getSapCustomerId());	
		checkAndSetProperty(userItem,propMgr.getTitle(),idmUserInputBean.getTitle());  
		checkAndSetProperty(userItem,propMgr.getDepartment(),idmUserInputBean.getDepartment());  
	//	checkAndSetProperty(userItem,propMgr.getRegion(),idmUserInputBean.getRegion()); 
		
		if (!StringUtils.isEmpty(idmUserInputBean.getEcommerceStatus())) {
			if (Constants.VALUE_WEB.equals(idmUserInputBean.getEcommerceStatus())) {
				userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
			} else if (Constants.VALUE_SAP.equals(idmUserInputBean.getEcommerceStatus())) {
				userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_SAP);
			}
		}

		if (!StringUtils.isEmpty(idmUserInputBean.getMemberType())
				&& idmUserInputBean.getMemberType().equals(Constants.VALUE_DISTRIBUTOR)) {
			userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_DISTRIBUTOR);
		}

		if (!StringUtils.isEmpty(idmUserInputBean.getMemberType())
				&& idmUserInputBean.getMemberType().equals(Constants.VALUE_MEMBER)) {
			userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
		}
					
		if (!StringUtils.isEmpty(idmUserInputBean.getSapSalesOrg())) {
			userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(),idmUserInputBean.getSapSalesOrg().toUpperCase());
		}
		

		//userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
		//checkAndSetBoolean(userItem, propMgr.getAutoLoginPropertyName(), idmUserInputBean.getAutoLogin());

//		if (idmUserInputBean.getReceiveEmail() == 1 || idmUserInputBean.getReceiveEmail() == 0) {
//			userItem.setPropertyValue(propMgr.getReceiveEmailPropertyName(),idmUserInputBean.getReceiveEmail() == 1 ? "yes" : "no");
//		}
		checkAndSetBoolean(userItem, propMgr.getPlaceOnlineOrdersPropertyName(), idmUserInputBean.getEnableCommerce());
		//checkAndSetBoolean(userItem, propMgr.getNewsOptInPropertyName(), idmUserInputBean.getNewsOptIn());
		checkAndSetBoolean(userItem, propMgr.getTestAccountPropertyName(), idmUserInputBean.getTestAccount());		
		checkAndSetBoolean(userItem, propMgr.getDropShipmentPropertyName(), idmUserInputBean.getDropShipment());
		checkAndSetBoolean(userItem, propMgr.getIncludePunchoutShippingPropertyName(),idmUserInputBean.getIncludePunchoutShipping());
		checkAndSetBoolean(userItem, propMgr.getIncludePunchoutShippingPropertyName(),idmUserInputBean.getIncludePunchoutShipping());
		checkAndSetBoolean(userItem, propMgr.getIncludePunchoutTaxesPropertyName(),idmUserInputBean.getIncludePunchoutTaxes());
		checkAndSetBoolean(userItem, ADVANCE_SHIPDISABLE, idmUserInputBean.getAdvanceShippingDisabled());
		//checkAndSetBoolean(userItem, propMgr.getAccessLibrayOptInPropertyName(),idmUserInputBean.getAccesLibraryOptIn());		
		checkAndSetProperty(userItem,propMgr.getPartnerNamePropertyName(),idmUserInputBean.getPartnerName());		
		checkAndSetProperty(userItem,propMgr.getPartnerIdentifierrPropertyName(),idmUserInputBean.getPartnerIdentifier());				
		checkAndSetProperty(userItem,propMgr.getShippAddTypeProppertyName(),idmUserInputBean.getDefaultShipAddressType());		
		checkAndSetProperty(userItem,propMgr.getDefaultSAPBillToAddressPropertyName(),idmUserInputBean.getSapBillToAddress());		
		checkAndSetProperty(userItem,propMgr.getDefaultSAPShipToAddressPropertyName(),idmUserInputBean.getSapShipToAddress());			
		checkAndSetProperty(userItem,propMgr.getPunchoutMemberPropertyName(),idmUserInputBean.getPunchoutMember());			
		checkAndSetProperty(userItem,propMgr.getTaxExemptedNumPropertyName(),idmUserInputBean.getTaxExemptNumber());
		checkAndSetProperty(userItem,propMgr.getTaxExemptCertPropertyName(),idmUserInputBean.getTaxExemptCertificatePath());
		
		checkAndSetBoolean(userItem, propMgr.getTaxExemptedPropertyName(), idmUserInputBean.getTaxExempt());
		checkAndSetProperty(userItem,propMgr.getFedexUpsCollectNumber(),idmUserInputBean.getFedexCollectNumber());	
		checkAndSetProperty(userItem,propMgr.getUPSCollectNumber(),idmUserInputBean.getUpsCollectNumber());				

		checkAndSetBoolean(userItem, propMgr.getSapMasterAccountPropertyName(), idmUserInputBean.getSapMasterAccount());
		checkAndSetBoolean(userItem, SHOW_DUTY_FREE_PRICE, idmUserInputBean.getShowDutyFreePrice());
		checkAndSetBoolean(userItem, ADD_FILE_UPLOADED, idmUserInputBean.getAddFileUploaded());
		
		checkAndSetProperty(userItem,PAYER_INVOICE_EMAIL, idmUserInputBean.getPayerInvoiceEmail());

		createBillContatcInfoForUpdate(idmUserInputBean, userItem);
		createShipContatcInfoForUpdate(idmUserInputBean, userItem);
		
		
		checkAndSetProperty(userItem,CUSTOMER_NAME1,idmUserInputBean.getInvoice().getInvoiceCustomerName());				
		checkAndSetProperty(userItem,COMPANY_TAX_CODE1, idmUserInputBean.getInvoice().getInvoiceCompanyTaxCode());
		checkAndSetProperty(userItem,ADDRESS1, idmUserInputBean.getInvoice().getInvoiceAddress());
		checkAndSetProperty(userItem,BANK_NAME1, idmUserInputBean.getInvoice().getInvoiceBankName());
		checkAndSetProperty(userItem,BANK_ACCOUNT1, idmUserInputBean.getInvoice().getInvoiceBankAccount());
		checkAndSetProperty(userItem,CUSTOMER_NAME2, idmUserInputBean.getInvoice().getInvoiceShipCustomerName());
		checkAndSetProperty(userItem,CITY2, idmUserInputBean.getInvoice().getInvoiceShipCity());
		checkAndSetProperty(userItem,SHIPPING_ADDRESS2, idmUserInputBean.getInvoice().getInvoiceShipShippingAddress());
		checkAndSetProperty(userItem,POST_CODE2, idmUserInputBean.getInvoice().getInvoiceShipPostCode());
		checkAndSetProperty(userItem,CONTACTOR_NAME2, idmUserInputBean.getInvoice().getInvoiceShipContactPerson());
		checkAndSetProperty(userItem,CONTACTOR_PHNUM2, idmUserInputBean.getInvoice().getInvoiceShipContactPhoneNumber());
		
		checkAndSetBoolean(userItem, B2BUSER, idmUserInputBean.getB2bUser());
		checkAndSetBoolean(userItem, DIRECTOR_ACCOUNT, idmUserInputBean.getSapDirectorAccount());
		checkAndSetProperty(userItem,GROUP_ID, idmUserInputBean.getB2bGroupId());

		checkAndSetProperty(userItem,propMgr.getFedexUpsCollectNumber(), idmUserInputBean.getFedexCollectNumber());
		
		if (idmUserInputBean.getUserRole().getRole() != null) {
			Set<RepositoryItem> roleSet = manageUserRoles(idmUserInputBean, userItem);

			if (roleSet != null && roleSet.size() > 0) {
				userItem.setPropertyValue("roles", roleSet);
			}

		}
		
				
		getProfileTools().getProfileRepository().updateItem(userItem);

	}


	public RepositoryItem createBillContatcInfo(IDMUserInputBean bean) throws RepositoryException {
		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
		item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getFirstName());
		item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getLastName());
		item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getCompanyName());
		item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getBillAddress1());
		item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getBillAddress2());
		item.setPropertyValue(propMgr.getCityPropertyName(), bean.getBillCity());
		item.setPropertyValue(propMgr.getStatePropertyName(), bean.getBillState());
		item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getBillPostalCode());
		item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getBillCountry());
		item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getPhoneNumber());
		item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getExtension());

		return item;
	}

	public RepositoryItem createBillContatcInfoForUpdate(IDMUserInputBean idmUserInputBean,
			MutableRepositoryItem userItem) throws RepositoryException {
		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		MutableRepositoryItem item = (MutableRepositoryItem) userItem.getPropertyValue(Constants.PROP_BILLING_ADDRESS);

		checkAndSetProperty(item,propMgr.getFirstNamePropertyName(), idmUserInputBean.getFirstName());
		checkAndSetProperty(item,propMgr.getLastNamePropertyName(), idmUserInputBean.getLastName());				
		checkAndSetProperty(item,propMgr.getCompanyPropertyName(), idmUserInputBean.getCompanyName());
		checkAndSetProperty(item,propMgr.getAddress1PropertyName(), idmUserInputBean.getBillAddress1());
		checkAndSetProperty(item,propMgr.getAddress2PropertyName(), idmUserInputBean.getBillAddress2());
		checkAndSetProperty(item,propMgr.getCityPropertyName(), idmUserInputBean.getBillCity());
		checkAndSetProperty(item,propMgr.getStatePropertyName(), idmUserInputBean.getBillState());
		checkAndSetProperty(item,propMgr.getPostalCodePropertyName(), idmUserInputBean.getBillPostalCode());
		checkAndSetProperty(item,propMgr.getCountryPropertyName(), idmUserInputBean.getBillCountry());
		checkAndSetProperty(item,propMgr.getPhoneNumberPropertyName(), idmUserInputBean.getPhoneNumber());
		checkAndSetProperty(item,propMgr.getExtensionPropertyName(), idmUserInputBean.getExtension());
		
		return item;
	}

	public RepositoryItem createShipContatcInfo(IDMUserInputBean bean) throws RepositoryException {
		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
		item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getFirstName());
		item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getLastName());
		item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getCompanyName());
		item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getShipAddress1());
		item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getShipAddress2());
		item.setPropertyValue(propMgr.getCityPropertyName(), bean.getShipCity());
		item.setPropertyValue(propMgr.getStatePropertyName(), bean.getShipState());
		item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getShipPostalCode());
		item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getShipCountry());
		item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getPhoneNumber());
		item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getExtension());

		return item;
	}

	public RepositoryItem createShipContatcInfoForUpdate(IDMUserInputBean idmUserInputBean,
			MutableRepositoryItem userItem) throws RepositoryException {
		AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		MutableRepositoryItem item = (MutableRepositoryItem) userItem.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
		
		checkAndSetProperty(item,propMgr.getFirstNamePropertyName(), idmUserInputBean.getFirstName());
		checkAndSetProperty(item,propMgr.getLastNamePropertyName(), idmUserInputBean.getLastName());				
		checkAndSetProperty(item,propMgr.getCompanyPropertyName(), idmUserInputBean.getCompanyName());
		checkAndSetProperty(item,propMgr.getAddress1PropertyName(), idmUserInputBean.getShipAddress1());
		checkAndSetProperty(item,propMgr.getAddress2PropertyName(), idmUserInputBean.getShipAddress2());
		checkAndSetProperty(item,propMgr.getCityPropertyName(), idmUserInputBean.getShipCity());
		checkAndSetProperty(item,propMgr.getStatePropertyName(), idmUserInputBean.getShipState());
		checkAndSetProperty(item,propMgr.getPostalCodePropertyName(), idmUserInputBean.getShipPostalCode());
		checkAndSetProperty(item,propMgr.getCountryPropertyName(), idmUserInputBean.getShipCountry());
		checkAndSetProperty(item,propMgr.getPhoneNumberPropertyName(), idmUserInputBean.getPhoneNumber());
		checkAndSetProperty(item,propMgr.getExtensionPropertyName(), idmUserInputBean.getExtension());
		
		return item;
	}

	public Set<RepositoryItem> getDefaultPreferenLanguage(String languageId) {
		RepositoryItem item = null;
		Set<RepositoryItem> languageSet = new HashSet<RepositoryItem>();
		try {
			if (!StringUtils.isBlank(languageId)) {
				item = getProfileTools().getProfileRepository().getItem(languageId, "SharePointLanguages");
			}
			if (item == null) {
				item = getProfileTools().getProfileRepository().getItem("en-US", "SharePointLanguages");
			}
		} catch (RepositoryException e) {
			vlogError("Error occured while getting the getDefaultPreferenLanguage", e.getMessage());
		}
		languageSet.add(item);
		return languageSet;
	}
	
	
	private Set<RepositoryItem> manageUserRoles(IDMUserInputBean idmUserInputBean,MutableRepositoryItem userItem) throws RepositoryException {
		
		RepositoryItem roleItem=null;
		IDMUserInputBean.UserRoles rolesBean=idmUserInputBean.getUserRole();
		Set<RepositoryItem> roleSet = null;
		
		vlogInfo("Input for Roles Action={0} and Role={1}", rolesBean.getActionCode(),rolesBean.getRole());
		
		if (rolesBean.getRole() != null) {
			roleItem = getProfileTools().getProfileRepository().getItem(rolesBean.getRole(), "role");			
		} 
		
		if (roleItem == null) {
			vlogInfo("User Provided Role is not available in Our Role List ={0}", rolesBean.getRole());
			return roleSet;
		}
		
		roleSet =(Set<RepositoryItem>) userItem.getPropertyValue("roles");
		vlogInfo("Available roles for user before update={0}", roleSet);

		if (rolesBean.getActionCode() == IDMUserInputBean.ActionCode.ADD) {
			vlogInfo("Add new Role to the User={0}", roleItem);
			if (roleSet != null && roleSet.size() > 0) {
				roleSet.add(roleItem);
			} else {
				roleSet = new HashSet<RepositoryItem>();
				roleSet.add(roleItem);
			}
		}
		
		if (rolesBean.getActionCode() == IDMUserInputBean.ActionCode.REMOVE) {			
			if (roleSet != null && roleSet.size() > 0) {
				vlogInfo("Remove Role From the user User={0}", roleItem);
				roleSet.remove(roleItem);
			}
		}
		 				
		vlogInfo("Available roles for user After update={0} \n", roleSet);			

		return roleSet;
		
	}

	private void createSecondaryAddress(MutableRepositoryItem userItem) {
		AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
		Map secondaryAddresses = (Map) userItem.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
		RepositoryItem shippingAddress = (RepositoryItem) userItem.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
		// To make sure nickname will be unique always
		long number = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;
		String nickname = String.valueOf(number);
		Map<String, RepositoryItem> secondaryAdd = (Map<String, RepositoryItem>) userItem
				.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
		Set<String> key = secondaryAdd.keySet();
		Random rdn = new Random();
		while (key.contains(nickname)) {
			nickname = nickname + rdn.nextInt(100);
		}
		secondaryAddresses.put(nickname, shippingAddress);
	}

	private void checkAndSetBoolean(MutableRepositoryItem userItem, String propertyName, int inputValue) {
		if (inputValue == 1) {
			userItem.setPropertyValue(propertyName, true);
		}
		if (inputValue == 0) {
			userItem.setPropertyValue(propertyName, false);
		}
	}
	
	private void checkAndSetProperty(MutableRepositoryItem userItem, String propertyName, String inputValue) {
		if (!StringUtils.isEmpty(inputValue)) {
			userItem.setPropertyValue(propertyName, inputValue);
		}
	}

}
