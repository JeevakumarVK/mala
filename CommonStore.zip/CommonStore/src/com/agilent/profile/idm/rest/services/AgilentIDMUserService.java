/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.profile.idm.rest.services;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.Set;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;


import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.platform.IErrorId;
import com.agilent.base.platform.SystemException;
import com.agilent.base.platform.ValidationExceptions;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.platform.util.ValidatorUtil;
import com.agilent.base.platform.validator.IValidator;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.Constants;
import com.agilent.base.util.AgilentUtil;
import com.agilent.profile.idm.functions.IdmServiceConstants;
import com.agilent.profile.idm.rest.helper.AgilentIDMUserHelper;
import com.agilent.profile.idm.rest.services.bean.IDMUserInputBean;
import com.agilent.profile.idm.rest.services.bean.IDMUserOutputBean;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.repository.MutableRepository;
import atg.repository.MutableRepositoryItem;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.RepositoryUtils;
import atg.repository.RepositoryImpl;
import atg.servlet.ServletUtil;

/**
 * This is IDM service class used to perform create, update operation related to profile.
 */
@SuppressWarnings({"rawtypes", "cast"})
public class AgilentIDMUserService extends GenericService implements IdmServiceConstants {

    private static final String DEFAULT_LANGUAGE = "en";
    private static final String DEFAULT_COUNTRY = "US";
    private static final String BILLING_ZIPNDPOSTAL = "billing.zipndpostal";
    private static final String SHIPPING_ZIPNDPOSTAL = "shipping.zipndpostal";

    private AgilentProfileTools profileTools = null;
    private IValidator validator;
    private ErrorHandlerImpl errorHandler;
    private CountryUtils countryUtils;
    private AgilentIDMUserHelper agilentIDMUserHelper;
    private String migratedRedirectURL;
    private AgilentConfiguration agilentConfiguration;
    private Repository mProfileAdapterRepository;
    public AgilentConfiguration getAgilentConfiguration() {
        return agilentConfiguration;
    }

    public void setAgilentConfiguration(AgilentConfiguration agilentConfiguration) {
        this.agilentConfiguration = agilentConfiguration;
    }

    public String getMigratedRedirectURL() {
        return migratedRedirectURL;
    }

    public void setMigratedRedirectURL(String migratedRedirectURL) {
        this.migratedRedirectURL = migratedRedirectURL;
    }

    public AgilentIDMUserHelper getAgilentIDMUserHelper() {
        return agilentIDMUserHelper;
    }

    public void setAgilentIDMUserHelper(AgilentIDMUserHelper agilentIDMUserHelper) {
        this.agilentIDMUserHelper = agilentIDMUserHelper;
    }

    public AgilentProfileTools getProfileTools() {
        return profileTools;
    }

    public void setProfileTools(AgilentProfileTools profileTools) {
        this.profileTools = profileTools;
    }

    public IValidator getValidator() {
        return validator;
    }

    public void setValidator(IValidator validator) {
        this.validator = validator;
    }

    public ErrorHandlerImpl getErrorHandler() {
        return errorHandler;
    }

    public void setErrorHandler(ErrorHandlerImpl errorHandler) {
        this.errorHandler = errorHandler;
    }

    public CountryUtils getCountryUtils() {
        return countryUtils;
    }

    public void setCountryUtils(CountryUtils countryUtils) {
        this.countryUtils = countryUtils;
    }

    /**
     * Gets the value of property profileAdapterRepository
     *
     * @return the value of property profileAdapterRepository
     */
    public Repository getProfileAdapterRepository() {
        return mProfileAdapterRepository;
    }
    /**
     * Sets the value of property profileAdapterRepository with value pProfileAdapterRepository
     *
     * @param pProfileAdapterRepository
     *            for setting property profileAdapterRepository
     */
    public void setProfileAdapterRepository(Repository pProfileAdapterRepository) {
        mProfileAdapterRepository = pProfileAdapterRepository;
    }

	public IDMUserOutputBean addUser() {
        IDMUserOutputBean idmUserResponse = null;
        String idmUserRequestString = ServletUtil.getCurrentRequest().getParameter("idmUserRequest");

        if (StringUtils.isBlank(idmUserRequestString)) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_REQUEST_EMPTY");
        }

        vlogDebug("Obtained Request json for new User Creation==={0}", idmUserRequestString);

        Gson gson = new Gson();
        IDMUserInputBean idmUserInputBean = gson.fromJson(idmUserRequestString, IDMUserInputBean.class);
        vlogDebug("Json to Object Conversion Output==={0}", idmUserInputBean);

        if (idmUserInputBean == null) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_JSON_REQUEST_PARSE_ERROR");
        }

        if (!validPrimitiveType(idmUserRequestString, gson)) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_JSON_REQUEST_HAS_INVALID_NUMERIC_VALUE");
        }

        MutableRepositoryItem userItem = null;
        try {
            if (StringUtils.isBlank(idmUserInputBean.getLogin())) {
                idmUserInputBean.setLogin(idmUserInputBean.getEmail());
            }

            List<String> errorMessages = inputValidationForCreate(idmUserInputBean);
            if (!errorMessages.isEmpty()) {
                return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_REQUEST_DATA_VALIDATION_ERROR", errorMessages);
            }

            if (!StringUtils.isBlank(idmUserInputBean.getAdLoginName())) {
                RepositoryItem userItem_login = getProfileTools().getItemFromDotNetId(idmUserInputBean.getAdLoginName());
                if (userItem_login != null) {
                    vlogInfo("login is already available in database= AdloginName={0}", idmUserInputBean.getAdLoginName());
                    return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "LOGIN_NAME_ALREADY_EXISTS");
                }
            }

            if (!StringUtils.isBlank(idmUserInputBean.getEmail())) {
                RepositoryItem userItem_email = getProfileTools().getItemFromEmail(idmUserInputBean.getEmail());
                if (userItem_email != null) {
                    vlogInfo("login is already available in database email={0}", idmUserInputBean.getEmail());
                    return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "EMAIL_ALREADY_EXISTS");
                }
            }

            userItem = getProfileTools().getProfileRepository().createItem(getProfileTools().getDefaultProfileType());
            getAgilentIDMUserHelper().createUserInRepo(userItem, idmUserInputBean);

            idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.SUCCESS, "USER_CREATED_SUCCESS");
            idmUserResponse.setAtgUserId(userItem.getRepositoryId());

        } catch (Exception e) {
            idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_CREATE");
            vlogError(e, "EXPECTION_OCCURED_DURING_USER_CREATE");
        }

        gson = null;
        userItem = null;
        idmUserInputBean = null;

        return idmUserResponse;
    }

    public IDMUserOutputBean updateUser() {

        IDMUserOutputBean idmUserResponse = null;
        String idmUserRequestString = ServletUtil.getCurrentRequest().getParameter("idmUserRequest");

        if (StringUtils.isBlank(idmUserRequestString)) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_REQUEST_EMPTY");
        }

        vlogDebug("Obtained Request json for Update User Creation==={0}", idmUserRequestString);

        Gson gson = new Gson();
        IDMUserInputBean idmUserInputBean = gson.fromJson(idmUserRequestString, IDMUserInputBean.class);

        if (!validPrimitiveType(idmUserRequestString, gson)) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_JSON_REQUEST_HAS_INVALID_NUMERIC_VALUE");
        }

        vlogDebug("Json to Object Conversion Output==={0}", idmUserInputBean);

        if (idmUserInputBean == null) {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_JSON_REQUEST_PARSE_ERROR");
        }

        MutableRepositoryItem userItem = null;

        try {

            if (!StringUtils.isBlank(idmUserInputBean.getId())) {
                userItem = getProfileTools().getProfileRepository().getItemForUpdate(idmUserInputBean.getId(), "user");
                if (userItem == null) {
                    vlogInfo("Provided User Id is not available in Sytem Id=={0}", idmUserInputBean.getId());
                    return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "PROVIDED_USER_ID_NOT_AVAILBLE");
                }
            } else {
                vlogInfo("Please provide User Id =={0}", idmUserInputBean.getId());
                return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "USER_ID_REQUIRED");
            }

            List<String> errorMessages = inputValidationForUpdate(idmUserInputBean);
            if (!errorMessages.isEmpty()) {
                return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_REQUEST_DATA_VALIDATION_ERROR", errorMessages);
            }

            getAgilentIDMUserHelper().updateUserInRepo(userItem, idmUserInputBean);

            idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.SUCCESS, "USER_UPDATED_SUCCESS");
            idmUserResponse.setAtgUserId(userItem.getRepositoryId());
            // APP-23113 START
            RepositoryImpl rep = (RepositoryImpl) getProfileAdapterRepository();
            vlogDebug("invalidating ProfileAdapterRepository cache");
            rep.invalidateCaches();
            // APP-23113 END
        } catch (Exception e) {
            idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_UPDATE");
            vlogError(e, "EXPECTION_OCCURED_DURING_USER_UPDATE");
        }

        gson = null;
        userItem = null;
        idmUserInputBean = null;

        return idmUserResponse;

    }

    // Single Param - Change - Start
    /**
     * Method to validate the email id
     * 
     * @param email
     * @return
     */
    public static boolean isValidEmailAddress(String email) {
        boolean result = true;
        try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
        } catch (AddressException ex) {
            result = false;
        }
        return result;
    }
    // Single Param - Change - End

    /**
     * This method will be used to retrieve user migration details of a particular user based on his email or login name
     * 
     * @return IDMUserOutputBean
     */
    public IDMUserOutputBean retrieveUserMigrationDetails() {

        IDMUserOutputBean idmUserResponse = null;
        // Single Param - Change - Start
        ServletUtil.getCurrentRequest().getResponse().addHeader("Access-Control-Allow-Origin", "*");
        String login = ServletUtil.getCurrentRequest().getParameter(LOGIN);
        if (!StringUtils.isBlank(login)) {
            vlogDebug("Required inputs are present login{0}", login);
        } else {
            return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "IDM_INPUT_REQUEST_EMPTY");
        }
        boolean isValidEmailAddress = isValidEmailAddress(login);
        // Single Param - Change - End
        RepositoryItem userItem = null;

        try {
            AgilentProfileTools lAgilentProfileTools = (AgilentProfileTools) getProfileTools();
            // Single Param - Change - Start
            if (isValidEmailAddress) {
                userItem = lAgilentProfileTools.getItemFromEmail(login);
            } else {
                userItem = lAgilentProfileTools.getItemFromDotNetId(login);
            }
            // Single Param - Change - End
            if (userItem == null) {
                vlogInfo("User not available in System for given login {0}", login);
                return new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "USER_NOT_AVAILBLE");
            } else {

                idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.SUCCESS, "USER_MIGRATION_RETRIEVAL_SUCCESS");
                idmUserResponse.setAtgUserId(userItem.getRepositoryId());

                idmUserResponse.setMigratedUserEmail((String) userItem.getPropertyValue(USER_EMAIL_ID));

                if ((Boolean) userItem.getPropertyValue(Constants.MIGRATED_USER)) {
                    idmUserResponse.setMigratedStatus(1);
                    idmUserResponse.setMigratedSource((String) userItem.getPropertyValue(Constants.MIGRATED_SOURCE_NAME));
                    if (userItem.getPropertyValue(Constants.MIGRATED_SOURCE_NAME) == null) {
                        idmUserResponse.setMigratedredirectURL("");
                    } else if (LYNX.equalsIgnoreCase((String) userItem.getPropertyValue(Constants.MIGRATED_SOURCE_NAME))) {
                        idmUserResponse.setMigratedredirectURL(getAgilentConfiguration().getCommonStoreURL() + getMigratedRedirectURL());
                    } else {
                        idmUserResponse.setMigratedredirectURL(getAgilentConfiguration().getCommonStoreURL() + getMigratedRedirectURL());
                    }
                } else {
                    idmUserResponse.setMigratedStatus(0);
                    idmUserResponse.setMigratedSource("");
                    idmUserResponse.setMigratedredirectURL("");
                }
            }
            vlogDebug(idmUserResponse.toString());

        } catch (Exception e) {
            idmUserResponse = new IDMUserOutputBean(IDMUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_MIGRATION_RETRIEVAL");
            vlogError(e, "EXPECTION_OCCURED_DURING_USER_UPDATE");
        }

        return idmUserResponse;
    }

    public List<String> inputValidationForCreate(IDMUserInputBean idmUserInputBean) throws RepositoryException {

        List<String> errorMessages = new ArrayList<String>();
        Locale locale = new Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
        ResourceBundle resourceBundle = ResourceBundle.getBundle(getErrorHandler().getBundleMap().get("profile"), locale);

        try {
            getValidator().validate("registerServiceValidation", idmUserInputBean);
        } catch (SystemException e) {
            vlogError(e, "EXPECTION_OCCURED_DURING_inputValidationForCreate");
        } catch (ValidationExceptions eValidationErros) {
            List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
            for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                try {
                    errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                            validationError.getMessageContext()));
                } catch (Exception ev) {
                    vlogError(ev, "EXPECTION_OCCURED_inputValidationForCreate");
                }
            }
        }

        if (StringUtils.isEmpty(idmUserInputBean.getBillPostalCode())) {
            errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(BILLING_ZIPNDPOSTAL)));
        } else {
            ValidationExceptions validationException_bill = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase();
            }
            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getBillPostalCode(), BILLING_ZIPNDPOSTAL, validationException_bill);
            for (com.agilent.base.platform.ValidationError validationErrorBill : validationException_bill.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorBill.getErrId(), "profile", validationErrorBill.getKeyContext(),
                        validationErrorBill.getMessageContext()));
            }
        }

        if (StringUtils.isEmpty(idmUserInputBean.getShipPostalCode())) {
            errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(SHIPPING_ZIPNDPOSTAL)));
        } else {
            ValidationExceptions validationException_ship = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase();
            }
            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getShipPostalCode(), SHIPPING_ZIPNDPOSTAL, validationException_ship);
            for (com.agilent.base.platform.ValidationError validationErrorShip : validationException_ship.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorShip.getErrId(), "profile", validationErrorShip.getKeyContext(),
                        validationErrorShip.getMessageContext()));
            }
        }

        if (getCountryUtils().getCountryItems(idmUserInputBean.getShipCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmShipCountryInvalid"));
        } else

        if (getCountryUtils().getCountryItems(idmUserInputBean.getBillCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmBillCountryInvalid"));
        } else

        if (!StringUtils.isBlank(idmUserInputBean.getBillCountry()) && !idmUserInputBean.getBillCountry().equals(idmUserInputBean.getShipCountry())) {
            errorMessages.add(resourceBundle.getString("idmShipandBillSameCountry"));
        }

        if (errorMessages.size() > 0) {
            vlogInfo("Validation Failed and list of problem == {0}", errorMessages);
        }

        return errorMessages;
    }

    public List<String> inputValidationForUpdate(IDMUserInputBean idmUserInputBean) throws RepositoryException {

        List<String> errorMessages = new ArrayList<String>();
        Locale locale = new Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
        ResourceBundle resourceBundle = ResourceBundle.getBundle(getErrorHandler().getBundleMap().get("profile"), locale);

        try {
            getValidator().validate("registerServiceValidationUpdate", idmUserInputBean);
        } catch (SystemException e) {
            vlogError(e, "EXPECTION_OCCURED_inputValidationForUpdate");
        } catch (ValidationExceptions eValidationErros) {
            List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
            for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                try {
                    errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                            validationError.getMessageContext()));
                } catch (Exception ev) {
                    vlogError(ev, "EXPECTION_OCCURED_inputValidationForUpdate");
                }
            }
        }

        if (!StringUtils.isEmpty(idmUserInputBean.getSapSalesOrg())) {
            if (!AgilentUtil.isValidSalesOrg(idmUserInputBean.getSapSalesOrg().toUpperCase())) {
                errorMessages.add("Provided SalesOrg is not Valid");
            }
        }

        if (!StringUtils.isEmpty(idmUserInputBean.getBillPostalCode())) {
            ValidationExceptions validationException_bill = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase();
            }
            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getBillPostalCode(), BILLING_ZIPNDPOSTAL, validationException_bill);
            for (com.agilent.base.platform.ValidationError validationErrorBill : validationException_bill.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorBill.getErrId(), "profile", validationErrorBill.getKeyContext(),
                        validationErrorBill.getMessageContext()));
            }
        }

        if (!StringUtils.isEmpty(idmUserInputBean.getShipPostalCode())) {
            ValidationExceptions validationException_ship = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase();
            }
            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getShipPostalCode(), SHIPPING_ZIPNDPOSTAL, validationException_ship);
            for (com.agilent.base.platform.ValidationError validationErrorShip : validationException_ship.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorShip.getErrId(), "profile", validationErrorShip.getKeyContext(),
                        validationErrorShip.getMessageContext()));
            }
        }

        if (!StringUtils.isBlank(idmUserInputBean.getShipCountry()) && getCountryUtils().getCountryItems(idmUserInputBean.getShipCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmShipCountryInvalid"));
        } else

        if (!StringUtils.isBlank(idmUserInputBean.getBillCountry()) && getCountryUtils().getCountryItems(idmUserInputBean.getBillCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmBillCountryInvalid"));
        } else

        if (!StringUtils.isBlank(idmUserInputBean.getBillCountry()) && !StringUtils.isBlank(idmUserInputBean.getShipCountry())
                && !idmUserInputBean.getBillCountry().equals(idmUserInputBean.getShipCountry())) {
            errorMessages.add(resourceBundle.getString("idmShipandBillSameCountry"));
        }

        if (errorMessages.size() > 0) {
            vlogInfo("Validation Failed and list of problem1 == {0}", errorMessages);
        }

        return errorMessages;
    }

    private boolean validPrimitiveType(String idmUserRequestString, Gson gjson) {
        JsonObject json = gjson.fromJson(idmUserRequestString, JsonObject.class);
        Set<Entry<String, JsonElement>> slist = json.entrySet();
        for (Entry e : slist) {
            JsonElement ele = (JsonElement) e.getValue();
            if (ele.isJsonPrimitive() && ele.getAsJsonPrimitive().isNumber()) {
                if (!(ele.getAsJsonPrimitive().getAsInt() == 1 || ele.getAsJsonPrimitive().getAsInt() == 0)) {
                    vlogDebug("Invalid Number has provided , Needed value is 1 or 0 ====={0}", ele.getAsJsonPrimitive().getAsInt());
                    return false;
                }
            }
        }
        return true;
    }
}
