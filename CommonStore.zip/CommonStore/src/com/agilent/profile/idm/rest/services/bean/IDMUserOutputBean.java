package com.agilent.profile.idm.rest.services.bean;

import java.util.List;

public class IDMUserOutputBean {
		
	public enum StatusCode {SUCCESS,ERROR};

	public IDMUserOutputBean() {
	
	}
	
	public IDMUserOutputBean(StatusCode statusCode,String status) {
		this.statusCode=statusCode;
		this.status=status;		
	}
	
	public IDMUserOutputBean(StatusCode statusCode,String status,List<String> errorMessages) {
		this.statusCode=statusCode;
		this.status=status;		
		this.errorMessages=errorMessages;
	}
	
	private StatusCode statusCode;
	private String status;	
	private List<String> errorMessages;
	private String atgUserId;
	private Integer migratedStatus;
	private String migratedSource;
	private String migratedredirectURL;
	private String migratedUserEmail;
	
	


	public Integer getMigratedStatus() {
		return migratedStatus;
	}

	public void setMigratedStatus(Integer migratedStatus) {
		this.migratedStatus = migratedStatus;
	}

	public String getMigratedSource() {
		return migratedSource;
	}

	public void setMigratedSource(String migratedSource) {
		this.migratedSource = migratedSource;
	}

	public String getMigratedredirectURL() {
		return migratedredirectURL;
	}

	public void setMigratedredirectURL(String migratedredirectURL) {
		this.migratedredirectURL = migratedredirectURL;
	}

	public String getMigratedUserEmail() {
		return migratedUserEmail;
	}

	public void setMigratedUserEmail(String migratedUserEmail) {
		this.migratedUserEmail = migratedUserEmail;
	}

	public StatusCode getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(StatusCode statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<String> getErrorMessages() {
		return errorMessages;
	}

	public void setErrorMessages(List<String> errorMessages) {
		this.errorMessages = errorMessages;
	}	

	public String getAtgUserId() {
		return atgUserId;
	}

	public void setAtgUserId(String atgUserId) {
		this.atgUserId = atgUserId;
	}

	@Override
	public String toString() {

		StringBuffer sb= new StringBuffer();
		sb.append("status"+status+"\n");
		sb.append("statusCode="+statusCode+"\n");
		sb.append("atgUserId="+atgUserId+"\n");
		sb.append("migratedStatus="+migratedStatus+"\n");
		sb.append("migratedredirectURL="+migratedredirectURL+"\n");
		sb.append("migratedUserEmail="+migratedUserEmail+"\n");
		sb.append("migratedSource="+migratedSource+"\n");

		
		return sb.toString();
	}
	
		
	
}
