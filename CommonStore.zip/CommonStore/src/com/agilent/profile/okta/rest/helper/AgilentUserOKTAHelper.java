package com.agilent.profile.okta.rest.helper;

import static com.agilent.base.commerce.Constants.PROP_ECOMMCSREMAIL;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.Set;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;

import com.agilent.base.platform.CountryUtils;
import com.agilent.base.platform.IErrorId;
import com.agilent.base.platform.ValidationExceptions;
import com.agilent.base.platform.util.AgilentEmailTools;
import com.agilent.base.platform.util.ValidatorUtil;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.profile.AgilentPropertyManager;
import com.agilent.base.profile.Constants;
import com.agilent.base.profile.services.FileUploadComponent;
import com.agilent.base.userprofiling.CountrySalesOrgProfilePropertySetter;
import com.agilent.profile.okta.rest.services.bean.OKTAUserInputBean;
import com.agilent.profile.okta.services.rest.RegisterInfoInput;

import atg.core.util.StringUtils;
import atg.multisite.SiteContextManager;
import atg.nucleus.GenericService;
import atg.repository.MutableRepositoryItem;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.rql.RqlStatement;
import atg.servlet.RequestLocale;
import atg.userprofiling.Profile;
import atg.userprofiling.email.TemplateEmailException;
import atg.userprofiling.email.TemplateEmailInfoImpl;

public class AgilentUserOKTAHelper extends GenericService {

    private static final String DEFAULT_lOCALE_EN_US = "en_US";
    private static final String DEFAULT_SALES_ORG = "04US";
    private static final String DEFAULT_COUNTRY = "US";
    private static final String CHINA_LOCALE =   "zh_CN";
  
    public static final String CUSTOMER_NAME1 = "customerName1";
    public static final String COMPANY_TAX_CODE1 = "companyTaxCode1";
    public static final String ADDRESS1 = "address1";
    public static final String BANK_NAME1 = "bankName1";
    public static final String BANK_ACCOUNT1 = "bankAccount1";
    public static final String CUSTOMER_NAME2 = "customerName2";
    public static final String CITY2 = "city2";
    public static final String SHIPPING_ADDRESS2 = "shippingAdrress2";
    public static final String POST_CODE2 = "postCode2";
    public static final String CONTACTOR_NAME2 = "contactorName2";
    public static final String CONTACTOR_PHNUM2 = "contactorPhNum2";
    public static final String B2BUSER = "b2bUser";
    public static final String DIRECTOR_ACCOUNT = "directorAccount";
    public static final String GROUP_ID = "groupId";
    public static final String SHOW_DUTY_FREE_PRICE = "showDutyFreePrice";
    public static final String ADD_FILE_UPLOADED = "isAddFileUploaded";
    public static final String PAYER_INVOICE_EMAIL = "payerInvoiceEmail";
    public static final String ADVANCE_SHIPDISABLE = "advShpDisable";
    public static final String CRM_CONTACTID = "crmContactId";
    public static final String SECONDARY_ECC_ID = "secondaryEccId";
    public static final String MULTIPLE_SOLD_ID = "multipleSoldTo";
    private static final String OKTA_PROFILE_STATUS = "oktaProfileStatus";
    private static final String DEACTIVE="DEACTIVE";
    private static final String ACTIVE="ACTIVE";
    private static final String INTERMEDIATE="INTERMEDIATE";
   

    private AgilentProfileTools profileTools = null;
    private CountrySalesOrgProfilePropertySetter countrySalesOrgProfilePropertySetter;
    private TemplateEmailInfoImpl mRegEmailTemplateInfo;
    private List<String> mCountriesListwithoutPC;
    private CountryUtils mCountryUtils;
    private Map<String, String> mSalesRegionDefaultShipMethod;
    private List<String> mValidCreditCardCountryList;
    private FileUploadComponent mFileUploadController;
    private List<String> mEmailDisabledSite;
    private Map<String, String> mDefaultRegEmailGroup;
    private String mRegisterCsrEmailFrom;
    private boolean mPeriodicEmail;
    private AgilentEmailTools mEmailTools;
    private List<String> mEnabledCountryList;
    private String mRegMessageSubject;
    private TransactionManager mTransactionManager;
    private boolean mProgressiveRegistration;
    

	/**
	 * This method is used to create user in atg with limitted attriubutes
	 * @param userItem
	 * @param idmUserInputBean
	 * @throws IOException
	 * @throws RepositoryException
	 */
    public void createUserWithLimitedAttribute(MutableRepositoryItem userItem, OKTAUserInputBean pIdmUserInputBean) throws IOException, RepositoryException {
    	vlogDebug("----- Entering into AgilentUserOKTAHelper.createUserWithLimitedAttribute ------");
    	OKTAUserInputBean idmUserInputBean = pIdmUserInputBean;
    	AgilentPropertyManager propMgr = null;
    	if(null != idmUserInputBean && StringUtils.isNotBlank(idmUserInputBean.getEmail())) {
    		propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
            userItem.setPropertyValue(propMgr.getLoginPropertyName(), idmUserInputBean.getEmail());
            userItem.setPropertyValue(propMgr.getAdLoginNamePropertyName(), idmUserInputBean.getEmail());
            userItem.setPropertyValue(propMgr.getEmailAddressPropertyName(), idmUserInputBean.getEmail());
            userItem.setPropertyValue(propMgr.getFirstNamePropertyName(), idmUserInputBean.getFirstName());
            userItem.setPropertyValue(propMgr.getLastNamePropertyName(), idmUserInputBean.getLastName());
            if (StringUtils.isBlank(idmUserInputBean.getBillCountry())) {
            	vlogInfo("AgilentUserOKTAHelper.createUserWithLimitedAttribute ::: Billing Country is empty, Hence setting US");
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), DEFAULT_COUNTRY);
            } else {
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());
            }
            if (StringUtils.isBlank(idmUserInputBean.getEcommerceStatus())) {
            	vlogInfo("AgilentUserOKTAHelper.createUserWithLimitedAttribute ::: EcommStatus is empty, Hence setting WEB");
                userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
            } else {
            	userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(),
                        idmUserInputBean.getEcommerceStatus().equals(Constants.VALUE_SAP) ? Constants.VALUE_SAP : Constants.VALUE_WEB);
            }
            if (StringUtils.isBlank(idmUserInputBean.getMemberType())) {
            	vlogInfo("AgilentUserOKTAHelper.createUserWithLimitedAttribute ::: MemberType is empty, Hence setting Member");
            	userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
            } else {
            	userItem.setPropertyValue(propMgr.getMemberTypePropertyName(),
                         idmUserInputBean.getMemberType().equals(Constants.VALUE_DISTRIBUTOR) ? Constants.VALUE_DISTRIBUTOR : Constants.VALUE_MEMBER);
            }
            userItem.setPropertyValue(propMgr.getDefaultShippingMethodPropertyName(), Constants.STANDARDSHIPPING);
            userItem.setPropertyValue(propMgr.getDefaultPaymentMethodPropertyName(), Constants.PAY_METHOD_PO);
            userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
            userItem.setPropertyValue(propMgr.getLocalePropertyName(), DEFAULT_lOCALE_EN_US);
            userItem.setPropertyValue(propMgr.getPlaceOnlineOrdersPropertyName(), idmUserInputBean.getEnableCommerce() == 0 ? false : true);
            userItem.setPropertyValue(propMgr.getTestAccountPropertyName(), idmUserInputBean.getTestAccount() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), idmUserInputBean.getDropShipment() == 0 ? false : true);
            userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(), idmUserInputBean.getIncludePunchoutShipping() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(), idmUserInputBean.getIncludePunchoutTaxes() == 1 ? true : false);
            userItem.setPropertyValue(ADVANCE_SHIPDISABLE, idmUserInputBean.getAdvanceShippingDisabled() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(), idmUserInputBean.getTaxExempt() == 1 ? true : false);
            userItem.setPropertyValue(B2BUSER, idmUserInputBean.getB2bUser() == 1 ? true : false);
            userItem.setPropertyValue(Constants.PROP_BILLING_ADDRESS, createBillContatcInfo(idmUserInputBean));
            userItem.setPropertyValue(Constants.PROP_SHIPPING_ADDRESS, createShipContatcInfo(idmUserInputBean));
            createSecondaryAddress(userItem);
            String salesOrg = DEFAULT_SALES_ORG;
            if (this.getCountrySalesOrgProfilePropertySetter() == null || idmUserInputBean.getBillCountry() == null) {
            	vlogInfo("AgilentUserOKTAHelper.createUserWithLimitedAttribute ::: Bill Country is empty, Hence setting 04US");
            	userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
            }else {
                salesOrg = this.getCountrySalesOrgProfilePropertySetter().getSalesOrg(idmUserInputBean.getBillCountry());
                if (salesOrg == null) {
                    salesOrg = DEFAULT_SALES_ORG;
                    vlogDebug("Cannot retrieve SAP Sales Org for country ::" + idmUserInputBean.getBillCountry());
                }
                userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());
            }
            userItem.setPropertyValue(ADD_FILE_UPLOADED, idmUserInputBean.getAddFileUploaded() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getSapMasterAccountPropertyName(), idmUserInputBean.getSapMasterAccount() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getMossDownWhenRegisterPropertyName(), idmUserInputBean.getMossDownWhenRegister() == 1 ? true : false);
            userItem.setPropertyValue(SHOW_DUTY_FREE_PRICE, idmUserInputBean.getShowDutyFreePrice() == 1 ? true : false);
            getProfileTools().getProfileRepository().addItem(userItem);
    	}else {
    		vlogInfo("----- AgilentUserOKTAHelper.createUserWithLimitedAttribute  :: empty Response/email id is blacnk, Hence user not created in ATG ------");
    	}
        vlogDebug("----- Existing from AgilentUserOKTAHelper.createUserWithLimitedAttribute ------");
    }

    /**
     * This method will create an user in ATG
     * @param userItem
     * @param pIdmUserInputBean
     * @throws IOException
     * @throws RepositoryException
     */
    public void createUserInRepo(MutableRepositoryItem userItem, OKTAUserInputBean pIdmUserInputBean) throws IOException, RepositoryException {
    	vlogDebug("----- Entering into AgilentUserOKTAHelper.createUserInRepo ------");
    	OKTAUserInputBean idmUserInputBean = pIdmUserInputBean;
    	AgilentPropertyManager propMgr = null;
    	String[] secondaryEccId = null;
        String[] multipleSoldTo = null;
        Set<String> sEccSet = null;
        Set<String> sMccSet = null;
        String encryptedNewPassword = null;
    	if(null != idmUserInputBean && StringUtils.isNotBlank(idmUserInputBean.getEmail())) {
			propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
			encryptedNewPassword = getProfileTools().getPropertyManager().generatePassword(idmUserInputBean.getPassword(), "pa$$word");
	        userItem.setPropertyValue(propMgr.getLoginPropertyName(), idmUserInputBean.getEmail());
	        userItem.setPropertyValue(propMgr.getPasswordPropertyName(), encryptedNewPassword);
	        userItem.setPropertyValue(propMgr.getAdLoginNamePropertyName(), idmUserInputBean.getEmail());
	        userItem.setPropertyValue(propMgr.getFirstNamePropertyName(), idmUserInputBean.getFirstName());
	        userItem.setPropertyValue(propMgr.getLastNamePropertyName(), idmUserInputBean.getLastName());
	        userItem.setPropertyValue(propMgr.getEmailAddressPropertyName(), idmUserInputBean.getEmail());
	        userItem.setPropertyValue(propMgr.getSapContactNumberPropertyName(), idmUserInputBean.getSapCustomerId());
	        userItem.setPropertyValue(propMgr.getTitle(), idmUserInputBean.getTitle());
	        userItem.setPropertyValue(propMgr.getDepartment(), idmUserInputBean.getDepartment());
	        userItem.setPropertyValue(propMgr.getRegion(), idmUserInputBean.getRegion());

	        if(StringUtils.isBlank(idmUserInputBean.getBillCountry()) && StringUtils.isNotBlank(idmUserInputBean.getUserCountry())) {
	        	userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getUserCountry());
	        }else if(StringUtils.isNotBlank(idmUserInputBean.getBillCountry())) {
	        	userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());
	        }else {
	        	userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), DEFAULT_COUNTRY);
	        }
	        
	        if (StringUtils.isBlank(idmUserInputBean.getEcommerceStatus())) {
	        	userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
	        } else {
	            userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(),
	                    idmUserInputBean.getEcommerceStatus().equals(Constants.VALUE_SAP) ? Constants.VALUE_SAP : Constants.VALUE_WEB);
	        }

	        if (StringUtils.isBlank(idmUserInputBean.getMemberType())) {
	        	userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
	        } else {
	            userItem.setPropertyValue(propMgr.getMemberTypePropertyName(),
	                    idmUserInputBean.getMemberType().equals(Constants.VALUE_DISTRIBUTOR) ? Constants.VALUE_DISTRIBUTOR : Constants.VALUE_MEMBER);
	        }

	        userItem.setPropertyValue(propMgr.getDefaultShippingMethodPropertyName(), Constants.STANDARDSHIPPING);
	        userItem.setPropertyValue(propMgr.getDefaultPaymentMethodPropertyName(), Constants.PAY_METHOD_PO);
	        userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
	        userItem.setPropertyValue(propMgr.getLocalePropertyName(), DEFAULT_lOCALE_EN_US);
	        userItem.setPropertyValue(propMgr.getPlaceOnlineOrdersPropertyName(), idmUserInputBean.getEnableCommerce() == 0 ? false : true);
	        userItem.setPropertyValue(propMgr.getTestAccountPropertyName(), idmUserInputBean.getTestAccount() == 1 ? true : false);
	        userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), idmUserInputBean.getDropShipment() == 0 ? false : true);
	        userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(), idmUserInputBean.getIncludePunchoutShipping() == 1 ? true : false);
	        userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(), idmUserInputBean.getIncludePunchoutTaxes() == 1 ? true : false);
	        userItem.setPropertyValue(ADVANCE_SHIPDISABLE, idmUserInputBean.getAdvanceShippingDisabled() == 1 ? true : false);
	        userItem.setPropertyValue(propMgr.getPartnerNamePropertyName(), idmUserInputBean.getPartnerName());
	        userItem.setPropertyValue(propMgr.getPartnerIdentifierrPropertyName(), idmUserInputBean.getPartnerIdentifier());
	        userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), idmUserInputBean.getPunchoutMember());
	        userItem.setPropertyValue(propMgr.getShippAddTypeProppertyName(), idmUserInputBean.getDefaultShipAddressType());
	        userItem.setPropertyValue(propMgr.getDefaultSAPBillToAddressPropertyName(), idmUserInputBean.getSapBillToAddress());
	        userItem.setPropertyValue(propMgr.getDefaultSAPShipToAddressPropertyName(), idmUserInputBean.getSapShipToAddress());
	        userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), idmUserInputBean.getPunchoutMember());
	        userItem.setPropertyValue(propMgr.getTaxExemptedNumPropertyName(), idmUserInputBean.getTaxExemptNumber());
	        userItem.setPropertyValue(propMgr.getTaxExemptCertPropertyName(), idmUserInputBean.getTaxExemptCertificatePath());
	        userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(), idmUserInputBean.getTaxExempt() == 1 ? true : false);
	        userItem.setPropertyValue(B2BUSER, idmUserInputBean.getB2bUser() == 1 ? true : false);
	        userItem.setPropertyValue(GROUP_ID, idmUserInputBean.getB2bGroupId());

	        if (!StringUtils.isBlank(idmUserInputBean.getFedexCollectNumber())) {
	            userItem.setPropertyValue(propMgr.getFedexUpsCollectNumber(), idmUserInputBean.getFedexCollectNumber());
	        }

	        if (!StringUtils.isBlank(idmUserInputBean.getUpsCollectNumber())) {
	            userItem.setPropertyValue(propMgr.getUPSCollectNumber(), idmUserInputBean.getUpsCollectNumber());
	        }

	        userItem.setPropertyValue(Constants.PROP_BILLING_ADDRESS, createBillContatcInfo(idmUserInputBean));
	        userItem.setPropertyValue(Constants.PROP_SHIPPING_ADDRESS, createShipContatcInfo(idmUserInputBean));
	        String billPostalCode = idmUserInputBean.getBillPostalCode();
	        String shipPostalCode = idmUserInputBean.getShipPostalCode();
	        String billCity = idmUserInputBean.getBillCity();
	        String shipCity = idmUserInputBean.getShipCity();
	        if(StringUtils.isNotBlank(billPostalCode) && StringUtils.isNotBlank(shipPostalCode) && 
	        		StringUtils.isNotBlank(billCity) && StringUtils.isNotBlank(shipCity)) {
	        	createSecondaryAddress(userItem);
	        	vlogDebug("AgilentUserOKTAHelper.createUserInRepo ::: secondary Address created for this profile");
	        }
	        
	        if(getCountriesListwithoutPC().contains(idmUserInputBean.getShipCountry())){
	            createSecondaryAddress(userItem); 
	            vlogDebug("AgilentUserOKTAHelper.createUserInRepo ::: secondary Address created for postal code not available for countries");
	        }
	        String salesOrg = DEFAULT_SALES_ORG;
	        if (this.getCountrySalesOrgProfilePropertySetter() != null && idmUserInputBean.getBillCountry() != null) {
	            salesOrg = this.getCountrySalesOrgProfilePropertySetter().getSalesOrg(idmUserInputBean.getBillCountry());
	            if (salesOrg == null) {
	                salesOrg = DEFAULT_SALES_ORG;
	                vlogDebug("Cannot retrieve SAP Sales Org for country ::{0}", idmUserInputBean.getBillCountry());
	            }
	            userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
	            userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), idmUserInputBean.getBillCountry());
	            if (salesOrg != null && "04MX".equals(salesOrg)) {
	                userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), false);
	            } else {
	                userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), true);
	            }
	        }else {
	        	salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getUserCountry());
	        	if (salesOrg == null) {
	                salesOrg = DEFAULT_SALES_ORG;
	                vlogDebug("Cannot retrieve SAP Sales Org for country:::{0}",idmUserInputBean.getUserCountry());
	            }
	        	userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
	        }

	        userItem.setPropertyValue(CRM_CONTACTID, idmUserInputBean.getCrmContactNumber());
	        userItem.setPropertyValue(PAYER_INVOICE_EMAIL, idmUserInputBean.getPayerInvoiceEmail());
	        userItem.setPropertyValue(ADD_FILE_UPLOADED, idmUserInputBean.getAddFileUploaded() == 1 ? true : false);
	        userItem.setPropertyValue(propMgr.getSapMasterAccountPropertyName(), idmUserInputBean.getSapMasterAccount() == 1 ? true : false);
	        userItem.setPropertyValue(propMgr.getMossDownWhenRegisterPropertyName(), idmUserInputBean.getMossDownWhenRegister() == 1 ? true : false);
	        userItem.setPropertyValue(SHOW_DUTY_FREE_PRICE, idmUserInputBean.getShowDutyFreePrice() == 1 ? true : false);
	        secondaryEccId = idmUserInputBean.getSecondaryECCContact_ID();
	        if (null != secondaryEccId && secondaryEccId.length > 0) {
	            sEccSet = new HashSet<String>(Arrays.asList(secondaryEccId));
	            if(sEccSet!= null && sEccSet.contains(null)){
	            	sEccSet.remove(null);
	            }
	            userItem.setPropertyValue(SECONDARY_ECC_ID, sEccSet);
	        }
	        multipleSoldTo = idmUserInputBean.getMultipleSoldTo();
	        if (null != multipleSoldTo && multipleSoldTo.length > 0) {
	        	sMccSet = new HashSet<String>(Arrays.asList(multipleSoldTo));
	        	sMccSet.remove(" ");
	            if(sMccSet!= null && sMccSet.contains(null)){
	            	sMccSet.remove(null);
	            }
	            userItem.setPropertyValue(MULTIPLE_SOLD_ID, sMccSet);
	        }

	        // Invoice details insert

	        userItem.setPropertyValue(CUSTOMER_NAME1, idmUserInputBean.getInvoice().getInvoiceCustomerName());
	        userItem.setPropertyValue(COMPANY_TAX_CODE1, idmUserInputBean.getInvoice().getInvoiceCompanyTaxCode());
	        userItem.setPropertyValue(ADDRESS1, idmUserInputBean.getInvoice().getInvoiceAddress());
	        userItem.setPropertyValue(BANK_NAME1, idmUserInputBean.getInvoice().getInvoiceBankName());
	        userItem.setPropertyValue(BANK_ACCOUNT1, idmUserInputBean.getInvoice().getInvoiceBankAccount());
	        userItem.setPropertyValue(CUSTOMER_NAME2, idmUserInputBean.getInvoice().getInvoiceShipCustomerName());
	        userItem.setPropertyValue(CITY2, idmUserInputBean.getInvoice().getInvoiceShipCity());
	        userItem.setPropertyValue(SHIPPING_ADDRESS2, idmUserInputBean.getInvoice().getInvoiceShipShippingAddress());
	        userItem.setPropertyValue(POST_CODE2, idmUserInputBean.getInvoice().getInvoiceShipPostCode());
	        userItem.setPropertyValue(CONTACTOR_NAME2, idmUserInputBean.getInvoice().getInvoiceShipContactPerson());
	        userItem.setPropertyValue(CONTACTOR_PHNUM2, idmUserInputBean.getInvoice().getInvoiceShipContactPhoneNumber());

	        getProfileTools().getProfileRepository().addItem(userItem);
	        encryptedNewPassword = clearVariables();
    	}else {
    		vlogInfo("----- AgilentUserOKTAHelper.createUserInRepo  :: empty Response/email id is blacnk, Hence user not created in ATG ------");
    	}
    	
        vlogDebug("----- Existing from AgilentUserOKTAHelper.createUserInRepo ------");
    }
    
    /**
     * Clear variables
     * @return
     */
	private String clearVariables() {
		return null;
	}

	/**
	 * This method will update user in atg from Okta response
	 * 
	 * @param userItem
	 * @param pOktaUserInputBean
	 * @throws RepositoryException
	 */
    public void updateUserInRepo(MutableRepositoryItem userItem, OKTAUserInputBean pOktaUserInputBean) throws RepositoryException {
    	vlogDebug("::::  Entering into AgilentUserOKTAHelper..updateUserInRepo ::::");
    	OKTAUserInputBean oktaUserInputBean = pOktaUserInputBean;
    	AgilentPropertyManager propMgr = null;
    	String[] secondaryEccId = null;
        String[] multipleSoldTo = null;
        Set<String> sEccSet = null;
        Set<String> sMccSet = null;
    	if(null != oktaUserInputBean) {
    		propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
    		checkAndSetProperty(userItem, propMgr.getEmailAddressPropertyName(), oktaUserInputBean.getEmail());
    		checkAndSetProperty(userItem, propMgr.getLoginPropertyName(), oktaUserInputBean.getEmail());
    		checkAndSetProperty(userItem, propMgr.getAdLoginNamePropertyName(), oktaUserInputBean.getAdLoginName());
            checkAndSetProperty(userItem, propMgr.getFirstNamePropertyName(), oktaUserInputBean.getFirstName());
            checkAndSetProperty(userItem, propMgr.getLastNamePropertyName(), oktaUserInputBean.getLastName());
            checkAndSetProperty(userItem, propMgr.getSapContactNumberPropertyName(), oktaUserInputBean.getSapCustomerId());
            checkAndSetProperty(userItem, propMgr.getTitle(), oktaUserInputBean.getTitle());
            checkAndSetProperty(userItem, propMgr.getDepartment(), oktaUserInputBean.getDepartment());
            if (!StringUtils.isBlank(oktaUserInputBean.getEcommerceStatus())) {
                if (Constants.VALUE_WEB.equals(oktaUserInputBean.getEcommerceStatus())) {
                    userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
                } else if (Constants.VALUE_SAP.equals(oktaUserInputBean.getEcommerceStatus())) {
                    userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_SAP);
                }
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getMemberType()) && oktaUserInputBean.getMemberType().equals(Constants.VALUE_DISTRIBUTOR)) {
                userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_DISTRIBUTOR);
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getMemberType()) && oktaUserInputBean.getMemberType().equals(Constants.VALUE_MEMBER)) {
                userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getSapSalesOrg())) {
                userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), oktaUserInputBean.getSapSalesOrg().toUpperCase());
            }
            checkAndSetBoolean(userItem, propMgr.getTestAccountPropertyName(), oktaUserInputBean.getTestAccount());
            checkAndSetBoolean(userItem, propMgr.getSapMasterAccountPropertyName(), oktaUserInputBean.getSapMasterAccount());
            createBillContatcInfoForUpdate(oktaUserInputBean, userItem);
            createShipContatcInfoForUpdate(oktaUserInputBean, userItem);
            if(isProgressiveRegistration()){            	
            	Map<String, RepositoryItem> secondaryAddresses = (Map) userItem.getPropertyValue(propMgr.getSecondaryAddressPropertyName());
            	vlogDebug("AgilentUserOKTAHelper.updateUserInRepo Inside Progressive Reg Secondary Address {0} ",secondaryAddresses);
            	if(null != secondaryAddresses && secondaryAddresses.isEmpty()){
            		vlogDebug("AgilentUserOKTAHelper.updateUserInRepo ::: secondary Address is Empty for this profile");
            		String billPostalCode = oktaUserInputBean.getBillPostalCode();
            		String shipPostalCode = oktaUserInputBean.getShipPostalCode();
            		String billCity = oktaUserInputBean.getBillCity();
            		String shipCity = oktaUserInputBean.getShipCity();
            		if(StringUtils.isNotBlank(billPostalCode) && StringUtils.isNotBlank(shipPostalCode) && 
            				StringUtils.isNotBlank(billCity) && StringUtils.isNotBlank(shipCity)) {
            			createSecondaryAddress(userItem);
            			vlogDebug("AgilentUserOKTAHelper.updateUserInRepo ::: secondary Address created for this profile");
            		}

            		if(getCountriesListwithoutPC().contains(oktaUserInputBean.getShipCountry())){
            			createSecondaryAddress(userItem); 
            			vlogDebug("AgilentUserOKTAHelper.updateUserInRepo ::: secondary Address created for postal code not available for countries");
            		}

            	}
            }
            checkAndSetProperty(userItem, CUSTOMER_NAME1, oktaUserInputBean.getInvoice().getInvoiceCustomerName());
            checkAndSetProperty(userItem, COMPANY_TAX_CODE1, oktaUserInputBean.getInvoice().getInvoiceCompanyTaxCode());
            checkAndSetProperty(userItem, ADDRESS1, oktaUserInputBean.getInvoice().getInvoiceAddress());
            checkAndSetProperty(userItem, BANK_NAME1, oktaUserInputBean.getInvoice().getInvoiceBankName());
            checkAndSetProperty(userItem, BANK_ACCOUNT1, oktaUserInputBean.getInvoice().getInvoiceBankAccount());
            checkAndSetProperty(userItem, CUSTOMER_NAME2, oktaUserInputBean.getInvoice().getInvoiceShipCustomerName());
            checkAndSetProperty(userItem, CITY2, oktaUserInputBean.getInvoice().getInvoiceShipCity());
            checkAndSetProperty(userItem, SHIPPING_ADDRESS2, oktaUserInputBean.getInvoice().getInvoiceShipShippingAddress());
            checkAndSetProperty(userItem, POST_CODE2, oktaUserInputBean.getInvoice().getInvoiceShipPostCode());
            checkAndSetProperty(userItem, CONTACTOR_NAME2, oktaUserInputBean.getInvoice().getInvoiceShipContactPerson());
            checkAndSetProperty(userItem, CONTACTOR_PHNUM2, oktaUserInputBean.getInvoice().getInvoiceShipContactPhoneNumber());
            checkAndSetProperty(userItem, CRM_CONTACTID, oktaUserInputBean.getCrmContactNumber());
            secondaryEccId = oktaUserInputBean.getSecondaryECCContact_ID();
            if (null != secondaryEccId && secondaryEccId.length > 0) {
                sEccSet = new HashSet<String>(Arrays.asList(secondaryEccId));
                sEccSet.remove(" ");
                if(sEccSet!= null && sEccSet.contains(null)){
                	sEccSet.remove(null);
                }
                userItem.setPropertyValue(SECONDARY_ECC_ID, sEccSet);
            }else {
            	 sEccSet = new HashSet<String>();
            	 userItem.setPropertyValue(SECONDARY_ECC_ID, sEccSet);
            }
            multipleSoldTo = oktaUserInputBean.getMultipleSoldTo();
            if (null != multipleSoldTo && multipleSoldTo.length > 0) {
            	sMccSet = new HashSet<String>(Arrays.asList(multipleSoldTo));
            	sMccSet.remove(" ");
                if(sMccSet!= null && sMccSet.contains(null)){
                	sMccSet.remove(null);
                }
                userItem.setPropertyValue(MULTIPLE_SOLD_ID, sMccSet);
            }else {
            	sMccSet = new HashSet<String>();
           	 	userItem.setPropertyValue(MULTIPLE_SOLD_ID, sMccSet);
            }
            getProfileTools().getProfileRepository().updateItem(userItem);
    	}else {
    		vlogInfo("----- AgilentUserOKTAHelper.createUserInRepo  :: empty Response is blacnk, Hence user not created in ATG ------");
    	}
        vlogDebug("::::  Exiting from AgilentUserOKTAHelper.updateUserInRepo ::::");
    }
    
    /**
     * This method will create bill contact info
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createBillContatcInfo(OKTAUserInputBean bean) throws RepositoryException {
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
        if (bean != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getCompanyName());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getBillAddress1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getBillAddress2());
            item.setPropertyValue(propMgr.getCityPropertyName(), bean.getBillCity());
            item.setPropertyValue(propMgr.getStatePropertyName(), bean.getBillState());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getBillPostalCode());
            item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getBillCountry());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getPhoneNumber());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getExtension());
        }
        return item;
    }

    /**
     * This method will create bill contact info for update operation
     * @param oktaUserInputBean
     * @param userItem
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createBillContatcInfoForUpdate(OKTAUserInputBean oktaUserInputBean, MutableRepositoryItem userItem) throws RepositoryException {
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem billingItem = (MutableRepositoryItem) userItem.getPropertyValue(Constants.PROP_BILLING_ADDRESS);
        if (billingItem != null) {
            checkAndSetProperty(billingItem, propMgr.getFirstNamePropertyName(), oktaUserInputBean.getFirstName());
            checkAndSetProperty(billingItem, propMgr.getLastNamePropertyName(), oktaUserInputBean.getLastName());
            checkAndSetProperty(billingItem, propMgr.getCompanyPropertyName(), oktaUserInputBean.getCompanyName());
            checkAndSetProperty(billingItem, propMgr.getAddress1PropertyName(), oktaUserInputBean.getBillAddress1());
            checkAndSetProperty(billingItem, propMgr.getAddress2PropertyName(), oktaUserInputBean.getBillAddress2());
            checkAndSetProperty(billingItem, propMgr.getCityPropertyName(), oktaUserInputBean.getBillCity());
            checkAndSetProperty(billingItem, propMgr.getStatePropertyName(), oktaUserInputBean.getBillState());
            checkAndSetProperty(billingItem, propMgr.getPostalCodePropertyName(), oktaUserInputBean.getBillPostalCode());
            checkAndSetProperty(billingItem, propMgr.getCountryPropertyName(), oktaUserInputBean.getBillCountry());
            checkAndSetProperty(billingItem, propMgr.getPhoneNumberPropertyName(), oktaUserInputBean.getPhoneNumber());
            checkAndSetProperty(billingItem, propMgr.getExtensionPropertyName(), oktaUserInputBean.getExtension());
        }
        userItem.setPropertyValue(Constants.PROP_BILLING_ADDRESS, createBillContatcInfo(oktaUserInputBean));
        return billingItem;
    }

    /**
     * This method wil create ship contact info for update
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createShipContatcInfo(OKTAUserInputBean bean) throws RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createShipContatcInfo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
        if (bean != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getCompanyName());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getShipAddress1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getShipAddress2());
            item.setPropertyValue(propMgr.getCityPropertyName(), bean.getShipCity());
            item.setPropertyValue(propMgr.getStatePropertyName(), bean.getShipState());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getShipPostalCode());
            item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getShipCountry());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getPhoneNumber());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getExtension());
        }
        if (isLoggingDebug()) {
            vlogDebug("createShipContatcInfo Items {0}", item);
        }
        return item;
    }

    /**
     * This method will create ship contact infor for update
     * @param oktaUserInputBean
     * @param userItem
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createShipContatcInfoForUpdate(OKTAUserInputBean oktaUserInputBean, MutableRepositoryItem userItem) throws RepositoryException {
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem shippingItem = (MutableRepositoryItem) userItem.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
        if (shippingItem != null && oktaUserInputBean != null) {
            checkAndSetProperty(shippingItem, propMgr.getFirstNamePropertyName(), oktaUserInputBean.getFirstName());
            checkAndSetProperty(shippingItem, propMgr.getLastNamePropertyName(), oktaUserInputBean.getLastName());
            checkAndSetProperty(shippingItem, propMgr.getCompanyPropertyName(), oktaUserInputBean.getCompanyName());
            checkAndSetProperty(shippingItem, propMgr.getAddress1PropertyName(), oktaUserInputBean.getShipAddress1());
            checkAndSetProperty(shippingItem, propMgr.getAddress2PropertyName(), oktaUserInputBean.getShipAddress2());
            checkAndSetProperty(shippingItem, propMgr.getCityPropertyName(), oktaUserInputBean.getShipCity());
            checkAndSetProperty(shippingItem, propMgr.getStatePropertyName(), oktaUserInputBean.getShipState());
            checkAndSetProperty(shippingItem, propMgr.getPostalCodePropertyName(), oktaUserInputBean.getShipPostalCode());
            checkAndSetProperty(shippingItem, propMgr.getCountryPropertyName(), oktaUserInputBean.getShipCountry());
            checkAndSetProperty(shippingItem, propMgr.getPhoneNumberPropertyName(), oktaUserInputBean.getPhoneNumber());
            checkAndSetProperty(shippingItem, propMgr.getExtensionPropertyName(), oktaUserInputBean.getExtension());
        }
        userItem.setPropertyValue(Constants.PROP_SHIPPING_ADDRESS, createShipContatcInfo(oktaUserInputBean));
        return shippingItem;
    }

   
    /**
     * This method will update the status in the repository
     * @param pUserItem
     * @param pStatus
     * @throws RepositoryException
     */
    public void updateStatusInRepo(MutableRepositoryItem pUserItem, String pStatus) throws RepositoryException {
    	vlogDebug("::::  Entering into AgilentUserOKTAHelper.updateStatusInRepo ::::");
    	TransactionManager transactionManager = null;
        Transaction transaction = null;
    	if (StringUtils.isNotBlank(pStatus) && null != pUserItem) {
    		try {
	            transactionManager = getTransactionManager();
	            if (transactionManager == null) {
	                vlogError("NO Transaction Manager exist. Hence terminating persistRelayStateValue.");
	            } else {
	                transaction = transactionManager.getTransaction();
	                if (transaction == null) {
	                    transactionManager.begin();
	                }
	                if (DEACTIVE.equals(pStatus)) {
	                	pUserItem.setPropertyValue(OKTA_PROFILE_STATUS, DEACTIVE);
	                	getProfileTools().getProfileRepository().updateItem(pUserItem);
	                	vlogInfo(":::: AgilentUserOKTAHelper.updateStatusInRepo ::: Status value updated as DEACTIVE for ATG ID --->  {0} ::::",
	                			pUserItem.getRepositoryId());
	                } else if (ACTIVE.equals(pStatus)) {
	                	pUserItem.setPropertyValue(OKTA_PROFILE_STATUS, ACTIVE);
	                	getProfileTools().getProfileRepository().updateItem(pUserItem);
	                	vlogInfo(":::: AgilentUserOKTAHelper.updateStatusInRepo ::: Status value updated as ACTIVE for ATG ID --->  {0} ::::",
	                			pUserItem.getRepositoryId());
	                } else if (INTERMEDIATE.equals(pStatus)) {
	                	pUserItem.setPropertyValue(OKTA_PROFILE_STATUS, "INTERMEDIATE");
	                	getProfileTools().getProfileRepository().updateItem(pUserItem);
	                	vlogInfo(":::: AgilentUserOKTAHelper.updateStatusInRepo ::: Status value updated as INTERMEDIATE for ATG ID --->  {0} ::::",
	                			pUserItem.getRepositoryId());
	                } else {
	                	vlogInfo(":::: AgilentUserOKTAHelper.updateStatusInRepo ::: Status value not updated for ---> {0} ::::", pStatus);
	        		}
	            }
	        } catch (RepositoryException exception) {
	            	vlogError(exception, "RepositoryException occurred while performing create or update database");
		    } catch (SystemException exception) {
		            vlogError(exception, "SystemException occurred while initiating or beginning transaction.");
		    } catch (NotSupportedException exception) {
		            vlogError(exception,"NotSupportedException occurred while beginning transaction.");
		    } catch (Exception exception) {
		            vlogError(exception,"AgilentUserOKTAHelper");
		    } finally {
	            if (transactionManager != null) {
	                try {
	                    int transactionStatus = transactionManager.getStatus();
	                    if (transactionStatus == javax.transaction.Status.STATUS_MARKED_ROLLBACK) {
	                        transactionManager.rollback();
	                    } else {
	                        transactionManager.commit();
	                    }
	                } catch (RollbackException exception) {
	                    vlogError(exception,"RollbackException occurred while committing database transaction.");
	                } catch (HeuristicMixedException exception) {
	                    vlogError(exception,"HeuristicMixedException occurred while committing database transaction.");
	                } catch (HeuristicRollbackException exception) {
	                    vlogError(exception,"HeuristicRollbackException occurred while committing database transaction.");
	                } catch (SystemException exception) {
	                    vlogError(exception,"SystemException occurred while committing or rollbacking database transaction.");
	                }
	            }
		     }
        } else {
        	vlogInfo(":::: AgilentUserOKTAHelper.updateStatusInRepo ::: Status/userItem is Blank ::::");
        } 
    	vlogDebug("::::  Exiting from AgilentUserOKTAHelper.updateStatusInRepo ::::");
    }
    
    /**
     * This method will create secondary addressed for an user in ATG
     * @param userItem
     */
    private void createSecondaryAddress(MutableRepositoryItem userItem) {
        if (userItem != null) {
            vlogDebug("::::  Entering to the AgilentUserOKTAHelper.createSecondaryAddress ::::");
            AgilentPropertyManager propertyManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
            Map<String, RepositoryItem> secondaryAddresses = (Map) userItem.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
            RepositoryItem shippingAddress = (RepositoryItem) userItem.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
            // To make sure nickname will be unique always
            long number = (long) Math.floor(Math.random() * 9000000000L) + 1000000000L;
            String nickname = String.valueOf(number);
            Map<String, RepositoryItem> secondaryAdd = (Map<String, RepositoryItem>) userItem.getPropertyValue(propertyManager.getSecondaryAddressPropertyName());
            Set<String> key = secondaryAdd.keySet();
            Random rdn = new Random();
            if (!key.isEmpty()) {
                while (key.contains(nickname)) {
                    nickname = nickname + rdn.nextInt(100);
                }
            }
            secondaryAddresses.put(nickname, shippingAddress);
            vlogDebug("::::  Exiting from AgilentUserOKTAHelper.createSecondaryAddress ::::");
         }
        }
    
	/**
	 * This method will set boolean values
	 * @param userItem
	 * @param propertyName
	 * @param inputValue
	 */
    private void checkAndSetBoolean(MutableRepositoryItem userItem, String propertyName, int inputValue) {
    	if(inputValue == 1) {
    		 userItem.setPropertyValue(propertyName, true);
    	}else if(inputValue == 0) {
    		 userItem.setPropertyValue(propertyName, false);
    	}else {
    		vlogDebug("AgilentUserOKTAHelper.checkAndSetBoolean ::: Value is not 0 or 1 for the property --{0}", propertyName);
    	}
    }
    
	/**
	 * This method will set the property value to the profile
	 * @param userItem
	 * @param propertyName
	 * @param inputValue
	 */
    private void checkAndSetProperty(MutableRepositoryItem userItem, String propertyName, String inputValue) {
        if (StringUtils.isNotBlank(inputValue)) {
            userItem.setPropertyValue(propertyName, inputValue);
        }else {
        	vlogDebug("AgilentUserOKTAHelper.checkAndSetProperty ::: Value is empty for the property --{0}", propertyName);
        }
    }
    
    /**
     * This method is used for creating user in ATG
     * 
     * @param userItem
     * @param registerInput
     * @throws IOException
     * @throws RepositoryException
     */
    public void createUserInRepo(MutableRepositoryItem userItem, RegisterInfoInput registerInput) throws IOException, RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createUserInRepo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        String encryptedNewPassword = null;
        if (registerInput != null) {
            encryptedNewPassword = getProfileTools().getPropertyManager().generatePassword(registerInput.getAtgRestValue().getPassword(), "pa$$word");
            userItem.setPropertyValue(propMgr.getLoginPropertyName(), registerInput.getAtgRestValue().getEmail());
            userItem.setPropertyValue(propMgr.getAdLoginNamePropertyName(), registerInput.getAtgRestValue().getadLoginName());
            userItem.setPropertyValue(propMgr.getPasswordPropertyName(), encryptedNewPassword);
            userItem.setPropertyValue(propMgr.getFirstNamePropertyName(), registerInput.getAtgRestValue().getFirstName());
            userItem.setPropertyValue(propMgr.getLastNamePropertyName(), registerInput.getAtgRestValue().getLastName());
            userItem.setPropertyValue(propMgr.getEmailAddressPropertyName(), registerInput.getAtgRestValue().getEmail());
            userItem.setPropertyValue(propMgr.getTitle(), registerInput.getAtgRestValue().getTitle());
            userItem.setPropertyValue(propMgr.getDepartment(), registerInput.getAtgRestValue().getDepartment());
            userItem.setPropertyValue(propMgr.getRegion(), registerInput.getAtgRestValue().getRegion());

            if (StringUtils.isBlank(registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry())) {
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), DEFAULT_COUNTRY);
            } else {
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry());
            }

            if (!StringUtils.isBlank(registerInput.getAtgRestValue().getEcommerceStatus())) {
                userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(),
                        registerInput.getAtgRestValue().getEcommerceStatus().equals(Constants.VALUE_SAP) ? Constants.VALUE_SAP : Constants.VALUE_WEB);
            } else {
                userItem.setPropertyValue(propMgr.getEcomStatusPropertyName(), Constants.VALUE_WEB);
            }

            if (!StringUtils.isBlank(registerInput.getAtgRestValue().getMemberType())) {
                userItem.setPropertyValue(propMgr.getMemberTypePropertyName(),
                        registerInput.getAtgRestValue().getMemberType().equals(Constants.VALUE_DISTRIBUTOR) ? Constants.VALUE_DISTRIBUTOR : Constants.VALUE_MEMBER);
            } else {
                userItem.setPropertyValue(propMgr.getMemberTypePropertyName(), Constants.VALUE_MEMBER);
            }

            userItem.setPropertyValue(propMgr.getDefaultShippingMethodPropertyName(), Constants.STANDARDSHIPPING);
            userItem.setPropertyValue(propMgr.getDefaultPaymentMethodPropertyName(), Constants.PAY_METHOD_PO);
            userItem.setPropertyValue(propMgr.getAutoLoginPropertyName(), Boolean.TRUE);
            userItem.setPropertyValue(propMgr.getLocalePropertyName(), DEFAULT_lOCALE_EN_US);
            userItem.setPropertyValue(propMgr.getTestAccountPropertyName(), registerInput.getAtgRestValue().getTestAccount() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getDropShipmentPropertyName(), registerInput.getAtgRestValue().getDropShipment() == 0 ? false : true);
            userItem.setPropertyValue(propMgr.getIncludePunchoutShippingPropertyName(), registerInput.getAtgRestValue().getIncludePunchoutShipping() == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getIncludePunchoutTaxesPropertyName(), registerInput.getAtgRestValue().getIncludePunchoutTaxes() == 1 ? true : false);
            userItem.setPropertyValue(ADVANCE_SHIPDISABLE, registerInput.getAtgRestValue().getAdvanceShippingDisabled() == 1 ? true : false);
            // userItem.setPropertyValue(propMgr.getAccessLibrayOptInPropertyName(),idmUserInputBean.getAccesLibraryOptIn()
            // == 1 ? true : false);
            userItem.setPropertyValue(propMgr.getPartnerNamePropertyName(), registerInput.getAtgRestValue().getPartnerName());
            userItem.setPropertyValue(propMgr.getPartnerIdentifierrPropertyName(), registerInput.getAtgRestValue().getPartnerIdentifier());
            userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), registerInput.getAtgRestValue().getPunchoutMember());
            userItem.setPropertyValue(propMgr.getShippAddTypeProppertyName(), registerInput.getAtgRestValue().getDefaultShipAddressType());
            userItem.setPropertyValue(propMgr.getDefaultSAPBillToAddressPropertyName(), registerInput.getAtgRestValue().getSapBillToAddress());
            userItem.setPropertyValue(propMgr.getDefaultSAPShipToAddressPropertyName(), registerInput.getAtgRestValue().getSapShipToAddress());
            userItem.setPropertyValue(propMgr.getPunchoutMemberPropertyName(), registerInput.getAtgRestValue().getPunchoutMember());
            userItem.setPropertyValue(propMgr.getTaxExemptedNumPropertyName(), registerInput.getAtgRestValue().getTaxExemptNumber());
            userItem.setPropertyValue(propMgr.getTaxExemptCertPropertyName(), registerInput.getAtgRestValue().getTaxExemptCertificatePath());
            userItem.setPropertyValue(propMgr.getTaxExemptedPropertyName(), registerInput.getAtgRestValue().getTaxExempt() == 1 ? true : false);
            userItem.setPropertyValue(B2BUSER, registerInput.getAtgRestValue().getB2bUser() == 1 ? true : false);
            userItem.setPropertyValue(GROUP_ID, registerInput.getAtgRestValue().getB2bGroupId());

            if (!StringUtils.isBlank(registerInput.getAtgRestValue().getFedexCollectNumber())) {
                userItem.setPropertyValue(propMgr.getFedexUpsCollectNumber(), registerInput.getAtgRestValue().getFedexCollectNumber());
            }

            if (!StringUtils.isBlank(registerInput.getAtgRestValue().getUpsCollectNumber())) {
                userItem.setPropertyValue(propMgr.getUPSCollectNumber(), registerInput.getAtgRestValue().getUpsCollectNumber());
            }

            userItem.setPropertyValue(Constants.PROP_BILLING_ADDRESS, createBillContactInfo(registerInput));
            userItem.setPropertyValue(Constants.PROP_SHIPPING_ADDRESS, createShipContactInfo(registerInput));
            createSecondaryAddress(userItem);

            String salesOrg = DEFAULT_SALES_ORG;
            if (this.getCountrySalesOrgProfilePropertySetter() != null && registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry() != null) {
                salesOrg = this.getCountrySalesOrgProfilePropertySetter().getSalesOrg(registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry());
                if (salesOrg == null) {
                    salesOrg = DEFAULT_SALES_ORG;
                    vlogDebug("Cannot retrieve SAP Sales Org for country :" + registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry());
                }

                userItem.setPropertyValue(propMgr.getSapSalesOrgPropertyName(), salesOrg);
                userItem.setPropertyValue(propMgr.getUserCountryPropertyName(), registerInput.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry());

            }

            // Invoice details insert

            userItem.setPropertyValue(CUSTOMER_NAME1, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceCustomerName());
            userItem.setPropertyValue(COMPANY_TAX_CODE1, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceCompanyTaxCode());
            userItem.setPropertyValue(ADDRESS1, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceAddress());
            userItem.setPropertyValue(BANK_NAME1, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceBankName());
            userItem.setPropertyValue(BANK_ACCOUNT1, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceBankAccount());
            userItem.setPropertyValue(CUSTOMER_NAME2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipCustomerName());
            userItem.setPropertyValue(CITY2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipCity());
            userItem.setPropertyValue(SHIPPING_ADDRESS2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipShippingAddress());
            userItem.setPropertyValue(POST_CODE2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipPostCode());
            userItem.setPropertyValue(CONTACTOR_NAME2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipContactPerson());
            userItem.setPropertyValue(CONTACTOR_PHNUM2, registerInput.getAtgRestValue().getInvoice().getAtgRestValue().getInvoiceShipContactPhoneNumber());
        }
        if (isLoggingDebug()) {
            vlogDebug("BillContactInfo Items {0}", userItem);
        }
        getProfileTools().getProfileRepository().addItem(userItem);
        encryptedNewPassword = clearVariables();
    }
    /**
     * This method is used for creating the billing address in ATG
     * 
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createBillContactInfo(RegisterInfoInput bean) throws RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createBillContactInfo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
        if (bean != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getAtgRestValue().getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getAtgRestValue().getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getAtgRestValue().getCompanyName());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getAddress1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getAddress2());
            item.setPropertyValue(propMgr.getCityPropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getCity());
            item.setPropertyValue(propMgr.getStatePropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getState());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getPostalCode());
            item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getAtgRestValue().getPhoneNumber());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getAtgRestValue().getExtension());
        }
        if (isLoggingDebug()) {
            vlogDebug("BillContactInfo Items {0}", item);
        }
        return item;
    }

    /**
     * This method is used for creating Shipping Address information in ATG
     * 
     * @param bean
     * @return
     * @throws RepositoryException
     */
    public RepositoryItem createShipContactInfo(RegisterInfoInput bean) throws RepositoryException {
        if (isLoggingDebug()) {
            vlogDebug("Enteroing into createShipContactInfo");
        }
        AgilentPropertyManager propMgr = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        MutableRepositoryItem item = getProfileTools().getProfileRepository().createItem(Constants.ITEM_CONTACT_INTO);
        if (bean != null) {
            item.setPropertyValue(propMgr.getFirstNamePropertyName(), bean.getAtgRestValue().getFirstName());
            item.setPropertyValue(propMgr.getLastNamePropertyName(), bean.getAtgRestValue().getLastName());
            item.setPropertyValue(propMgr.getCompanyPropertyName(), bean.getAtgRestValue().getCompanyName());
            item.setPropertyValue(propMgr.getAddress1PropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getAddress1());
            item.setPropertyValue(propMgr.getAddress2PropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getAddress2());
            item.setPropertyValue(propMgr.getCityPropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getCity());
            item.setPropertyValue(propMgr.getStatePropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getState());
            item.setPropertyValue(propMgr.getPostalCodePropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getPostalCode());
            item.setPropertyValue(propMgr.getCountryPropertyName(), bean.getAtgRestValue().getShippingAddress().getAtgRestValue().getCountry());
            item.setPropertyValue(propMgr.getPhoneNumberPropertyName(), bean.getAtgRestValue().getPhoneNumber());
            item.setPropertyValue(propMgr.getExtensionPropertyName(), bean.getAtgRestValue().getExtension());
        }
        if (isLoggingDebug()) {
            vlogDebug("BillContactInfo Items {0}", item);
        }
        return item;
    }
    
    /**
     * This method is for setting default values for the created profile and for sending email pot registration
     * 
     * @param pProfile
     * @param eCommerceEnabled
     */
    public void postUserRegistration(Profile pProfile, boolean eCommerceEnabled,String userLocale,String fileUploadId) {
    	vlogDebug("::::  Entering to the AgilentUserOKTAHelper.postUserRegistration ::::");
        AgilentPropertyManager propertyManager = (AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager();
        getRegEmailTemplateInfo().setMessageSubject(getRegMessageSubject());
        String userBillingCountry = null;
        if (eCommerceEnabled) {
            MutableRepositoryItem billingAddrItem = (MutableRepositoryItem) pProfile.getPropertyValue(Constants.PROP_BILLING_ADDRESS);
            userBillingCountry = (String) billingAddrItem.getPropertyValue(Constants.PROP_COUNTRY);
            userBillingCountry = StringUtils.isEmpty(userBillingCountry) ? "US" : userBillingCountry.trim();
            pProfile.setPropertyValue(Constants.USER_COUNTRY, userBillingCountry);
            // Setting default Shipping method if profile does not have any default shipping method
            String shippingMethod = Constants.STANDARDSHIPPING;
            RepositoryItem countryItem = getCountryUtils().getComRegionForCountry(userBillingCountry);
            if (countryItem != null) {
                RepositoryItem salesregionitem = (RepositoryItem) countryItem.getPropertyValue(Constants.SALESREGIONPROPERTY);
                if (salesregionitem != null) {
                    String configshippingMethod = getSalesRegionDefaultShipMethod().get(salesregionitem.getRepositoryId());
                    if (!StringUtils.isEmpty(configshippingMethod)) {
                        shippingMethod = configshippingMethod;
                    }
                }
            }
            pProfile.setPropertyValue(Constants.PROP_DEFAULTSHIPPINGMETHOD, shippingMethod);
        } else {
            String userCountry = (String) pProfile.getPropertyValue(Constants.USER_COUNTRY);
            userBillingCountry = StringUtils.isEmpty(userCountry) ? "US" : userCountry.trim();
        }
        String profilePayMethod = (String) pProfile
                .getPropertyValue(((AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager()).getDefaultPaymentMethodPropertyName());

        if (StringUtils.isEmpty(profilePayMethod) || profilePayMethod.equalsIgnoreCase(com.agilent.base.commerce.Constants.CYBERSOURCEPAYMENTMETHOD)
                && !getValidCreditCardCountryList().contains(userBillingCountry)) {
            pProfile.setPropertyValue(((AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager()).getDefaultPaymentMethodPropertyName(),
                    com.agilent.base.commerce.Constants.PURCHASEORDERPAYMENTMETHOD);
        }

        // This will put a flag to get to know either this user is new or not
        // getSessionBean().getValues().put(SessionBean.NEW_USER, SessionBean.NEW_USER);
         setRegionSubjectQuotes(pProfile);

      
        if (userLocale != null && userLocale.equals(CHINA_LOCALE)) {
            ResourceBundle bundle = ResourceBundle.getBundle("com.agilent.email.LabelResources", RequestLocale.getCachedLocale((String) userLocale));
            String message = bundle.getString("register.user.subject");
            getRegEmailTemplateInfo().setMessageSubject(message);
        }
        List<String> recipentsList = new ArrayList<String>();
        if (pProfile.getPropertyValue(Constants.PROP_EMAIL) != null) {
            recipentsList.add(pProfile.getPropertyValue(Constants.PROP_EMAIL).toString());
        }

      
        if (StringUtils.isNotBlank(fileUploadId)) {
            File[] userUpFiles = getFileUploadController().fetchUserUploadedFiles(fileUploadId);
            if (userUpFiles != null) {
                getRegEmailTemplateInfo().setMessageAttachments(userUpFiles);
            }
        } else {
            getRegEmailTemplateInfo().setMessageAttachments(null);
        }
        getRegEmailTemplateInfo().setTemplateParameters(getUserRegistrationTemplateParam(pProfile, userLocale));
        try {
            getEmailTools().getEmailSender().sendEmailMessage(getRegEmailTemplateInfo(), recipentsList, true, Boolean.FALSE);

            // Sending mail to CSR
            Map tempParams = collectCsrEmailParams(pProfile, eCommerceEnabled);
            File[] csrFiles = null;
            if (StringUtils.isNotBlank(fileUploadId)) {
                csrFiles = getFileUploadController().fetchUserUploadedFiles("_" +fileUploadId);
            }
            getEmailTools().registerCsrMailRegWithFiles(tempParams, csrFiles);
        } catch (TemplateEmailException e) {
            vlogError("Template Exception", e);
        }

        pProfile.setPropertyValue(propertyManager.getMossDownWhenRegisterPropertyName(), Boolean.TRUE);
        vlogDebug("::::  Existing from the AgilentUserOKTAHelper.postUserRegistration ::::");
    }

    /**
     * This method is for setting the region level quotes for the profile
     * @param pProfile
     */
    public void setRegionSubjectQuotes(Profile pProfile) {

        String region = "";
        String regionSubject = "";
        RepositoryItem[] countries = getCountryUtils().getCountryItems((String) pProfile.getPropertyValue(Constants.USER_COUNTRY));
        if (countries != null && countries.length > 0) {
            RepositoryItem regionItem = (RepositoryItem) countries[0].getPropertyValue("regionId");
            if (regionItem != null) {
                region = (String) regionItem.getPropertyValue("regionName");
            }
        }

        if (region.equalsIgnoreCase("Europe") || region.equalsIgnoreCase("Middle East") || region.equalsIgnoreCase("Africa") || region.equalsIgnoreCase("India")) {
            regionSubject = getEmailTools().getRegisterEMEAICampaign();
        } else if (region.equalsIgnoreCase("SAPK") || region.equalsIgnoreCase("Asia-Pacific")) {
            regionSubject = getEmailTools().getRegisterSAPKCampaign();
        } else if (region.equalsIgnoreCase("Americas")) {
            regionSubject = getEmailTools().getRegisterAFOCampaign();
        } else if (region.equalsIgnoreCase("China")) {
            regionSubject = getEmailTools().getRegisterCHINACampaign();
        } else if (region.equalsIgnoreCase("Japan")) {
            regionSubject = getEmailTools().getRegisterJAPANCampaign();
        } else {
            regionSubject = getEmailTools().getRegisterAFOCampaign();
        }

        String mesageSubject = getRegEmailTemplateInfo().getMessageSubject();
        if (StringUtils.isEmpty(regionSubject)) {
            getRegEmailTemplateInfo().setMessageSubject(mesageSubject);
        } else {
            getRegEmailTemplateInfo().setMessageSubject(regionSubject + " : " + mesageSubject);
        }
    }

    /**
     * This is for setting the values needed for sending emails post registration
     * 
     * @param pProfile
     * @return
     */
    private Map<String, String> getUserRegistrationTemplateParam(Profile pProfile, String locale) {
        AgilentPropertyManager propManager = (AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager();
        RepositoryItem shippingAddress = (RepositoryItem) pProfile.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
        RepositoryItem billingAddress = (RepositoryItem) pProfile.getPropertyValue(Constants.PROP_BILLING_ADDRESS);
        Map<String, String> param = new HashMap<String, String>();
        if (isLoggingDebug()) {
            vlogDebug("shippingAddress: {0} billingAddress: {1}", shippingAddress, billingAddress);
        }
        if (propManager != null) {
            param.put(Constants.PROP_FIRST_NAME, (String) pProfile.getPropertyValue(propManager.getFirstNamePropertyName()));
            param.put(Constants.PROP_LAST_NAME, (String) pProfile.getPropertyValue(propManager.getLastNamePropertyName()));
            param.put(propManager.getAdLoginNamePropertyName(), (String) pProfile.getPropertyValue(propManager.getAdLoginNamePropertyName()));
            param.put(Constants.PROP_LOGIN, (String) pProfile.getPropertyValue(propManager.getLoginPropertyName()));
            param.put(Constants.PROP_EMAIL, (String) pProfile.getPropertyValue(propManager.getEmailAddressPropertyName()));
            if (shippingAddress != null) {
                param.put(Constants.SHIPPING_CITY, (String) shippingAddress.getPropertyValue(propManager.getCityPropertyName()));
                param.put(Constants.SHIPPING_STATE, (String) shippingAddress.getPropertyValue(propManager.getStatePropertyName()));
                param.put(Constants.SHIPPING_POSTALCODE, (String) shippingAddress.getPropertyValue(propManager.getPostalCodePropertyName()));
                param.put(Constants.SHIPPING_ADDRESS1, (String) shippingAddress.getPropertyValue(propManager.getAddress1PropertyName()));
                param.put(Constants.SHIPPING_ADDRESS2, (String) shippingAddress.getPropertyValue(propManager.getAddress2PropertyName()));
                param.put(Constants.SHIPPING_ADDRESS3, (String) shippingAddress.getPropertyValue(propManager.getAddress3PropertyName()));
                param.put(Constants.SHIPPING_COMPANY, (String) shippingAddress.getPropertyValue(propManager.getCompanyPropertyName()));
                param.put(Constants.BILLING_COUNTRY, (String) shippingAddress.getPropertyValue(propManager.getCountryPropertyName()));
            }
            if (billingAddress != null) {
                param.put(Constants.BILLING_PHONENUMBER, (String) billingAddress.getPropertyValue(propManager.getPhoneNumberPropertyName()));
            }
        }
        /* Added for CR APP-3755 China Direct Customers */
        param.put("requestLocale", locale);
        return param;
    }

    /**
     * This method is for setting params necessage for sending csr emails
     * @param pProfile
     * @return
     */
    protected Map collectCsrEmailParams(Profile pProfile, boolean eCommerceEnabled) {
        Map<String,Object> tempParams = new HashMap<String,Object>();
        AgilentPropertyManager propManager = (AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager();
        MutableRepositoryItem billingAddrItem = (MutableRepositoryItem) pProfile.getPropertyValue(Constants.PROP_BILLING_ADDRESS);
        RepositoryItem shippingAddress = (RepositoryItem) pProfile.getPropertyValue(Constants.PROP_SHIPPING_ADDRESS);
        String usershippingCountry = "";
        if (shippingAddress != null) {
            usershippingCountry = (String) shippingAddress.getPropertyValue(Constants.PROP_COUNTRY);
        } else if (billingAddrItem != null) {
            usershippingCountry = (String) billingAddrItem.getPropertyValue(Constants.PROP_COUNTRY);
        } else {
            usershippingCountry = (String) pProfile.getPropertyValue(propManager.getUserCountryPropertyName());
        }
        vlogDebug("Inside collectCsrEmailParams {0}", usershippingCountry);
        RepositoryItem[] countries = getCountryUtils().getCountryItems(usershippingCountry);
        String countryName = null;
        boolean placeOnlineOrder = false;
        if (eCommerceEnabled) {
            placeOnlineOrder = true;
        }

        String siteId = SiteContextManager.getCurrentSiteId();
        if (countries != null && countries.length > 0) {
            countryName = (String) countries[0].getPropertyValue(Constants.COUNTRY_NAME);
            if (placeOnlineOrder || !(getEmailDisabledSite() != null && siteId != null && getEmailDisabledSite().contains(siteId))) {
                String csrEmail = (String) countries[0].getPropertyValue(PROP_ECOMMCSREMAIL);
                if (!StringUtils.isEmpty(csrEmail)) {
                    csrEmail = csrEmail.replaceAll(";|,", ",");
                    tempParams.put("csrmail", csrEmail);
                }
            } else {
                String csrEmail = (String) getDefaultRegEmailGroup().get(siteId);
                if (!StringUtils.isEmpty(csrEmail)) {
                    csrEmail = csrEmail.replaceAll(";|,", ",");
                    tempParams.put("csrmail", csrEmail);
                }
            }
        }
        String loginame = (String) pProfile.getPropertyValue(propManager.getAdLoginNamePropertyName());
        tempParams.put(Constants.PROP_LOGIN, loginame);
        tempParams.put(Constants.PROP_COUNTRY, countryName);
        tempParams.put(Constants.PROP_FIRST_NAME, pProfile.getPropertyValue(propManager.getFirstNamePropertyName()));
        tempParams.put(Constants.PROP_LAST_NAME, pProfile.getPropertyValue(propManager.getLastNamePropertyName()));
        tempParams.put(Constants.PROP_EMAIL, pProfile.getPropertyValue(propManager.getEmailAddressPropertyName()));
        String salesOrg = (String) pProfile.getPropertyValue(propManager.getSapSalesOrgPropertyName());
        if (StringUtils.isEmpty(salesOrg)) {
            salesOrg = " ";
        }
        
        tempParams.put(Constants.PROP_SALES_ORG, salesOrg);
        tempParams.put(Constants.REGISTER_MAIL_FROM, getRegisterCsrEmailFrom());
        vlogDebug("Sales Org {0}", salesOrg);
        vlogDebug("Register CSR Email From {0}", getRegisterCsrEmailFrom());
        if (shippingAddress != null) {
            shippingAddressCSR(shippingAddress, tempParams, pProfile);
        }

        if (placeOnlineOrder && billingAddrItem != null) {
            billingAddressCSR(billingAddrItem, tempParams, pProfile);
        }
        else{
            vlogDebug(":::: AgilentUserOKTAHelper placeOnlineOrder {0}",placeOnlineOrder);
        }
        tempParams.put(Constants.REGISTRATION_PLACE_ONLINE_ORDER, placeOnlineOrder);
        // added to disable campaign in subject for LSCA
        tempParams.put(Constants.INCLUDEECAMPAIGN, true);

        // Checking for opted option
        String isReceiveEmail = (String) pProfile.getPropertyValue(propManager.getReceiveEmailPropertyName());
        String optedOption = "";
        if (isReceiveEmail != null) {
            if (isReceiveEmail != null) {
                if (isReceiveEmail.equalsIgnoreCase("yes")) {
                    optedOption = Constants.OPTED_OPTION_YES;
                } else {
                    optedOption = Constants.OPTED_OPTION_NO;
                }
            }
        }
        tempParams.put(Constants.PROP_OPTED_OPTION, optedOption);
        return tempParams;
    }

    /**
     * This method is used for setting the shipping address details for sending csr emails
     * 
     * @param shippingAddress
     * @param tempParams
     * @param pProfile
     */
    private void shippingAddressCSR(RepositoryItem shippingAddress, Map tempParams, Profile pProfile) {
    	vlogDebug("::::  Entering to the AgilentUserOKTAHelper.shippingAddressCSR ::::");
    	if(null != shippingAddress && null != pProfile) {
    		AgilentPropertyManager propManager = (AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager();
    		String address2 = (String) shippingAddress.getPropertyValue(propManager.getAddress2PropertyName());
            if (address2 == null) {
                tempParams.put(Constants.SHIPPING_ADDRESS2, " ");
                tempParams.put(Constants.SHIPPING_ADDRESS3, " ");
            } else {
                tempParams.put(Constants.SHIPPING_ADDRESS2, shippingAddress.getPropertyValue(propManager.getAddress2PropertyName()));
                String address3 = (String) shippingAddress.getPropertyValue(propManager.getAddress3PropertyName());
                if (StringUtils.isEmpty(address3)) {
                    address3 = " ";
                }
                tempParams.put(Constants.SHIPPING_ADDRESS3, address3);
            }
            String State = (String) shippingAddress.getPropertyValue(propManager.getStatePropertyName());
            if (State == null) {
                tempParams.put(Constants.SHIPPING_STATE, " ");
            } else {
                tempParams.put(Constants.SHIPPING_STATE, shippingAddress.getPropertyValue(propManager.getStatePropertyName()));
            }

            String phoneNum = ((String) shippingAddress.getPropertyValue(propManager.getPhoneNumberPropertyName()));
            if (StringUtils.isEmpty(phoneNum)) {
                phoneNum = " ";
            }
            tempParams.put(Constants.SHIPPING_PHONENUMBER, phoneNum);
            tempParams.put(Constants.SHIPPING_COMPANY,
                    shippingAddress.getPropertyValue(propManager.getCompanyPropertyName()) != null ? shippingAddress.getPropertyValue(propManager.getCompanyPropertyName()) : "");
            tempParams.put(Constants.SHIPPING_ADDRESS1,
                    (shippingAddress.getPropertyValue(propManager.getAddress1PropertyName()) != null ? shippingAddress.getPropertyValue(propManager.getAddress1PropertyName()) : ""));
            tempParams.put(Constants.SHIPPING_CITY,
                    (shippingAddress.getPropertyValue(propManager.getCityPropertyName()) != null ? shippingAddress.getPropertyValue(propManager.getCityPropertyName()) : ""));
            String postalcode = (String) shippingAddress.getPropertyValue(propManager.getPostalCodePropertyName());
            if (StringUtils.isEmpty(postalcode)) {
                postalcode = " ";
            }
            tempParams.put(Constants.SHIPPING_POSTALCODE, postalcode);
    	}else {
    		 vlogDebug(":::: AgilentUserOKTAHelper.shippingAddressCSR :::: shippingAddress/Profile is null");
    	}
        vlogDebug("::::  Existing from the AgilentUserOKTAHelper.shippingAddressCSR ::::");
    }

    /**
     * This method is for setting the billing address details for sending csr emails
     * 
     * @param billingAddress
     * @param tempParams
     * @param pProfile
     */
    private void billingAddressCSR(MutableRepositoryItem billingAddress, Map tempParams, Profile pProfile) {
        AgilentPropertyManager propManager = (AgilentPropertyManager) pProfile.getProfileTools().getPropertyManager();

        String address2 = (String) billingAddress.getPropertyValue(propManager.getAddress2PropertyName());
        if (address2 == null) {
            tempParams.put(Constants.BILLING_ADDRESS2, " ");
            tempParams.put(Constants.BILLING_ADDRESS3, " ");
        } else {
            tempParams.put(Constants.BILLING_ADDRESS2, billingAddress.getPropertyValue(propManager.getAddress2PropertyName()));
            String address3 = (String) billingAddress.getPropertyValue(propManager.getAddress3PropertyName());
            if (StringUtils.isEmpty(address3)) {
                address3 = " ";
            }
            tempParams.put(Constants.BILLING_ADDRESS3, address3);
        }
        String State = (String) billingAddress.getPropertyValue(propManager.getStatePropertyName());
        if (State == null) {
            tempParams.put(Constants.BILLING_STATE, " ");
        } else {
            tempParams.put(Constants.BILLING_STATE, billingAddress.getPropertyValue(propManager.getStatePropertyName()));
        }

        String phoneNum = ((String) billingAddress.getPropertyValue(propManager.getPhoneNumberPropertyName()));
        if (StringUtils.isEmpty(phoneNum)) {
            phoneNum = " ";
        }
        tempParams.put(Constants.BILLING_PHONENUMBER, phoneNum);
        tempParams.put(Constants.BILLING_COMPANY, billingAddress.getPropertyValue(propManager.getCompanyPropertyName()));
        tempParams.put(Constants.BILLING_ADDRESS1, billingAddress.getPropertyValue(propManager.getAddress1PropertyName()));
        tempParams.put(Constants.BILLING_CITY, billingAddress.getPropertyValue(propManager.getCityPropertyName()));
        String postalcode = (String) billingAddress.getPropertyValue(propManager.getPostalCodePropertyName());
        if (StringUtils.isEmpty(postalcode)) {
            postalcode = " ";
        }
        tempParams.put(Constants.BILLING_POSTALCODE, postalcode);
        vlogDebug(":::: AgilentUserOKTAHelper billingAddressCSR is set");
    }
    
    /**
     * This method is for validating billing address and shipping address
     * 
     * @param isPlaceOnlineOrder
     */
    public boolean lscaValidateBillingShippingAddress(boolean isPlaceOnlineOrder, RegisterInfoInput registerUserInputBean) {
        boolean addressValidateSuccess = true;
        AgilentPropertyManager propManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
        validateAddress(Constants.PROP_SHIPPING_ADDRESS, Constants.POSTAL_CODE_TYPE_SHIP, registerUserInputBean);

        if (!isPlaceOnlineOrder) {
            registerUserInputBean.getAtgRestValue().setBillingAddress(registerUserInputBean.getAtgRestValue().getShippingAddress());
            // getValue().put(propManager.getDefaultPaymentMethodPropertyName(),Constants.PAY_METHOD_PO);
        } else {
            validateAddress(Constants.PROP_BILLING_ADDRESS, Constants.POSTAL_CODE_TYPE_BILL, registerUserInputBean);
            if (!registerUserInputBean.getAtgRestValue().getShippingAddress().getAtgRestValue().getCountry()
                    .equalsIgnoreCase(registerUserInputBean.getAtgRestValue().getBillingAddress().getAtgRestValue().getCountry())) {
                addressValidateSuccess = false;
            }
        }
        return addressValidateSuccess;
    }

    
    /**
     * This method is for validating the address eneter by user in the registration page
     * 
     * @param addType
     * @param postalCodeType
     * @param registerUserInputBean
     */
    protected void validateAddress(String addType, String postalCodeType, RegisterInfoInput registerUserInputBean) {
        List<String> mInnerKeyList = new ArrayList<String>();
    	vlogDebug("::::  Entering to the AgilentUserOKTAHelper.validateAddress ::::");
        ValidationExceptions validationExceptions = new ValidationExceptions();
        try {
            AgilentPropertyManager propManager = (AgilentPropertyManager) getProfileTools().getPropertyManager();
            String postalCode = null;
            String salesOrg = null;
            String twoLetterContCode = null;
            if (addType.equalsIgnoreCase(Constants.PROP_SHIPPING_ADDRESS)) {
                postalCode = registerUserInputBean.getAtgRestValue().getShippingAddress().getAtgRestValue().getPostalCode();
                twoLetterContCode = registerUserInputBean.getAtgRestValue().getShippingAddress().getAtgRestValue().getCountry();
            } else {
                postalCode = registerUserInputBean.getAtgRestValue().getBillingAddress().getAtgRestValue().getPostalCode();
            }
            if (!getCountriesListwithoutPC().contains(twoLetterContCode) && StringUtils.isEmpty(postalCode)) {
                validationExceptions.addValidationError(IErrorId.PROP_REQUIRED, new String[]
                    {"pcode.type.bill".equalsIgnoreCase(postalCodeType) ? Constants.BILLING_ZIPNDPOSTAL : Constants.SHIPPING_ZIPNDPOSTAL}, new Object[]
                    {});
            }
            if (!StringUtils.isEmpty(twoLetterContCode)) {
                salesOrg = getCountryUtils().getSalesOrgForCountry(twoLetterContCode).toUpperCase();
                if (postalCode != null && !StringUtils.isEmpty(postalCode)) {
                    ValidatorUtil.validatePostalCode("04" + twoLetterContCode, postalCode, postalCodeType, validationExceptions);
                }
            }
        } catch (RepositoryException exception) {
            vlogError(exception, "RepositoryException exception got in AgilentProfileFormHandler.preCreateUser");
        }
        if (validationExceptions.hasValidationErrors()) {
            /* START: Added code for Google Analytics */
            List<com.agilent.base.platform.ValidationError> validatetionErrors = validationExceptions.getValidationErrors();
            for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                for (String keyList : validationError.getKeyContext()) {
                    mInnerKeyList.add(keyList);
                }
            }
            /* END: Added code for Google Analytics */
        }
        vlogDebug("::::  Entering to the AgilentUserOKTAHelper.validateAddress ::::");
    }    
    
    /**
     * This method is used to check whether country selected by user is eCommerce Enable dor not
     * 
     * @param userCountry
     * @return
     */
    public boolean computeEcommerceEnabledCountry(String userCountry) {
        boolean eCommerceEnabled = false;
        if (userCountry != null && getEnabledCountryList() != null) {
            if (getEnabledCountryList().contains(userCountry)) {
                eCommerceEnabled = true;
            } else {
                eCommerceEnabled = false;
            }
        }
        return eCommerceEnabled;
    }
    
    /**
     * Gets the value of property mRegEmailTemplateInfo
     *
     * @return the value of property mRegEmailTemplateInfo
     */
    public TemplateEmailInfoImpl getRegEmailTemplateInfo() {
        return mRegEmailTemplateInfo;
    }

    /**
     * Sets the value of property mRegEmailTemplateInfo with value mRegEmailTemplateInfo
     *
     * @param mRegEmailTemplateInfo
     *            for setting property mRegEmailTemplateInfo
     */
    public void setRegEmailTemplateInfo(TemplateEmailInfoImpl mRegEmailTemplateInfo) {
        this.mRegEmailTemplateInfo = mRegEmailTemplateInfo;
    }

    /**
     * Gets the value of property mCountriesListwithoutPC
     *
     * @return the value of property mCountriesListwithoutPC
     */
    public List<String> getCountriesListwithoutPC() {
        return mCountriesListwithoutPC;
    }

    /**
     * Sets the value of property mCountriesListwithoutPC with value mCountriesListwithoutPC
     *
     * @param mCountriesListwithoutPC
     *            for setting property mCountriesListwithoutPC
     */
    public void setCountriesListwithoutPC(List<String> mCountriesListwithoutPC) {
        this.mCountriesListwithoutPC = mCountriesListwithoutPC;
    }

    /**
     * Gets the value of property mCountryUtils
     *
     * @return the value of property mCountryUtils
     */
    public CountryUtils getCountryUtils() {
        return mCountryUtils;
    }

    /**
     * Sets the value of property mCountryUtils with value mCountryUtils
     *
     * @param mCountryUtils
     *            for setting property mCountryUtils
     */
    public void setCountryUtils(CountryUtils mCountryUtils) {
        this.mCountryUtils = mCountryUtils;
    }

    /**
     * Gets the value of property mSalesRegionDefaultShipMethod
     *
     * @return the value of property mSalesRegionDefaultShipMethod
     */
    public Map<String, String> getSalesRegionDefaultShipMethod() {
        return mSalesRegionDefaultShipMethod;
    }

    /**
     * Sets the value of property mSalesRegionDefaultShipMethod with value mSalesRegionDefaultShipMethod
     *
     * @param mSalesRegionDefaultShipMethod
     *            for setting property mSalesRegionDefaultShipMethod
     */
    public void setSalesRegionDefaultShipMethod(Map<String, String> mSalesRegionDefaultShipMethod) {
        this.mSalesRegionDefaultShipMethod = mSalesRegionDefaultShipMethod;
    }

    /**
     * Gets the value of property mValidCreditCardCountryList
     *
     * @return the value of property mValidCreditCardCountryList
     */
    public List<String> getValidCreditCardCountryList() {
        return mValidCreditCardCountryList;
    }

    /**
     * Sets the value of property mValidCreditCardCountryList with value mValidCreditCardCountryList
     *
     * @param mValidCreditCardCountryList
     *            for setting property mValidCreditCardCountryList
     */
    public void setValidCreditCardCountryList(List<String> mValidCreditCardCountryList) {
        this.mValidCreditCardCountryList = mValidCreditCardCountryList;
    }



    /**
     * Gets the value of property mFileUploadController
     *
     * @return the value of property mFileUploadController
     */
    public FileUploadComponent getFileUploadController() {
        return mFileUploadController;
    }

    /**
     * Sets the value of property mFileUploadController with value mFileUploadController
     *
     * @param mFileUploadController
     *            for setting property mFileUploadController
     */
    public void setFileUploadController(FileUploadComponent mFileUploadController) {
        this.mFileUploadController = mFileUploadController;
    }

    /**
     * Gets the value of property mEmailDisabledSite
     *
     * @return the value of property mEmailDisabledSite
     */
    public List<String> getEmailDisabledSite() {
        return mEmailDisabledSite;
    }

    /**
     * Sets the value of property mEmailDisabledSite with value mEmailDisabledSite
     *
     * @param mEmailDisabledSite
     *            for setting property mEmailDisabledSite
     */
    public void setEmailDisabledSite(List<String> mEmailDisabledSite) {
        this.mEmailDisabledSite = mEmailDisabledSite;
    }

    /**
     * Gets the value of property mDefaultRegEmailGroup
     *
     * @return the value of property mDefaultRegEmailGroup
     */
    public Map<String, String> getDefaultRegEmailGroup() {
        return mDefaultRegEmailGroup;
    }

    /**
     * Sets the value of property mDefaultRegEmailGroup with value mDefaultRegEmailGroup
     *
     * @param mDefaultRegEmailGroup
     *            for setting property mDefaultRegEmailGroup
     */
    public void setDefaultRegEmailGroup(Map<String, String> mDefaultRegEmailGroup) {
        this.mDefaultRegEmailGroup = mDefaultRegEmailGroup;
    }

    /**
     * Gets the value of property mRegisterCsrEmailFrom
     *
     * @return the value of property mRegisterCsrEmailFrom
     */
    public String getRegisterCsrEmailFrom() {
        return mRegisterCsrEmailFrom;
    }

    /**
     * Sets the value of property mRegisterCsrEmailFrom with value mRegisterCsrEmailFrom
     *
     * @param mRegisterCsrEmailFrom
     *            for setting property mRegisterCsrEmailFrom
     */
    public void setRegisterCsrEmailFrom(String mRegisterCsrEmailFrom) {
        this.mRegisterCsrEmailFrom = mRegisterCsrEmailFrom;
    }

    /**
     * Gets the value of property mPeriodicEmail
     *
     * @return the value of property mPeriodicEmail
     */
    public boolean isPeriodicEmail() {
        return mPeriodicEmail;
    }

    /**
     * Sets the value of property mPeriodicEmail with value mPeriodicEmail
     *
     * @param mPeriodicEmail
     *            for setting property mPeriodicEmail
     */
    public void setPeriodicEmail(boolean mPeriodicEmail) {
        this.mPeriodicEmail = mPeriodicEmail;
    }

    /**
     * Gets the value of property mEmailTools
     *
     * @return the value of property mEmailTools
     */
    public AgilentEmailTools getEmailTools() {
        return mEmailTools;
    }

    /**
     * Sets the value of property mEmailTools with value mEmailTools
     *
     * @param mEmailTools
     *            for setting property mEmailTools
     */
    public void setEmailTools(AgilentEmailTools mEmailTools) {
        this.mEmailTools = mEmailTools;
    }

    /**
     * Gets the value of property mEnabledCountryList
     *
     * @return the value of property mEnabledCountryList
     */
    public List<String> getEnabledCountryList() {
        return mEnabledCountryList;
    }

    /**
     * Sets the value of property mEnabledCountryList with value mEnabledCountryList
     *
     * @param mEnabledCountryList
     *            for setting property mEnabledCountryList
     */
    public void setEnabledCountryList(List<String> mEnabledCountryList) {
        this.mEnabledCountryList = mEnabledCountryList;
    }

    /**
     * Gets the value of property mRegMessageSubject
     *
     * @return the value of property mRegMessageSubject
     */
    public String getRegMessageSubject() {
        return mRegMessageSubject;
    }

    /**
     * Sets the value of property mRegMessageSubject with value mRegMessageSubject
     *
     * @param mRegMessageSubject
     *            for setting property mRegMessageSubject
     */
    public void setRegMessageSubject(String mRegMessageSubject) {
        this.mRegMessageSubject = mRegMessageSubject;
    }
    
    public AgilentProfileTools getProfileTools() {
        return profileTools;
    }

    public void setProfileTools(AgilentProfileTools profileTools) {
        this.profileTools = profileTools;
    }

    public CountrySalesOrgProfilePropertySetter getCountrySalesOrgProfilePropertySetter() {
        return countrySalesOrgProfilePropertySetter;
    }

    public void setCountrySalesOrgProfilePropertySetter(CountrySalesOrgProfilePropertySetter countrySalesOrgProfilePropertySetter) {
        this.countrySalesOrgProfilePropertySetter = countrySalesOrgProfilePropertySetter;
    }
    /**
     * @return the transactionManager
     */
    public TransactionManager getTransactionManager() {
        return mTransactionManager;
    }

    /**
     * @param pTransactionManager
     *            the transactionManager to set
     */
    public void setTransactionManager(final TransactionManager pTransactionManager) {
        mTransactionManager = pTransactionManager;
    }

	/**
	 * @return the mProgressiveRegistration
	 */
	public boolean isProgressiveRegistration() {
		return mProgressiveRegistration;
	}

	/**
	 * @param mProgressiveRegistration the mProgressiveRegistration to set
	 */
	public void setProgressiveRegistration(boolean mProgressiveRegistration) {
		this.mProgressiveRegistration = mProgressiveRegistration;
	}

    
    
}

