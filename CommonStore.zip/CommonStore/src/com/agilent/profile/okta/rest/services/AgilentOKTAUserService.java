/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.profile.okta.rest.services;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.Set;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.agilent.base.common.AgilentConfiguration;
import com.agilent.base.platform.CountryUtils;
import com.agilent.base.platform.IErrorId;
import com.agilent.base.platform.SystemException;
import com.agilent.base.platform.ValidationExceptions;
import com.agilent.base.platform.errorhandler.ErrorHandlerImpl;
import com.agilent.base.platform.util.ValidatorUtil;
import com.agilent.base.platform.validator.IValidator;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.base.rest.Constants;
import com.agilent.base.rest.okta.OktaHttpConnectionManager;
import com.agilent.base.rest.okta.vo.OktaUser;
import com.agilent.base.util.AgilentUtil;
import com.agilent.migration.profile.UserMigrationDataBean;
import com.agilent.migration.profile.UserProfileMigrationHelper;
import com.agilent.profile.idm.functions.IdmServiceConstants;
import com.agilent.profile.okta.rest.helper.AgilentUserOKTAHelper;
import com.agilent.profile.okta.rest.services.bean.ATGUserInfoBean;
import com.agilent.profile.okta.rest.services.bean.OKTAUserInputBean;
import com.agilent.profile.okta.rest.services.bean.OKTAUserOutputBean;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;

import atg.core.util.StringUtils;
import atg.nucleus.GenericService;
import atg.repository.ItemDescriptorImpl;
import atg.repository.MutableRepositoryItem;
import atg.repository.Repository;
import atg.repository.RepositoryException;
import atg.repository.RepositoryImpl;
import atg.repository.RepositoryItem;
import atg.servlet.ServletUtil;

/**
 * This is service class used to perform create, update operation related to profile.
 */
@SuppressWarnings({"rawtypes", "cast"})
public class AgilentOKTAUserService extends GenericService implements IdmServiceConstants, Constants {

    private static final String DEFAULT_LANGUAGE = "en";
    private static final String DEFAULT_COUNTRY = "US";
    private static final String BILLING_ZIPNDPOSTAL = "billing.zipndpostal";
    private static final String SHIPPING_ZIPNDPOSTAL = "shipping.zipndpostal";
    private static final String OKTA_PROFILE_STATUS = "oktaProfileStatus";
    private static final String DEACTIVE="DEACTIVE";
    private static final String ACTIVE="ACTIVE";
    private static final String INTERMEDIATE="INTERMEDIATE";

    private AgilentProfileTools profileTools = null;
    private IValidator validator;
    private ErrorHandlerImpl errorHandler;
    private CountryUtils countryUtils;
    private AgilentUserOKTAHelper agilentOKTAUserHelper;
    private String migratedRedirectURL;
    private AgilentConfiguration agilentConfiguration;
    private Repository mProfileAdapterRepository;
    private UserProfileMigrationHelper userProfileMigrationHelper = null;
    private List<String> enabledCountryList;
    private OktaHttpConnectionManager mOktaHttpConnectionManager;
    private List<String> mCountriesListwithoutPC;
    
    /**
     * This method used for adding an user in ATG via Rest Serivce
     * @return
     */
	public OKTAUserOutputBean addUser() {
		vlogDebug("::: Entering into AgilentOKTAUserService.addUser method :::");
        OKTAUserOutputBean oktaUserResponse = null;
        OKTAUserInputBean oktaUserInputBean = null;
        MutableRepositoryItem userItem = null;
        Gson gson = null;
        String oktaUserRequestString = ServletUtil.getCurrentRequest().getParameter("oktaUserRequest");
        if (StringUtils.isBlank(oktaUserRequestString)) {
            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_EMPTY");
        }
        vlogDebug("Obtained Request json for new User Creation==={0}", oktaUserRequestString);
        try {
	        gson = new Gson();
	        oktaUserInputBean = gson.fromJson(oktaUserRequestString, OKTAUserInputBean.class);
	        vlogDebug("Json to Object Conversion Output==={0}", oktaUserInputBean);
	        if (oktaUserInputBean == null) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_PARSE_ERROR");
	        }
	        if (!validPrimitiveType(oktaUserRequestString, gson)) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_HAS_INVALID_NUMERIC_VALUE");
	        }
            if (StringUtils.isBlank(oktaUserInputBean.getLogin())) {
                oktaUserInputBean.setLogin(oktaUserInputBean.getEmail());
            }
            List<String> errorMessages = inputValidationForCreate(oktaUserInputBean);
            if (!errorMessages.isEmpty()) {
                return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_DATA_VALIDATION_ERROR", errorMessages);
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getAdLoginName())) {
                RepositoryItem userItem_login = getProfileTools().getItemFromDotNetId(oktaUserInputBean.getAdLoginName());
                if (userItem_login != null) {
                    vlogInfo("login is already available in database :: AdloginName={0}", oktaUserInputBean.getAdLoginName());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "LOGIN_NAME_ALREADY_EXISTS");
                }
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getEmail())) {
                RepositoryItem userItem_email = getProfileTools().getItemFromEmail(oktaUserInputBean.getEmail());
                if (userItem_email != null) {
                    vlogInfo("login is already available in database :: email={0}", oktaUserInputBean.getEmail());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EMAIL_ALREADY_EXISTS");
                }
            }
            if (StringUtils.isNotBlank(oktaUserInputBean.getLogin())) {
                RepositoryItem userItem_login = getProfileTools().findUserByLogin(oktaUserInputBean.getLogin());
                if (userItem_login != null) {
                    vlogInfo("login is already available in database :: login={0}", oktaUserInputBean.getLogin());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "LOGIN_ALREADY_EXISTS");
                }
            }
            if(null != getProfileTools() && null != getProfileTools().getProfileRepository()) {
                userItem = getProfileTools().getProfileRepository().createItem(getProfileTools().getDefaultProfileType());
                getAgilentOKTAUserHelper().createUserInRepo(userItem, oktaUserInputBean);
                oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.SUCCESS, "USER_CREATED_SUCCESS");
                oktaUserResponse.setAtgUserId(userItem.getRepositoryId());
            }else {
            	vlogInfo("AgilentOKTAUserService.addUser getProfileTools()/getProfileTools().getProfileRepository() not initialized properly");
            	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "CLASS_NOT_INITIALIZED");
            }
        } catch (JsonSyntaxException jse) {
        	vlogError(jse, "EXPECTION_OCCURED_DURING_USER_CREATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_SYNTAX_EXCEPTION");
        } catch (JsonParseException jpe) {
        	vlogError(jpe, "EXPECTION_OCCURED_DURING_USER_CREATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_PARSE_EXCEPTION");
        } catch (Exception e) {
            oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_CREATE");
            vlogError(e, "EXPECTION_OCCURED_DURING_USER_CREATE");
        }
        gson = null;
        userItem = null;
        oktaUserInputBean = null;
        vlogDebug("::: Existing from AgilentOKTAUserService.addUser method :::");
        return oktaUserResponse;
    }
	
	/**
	 * This method will create user in ATG with limited  attributes.
	 * @return
	 */
	public OKTAUserOutputBean createUserWithLimitedAttributes() {
		vlogDebug("::::::: Entering method AgilentOKTAUserService.addUserWithLimittedAttributes ::::::::");
        OKTAUserOutputBean oktaUserResponse = null;
        MutableRepositoryItem userItem = null;
        OKTAUserInputBean oktaUserInputBean = null;
        Gson gson = null;
        String oktaUserRequestString = ServletUtil.getCurrentRequest().getParameter("oktaUserRequest");
        if (StringUtils.isBlank(oktaUserRequestString)) {
            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_EMPTY");
        }
        vlogDebug("Obtained Request json for new User Creation with Limitted attributes ==={0}", oktaUserRequestString);
        try {
	        gson = new Gson();
	        oktaUserInputBean = gson.fromJson(oktaUserRequestString, OKTAUserInputBean.class);
	        vlogDebug("Json to Object Conversion Output==={0}", oktaUserInputBean);
	        if (oktaUserInputBean == null) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_PARSE_ERROR");
	        }
	        if (!validPrimitiveType(oktaUserRequestString, gson)) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_HAS_INVALID_NUMERIC_VALUE");
	        }
            if (StringUtils.isBlank(oktaUserInputBean.getLogin())) {
                oktaUserInputBean.setLogin(oktaUserInputBean.getEmail());
            }
            List<String> errorMessages = inputValidationForOKTACreate(oktaUserInputBean);
            if (!errorMessages.isEmpty()) {
                return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_DATA_VALIDATION_ERROR", errorMessages);
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getAdLoginName())) {
                RepositoryItem userItem_login = getProfileTools().getItemFromDotNetId(oktaUserInputBean.getAdLoginName());
                if (userItem_login != null) {
                    vlogInfo("login is already available in database= AdloginName={0}", oktaUserInputBean.getAdLoginName());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "LOGIN_NAME_ALREADY_EXISTS");
                }
            }
            if (!StringUtils.isBlank(oktaUserInputBean.getEmail())) {
                RepositoryItem userItem_email = getProfileTools().getItemFromEmail(oktaUserInputBean.getEmail());
                if (userItem_email != null) {
                    vlogInfo("login is already available in database email={0}", oktaUserInputBean.getEmail());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EMAIL_ALREADY_EXISTS");
                }
            }
            if (StringUtils.isNotBlank(oktaUserInputBean.getLogin())) {
                RepositoryItem userItem_login = getProfileTools().findUserByLogin(oktaUserInputBean.getLogin());
                if (userItem_login != null) {
                    vlogInfo("login is already available in database :: login={0}", oktaUserInputBean.getLogin());
                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "LOGIN_ALREADY_EXISTS");
                }
            }
            if(null != getProfileTools() && null != getProfileTools().getProfileRepository()) {
	            userItem = getProfileTools().getProfileRepository().createItem(getProfileTools().getDefaultProfileType());
	            getAgilentOKTAUserHelper().createUserWithLimitedAttribute(userItem, oktaUserInputBean);
	            oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.SUCCESS, "USER_CREATED_SUCCESS");
	            oktaUserResponse.setAtgUserId(userItem.getRepositoryId());
            }else {
            	vlogInfo("AgilentOKTAUserService.addUser getProfileTools()/getProfileTools().getProfileRepository() not initialized properly");
            	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "CLASS_NOT_INITIALIZED");
            }
        } catch (JsonSyntaxException jse) {
        	vlogError(jse, "EXPECTION_OCCURED_DURING_USER_LIMITTED_CREATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_SYNTAX_EXCEPTION");
        } catch (JsonParseException jpe) {
        	vlogError(jpe, "EXPECTION_OCCURED_DURING_USER_LIMITTED_CREATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_PARSE_EXCEPTION");
        } catch (Exception e) {
            oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_LIMITTED_CREATE");
            vlogError(e, "EXPECTION_OCCURED_DURING_USER_LIMITTED_CREATE");
        }
        gson = null;
        userItem = null;
        oktaUserInputBean = null;
        vlogDebug("::::::: Existing from AgilentOKTAUserService.addUserWithLimittedAttributes ::::::::");
        return oktaUserResponse;
    }
	
	
	/**
	 * This method used for update user in ATG from OKTA
	 * @return
	 */
	public OKTAUserOutputBean updateUser() {
		vlogDebug("::::: Entering method AgilentOKTAUserService.updateUser ::::::::");
	    OKTAUserOutputBean oktaUserResponse = null;
	    MutableRepositoryItem userItem = null;
	    OKTAUserInputBean oktaUserInputBean = null;
	    Gson gson = null;
	    OktaUser lOktaUser = null;
	    String profileStatus = null;
	    String oktaUserRequestString = ServletUtil.getCurrentRequest().getParameter("oktaUserRequest");
	    if (StringUtils.isBlank(oktaUserRequestString)) {
	        return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_EMPTY");
	    }
	    vlogDebug("Obtained Request json for Update User Creation=={0}", oktaUserRequestString);
	    try {
		    gson = new Gson();
		    oktaUserInputBean = gson.fromJson(oktaUserRequestString, OKTAUserInputBean.class);
		    if (!validPrimitiveType(oktaUserRequestString, gson)) {
		        return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_HAS_INVALID_NUMERIC_VALUE");
		    }
		    vlogDebug("Json to Object Conversion Output==={0}", oktaUserInputBean);
		    if (oktaUserInputBean == null) {
		        return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_JSON_REQUEST_PARSE_ERROR");
		    }
	        if (StringUtils.isBlank(oktaUserInputBean.getId())) {
	        	vlogInfo("Please provide User Id =={0}", oktaUserInputBean.getId());
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "USER_ID_REQUIRED");
	        } else {
	        	userItem = getProfileTools().getProfileRepository().getItemForUpdate(oktaUserInputBean.getId(), "user");
	            if (userItem == null) {
	                vlogInfo("Provided User Id is not available in Sytem Id=={0}", oktaUserInputBean.getId());
	                return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "PROVIDED_USER_ID_NOT_AVAILBLE");
	            }else {
		            if (StringUtils.isNotBlank(oktaUserInputBean.getAdLoginName())) {
		                RepositoryItem[] userItem_login = getProfileTools().getItemsFromDotNetId(oktaUserInputBean.getAdLoginName(),getProfileTools().getDefaultProfileType());
		                if (userItem_login != null) {
		                	for(RepositoryItem ui : userItem_login) {
		                		if(!ui.getRepositoryId().equals(userItem.getRepositoryId())){
		                			vlogInfo("login is already available in database= AdloginName={0}", oktaUserInputBean.getAdLoginName());
		     	                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "LOGIN_NAME_ALREADY_EXISTS");
		                		}
		                	}
		                }
		            }
		            if (StringUtils.isNotBlank(oktaUserInputBean.getEmail())) {
		            	RepositoryItem userItem_email = getProfileTools().getItemFromEmail(oktaUserInputBean.getEmail());
		                if (userItem_email != null) {
	                		if(!userItem_email.getRepositoryId().equals(userItem.getRepositoryId())){
	                			vlogInfo("email is already available in database= email={0} ::", oktaUserInputBean.getEmail());
	     	                    return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EMAIL_ALREADY_EXISTS");
	                		}
		                }
		            }
	            }
	        }
	        String oktaProfileStatus = (String) userItem.getPropertyValue(OKTA_PROFILE_STATUS);
	        if(StringUtils.isNotBlank(oktaProfileStatus) && (INTERMEDIATE.equals(oktaProfileStatus) || DEACTIVE.equals(oktaProfileStatus))) {
	        	vlogInfo("AgilentOKTAUserService.updateUser :: Status value from ATG =={0}", oktaProfileStatus);
	        	String email = (String) userItem.getPropertyValue("email");
	        	lOktaUser = getOktaHttpConnectionManager().findUserDetailsUsingEmail(email);
	        	if(null  == lOktaUser) {
	        		 return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "PROVIDED_USER_NOT_AVAILBLE_FROM_UPSTREAM_SYSTEM");
	        	}else {
	        		profileStatus = lOktaUser.getStatus();
	        		vlogInfo("AgilentOKTAUserService.updateUser :: Status value from OKTA =={0}", profileStatus);
	        	}
	        }
	        if (StringUtils.isNotBlank(profileStatus) && ACTIVE.equals(profileStatus)){
	        	getAgilentOKTAUserHelper().updateStatusInRepo(userItem, ACTIVE);
	        	oktaProfileStatus = (String) userItem.getPropertyValue(OKTA_PROFILE_STATUS);
	        }
	        if (StringUtils.isNotBlank(oktaProfileStatus) && DEACTIVE.equals(oktaProfileStatus)){
	        	getAgilentOKTAUserHelper().updateStatusInRepo(userItem, INTERMEDIATE);
	        } else {
	        	List<String> errorMessages = inputValidationForUpdate(oktaUserInputBean);
		        if (!errorMessages.isEmpty()) {
		            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_DATA_VALIDATION_ERROR", errorMessages);
		        }
		        getAgilentOKTAUserHelper().updateUserInRepo(userItem, oktaUserInputBean);
	        }
	        oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.SUCCESS, "USER_UPDATED_SUCCESS");
	        oktaUserResponse.setAtgUserId(userItem.getRepositoryId());
	        
	        RepositoryImpl rep = (RepositoryImpl) getProfileAdapterRepository();
	        String[] descriptorNames = rep.getItemDescriptorNames();
	        boolean isCacheInvalidated = false;
	        if(null != descriptorNames && descriptorNames.length > 0) {
	    		for (int i=0; i < descriptorNames.length; i++) {
	    		    String name = descriptorNames[i];
	    		    ItemDescriptorImpl d = (ItemDescriptorImpl)rep.getItemDescriptor(name);
	    		    d.removeItemFromCache(userItem.getRepositoryId());
	    		    isCacheInvalidated = true;
	    		}
	    		if(isCacheInvalidated) {
	    			vlogInfo("Cache Invalidation for the user ID ==== {0}", oktaUserInputBean.getId());
	    		}
			}
	    } catch (JsonSyntaxException jse) {
        	vlogError(jse, "EXPECTION_OCCURED_DURING_USER_UPDATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_SYNTAX_EXCEPTION");
        } catch (JsonParseException jpe) {
        	vlogError(jpe, "EXPECTION_OCCURED_DURING_USER_UPDATE");
        	return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "JSON_PARSE_EXCEPTION");
        } catch (Exception e) {
	        oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_UPDATE");
	        vlogError(e, "EXPECTION_OCCURED_DURING_USER_UPDATE");
	    }
	    gson = null;
	    userItem = null;
	    oktaUserInputBean = null;
	    vlogDebug("::::::: Exisisting from method AgilentOKTAUserService.updateUser ::::::::");
	    return oktaUserResponse;
	}
	
	/**
	 * This method is used for deleting an user in ATG from OKTA request
	 * @return
	 */
    public OKTAUserOutputBean deleteUser() {
    	vlogDebug("::::::: Entering into method AgilentOKTAUserService.deleteUser ::::::::");
        OKTAUserOutputBean oktaUserResponse = null;
        String atgId = ServletUtil.getCurrentRequest().getParameter("atgId");
        RepositoryItem profileItem = null;
        UserMigrationDataBean userBean = null;
        String email = null;
        try {
	        if (StringUtils.isBlank(atgId)) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_EMPTY");
	        }else {
	        	vlogDebug("Obtained Request json for delete user==={0}", atgId);
	        	profileItem = getProfileAdapterRepository().getItem(atgId,"user");
	        }
        	if(null == profileItem) {
        		oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "USER_NOT_FOUND_IN_ATG");
        	}else {
        		userBean = new UserMigrationDataBean();
        		email = (String) profileItem.getPropertyValue("email");
        		if(StringUtils.isNotBlank(email)) {
                    getUserProfileMigrationHelper().removeATGProfile(userBean,profileItem);
                    if (userBean.isProfileDeletionState()) {
                        oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.SUCCESS, "USER_DELETED_SUCCESS",atgId,email);
                    } else {
                        oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "USER_NOT_FOUND_IN_ATG");
                    }
        		}else {
        			oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EMAIL NOT FOUND FOR THE PROFILE");
                    vlogError("Error occured while removing the user profile from ATG");
        		}
        	}
        } catch (Exception e) {
            oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_DELETE");
            vlogError("Error occured while removing the user profile from ATG");
        }
        vlogDebug("::::::: Existing from the method AgilentOKTAUserService.deleteUser ::::::::");
        return oktaUserResponse;
    }
    
    /**
     * Find the Login Id of the user from email
     * @return
     */
    public ATGUserInfoBean findLoginIdFromEmail() {

        vlogDebug("Entering method AgilentOKTAUserService.findLoginIdFromEmail");

        ATGUserInfoBean userInfoBean = null;
        String adLoginName = null;
        String atgId = null;
        String userEmail = ServletUtil.getCurrentRequest().getParameter("email");
        vlogDebug("User entered email {0}", userEmail);

        if (StringUtils.isNotBlank(userEmail) && isValidEmailAddress(userEmail)) {
            adLoginName = getOktaHttpConnectionManager().findLoginNameFromEmail(userEmail);
            atgId = findAtgIdByEmail(userEmail);
            if (StringUtils.isNotBlank(adLoginName)) {
                userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.SUCCESS, adLoginName, EMPTY_STRING, atgId, userEmail);
            } else {
                userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "No user found with given email id");
                vlogError("No user found with given email id {0}", userEmail);
            }
        } else {
            userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "Invalid email address entered");
            vlogError("Invalid email address entered {0}", userEmail);
        }

        vlogDebug("Method AgilentOKTAUserService.findLoginIdFromEmail returning {0}", adLoginName);

        return userInfoBean;
    }
    
    /**
     * This method will find user from ATG by Email
     * @param pEmail
     * @return
     */
    private String findAtgIdByEmail(String pEmail) {
        String atgId = null;
        RepositoryItem userItem = getProfileTools().getItemFromEmail(pEmail);
        if (userItem == null) {
            vlogError("No user found with email id {0}", pEmail);
        } else {
            atgId = (String) userItem.getPropertyValue("id");
        }
        vlogDebug("AtgId for the email {0} is {1}", pEmail, atgId);
        return atgId;
    }
    
    /**
     * This method will find an user from ATG by ATG ID
     * @param pEmail
     * @return
     */
    public ATGUserInfoBean findUserFromID() {
        vlogDebug("Entering method AgilentOKTAUserService.findUserFromID");
        ATGUserInfoBean userInfoBean = null;
        String atgId = ServletUtil.getCurrentRequest().getParameter("atgId");
        RepositoryItem profileItem = null;
        String email = null;
        String adLoginName = null;
        try {
            if (StringUtils.isBlank(atgId)) {
                return new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "INPUT EMPTY");
            }else {
                vlogDebug("Obtained Request json ==={0}", atgId);
                profileItem = getProfileAdapterRepository().getItem(atgId,"user");
            }
            if(null == profileItem) {
            	userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "No user found in the ATG data base");
            }else {
            	email = (String) profileItem.getPropertyValue("email");
                adLoginName = (String) profileItem.getPropertyValue("adLoginName");
                userInfoBean =  new ATGUserInfoBean(ATGUserInfoBean.StatusCode.SUCCESS, adLoginName,EMPTY_STRING,atgId,email);
            }
        } catch (Exception e) {
            userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_FIND_USER");
            vlogError("Error occured while removing the user profile from ATG");
        }
        vlogDebug("Existing from the method AgilentOKTAUserService.findUserFromID");
        return userInfoBean;
    }
    
    /**
     * This method will find an user from ATG by ATG ID
     * @param pEmail
     * @return
     */
    public ATGUserInfoBean findUserFromLoginOrEmail() {
        vlogDebug("Entering method AgilentOKTAUserService.findUserFromLogin");
        ATGUserInfoBean userInfoBean = null;
        String loginOrEmail = ServletUtil.getCurrentRequest().getParameter("loginOrEmail");
        RepositoryItem profileItem = null;
        String email = null;
        String atgID = null;
        String adLoginName = null;
        try {
            if (StringUtils.isBlank(loginOrEmail)) {
                return new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "INPUT EMPTY");
            }else {
                vlogDebug("Obtained Request json ==={0}", loginOrEmail);
                profileItem = getProfileTools().findUserByLoginName(loginOrEmail);
                if(null == profileItem) {
                	profileItem = getProfileTools().getItemFromEmail(loginOrEmail);
                }
            }
            if(null == profileItem) {
            	userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, EMPTY_STRING, "No user found in the ATG data base");
            }else {
                email = (String) profileItem.getPropertyValue("email");
                atgID = profileItem.getRepositoryId();
                adLoginName = (String) profileItem.getPropertyValue("adLoginName");
                userInfoBean =  new ATGUserInfoBean(ATGUserInfoBean.StatusCode.SUCCESS, adLoginName,EMPTY_STRING,atgID,email);
            }
        } catch (Exception e) {
            userInfoBean = new ATGUserInfoBean(ATGUserInfoBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_FIND_USER");
            vlogError("Error occured while removing the user profile from ATG");
        }
        vlogDebug("Existing from the method AgilentOKTAUserService.findUserFromLogin");
        return userInfoBean;
    }
    
	/**
	 * This method is used for deactivating an user in ATG
	 * @return
	 */
    public OKTAUserOutputBean deActivateUser() {
    	vlogDebug("::::::: Entering into method AgilentOKTAUserService.deActivateUser ::::::::");
        OKTAUserOutputBean oktaUserResponse = null;
        String atgId = ServletUtil.getCurrentRequest().getParameter("atgId");
        MutableRepositoryItem profileItem = null;
        String email = null;
        try {
	        if (StringUtils.isBlank(atgId)) {
	            return new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "OKTA_INPUT_REQUEST_EMPTY");
	        }else {
	        	vlogDebug("Obtained Request json for delete user==={0}", atgId);
	        	profileItem = getProfileTools().getProfileRepository().getItemForUpdate(atgId, "user");
	        }
        	if(null == profileItem) {
        		oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "USER_NOT_FOUND_IN_ATG");
        	}else {
        		getAgilentOKTAUserHelper().updateStatusInRepo(profileItem, DEACTIVE);
        		email = (String) profileItem.getPropertyValue("email");
        		oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.SUCCESS, "USER_DEACTIVATION_SUCCESS", atgId, email);
        		RepositoryImpl rep = (RepositoryImpl) getProfileAdapterRepository();
     	        String[] descriptorNames = rep.getItemDescriptorNames();
     	        boolean isCacheInvalidated = false;
     	        if(null != descriptorNames && descriptorNames.length > 0) {
     	    		for (int i=0; i < descriptorNames.length; i++) {
     	    		    String name = descriptorNames[i];
     	    		    ItemDescriptorImpl d = (ItemDescriptorImpl)rep.getItemDescriptor(name);
     	    		    d.removeItemFromCache(profileItem.getRepositoryId());
     	    		    isCacheInvalidated = true;
     	    		}
     	    		if(isCacheInvalidated) {
     	    			vlogInfo("Cache Invalidation for the user ID from deActivateUser==== {0}", oktaUserResponse.getAtgUserId());
     	    		}
     			}
        	}
        } catch (Exception e) {
            oktaUserResponse = new OKTAUserOutputBean(OKTAUserOutputBean.StatusCode.ERROR, "EXPECTION_OCCURED_DURING_USER_DEACTIVATE");
            vlogError("Error occured while removing the user profile from ATG");
        }
        vlogDebug("::::::: Existing from the method AgilentOKTAUserService.deActivateUser ::::::::");
        return oktaUserResponse;
    }
    
    /**
     * Method to validate the email id
     * 
     * @param email
     * @return
     */
    public static boolean isValidEmailAddress(String email) {
        boolean result = true;
        try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
        } catch (AddressException ex) {
            result = false;
        }
        return result;
    }
    
    /**
     * This method will do the invalidation for create user
     * @param oktaUserInputBean
     * @return
     * @throws RepositoryException
     */
    
    public List<String> inputValidationForCreate(OKTAUserInputBean oktaUserInputBean) throws RepositoryException {
    	vlogDebug("Entering into AgilentOKTAUserService.inputValidationForCreate");
        List<String> errorMessages = new ArrayList<String>();
        Locale locale = new Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
        ResourceBundle resourceBundle = ResourceBundle.getBundle(getErrorHandler().getBundleMap().get("profile"), locale);
        try {
            getValidator().validate("addUserValidation", oktaUserInputBean);
        } catch (SystemException e) {
            vlogError(e, "EXPECTION_OCCURED_DURING_inputValidationForCreate");
        } catch (ValidationExceptions eValidationErros) {
            List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
            for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                try {
                    errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                            validationError.getMessageContext()));
                } catch (Exception ev) {
                    vlogError(ev, "EXPECTION_OCCURED_inputValidationForCreate");
                }
            }
        }
        boolean isEcomEnabled = computeEcommerceEnabledCountry(oktaUserInputBean.getShipCountry());
        vlogDebug("AgilentOKTAUserService.inputValidationForCreate ::: isEcomEnabled::: {0}", isEcomEnabled);
        if(isEcomEnabled) {
        	try {
                getValidator().validate("addUserBillAddrValidation", oktaUserInputBean);
            } catch (SystemException e) {
                vlogError(e, "EXPECTION_OCCURED_DURING_inputValidationForCreate");
            } catch (ValidationExceptions eValidationErros) {
                List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
                for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                    try {
                        errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                                validationError.getMessageContext()));
                    } catch (Exception ev) {
                        vlogError(ev, "EXPECTION_OCCURED_inputValidationForCreate");
                    }
                }
            }
        	
        	try {
                getValidator().validate("addUserShipAddrValidation", oktaUserInputBean);
            } catch (SystemException e) {
                vlogError(e, "EXPECTION_OCCURED_DURING_inputValidationForCreate");
            } catch (ValidationExceptions eValidationErros) {
                List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
                for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                    try {
                        errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                                validationError.getMessageContext()));
                    } catch (Exception ev) {
                        vlogError(ev, "EXPECTION_OCCURED_inputValidationForCreate");
                    }
                }
            }
        	
            if (!getCountriesListwithoutPC().contains(oktaUserInputBean.getShipCountry()) && StringUtils.isEmpty(oktaUserInputBean.getBillPostalCode())) {
                errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(BILLING_ZIPNDPOSTAL)));
            } else {
                ValidationExceptions validationException_bill = new ValidationExceptions();
                String salesOrg = getCountryUtils().getSalesOrgForCountry(oktaUserInputBean.getShipCountry());
                if (salesOrg != null) {
                    salesOrg = salesOrg.toUpperCase(Locale.ENGLISH);
                }
                if (StringUtils.isNotBlank(oktaUserInputBean.getBillPostalCode())) {
                    ValidatorUtil.validatePostalCode(salesOrg, oktaUserInputBean.getBillPostalCode(), BILLING_ZIPNDPOSTAL, validationException_bill);
                }
                for (com.agilent.base.platform.ValidationError validationErrorBill : validationException_bill.getValidationErrors()) {
                    errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorBill.getErrId(), "profile", validationErrorBill.getKeyContext(),
                            validationErrorBill.getMessageContext()));
                }
            }

             if (!getCountriesListwithoutPC().contains(oktaUserInputBean.getShipCountry()) && StringUtils.isEmpty(oktaUserInputBean.getShipPostalCode())) {
                 errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(SHIPPING_ZIPNDPOSTAL)));
             } else {
                 ValidationExceptions validationException_ship = new ValidationExceptions();
                 String salesOrg = getCountryUtils().getSalesOrgForCountry(oktaUserInputBean.getShipCountry());
                 if (salesOrg != null) {
                     salesOrg = salesOrg.toUpperCase(Locale.ENGLISH);
                 }
                 if (StringUtils.isNotBlank(oktaUserInputBean.getShipPostalCode())) {
                 ValidatorUtil.validatePostalCode(salesOrg, oktaUserInputBean.getShipPostalCode(), SHIPPING_ZIPNDPOSTAL, validationException_ship);
                 }
                 for (com.agilent.base.platform.ValidationError validationErrorShip : validationException_ship.getValidationErrors()) {
                     errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorShip.getErrId(), "profile", validationErrorShip.getKeyContext(),
                             validationErrorShip.getMessageContext()));
                 }
             }

             if (getCountryUtils().getCountryItems(oktaUserInputBean.getShipCountry()) == null) {
                 errorMessages.add(resourceBundle.getString("idmShipCountryInvalid"));
             } else

             if (getCountryUtils().getCountryItems(oktaUserInputBean.getBillCountry()) == null) {
                 errorMessages.add(resourceBundle.getString("idmBillCountryInvalid"));
             } else

             if (!StringUtils.isBlank(oktaUserInputBean.getBillCountry()) && !oktaUserInputBean.getBillCountry().equals(oktaUserInputBean.getShipCountry())) {
                 errorMessages.add(resourceBundle.getString("idmShipandBillSameCountry"));
             }
        	
        }
        if (!errorMessages.isEmpty()) {
            vlogInfo("Validation Failed and list of problem == {0}", errorMessages);
        }
        vlogDebug("Existing from AgilentOKTAUserService.inputValidationForCreate");
        return errorMessages;
    }
    
    /**
     * This method is used to check whether country selected by user is eCommerce Enable dor not
     * 
     * @param pShipCountry
     * @return
     */
    private boolean computeEcommerceEnabledCountry(String pShipCountry) {
    	 boolean eCommerceEnabled = false;
         if (pShipCountry != null && getEnabledCountryList() != null) {
             if (getEnabledCountryList().contains(pShipCountry)) {
                 eCommerceEnabled = true;
             } else {
                 eCommerceEnabled = false;
             }
         }
         return eCommerceEnabled;
    }
    /**
     * This method will validate the parameters for create
     * @param oktaUserInputBean
     * @return
     * @throws RepositoryException
     */
	public List<String> inputValidationForOKTACreate(OKTAUserInputBean oktaUserInputBean) throws RepositoryException {
		vlogDebug("Entring into AgilentOKTAUserService.inputValidationForOKTACreate");
        List<String> errorMessages = new ArrayList<String>();
        Locale locale = new Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
        ResourceBundle resourceBundle = ResourceBundle.getBundle(getErrorHandler().getBundleMap().get("profile"), locale);
        if(StringUtils.isBlank(oktaUserInputBean.getFirstName())) {
        	errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(USER_FIRST_NAME)));
        }else if(StringUtils.isBlank(oktaUserInputBean.getLastName())) {
        	errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(USER_LAST_NAME)));
        }else if(StringUtils.isBlank(oktaUserInputBean.getLogin())) {
        	errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(USER_LOGIN_NAME)));
        }else if(StringUtils.isBlank(oktaUserInputBean.getEmail())) {
        	errorMessages.add(MessageFormat.format(resourceBundle.getString(IErrorId.PROP_REQUIRED), resourceBundle.getString(USER_EMAIL_ID)));
        }
        vlogDebug("Exisiting from AgilentOKTAUserService.inputValidationForOKTACreate");
        return errorMessages;
    }
	
	/**
	 * This method will validate the parameters for udpate
	 * @param idmUserInputBean
	 * @return
	 * @throws RepositoryException
	 */
    public List<String> inputValidationForUpdate(OKTAUserInputBean idmUserInputBean) throws RepositoryException {
    	vlogDebug("Entring into AgilentOKTAUserService.inputValidationForUpdate");
        List<String> errorMessages = new ArrayList<String>();
        Locale locale = new Locale(DEFAULT_LANGUAGE, DEFAULT_COUNTRY);
        ResourceBundle resourceBundle = ResourceBundle.getBundle(getErrorHandler().getBundleMap().get("profile"), locale);
        try {
            getValidator().validate("registerServiceValidationUpdate", idmUserInputBean);
        } catch (SystemException e) {
            vlogError(e, "EXPECTION_OCCURED_inputValidationForUpdate");
        } catch (ValidationExceptions eValidationErros) {
            List<com.agilent.base.platform.ValidationError> validatetionErrors = eValidationErros.getValidationErrors();
            for (com.agilent.base.platform.ValidationError validationError : validatetionErrors) {
                try {
                    errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationError.getErrId(), "profile", validationError.getKeyContext(),
                            validationError.getMessageContext()));
                } catch (Exception ev) {
                    vlogError(ev, "EXPECTION_OCCURED_inputValidationForUpdate");
                }
            }
        }
        if (!StringUtils.isEmpty(idmUserInputBean.getSapSalesOrg())) {
            if (!AgilentUtil.isValidSalesOrg(idmUserInputBean.getSapSalesOrg().toUpperCase(Locale.ENGLISH))) {
                errorMessages.add("Provided SalesOrg is not Valid");
            }
        }
        if (!getCountriesListwithoutPC().contains(idmUserInputBean.getShipCountry()) && !StringUtils.isEmpty(idmUserInputBean.getBillPostalCode())) {
            ValidationExceptions validationException_bill = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase(Locale.ENGLISH);
            }

            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getBillPostalCode(), BILLING_ZIPNDPOSTAL, validationException_bill);

            for (com.agilent.base.platform.ValidationError validationErrorBill : validationException_bill.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorBill.getErrId(), "profile", validationErrorBill.getKeyContext(),
                        validationErrorBill.getMessageContext()));
            }
        }
        if (!getCountriesListwithoutPC().contains(idmUserInputBean.getShipCountry()) && !StringUtils.isEmpty(idmUserInputBean.getShipPostalCode())) {
            ValidationExceptions validationException_ship = new ValidationExceptions();
            String salesOrg = getCountryUtils().getSalesOrgForCountry(idmUserInputBean.getShipCountry());
            if (salesOrg != null) {
                salesOrg = salesOrg.toUpperCase();
            }

            ValidatorUtil.validatePostalCode(salesOrg, idmUserInputBean.getShipPostalCode(), SHIPPING_ZIPNDPOSTAL, validationException_ship);

            for (com.agilent.base.platform.ValidationError validationErrorShip : validationException_ship.getValidationErrors()) {
                errorMessages.add(getErrorHandler().getFormattedErrorMessage(validationErrorShip.getErrId(), "profile", validationErrorShip.getKeyContext(),
                        validationErrorShip.getMessageContext()));
            }
        }
        if (!StringUtils.isBlank(idmUserInputBean.getShipCountry()) && getCountryUtils().getCountryItems(idmUserInputBean.getShipCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmShipCountryInvalid"));
        } else if (!StringUtils.isBlank(idmUserInputBean.getBillCountry()) && getCountryUtils().getCountryItems(idmUserInputBean.getBillCountry()) == null) {
            errorMessages.add(resourceBundle.getString("idmBillCountryInvalid"));
        } else if (!StringUtils.isBlank(idmUserInputBean.getBillCountry()) && !StringUtils.isBlank(idmUserInputBean.getShipCountry())
                && !idmUserInputBean.getBillCountry().equals(idmUserInputBean.getShipCountry())) {
            errorMessages.add(resourceBundle.getString("idmShipandBillSameCountry"));
        }
        if (!errorMessages.isEmpty()) {
            vlogInfo("Validation Failed and list of problem1 == {0}", errorMessages);
        }
        vlogDebug("Exisiting from AgilentOKTAUserService.inputValidationForUpdate");
        return errorMessages;
    }
    
    /**
     * This method will validate the primitive type
     * @param idmUserRequestString
     * @param gjson
     * @return
     */
    private boolean validPrimitiveType(String idmUserRequestString, Gson gjson) {
        try {
            JsonObject json = gjson.fromJson(idmUserRequestString, JsonObject.class);
            Set<Entry<String, JsonElement>> slist = json.entrySet();
            for (Entry e : slist) {
                JsonElement ele = (JsonElement) e.getValue();
                if (ele.isJsonPrimitive() && ele.getAsJsonPrimitive().isNumber()) {
                    if (!(ele.getAsJsonPrimitive().getAsInt() == 1 || ele.getAsJsonPrimitive().getAsInt() == 0)) {
                        vlogDebug("Invalid Number has provided , Needed value is 1 or 0 ====={0}", ele.getAsJsonPrimitive().getAsInt());
                        return false;
                    }
                }
            }	
        } catch (JsonSyntaxException jse) {
        	vlogError(jse, "SYNTAX_EXPECTION_OCCURED");
        	return false;
        } catch (JsonParseException jpe) {
        	vlogError(jpe, "PARSE_EXPECTION_OCCURED");
        	return false;
        }
        return true;
    }

    /**
     * Gets the value of property oktaHttpConnectionManager
     *
     * @return the value of property oktaHttpConnectionManager
     */
    public OktaHttpConnectionManager getOktaHttpConnectionManager() {
        return mOktaHttpConnectionManager;
    }

    /**
     * Sets the value of property oktaHttpConnectionManager with value oktaHttpConnectionManager
     *
     * @param oktaHttpConnectionManager
     *            for setting property oktaHttpConnectionManager
     */
    public void setOktaHttpConnectionManager(OktaHttpConnectionManager oktaHttpConnectionManager) {
        this.mOktaHttpConnectionManager = oktaHttpConnectionManager;
    }

    /**
     * Gets the value of property mCountriesListwithoutPC
     *
     * @return the value of property mCountriesListwithoutPC
     */
    public List<String> getCountriesListwithoutPC() {
        return mCountriesListwithoutPC;
    }

    /**
     * Sets the value of property mCountriesListwithoutPC with value mCountriesListwithoutPC
     *
     * @param mCountriesListwithoutPC
     *            for setting property mCountriesListwithoutPC
     */
    public void setCountriesListwithoutPC(List<String> mCountriesListwithoutPC) {
        this.mCountriesListwithoutPC = mCountriesListwithoutPC;
    }

/**
	 * @return the enabledCountryList
	 */
	public List<String> getEnabledCountryList() {
		return enabledCountryList;
	}

	/**
	 * @param enabledCountryList the enabledCountryList to set
	 */
	public void setEnabledCountryList(List<String> enabledCountryList) {
		this.enabledCountryList = enabledCountryList;
	}
    /**
     * @return the userProfileMigrationHelper
     */
    public UserProfileMigrationHelper getUserProfileMigrationHelper() {
        return userProfileMigrationHelper;
    }

    /**
     * @param userProfileMigrationHelper the userProfileMigrationHelper to set
     */
    public void setUserProfileMigrationHelper(UserProfileMigrationHelper userProfileMigrationHelper) {
        this.userProfileMigrationHelper = userProfileMigrationHelper;
    }

    public AgilentConfiguration getAgilentConfiguration() {
        return agilentConfiguration;
    }

    public void setAgilentConfiguration(AgilentConfiguration agilentConfiguration) {
        this.agilentConfiguration = agilentConfiguration;
    }

    public String getMigratedRedirectURL() {
        return migratedRedirectURL;
    }

    public void setMigratedRedirectURL(String migratedRedirectURL) {
        this.migratedRedirectURL = migratedRedirectURL;
    }

    public AgilentUserOKTAHelper getAgilentOKTAUserHelper() {
        return agilentOKTAUserHelper;
    }

    public void setAgilentOKTAUserHelper(AgilentUserOKTAHelper agilentOKTAUserHelper) {
        this.agilentOKTAUserHelper = agilentOKTAUserHelper;
    }

    public AgilentProfileTools getProfileTools() {
        return profileTools;
    }

    public void setProfileTools(AgilentProfileTools profileTools) {
        this.profileTools = profileTools;
    }

    public IValidator getValidator() {
        return validator;
    }

    public void setValidator(IValidator validator) {
        this.validator = validator;
    }

    public ErrorHandlerImpl getErrorHandler() {
        return errorHandler;
    }

    public void setErrorHandler(ErrorHandlerImpl errorHandler) {
        this.errorHandler = errorHandler;
    }

    public CountryUtils getCountryUtils() {
        return countryUtils;
    }

    public void setCountryUtils(CountryUtils countryUtils) {
        this.countryUtils = countryUtils;
    }

    /**
     * Gets the value of property profileAdapterRepository
     *
     * @return the value of property profileAdapterRepository
     */
    public Repository getProfileAdapterRepository() {
        return mProfileAdapterRepository;
    }
    /**
     * Sets the value of property profileAdapterRepository with value pProfileAdapterRepository
     *
     * @param pProfileAdapterRepository
     *            for setting property profileAdapterRepository
     */
    public void setProfileAdapterRepository(Repository pProfileAdapterRepository) {
        mProfileAdapterRepository = pProfileAdapterRepository;
    }
}
