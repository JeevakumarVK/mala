/**
 * 
 */
package com.agilent.profile.okta.rest.services.bean;

/**
 * @author 618305
 *
 */
public class ATGUserInfoBean {
    
    public enum StatusCode {SUCCESS,ERROR};
    
    private StatusCode statusCode;
    private String adLoginName;
    private String errorMessage;
    private String atgID;
    private String email;
    
	/**
     * @param statusCode
     * @param adLoginName
     */
    public ATGUserInfoBean(StatusCode statusCode, String adLoginName) {
        super();
        this.statusCode = statusCode;
        this.adLoginName = adLoginName;
    }
    
    /**
     * @param statusCode
     * @param adLoginName
     * @param errorMessage
     */
    public ATGUserInfoBean(StatusCode statusCode, String adLoginName, String errorMessage) {
        super();
        this.statusCode = statusCode;
        this.adLoginName = adLoginName;
        this.errorMessage = errorMessage;
    }
    
    public ATGUserInfoBean(StatusCode statusCode, String adLoginName, String errorMessage,String atgID, String email) {
        super();
        this.statusCode = statusCode;
        this.adLoginName = adLoginName;
        this.errorMessage = errorMessage;
        this.atgID = atgID;
        this.email = email;
    }

    /**
     * Gets the value of property statusCode
     *
     * @return the value of property statusCode
     */
    public StatusCode getStatusCode() {
        return statusCode;
    }
    /**
     * Sets the value of property statusCode with value statusCode
     *
     * @param statusCode
     *            for setting property statusCode
     */
    public void setStatusCode(StatusCode statusCode) {
        this.statusCode = statusCode;
    }
    /**
     * Gets the value of property adLoginName
     *
     * @return the value of property adLoginName
     */
    public String getAdLoginName() {
        return adLoginName;
    }
    /**
     * Sets the value of property adLoginName with value adLoginName
     *
     * @param adLoginName
     *            for setting property adLoginName
     */
    public void setAdLoginName(String adLoginName) {
        this.adLoginName = adLoginName;
    }
    /**
     * Gets the value of property errorMessage
     *
     * @return the value of property errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }
    /**
     * Sets the value of property errorMessage with value errorMessage
     *
     * @param errorMessage
     *            for setting property errorMessage
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
    
    /**
	 * @return the atgID
	 */
	public String getAtgID() {
		return atgID;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param atgID the atgID to set
	 */
	public void setAtgID(String atgID) {
		this.atgID = atgID;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
    

}
