/* <Agilent Copyright>
 * Copyright (C) 2012 Agilent
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Agilent.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * AGILENT MAKES NO REPRESENTATIONS OR WARRANTIES
 * ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT
 * SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * </Agilent Copyright>
 */
package com.agilent.profile.okta.rest.services.bean;

import java.sql.Timestamp;

public class OKTAUserInputBean {

    public enum ActionCode {
        ADD, REMOVE
    };
    private String id;
    private String login;
    private int autoLogin = -1;
    private String firstName;
    private String lastName;
    private Timestamp lastActivityDate;
    private Timestamp registrationDate;
    private String email;
    private String fedexCollectNumber;
    private String defaultShippingMethod;
    private String defaultPaymentMethod;
    private int taxExempt = -1;
    private String taxExemptCertificatePath;
    private String taxExemptNumber;
    private String sapCustomerId;
    private int enableCommerce = -1;
    private String sapSalesOrg;
    private String punchoutMember;
    private String sapBillToAddress;
    private String sapShipToAddress;
    private String adLoginName;
    private int mossDownWhenRegister = -1;
    private String userCountry;
    private String defaultShipAddressType;
    private int testAccount = -1;
    private int sapMasterAccount = -1;
    private int dropShipment = -1;
    private int includePunchoutShipping = -1;
    private int includePunchoutTaxes = -1;
    private String memberType;
    private String ecommerceStatus;
    private int showDutyFreePrice = -1;
    private String upsCollectNumber;
    private String payerInvoiceEmail;
    private int addFileUploaded = -1;
    private int advanceShippingDisabled = -1;
    private String partnerName;
    private String partnerIdentifier;
    private String password;
    private String companyName;
    private String phoneNumber;
    private String extension;
    private String shipAddress1;
    private String shipAddress2;
    private String shipCity;
    private String shipState;
    private String shipPostalCode;
    private String shipCountry;
    private String billAddress1;
    private String billAddress2;
    private String billCity;
    private String billState;
    private String billPostalCode;
    private String billCountry;
    private OKTAUserInputBean.Invoice invoice = new OKTAUserInputBean.Invoice();
    private int b2bUser = -1;
    private int sapDirectorAccount = -1;
    private String b2bGroupId;
    private OKTAUserInputBean.UserRoles userRole = new OKTAUserInputBean.UserRoles();
    private String title;
    private String department;
    private String region;
    private String[] secondaryECCContact_ID;
    private String[] role;
    private String crmContactNumber;
    private String[] multipleSoldTo;

    /**
     * @return the secondaryECCContact_ID
     */
    public String[] getSecondaryECCContact_ID() {
        return secondaryECCContact_ID;
    }


    /**
     * @param secondaryECCContact_ID the secondaryECCContact_ID to set
     */
    public void setSecondaryECCContact_ID(String[] secondaryECCContact_ID) {
        this.secondaryECCContact_ID = secondaryECCContact_ID;
    }


    /**
     * @return the role
     */
    public String[] getRole() {
        return role;
    }


    /**
     * @param role the role to set
     */
    public void setRole(String[] role) {
        this.role = role;
    }


    /**
     * @return the crmContactNumber
     */
    public String getCrmContactNumber() {
        return crmContactNumber;
    }


    /**
     * @param crmContactNumber the crmContactNumber to set
     */
    public void setCrmContactNumber(String crmContactNumber) {
        this.crmContactNumber = crmContactNumber;
    }
    public String getTitle() {
        return title;
    }

 
    public void setTitle(String title) {
        this.title = title;
    }

    public String getDepartment() {
        return department;
    }


    public void setDepartment(String department) {
        this.department = department;
    }

    public String getRegion() {
        return region;
    }


    public void setRegion(String region) {
        this.region = region;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Timestamp getLastActivityDate() {
        return lastActivityDate;
    }

    public void setLastActivityDate(Timestamp lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }

    public Timestamp getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Timestamp registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFedexCollectNumber() {
        return fedexCollectNumber;
    }

    public void setFedexCollectNumber(String fedexCollectNumber) {
        this.fedexCollectNumber = fedexCollectNumber;
    }

    public String getDefaultShippingMethod() {
        return defaultShippingMethod;
    }

    public void setDefaultShippingMethod(String defaultShippingMethod) {
        this.defaultShippingMethod = defaultShippingMethod;
    }

    public String getDefaultPaymentMethod() {
        return defaultPaymentMethod;
    }

    public void setDefaultPaymentMethod(String defaultPaymentMethod) {
        this.defaultPaymentMethod = defaultPaymentMethod;
    }

    public String getTaxExemptCertificatePath() {
        return taxExemptCertificatePath;
    }

    public void setTaxExemptCertificatePath(String taxExemptCertificatePath) {
        this.taxExemptCertificatePath = taxExemptCertificatePath;
    }

    public String getTaxExemptNumber() {
        return taxExemptNumber;
    }

    public void setTaxExemptNumber(String taxExemptNumber) {
        this.taxExemptNumber = taxExemptNumber;
    }

    public String getSapCustomerId() {
        return sapCustomerId;
    }

    public void setSapCustomerId(String sapCustomerId) {
        this.sapCustomerId = sapCustomerId;
    }

    public String getSapSalesOrg() {
        return sapSalesOrg;
    }

    public void setSapSalesOrg(String sapSalesOrg) {
        this.sapSalesOrg = sapSalesOrg;
    }

    public String getPunchoutMember() {
        return punchoutMember;
    }

    public void setPunchoutMember(String punchoutMember) {
        this.punchoutMember = punchoutMember;
    }

    public String getSapBillToAddress() {
        return sapBillToAddress;
    }

    public void setSapBillToAddress(String sapBillToAddress) {
        this.sapBillToAddress = sapBillToAddress;
    }

    public String getSapShipToAddress() {
        return sapShipToAddress;
    }

    public void setSapShipToAddress(String sapShipToAddress) {
        this.sapShipToAddress = sapShipToAddress;
    }

    public String getAdLoginName() {
        return adLoginName;
    }

    public void setAdLoginName(String adLoginName) {
        this.adLoginName = adLoginName;
    }

    public String getUserCountry() {
        return userCountry;
    }

    public void setUserCountry(String userCountry) {
        this.userCountry = userCountry;
    }

    public String getDefaultShipAddressType() {
        return defaultShipAddressType;
    }

    public void setDefaultShipAddressType(String defaultShipAddressType) {
        this.defaultShipAddressType = defaultShipAddressType;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    public String getEcommerceStatus() {
        return ecommerceStatus;
    }

    public void setEcommerceStatus(String ecommerceStatus) {
        this.ecommerceStatus = ecommerceStatus;
    }

    public String getUpsCollectNumber() {
        return upsCollectNumber;
    }

    public void setUpsCollectNumber(String upsCollectNumber) {
        this.upsCollectNumber = upsCollectNumber;
    }

    public String getPayerInvoiceEmail() {
        return payerInvoiceEmail;
    }

    public void setPayerInvoiceEmail(String payerInvoiceEmail) {
        this.payerInvoiceEmail = payerInvoiceEmail;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getPartnerIdentifier() {
        return partnerIdentifier;
    }

    public void setPartnerIdentifier(String partnerIdentifier) {
        this.partnerIdentifier = partnerIdentifier;
    }
    // public String getPreferredLanguages() {
    // return preferredLanguages;
    // }
    // public void setPreferredLanguages(String preferredLanguages) {
    // this.preferredLanguages = preferredLanguages;
    // }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension(String extension) {
        this.extension = extension;
    }

    public String getShipAddress1() {
        return shipAddress1;
    }

    public void setShipAddress1(String shipAddress1) {
        this.shipAddress1 = shipAddress1;
    }

    public String getShipAddress2() {
        return shipAddress2;
    }

    public void setShipAddress2(String shipAddress2) {
        this.shipAddress2 = shipAddress2;
    }

    public String getShipCity() {
        return shipCity;
    }

    public void setShipCity(String shipCity) {
        this.shipCity = shipCity;
    }

    public String getShipState() {
        return shipState;
    }

    public void setShipState(String shipState) {
        this.shipState = shipState;
    }

    public String getShipPostalCode() {
        return shipPostalCode;
    }

    public void setShipPostalCode(String shipPostalCode) {
        this.shipPostalCode = shipPostalCode;
    }

    public String getShipCountry() {
        return shipCountry;
    }

    public void setShipCountry(String shipCountry) {
        this.shipCountry = shipCountry;
    }

    public String getBillAddress1() {
        return billAddress1;
    }

    public void setBillAddress1(String billAddress1) {
        this.billAddress1 = billAddress1;
    }

    public String getBillAddress2() {
        return billAddress2;
    }

    public void setBillAddress2(String billAddress2) {
        this.billAddress2 = billAddress2;
    }

    public String getBillCity() {
        return billCity;
    }

    public void setBillCity(String billCity) {
        this.billCity = billCity;
    }

    public String getBillState() {
        return billState;
    }

    public void setBillState(String billState) {
        this.billState = billState;
    }

    public String getBillPostalCode() {
        return billPostalCode;
    }

    public void setBillPostalCode(String billPostalCode) {
        this.billPostalCode = billPostalCode;
    }

    public String getBillCountry() {
        return billCountry;
    }

    public void setBillCountry(String billCountry) {
        this.billCountry = billCountry;
    }

    public int getTaxExempt() {
        return taxExempt;
    }

    public void setTaxExempt(int taxExempt) {
        this.taxExempt = taxExempt;
    }

    public int getEnableCommerce() {
        return enableCommerce;
    }

    public void setEnableCommerce(int enableCommerce) {
        this.enableCommerce = enableCommerce;
    }

    // public int getAccesLibraryOptIn() {
    // return accesLibraryOptIn;
    // }
    // public void setAccesLibraryOptIn(int accesLibraryOptIn) {
    // this.accesLibraryOptIn = accesLibraryOptIn;
    // }
    // public int getNewsOptIn() {
    // return newsOptIn;
    // }
    // public void setNewsOptIn(int newsOptIn) {
    // this.newsOptIn = newsOptIn;
    // }
    public int getMossDownWhenRegister() {
        return mossDownWhenRegister;
    }

    public void setMossDownWhenRegister(int mossDownWhenRegister) {
        this.mossDownWhenRegister = mossDownWhenRegister;
    }

    public int getTestAccount() {
        return testAccount;
    }

    public void setTestAccount(int testAccount) {
        this.testAccount = testAccount;
    }

    public int getSapMasterAccount() {
        return sapMasterAccount;
    }

    public void setSapMasterAccount(int sapMasterAccount) {
        this.sapMasterAccount = sapMasterAccount;
    }

    public int getDropShipment() {
        return dropShipment;
    }

    public void setDropShipment(int dropShipment) {
        this.dropShipment = dropShipment;
    }

    public int getIncludePunchoutShipping() {
        return includePunchoutShipping;
    }

    public void setIncludePunchoutShipping(int includePunchoutShipping) {
        this.includePunchoutShipping = includePunchoutShipping;
    }

    public int getIncludePunchoutTaxes() {
        return includePunchoutTaxes;
    }

    public void setIncludePunchoutTaxes(int includePunchoutTaxes) {
        this.includePunchoutTaxes = includePunchoutTaxes;
    }

    public int getShowDutyFreePrice() {
        return showDutyFreePrice;
    }

    public void setShowDutyFreePrice(int showDutyFreePrice) {
        this.showDutyFreePrice = showDutyFreePrice;
    }

    public int getAddFileUploaded() {
        return addFileUploaded;
    }

    public void setAddFileUploaded(int addFileUploaded) {
        this.addFileUploaded = addFileUploaded;
    }

    public int getAdvanceShippingDisabled() {
        return advanceShippingDisabled;
    }

    public void setAdvanceShippingDisabled(int advanceShippingDisabled) {
        this.advanceShippingDisabled = advanceShippingDisabled;
    }

    public int getAutoLogin() {
        return autoLogin;
    }
    // public int getReceiveEmail() {
    // return receiveEmail;
    // }
    //
    // public void setReceiveEmail(int receiveEmail) {
    // this.receiveEmail = receiveEmail;
    // }

    public void setAutoLogin(int autoLogin) {
        this.autoLogin = autoLogin;
    }

    public OKTAUserInputBean.Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(OKTAUserInputBean.Invoice invoice) {
        this.invoice = invoice;
    }

    public int getB2bUser() {
        return b2bUser;
    }

    public void setB2bUser(int b2bUser) {
        this.b2bUser = b2bUser;
    }

    public int getSapDirectorAccount() {
        return sapDirectorAccount;
    }

    public void setSapDirectorAccount(int sapDirectorAccount) {
        this.sapDirectorAccount = sapDirectorAccount;
    }

    public String getB2bGroupId() {
        return b2bGroupId;
    }

    public void setB2bGroupId(String b2bGroupId) {
        this.b2bGroupId = b2bGroupId;
    }

    public OKTAUserInputBean.UserRoles getUserRole() {
        return userRole;
    }

    public void setUserRole(OKTAUserInputBean.UserRoles userRole) {
        this.userRole = userRole;
    }

    @Override
    public String toString() {

        StringBuffer sb = new StringBuffer();
        sb.append("Id=" + id + "\n");
        sb.append("login=" + login + "\n");
        sb.append("autoLogin=" + autoLogin + "\n");
        sb.append("firstName=" + firstName + "\n");
        sb.append("lastName=" + lastName + "\n");
        sb.append("lastActivityDate=" + lastActivityDate + "\n");
        sb.append("registrationDate=" + registrationDate + "\n");
        sb.append("email=" + email + "\n");
        // sb.append("receiveEmail="+receiveEmail+"\n");
        sb.append("fedexCollectNumber=" + fedexCollectNumber + "\n");
        sb.append("defaultShippingMethod=" + defaultShippingMethod + "\n");
        sb.append("defaultPaymentMethod=" + defaultPaymentMethod + "\n");
        sb.append("taxExempt=" + taxExempt + "\n");
        sb.append("taxExemptCertificatePath=" + taxExemptCertificatePath + "\n");
        sb.append("taxExemptNumber=" + taxExemptNumber + "\n");
        sb.append("sapCustomerId=" + sapCustomerId + "\n");
        sb.append("enableCommerce=" + enableCommerce + "\n");
        // sb.append("accesLibraryOptIn="+accesLibraryOptIn+"\n");
        // sb.append("newsOptIn="+newsOptIn+"\n");
        sb.append("sapSalesOrg=" + sapSalesOrg + "\n");
        sb.append("punchoutMember=" + punchoutMember + "\n");
        sb.append("sapBillToAddress=" + sapBillToAddress + "\n");
        sb.append("sapShipToAddress=" + sapShipToAddress + "\n");
        sb.append("adLoginName=" + adLoginName + "\n");
        sb.append("mossDownWhenRegister=" + mossDownWhenRegister + "\n");
        sb.append("userCountry=" + userCountry + "\n");
        sb.append("defaultShipAddressType=" + defaultShipAddressType + "\n");
        sb.append("testAccount=" + testAccount + "\n");
        sb.append("sapMasterAccount=" + sapMasterAccount + "\n");
        sb.append("dropShipment=" + dropShipment + "\n");
        sb.append("includePunchoutShipping=" + includePunchoutShipping + "\n");
        sb.append("includePunchoutTaxes=" + includePunchoutTaxes + "\n");
        sb.append("memberType=" + memberType + "\n");
        sb.append("ecommerceStatus=" + ecommerceStatus + "\n");
        sb.append("showDutyFreePrice=" + showDutyFreePrice + "\n");
        sb.append("upsCollectNumber=" + upsCollectNumber + "\n");
        sb.append("payerInvoiceEmail=" + payerInvoiceEmail + "\n");
        sb.append("addFileUploaded=" + addFileUploaded + "\n");
        sb.append("advanceShippingDisabled=" + advanceShippingDisabled + "\n");
        sb.append("partnerName=" + partnerName + "\n");
        sb.append("partnerIdentifier=" + partnerIdentifier + "\n");
        // sb.append("preferredLanguages="+preferredLanguages+"\n");
        sb.append("password=" + password + "\n");
        sb.append("compantName=" + companyName + "\n");
        sb.append("phoneNumber=" + phoneNumber + "\n");
        sb.append("extension=" + extension + "\n");
        sb.append("shipAddress1=" + shipAddress1 + "\n");
        sb.append("shipAddress2=" + shipAddress2 + "\n");
        sb.append("shipCity=" + shipCity + "\n");
        sb.append("shipState=" + shipState + "\n");
        sb.append("shipPostalCode=" + shipPostalCode + "\n");
        sb.append("shipCountry=" + shipCountry + "\n");
        sb.append("billAddress1=" + billAddress1 + "\n");
        sb.append("billAddress2=" + billAddress2 + "\n");
        sb.append("billCity=" + billCity + "\n");
        sb.append("billState=" + billState + "\n");
        sb.append("billPostalCode=" + billPostalCode + "\n");
        sb.append("billCountry=" + billCountry + "\n");
        sb.append("Invoice=" + getInvoice() + "\n");
        sb.append("UserRole=" + getUserRole() + "\n");

        return sb.toString();
    }

    public class Invoice {

        private String invoiceCustomerName;
        private String invoiceCompanyTaxCode;
        private String invoiceAddress;
        private String invoiceBankName;
        private String invoiceBankAccount;
        private String invoiceShipCustomerName;
        private String invoiceShipCity;
        private String invoiceShipShippingAddress;
        private String invoiceShipPostCode;
        private String invoiceShipContactPerson;
        private String invoiceShipContactPhoneNumber;

        public String getInvoiceCustomerName() {
            return invoiceCustomerName;
        }

        public void setInvoiceCustomerName(String invoiceCustomerName) {
            this.invoiceCustomerName = invoiceCustomerName;
        }

        public String getInvoiceCompanyTaxCode() {
            return invoiceCompanyTaxCode;
        }

        public void setInvoiceCompanyTaxCode(String invoiceCompanyTaxCode) {
            this.invoiceCompanyTaxCode = invoiceCompanyTaxCode;
        }

        public String getInvoiceAddress() {
            return invoiceAddress;
        }

        public void setInvoiceAddress(String invoiceAddress) {
            this.invoiceAddress = invoiceAddress;
        }

        public String getInvoiceBankName() {
            return invoiceBankName;
        }

        public void setInvoiceBankName(String invoiceBankName) {
            this.invoiceBankName = invoiceBankName;
        }

        public String getInvoiceBankAccount() {
            return invoiceBankAccount;
        }

        public void setInvoiceBankAccount(String invoiceBankAccount) {
            this.invoiceBankAccount = invoiceBankAccount;
        }

        public String getInvoiceShipCustomerName() {
            return invoiceShipCustomerName;
        }

        public void setInvoiceShipCustomerName(String invoiceShipCustomerName) {
            this.invoiceShipCustomerName = invoiceShipCustomerName;
        }

        public String getInvoiceShipCity() {
            return invoiceShipCity;
        }

        public void setInvoiceShipCity(String invoiceShipCity) {
            this.invoiceShipCity = invoiceShipCity;
        }

        public String getInvoiceShipShippingAddress() {
            return invoiceShipShippingAddress;
        }

        public void setInvoiceShipShippingAddress(String invoiceShipShippingAddress) {
            this.invoiceShipShippingAddress = invoiceShipShippingAddress;
        }

        public String getInvoiceShipPostCode() {
            return invoiceShipPostCode;
        }

        public void setInvoiceShipPostCode(String invoiceShipPostCode) {
            this.invoiceShipPostCode = invoiceShipPostCode;
        }

        public String getInvoiceShipContactPerson() {
            return invoiceShipContactPerson;
        }

        public void setInvoiceShipContactPerson(String invoiceShipContactPerson) {
            this.invoiceShipContactPerson = invoiceShipContactPerson;
        }

        public String getInvoiceShipContactPhoneNumber() {
            return invoiceShipContactPhoneNumber;
        }

        public void setInvoiceShipContactPhoneNumber(String invoiceShipContactPhoneNumber) {
            this.invoiceShipContactPhoneNumber = invoiceShipContactPhoneNumber;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append("getInvoiceCustomerName >> " + getInvoiceCustomerName() + "\n");
            sb.append("getInvoiceCompanyTaxCode >> " + getInvoiceCompanyTaxCode() + "\n");
            sb.append("getInvoiceAddress >> " + getInvoiceAddress() + "\n");
            sb.append("getInvoiceBankName >> " + getInvoiceBankName() + "\n");
            sb.append("getInvoiceBankAccount >> " + getInvoiceBankAccount() + "\n");
            sb.append("getInvoiceShipCustomerName >>" + getInvoiceShipCustomerName() + "\n");
            sb.append("getInvoiceShipCity >> " + getInvoiceShipCity() + "\n");
            sb.append("getInvoiceShipShippingAddress >>" + getInvoiceShipShippingAddress() + "\n");
            sb.append("getInvoiceShipPostCode >> " + getInvoiceShipPostCode() + "\n");
            sb.append("getInvoiceShipContactPerson >> " + getInvoiceShipContactPerson() + "\n");
            sb.append("getInvoiceShipContactPhoneNumber >> " + getInvoiceShipContactPhoneNumber() + "\n");
            return sb.toString();
        }
    }

    public class UserRoles {
        private String role;
        private ActionCode actionCode;

        public String getRole() {
            return role;
        }

        public void setRole(String role) {
            this.role = role;
        }

        public ActionCode getActionCode() {
            return actionCode;
        }

        public void setActionCode(ActionCode actionCode) {
            this.actionCode = actionCode;
        }

        @Override
        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append("Role***" + getRole() + "\n");
            sb.append("Action***" + getActionCode() + "\n");
            return sb.toString();
        }
    }

	/**
	 * @return the multipleSoldTo
	 */
	public String[] getMultipleSoldTo() {
		return multipleSoldTo;
	}


	/**
	 * @param multipleSoldTo the multipleSoldTo to set
	 */
	public void setMultipleSoldTo(String[] multipleSoldTo) {
		this.multipleSoldTo = multipleSoldTo;
	}
}
