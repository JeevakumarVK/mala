/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS AgilentConfiguration
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 11:42:13 AM Author: Ramandeep_Singh
 */

import java.util.List;

public class AgilentSearchConfiguration {

    private String       mMdexHost                             = null;
    private String       mMdexPort                             = null;
    private List<String> mEndecaRecordKeySetList               = null;
    private List<String> mEndecaSearchSuggestionRecordKeyList  = null;
    private String       mEacHost                              = null;
    private String       mCasHostName                          = null;

    private String       mLanguageDimensionName                = null;
    private String       mContentTypeDimensionName             = null;
    private String       mContentTypePropertyName              = null;
    private String       mDefautLanguage                       = null;
    private String       mSureFishDimValName                   = null;
    private String       mGenomicsDimValName                   = null;
    private String       mGenesDimValName                      = null;
    private String       mLibraryDimValName                    = null;
    private String       mLibraryDisplayName                   = null;
    private String       mInformationAreasDisplayName          = null;
    private String       mGenomicsDisplayName                  = null;
    private String       mGenesDisplayName                     = null;
    private String       mSureFishDisplayName                  = null;
    private String       mLibraryContentLink                   = null;
    private String       mLocalHost                            = null;
    private int          mRmiPort                              = 0;
    private String       mCytoBandDimValName                   = null;
    private String       mChildProbesDimValName                = null;
    private String       mProductOverviewDimValName            = null;
    private String       mExportLibraryContentType             = null;
    private String       mWebArticlesLeftNavName               = null;
    private String       mGenomicsProductLeftNavName           = null;
    private String       mProductOverviewLeftNavName           = null;
    private String       mLiteratureLeftNavName                = null;
    private String       mSureFishLeftNavName                  = null;
    private String       mSureFishProductLeftNavName           = null;
    private String       mCytobandsLeftNavName                 = null;
    private String       mProbesLeftNavName                    = null;
    private String       mGenesLeftNavName                     = null;
    private String       mChildProbesLeftNavName               = null;
    private long         mLanguageCount                        = 0l;
    private String       mExportLibraryContentTypePropertyName = null;
    private String       mCofalinkForEndecaBasicSearch         = null;

    /**
     * Gets the value of cofalinkForEndecaBasicSearch
     * 
     * @return returns the property cofalinkForEndecaBasicSearch
     */
    public String getCofalinkForEndecaBasicSearch() {
        return mCofalinkForEndecaBasicSearch;
    }

    /**
     * Sets the value of property cofalinkForEndecaBasicSearch with value pCofalinkForEndecaBasicSearch
     * 
     * @param pCofalinkForEndecaBasicSearch
     *            the cofalinkForEndecaBasicSearch to set
     */
    public void setCofalinkForEndecaBasicSearch( String pCofalinkForEndecaBasicSearch) {
        mCofalinkForEndecaBasicSearch = pCofalinkForEndecaBasicSearch;
    }

    /**
     * Gets the value of exportLibraryContentTypePropertyName
     * 
     * @return returns the property exportLibraryContentTypePropertyName
     */
    public String getExportLibraryContentTypePropertyName() {
        return mExportLibraryContentTypePropertyName;
    }

    /**
     * Sets the value of property exportLibraryContentTypePropertyName with value pExportLibraryContentTypePropertyName
     * 
     * @param pExportLibraryContentTypePropertyName
     *            the exportLibraryContentTypePropertyName to set
     */
    public void setExportLibraryContentTypePropertyName( String pExportLibraryContentTypePropertyName) {
        mExportLibraryContentTypePropertyName = pExportLibraryContentTypePropertyName;
    }

    /**
     * Gets the value of childProbesLeftNavName
     * 
     * @return returns the property childProbesLeftNavName
     */
    public String getChildProbesLeftNavName() {
        return mChildProbesLeftNavName;
    }

    /**
     * Sets the value of property childProbesLeftNavName with value pChildProbesLeftNavName
     * 
     * @param pChildProbesLeftNavName
     *            the childProbesLeftNavName to set
     */
    public void setChildProbesLeftNavName( String pChildProbesLeftNavName) {
        mChildProbesLeftNavName = pChildProbesLeftNavName;
    }

    /**
     * Gets the value of childProbesDimValName
     * 
     * @return returns the property childProbesDimValName
     */
    public String getChildProbesDimValName() {
        return mChildProbesDimValName;
    }

    /**
     * Sets the value of property childProbesDimValName with value pChildProbesDimValName
     * 
     * @param pChildProbesDimValName
     *            the childProbesDimValName to set
     */
    public void setChildProbesDimValName( String pChildProbesDimValName) {
        mChildProbesDimValName = pChildProbesDimValName;
    }

    /**
     * Gets the value of productOverviewDimValName
     * 
     * @return returns the property productOverviewDimValName
     */
    public String getProductOverviewDimValName() {
        return mProductOverviewDimValName;
    }

    /**
     * Sets the value of property productOverviewDimValName with value pProductOverviewDimValName
     * 
     * @param pProductOverviewDimValName
     *            the productOverviewDimValName to set
     */
    public void setProductOverviewDimValName( String pProductOverviewDimValName) {
        mProductOverviewDimValName = pProductOverviewDimValName;
    }

    /**
     * Gets the value of languageCount
     * 
     * @return returns the property languageCount
     */
    public long getLanguageCount() {
        return mLanguageCount;
    }

    /**
     * Sets the value of property languageCount with value pLanguageCount
     * 
     * @param pLanguageCount
     *            the languageCount to set
     */
    public void setLanguageCount( long pLanguageCount) {
        mLanguageCount = pLanguageCount;
    }

    /**
     * Gets the value of genesLeftNavName
     * 
     * @return returns the property genesLeftNavName
     */
    public String getGenesLeftNavName() {
        return mGenesLeftNavName;
    }

    /**
     * Sets the value of property genesLeftNavName with value pGenesLeftNavName
     * 
     * @param pGenesLeftNavName
     *            the genesLeftNavName to set
     */
    public void setGenesLeftNavName( String pGenesLeftNavName) {
        mGenesLeftNavName = pGenesLeftNavName;
    }

    /**
     * Gets the value of webArticlesLeftNavName
     * 
     * @return returns the property webArticlesLeftNavName
     */
    public String getWebArticlesLeftNavName() {
        return mWebArticlesLeftNavName;
    }

    /**
     * Sets the value of property webArticlesLeftNavName with value pWebArticlesLeftNavName
     * 
     * @param pWebArticlesLeftNavName
     *            the webArticlesLeftNavName to set
     */
    public void setWebArticlesLeftNavName( String pWebArticlesLeftNavName) {
        mWebArticlesLeftNavName = pWebArticlesLeftNavName;
    }

    /**
     * Gets the value of genomicsProductLeftNavName
     * 
     * @return returns the property genomicsProductLeftNavName
     */
    public String getGenomicsProductLeftNavName() {
        return mGenomicsProductLeftNavName;
    }

    /**
     * Sets the value of property genomicsProductLeftNavName with value pGenomicsProductLeftNavName
     * 
     * @param pGenomicsProductLeftNavName
     *            the genomicsProductLeftNavName to set
     */
    public void setGenomicsProductLeftNavName( String pGenomicsProductLeftNavName) {
        mGenomicsProductLeftNavName = pGenomicsProductLeftNavName;
    }

    /**
     * Gets the value of productOverviewLeftNavName
     * 
     * @return returns the property productOverviewLeftNavName
     */
    public String getProductOverviewLeftNavName() {
        return mProductOverviewLeftNavName;
    }

    /**
     * Sets the value of property productOverviewLeftNavName with value pProductOverviewLeftNavName
     * 
     * @param pProductOverviewLeftNavName
     *            the productOverviewLeftNavName to set
     */
    public void setProductOverviewLeftNavName( String pProductOverviewLeftNavName) {
        mProductOverviewLeftNavName = pProductOverviewLeftNavName;
    }

    /**
     * Gets the value of literatureLeftNavName
     * 
     * @return returns the property literatureLeftNavName
     */
    public String getLiteratureLeftNavName() {
        return mLiteratureLeftNavName;
    }

    /**
     * Sets the value of property literatureLeftNavName with value pLiteratureLeftNavName
     * 
     * @param pLiteratureLeftNavName
     *            the literatureLeftNavName to set
     */
    public void setLiteratureLeftNavName( String pLiteratureLeftNavName) {
        mLiteratureLeftNavName = pLiteratureLeftNavName;
    }

    /**
     * Gets the value of sureFishLeftNavName
     * 
     * @return returns the property sureFishLeftNavName
     */
    public String getSureFishLeftNavName() {
        return mSureFishLeftNavName;
    }

    /**
     * Sets the value of property sureFishLeftNavName with value pSureFishLeftNavName
     * 
     * @param pSureFishLeftNavName
     *            the sureFishLeftNavName to set
     */
    public void setSureFishLeftNavName( String pSureFishLeftNavName) {
        mSureFishLeftNavName = pSureFishLeftNavName;
    }

    /**
     * Gets the value of sureFishProductLeftNavName
     * 
     * @return returns the property sureFishProductLeftNavName
     */
    public String getSureFishProductLeftNavName() {
        return mSureFishProductLeftNavName;
    }

    /**
     * Sets the value of property sureFishProductLeftNavName with value pSureFishProductLeftNavName
     * 
     * @param pSureFishProductLeftNavName
     *            the sureFishProductLeftNavName to set
     */
    public void setSureFishProductLeftNavName( String pSureFishProductLeftNavName) {
        mSureFishProductLeftNavName = pSureFishProductLeftNavName;
    }

    /**
     * Gets the value of cytobandsLeftNavName
     * 
     * @return returns the property cytobandsLeftNavName
     */
    public String getCytobandsLeftNavName() {
        return mCytobandsLeftNavName;
    }

    /**
     * Sets the value of property cytobandsLeftNavName with value pCytobandsLeftNavName
     * 
     * @param pCytobandsLeftNavName
     *            the cytobandsLeftNavName to set
     */
    public void setCytobandsLeftNavName( String pCytobandsLeftNavName) {
        mCytobandsLeftNavName = pCytobandsLeftNavName;
    }

    /**
     * Gets the value of probesLeftNavName
     * 
     * @return returns the property probesLeftNavName
     */
    public String getProbesLeftNavName() {
        return mProbesLeftNavName;
    }

    /**
     * Sets the value of property probesLeftNavName with value pProbesLeftNavName
     * 
     * @param pProbesLeftNavName
     *            the probesLeftNavName to set
     */
    public void setProbesLeftNavName( String pProbesLeftNavName) {
        mProbesLeftNavName = pProbesLeftNavName;
    }

    /**
     * Gets the value of exportLibraryContentType
     * 
     * @return returns the property exportLibraryContentType
     */
    public String getExportLibraryContentType() {
        return mExportLibraryContentType;
    }

    /**
     * Sets the value of property exportLibraryContentType with value pExportLibraryContentType
     * 
     * @param pExportLibraryContentType
     *            the exportLibraryContentType to set
     */
    public void setExportLibraryContentType( String pExportLibraryContentType) {
        mExportLibraryContentType = pExportLibraryContentType;
    }

    /**
     * Gets the value of cytoBandDimValName
     * 
     * @return returns the property cytoBandDimValName
     */
    public String getCytoBandDimValName() {
        return mCytoBandDimValName;
    }

    /**
     * Sets the value of property cytoBandDimValName with value pCytoBandDimValName
     * 
     * @param pCytoBandDimValName
     *            the cytoBandDimValName to set
     */
    public void setCytoBandDimValName( String pCytoBandDimValName) {
        mCytoBandDimValName = pCytoBandDimValName;
    }

    /**
     * Gets the value of rmiPort
     * 
     * @return returns the property rmiPort
     */
    public int getRmiPort() {
        return mRmiPort;
    }

    /**
     * Sets the value of property rmiPort with value pRmiPort
     * 
     * @param pRmiPort
     *            the rmiPort to set
     */
    public void setRmiPort( int pRmiPort) {
        mRmiPort = pRmiPort;
    }

    /**
     * Gets the value of localHost
     * 
     * @return returns the property localHost
     */
    public String getLocalHost() {
        return mLocalHost;
    }

    /**
     * Sets the value of property localHost with value pLocalHost
     * 
     * @param pLocalHost
     *            the localHost to set
     */
    public void setLocalHost( String pLocalHost) {
        mLocalHost = pLocalHost;
    }

    /**
     * Gets the value of languageDimensionName
     * 
     * @return returns the property languageDimensionName
     */
    public String getLanguageDimensionName() {
        return mLanguageDimensionName;
    }

    /**
     * Sets the value of property languageDimensionName with value pLanguageDimensionName
     * 
     * @param pLanguageDimensionName
     *            the languageDimensionName to set
     */
    public void setLanguageDimensionName( String pLanguageDimensionName) {
        mLanguageDimensionName = pLanguageDimensionName;
    }

    /**
     * Gets the value of contentTypeDimensionName
     * 
     * @return returns the property contentTypeDimensionName
     */
    public String getContentTypeDimensionName() {
        return mContentTypeDimensionName;
    }

    /**
     * Sets the value of property contentTypeDimensionName with value pContentTypeDimensionName
     * 
     * @param pContentTypeDimensionName
     *            the contentTypeDimensionName to set
     */
    public void setContentTypeDimensionName( String pContentTypeDimensionName) {
        mContentTypeDimensionName = pContentTypeDimensionName;
    }

    /**
     * Gets the value of contentTyepPropertyName
     * 
     * @return returns the property contentTyepPropertyName
     */
    public String getContentTypePropertyName() {
        return mContentTypePropertyName;
    }

    /**
     * Sets the value of property contentTypePropertyName with value pContentTypePropertyName
     * 
     * @param pContentTypePropertyName
     *            the contentTypePropertyName to set
     */
    public void setContentTypePropertyName( String pContentTypePropertyName) {
        mContentTypePropertyName = pContentTypePropertyName;
    }

    /**
     * Gets the value of defautLanguage
     * 
     * @return returns the property defautLanguage
     */
    public String getDefautLanguage() {
        return mDefautLanguage;
    }

    /**
     * Sets the value of property defautLanguage with value pDefautLanguage
     * 
     * @param pDefautLanguage
     *            the defautLanguage to set
     */
    public void setDefautLanguage( String pDefautLanguage) {
        mDefautLanguage = pDefautLanguage;
    }

    /**
     * Gets the value of sureFishDimValName
     * 
     * @return returns the property sureFishDimValName
     */
    public String getSureFishDimValName() {
        return mSureFishDimValName;
    }

    /**
     * Sets the value of property sureFishDimValName with value pSureFishDimValName
     * 
     * @param pSureFishDimValName
     *            the sureFishDimValName to set
     */
    public void setSureFishDimValName( String pSureFishDimValName) {
        mSureFishDimValName = pSureFishDimValName;
    }

    /**
     * Gets the value of genomicsDimValName
     * 
     * @return returns the property genomicsDimValName
     */
    public String getGenomicsDimValName() {
        return mGenomicsDimValName;
    }

    /**
     * Sets the value of property genomicsDimValName with value pGenomicsDimValName
     * 
     * @param pGenomicsDimValName
     *            the genomicsDimValName to set
     */
    public void setGenomicsDimValName( String pGenomicsDimValName) {
        mGenomicsDimValName = pGenomicsDimValName;
    }

    /**
     * Gets the value of genesDimValName
     * 
     * @return returns the property genesDimValName
     */
    public String getGenesDimValName() {
        return mGenesDimValName;
    }

    /**
     * Sets the value of property genesDimValName with value pGenesDimValName
     * 
     * @param pGenesDimValName
     *            the genesDimValName to set
     */
    public void setGenesDimValName( String pGenesDimValName) {
        mGenesDimValName = pGenesDimValName;
    }

    /**
     * Gets the value of libraryDimValName
     * 
     * @return returns the property libraryDimValName
     */
    public String getLibraryDimValName() {
        return mLibraryDimValName;
    }

    /**
     * Sets the value of property libraryDimValName with value pLibraryDimValName
     * 
     * @param pLibraryDimValName
     *            the libraryDimValName to set
     */
    public void setLibraryDimValName( String pLibraryDimValName) {
        mLibraryDimValName = pLibraryDimValName;
    }

    /**
     * Gets the value of libraryDisplayName
     * 
     * @return returns the property libraryDisplayName
     */
    public String getLibraryDisplayName() {
        return mLibraryDisplayName;
    }

    /**
     * Sets the value of property libraryDisplayName with value pLibraryDisplayName
     * 
     * @param pLibraryDisplayName
     *            the libraryDisplayName to set
     */
    public void setLibraryDisplayName( String pLibraryDisplayName) {
        mLibraryDisplayName = pLibraryDisplayName;
    }

    /**
     * Gets the value of informationAreasDisplayName
     * 
     * @return returns the property informationAreasDisplayName
     */
    public String getInformationAreasDisplayName() {
        return mInformationAreasDisplayName;
    }

    /**
     * Sets the value of property informationAreasDisplayName with value pInformationAreasDisplayName
     * 
     * @param pInformationAreasDisplayName
     *            the informationAreasDisplayName to set
     */
    public void setInformationAreasDisplayName( String pInformationAreasDisplayName) {
        mInformationAreasDisplayName = pInformationAreasDisplayName;
    }

    /**
     * Gets the value of genomicsDisplayName
     * 
     * @return returns the property genomicsDisplayName
     */
    public String getGenomicsDisplayName() {
        return mGenomicsDisplayName;
    }

    /**
     * Sets the value of property genomicsDisplayName with value pGenomicsDisplayName
     * 
     * @param pGenomicsDisplayName
     *            the genomicsDisplayName to set
     */
    public void setGenomicsDisplayName( String pGenomicsDisplayName) {
        mGenomicsDisplayName = pGenomicsDisplayName;
    }

    /**
     * Gets the value of genesDisplayName
     * 
     * @return returns the property genesDisplayName
     */
    public String getGenesDisplayName() {
        return mGenesDisplayName;
    }

    /**
     * Sets the value of property genesDisplayName with value pGenesDisplayName
     * 
     * @param pGenesDisplayName
     *            the genesDisplayName to set
     */
    public void setGenesDisplayName( String pGenesDisplayName) {
        mGenesDisplayName = pGenesDisplayName;
    }

    /**
     * Gets the value of sureFishDisplayName
     * 
     * @return returns the property sureFishDisplayName
     */
    public String getSureFishDisplayName() {
        return mSureFishDisplayName;
    }

    /**
     * Sets the value of property sureFishDisplayName with value pSureFishDisplayName
     * 
     * @param pSureFishDisplayName
     *            the sureFishDisplayName to set
     */
    public void setSureFishDisplayName( String pSureFishDisplayName) {
        mSureFishDisplayName = pSureFishDisplayName;
    }

    /**
     * Gets the value of eacHost
     * 
     * @return returns the property eacHost
     */
    public String getEacHost() {
        return mEacHost;
    }

    /**
     * Sets the value of property eacHost with value pEacHost
     * 
     * @param pEacHost
     *            the eacHost to set
     */
    public void setEacHost( String pEacHost) {
        mEacHost = pEacHost;
    }

    /**
     * Gets the value of casHostName
     * 
     * @return returns the property casHostName
     */
    public String getCasHostName() {
        return mCasHostName;
    }

    /**
     * Sets the value of property casHostName with value pCasHostName
     * 
     * @param pCasHostName
     *            the casHostName to set
     */
    public void setCasHostName( String pCasHostName) {
        mCasHostName = pCasHostName;
    }

    /**
     * Gets the value of mdexHost
     * 
     * @return returns the property mdexHost
     */
    public String getMdexHost() {
        return mMdexHost;
    }

    /**
     * Sets the value of property mdexHost with value pMdexHost
     * 
     * @param pMdexHost
     *            the mdexHost to set
     */
    public void setMdexHost( String pMdexHost) {
        mMdexHost = pMdexHost;
    }

    /**
     * Gets the value of mdexPort
     * 
     * @return returns the property mdexPort
     */
    public String getMdexPort() {
        return mMdexPort;
    }

    /**
     * Sets the value of property mdexPort with value pMdexPort
     * 
     * @param pMdexPort
     *            the mdexPort to set
     */
    public void setMdexPort( String pMdexPort) {
        mMdexPort = pMdexPort;
    }

    /**
     * Gets the value of endecaRecordKeySetList
     * 
     * @return returns the property endecaRecordKeySetList
     */
    public List<String> getEndecaRecordKeySetList() {
        return mEndecaRecordKeySetList;
    }

    /**
     * Sets the value of property endecaRecordKeySetList with value pEndecaRecordKeySetList
     * 
     * @param pEndecaRecordKeySetList
     *            the endecaRecordKeySetList to set
     */
    public void setEndecaRecordKeySetList( List<String> pEndecaRecordKeySetList) {
        mEndecaRecordKeySetList = pEndecaRecordKeySetList;
    }

    /**
     * Gets the value of endecaSearchSuggestionRecordKeyList
     * 
     * @return returns the property endecaSearchSuggestionRecordKeyList
     */
    public List<String> getEndecaSearchSuggestionRecordKeyList() {
        return mEndecaSearchSuggestionRecordKeyList;
    }

    /**
     * Sets the value of property endecaSearchSuggestionRecordKeyList with value pEndecaSearchSuggestionRecordKeyList
     * 
     * @param pEndecaSearchSuggestionRecordKeyList
     *            the endecaSearchSuggestionRecordKeyList to set
     */
    public void setEndecaSearchSuggestionRecordKeyList( List<String> pEndecaSearchSuggestionRecordKeyList) {
        mEndecaSearchSuggestionRecordKeyList = pEndecaSearchSuggestionRecordKeyList;
    }

    /**
     * Gets the value of libraryContentLink
     * 
     * @return returns the property libraryContentLink
     */
    public String getLibraryContentLink() {
        return mLibraryContentLink;
    }

    /**
     * Sets the value of property libraryContentLink with value pLibraryContentLink
     * 
     * @param pLibraryContentLink
     *            the libraryContentLink to set
     */
    public void setLibraryContentLink( String pLibraryContentLink) {
        mLibraryContentLink = pLibraryContentLink;
    }

}
