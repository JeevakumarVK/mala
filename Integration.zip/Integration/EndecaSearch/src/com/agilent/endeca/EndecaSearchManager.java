/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca;

/**
 * <p>
 * EndecaSearchManager class is an Atg component which act as interaction layer between Atg and Endeca Presentation API , component interact with
 * HttpENEConnection class to create connection with MDEX engine , execute Endeca query and get the Endeca result as ENEQueryResult object EndecaSearchManager
 * use EndecaSearchOutput and EndecaSearchSuggestionOutput VO classes to get data for search type and query and store it in EndecaSearchWrapper class.
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 10:43:57 AM Author: Ramandeep_Singh
 */

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import atg.nucleus.GenericService;

import com.agilent.endeca.query.common.Constants;
import com.agilent.endeca.query.common.EndecaSearchLeftNavVO;
import com.agilent.endeca.query.common.EndecaSearchOutput;
import com.agilent.endeca.query.common.EndecaSearchRecordVO;
import com.agilent.endeca.query.common.EndecaSearchSuggestionOutput;
import com.agilent.endeca.query.common.EndecaSearchSuggestionWrapper;
import com.agilent.endeca.query.common.EndecaSearchWrapper;
import com.endeca.navigation.AggrERec;
import com.endeca.navigation.AggrERecList;
import com.endeca.navigation.AssocDimLocations;
import com.endeca.navigation.AssocDimLocationsList;
import com.endeca.navigation.DimLocation;
import com.endeca.navigation.DimVal;
import com.endeca.navigation.DimValList;
import com.endeca.navigation.Dimension;
import com.endeca.navigation.DimensionList;
import com.endeca.navigation.ENEQuery;
import com.endeca.navigation.ENEQueryException;
import com.endeca.navigation.ENEQueryResults;
import com.endeca.navigation.ERec;
import com.endeca.navigation.ERecList;
import com.endeca.navigation.ESearchAutoSuggestion;
import com.endeca.navigation.ESearchDYMSuggestion;
import com.endeca.navigation.ESearchReport;
import com.endeca.navigation.HttpENEConnection;
import com.endeca.navigation.Navigation;
import com.endeca.navigation.Property;
import com.endeca.navigation.PropertyMap;
import com.endeca.navigation.UrlENEQuery;
import com.endeca.navigation.UrlENEQueryParseException;

public class EndecaSearchManager extends GenericService {

    private String                     mMdexHost                            = null;
    private String                     mMdexPort                            = null;
    private HttpENEConnection          httpEndecaConnection                 = null;
    private List<String>               mEndecaRecordKeySetList              = null;
    private List<String>               mEndecaSearchSuggestionRecordKeyList = null;
    private AgilentSearchConfiguration mSearchConfiguration                 = null;

    /**
     * Gets the value of mdexHost
     * 
     * @return returns the property mdexHost
     */
    public String getMdexHost() {
        return mMdexHost;
    }

    /**
     * Sets the value of property mdexHost with value pMdexHost
     * 
     * @param pMdexHost
     *            the mdexHost to set
     */
    public void setMdexHost( String pMdexHost) {
        mMdexHost = pMdexHost;
    }

    /**
     * Gets the value of mdexPort
     * 
     * @return returns the property mdexPort
     */
    public String getMdexPort() {
        return mMdexPort;
    }

    /**
     * Sets the value of property mdexPort with value pMdexPort
     * 
     * @param pMdexPort
     *            the mdexPort to set
     */
    public void setMdexPort( String pMdexPort) {
        mMdexPort = pMdexPort;
    }

    public HttpENEConnection getHttpENEConnection() {

        httpEndecaConnection = new HttpENEConnection(mMdexHost, mMdexPort);
        return httpEndecaConnection;

        // logging to do task

    }

    /**
     * Gets the value of endecaRecordKeySetList
     * 
     * @return returns the property endecaRecordKeySetList
     */
    public List<String> getEndecaRecordKeySetList() {
        return mEndecaRecordKeySetList;
    }

    /**
     * Sets the value of property endecaRecordKeySetList with value pEndecaRecordKeySetList
     * 
     * @param pEndecaRecordKeySetList
     *            the endecaRecordKeySetList to set
     */
    public void setEndecaRecordKeySetList( List<String> pEndecaRecordKeySetList) {
        mEndecaRecordKeySetList = pEndecaRecordKeySetList;
    }

    /**
     * Gets the value of endecaSearchSuggestionRecordKeyList
     * 
     * @return returns the property endecaSearchSuggestionRecordKeyList
     */
    public List<String> getEndecaSearchSuggestionRecordKeyList() {
        return mEndecaSearchSuggestionRecordKeyList;
    }

    /**
     * Sets the value of property endecaSearchSuggestionRecordKeyList with value pEndecaSearchSuggestionRecordKeyList
     * 
     * @param pEndecaSearchSuggestionRecordKeyList
     *            the endecaSearchSuggestionRecordKeyList to set
     */
    public void setEndecaSearchSuggestionRecordKeyList( List<String> pEndecaSearchSuggestionRecordKeyList) {
        mEndecaSearchSuggestionRecordKeyList = pEndecaSearchSuggestionRecordKeyList;
    }

    /**
     * Gets the value of searchConfiguration
     * 
     * @return returns the property searchConfiguration
     */
    public AgilentSearchConfiguration getSearchConfiguration() {
        return mSearchConfiguration;
    }

    /**
     * Sets the value of property searchConfiguration with value pSearchConfiguration
     * 
     * @param pSearchConfiguration
     *            the searchConfiguration to set
     */
    public void setSearchConfiguration( AgilentSearchConfiguration pSearchConfiguration) {
        mSearchConfiguration = pSearchConfiguration;
    }

    public EndecaSearchWrapper searchEndecaQuery( EndecaSearchOutput ovo, String query) {
        EndecaSearchWrapper esw = null;
        HttpENEConnection endecaConnection = getHttpENEConnection();
        ENEQuery eneQuery = setENEQuery(query);
        eneQuery.setNavNumERecs(ovo.getSearchItemsCountPerPage());
        ENEQueryResults eneQueryResult = getENEQueryResults(endecaConnection, eneQuery);
        // removeNavigationIDsForBaseDimensions(ovo);
        // populateNavigationIDsForBasicSearch(eneQueryResult, query, ovo);

        if (eneQuery.toString().contains("&Nu")) {
            esw = parseAggQueryResults(eneQueryResult);
        } else {
            esw = parseQueryResults(eneQueryResult);
        }

        if (esw.getAutoCorrection() != null) {
            try {
                ovo.setSearchTerm(URLEncoder.encode(esw.getAutoCorrection(), Constants.ENCODING_FORMAT));
            } catch (UnsupportedEncodingException exception) {
                vlogError(exception, "UnsupportedEncodingException");
            }
        }
        esw.setNavigationMap(ovo.getLeftNavMap());
        if (esw.getAutoCorrection() != null) {
            try {
                ovo.setSearchTerm(URLDecoder.decode(ovo.getSearchTerm(), Constants.ENCODING_FORMAT));
            } catch (UnsupportedEncodingException exception) {
                vlogError(exception, "UnsupportedEncodingException");
            }
        }
        return esw;
    }

    private ENEQuery setENEQuery( String searchQueryText) {

        ENEQuery searchQuery = null;
        try {

            searchQuery = new UrlENEQuery(searchQueryText, Constants.ENCODING_FORMAT);
        } catch (UrlENEQueryParseException exception) {

            vlogError("EndecaSearchManager - [setENEQuery()] = UrlENEQueryParseException \n" + exception);
        }
        // Set query so that only explicitly requested refinements are returned
        if (searchQuery != null) {
            searchQuery.setNavAllRefinements(false);

        }

        return searchQuery;
    }

    private ENEQueryResults getENEQueryResults( HttpENEConnection endecaConnection, ENEQuery eneQuery) {

        // Make ENE request
        ENEQueryResults eneQueryResults = null;
        try {
            eneQueryResults = endecaConnection.query(eneQuery);
        } catch (ENEQueryException exception) {
            vlogError("EndecaSearchManager - [getENEQueryResults()] = ENEQueryException \n" + exception);
        }

        return eneQueryResults;
    }

    private EndecaSearchWrapper parseQueryResults( ENEQueryResults eneQueryResults) {
        // Get the total compute time
        // double responseTime = eneQueryResults.getTotalNetworkAndComputeTime();
//        if (eneQueryResults == null)
//            return new EndecaSearchWrapper();

        EndecaSearchWrapper esw = new EndecaSearchWrapper();
        List<EndecaSearchRecordVO> searchResultList = new ArrayList<EndecaSearchRecordVO>();
        
        if(eneQueryResults!=null){
        	Navigation nav = eneQueryResults.getNavigation();
        	// Get ERec Record
        	ERecList records = nav.getERecs();

        	// DYM suggestion
        	if (nav.getESearchReportsComplete() != null && nav.getESearchReportsComplete().size() > 0) {
        		ESearchReport eSearchReport = (ESearchReport) nav.getESearchReportsComplete().get(Constants.BasicSearchInterface);
        		// Did You Mean
        		if (eSearchReport != null && eSearchReport.getDYMSuggestions().size() > 0) {
        			esw.setDYMSuggestion(((ESearchDYMSuggestion) eSearchReport.getDYMSuggestions().get(0)).getTerms());
        		}

        		// AutoCorrection
        		if (eSearchReport != null && eSearchReport.getAutoSuggestions().size() > 0) {
        			esw.setAutoCorrection(((ESearchAutoSuggestion) eSearchReport.getAutoSuggestions().get(0)).getTerms());
        		}

        	}

        	esw.setTotalRecordCount(nav.getTotalNumERecs());
        	// esw.setQueryResponseTime(responseTime);
        	// record Iterator
        	@SuppressWarnings( "unchecked")
        	ListIterator<ERec> recordsIterator = records.listIterator();

        	String recordKey = null;
        	String recordPropertyValue = null;

        	// Loop through record list
        	while (recordsIterator.hasNext()) {

        		ERec record = recordsIterator.next();

        		EndecaSearchRecordVO searchOutput = new EndecaSearchRecordVO();
        		HashMap<String, String> recordFinalMap = new HashMap<String, String>();

        		ListIterator<String> li = getEndecaRecordKeySetList().listIterator();
        		PropertyMap recordProperties = record.getProperties();

        		while (li.hasNext()) {
        			recordKey = li.next().toString();
        			recordPropertyValue = (String) recordProperties.get(recordKey);
        			if (recordKey.equals(getSearchConfiguration().getContentTypePropertyName())) {
        				if (recordPropertyValue != null && recordPropertyValue.equals(getSearchConfiguration().getGenomicsDimValName())) {
        					recordPropertyValue = getSearchConfiguration().getGenomicsDisplayName();
        				}
        				if (recordPropertyValue != null && recordPropertyValue.equals(getSearchConfiguration().getSureFishDimValName())) {
        					recordPropertyValue = getSearchConfiguration().getSureFishDisplayName();
        				}
        			}
        			if (recordPropertyValue != null) {
        				recordFinalMap.put(recordKey.toString(), recordPropertyValue);
        			}

        		}
        		searchOutput.setRecordKeyValueMap(recordFinalMap);

        		searchResultList.add(searchOutput);

        	}
        }
        esw.setEndecaSearchRecordVOList(searchResultList);
        return esw;
    }

    private EndecaSearchWrapper parseAggQueryResults( ENEQueryResults eneQueryResults) {
        // Get the total compute time
        // double responseTime = eneQueryResults.getTotalNetworkAndComputeTime();

        Navigation nav = eneQueryResults.getNavigation();

        EndecaSearchWrapper esw = new EndecaSearchWrapper();
        List<EndecaSearchRecordVO> searchResultList = new ArrayList<EndecaSearchRecordVO>();

        // Get aggregated record list
        AggrERecList aggrecs = nav.getAggrERecs();

        esw.setTotalRecordCount(nav.getTotalNumAggrERecs());

        for ( int i = 0; i < aggrecs.size(); i++) {
            // Get individual aggregated record
            AggrERec aggrec = (AggrERec) aggrecs.get(i);

            ERec eRecRecord = aggrec.getRepresentative();

            // Get all derived properties.
            PropertyMap derivedProps = eRecRecord.getProperties();
            Iterator derivedPropIter = derivedProps.entrySet().iterator();
            // Loop over each derived property,
            // handle as an ordinary property.
            EndecaSearchRecordVO searchOutput = new EndecaSearchRecordVO();
            HashMap<String, String> recordFinalMap = new HashMap<String, String>();
            String recordKey = null;
            String recordPropertyValue = null;

            while (derivedPropIter.hasNext()) {
                Property prop = (Property) derivedPropIter.next();
                // Display property

                // Loop through record list

                recordKey = (String) prop.getKey();
                recordPropertyValue = (String) prop.getValue();
                if (recordKey.equals(getSearchConfiguration().getContentTypePropertyName())) {
                    if (recordPropertyValue != null && recordPropertyValue.equals(getSearchConfiguration().getGenomicsDimValName())) {
                        recordPropertyValue = getSearchConfiguration().getGenomicsDisplayName();
                    }
                    if (recordPropertyValue != null && recordPropertyValue.equals(getSearchConfiguration().getSureFishDimValName())) {
                        recordPropertyValue = getSearchConfiguration().getSureFishDisplayName();
                    }
                }
                if (recordPropertyValue != null) {
                    recordFinalMap.put(recordKey.toString(), recordPropertyValue);
                }

            }
            searchOutput.setRecordKeyValueMap(recordFinalMap);

            searchResultList.add(searchOutput);

        }
        esw.setEndecaSearchRecordVOList(searchResultList);
        return esw;
    }

    public String getBasicSearchQuery( String searchString, long offset) {

        StringBuffer baseQuery = new StringBuffer();
        baseQuery.append("N=" + Constants.NAV_ID);
        baseQuery.append("&Ntk=" + Constants.BasicSearchInterface);
        baseQuery.append("&Ntt=" + searchString);
        baseQuery.append("&Nty=" + Constants.DYM_TRUE);
        baseQuery.append("&Ntx=" + Constants.NTX_ALL);
        baseQuery.append("&No=" + offset);
        return baseQuery.toString();

    }

    /**
     * @param pSearchInputVO
     */
    public void populateNavigationIDsForBasicSearch( String searchTerm, EndecaSearchOutput pSearchOutputVO) {
        ENEQuery eneQuery = setENEQuery(getBasicSearchQuery(searchTerm, 0));
        // Setting to 1 as we only require for getting the Navigation parameters at this stage and not all the records
        eneQuery.setNavNumERecs(1);
        ENEQueryResults eneQueryResult = getENEQueryResults(getHttpENEConnection(), eneQuery);
        populateNavigationIDs(eneQueryResult, getBasicSearchQuery(searchTerm, 0), pSearchOutputVO);
    }

    /**
     * @param pZeroNavigationQuery
     * @param pSearchOutputVO
     */
    private void populateNavigationIDs( ENEQueryResults eneQueryResult, String navigationQuery, EndecaSearchOutput pSearchOutputVO) {
        StringBuffer concatQuery = new StringBuffer();
        concatQuery.append("&Ntk=" + Constants.BasicSearchInterface);
        concatQuery.append("&Ntt=" + pSearchOutputVO.getSearchTerm());
        concatQuery.append("&Nty=" + Constants.DYM_TRUE);
        concatQuery.append(Constants.MODE_MATCHALL);
        String newNavQuery = null;

        List<EndecaSearchLeftNavVO> searchLeftNavGenoList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavSurefishList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavGeneList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavCytoBandList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavExpoLibList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavLibList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavChildProbesList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavProductOverviewList = new ArrayList<EndecaSearchLeftNavVO>();
        List<EndecaSearchLeftNavVO> searchLeftNavTempList = new ArrayList<EndecaSearchLeftNavVO>();

        Map<String, List<EndecaSearchLeftNavVO>> leftNavMap = new LinkedHashMap<String, List<EndecaSearchLeftNavVO>>();

        if (eneQueryResult != null && eneQueryResult.getNavigation() != null && eneQueryResult.getNavigation().getTotalNumERecs() > 0) {
            Navigation nav = eneQueryResult.getNavigation();
            DimensionList dimList = nav.getRefinementDimensions();

            for ( int k = 0; k < dimList.size(); k++) {
                Dimension dim = (Dimension) dimList.get(k);
                populateLanguageNavIdForBasicSearch(dim, navigationQuery, pSearchOutputVO);

            }
            for ( int k = 0; k < dimList.size(); k++) {
                Dimension dim = (Dimension) dimList.get(k);
                if (dim.getName().equals(getSearchConfiguration().getContentTypeDimensionName())) {
                    if (pSearchOutputVO.getLanguageNavID() != null) {
                        newNavQuery = navigationQuery.replace("N=0", "N=" + pSearchOutputVO.getLanguageNavID());
                    } else {
                        newNavQuery = navigationQuery;
                    }
                    ENEQueryResults eneQueryResultForContentType = getENEQueryResults(getHttpENEConnection(), setENEQuery(newNavQuery + "&Ne=" + dim.getId()));
                    Navigation navForContentType = eneQueryResultForContentType.getNavigation();

                    for ( int j = 0; j < navForContentType.getRefinementDimensions().size(); j++) {
                        DimValList dimValList = ((Dimension) navForContentType.getRefinementDimensions().get(j)).getRefinements();
                        if (dimValList.size() > 0) {
                            populateContentTypeNavId(dimValList, pSearchOutputVO, concatQuery, searchLeftNavGenoList, searchLeftNavSurefishList,
                                    searchLeftNavGeneList, searchLeftNavCytoBandList, searchLeftNavChildProbesList, searchLeftNavProductOverviewList);

                        }
                    }
                }
                if (dim.getName().equals(getSearchConfiguration().getExportLibraryContentType())) {
                    if (pSearchOutputVO.getLanguageNavID() != null) {
                        newNavQuery = navigationQuery.replace("N=0", "N=" + pSearchOutputVO.getLanguageNavID());
                    } else {
                        newNavQuery = navigationQuery;
                    }
                    ENEQueryResults eneQueryResultForExpLibContentType = getENEQueryResults(getHttpENEConnection(),
                            setENEQuery(newNavQuery + "&Ne=" + dim.getId()));
                    Navigation navForExpLibContentType = eneQueryResultForExpLibContentType.getNavigation();
                    searchLeftNavExpoLibList = new ArrayList<EndecaSearchLeftNavVO>();
                    populateExpoLibNavId(navForExpLibContentType, pSearchOutputVO, concatQuery, searchLeftNavExpoLibList);

                }
                if (dim.getName().equals(getSearchConfiguration().getLibraryDimValName())) {
                    if (pSearchOutputVO.getLanguageNavID() != null) {
                        newNavQuery = navigationQuery.replace("N=0", "N=" + pSearchOutputVO.getLanguageNavID());
                    } else {
                        newNavQuery = navigationQuery;
                    }
                    ENEQueryResults eneQueryResultForLibContentType = getENEQueryResults(getHttpENEConnection(),
                            setENEQuery(newNavQuery + "&Ne=" + dim.getId()));
                    Navigation navForLibContentType = eneQueryResultForLibContentType.getNavigation();
                    searchLeftNavLibList = new ArrayList<EndecaSearchLeftNavVO>();
                    populateLibraryNavId(navForLibContentType, pSearchOutputVO, concatQuery, searchLeftNavLibList);

                }

            }

            makeLeftNavigationMap(leftNavMap, searchLeftNavGenoList, searchLeftNavSurefishList, searchLeftNavGeneList, searchLeftNavCytoBandList,
                    searchLeftNavExpoLibList, searchLeftNavLibList, searchLeftNavChildProbesList, searchLeftNavProductOverviewList, searchLeftNavTempList);

            // Populating those navigations which were not part of refinements
            populateNoRefinementNav(leftNavMap, eneQueryResult, pSearchOutputVO, nav, concatQuery);

            pSearchOutputVO.setLeftNavMap(leftNavMap);

        } else {

            // Even if there are zero records returned, there can be a DYM suggestion

            if (eneQueryResult != null && eneQueryResult.getNavigation() != null && eneQueryResult.getNavigation().getESearchReportsComplete() != null
                    && eneQueryResult.getNavigation().getESearchReportsComplete().size() > 0) {
                ESearchReport eSearchReport = (ESearchReport) eneQueryResult.getNavigation().getESearchReportsComplete().get(Constants.BasicSearchInterface);
                // Did You Mean
                if (eSearchReport != null && eSearchReport.getDYMSuggestions().size() > 0) {
                    pSearchOutputVO.setDYMSuggestion(((ESearchDYMSuggestion) eSearchReport.getDYMSuggestions().get(0)).getTerms());
                }
            }

            // setting Language Id as null on getting no dimension List from navigation object
            pSearchOutputVO.setLanguageNavID(null);
        }
    }

    private EndecaSearchLeftNavVO addToMakeLeftNavList( PropertyMap propMap, String dimName, EndecaSearchOutput eso, long dimId, String commonQuery) {
        String dimSize = null;
        dimSize = (String) propMap.get(Constants.DIM_SIZE_KEY_NAME);
        EndecaSearchLeftNavVO esLNVO = new EndecaSearchLeftNavVO();
        esLNVO.setDimensionName(dimName);
        esLNVO.setDimensionURL("N=" + eso.getLanguageNavID() + "+" + dimId + commonQuery);
        esLNVO.setDimensionSize(dimSize);
        return esLNVO;

    }

    private void populateNoRefinementNav( Map<String, List<EndecaSearchLeftNavVO>> leftNavMap, ENEQueryResults eneQueryResult,
            EndecaSearchOutput pSearchOutputVO, Navigation nav, StringBuffer concatQuery) {
        if (pSearchOutputVO.getLanguageNavID() == null) {
            // Get from first record as all records belong to the same language since we didn't language get in refinements
            ERec firstRecord = (ERec) eneQueryResult.getNavigation().getERecs().get(0);
            AssocDimLocationsList assocDimList = firstRecord.getDimValues();
            AssocDimLocations assocDimLocations = assocDimList.getAssocDimLocations(getSearchConfiguration().getLanguageDimensionName());
            if (assocDimLocations != null) {
                if (((DimLocation) assocDimLocations.get(0)).getDimValue().getName().equals(pSearchOutputVO.getUserLanguage())) {
                    pSearchOutputVO.setLanguageNavID(((DimLocation) assocDimLocations.get(0)).getDimValue().getId());
                }
            }
        }
        if (pSearchOutputVO.getSureFishDimValId() == null && pSearchOutputVO.getGenomicsDimValId() == null && pSearchOutputVO.getLibraryDimValId() == null
                && pSearchOutputVO.getGeneDimValId() == null && pSearchOutputVO.getExportLibraryDimValId() == null) {
            String contentType = "";
            DimVal dimVal = null;
            // Get from first record as all records belong to the same content-type since we didn't get content-type in refinements
            ERec firstRecord = (ERec) eneQueryResult.getNavigation().getERecs().get(0);
            AssocDimLocationsList assocDimList = firstRecord.getDimValues();
            AssocDimLocations assocDimLocations = assocDimList.getAssocDimLocations(getSearchConfiguration().getContentTypeDimensionName());
            if (assocDimLocations != null) {
                dimVal = ((DimLocation) assocDimLocations.get(0)).getDimValue();
                contentType = dimVal.getName();
            }
            if (dimVal != null && contentType != null && contentType.equals(getSearchConfiguration().getSureFishDimValName())) {
                pSearchOutputVO.setSureFishDimValId(dimVal.getId());
                List<EndecaSearchLeftNavVO> searchLeftNavList = new ArrayList<EndecaSearchLeftNavVO>();
                EndecaSearchLeftNavVO esLNVO = new EndecaSearchLeftNavVO();
                esLNVO.setDimensionName(getSearchConfiguration().getSureFishProductLeftNavName());
                esLNVO.setDimensionURL("N=" + pSearchOutputVO.getLanguageNavID() + "+" + dimVal.getId() + concatQuery);
                if (pSearchOutputVO.getLanguageNavID() != null) {
                    esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs() / getSearchConfiguration().getLanguageCount()));
                } else {
                    esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs()));
                }

                searchLeftNavList.add(esLNVO);
                leftNavMap.put(getSearchConfiguration().getSureFishLeftNavName(), searchLeftNavList);
            }
            if (dimVal != null && contentType != null && contentType.equals(getSearchConfiguration().getGenomicsDimValName())) {
                pSearchOutputVO.setGenomicsDimValId(dimVal.getId());
                List<EndecaSearchLeftNavVO> searchLeftNavList = new ArrayList<EndecaSearchLeftNavVO>();
                EndecaSearchLeftNavVO esLNVO = new EndecaSearchLeftNavVO();
                esLNVO.setDimensionName(getSearchConfiguration().getGenomicsProductLeftNavName());
                esLNVO.setDimensionURL("N=" + pSearchOutputVO.getLanguageNavID() + "+" + dimVal.getId() + concatQuery);
                if (pSearchOutputVO.getLanguageNavID() != null) {
                    esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs() / getSearchConfiguration().getLanguageCount()));
                } else {
                    esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs()));
                }

                searchLeftNavList.add(esLNVO);
                leftNavMap.put(getSearchConfiguration().getWebArticlesLeftNavName(), searchLeftNavList);
            }
            if (dimVal != null && contentType != null && contentType.equals(getSearchConfiguration().getLibraryDimValName())) {
                pSearchOutputVO.setLibraryDimValId(dimVal.getId());
                String dimensionName = null;
                AssocDimLocations assocDimLocations1 = assocDimList.getAssocDimLocations(getSearchConfiguration().getExportLibraryContentType());
                if (assocDimLocations1 == null) {
                    assocDimLocations1 = assocDimList.getAssocDimLocations(getSearchConfiguration().getLibraryDimValName());
                }
                if (assocDimLocations1 != null) {
                    dimensionName = ((DimLocation) assocDimLocations1.get(0)).getDimValue().getName();
                    List<EndecaSearchLeftNavVO> searchLeftNavList = new ArrayList<EndecaSearchLeftNavVO>();
                    EndecaSearchLeftNavVO esLNVO = new EndecaSearchLeftNavVO();
                    esLNVO.setDimensionName(dimensionName);
                    esLNVO.setDimensionURL("N=" + pSearchOutputVO.getLanguageNavID() + "+" + dimVal.getId() + concatQuery);

                    esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs() / getSearchConfiguration().getLanguageCount()));

                    searchLeftNavList.add(esLNVO);
                    if (dimensionName.equals(Constants.COFA_DIM_NAME)) {
                        // do nothing
                    } else {
                        leftNavMap.put(getSearchConfiguration().getLiteratureLeftNavName(), searchLeftNavList);
                    }
                }
            }
            if (dimVal != null && contentType != null && contentType.equals(getSearchConfiguration().getCytoBandDimValName())) {
                pSearchOutputVO.setCytoBandsDimValId(dimVal.getId());
            }
            if (dimVal != null && contentType != null && contentType.equals(getSearchConfiguration().getGenesDimValName())) {
                pSearchOutputVO.setGeneDimValId(dimVal.getId());
                List<EndecaSearchLeftNavVO> searchLeftNavList = new ArrayList<EndecaSearchLeftNavVO>();
                EndecaSearchLeftNavVO esLNVO = new EndecaSearchLeftNavVO();
                esLNVO.setDimensionName(getSearchConfiguration().getGenesDisplayName());
                esLNVO.setDimensionURL("N=" + pSearchOutputVO.getLanguageNavID() + "+" + dimVal.getId() + concatQuery);
                esLNVO.setDimensionSize(String.valueOf(nav.getTotalNumERecs() / getSearchConfiguration().getLanguageCount()));
                searchLeftNavList.add(esLNVO);
                leftNavMap.put(getSearchConfiguration().getSureFishLeftNavName(), searchLeftNavList);
            }

        }

    }

    private void makeLeftNavigationMap( Map<String, List<EndecaSearchLeftNavVO>> leftNavMap, List<EndecaSearchLeftNavVO> searchLeftNavGenoList,
            List<EndecaSearchLeftNavVO> searchLeftNavSurefishList, List<EndecaSearchLeftNavVO> searchLeftNavGeneList,
            List<EndecaSearchLeftNavVO> searchLeftNavCytoBandList, List<EndecaSearchLeftNavVO> searchLeftNavExpoLibList,
            List<EndecaSearchLeftNavVO> searchLeftNavLibList, List<EndecaSearchLeftNavVO> searchLeftNavChildProbesList,
            List<EndecaSearchLeftNavVO> searchLeftNavProductOverviewList, List<EndecaSearchLeftNavVO> searchLeftNavTempList) {
        // making combined list for Web Article Left Navigation display

        if (searchLeftNavGenoList.size() > 0) {
            searchLeftNavTempList.addAll(searchLeftNavGenoList);
        }
        if (searchLeftNavProductOverviewList.size() > 0) {
            searchLeftNavTempList.addAll(searchLeftNavProductOverviewList);
        }
        if (searchLeftNavLibList.size() > 0) {
            searchLeftNavTempList.addAll(searchLeftNavLibList);
        }

        if (searchLeftNavTempList.size() > 0) {
            leftNavMap.put(getSearchConfiguration().getWebArticlesLeftNavName(), searchLeftNavTempList);
        }

        // making combined list for Literature Left Navigation display
        if (searchLeftNavExpoLibList.size() > 0) {
            leftNavMap.put(getSearchConfiguration().getLiteratureLeftNavName(), searchLeftNavExpoLibList);
        }

        // making combined list to for SureFish Left Navigation display
        List<EndecaSearchLeftNavVO> searchLeftNavTemp2List = new ArrayList<EndecaSearchLeftNavVO>();
        if (searchLeftNavSurefishList.size() > 0) {
            searchLeftNavTemp2List.addAll(searchLeftNavSurefishList);
        }
        if (searchLeftNavGeneList.size() > 0) {
            searchLeftNavTemp2List.addAll(searchLeftNavGeneList);
        }
        if (searchLeftNavCytoBandList.size() > 0) {
            searchLeftNavTemp2List.addAll(searchLeftNavCytoBandList);
        }
        if (searchLeftNavChildProbesList.size() > 0) {
            searchLeftNavTemp2List.addAll(searchLeftNavChildProbesList);
        }

        if (searchLeftNavTemp2List.size() > 0) {
            leftNavMap.put(getSearchConfiguration().getSureFishLeftNavName(), searchLeftNavTemp2List);
        }

    }

    private void populateExpoLibNavId( Navigation navForExpLibContentType, EndecaSearchOutput eso, StringBuffer concatQuery,
            List<EndecaSearchLeftNavVO> searchLeftNavExpoLibList) {
        String dimName = null;
        long dimId = 0L;
        PropertyMap MultiMap = null;
        for ( int j = 0; j < navForExpLibContentType.getRefinementDimensions().size(); j++) {
            DimValList dimValList = ((Dimension) navForExpLibContentType.getRefinementDimensions().get(j)).getRefinements();
            if (dimValList.size() > 0) {
                for ( int i = 0; i < dimValList.size(); i++) {
                    dimId = dimValList.getDimValue(i).getId();
                    MultiMap = dimValList.getDimValue(i).getProperties();
                    dimName = dimValList.getDimValue(i).getName();
                    EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, concatQuery.toString());
                    searchLeftNavExpoLibList.add(leftNavVO);
                }
            }
        }
    }

    private void populateLibraryNavId( Navigation navForLibContentType, EndecaSearchOutput eso, StringBuffer concatQuery,
            List<EndecaSearchLeftNavVO> searchLeftNavLibList) {
        String dimName = null;
        long dimId = 0L;
        PropertyMap MultiMap = null;
        for ( int j = 0; j < navForLibContentType.getRefinementDimensions().size(); j++) {
            DimValList dimValList = ((Dimension) navForLibContentType.getRefinementDimensions().get(j)).getRefinements();
            if (dimValList.size() > 0) {
                for ( int i = 0; i < dimValList.size(); i++) {
                    if (!dimValList.getDimValue(i).getName().equals(Constants.EXPORT_LIBRARY)) {
                        if (!dimValList.getDimValue(i).getName().equals(Constants.COFA_DIM_NAME)) {
                            dimId = dimValList.getDimValue(i).getId();
                            MultiMap = dimValList.getDimValue(i).getProperties();
                            dimName = dimValList.getDimValue(i).getName();
                            EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, concatQuery.toString());
                            searchLeftNavLibList.add(leftNavVO);
                            if (eso.getLibraryDimValId() == null) {
                                eso.setLibraryDimValId(0L);
                            }
                        }
                    } else {
                        eso.setExportLibraryDimValId(dimValList.getDimValue(i).getId());
                    }
                }
            }
        }
    }

    private void populateContentTypeNavId( DimValList dimValList, EndecaSearchOutput eso, StringBuffer conQuery,
            List<EndecaSearchLeftNavVO> searchLeftNavGenoList, List<EndecaSearchLeftNavVO> searchLeftNavSurefishList,
            List<EndecaSearchLeftNavVO> searchLeftNavGeneList, List<EndecaSearchLeftNavVO> searchLeftNavCytoBandList,
            List<EndecaSearchLeftNavVO> searchLeftNavChildProbesList, List<EndecaSearchLeftNavVO> searchLeftNavProductOverviewList) {
        String dimName = null;
        long dimId = 0L;
        PropertyMap MultiMap = null;

        for ( int i = 0; i < dimValList.size(); i++) {
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getGenomicsDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setGenomicsDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getGenomicsProductLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavGenoList.add(leftNavVO);

            }
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getSureFishDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setSureFishDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getSureFishProductLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavSurefishList.add(leftNavVO);

            }
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getGenesDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setGeneDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getGenesLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavGeneList.add(leftNavVO);

            }
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getCytoBandDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setCytoBandsDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getCytobandsLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavCytoBandList.add(leftNavVO);

            }

            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getLibraryDimValName())) {
                eso.setLibraryDimValId(dimValList.getDimValue(i).getId());
            }
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getChildProbesDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setChildProbesDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getChildProbesLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavChildProbesList.add(leftNavVO);
            }
            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getProductOverviewDimValName())) {
                dimId = dimValList.getDimValue(i).getId();
                eso.setProductOverviewDimValId(dimValList.getDimValue(i).getId());
                MultiMap = dimValList.getDimValue(i).getProperties();
                dimName = getSearchConfiguration().getProductOverviewLeftNavName();
                EndecaSearchLeftNavVO leftNavVO = addToMakeLeftNavList(MultiMap, dimName, eso, dimId, conQuery.toString());
                searchLeftNavProductOverviewList.add(leftNavVO);
            }
        }

    }

    private void populateLanguageNavIdForBasicSearch( Dimension dimension, String navQuery, EndecaSearchOutput eso) {
        if (dimension.getName().equals(getSearchConfiguration().getLanguageDimensionName())) {
            ENEQueryResults eneQueryResultForLanguage = getENEQueryResults(getHttpENEConnection(), setENEQuery(navQuery + "&Ne=" + dimension.getId()));
            Navigation navForLanguage = eneQueryResultForLanguage.getNavigation();

            for ( int j = 0; j < navForLanguage.getRefinementDimensions().size(); j++) {
                DimValList dimValList = ((Dimension) navForLanguage.getRefinementDimensions().get(j)).getRefinements();
                if (dimValList.size() > 0) {
                    for ( int i = 0; i < dimValList.size(); i++) {
                        if (dimValList.getDimValue(i).getName().equals(eso.getUserLanguage())) {
                            eso.setLanguageNavID(dimValList.getDimValue(i).getId());
                        }
                    }
                    if (eso.getLanguageNavID() == null) {

                        for ( int i = 0; i < dimValList.size(); i++) {
                            if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getDefautLanguage())) {
                                eso.setLanguageNavID(dimValList.getDimValue(i).getId());
                            }
                        }
                    }

                }
            }
        }

    }

    /**
     * @return
     */
    private String getZeroNavigationQuery() {
        return "N=" + Constants.NAV_ID;
    }

    public String createSearchBaseQuery( EndecaSearchOutput endecaSearchOutput) {
        StringBuffer strbuff = new StringBuffer();
        strbuff.append("N=" + endecaSearchOutput.getLanguageNavID());

        if (endecaSearchOutput.getGenomicsDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getGenomicsDimValId());
        }
        if (endecaSearchOutput.getSureFishDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getSureFishDimValId());
        }
        if (endecaSearchOutput.getLibraryDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getLibraryDimValId());
        }
        if (endecaSearchOutput.getCytoBandsDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getCytoBandsDimValId());
        }
        if (endecaSearchOutput.getGeneDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getGeneDimValId());
        }
        if (endecaSearchOutput.getChildProbesDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getChildProbesDimValId());
        }
        if (endecaSearchOutput.getProductOverviewDimValId() != null) {
            strbuff.append("+" + endecaSearchOutput.getProductOverviewDimValId());
        }
        strbuff.append("&Ntk=" + Constants.BasicSearchInterface);
        strbuff.append("&Ntt=" + endecaSearchOutput.getSearchTerm());
        strbuff.append("&Nty=" + Constants.DYM_TRUE);
        strbuff.append(Constants.MODE_MATCHALL);
        strbuff.append("&No=" + endecaSearchOutput.getOffsetParameter());
        return strbuff.toString();
    }

    public String createSearchRangeQuery( EndecaSearchOutput pEndecaSearchOutput) {
        StringBuffer strbuff = new StringBuffer();

        strbuff.append("N=" + pEndecaSearchOutput.getLanguageNavID());

        /*
         * if (pEndecaSearchOutput.getSureFishDimValId() != null) { strbuff.append("+" + pEndecaSearchOutput.getSureFishDimValId()); }
         */

        if (pEndecaSearchOutput.getStartRange() != null && pEndecaSearchOutput.getEndRange() != null) {
            String startLocation = pEndecaSearchOutput.getStartRange();
            String endLocation = pEndecaSearchOutput.getEndRange();
            /*
             * Example query : &Nr=OR(product.chrom:22,OR(product.childProbes.chrom:22))&Nrs=collection()/record [ (product.startLocation >= 23172168 and
             * product.startLocation < 24560508 ) or (product.endLocation > 23172168 and product.endLocation <= 24560508 )or (product.childProbes.startLocation
             * >= 23172168 and product.childProbes.startLocation < 24560508 ) or (product.childProbes.endLocation > 23172168 and product.childProbes.endLocation
             * <= 24560508 ) or (product.childProbes.startLocation < 23172168 and product.childProbes.endLocation > 24560508)or (product.startLocation <
             * 23172168 and product.endLocation > 24560508)]
             */
            strbuff.append("&Nr=OR(" + Constants.PRODUCT_CHROME_NAME + ":" + pEndecaSearchOutput.getChromNum() + ",OR(" + Constants.CHILDPROBE_CHROME_NAME
                    + ":" + pEndecaSearchOutput.getChromNum() + "))&Nrs=collection()/record [(" + Constants.PRODUCT_START_LOCATION + ">=" + startLocation
                    + " and " + Constants.PRODUCT_START_LOCATION + "<" + endLocation + ")");

            strbuff.append("or(" + Constants.PRODUCT_END_LOCATION + ">" + startLocation + " and " + Constants.PRODUCT_END_LOCATION + "<=" + endLocation + ")");

            strbuff.append("or(" + Constants.CHILDPROBE_START_LOCATION + ">=" + startLocation + " and " + Constants.CHILDPROBE_START_LOCATION + "<"
                    + endLocation + ")");

            strbuff.append("or(" + Constants.CHILDPROBE_END_LOCATION + ">" + startLocation + " and " + Constants.CHILDPROBE_END_LOCATION + "<=" + endLocation
                    + ")");

            strbuff.append("or(" + Constants.CHILDPROBE_START_LOCATION + "<" + startLocation + " and " + Constants.CHILDPROBE_END_LOCATION + ">" + endLocation
                    + ")");

            strbuff.append("or(" + Constants.PRODUCT_START_LOCATION + "<" + startLocation + " and " + Constants.PRODUCT_END_LOCATION + ">" + endLocation + ")]");

            strbuff.append("&Nao=" + pEndecaSearchOutput.getOffsetParameter());
            strbuff.append(Constants.PRODUCT_DISPLAYNAME);
            strbuff.append(Constants.STARTLOCATION_FILTER);

            vlogDebug("createSearchRangeQuery with Start and End location : " + strbuff);
        } else {
            /*
             * Example Query : &Nr=OR(product.chrom:12,OR(product.childProbes.chrom:12))
             */
            strbuff.append("&Nr=OR(" + Constants.PRODUCT_CHROME_NAME + ":" + pEndecaSearchOutput.getChromNum() + ",OR(" + Constants.CHILDPROBE_CHROME_NAME
                    + ":" + pEndecaSearchOutput.getChromNum() + "))");
            strbuff.append("&Nao=" + pEndecaSearchOutput.getOffsetParameter());
            strbuff.append(Constants.PRODUCT_DISPLAYNAME);
            strbuff.append(Constants.STARTLOCATION_FILTER);

            vlogDebug("createSearchRangeQuery with chr number : " + strbuff);
        }
        return strbuff.toString();
    }

    /**
     * @param pSearchInput
     * @param pEndecaSearchSuggestionOutput
     */
    public void populateLanguageNavigationIDs( String pSearchInput, EndecaSearchSuggestionOutput pEndecaSearchSuggestionOutput) {

        ENEQueryResults eneQueryResult = getENEQueryResults(getHttpENEConnection(), setENEQuery(getBasicSearchQuery(pSearchInput, 0)));
        if (eneQueryResult != null) {
            Navigation nav = eneQueryResult.getNavigation();
            DimensionList dimList = nav.getRefinementDimensions();
            if (!dimList.isEmpty()) {
                for ( int k = 0; k < dimList.size(); k++) {
                    Dimension dim = (Dimension) dimList.get(k);
                    if (dim.getName().equals(getSearchConfiguration().getLanguageDimensionName())) {
                        ENEQueryResults eneQueryResultForLanguage = getENEQueryResults(getHttpENEConnection(), setENEQuery(getBasicSearchQuery(pSearchInput, 0)
                                + "&Ne=" + dim.getId()));
                        Navigation navForLanguage = eneQueryResultForLanguage.getNavigation();

                        for ( int j = 0; j < navForLanguage.getRefinementDimensions().size(); j++) {
                            DimValList dimValList = ((Dimension) navForLanguage.getRefinementDimensions().get(j)).getRefinements();
                            if (dimValList.size() > 0) {
                                for ( int i = 0; i < dimValList.size(); i++) {
                                    if (dimValList.getDimValue(i).getName().equals(pEndecaSearchSuggestionOutput.getUserLanguage())) {
                                        pEndecaSearchSuggestionOutput.setLanguageNavID(dimValList.getDimValue(i).getId());
                                    }
                                }
                                if (pEndecaSearchSuggestionOutput.getLanguageNavID() == null) {

                                    for ( int i = 0; i < dimValList.size(); i++) {
                                        if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getDefautLanguage())) {
                                            pEndecaSearchSuggestionOutput.setLanguageNavID(dimValList.getDimValue(i).getId());
                                        }
                                    }
                                }

                            }
                        }
                    }
                }
            }
            // Populating those navigations which were not part of refinements
            if (pEndecaSearchSuggestionOutput.getLanguageNavID() == null) {
                if (eneQueryResult.getNavigation().getERecs().size() > 0) {
                    // Get from first record as all records belong to the same language since we didn't get Language in refinements
                    ERec firstRecord = (ERec) eneQueryResult.getNavigation().getERecs().get(0);
                    AssocDimLocationsList assocDimList = firstRecord.getDimValues();
                    AssocDimLocations assocDimLocations = assocDimList.getAssocDimLocations(getSearchConfiguration().getLanguageDimensionName());

                    if (((DimLocation) assocDimLocations.get(0)).getDimValue().getName().equals(pEndecaSearchSuggestionOutput.getUserLanguage())) {
                        pEndecaSearchSuggestionOutput.setLanguageNavID(((DimLocation) assocDimLocations.get(0)).getDimValue().getId());
                    }
                }
            }
        }
    }

    /**
     * @param pEndecaSearchSuggestionOutput
     * @return
     */
    public String createSearchSuggestionQuery( EndecaSearchSuggestionOutput pEndecaSearchSuggestionOutput) {
        StringBuffer strbuff = new StringBuffer();
        if (pEndecaSearchSuggestionOutput.getLanguageNavID() != null) {
            strbuff.append("N=" + pEndecaSearchSuggestionOutput.getLanguageNavID());
        } else {
            strbuff.append("N=0");
        }
        strbuff.append("&Ntk=" + Constants.SearchSuggestionInterface);
        strbuff.append("&Ntt=" + pEndecaSearchSuggestionOutput.getSearchTerm());
        strbuff.append("&Nty=" + Constants.DYM_FALSE);
        strbuff.append(Constants.MODE_MATCHALL);
        return strbuff.toString();
    }

    /**
     * @param pEndecaSearchSuggestionOutput
     * @param pBaseQuery
     * @return
     */
    public EndecaSearchSuggestionWrapper searchEndecaQueryForSuggestions( EndecaSearchSuggestionOutput pEndecaSearchSuggestionOutput, String pBaseQuery) {
        HttpENEConnection endecaConnection = getHttpENEConnection();
        ENEQuery eneQuery = setENEQuery(pBaseQuery);
        eneQuery.setNavNumERecs(pEndecaSearchSuggestionOutput.getSearchItemsCountPerPage());
        ENEQueryResults eneQueryResult = getENEQueryResults(endecaConnection, eneQuery);

        EndecaSearchSuggestionWrapper esw = parseQueryResultsForSearchSuggestion(eneQueryResult);
        return esw;
    }

    @SuppressWarnings( "unchecked")
    private EndecaSearchSuggestionWrapper parseQueryResultsForSearchSuggestion( ENEQueryResults eneQueryResults) {

        EndecaSearchSuggestionWrapper esw = new EndecaSearchSuggestionWrapper();
        Map<String, List<EndecaSearchRecordVO>> searchSuggestionCategoryMap = new LinkedHashMap<String, List<EndecaSearchRecordVO>>();
        esw.setSearchSuggestionCategoryMap(searchSuggestionCategoryMap);

        List<EndecaSearchRecordVO> genomicsList = new ArrayList<EndecaSearchRecordVO>();
        List<EndecaSearchRecordVO> surefishList = new ArrayList<EndecaSearchRecordVO>();
        List<EndecaSearchRecordVO> libraryList = new ArrayList<EndecaSearchRecordVO>();
        List<EndecaSearchRecordVO> genesList = new ArrayList<EndecaSearchRecordVO>();

        Navigation nav = eneQueryResults.getNavigation();
        ERecList records = nav.getERecs();
        esw.setTotalRecordCount(nav.getTotalNumERecs());
        // record Iterator
        ListIterator<ERec> recordsIterator = records.listIterator();

        String recordKey = null;
        String recordPropertyValue = null;
        // Loop through record list
        while (recordsIterator.hasNext()) {

            ERec record = recordsIterator.next();

            EndecaSearchRecordVO searchOutput = new EndecaSearchRecordVO();
            HashMap<String, String> recordFinalMap = new HashMap<String, String>();

            ListIterator<String> li = getEndecaSearchSuggestionRecordKeyList().listIterator();
            PropertyMap recordProperties = record.getProperties();

            while (li.hasNext()) {
                recordKey = li.next().toString();
                recordPropertyValue = (String) recordProperties.get(recordKey.toString());
                if (recordKey.equals(getSearchConfiguration().getContentTypePropertyName())) {
                    if (recordPropertyValue.equals(getSearchConfiguration().getGenomicsDimValName())) {
                        recordPropertyValue = getSearchConfiguration().getGenomicsDisplayName();
                    }
                    if (recordPropertyValue.equals(getSearchConfiguration().getSureFishDimValName())) {
                        recordPropertyValue = getSearchConfiguration().getSureFishDisplayName();
                    }
                }
                if (recordPropertyValue != null) {
                    recordFinalMap.put(recordKey.toString(), recordPropertyValue);
                }

            }
            searchOutput.setRecordKeyValueMap(recordFinalMap);
            if (recordProperties.get(getSearchConfiguration().getContentTypePropertyName()) != null) {
                String contentType = (String) recordProperties.get(getSearchConfiguration().getContentTypePropertyName());

                if (contentType.equals(getSearchConfiguration().getGenomicsDimValName())) {
                    genomicsList.add(searchOutput);
                } else if (contentType.equals(getSearchConfiguration().getSureFishDimValName())) {
                    surefishList.add(searchOutput);
                } else if (contentType.equals(getSearchConfiguration().getLibraryDimValName())) {
                    String expoLibcontentType = (String) recordProperties.get(getSearchConfiguration().getExportLibraryContentTypePropertyName());
                    if (expoLibcontentType != null) {
                        libraryList.add(searchOutput);
                    }
                } else if (contentType.equals(getSearchConfiguration().getGenesDimValName())) {
                    genesList.add(searchOutput);
                }
            }
        }

        if (surefishList.size() > 0 || genesList.size() > 0 || genomicsList.size() > 0 || libraryList.size() > 0) {
            searchSuggestionCategoryMap.put(getSearchConfiguration().getSureFishDisplayName(), surefishList);

            searchSuggestionCategoryMap.put(getSearchConfiguration().getGenesDisplayName(), genesList);

            searchSuggestionCategoryMap.put(getSearchConfiguration().getGenomicsDisplayName(), genomicsList);

            searchSuggestionCategoryMap.put(getSearchConfiguration().getLibraryDisplayName(), libraryList);
        }
        return esw;
    }

    /**
     * @param pEndecaSearchOutput
     * @return
     */
    public String createGeneSearchBaseQuery( EndecaSearchOutput pEndecaSearchOutput) {

        StringBuffer strbuff = new StringBuffer();
        strbuff.append("N=" + pEndecaSearchOutput.getLanguageNavID());

        /*
         * if (pEndecaSearchOutput.getSureFishDimValId() != null && !pEndecaSearchOutput.getSureFishDimValId().equals("")) { strbuff.append("+" +
         * pEndecaSearchOutput.getSureFishDimValId()); }
         */
        // Example query : Nr=AND(OR(product.chrom:6000,OR(product.childProbes.chrom:6)),product.relatedGenes.name:DCBLD1)
        strbuff.append("&Nr=AND(OR(" + Constants.PRODUCT_CHROME_NAME + ":" + pEndecaSearchOutput.getChromNum() + ",OR(" + Constants.CHILDPROBE_CHROME_NAME
                + ":" + pEndecaSearchOutput.getChromNum() + "))," + Constants.RELATED_GENE_PROP_NAME + ":" + pEndecaSearchOutput.getSearchTerm() + ")");
        // Put logger for query created.
        strbuff.append("&No=" + pEndecaSearchOutput.getOffsetParameter());
        return strbuff.toString();
    }

    /**
     * @param pSearchInput
     * @param pEndecaSearchOutput
     */
    public void populateSureFishNavigationIDs( EndecaSearchOutput pEndecaSearchOutput) {

        ENEQueryResults eneQueryResult = getENEQueryResults(getHttpENEConnection(), setENEQuery(getZeroNavigationQuery()));
        if (eneQueryResult != null) {
            Navigation nav = eneQueryResult.getNavigation();
            DimensionList dimList = nav.getRefinementDimensions();
            if (!dimList.isEmpty()) {
                for ( int k = 0; k < dimList.size(); k++) {
                    Dimension dim = (Dimension) dimList.get(k);
                    if (dim.getName().equals(getSearchConfiguration().getContentTypeDimensionName())) {

                        ENEQueryResults eneQueryResultForContentType = getENEQueryResults(getHttpENEConnection(), setENEQuery(getZeroNavigationQuery() + "&Ne="
                                + dim.getId()));
                        Navigation navForContentType = eneQueryResultForContentType.getNavigation();

                        for ( int j = 0; j < navForContentType.getRefinementDimensions().size(); j++) {
                            DimValList dimValList = ((Dimension) navForContentType.getRefinementDimensions().get(j)).getRefinements();
                            if (dimValList.size() > 0) {
                                for ( int i = 0; i < dimValList.size(); i++) {
                                    if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getSureFishDimValName())) {
                                        pEndecaSearchOutput.setSureFishDimValId(dimValList.getDimValue(i).getId());
                                    }
                                }
                            }
                        }
                    }
                    if (dim.getName().equals(getSearchConfiguration().getLanguageDimensionName())) {
                        ENEQueryResults eneQueryResultForLanguage = getENEQueryResults(getHttpENEConnection(), setENEQuery(getZeroNavigationQuery() + "&Ne="
                                + dim.getId()));
                        Navigation navForLanguage = eneQueryResultForLanguage.getNavigation();

                        for ( int j = 0; j < navForLanguage.getRefinementDimensions().size(); j++) {
                            DimValList dimValList = ((Dimension) navForLanguage.getRefinementDimensions().get(j)).getRefinements();
                            if (dimValList.size() > 0) {
                                for ( int i = 0; i < dimValList.size(); i++) {
                                    if (dimValList.getDimValue(i).getName().equals(pEndecaSearchOutput.getUserLanguage())) {
                                        pEndecaSearchOutput.setLanguageNavID(dimValList.getDimValue(i).getId());
                                    }
                                }
                                if (pEndecaSearchOutput.getLanguageNavID() == null) {

                                    for ( int i = 0; i < dimValList.size(); i++) {
                                        if (dimValList.getDimValue(i).getName().equals(getSearchConfiguration().getDefautLanguage())) {
                                            pEndecaSearchOutput.setLanguageNavID(dimValList.getDimValue(i).getId());
                                        }
                                    }
                                }

                            }
                        }
                    }

                }
            }
        }
    }

    public String createCofaSearchQuery( EndecaSearchOutput endecaSearchOutput) {

        StringBuffer strbuff = new StringBuffer();
        strbuff.append("N=0");

        if (endecaSearchOutput.getCofaQueryType().equals("cofaLot")) {
            strbuff.append("&Ntk=" + Constants.COFA_LOT_ID);
        } else {
            strbuff.append("&Ntk=" + Constants.COFA_CATALOG_ID);
        }
        strbuff.append("&Ntt=" + endecaSearchOutput.getSearchTerm());
        strbuff.append(Constants.MODE_MATCHALL);
        return strbuff.toString();
    }

}
