/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.index;

import java.util.Locale;

import atg.endeca.index.AbstractRecordStoreAggregateSession;
import atg.endeca.index.RecordSubmitterImpl;
import atg.endeca.index.accessor.LanguageNameAccessor;
import atg.repository.RepositoryItem;
import atg.repository.search.indexing.Context;
import atg.repository.search.indexing.DocumentSubmitterSession;
import atg.repository.search.indexing.specifier.PropertyTypeEnum;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS AgilentLanguageNameAccessor
 * </p>
 * 
 * @author sunny.mangla
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: Jan 16, 2013 11:49:34 AM Author: sunny.mangla
 */

public class AgilentLanguageNameAccessor extends LanguageNameAccessor {

    protected Object getTextOrMetaPropertyValue( Context pContext, RepositoryItem pItem, String pPropertyName, PropertyTypeEnum pType) {

        DocumentSubmitterSession session = pContext.getDocumentSubmitterSession();
        if ((session instanceof AbstractRecordStoreAggregateSession)) {
            RecordSubmitterImpl submitter = ((AbstractRecordStoreAggregateSession) session).getSubmitter();

            if (submitter.getDefaultLanguageForRecordStores() == null) {
                return null;
            }
        }
        Locale locale = pContext.getCurrentDocumentLocale();
        return locale.getLanguage();  
    }
}
