/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.index;

public interface Constants {

    String CHILD_PROBES_ITR         = "childProbes_itr";
    String CHILD_PROBES             = "childProbes";
    String TITLE                    = "title";
    String LSCA_COLUMNS_CATEGORY_ID = "ClassECS_29491";
    String LSCA_OBSOLETE_CATEGORY_ID = "ClassECS_20212";
}
