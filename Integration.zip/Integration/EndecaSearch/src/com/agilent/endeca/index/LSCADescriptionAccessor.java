/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.index;

import java.util.Set;

import atg.repository.RepositoryItem;
import atg.repository.search.indexing.Context;
import atg.repository.search.indexing.PropertyAccessorImpl;
import atg.repository.search.indexing.specifier.PropertyTypeEnum;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS LSCADescriptionAccessor
 * </p>
 * 
 * @author amogh.k
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: Jan 16, 2014 12:12:30 PM Author: amogh.k
 */

public class LSCADescriptionAccessor extends PropertyAccessorImpl {

    private LanguagePropertyAccessor mLanguagePropertyAccessor;

    /**
     * Gets the value of languagePropertyAccessor
     * 
     * @return returns the property languagePropertyAccessor
     */
    public LanguagePropertyAccessor getLanguagePropertyAccessor() {
        return mLanguagePropertyAccessor;
    }

    /**
     * Sets the value of property languagePropertyAccessor with value languagePropertyAccessor
     * 
     * @param languagePropertyAccessor
     *            the languagePropertyAccessor to set
     */
    public void setLanguagePropertyAccessor( LanguagePropertyAccessor languagePropertyAccessor) {
        mLanguagePropertyAccessor = languagePropertyAccessor;
    }

    /*
     * (non-Javadoc)
     * @see atg.repository.search.indexing.PropertyAccessorImpl#getTextOrMetaPropertyValue(atg.repository.search.indexing.Context,
     * atg.repository.RepositoryItem, java.lang.String, atg.repository.search.indexing.specifier.PropertyTypeEnum)
     */
    @Override
    protected Object getTextOrMetaPropertyValue( Context pContext, RepositoryItem pItem, String pPropertyName, PropertyTypeEnum pType) {
        String descriptionName = "description";
        try {

            Set<String> ancestorCategoriesIds = (Set<String>) pItem.getPropertyValue("ancestorCategoryIds");

            if (!ancestorCategoriesIds.contains(Constants.LSCA_COLUMNS_CATEGORY_ID) && !ancestorCategoriesIds.contains(Constants.LSCA_OBSOLETE_CATEGORY_ID)) {
                return getLanguagePropertyAccessor().getTextOrMetaPropertyValue(pContext, pItem, descriptionName, pType);
            }
            return null;
        } catch (Exception exceptions) {
            logError(exceptions);
        }
        return super.getTextOrMetaPropertyValue(pContext, pItem, descriptionName, pType);
    }
}
