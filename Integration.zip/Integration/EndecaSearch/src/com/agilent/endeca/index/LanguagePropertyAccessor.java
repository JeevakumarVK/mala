package com.agilent.endeca.index;

import atg.beans.DynamicPropertyDescriptor;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.search.indexing.Context;
import atg.repository.search.indexing.MultiTranslationPropertyAccessorImpl;
import atg.repository.search.indexing.specifier.PropertyTypeEnum;

/**
 * This propertyAccessor is use to get and return the correct translation of the property of the item for the process of indexing
 * 

 */

public class LanguagePropertyAccessor extends MultiTranslationPropertyAccessorImpl {

    // -----------------------------------------------------------------------------------
    // property: loggingDebug

    private boolean mLoggingDebug = false;

    /**
     * Set the logging debug. Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @param pLoggingDebug
     *            A boolean value to enable/disable logging debug.
     */
    public void setLoggingDebug( boolean pLoggingDebug) {
        mLoggingDebug = pLoggingDebug;
    }

    /**
     * Get the logging debug. Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @return True if loggingDebug set,False otherwise.
     */
    public boolean isLoggingDebug() {
        return mLoggingDebug;
    }

    // -------------------------------------------------------------------------------

    // -----------------------------------------------------------------------------

    private boolean mLoggingError = false;

    /**
     * Set the logging error Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @param pLoggingError
     *            A boolean value to enable/disable logging errors.
     */
    public void setLoggingError( boolean pLoggingError) {
        mLoggingError = pLoggingError;
    }

    /**
     * Get the logging error Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @return True if logging for errors is enabled,False otherwise.
     */
    public boolean isLoggingError() {
        return mLoggingError;
    }

    // -----------------------------------------------------------------------------------
    // -----------------------------------------------------------------------------

    private boolean mLoggingWarning = false;

    /**
     * Set the logging warning Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @param pLoggingWarning
     *            A boolean value to enable/disable logging warnings.
     */
    public void setLoggingWarning( boolean pLoggingWarning) {
        mLoggingWarning = pLoggingWarning;
    }

    /**
     * Get the logging warning Logs through the IndexingOutputConfig on the {@see atg.repository.search.indexing.Context}.
     * 
     * @return True if logging for warnings is enabled,False otherwise.
     */
    public boolean isLoggingWarning() {
        return mLoggingWarning;
    }

    // ---------------------------------------------------------------------------------
    /**
     * This function sets the pContext in the ContextranslationRepositoryKeyService.
     * 
     * @param pContext
     *            Current locale of the property whose value is needed.
     * @param pItem
     *            A RepositoryItem object to get the value of the property passed.
     * @param pPropertyName
     *            Name of the property whose value is needed.
     * @param pType
     *            Type of the property whose value is needed.
     * @return Object The value of the pPropertyName obtained from TranslationDescriptor.
     */
    protected Object getTextOrMetaPropertyValue( Context pContext, RepositoryItem pItem, String pPropertyName, PropertyTypeEnum pType) {

        if (isLoggingDebug()) {
            pContext.getIndexingOutputConfig().logDebug("LanguagePropertyAccessor.getTextOrMetaPropertyValue(" + pItem + " , " + pPropertyName + ")");
        }
        DynamicPropertyDescriptor propDesc = null;
        try {
            propDesc = pItem.getItemDescriptor().getPropertyDescriptor(pPropertyName);

            IndexingLanguageTranslation translationDescriptor = getCachedContextTranslationDescriptor(pContext, propDesc);

            if (translationDescriptor != null) {
                Object objResult = translationDescriptor.derivePropertyValue(pItem);
                if (isLoggingDebug()) {
                    pContext.getIndexingOutputConfig().logDebug(
                            "The IndexingTranslationDescriptor returned " + objResult + " for " + pPropertyName + " of " + pItem + " using locale of "
                                    + pContext.getCurrentDocumentLocale());
                }
                return objResult;
            }
            if (isLoggingDebug()) {
                pContext.getIndexingOutputConfig().logDebug("No derived property descriptor for " + pPropertyName + " of " + pItem);
            }
        } catch (RepositoryException e) {
            pContext.getIndexingOutputConfig().logError(e);
        }

        return super.getTextOrMetaPropertyValue(pContext, pItem, pPropertyName, pType);
    }

    /**
     * This function passes the default value of the property passed to it.
     * 
     * @param pItem
     *            A RepositoryItem object to get the value of the property passed.
     * @param pPropertyName
     *            Name of the property whose default value is needed.
     * @return Object The default value of the property passed.
     */
    protected Object getDefaultPropertyValue( RepositoryItem pItem, String pPropertyName) {

        return pItem.getPropertyValue(pPropertyName + "Default");

    }

}
