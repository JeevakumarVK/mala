
package com.agilent.endeca.index;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import atg.core.util.Null;
import atg.nucleus.GenericService;
import atg.repository.RepositoryItem;
import atg.repository.search.indexing.Context;
import atg.repository.search.indexing.VariantProducer;

public class ProbesVariantProducer extends GenericService implements VariantProducer {

    private String mProbeUniqueParamName;
    private String mAttributeName;

    public String getProbeUniqueParamName() {
        return mProbeUniqueParamName;
    }

    public void setProbeUniqueParamName( String pProbeUniqueParamName) {
        mProbeUniqueParamName = pProbeUniqueParamName;
    }

    public void setAttributeName( String pAttributeName) {
        mAttributeName = pAttributeName;
    }

    public String getAttributeName() {
        return mAttributeName;
    }

    public boolean prepareNextVariant( Context pContext, String pPropertyName, RepositoryItem pItem, int pIndex, Map pUniqueParams) {

        Object childProbesItrAttr = pContext.getAttribute("childProbes_itr");

        Iterator childProbesIter = null;

        if (childProbesItrAttr == Null.NULL) {
            pContext.removeAttribute("childProbes_itr");
            pContext.removeAttribute("childProbes");
            return false;
        }

        if (childProbesItrAttr == null) {
            Collection childProbes = getChildProbes(pItem);
            if (childProbes == null || childProbes.size() == 0) {
                pContext.setAttribute("childProbes_itr", Null.NULL);
                pContext.setAttribute("childProbes", Null.NULL);
                return true;
            }
            childProbesIter = childProbes.iterator();
            pContext.setAttribute("childProbes_itr", childProbesIter);
        }

        if (childProbesItrAttr instanceof Iterator) {
            childProbesIter = (Iterator) childProbesItrAttr;
        }
        if (childProbesIter != null && childProbesIter.hasNext()) {

            Object childProbe = childProbesIter.next();
            pContext.setAttribute("childProbes", childProbe);
            if (childProbe instanceof RepositoryItem) {
                pUniqueParams.put("childProbeId", ((RepositoryItem) childProbe).getRepositoryId());
                return true;
            }

        } else {

            pContext.removeAttribute("childProbes_itr");
            pContext.removeAttribute("childProbes");
            return false;
        }
        return true;

    }

    private Collection getChildProbes( RepositoryItem pItem) {

        Collection childProbes = null;
        if (pItem == null) {
            return null;
        }
        Integer type = (Integer) pItem.getPropertyValue("type");
        if (type == 1) {
            childProbes = (Collection) pItem.getPropertyValue("childProbes");
        }
        return childProbes;
    }
}