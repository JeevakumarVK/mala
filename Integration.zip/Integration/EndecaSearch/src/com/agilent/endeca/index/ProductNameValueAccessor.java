
package com.agilent.endeca.index;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;
import atg.repository.search.indexing.Context;
import atg.repository.search.indexing.PropertyAccessorImpl;
import atg.repository.search.indexing.specifier.PropertyTypeEnum;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;

public class ProductNameValueAccessor extends PropertyAccessorImpl {

    private AgilentCatalogTools        mCatalogTools;

    private static Map<String, String> mPropertyMap;

    public Map<String, String> getPropertyMap() {
        return mPropertyMap;
    }

    public void setPropertyMap( Map<String, String> pPropertyMap) {
        mPropertyMap = pPropertyMap;
    }

    @Override
    protected Object getTextOrMetaPropertyValue( Context pContext, RepositoryItem pItem, String pPropertyName, PropertyTypeEnum pType) {

        if (pItem == null) {
            return null;
        }
        Set<String> products = null;
        Set<String> outputProducts = null;
        Set<String> productGroup = null;
        try {
            if (pPropertyName.equals("products")) {

                products = (Set<String>) pItem.getPropertyValue(pPropertyName);

                if (products != null && products.size() > 0) {
                    for ( String product : products) {
                        RepositoryItem productItem = getCatalogTools().findProduct(product);
                        if (productItem != null) {
                            String title = (String) productItem.getPropertyValue(Constants.TITLE);
                            if (outputProducts == null) {
                                outputProducts = new HashSet<String>();
                            }
                            outputProducts.add(title);
                        }
                    }
                }
                if (outputProducts == null) {
                    return null;
                }

                return outputProducts.toString();
            } else if (pPropertyName.equals("productGroup")) {

                productGroup = (Set<String>) pItem.getPropertyValue(pPropertyName);

                if (productGroup != null && productGroup.size() > 0) {
                    for ( String category : productGroup) {
                        RepositoryItem categoryItem = getCatalogTools().findCategory(category);
                        if (categoryItem != null) {
                            String title = (String) categoryItem.getPropertyValue(Constants.TITLE);
                            if (outputProducts == null) {
                                outputProducts = new HashSet<String>();
                            }
                            outputProducts.add(title);
                        }
                    }
                }
                if (outputProducts == null) {
                    return null;
                }

                return outputProducts.toString();
            }

            else {
                return null;
            }
        } catch (RepositoryException exception) {
            vlogError(exception, "");
        }
        return null;
    }

    public AgilentCatalogTools getCatalogTools() {
        return mCatalogTools;
    }

    public void setCatalogTools( AgilentCatalogTools pCatalogTools) {
        mCatalogTools = pCatalogTools;
    }

}
