/**
 * 
 */
package com.agilent.endeca.index.scheduler;

import atg.nucleus.GenericService;
import atg.nucleus.ServiceException;
import atg.service.scheduler.Schedulable;
import atg.service.scheduler.Schedule;
import atg.service.scheduler.ScheduledJob;
import atg.service.scheduler.Scheduler;

import com.agilent.endeca.webservice.GetCoursesInvoke;

/**
 * @author saini_i
 *
 */
public class GetCoursesSchedule extends GenericService implements Schedulable {

	GetCoursesInvoke getCoursesInvoker;

	/**
	 * @return the getCoursesInvoker
	 */
	public GetCoursesInvoke getGetCoursesInvoker() {
		return getCoursesInvoker;
	}

	/**
	 * @param getCoursesInvoker
	 *            the getCoursesInvoker to set
	 */
	public void setGetCoursesInvoker(GetCoursesInvoke getCoursesInvoker) {
		this.getCoursesInvoker = getCoursesInvoker;
	}

	// Scheduler property
	Scheduler scheduler;

	public Scheduler getScheduler() {
		return scheduler;
	}

	public void setScheduler(Scheduler scheduler) {
		this.scheduler = scheduler;
	}

	// Schedule property
	Schedule schedule;

	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * atg.service.scheduler.Schedulable#performScheduledTask(atg.service.scheduler
	 * .Scheduler, atg.service.scheduler.ScheduledJob)
	 */
	@Override
	public void performScheduledTask(Scheduler arg0, ScheduledJob arg1) {
		// TODO Auto-generated method stub
		try {
			getGetCoursesInvoker().invoke();
		} catch (Exception e) {
			vlogError(e,
					"Exception encountered while calling View Central service.");
		}
	}

	// Start method
	int jobId;

	public void doStartService() throws ServiceException {
		ScheduledJob job = new ScheduledJob("GetCoursesJob", "Invoke GetCourses and GetSchedules web service of View Central",
				getAbsoluteName(), getSchedule(), this,
				ScheduledJob.SCHEDULER_THREAD);
		jobId = getScheduler().addScheduledJob(job);
	}

	// Stop method
	public void doStopService() throws ServiceException {
		getScheduler().removeScheduledJob(jobId);
	}
}
