/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchConstant
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 1:21:08 PM Author: Ramandeep_Singh
 */

public interface Constants {

    String ENCODING_FORMAT           = "UTF-8";
    String NAV_ID                    = "0";
    String ROOT                      = "0";
    String AMP_NTT                   = "&Ntt=";
    String BasicSearchInterface      = "BasicSearch";
    String SearchSuggestionInterface = "SearchSuggestion";
    String AMP_D                     = "&D=";
    String PRODUCT_CHROME_NAME       = "product.chrom";
    String CHILDPROBE_CHROME_NAME    = "product.childProbes.chrom";

    String PRODUCT_START_LOCATION    = "product.startLocation";
    String PRODUCT_END_LOCATION      = "product.endLocation";
    String CHILDPROBE_START_LOCATION = "product.childProbes.startLocation";
    String CHILDPROBE_END_LOCATION   = "product.childProbes.endLocation";
    String DYM_TRUE                  = "1";
    String DYM_FALSE                 = "0";
    String NTX_ALL                   = "mode+matchall";
    String NTX_BOOLEAN               = "mode+matchboolean";
    String AMP_DX_ALL                = "&Dx=mode+matchall";
    String AMP_No                    = "&No=";
    String RELATED_GENE_PROP_NAME    = "product.relatedGenes.name";

    String PIPE_SEPERATOR            = "|";

    String COFA_LOT_ID               = "cofa.lotId";
    String COFA_CATALOG_ID           = "cofa.stockCode";
    String DIM_SIZE_KEY_NAME         = "DGraph.Bins";
    String EXPORT_LIBRARY            = "exportLibrary";
    String AMP_NTK                   = "&Ntk=";
    String AMP_NTY                   = "&Nty=";
    String AMP_NTX_All               = "&Ntx=mode+matchall";
    String N                         = "N=0";
    String AMP_NE                    = "&Ne=";
    String AND                       = "and";
    String OR                        = "or(";
    String COFA_DIM_NAME             = "cofaTemplates";
    String AMP_BASE_SEARCH_TYPE      = "&type=baseSearch";

    String PRODUCT_DISPLAYNAME       = "&Nu=product.displayName";
    String MODE_MATCHALL             = "&Ntx=mode+matchall";
    String STARTLOCATION_FILTER      = "&Ns=product.startLocation.filter";

}
