/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchLeftNavVO
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 18-Feb-2013 1:28:58 PM Author: Ramandeep_Singh
 */

public class EndecaSearchLeftNavVO {

    String mDimensionName = null;
    String mDimensionSize = null;
    String mDimensionURL  = null;

    /**
     * Gets the value of dimensionName
     * 
     * @return returns the property dimensionName
     */
    public String getDimensionName() {
        return mDimensionName;
    }

    /**
     * Sets the value of property dimensionName with value pDimensionName
     * 
     * @param pDimensionName
     *            the dimensionName to set
     */
    public void setDimensionName( String pDimensionName) {
        mDimensionName = pDimensionName;
    }

    /**
     * Gets the value of dimensionSize
     * 
     * @return returns the property dimensionSize
     */
    public String getDimensionSize() {
        return mDimensionSize;
    }

    /**
     * Sets the value of property dimensionSize with value pDimensionSize
     * 
     * @param pDimensionSize
     *            the dimensionSize to set
     */
    public void setDimensionSize( String pDimensionSize) {
        mDimensionSize = pDimensionSize;
    }

    /**
     * Gets the value of dimensionURL
     * 
     * @return returns the property dimensionURL
     */
    public String getDimensionURL() {
        return mDimensionURL;
    }

    /**
     * Sets the value of property dimensionURL with value pDimensionURL
     * 
     * @param pDimensionURL
     *            the dimensionURL to set
     */
    public void setDimensionURL( String pDimensionURL) {
        mDimensionURL = pDimensionURL;
    }

}
