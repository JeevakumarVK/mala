/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchOutputVO
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 28-Dec-2012 1:31:01 PM Author: Ramandeep_Singh
 */

public class EndecaSearchOutput {

    private long                                     mNextPageNumToMove       = 2;
    private long                                     mPrevPageNumToMove       = 1;
    private long                                     mStartRecordNumber       = 0;
    private long                                     mEndRecordNumber         = 0;
    private int                                      mSearchItemsCountPerPage = 0;
    private long                                     mRecordSetCount          = 0;
    private double                                   mPageCount               = 0;
    private Long                                     mLanguageNavID           = null;
    private Long                                     mSureFishDimValId        = null;
    private Long                                     mGenomicsDimValId        = null;
    private Long                                     mLibraryDimValId         = null;
    private Long                                     mCytoBandsDimValId       = null;
    private Long                                     mGeneDimValId            = null;
    private Long                                     mExportLibraryDimValId   = null;
    private Long                                     mChildProbesDimValId     = null;
    private Long                                     mProductOverviewDimValId = null;
    private String                                   mSearchTerm              = null;
    private String                                   mSearchInterface         = null;
    private long                                     mOffsetParameter         = 0;
    private String                                   mUserLanguage            = "";
    private String                                   mLeftNavQueryType        = null;
    private String                                   mLeftNavQuery            = null;
    private String                                   mDYMSuggestion           = "";
    private String                                   mAutoCorrection          = "";
    private double                                   mQueryResponseTime       = 0.0;
    private String                                   mChromNum                = "";
    private String                                   mStartRange              = null;
    private String                                   mEndRange                = null;
    private String                                   mCofaQueryType           = null;
    private Map<String, List<EndecaSearchLeftNavVO>> mLeftNavMap              = null;

    /**
     * Gets the value of childProbesDimValId
     * 
     * @return returns the property childProbesDimValId
     */
    public Long getChildProbesDimValId() {
        return mChildProbesDimValId;
    }

    /**
     * Sets the value of property childProbesDimValId with value pChildProbesDimValId
     * 
     * @param pChildProbesDimValId
     *            the childProbesDimValId to set
     */
    public void setChildProbesDimValId( Long pChildProbesDimValId) {
        mChildProbesDimValId = pChildProbesDimValId;
    }

    /**
     * Gets the value of productOverviewDimValId
     * 
     * @return returns the property productOverviewDimValId
     */
    public Long getProductOverviewDimValId() {
        return mProductOverviewDimValId;
    }

    /**
     * Sets the value of property productOverviewDimValId with value pProductOverviewDimValId
     * 
     * @param pProductOverviewDimValId
     *            the productOverviewDimValId to set
     */
    public void setProductOverviewDimValId( Long pProductOverviewDimValId) {
        mProductOverviewDimValId = pProductOverviewDimValId;
    }

    /**
     * Gets the value of leftNavQuery
     * 
     * @return returns the property leftNavQuery
     */
    public String getLeftNavQuery() {
        return mLeftNavQuery;
    }

    /**
     * Sets the value of property leftNavQuery with value pLeftNavQuery
     * 
     * @param pLeftNavQuery
     *            the leftNavQuery to set
     */
    public void setLeftNavQuery( String pLeftNavQuery) {
        mLeftNavQuery = pLeftNavQuery;
    }

    /**
     * Gets the value of geneDimValId
     * 
     * @return returns the property geneDimValId
     */
    public Long getGeneDimValId() {
        return mGeneDimValId;
    }

    /**
     * Sets the value of property geneDimValId with value pGeneDimValId
     * 
     * @param pGeneDimValId
     *            the geneDimValId to set
     */
    public void setGeneDimValId( Long pGeneDimValId) {
        mGeneDimValId = pGeneDimValId;
    }

    /**
     * Gets the value of exportLibraryDimValId
     * 
     * @return returns the property exportLibraryDimValId
     */
    public Long getExportLibraryDimValId() {
        return mExportLibraryDimValId;
    }

    /**
     * Sets the value of property exportLibraryDimValId with value pExportLibraryDimValId
     * 
     * @param pExportLibraryDimValId
     *            the exportLibraryDimValId to set
     */
    public void setExportLibraryDimValId( Long pExportLibraryDimValId) {
        mExportLibraryDimValId = pExportLibraryDimValId;
    }

    /**
     * Gets the value of leftNavMap
     * 
     * @return returns the property leftNavMap
     */
    public Map<String, List<EndecaSearchLeftNavVO>> getLeftNavMap() {
        return mLeftNavMap;
    }

    /**
     * Sets the value of property leftNavMap with value pLeftNavMap
     * 
     * @param pLeftNavMap
     *            the leftNavMap to set
     */
    public void setLeftNavMap( Map<String, List<EndecaSearchLeftNavVO>> pLeftNavMap) {
        mLeftNavMap = pLeftNavMap;
    }

    /**
     * Gets the value of startRange
     * 
     * @return returns the property cofaQueryType
     */
    public String getCofaQueryType() {
        return mCofaQueryType;
    }

    /**
     * Sets the value of property startRange with value pStartRange
     * 
     * @param pCofaQueryType
     *            the cofaQueryType to set
     */
    public void setCofaQueryType( String pCofaQueryType) {
        mCofaQueryType = pCofaQueryType;
    }

    /**
     * Gets the value of startRange
     * 
     * @return returns the property startRange
     */
    public String getStartRange() {
        return mStartRange;
    }

    /**
     * Sets the value of property startRange with value pStartRange
     * 
     * @param pStartRange
     *            the startRange to set
     */
    public void setStartRange( String pStartRange) {
        mStartRange = pStartRange;
    }

    /**
     * Gets the value of endRange
     * 
     * @return returns the property endRange
     */
    public String getEndRange() {
        return mEndRange;
    }

    /**
     * Sets the value of property endRange with value pEndRange
     * 
     * @param pEndRange
     *            the endRange to set
     */
    public void setEndRange( String pEndRange) {
        mEndRange = pEndRange;
    }

    /**
     * Gets the value of chromNum
     * 
     * @return returns the property chromNum
     */
    public String getChromNum() {
        return mChromNum;
    }

    /**
     * Sets the value of property chromNum with value pChromNum
     * 
     * @param pChromNum
     *            the chromNum to set
     */
    public void setChromNum( String pChromNum) {
        mChromNum = pChromNum;
    }

    /**
     * Gets the value of queryResponseTime
     * 
     * @return returns the property queryResponseTime
     */
    public double getQueryResponseTime() {
        return mQueryResponseTime;
    }

    /**
     * Sets the value of property queryResponseTime with value pQueryResponseTime
     * 
     * @param pQueryResponseTime
     *            the queryResponseTime to set
     */
    public void setQueryResponseTime( double pQueryResponseTime) {
        mQueryResponseTime = pQueryResponseTime;
    }

    /**
     * Gets the value of dYMSuggestion
     * 
     * @return returns the property dYMSuggestion
     */
    public String getDYMSuggestion() {
        return mDYMSuggestion;
    }

    /**
     * Sets the value of property dYMSuggestion with value pDYMSuggestion
     * 
     * @param pDYMSuggestion
     *            the dYMSuggestion to set
     */
    public void setDYMSuggestion( String pDYMSuggestion) {
        mDYMSuggestion = pDYMSuggestion;
    }

    /**
     * Gets the value of autoCorrection
     * 
     * @return returns the property autoCorrection
     */
    public String getAutoCorrection() {
        return mAutoCorrection;
    }

    /**
     * Sets the value of property autoCorrection with value pAutoCorrection
     * 
     * @param pAutoCorrection
     *            the autoCorrection to set
     */
    public void setAutoCorrection( String pAutoCorrection) {
        mAutoCorrection = pAutoCorrection;
    }

    /**
     * Gets the value of searchTerm
     * 
     * @return returns the property searchTerm
     */
    public String getSearchTerm() {
        return mSearchTerm;
    }

    /**
     * Sets the value of property searchTerm with value pSearchTerm
     * 
     * @param pSearchTerm
     *            the searchTerm to set
     */
    public void setSearchTerm( String pSearchTerm) {
        mSearchTerm = pSearchTerm;
    }

    /**
     * Gets the value of searchInterface
     * 
     * @return returns the property searchInterface
     */
    public String getSearchInterface() {
        return mSearchInterface;
    }

    /**
     * Sets the value of property searchInterface with value pSearchInterface
     * 
     * @param pSearchInterface
     *            the searchInterface to set
     */
    public void setSearchInterface( String pSearchInterface) {
        mSearchInterface = pSearchInterface;
    }

    /**
     * Gets the value of offsetParameter
     * 
     * @return returns the property offsetParameter
     */
    public long getOffsetParameter() {
        return mOffsetParameter;
    }

    /**
     * Sets the value of property offsetParameter with value pOffsetParameter
     * 
     * @param pOffsetParameter
     *            the offsetParameter to set
     */
    public void setOffsetParameter( long pOffsetParameter) {
        mOffsetParameter = pOffsetParameter;
    }

    /**
     * Gets the value of userLanguage
     * 
     * @return returns the property userLanguage
     */
    public String getUserLanguage() {
        return mUserLanguage;
    }

    /**
     * Sets the value of property userLanguage with value pUserLanguage
     * 
     * @param pUserLanguage
     *            the userLanguage to set
     */
    public void setUserLanguage( String pUserLanguage) {
        mUserLanguage = pUserLanguage;
    }

    /**
     * Gets the value of languageNavID
     * 
     * @return returns the property languageNavID
     */
    public Long getLanguageNavID() {
        return mLanguageNavID;
    }

    /**
     * Sets the value of property languageNavID with value pLanguageNavID
     * 
     * @param pLanguageNavID
     *            the languageNavID to set
     */
    public void setLanguageNavID( Long pLanguageNavID) {
        mLanguageNavID = pLanguageNavID;
    }

    /**
     * Gets the value of sureFishDimValId
     * 
     * @return returns the property sureFishDimValId
     */
    public Long getSureFishDimValId() {
        return mSureFishDimValId;
    }

    /**
     * Sets the value of property sureFishDimValId with value pSureFishDimValId
     * 
     * @param pSureFishDimValId
     *            the sureFishDimValId to set
     */
    public void setSureFishDimValId( Long pSureFishDimValId) {
        mSureFishDimValId = pSureFishDimValId;
    }

    /**
     * Gets the value of genomicsDimValId
     * 
     * @return returns the property genomicsDimValId
     */
    public Long getGenomicsDimValId() {
        return mGenomicsDimValId;
    }

    /**
     * Sets the value of property genomicsDimValId with value pGenomicsDimValId
     * 
     * @param pGenomicsDimValId
     *            the genomicsDimValId to set
     */
    public void setGenomicsDimValId( Long pGenomicsDimValId) {
        mGenomicsDimValId = pGenomicsDimValId;
    }

    /**
     * Gets the value of libraryDimValId
     * 
     * @return returns the property libraryDimValId
     */
    public Long getLibraryDimValId() {
        return mLibraryDimValId;
    }

    /**
     * Sets the value of property libraryDimValId with value pLibraryDimValId
     * 
     * @param pLibraryDimValId
     *            the libraryDimValId to set
     */
    public void setLibraryDimValId( Long pLibraryDimValId) {
        mLibraryDimValId = pLibraryDimValId;
    }

    /**
     * Gets the value of cytoBandsDimValId
     * 
     * @return returns the property cytoBandsDimValId
     */
    public Long getCytoBandsDimValId() {
        return mCytoBandsDimValId;
    }

    /**
     * Sets the value of property cytoBandsDimValId with value pCytoBandsDimValId
     * 
     * @param pCytoBandsDimValId
     *            the cytoBandsDimValId to set
     */
    public void setCytoBandsDimValId( Long pCytoBandsDimValId) {
        mCytoBandsDimValId = pCytoBandsDimValId;
    }

    /**
     * Gets the value of nextPageNumToMove
     * 
     * @return returns the property nextPageNumToMove
     */
    public long getNextPageNumToMove() {
        return mNextPageNumToMove;
    }

    /**
     * Sets the value of property nextPageNumToMove with value pNextPageNumToMove
     * 
     * @param pNextPageNumToMove
     *            the nextPageNumToMove to set
     */
    public void setNextPageNumToMove( long pNextPageNumToMove) {
        mNextPageNumToMove = pNextPageNumToMove;
    }

    /**
     * Gets the value of prevPageNumToMove
     * 
     * @return returns the property prevPageNumToMove
     */
    public long getPrevPageNumToMove() {
        return mPrevPageNumToMove;
    }

    /**
     * Sets the value of property prevPageNumToMove with value pPrevPageNumToMove
     * 
     * @param pPrevPageNumToMove
     *            the prevPageNumToMove to set
     */
    public void setPrevPageNumToMove( long pPrevPageNumToMove) {
        mPrevPageNumToMove = pPrevPageNumToMove;
    }

    /**
     * Gets the value of startRecordNumber
     * 
     * @return returns the property startRecordNumber
     */
    public long getStartRecordNumber() {
        return mStartRecordNumber;
    }

    /**
     * Sets the value of property startRecordNumber with value pStartRecordNumber
     * 
     * @param pStartRecordNumber
     *            the startRecordNumber to set
     */
    public void setStartRecordNumber( long pStartRecordNumber) {
        mStartRecordNumber = pStartRecordNumber;
    }

    /**
     * Gets the value of endRecordNumber
     * 
     * @return returns the property endRecordNumber
     */
    public long getEndRecordNumber() {
        return mEndRecordNumber;
    }

    /**
     * Sets the value of property endRecordNumber with value pEndRecordNumber
     * 
     * @param pEndRecordNumber
     *            the endRecordNumber to set
     */
    public void setEndRecordNumber( long pEndRecordNumber) {
        mEndRecordNumber = pEndRecordNumber;
    }

    /**
     * Gets the value of searchItemsCountPerPage
     * 
     * @return returns the property searchItemsCountPerPage
     */
    public int getSearchItemsCountPerPage() {
        return mSearchItemsCountPerPage;
    }

    /**
     * Sets the value of property searchItemsCountPerPage with value pSearchItemsCountPerPage
     * 
     * @param pSearchItemsCountPerPage
     *            the searchItemsCountPerPage to set
     */
    public void setSearchItemsCountPerPage( int pSearchItemsCountPerPage) {
        mSearchItemsCountPerPage = pSearchItemsCountPerPage;
    }

    /**
     * Gets the value of recordSetCount
     * 
     * @return returns the property recordSetCount
     */
    public long getRecordSetCount() {
        return mRecordSetCount;
    }

    /**
     * Sets the value of property recordSetCount with value pRecordSetCount
     * 
     * @param pRecordSetCount
     *            the recordSetCount to set
     */
    public void setRecordSetCount( long pRecordSetCount) {
        mRecordSetCount = pRecordSetCount;
    }

    /**
     * Gets the value of pageCount
     * 
     * @return returns the property pageCount
     */
    public double getPageCount() {
        return mPageCount;
    }

    /**
     * Sets the value of property pageCount with value pPageCount
     * 
     * @param pPageCount
     *            the pageCount to set
     */
    public void setPageCount( double pPageCount) {
        mPageCount = pPageCount;
    }

    /**
     * Gets the value of leftNavQueryType
     * 
     * @return returns the property leftNavQueryType
     */
    public String getLeftNavQueryType() {
        return mLeftNavQueryType;
    }

    /**
     * Sets the value of property leftNavQueryType with value pLeftNavQueryType
     * 
     * @param pLeftNavQueryType
     *            the leftNavQueryType to set
     */
    public void setLeftNavQueryType( String pLeftNavQueryType) {
        mLeftNavQueryType = pLeftNavQueryType;
    }

}
