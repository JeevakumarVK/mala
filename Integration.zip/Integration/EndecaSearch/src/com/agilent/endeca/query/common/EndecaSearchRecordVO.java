/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

import java.util.HashMap;

/**
 * <p>
 * This is a request scope value object used to store necessary details to create Endeca search query. This object is populated by any component which need to
 * query the Endeca search engine. EndecaSearchVo object is passed to EndecaSearchManager class where the populated data is used for creating search query
 * depending on the type of query.
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 10:29:44 AM Author: Ramandeep_Singh
 */

public class EndecaSearchRecordVO {

    private HashMap<String, String> mRecordKeyValueMap = null;

    /**
     * Gets the value of recordKeyValueMap
     * 
     * @return returns the property recordKeyValueMap
     */
    public HashMap<String, String> getRecordKeyValueMap() {
        return mRecordKeyValueMap;
    }

    /**
     * Sets the value of property recordKeyValueMap with value pRecordKeyValueMap
     * 
     * @param pRecordKeyValueMap
     *            the recordKeyValueMap to set
     */
    public void setRecordKeyValueMap( HashMap<String, String> pRecordKeyValueMap) {
        mRecordKeyValueMap = pRecordKeyValueMap;
    }

}
