/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchSuggestionOutput
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 11-Jan-2013 1:42:55 PM Author: Ramandeep_Singh
 */

public class EndecaSearchSuggestionOutput {

    private Long   mLanguageNavID           = 0l;

    private String mSearchTerm              = null;
    private String mSearchInterface         = null;
    private String mUserLanguage            = "";
    private int    mSearchItemsCountPerPage = 0;

    /**
     * Gets the value of languageNavID
     * 
     * @return returns the property languageNavID
     */
    public Long getLanguageNavID() {
        return mLanguageNavID;
    }

    /**
     * Sets the value of property languageNavID with value pLanguageNavID
     * 
     * @param pLanguageNavID
     *            the languageNavID to set
     */
    public void setLanguageNavID( Long pLanguageNavID) {
        mLanguageNavID = pLanguageNavID;
    }

    /**
     * Gets the value of searchTerm
     * 
     * @return returns the property searchTerm
     */
    public String getSearchTerm() {
        return mSearchTerm;
    }

    /**
     * Sets the value of property searchTerm with value pSearchTerm
     * 
     * @param pSearchTerm
     *            the searchTerm to set
     */
    public void setSearchTerm( String pSearchTerm) {
        mSearchTerm = pSearchTerm;
    }

    /**
     * Gets the value of searchInterface
     * 
     * @return returns the property searchInterface
     */
    public String getSearchInterface() {
        return mSearchInterface;
    }

    /**
     * Sets the value of property searchInterface with value pSearchInterface
     * 
     * @param pSearchInterface
     *            the searchInterface to set
     */
    public void setSearchInterface( String pSearchInterface) {
        mSearchInterface = pSearchInterface;
    }

    /**
     * Gets the value of userLanguage
     * 
     * @return returns the property userLanguage
     */
    public String getUserLanguage() {
        return mUserLanguage;
    }

    /**
     * Sets the value of property userLanguage with value pUserLanguage
     * 
     * @param pUserLanguage
     *            the userLanguage to set
     */
    public void setUserLanguage( String pUserLanguage) {
        mUserLanguage = pUserLanguage;
    }

    /**
     * Gets the value of searchItemsCountPerPage
     * 
     * @return returns the property searchItemsCountPerPage
     */
    public int getSearchItemsCountPerPage() {
        return mSearchItemsCountPerPage;
    }

    /**
     * Sets the value of property searchItemsCountPerPage with value pSearchItemsCountPerPage
     * 
     * @param pSearchItemsCountPerPage
     *            the searchItemsCountPerPage to set
     */
    public void setSearchItemsCountPerPage( int pSearchItemsCountPerPage) {
        mSearchItemsCountPerPage = pSearchItemsCountPerPage;
    }

}
