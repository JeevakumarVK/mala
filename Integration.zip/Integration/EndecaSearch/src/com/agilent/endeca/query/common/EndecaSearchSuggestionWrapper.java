/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchSuggestionWrapper
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 11-Jan-2013 2:52:39 PM Author: Ramandeep_Singh
 */

public class EndecaSearchSuggestionWrapper {

    public Map<String, List<EndecaSearchRecordVO>> mSearchSuggestionCategoryMap = null;
    private Long                                   mTotalRecordCount            = null;

    /**
     * Gets the value of totalRecordCount
     * 
     * @return returns the property totalRecordCount
     */
    public Long getTotalRecordCount() {
        return mTotalRecordCount;
    }

    /**
     * Sets the value of property totalRecordCount with value pTotalRecordCount
     * 
     * @param pTotalRecordCount
     *            the totalRecordCount to set
     */
    public void setTotalRecordCount( Long pTotalRecordCount) {
        mTotalRecordCount = pTotalRecordCount;
    }

    /**
     * Gets the value of searchSuggestionCategoryMap
     * 
     * @return returns the property searchSuggestionCategoryMap
     */
    public Map<String, List<EndecaSearchRecordVO>> getSearchSuggestionCategoryMap() {
        return mSearchSuggestionCategoryMap;
    }

    /**
     * Sets the value of property searchSuggestionCategoryMap with value pSearchSuggestionCategoryMap
     * 
     * @param pSearchSuggestionCategoryMap
     *            the searchSuggestionCategoryMap to set
     */
    public void setSearchSuggestionCategoryMap( Map<String, List<EndecaSearchRecordVO>> pSearchSuggestionCategoryMap) {
        mSearchSuggestionCategoryMap = pSearchSuggestionCategoryMap;
    }

}
