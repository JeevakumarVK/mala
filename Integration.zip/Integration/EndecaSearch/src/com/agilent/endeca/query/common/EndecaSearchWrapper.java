/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS SearchResultWrapper
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 27-Dec-2012 4:37:02 PM Author: Ramandeep_Singh
 */

public class EndecaSearchWrapper {

    private List<EndecaSearchRecordVO>               mEndecaSearchRecordVOList = null;
    private Long                                     mTotalRecordCount         = null;
    private Map<String, List<EndecaSearchLeftNavVO>> mNavigationMap            = null;
    private String                                   mDYMSuggestion            = null;
    private String                                   mAutoCorrection           = null;
    private double                                   mQueryResponseTime        = 0.0;

    /**
     * Gets the value of queryResponseTime
     * 
     * @return returns the property queryResponseTime
     */
    public double getQueryResponseTime() {
        return mQueryResponseTime;
    }

    /**
     * Sets the value of property queryResponseTime with value pQueryResponseTime
     * 
     * @param pQueryResponseTime
     *            the queryResponseTime to set
     */
    public void setQueryResponseTime( double pQueryResponseTime) {
        mQueryResponseTime = pQueryResponseTime;
    }

    /**
     * Gets the value of dYMSuggestion
     * 
     * @return returns the property dYMSuggestion
     */
    public String getDYMSuggestion() {
        return mDYMSuggestion;
    }

    /**
     * Sets the value of property dYMSuggestion with value pDYMSuggestion
     * 
     * @param pDYMSuggestion
     *            the dYMSuggestion to set
     */
    public void setDYMSuggestion( String pDYMSuggestion) {
        mDYMSuggestion = pDYMSuggestion;
    }

    /**
     * Gets the value of autoCorrection
     * 
     * @return returns the property autoCorrection
     */
    public String getAutoCorrection() {
        return mAutoCorrection;
    }

    /**
     * Sets the value of property autoCorrection with value pAutoCorrection
     * 
     * @param pAutoCorrection
     *            the autoCorrection to set
     */
    public void setAutoCorrection( String pAutoCorrection) {
        mAutoCorrection = pAutoCorrection;
    }

    /**
     * Gets the value of navigationMap
     * 
     * @return returns the property navigationMap
     */
    public Map<String, List<EndecaSearchLeftNavVO>> getNavigationMap() {
        return mNavigationMap;
    }

    /**
     * Sets the value of property navigationMap with value pNavigationMap
     * 
     * @param pNavigationMap
     *            the navigationMap to set
     */
    public void setNavigationMap( Map<String, List<EndecaSearchLeftNavVO>> pNavigationMap) {
        mNavigationMap = pNavigationMap;
    }

    /**
     * Gets the value of endecaSearchRecordVOList
     * 
     * @return returns the property endecaSearchRecordVOList
     */
    public List<EndecaSearchRecordVO> getEndecaSearchRecordVOList() {
        return mEndecaSearchRecordVOList;
    }

    /**
     * Sets the value of property endecaSearchRecordVOList with value pEndecaSearchRecordVOList
     * 
     * @param pEndecaSearchRecordVOList
     *            the endecaSearchRecordVOList to set
     */
    public void setEndecaSearchRecordVOList( List<EndecaSearchRecordVO> pEndecaSearchRecordVOList) {
        mEndecaSearchRecordVOList = pEndecaSearchRecordVOList;
    }

    /**
     * Gets the value of totalRecordCount
     * 
     * @return returns the property totalRecordCount
     */
    public Long getTotalRecordCount() {
        return mTotalRecordCount;
    }

    /**
     * Sets the value of property totalRecordCount with value pTotalRecordCount
     * 
     * @param pTotalRecordCount
     *            the totalRecordCount to set
     */
    public void setTotalRecordCount( Long pTotalRecordCount) {
        mTotalRecordCount = pTotalRecordCount;
    }

}
