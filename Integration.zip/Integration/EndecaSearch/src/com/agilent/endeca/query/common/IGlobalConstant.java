/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.common;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS EndecaSearchConstant
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 1:21:08 PM Author: Ramandeep_Singh
 */

public interface IGlobalConstant {

    public static final String ENCODING_FORMAT             = "UTF-8";
    public static final String NAV_ID                      = "0";
    public static final String ROOT                        = "0";
    public static final String AMP_NTT                     = "&Ntt=";
    public static final String NTK_ALL                     = "All";
    public static final String AMP_D                       = "&D=";
    public static final String CHROME                      = "product.code";
    public static final String START_LOCATION              = "product.review.count";
    public static final String END_LOCATION                = "product.review.count";
    public static final String NTY                         = "1";
    public static final String NTX_ALL                     = "mode+matchall";
    public static final String AMP_DX_ALL                  = "&Dx=mode+matchall";
    public static final String AMP_No                      = "&No=";
    public static final String LANGUAGEDIMENSIONNAME       = "Language";
    public static final String DEFAULTLANGUAGE             = "en";
    public static final String CONTENTTYPEDIMENSIONNAME    = "ContentType";
    public static final String SUREFISHDIMVALNAME          = "SureFishProducts";
    public static final String GENOMICSDIMVALNAME          = "GenomicsProducts";
    public static final String LIBRARYDIMVALNAME           = "Library";
    public static final String LIBRARYDISPLAYNAME          = "Library";
    public static final String INFORMATIONAREASDISPLAYNAME = "InformationAreas";
    public static final String PIPE_SEPERATOR              = "|";

}
