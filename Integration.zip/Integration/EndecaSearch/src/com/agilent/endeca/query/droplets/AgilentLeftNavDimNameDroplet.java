/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.droplets;

import static com.agilent.base.platform.Constants.EMPTY;
import static com.agilent.base.platform.Constants.LEFTNAV_NAME;
import static com.agilent.base.platform.Constants.SERVICE_PARAMETER_OUTPUT;
import static com.agilent.base.platform.Constants.TEMPLATE_NAME;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;

import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS AgilentLeftNavDimNameDroplet
 * </p>
 * 
 * @author ramandeep_singh
 * @project Agilent.Integration.EndecaSearch
 * @updated DateTime: 28-Feb-2013 12:25:24 PM Author: ramandeep_singh
 */

public class AgilentLeftNavDimNameDroplet extends DynamoServlet {

    private Map<String, String> mLeftNavDimNameMap = null;

    public void service( DynamoHttpServletRequest pRequest, DynamoHttpServletResponse pResponse) throws ServletException, IOException {
        String libLeftNavName = pRequest.getParameter(LEFTNAV_NAME);
        String templateName = null;
        if (libLeftNavName == null) {
            pRequest.serviceParameter(EMPTY, pRequest, pResponse);
            return;
        } else if (getLeftNavDimNameMap().get(libLeftNavName) != null) {
            templateName = getLeftNavDimNameMap().get(libLeftNavName);
            pRequest.setParameter(TEMPLATE_NAME, templateName);
            pRequest.serviceLocalParameter(SERVICE_PARAMETER_OUTPUT, pRequest, pResponse);
            return;

        } else {
            pRequest.serviceLocalParameter(EMPTY, pRequest, pResponse);
            return;
        }

    }

    /**
     * Gets the value of leftNavDimNameMap
     * 
     * @return returns the property leftNavDimNameMap
     */
    public Map<String, String> getLeftNavDimNameMap() {
        return mLeftNavDimNameMap;
    }

    /**
     * Sets the value of property leftNavDimNameMap with value pLeftNavDimNameMap
     * 
     * @param pLeftNavDimNameMap
     *            the leftNavDimNameMap to set
     */
    public void setLeftNavDimNameMap( Map<String, String> pLeftNavDimNameMap) {
        mLeftNavDimNameMap = pLeftNavDimNameMap;
    }

}
