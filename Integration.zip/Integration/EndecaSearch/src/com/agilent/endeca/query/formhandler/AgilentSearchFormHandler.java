/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.endeca.query.formhandler;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;

import atg.core.util.StringUtils;
import atg.droplet.GenericFormHandler;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;

import com.agilent.endeca.AgilentSearchConfiguration;
import com.agilent.endeca.EndecaSearchManager;
import com.agilent.endeca.query.common.Constants;
import com.agilent.endeca.query.common.EndecaSearchLeftNavVO;
import com.agilent.endeca.query.common.EndecaSearchOutput;
import com.agilent.endeca.query.common.EndecaSearchRecordVO;
import com.agilent.endeca.query.common.EndecaSearchSuggestionOutput;
import com.agilent.endeca.query.common.EndecaSearchSuggestionWrapper;
import com.agilent.endeca.query.common.EndecaSearchWrapper;

/**
 * <p>
 * AgilentSearchFormHandler class is an ATG Form Handler
 * </p>
 * 
 * @author Ramandeep_Singh
 * @project Agilent.Genomics
 * @updated DateTime: 20-Dec-2012 3:34:07 PM Author: Ramandeep_Singh
 */

public class AgilentSearchFormHandler extends GenericFormHandler {

    public String                                   mSearchInput                  = null;
    public EndecaSearchManager                      mEndecaSearchManager          = null;
    public long                                     mNextPageNumber               = 0;
    public long                                     mPrevPageNumber               = 0;
    public String                                   mSuccessURL                   = null;
    public String                                   mErrorURL                     = null;
    public List<EndecaSearchRecordVO>               mSearchResultRecordList       = null;
    public Map<String, List<EndecaSearchLeftNavVO>> mSearchResultLeftNavMap       = null;
    public EndecaSearchOutput                       mEndecaSearchOutput           = new EndecaSearchOutput();
    public EndecaSearchSuggestionOutput             mEndecaSearchSuggestionOutput = new EndecaSearchSuggestionOutput();
    public Map<String, List<EndecaSearchRecordVO>>  mSearchSuggestionCategoryMap  = null;
    public int                                      mRecordsPerSearchPage         = 0;
    public int                                      mRecordsPerSuggestion         = 0;
    public AgilentSearchConfiguration               mSearchConfiguration          = null;

    // public ErrorHandlerImpl mExceptionHandler = null;

    /**
     * Gets the value of searchInput
     * 
     * @return returns the property searchInput
     */
    public String getSearchInput() {
   
    if (!StringUtils.isEmpty(mSearchInput))
      {
    	return mSearchInput.trim();
      }
      return mSearchInput;
    }

    /**
     * Sets the value of property searchInput with value pSearchInput
     * 
     * @param pSearchInput
     *            the searchInput to set
     */
    public void setSearchInput( String pSearchInput) {
    	
        mSearchInput = pSearchInput;
    }

    /**
     * Gets the value of endecaSearchManager
     * 
     * @return returns the property endecaSearchManager
     */
    public EndecaSearchManager getEndecaSearchManager() {
        return mEndecaSearchManager;
    }

    /**
     * Sets the value of property endecaSearchManager with value pEndecaSearchManager
     * 
     * @param pEndecaSearchManager
     *            the endecaSearchManager to set
     */
    public void setEndecaSearchManager( EndecaSearchManager pEndecaSearchManager) {
        mEndecaSearchManager = pEndecaSearchManager;
    }

    /**
     * Gets the value of nextPageNumber
     * 
     * @return returns the property nextPageNumber
     */
    public long getNextPageNumber() {
        return mNextPageNumber;
    }

    /**
     * Sets the value of property nextPageNumber with value pNextPageNumber
     * 
     * @param pNextPageNumber
     *            the nextPageNumber to set
     */
    public void setNextPageNumber( long pNextPageNumber) {
        mNextPageNumber = pNextPageNumber;
    }

    /**
     * Gets the value of prevPageNumber
     * 
     * @return returns the property prevPageNumber
     */
    public long getPrevPageNumber() {
        return mPrevPageNumber;
    }

    /**
     * Sets the value of property prevPageNumber with value pPrevPageNumber
     * 
     * @param pPrevPageNumber
     *            the prevPageNumber to set
     */
    public void setPrevPageNumber( long pPrevPageNumber) {
        mPrevPageNumber = pPrevPageNumber;
    }

    /**
     * Gets the value of successURL
     * 
     * @return returns the property successURL
     */

    public String getSuccessURL() {
        return mSuccessURL;
    }

    /**
     * Sets the value of property successURL with value pSuccessURL
     * 
     * @param pSuccessURL
     *            the successURL to set
     */
    public void setSuccessURL( String pSuccessURL) {
        mSuccessURL = pSuccessURL;
    }

    /**
     * Gets the value of errorURL
     * 
     * @return returns the property errorURL
     */
    public String getErrorURL() {
        return mErrorURL;
    }

    /**
     * Sets the value of property errorURL with value pErrorURL
     * 
     * @param pErrorURL
     *            the errorURL to set
     */

    public void setErrorURL( String pErrorURL) {
        mErrorURL = pErrorURL;
    }

    /**
     * Gets the value of searchResultRecordList
     * 
     * @return returns the property searchResultRecordList
     */
    public List<EndecaSearchRecordVO> getSearchResultRecordList() {
        return mSearchResultRecordList;
    }

    /**
     * Sets the value of property searchResultRecordList with value pSearchResultRecordList
     * 
     * @param pSearchResultRecordList
     *            the searchResultRecordList to set
     */
    public void setSearchResultRecordList( List<EndecaSearchRecordVO> pSearchResultRecordList) {
        mSearchResultRecordList = pSearchResultRecordList;
    }

    /**
     * Gets the value of endecaSearchOutput
     * 
     * @return returns the property endecaSearchOutput
     */
    public EndecaSearchOutput getEndecaSearchOutput() {
        return mEndecaSearchOutput;
    }

    /**
     * Gets the value of endecaSearchSuggestionOutput
     * 
     * @return returns the property endecaSearchSuggestionOutput
     */
    public EndecaSearchSuggestionOutput getEndecaSearchSuggestionOutput() {
        return mEndecaSearchSuggestionOutput;
    }

    /**
     * Sets the value of property endecaSearchSuggestionOutput with value pEndecaSearchSuggestionOutput
     * 
     * @param pEndecaSearchSuggestionOutput
     *            the endecaSearchSuggestionOutput to set
     */
    public void setEndecaSearchSuggestionOutput( EndecaSearchSuggestionOutput pEndecaSearchSuggestionOutput) {
        mEndecaSearchSuggestionOutput = pEndecaSearchSuggestionOutput;
    }

    /**
     * Sets the value of property endecaSearchOutput with value pEndecaSearchOutput
     * 
     * @param pEndecaSearchOutput
     *            the endecaSearchOutput to set
     */
    public void setEndecaSearchOutput( EndecaSearchOutput pEndecaSearchOutput) {
        mEndecaSearchOutput = pEndecaSearchOutput;
    }

    /**
     * Gets the value of searchResultLeftNavMap
     * 
     * @return returns the property searchResultLeftNavMap
     */
    public Map<String, List<EndecaSearchLeftNavVO>> getSearchResultLeftNavMap() {
        return mSearchResultLeftNavMap;
    }

    /**
     * Sets the value of property searchResultLeftNavMap with value pSearchResultLeftNavMap
     * 
     * @param pSearchResultLeftNavMap
     *            the searchResultLeftNavMap to set
     */
    public void setSearchResultLeftNavMap( Map<String, List<EndecaSearchLeftNavVO>> pSearchResultLeftNavMap) {
        mSearchResultLeftNavMap = pSearchResultLeftNavMap;
    }

    /**
     * Gets the value of recordsPerSearchPage
     * 
     * @return returns the property recordsPerSearchPage
     */
    public int getRecordsPerSearchPage() {
        return mRecordsPerSearchPage;
    }

    /**
     * Sets the value of property recordsPerSearchPage with value pRecordsPerSearchPage
     * 
     * @param pRecordsPerSearchPage
     *            the recordsPerSearchPage to set
     */
    public void setRecordsPerSearchPage( int pRecordsPerSearchPage) {
        mRecordsPerSearchPage = pRecordsPerSearchPage;
    }

    /**
     * Gets the value of recordsPerSuggestion
     * 
     * @return returns the property recordsPerSuggestion
     */
    public int getRecordsPerSuggestion() {
        return mRecordsPerSuggestion;
    }

    /**
     * Sets the value of property recordsPerSuggestion with value pRecordsPerSuggestion
     * 
     * @param pRecordsPerSuggestion
     *            the recordsPerSuggestion to set
     */
    public void setRecordsPerSuggestion( int pRecordsPerSuggestion) {
        mRecordsPerSuggestion = pRecordsPerSuggestion;
    }

    /**
     * Gets the value of searchConfiguration
     * 
     * @return returns the property searchConfiguration
     */
    public AgilentSearchConfiguration getSearchConfiguration() {
        return mSearchConfiguration;
    }

    /**
     * Sets the value of property searchConfiguration with value pSearchConfiguration
     * 
     * @param pSearchConfiguration
     *            the searchConfiguration to set
     */
    public void setSearchConfiguration( AgilentSearchConfiguration pSearchConfiguration) {
        mSearchConfiguration = pSearchConfiguration;
    }

    /**
     * Gets the value of searchSuggestionCategoryMap
     * 
     * @return returns the property searchSuggestionCategoryMap
     */
    public Map<String, List<EndecaSearchRecordVO>> getSearchSuggestionCategoryMap() {
        return mSearchSuggestionCategoryMap;
    }

    /**
     * Sets the value of property searchSuggestionCategoryMap with value pSearchSuggestionCategoryMap
     * 
     * @param pSearchSuggestionCategoryMap
     *            the searchSuggestionCategoryMap to set
     */
    public void setSearchSuggestionCategoryMap( Map<String, List<EndecaSearchRecordVO>> pSearchSuggestionCategoryMap) {
        mSearchSuggestionCategoryMap = pSearchSuggestionCategoryMap;
    }

    /**
     * @param request
     * @param response
     * @return
     */
    public boolean preHandleSearch( DynamoHttpServletRequest request, DynamoHttpServletResponse response) {
        String defaultText = request.getParameter("defaultText");

        if (!StringUtils.isEmpty(getSearchInput())) {
            if (!getSearchInput().equals(defaultText)) {
                clearSearchVariables();
                return true;
            }

        }

        return false;
    }

    public boolean handleSearch( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        long startTime = System.currentTimeMillis();
        String baseQuery = null;
        vlogDebug("AgilentSearchFormHandler - [handleSearch] = Entered in method \n");
        double pageCount = 0;
        String searchQueryString = request.getQueryString();

        if (searchQueryString != null) {
            if (searchQueryString.contains("Ntt") && searchQueryString.contains("No")) {
                setSearchInput(URLEncoder.encode(request.getParameter("Ntt"), Constants.ENCODING_FORMAT));
            }
        }

        if (!preHandleSearch(request, response)) {
            getEndecaSearchOutput().setStartRecordNumber(0);
            return checkFormRedirect(getSuccessURL(), getErrorURL(), request, response);
        }

        if (request.getParameter("didYouMeanText") != null) {
            vlogDebug("AgilentSearchFormHandler - [handleSearch] = Did you Mean Text : " + request.getParameter("didYouMeanText"));
            setSearchInput(URLEncoder.encode(request.getParameter("didYouMeanText"), Constants.ENCODING_FORMAT));
        } else {
            vlogDebug("AgilentSearchFormHandler - [handleSearch] = Input Text : " + getSearchInput());

            setSearchInput(URLEncoder.encode(getSearchInput(), Constants.ENCODING_FORMAT));
        }

        getEndecaSearchOutput().setOffsetParameter(0);

        getEndecaSearchOutput().setSearchTerm(getSearchInput());

        Locale locale = request.getRequestLocale().getLocale();
        String language = locale.getLanguage();

        if (language != null) {
            getEndecaSearchOutput().setUserLanguage(language);
        } else {
            getEndecaSearchOutput().setUserLanguage(getSearchConfiguration().getDefautLanguage());
        }

        vlogDebug("AgilentSearchFormHandler - [handleSearch] = Locale Language : " + getEndecaSearchOutput().getUserLanguage());

        getEndecaSearchOutput().setSearchItemsCountPerPage(getRecordsPerSearchPage());

        getEndecaSearchManager().populateNavigationIDsForBasicSearch(getSearchInput(), getEndecaSearchOutput());

        if (getEndecaSearchOutput().getLanguageNavID() == null || getEndecaSearchOutput().getLanguageNavID() == 0l) {
            setZeroResultsParameters();

        } else {

            baseQuery = getEndecaSearchManager().createSearchBaseQuery(getEndecaSearchOutput());

            vlogDebug("AgilentSearchFormHandler - [handleSearch] = Basic Search Query : " + baseQuery);

            EndecaSearchWrapper searchResultWrapper = getEndecaSearchManager().searchEndecaQuery(getEndecaSearchOutput(), baseQuery);
            getEndecaSearchOutput().setAutoCorrection(searchResultWrapper.getAutoCorrection());
            getEndecaSearchOutput().setDYMSuggestion(searchResultWrapper.getDYMSuggestion());
            getEndecaSearchOutput().setQueryResponseTime(searchResultWrapper.getQueryResponseTime());
            getEndecaSearchOutput().setSearchTerm(URLDecoder.decode(getSearchInput(), Constants.ENCODING_FORMAT));
            boolean checkZeroResult = checkForZeroResult(getEndecaSearchOutput());
            if (checkZeroResult == true) {
                getEndecaSearchOutput().setAutoCorrection(null);
                setZeroResultsParameters();
            } else {

                setSearchResultRecordList(searchResultWrapper.getEndecaSearchRecordVOList());
                setSearchResultLeftNavMap(searchResultWrapper.getNavigationMap());
                getEndecaSearchOutput().setRecordSetCount(searchResultWrapper.getTotalRecordCount());
                getEndecaSearchOutput().setStartRecordNumber(getEndecaSearchOutput().getNextPageNumToMove() - 1);
                if (getEndecaSearchOutput().getRecordSetCount() <= getEndecaSearchOutput().getSearchItemsCountPerPage()) {
                    getEndecaSearchOutput().setEndRecordNumber(getEndecaSearchOutput().getRecordSetCount());
                } else {
                    getEndecaSearchOutput().setEndRecordNumber(getEndecaSearchOutput().getSearchItemsCountPerPage());
                }
                pageCount = getPageCount(searchResultWrapper.getTotalRecordCount(), getEndecaSearchOutput().getSearchItemsCountPerPage());
                getEndecaSearchOutput().setPageCount(pageCount);
            }
        }

        long endTime = System.currentTimeMillis();
        double diff = (endTime - startTime) / 1000.0d;
        getEndecaSearchOutput().setQueryResponseTime(diff);

        vlogDebug("AgilentSearchFormHandler - [handleSearch] = Exit method \n");
        return checkFormRedirect(getSuccessURL() + "?" + baseQuery + Constants.AMP_BASE_SEARCH_TYPE, getErrorURL(), request, response);
    }

    /**
     * 
     */
    private void setZeroResultsParameters() {
        setSearchResultRecordList(new ArrayList<EndecaSearchRecordVO>()); // empty Map and here send an intimation that there are no record to display

        getEndecaSearchOutput().setRecordSetCount(0l);
        getEndecaSearchOutput().setStartRecordNumber(0l);
    }

    private boolean checkForZeroResult( EndecaSearchOutput pEndecaSearchOutputVO) {
        if (pEndecaSearchOutputVO.getSureFishDimValId() == null && pEndecaSearchOutputVO.getGenomicsDimValId() == null
                && pEndecaSearchOutputVO.getLibraryDimValId() == null && pEndecaSearchOutputVO.getExportLibraryDimValId() == null
                && pEndecaSearchOutputVO.getGeneDimValId() == null) {
            return true;
        }
        return false;

    }

    public boolean handleNextSearch( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        vlogDebug("AgilentSearchFormHandler - [handleNextSearch] = Entered in method \n");

        long startTime = System.currentTimeMillis();

        long pageToMove = getNextPageNumber();
        double pageCount = getEndecaSearchOutput().getPageCount();
        long nextSearchOffsetValue = 0;
        String baseQuery = null;

        if ((pageToMove <= pageCount) && (pageToMove >= 2)) {
            nextSearchOffsetValue = ((pageToMove - 1) * getEndecaSearchOutput().getSearchItemsCountPerPage());
            getEndecaSearchOutput().setSearchTerm(URLEncoder.encode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
            getEndecaSearchOutput().setOffsetParameter(nextSearchOffsetValue);
            if (getEndecaSearchOutput().getLeftNavQuery() != null) {
                baseQuery = getEndecaSearchOutput().getLeftNavQuery();
                baseQuery = baseQuery + "&No=" + getEndecaSearchOutput().getOffsetParameter();

            } else {
                baseQuery = getEndecaSearchManager().createSearchBaseQuery(getEndecaSearchOutput());
            }

            vlogDebug("AgilentSearchFormHandler - [handleNextSearch] = Next Nav Query : " + baseQuery);
            EndecaSearchWrapper searchResultWrapper = getEndecaSearchManager().searchEndecaQuery(getEndecaSearchOutput(), baseQuery);

            if (searchResultWrapper != null) {

                setSearchResultRecordList(searchResultWrapper.getEndecaSearchRecordVOList());
                getEndecaSearchOutput().setQueryResponseTime(searchResultWrapper.getQueryResponseTime());
                getEndecaSearchOutput().setRecordSetCount(searchResultWrapper.getTotalRecordCount());
                getEndecaSearchOutput().setStartRecordNumber(nextSearchOffsetValue + 1);

                if ((nextSearchOffsetValue + (getEndecaSearchOutput().getSearchItemsCountPerPage() - 1)) < getEndecaSearchOutput().getRecordSetCount()) {
                    getEndecaSearchOutput().setEndRecordNumber(nextSearchOffsetValue + (getEndecaSearchOutput().getSearchItemsCountPerPage()));

                } else {
                    getEndecaSearchOutput().setEndRecordNumber(getEndecaSearchOutput().getRecordSetCount());
                }

                getEndecaSearchOutput().setNextPageNumToMove(pageToMove + 1);
                getEndecaSearchOutput().setPrevPageNumToMove(pageToMove);

            }

            getEndecaSearchOutput().setSearchTerm(URLDecoder.decode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
        }

        vlogDebug("AgilentSearchFormHandler - [handleNextSearch] = Exit method \n");

        long endTime = System.currentTimeMillis();
        double diff = (endTime - startTime) / 1000.0d;
        getEndecaSearchOutput().setQueryResponseTime(diff);
        return checkFormRedirect(null, getErrorURL(), request, response);

    }

    public boolean handlePrevSearch( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {

        vlogDebug("AgilentSearchFormHandler - [handlePrevSearch] = Entered in method \n");

        long startTime = System.currentTimeMillis();

        long preSearchOffsetValue = 0;
        long pageToMove = getPrevPageNumber();
        String baseQuery = null;
        preSearchOffsetValue = ((pageToMove - 2) * getEndecaSearchOutput().getSearchItemsCountPerPage());

        getEndecaSearchOutput().setSearchTerm(URLEncoder.encode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
        getEndecaSearchOutput().setOffsetParameter(preSearchOffsetValue);
        if (getEndecaSearchOutput().getLeftNavQueryType() != null) {
            baseQuery = getEndecaSearchOutput().getLeftNavQuery();
            baseQuery = baseQuery + "&No=" + getEndecaSearchOutput().getOffsetParameter();
        } else {
            baseQuery = getEndecaSearchManager().createSearchBaseQuery(getEndecaSearchOutput());
        }

        vlogDebug("AgilentSearchFormHandler - [handlePrevSearch] = Prev Nav Query : " + baseQuery);
        EndecaSearchWrapper searchResultWrapper = getEndecaSearchManager().searchEndecaQuery(getEndecaSearchOutput(), baseQuery);

        if (searchResultWrapper != null) {

            setSearchResultRecordList(searchResultWrapper.getEndecaSearchRecordVOList());
            getEndecaSearchOutput().setQueryResponseTime(searchResultWrapper.getQueryResponseTime());
            getEndecaSearchOutput().setRecordSetCount(searchResultWrapper.getTotalRecordCount());
            getEndecaSearchOutput().setStartRecordNumber(preSearchOffsetValue + 1);
            getEndecaSearchOutput().setEndRecordNumber(preSearchOffsetValue + (getEndecaSearchOutput().getSearchItemsCountPerPage()));
            getEndecaSearchOutput().setNextPageNumToMove(pageToMove);
            getEndecaSearchOutput().setPrevPageNumToMove(pageToMove - 1);
            getEndecaSearchOutput().setSearchTerm(URLDecoder.decode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
            long endSuccessTime = System.currentTimeMillis();
            double diff = (endSuccessTime - startTime) / 1000.0d;
            getEndecaSearchOutput().setQueryResponseTime(diff);
            return true;

        }
        getEndecaSearchOutput().setSearchTerm(URLDecoder.decode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
        vlogDebug("AgilentSearchFormHandler - [handlePrevSearch] = Exit method \n");

        return checkFormRedirect(null, getErrorURL(), request, response);

    }

    public boolean handleSearchWithInSearch( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {
        vlogDebug("AgilentSearchFormHandler - [handleSearchWithInSearch] = Entered in method \n");
        long startTime = System.currentTimeMillis();

        cleaerLeftNavVariables();
        double pageCount = 0;

        // String query = request.getParameter("navURL");
        String query = request.getQueryString();

        String type = request.getParameter("type");
        vlogDebug("AgilentSearchFormHandler - [handleSearchWithInSearch] = navURL query : " + query);
        getEndecaSearchOutput().setLeftNavQueryType(type);

        if (getEndecaSearchOutput().getAutoCorrection() != null && getEndecaSearchOutput().getAutoCorrection() != "") {
            setSearchInput(URLEncoder.encode(getEndecaSearchOutput().getAutoCorrection(), Constants.ENCODING_FORMAT));
            getEndecaSearchOutput().setSearchTerm(getSearchInput());
        } else {

            if (query != null) {
                if (query.contains("Ntt")) {
                    setSearchInput(URLEncoder.encode(request.getParameter("Ntt"), Constants.ENCODING_FORMAT));
                    getEndecaSearchOutput().setSearchTerm(getSearchInput());
                    getEndecaSearchOutput().setSearchItemsCountPerPage(10);
                }
            } else {
                getEndecaSearchOutput().setSearchTerm(URLEncoder.encode(getEndecaSearchOutput().getSearchTerm(), Constants.ENCODING_FORMAT));
                setSearchInput(getEndecaSearchOutput().getSearchTerm());
            }

        }

        if (query != null && query.contains("Ntt")) {
            getEndecaSearchManager().populateNavigationIDsForBasicSearch(getSearchInput(), getEndecaSearchOutput());
        }
        EndecaSearchWrapper searchResultWrapper = getEndecaSearchManager().searchEndecaQuery(getEndecaSearchOutput(), query);
        if (searchResultWrapper != null) {
            if (searchResultWrapper.getTotalRecordCount() == 0) {
                getEndecaSearchOutput().setRecordSetCount(0L);
                getEndecaSearchOutput().setStartRecordNumber(0L);
            } else {
                setSearchResultRecordList(searchResultWrapper.getEndecaSearchRecordVOList());
                setSearchResultLeftNavMap(searchResultWrapper.getNavigationMap());
                getEndecaSearchOutput().setRecordSetCount(searchResultWrapper.getTotalRecordCount());
                getEndecaSearchOutput().setStartRecordNumber(getEndecaSearchOutput().getNextPageNumToMove() - 1);
                if (getEndecaSearchOutput().getRecordSetCount() <= getEndecaSearchOutput().getSearchItemsCountPerPage()) {
                    getEndecaSearchOutput().setEndRecordNumber(getEndecaSearchOutput().getRecordSetCount());
                } else {
                    getEndecaSearchOutput().setEndRecordNumber(getEndecaSearchOutput().getSearchItemsCountPerPage());
                }
                pageCount = getPageCount(searchResultWrapper.getTotalRecordCount(), getEndecaSearchOutput().getSearchItemsCountPerPage());
                getEndecaSearchOutput().setPageCount(pageCount);
                getEndecaSearchOutput().setSearchTerm(URLDecoder.decode(getSearchInput(), Constants.ENCODING_FORMAT));
            }
        }
        getEndecaSearchOutput().setLeftNavQuery(query);
        vlogDebug("AgilentSearchFormHandler - [handleSearchWithInSearch] = Exit method \n");

        long endTime = System.currentTimeMillis();
        double diff = (endTime - startTime) / 1000.0d;
        getEndecaSearchOutput().setQueryResponseTime(diff);
        return checkFormRedirect(getSuccessURL() + "?" + query, getErrorURL(), request, response);
    }

    /**
     * @param request
     * @param response
     * @return
     * @throws ServletException
     * @throws IOException
     */
    public boolean handleSearchSuggestion( DynamoHttpServletRequest request, DynamoHttpServletResponse response) throws ServletException, IOException {

        vlogDebug("AgilentSearchFormHandler - [handleSearchSuggestion] = Entered in method \n");

        if (!preHandleSearch(request, response)) {
            return checkFormRedirect(getSuccessURL(), getErrorURL(), request, response);
        }

        String searchSuggestionInput = URLEncoder.encode("*" + getSearchInput() + "*", Constants.ENCODING_FORMAT);
        getEndecaSearchSuggestionOutput().setSearchTerm(searchSuggestionInput);

        Locale locale = request.getRequestLocale().getLocale();
        String language = locale.getLanguage();
        if (language != null) {
            getEndecaSearchSuggestionOutput().setUserLanguage(language);
        } else {
            getEndecaSearchSuggestionOutput().setUserLanguage(getSearchConfiguration().getDefautLanguage());
        }

        getEndecaSearchSuggestionOutput().setSearchItemsCountPerPage(getRecordsPerSuggestion());
        // From here..
        getEndecaSearchManager().populateLanguageNavigationIDs(searchSuggestionInput, getEndecaSearchSuggestionOutput());

        String baseQuery = getEndecaSearchManager().createSearchSuggestionQuery(getEndecaSearchSuggestionOutput());
        vlogDebug("AgilentSearchFormHandler - [handleSearchSuggestion] = search suggestion query : " + baseQuery);

        EndecaSearchSuggestionWrapper searchSuggestionResultWrapper = getEndecaSearchManager().searchEndecaQueryForSuggestions(
                getEndecaSearchSuggestionOutput(), baseQuery);
        if (searchSuggestionResultWrapper.getTotalRecordCount() == 0) {
            setSearchSuggestionCategoryMap(new HashMap<String, List<EndecaSearchRecordVO>>()); // empty Map and here send an intimation that there are no record
                                                                                               // to display
        } else {
            setSearchSuggestionCategoryMap(searchSuggestionResultWrapper.getSearchSuggestionCategoryMap());
        }

        vlogDebug("AgilentSearchFormHandler - [handleSearch] = Exit method \n");

        return checkFormRedirect(getSuccessURL(), getErrorURL(), request, response);
    }

    /**
     * @param pTotalRecordCount
     * @param pSearchItemsCountPerPage
     * @return
     */
    private double getPageCount( double pTotalRecordCount, double pSearchItemsCountPerPage) {
        return Math.ceil(pTotalRecordCount / pSearchItemsCountPerPage);
    }

    private void clearSearchVariables() {
        getEndecaSearchOutput().setEndRecordNumber(0);
        getEndecaSearchOutput().setStartRecordNumber(0);
        getEndecaSearchOutput().setRecordSetCount(0);
        getEndecaSearchOutput().setNextPageNumToMove(2);
        getEndecaSearchOutput().setPrevPageNumToMove(1);
        getEndecaSearchOutput().setLeftNavQueryType(null);
        getEndecaSearchOutput().setLeftNavQuery(null);
        getEndecaSearchOutput().setOffsetParameter(0);
        getEndecaSearchOutput().setSureFishDimValId(null);
        getEndecaSearchOutput().setGenomicsDimValId(null);
        getEndecaSearchOutput().setLibraryDimValId(null);
        getEndecaSearchOutput().setGeneDimValId(null);
        getEndecaSearchOutput().setExportLibraryDimValId(null);
        getEndecaSearchOutput().setProductOverviewDimValId(null);
        getEndecaSearchOutput().setChildProbesDimValId(null);
        getEndecaSearchOutput().setCytoBandsDimValId(null);
        getEndecaSearchOutput().setLanguageNavID(null);
        getEndecaSearchOutput().setDYMSuggestion("");
        // getEndecaSearchOutput().setAutoCorrection("");

    }

    private void cleaerLeftNavVariables() {
        getEndecaSearchOutput().setEndRecordNumber(0);
        getEndecaSearchOutput().setStartRecordNumber(0);
        getEndecaSearchOutput().setRecordSetCount(0);
        getEndecaSearchOutput().setNextPageNumToMove(2);
        getEndecaSearchOutput().setPrevPageNumToMove(1);
        getEndecaSearchOutput().setLeftNavQueryType(null);
        getEndecaSearchOutput().setLeftNavQuery(null);
        getEndecaSearchOutput().setOffsetParameter(0);
    }

}
