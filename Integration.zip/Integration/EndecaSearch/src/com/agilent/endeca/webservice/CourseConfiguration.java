/**
 * 
 */
package com.agilent.endeca.webservice;

import java.util.List;
import java.util.Map;

/**
 * @author saini_i
 *
 */
public class CourseConfiguration {
	public String mAuthenticate_username;
	public String mAuthenticate_password;
	public String mAuthenticate_companyId;
	public String mAuthenticate_productId;
	public String mAuthenticate_courseActive;
	public String mNodePropNamePrefix;
	public String mFilePath;
	public List<String> mSchedulePropImportList;
	public static String mServicePath;
	public String ssourl;
	public Map<String, String> lidMap;
	public Map<String, String> proxyAddress;
	public String vcRedirectBaseURL;
	List<String> renderedNodeList = null;
	Map<String,String> applicationIdMap= null;
	
	public List<String> getRenderedNodeList() {
		return renderedNodeList;
	}

	public void setRenderedNodeList(List<String> renderedNodeList) {
		this.renderedNodeList = renderedNodeList;
	}

		public Map<String, String> getApplicationIdMap() {
		return applicationIdMap;
	}

	public void setApplicationIdMap(Map<String, String> applicationIdMap) {
		this.applicationIdMap = applicationIdMap;
	}
	
	public String getVcRedirectBaseURL() {
		return vcRedirectBaseURL;
	}
	public void setVcRedirectBaseURL(String vcRedirectBaseURL) {
		this.vcRedirectBaseURL = vcRedirectBaseURL;
	}
	/**
	 * @return the proxyAddress
	 */
	public Map<String, String> getProxyAddress() {
		return proxyAddress;
	}
	/**
	 * @param proxyAddress the proxyAddress to set
	 */
	public void setProxyAddress(Map<String, String> proxyAddress) {
		this.proxyAddress = proxyAddress;
	}
	/**
	 * @return the lidMap
	 */
	public Map<String, String> getLidMap() {
		return lidMap;
	}
	/**
	 * @param lidMap the lidMap to set
	 */
	public void setLidMap(Map<String, String> lidMap) {
		this.lidMap = lidMap;
	}
	/**
	 * @return the ssourl
	 */
	public String getSsourl() {
		return ssourl;
	}
	/**
	 * @param ssourl the ssourl to set
	 */
	public void setSsourl(String ssourl) {
		this.ssourl = ssourl;
	}
	/**
	 * @return the servicePath
	 */
	public static String getServicePath() {
		return mServicePath;
	}
	/**
	 * @param pServicePath the servicePath to set
	 */
	public void setServicePath(String pServicePath) {
		mServicePath = pServicePath;
	}
	//public String authenticate_username;
	/**
	 * @return the authenticate_username
	 */
	public String getAuthenticate_username() {
		return mAuthenticate_username;
	}
	/**
	 * @param pAuthenticate_username the authenticate_username to set
	 */
	public void setAuthenticate_username(String pAuthenticate_username) {
		mAuthenticate_username = pAuthenticate_username;
	}
	/**
	 * @return the authenticate_password
	 */
	public String getAuthenticate_password() {
		return mAuthenticate_password;
	}
	/**
	 * @param pAuthenticate_password the authenticate_password to set
	 */
	public void setAuthenticate_password(String pAuthenticate_password) {
		mAuthenticate_password = pAuthenticate_password;
	}
	/**
	 * @return the authenticate_companyId
	 */
	public String getAuthenticate_companyId() {
		return mAuthenticate_companyId;
	}
	/**
	 * @param pAuthenticate_companyId the authenticate_companyId to set
	 */
	public void setAuthenticate_companyId(String pAuthenticate_companyId) {
		mAuthenticate_companyId = pAuthenticate_companyId;
	}
	/**
	 * @return the authenticate_productId
	 */
	public String getAuthenticate_productId() {
		return mAuthenticate_productId;
	}
	/**
	 * @param pAuthenticate_productId the authenticate_productId to set
	 */
	public void setAuthenticate_productId(String pAuthenticate_productId) {
		mAuthenticate_productId = pAuthenticate_productId;
	}
	/**
	 * @return the authenticate_courseActive
	 */
	public String getAuthenticate_courseActive() {
		return mAuthenticate_courseActive;
	}
	/**
	 * @param pAuthenticate_courseActive the authenticate_courseActive to set
	 */
	public void setAuthenticate_courseActive(String pAuthenticate_courseActive) {
		mAuthenticate_courseActive = pAuthenticate_courseActive;
	}
	/**
	 * @return the nodePropNamePrefix
	 */
	public String getNodePropNamePrefix() {
		return mNodePropNamePrefix;
	}
	/**
	 * @param pNodePropNamePrefix the nodePropNamePrefix to set
	 */
	public void setNodePropNamePrefix(String pNodePropNamePrefix) {
		mNodePropNamePrefix = pNodePropNamePrefix;
	}
	/**
	 * @return the filePath
	 */
	public String getFilePath() {
		return mFilePath;
	}
	/**
	 * @param pFilePath the filePath to set
	 */
	public void setFilePath(String pFilePath) {
		mFilePath = pFilePath;
	}
	/**
	 * @return the schedulePropImportList
	 */
	public List<String> getSchedulePropImportList() {
		return mSchedulePropImportList;
	}
	/**
	 * @param pSchedulePropImportList the schedulePropImportList to set
	 */
	public void setSchedulePropImportList(List<String> pSchedulePropImportList) {
		mSchedulePropImportList = pSchedulePropImportList;
	}

}
