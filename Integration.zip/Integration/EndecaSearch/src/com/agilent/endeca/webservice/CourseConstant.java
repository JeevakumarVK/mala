/**
 * 
 */
package com.agilent.endeca.webservice;

/**
 * @author saini_i
 *
 */
public class CourseConstant {
	
	public static final String EMPTY_STRING = "";
	public static final String RECORD_NODE = "RECORD";
	public static final String PROP_NODE = "PROP";
	public static final String PROP_NAME_ATTR = "NAME";
	public static final String PVAL_NODE = "PVAL";
	public static final String RECORDS_NODE = "RECORDS";
	
	
	public static final String WSDL_LOC = "http://inter.viewcentral.com/DataExchangeService/VCExchange.asmx?wsdl";
	public static final String INDENT_FLAG = "yes";
	public static final String DESC_PROP = "sd_description";
	public static final String WEB_DESC_PROP = "sd_webpage_description";
	public static final String TITLE_PROP = "sd_title";
	public static final String COURSE_DAYS_PROP = "sd_course_days";
	public static final String PART_NUM_PROP = "sd_related_part_number";
	public static final String RELATIVE_URL_PROP = "sd_relative_url";	
	
	public static final Object EVENT_SCHEDULE_EVENT_ID = "event_schedule_event_id";
	public static final Object EVENT_SCHEDULE_LANG = "event_schedule_language_cat";
	public static final Object LOCATION_COUNTRY = "location_country";
	public static final Object EVENT_TYPE = "event_types_event_type";
	public static final Object EVENT_SCHEDULE_START_DATE = "event_schedule_start_date";
	public static final Object EVENT_SCHEDULE_END_DATE = "event_schedule_end_date";
	public static final String LANGUAGE = "sd_language";
	public static final String DIM_LANGUAGE = "Endeca.CMS.Misc.Language";
	public static final String DIM_COUNTRY = "Endeca.CMS.Misc.Country";
	public static final String DIM_COURSE_TYPE = "sd_course_type";
	public static final String DEFAULT_LANGUAGE = "English";
	public static final String DIM_PRODUCT = "Endeca.CMS.Misc.Product";
	public static final String DIM_PRODUCT_GROUP = "Endeca.CMS.Misc.ProductGroup";
	public static final String DIM_PRODUCT_TYPE = "Endeca.CMS.Misc.ProductType";
	public static final String APPEND_CHAR = " ";
	public static final String REPLACE_CHAR = "\\";
	public static final String VC_REDIRECT_BASE_URL = "http://inter.viewcentral.com/events/cust/catalog.aspx?eventsPerPage=20&company_login_id=agilent_sbox&pid=1&event_id=";
	public static final String DEFAULT_LID_PARAM = "1";
	public static final String ADD_LID_PARAM = "&lid=";
	public static final String DEFAULT_KEYWORDS = "training, course, ";
	public static final String LMS_INSTANCE_NAME = "LMSData:";

}
