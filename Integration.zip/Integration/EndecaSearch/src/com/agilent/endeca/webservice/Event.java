/**
 * 
 */
package com.agilent.endeca.webservice;

/**
 * @author saini_i
 *
 */
public class Event {
	@Override
    public String toString() {
        return "Event [eventId=" + eventId + ", eventName=" + eventName + ", eventDesc=" + eventDesc + ", eventWebDesc=" + eventWebDesc + ", productId=" + productId + ", url="
                + url + ", duration=" + duration + ", category=" + category + ", langCode=" + langCode + ", translationLangName=" + translationLangName + ", category1=" + category1
                + ", category2=" + category2 + ", category3=" + category3 + ", category4=" + category4 + ", category5=" + category5 + ", durationType=" + durationType + "]";
    }

    String eventId;
	String eventName;
	String eventDesc;
	String eventWebDesc;
	String productId;
	String url;
	String duration;
	String category;
	String langCode;
	String translationLangName;
	
	String category1;
	String category2;
	String category3;
	String category4;
	String category5;
	
	String durationType;
	
	public String getDurationType() {
        return durationType;
    }
    public void setDurationType(String pDurationType) {
        durationType = pDurationType;
    }
    /**
	 * @return the category1
	 */
	public String getCategory1() {
		return category1;
	}
	/**
	 * @param category1 the category1 to set
	 */
	public void setCategory1(String category1) {
		this.category1 = category1;
	}
	/**
	 * @return the category2
	 */
	public String getCategory2() {
		return category2;
	}
	/**
	 * @param category2 the category2 to set
	 */
	public void setCategory2(String category2) {
		this.category2 = category2;
	}
	/**
	 * @return the category3
	 */
	public String getCategory3() {
		return category3;
	}
	/**
	 * @param category3 the category3 to set
	 */
	public void setCategory3(String category3) {
		this.category3 = category3;
	}
	/**
	 * @return the category4
	 */
	public String getCategory4() {
		return category4;
	}
	/**
	 * @param category4 the category4 to set
	 */
	public void setCategory4(String category4) {
		this.category4 = category4;
	}
	/**
	 * @return the category5
	 */
	public String getCategory5() {
		return category5;
	}
	/**
	 * @param category5 the category5 to set
	 */
	public void setCategory5(String category5) {
		this.category5 = category5;
	}
	/**
	 * @return the langCode
	 */
	public String getLangCode() {
		return langCode;
	}
	/**
	 * @param langCode the langCode to set
	 */
	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}
	/**
	 * @return the eventId
	 */
	public String getEventId() {
		return eventId;
	}
	/**
	 * @param eventId the eventId to set
	 */
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}
	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	/**
	 * @return the eventDesc
	 */
	public String getEventDesc() {
		return eventDesc;
	}
	/**
	 * @param eventDesc the eventDesc to set
	 */
	public void setEventDesc(String eventDesc) {
		this.eventDesc = eventDesc;
	}
	/**
	 * @return the eventWebDesc
	 */
	public String getEventWebDesc() {
		return eventWebDesc;
	}
	/**
	 * @param eventWebDesc the eventWebDesc to set
	 */
	public void setEventWebDesc(String eventWebDesc) {
		this.eventWebDesc = eventWebDesc;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * @return the duration
	 */
	public String getDuration() {
		return duration;
	}
	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		this.duration = duration;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getTranslationLangName() {
		return translationLangName;
	}
	
    public void setTranslationLangName(String translationLangName) {
		this.translationLangName = translationLangName;
	}
	
}
