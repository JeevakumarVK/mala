/**
 * 
 */
package com.agilent.endeca.webservice;

import java.io.File;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.BindingProvider;

import org.jsoup.Jsoup;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import atg.nucleus.GenericService;

import com.agilent.base.platform.moss.client.UserProfileServiceSoap;
import com.viewcentral.dataexchange.GetCoursesResponse.GetCoursesResult;
import com.viewcentral.dataexchange.ServiceAuthenticationHeader;
import com.viewcentral.dataexchange.VCExchange;
import com.viewcentral.dataexchange.VCExchangeSoap;

/**
 * @author saini_i
 *
 */
public class GetCoursesInvoke extends GenericService {
	CourseConfiguration courseConfiguration;
	List<String> renderedNodeList = null;
	Map<String,String> applicationIdMap= null;

	/**
	 * @return the courseConfiguration
	 */
	public CourseConfiguration getCourseConfiguration() {
		return courseConfiguration;
	}

	/**
	 * @param courseConfiguration
	 *            the courseConfiguration to set
	 */
	public void setCourseConfiguration(CourseConfiguration courseConfiguration) {
		this.courseConfiguration = courseConfiguration;
	}
	
	
	public List<String> getRenderedNodeList() {
		return renderedNodeList;
	}

	public void setRenderedNodeList(List<String> renderedNodeList) {
		this.renderedNodeList = renderedNodeList;
	}

		public Map<String, String> getApplicationIdMap() {
		return applicationIdMap;
	}

	public void setApplicationIdMap(Map<String, String> applicationIdMap) {
		this.applicationIdMap = applicationIdMap;
	}

	/**
	 * This method is the main method, that invokes the VC API : GetCourses. 
	 * Response is then rendered into an record store format ready to be indexed by Endeca.
	 */
	public void invoke() {
		// call service
	    vlogDebug("create xml in GetCoursesInvoke start ");
		VCExchange vcService = new VCExchange();
        VCExchangeSoap binding = vcService.getVCExchangeSoap();
        Map requestContext = ((BindingProvider) binding).getRequestContext();
        requestContext.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, getCourseConfiguration().getServicePath());
		//VCExchangeSoap port = vcService.getPort(VCExchangeSoap.class);

		// initialize service parameters
		String category = CourseConstant.EMPTY_STRING;
		String courseId = CourseConstant.EMPTY_STRING;
		String courseName = CourseConstant.EMPTY_STRING;
		String courseActive = getCourseConfiguration()
				.getAuthenticate_courseActive();
		String attendeeGroups = CourseConstant.EMPTY_STRING;

		// initialize service authentication parameters
		ServiceAuthenticationHeader serviceAuthenticationHeader = new ServiceAuthenticationHeader();
		serviceAuthenticationHeader.setCompanyLoginId(getCourseConfiguration()
				.getAuthenticate_companyId());
		serviceAuthenticationHeader.setPassword(getCourseConfiguration()
				.getAuthenticate_password());
		serviceAuthenticationHeader.setProductId(getCourseConfiguration()
				.getAuthenticate_productId());
		serviceAuthenticationHeader.setUsername(getCourseConfiguration()
				.getAuthenticate_username());

		// call 'GetCourses' web service
		GetCoursesResult coursesResult = binding.getCourses(category, courseId,
				courseName, courseActive, attendeeGroups,
				serviceAuthenticationHeader);

		// get course response
		List<Object> coursesResultContent = coursesResult.getContent();

		// render course result into a list of map
		List<Map<String, Event>> elementList = renderResponse(coursesResultContent);

		// create xml file for record store
		createXml(elementList);
	}

	/**
	 * This method creates xml file on a specified path.
	 * @param elementList
	 * @throws TransformerFactoryConfigurationError
	 */
	private void createXml(List<Map<String, Event>> elementList)
			throws TransformerFactoryConfigurationError {
		DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder icBuilder;
		Map<String, String> lidMap = getCourseConfiguration().getLidMap();
		try {
			icBuilder = icFactory.newDocumentBuilder();
			Document doc = icBuilder.newDocument();
			Element mainRootElement = doc.createElementNS(
					CourseConstant.EMPTY_STRING, CourseConstant.RECORDS_NODE);
			doc.appendChild(mainRootElement);

			for (Map<String, Event> disMap : elementList) {
				Element recordNode = doc
						.createElement(CourseConstant.RECORD_NODE);
				Set<String> keySet = disMap.keySet();
				for (String key : keySet) {
					recordNode = doc.createElement(CourseConstant.RECORD_NODE);
					Event event = disMap.get(key);
					if (event instanceof Event) {
						String eventId = event.getEventId();
						String eventName = event.getEventName();
						String eventDesc = event.getEventDesc();
						String eventWebDesc = event.getEventWebDesc();
						String prodId = event.getProductId();
						String langCode = event.getLangCode();
						String url = event.getUrl();
						String duration = event.getDuration();
						
						String recordExternal = event.getCategory();
						
						String cat1 = event.getCategory1();
						String cat2 = event.getCategory2();
						String cat3 = event.getCategory3();
						String cat4 = event.getCategory4();
						String cat5 = event.getCategory5();
						vlogDebug("Event detail : eventID{0},eventNAme {1},eventDesc {2},eventWebDesc {3},prodId {4},langCode {5},"
						        + " url {6},duration {7},recordExternal {8}",eventId,eventName,eventDesc,eventWebDesc,prodId,langCode,url,duration,recordExternal);
						String durationType= event.getDurationType();
						vlogDebug("duration type read from event is "+durationType);
						vlogDebug("Duration type read from event is {0}",durationType);
						fillNodes(doc, recordNode, CourseConstant.LANGUAGE, key);
						if (eventName == null || !(eventName instanceof String)) {
							eventName = CourseConstant.EMPTY_STRING;
						}
						if(cat1 == null || !(cat1 instanceof String)){
							cat1 = "";
						}
						if(cat2 == null || !(cat2 instanceof String)){
							cat2 = "";
						}
						if(cat3 == null || !(cat3 instanceof String)){
							cat3 = "";
						}
						if(cat4 == null || !(cat4 instanceof String)){
							cat4 = "";
						}
						if(cat5 == null || !(cat5 instanceof String)){
							cat5 = "";
						}
						if (duration == null || !(duration instanceof String)) {
							duration = CourseConstant.EMPTY_STRING;
						}else{
							// removing one decimal place from course length
							if(duration != ""){
								duration = duration.substring(0, duration.lastIndexOf(".") + 2);
								vlogDebug("Duration value set by ATG {0}",duration);
							}
						}
						if (durationType == null || !(durationType instanceof String)) {
						    durationType = CourseConstant.EMPTY_STRING;
                        }
						if (eventDesc == null || !(eventDesc instanceof String)) {
							eventDesc = CourseConstant.EMPTY_STRING;
						}
						if (eventWebDesc == null
								|| !(eventWebDesc instanceof String))
							eventWebDesc = CourseConstant.EMPTY_STRING;
						if (prodId == null || !(prodId instanceof String)) {
							prodId = CourseConstant.EMPTY_STRING;
						}
						if (eventId == null || !(eventId instanceof String)) {
							eventId = CourseConstant.EMPTY_STRING;
						}
						String lidParam = CourseConstant.DEFAULT_LID_PARAM;
						lidParam = lidMap.get(key);
						if (lidParam == null || lidParam.isEmpty()) {
							lidParam = CourseConstant.DEFAULT_LID_PARAM;
						}
						
						url = getCourseConfiguration().getVcRedirectBaseURL()
									+ eventId + CourseConstant.ADD_LID_PARAM + lidParam;
						
						//url = URLEncoder.encode(url);
						String relevancyKey = CourseConstant.EMPTY_STRING;
						if (!eventName.isEmpty()) {
							String titleTemp = CourseConstant.EMPTY_STRING;
							titleTemp = excludeSpecialCharacters(eventName);
							String descTemp = CourseConstant.EMPTY_STRING;
							descTemp = excludeSpecialCharacters(eventDesc);
							String webDescTemp = CourseConstant.EMPTY_STRING;
							webDescTemp = Jsoup.parse(eventWebDesc).text();
							webDescTemp = excludeSpecialCharacters(webDescTemp);

							relevancyKey = titleTemp + descTemp + webDescTemp;
						}
						String keywords = CourseConstant.DEFAULT_KEYWORDS + eventName;
						fillNodes(doc, recordNode, CourseConstant.RELATIVE_URL_PROP,url);
						fillNodes(doc, recordNode, "sd_id", CourseConstant.LMS_INSTANCE_NAME
								+ langCode + "/Training-Events/" + prodId
								+ ":Event[{" + eventId + "}]");
						fillNodes(doc, recordNode, "sd_related_part_number",
								prodId);
						fillNodes(doc, recordNode, "g_rollup_key", "CourseDetailPage."+prodId);
						fillNodes(doc, recordNode, "sd_description", eventDesc);
						fillNodes(doc, recordNode, "sd_webpage_description",
								eventWebDesc);
						fillNodes(doc, recordNode, "sd_title", eventName);
						fillNodes(doc, recordNode, "Endeca.Document.Language",
								langCode);
						fillNodes(doc, recordNode, "sd_course_days", duration);
						fillNodes(doc, recordNode, "sd_keywords", keywords);
						fillNodes(doc, recordNode, "Endeca.CMS.Misc.Language",
								key);						
						fillNodes(doc, recordNode, "sd_category1", cat1);
						fillNodes(doc, recordNode, "sd_category2", cat2);
						fillNodes(doc, recordNode, "sd_category3", cat3);
						fillNodes(doc, recordNode, "sd_category4", cat4);
						fillNodes(doc, recordNode, "sd_category5", cat5);
						
						fillNodes(doc, recordNode, "sd_course_time", durationType);
						
						mainRootElement.appendChild(recordNode);
					}
				}
				// append child elements to root element
				mainRootElement.appendChild(recordNode);
			}
			// output DOM XML to console
			Transformer transformer = TransformerFactory.newInstance()
					.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT,
					CourseConstant.INDENT_FLAG);
			DOMSource source = new DOMSource(doc);
			StreamResult console = new StreamResult(new File(
					getCourseConfiguration().getFilePath()).getPath());
			transformer.transform(source, console);

			vlogDebug("XML DOM Created Successfully..");

		} catch (Exception e) {
			vlogError(e, "Error while creating xml file for record store....");
		}
	}

	/**
	 * This method excludes special characters from a given string. In this case, a course title
	 * The return value is being used creating a property value for relevancy ranking
	 * @param eventName
	 * @return
	 */
	private static String excludeSpecialCharacters(String eventName) {
		// initialize temp variable
		String temp = CourseConstant.EMPTY_STRING;
		// initialize pattern
		Pattern pt = Pattern.compile("[^a-zA-Z0-9]");
		// match the pattern
		Matcher match = pt.matcher(eventName);
		// loop for running the pattern
		while (match.find()) {
			String s = match.group();
			// exclude special characters
			temp = eventName.replaceAll(CourseConstant.REPLACE_CHAR + s, CourseConstant.APPEND_CHAR);
		}
		return temp;
	}

	/**
	 * This method creates node for each property, and their value respectively.
	 * @param doc
	 * @param recordNode
	 * @throws DOMException
	 */
	private static void fillNodes(Document doc, Element recordNode,
			String propName, String value) throws DOMException {
		Element propNode = doc.createElement(CourseConstant.PROP_NODE);
		propNode.setAttribute(CourseConstant.PROP_NAME_ATTR, propName);
		Element pvalnode = doc.createElement(CourseConstant.PVAL_NODE);
		pvalnode.appendChild(doc.createTextNode(value));
		propNode.appendChild(pvalnode);
		recordNode.appendChild(propNode);
	}

	/**
	 * This method renders the xml response from VC API into list of records.
	 * @param coursesResultContent
	 * @return
	 * @throws DOMException
	 */
	private List<Map<String, Event>> renderResponse(
			List<Object> coursesResultContent) throws DOMException {
		// initialize list for storing records
		List<Map<String, Event>> recordList = new LinkedList<Map<String, Event>>();
		// iterate over course result
		for (Object coursesResultEvents : coursesResultContent) {
			if(coursesResultEvents instanceof Node){
			// get events node
				Node coursesResultEventsEl = (Node) coursesResultEvents;
			if(coursesResultEventsEl instanceof Node){
				Node eventsNode = (Node) coursesResultEventsEl
					.getFirstChild();
			// initialize a map to store event objects
			Map<String, Event> eventMap = new LinkedHashMap<String, Event>();
			
			// null check for events node
			if (eventsNode instanceof Node) {
				// get event node
				Node eventNode = eventsNode.getNextSibling();
				
				// initialize flag for iterating over all event nodes in the xml response
				boolean eventFlag = true;
				while (eventFlag){
				
					// create event object for each record
					Event eventDef = new Event();
					
					
					eventMap = new LinkedHashMap<String, Event>();
					
					//iterating over all event child nodes to fetch the values
					NodeList allEventChildNodes = eventNode.getChildNodes();
					
					for(int i=0; i< allEventChildNodes.getLength(); i++){
						
						Node eventChildNode = allEventChildNodes.item(i);
							
						if(getCourseConfiguration().getRenderedNodeList().contains(eventChildNode.getNodeName())){
							
							if(eventChildNode.getNodeName()=="translations"){
								
								NodeList eventTranslationNodes = eventChildNode.getChildNodes();
								if(eventTranslationNodes!=null){
									
								
									for(int j=0; j< eventTranslationNodes.getLength(); j++){
										Node eventTranslationNode = eventTranslationNodes.item(j);
									
										
										NodeList translationNodeAttributes = eventTranslationNode.getChildNodes();
										
										//translation content map
										Event eventTrans = new Event();
										eventTrans.setCategory("Training");
										
										for(int k=0; k< translationNodeAttributes.getLength(); k++){
											
											Node eventTransAttributeNode = translationNodeAttributes.item(k);									
												
												
												if(eventTransAttributeNode.getNodeName().equals("summary_description"))
													eventTrans.setEventDesc(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("language_code"))
													eventTrans.setLangCode(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("language_display_name"))
													eventTrans.setTranslationLangName(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("event_name"))
													eventTrans.setEventName(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("product_id"))
													eventTrans.setProductId(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("description"))
													eventTrans.setEventWebDesc(eventTransAttributeNode.getTextContent());
												if(eventTransAttributeNode.getNodeName().equals("duration_type"))
                                                    eventTrans.setDurationType(eventTransAttributeNode.getTextContent());
										}
										
										eventTrans.setDuration(eventDef.getDuration());
										vlogDebug("Element Duration --->{0}", eventDef.getDuration());
										
										eventTrans.setEventId(eventDef.getEventId());
										
										eventTrans.setUrl(eventDef.getUrl());
										vlogDebug("final event is == {0}", eventTrans);
										// set an entry for each event in event map
										if(eventTrans.getLangCode()!=null){
											eventMap.put(eventTrans.getTranslationLangName(), eventTrans);
										}
										
									}
								}
							}
						
							if(eventChildNode.getNodeName()=="categories"){
								
								NodeList eventCategoriesNodes = eventChildNode.getChildNodes();
								for(int m=0; m<eventCategoriesNodes.getLength(); m++){
									
									Node eventCategoryNode = eventCategoriesNodes.item(m);
										if(eventCategoryNode.getFirstChild().getNextSibling().getTextContent()!=null){
											
											if(eventCategoryNode.getNodeName().equals("category_1"))
												eventDef.setCategory1(eventCategoryNode.getFirstChild().getNextSibling().getTextContent());
											else if(eventCategoryNode.getNodeName().equals("category_2"))
												eventDef.setCategory2(eventCategoryNode.getFirstChild().getNextSibling().getTextContent());
											
											// commented out the category 3, as it is being set by the application_id parameter.
											/*else if(eventCategoryNode.getNodeName().equals("category_3"))
												eventDef.setCategory3(eventCategoryNode.getFirstChild().getNextSibling().getTextContent());*/
											
											else if(eventCategoryNode.getNodeName().equals("category_4"))
												eventDef.setCategory4(eventCategoryNode.getFirstChild().getNextSibling().getTextContent());
											else if(eventCategoryNode.getNodeName().equals("category_5"))
												eventDef.setCategory5(eventCategoryNode.getFirstChild().getNextSibling().getTextContent());
										}
									}
							}						
							else{
								if(eventChildNode.getTextContent()!=null){
									if(eventChildNode.getNodeName().equals("duration_value"))
										eventDef.setDuration(eventChildNode.getTextContent());
									else if(eventChildNode.getNodeName().equals("summary_description"))
										eventDef.setEventDesc(eventChildNode.getTextContent());
									else if(eventChildNode.getNodeName().equals("event_id"))
										eventDef.setEventId(eventChildNode.getTextContent());
									else if(eventChildNode.getNodeName().equals("event_name"))
										eventDef.setEventName(eventChildNode.getTextContent());
									else if(eventChildNode.getNodeName().equals("product_id"))
										eventDef.setProductId(eventChildNode.getTextContent());	
									else if(eventChildNode.getNodeName().equals("description"))
										eventDef.setEventWebDesc(eventChildNode.getTextContent());	
									else if(eventChildNode.getNodeName().equals("event_url"))
										eventDef.setUrl(eventChildNode.getTextContent());
									else if(eventChildNode.getNodeName().equals("application_id"))
										eventDef.setCategory3(getCourseConfiguration().getApplicationIdMap().get((eventChildNode.getTextContent())));
									else if(eventChildNode.getNodeName().equals("duration_type"))
									    eventDef.setDurationType(eventChildNode.getTextContent());
																
								}							
							}
						}	
					
					}
					
						// content type external
						eventDef.setCategory("Training");
						eventDef.setLangCode("en");
														
						eventMap.put("English", eventDef);
											
						// get next event node for next iteration
						Node nextEventNode = eventNode.getNextSibling();
						// if no next node exists, break from loop
						if (nextEventNode == null) {
							eventFlag = false;
						}else{
							eventNode=nextEventNode;
						}
						// add event map to the list of all records
						recordList.add(eventMap);
					}
				}
			}
	}else{
			vlogError("Web service isn't responding.");
		}
	}
		// return record list
		return recordList;
	}
}