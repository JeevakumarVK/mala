/**
 * 
 */
package com.viewcentral.dataexchange;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.SocketAddress;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.agilent.endeca.webservice.CourseConfiguration;

/**
 * @author saini_i
 *
 */
public class GetCoursesProxySelector extends ProxySelector {

	CourseConfiguration courseConfiguration;

	/**
	 * @return the courseConfiguration
	 */
	public CourseConfiguration getCourseConfiguration() {
		return courseConfiguration;
	}

	/**
	 * @param courseConfiguration
	 *            the courseConfiguration to set
	 */
	public void setCourseConfiguration(CourseConfiguration courseConfiguration) {
		this.courseConfiguration = courseConfiguration;
	}

	// Keep a reference on the previous default
	ProxySelector defsel = null;

	/*
	 * Inner class representing a Proxy and a few extra data
	 */
	class InnerProxy {
		Proxy proxy;
		SocketAddress addr;
		// How many times did we fail to reach this proxy?
		int failedCount = 0;

		InnerProxy(InetSocketAddress a) {
			addr = a;
			proxy = new Proxy(Proxy.Type.HTTP, a);
		}

		SocketAddress address() {
			return addr;
		}

		Proxy toProxy() {
			return proxy;
		}

		int failed() {
			return ++failedCount;
		}
	}

	/*
	 * A list of proxies, indexed by their address.
	 */
	HashMap<SocketAddress, InnerProxy> proxies = new HashMap<SocketAddress, InnerProxy>();

	GetCoursesProxySelector(ProxySelector def) {
		// Save the previous default
		defsel = def;

		// Populate the HashMap (List of proxies)
		InnerProxy innerProxy = null;
		Map<String, String> proxyAddress = getCourseConfiguration()
				.getProxyAddress();
		Set<String> addressSet = proxyAddress.keySet();
		for (String address : addressSet) {
			String port = proxyAddress.get(address);
			innerProxy = new InnerProxy(new InetSocketAddress(address,
					Integer.parseInt(port)));
			proxies.put(innerProxy.address(), innerProxy);
		}
	}

	/*
	 * This is the method that the handlers will call. Returns a List of proxy.
	 */
	public java.util.List<Proxy> select(URI uri) {
		if (uri == null) {
			throw new IllegalArgumentException("URI can't be null.");
		}

		/*
		 * If it's a http (or https) URL, then we use our own list.
		 */
		String protocol = uri.getScheme();
		if ("http".equalsIgnoreCase(protocol)
				|| "https".equalsIgnoreCase(protocol)) {
			ArrayList<Proxy> proxyList = new ArrayList<Proxy>();
			for (InnerProxy p : proxies.values()) {
				proxyList.add(p.toProxy());
			}
			return proxyList;
		}

		/*
		 * Not HTTP or HTTPS (could be SOCKS or FTP) defer to the default
		 * selector.
		 */
		if (defsel != null) {
			return defsel.select(uri);
		} else {
			ArrayList<Proxy> proxyList = new ArrayList<Proxy>();
			proxyList.add(Proxy.NO_PROXY);
			return proxyList;
		}
	}

	/*
	 * Method called by the handlers when it failed to connect to one of the
	 * proxies returned by select().
	 */
	public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
		// Let's stick to the specs again.
		if (uri == null || sa == null || ioe == null) {
			throw new IllegalArgumentException("Arguments can't be null.");
		}

		/*
		 * Let's lookup for the proxy
		 */
		InnerProxy proxy = proxies.get(sa);
		if (proxy != null) {
			/*
			 * It's one of ours, if it failed more than 'size' times let's remove it
			 * from the list.
			 */
			int size = getCourseConfiguration().getProxyAddress().size();
			if (proxy.failed() >= size)
				proxies.remove(sa);
		} else {
			/*
			 * Not one of ours, let's delegate to the default.
			 */
			if (defsel != null)
				defsel.connectFailed(uri, sa, ioe);
		}
	}
}
