
package com.viewcentral.dataexchange;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.viewcentral.dataexchange package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ServiceAuthenticationHeader_QNAME = new QName("http://www.viewcentral.com/DataExchange", "ServiceAuthenticationHeader");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.viewcentral.dataexchange
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetSchedules1Response }
     * 
     */
    public GetSchedules1Response createGetSchedules1Response() {
        return new GetSchedules1Response();
    }

    /**
     * Create an instance of {@link GetCoursesResponse }
     * 
     */
    public GetCoursesResponse createGetCoursesResponse() {
        return new GetCoursesResponse();
    }

    /**
     * Create an instance of {@link GetRegistrationsResponse }
     * 
     */
    public GetRegistrationsResponse createGetRegistrationsResponse() {
        return new GetRegistrationsResponse();
    }

    /**
     * Create an instance of {@link GetSchedulesResponse }
     * 
     */
    public GetSchedulesResponse createGetSchedulesResponse() {
        return new GetSchedulesResponse();
    }

    /**
     * Create an instance of {@link GetRegistrations2Response }
     * 
     */
    public GetRegistrations2Response createGetRegistrations2Response() {
        return new GetRegistrations2Response();
    }

    /**
     * Create an instance of {@link GetRegistrations2 }
     * 
     */
    public GetRegistrations2 createGetRegistrations2() {
        return new GetRegistrations2();
    }

    /**
     * Create an instance of {@link ServiceAuthenticationHeader }
     * 
     */
    public ServiceAuthenticationHeader createServiceAuthenticationHeader() {
        return new ServiceAuthenticationHeader();
    }

    /**
     * Create an instance of {@link GetSchedules1Response.GetSchedules1Result }
     * 
     */
    public GetSchedules1Response.GetSchedules1Result createGetSchedules1ResponseGetSchedules1Result() {
        return new GetSchedules1Response.GetSchedules1Result();
    }

    /**
     * Create an instance of {@link GetRegistrations }
     * 
     */
    public GetRegistrations createGetRegistrations() {
        return new GetRegistrations();
    }

    /**
     * Create an instance of {@link GetCourses }
     * 
     */
    public GetCourses createGetCourses() {
        return new GetCourses();
    }

    /**
     * Create an instance of {@link GetCoursesResponse.GetCoursesResult }
     * 
     */
    public GetCoursesResponse.GetCoursesResult createGetCoursesResponseGetCoursesResult() {
        return new GetCoursesResponse.GetCoursesResult();
    }

    /**
     * Create an instance of {@link GetSchedules }
     * 
     */
    public GetSchedules createGetSchedules() {
        return new GetSchedules();
    }

    /**
     * Create an instance of {@link GetRegistrationsResponse.GetRegistrationsResult }
     * 
     */
    public GetRegistrationsResponse.GetRegistrationsResult createGetRegistrationsResponseGetRegistrationsResult() {
        return new GetRegistrationsResponse.GetRegistrationsResult();
    }

    /**
     * Create an instance of {@link GetSchedules1 }
     * 
     */
    public GetSchedules1 createGetSchedules1() {
        return new GetSchedules1();
    }

    /**
     * Create an instance of {@link GetSchedulesResponse.GetSchedulesResult }
     * 
     */
    public GetSchedulesResponse.GetSchedulesResult createGetSchedulesResponseGetSchedulesResult() {
        return new GetSchedulesResponse.GetSchedulesResult();
    }

    /**
     * Create an instance of {@link GetRegistrations2Response.GetRegistrations2Result }
     * 
     */
    public GetRegistrations2Response.GetRegistrations2Result createGetRegistrations2ResponseGetRegistrations2Result() {
        return new GetRegistrations2Response.GetRegistrations2Result();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ServiceAuthenticationHeader }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.viewcentral.com/DataExchange", name = "ServiceAuthenticationHeader")
    public JAXBElement<ServiceAuthenticationHeader> createServiceAuthenticationHeader(ServiceAuthenticationHeader value) {
        return new JAXBElement<ServiceAuthenticationHeader>(_ServiceAuthenticationHeader_QNAME, ServiceAuthenticationHeader.class, null, value);
    }

}
