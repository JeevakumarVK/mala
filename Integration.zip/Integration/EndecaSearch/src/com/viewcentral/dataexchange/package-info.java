@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.viewcentral.com/DataExchange", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.viewcentral.dataexchange;
