
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order.ShippingContactInfo;


/**
 * <p>Java class for Address complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Address">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AddressID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Line1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Line2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegionCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="RegionName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Type" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}AddressType" minOccurs="0"/>
 *         &lt;element name="MiddleName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SAPID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Land" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MailStop" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SPRAS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisplayText" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Attention" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DropShipLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DropShipLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DropShipLine3" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DropShipLine4" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FaxNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhoneNumberMobile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContactInfo" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile}ShippingContactInfo" minOccurs="0"/>
 *         &lt;element name="CNTelephoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CNMobileNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="street" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastAccessedAddressId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddrType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SpecialInstructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Address", propOrder = {
    "addressID",
    "firstName",
    "lastName",
    "line1",
    "line2",
    "regionCode",
    "regionName",
    "postalCode",
    "city",
    "countryCode",
    "countryName",
    "type",
    "middleName",
    "sapid",
    "land",
    "mailStop",
    "spras",
    "displayText",
    "attention",
    "additionalInfo",
    "companyName",
    "dropShipLine1",
    "dropShipLine2",
    "dropShipLine3",
    "dropShipLine4",
    "faxNumber",
    "phoneNumber",
    "phoneNumberMobile",
    "emailAddress",
    "contactInfo",
    "cnTelephoneNumber",
    "cnMobileNumber",
    "street",
    "state",
    "lastAccessedAddressId",
    "userId",
    "addrType",
    "specialInstructions"
})
public class Address {

    @XmlElement(name = "AddressID")
    protected String addressID;
    @XmlElementRef(name = "FirstName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> firstName;
    @XmlElementRef(name = "LastName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> lastName;
    @XmlElementRef(name = "Line1", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> line1;
    @XmlElementRef(name = "Line2", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> line2;
    @XmlElementRef(name = "RegionCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> regionCode;
    @XmlElementRef(name = "RegionName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> regionName;
    @XmlElementRef(name = "PostalCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> postalCode;
    @XmlElementRef(name = "City", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> city;
    @XmlElementRef(name = "CountryCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> countryCode;
    @XmlElementRef(name = "CountryName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> countryName;
    @XmlElement(name = "Type")
    protected AddressType type;
    @XmlElementRef(name = "MiddleName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> middleName;
    @XmlElementRef(name = "SAPID", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> sapid;
    @XmlElementRef(name = "Land", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> land;
    @XmlElementRef(name = "MailStop", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> mailStop;
    @XmlElementRef(name = "SPRAS", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> spras;
    @XmlElementRef(name = "DisplayText", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> displayText;
    @XmlElementRef(name = "Attention", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> attention;
    @XmlElementRef(name = "AdditionalInfo", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> additionalInfo;
    @XmlElementRef(name = "CompanyName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> companyName;
    @XmlElementRef(name = "DropShipLine1", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> dropShipLine1;
    @XmlElementRef(name = "DropShipLine2", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> dropShipLine2;
    @XmlElementRef(name = "DropShipLine3", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> dropShipLine3;
    @XmlElementRef(name = "DropShipLine4", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> dropShipLine4;
    @XmlElementRef(name = "FaxNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> faxNumber;
    @XmlElementRef(name = "PhoneNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> phoneNumber;
    @XmlElementRef(name = "PhoneNumberMobile", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> phoneNumberMobile;
    @XmlElementRef(name = "EmailAddress", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> emailAddress;
    @XmlElementRef(name = "ContactInfo", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ShippingContactInfo> contactInfo;
    @XmlElementRef(name = "CNTelephoneNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> cnTelephoneNumber;
    @XmlElementRef(name = "CNMobileNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> cnMobileNumber;
    @XmlElementRef(name = "street", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> street;
    @XmlElementRef(name = "state", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> state;
    @XmlElementRef(name = "LastAccessedAddressId", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> lastAccessedAddressId;
    @XmlElementRef(name = "userId", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> userId;
    @XmlElementRef(name = "AddrType", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> addrType;
    @XmlElementRef(name = "SpecialInstructions", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> specialInstructions;

    /**
     * Gets the value of the addressID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAddressID() {
        return addressID;
    }

    /**
     * Sets the value of the addressID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAddressID(String value) {
        this.addressID = value;
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFirstName(JAXBElement<String> value) {
        this.firstName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLastName(JAXBElement<String> value) {
        this.lastName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the line1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLine1() {
        return line1;
    }

    /**
     * Sets the value of the line1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLine1(JAXBElement<String> value) {
        this.line1 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the line2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLine2() {
        return line2;
    }

    /**
     * Sets the value of the line2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLine2(JAXBElement<String> value) {
        this.line2 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the regionCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRegionCode() {
        return regionCode;
    }

    /**
     * Sets the value of the regionCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRegionCode(JAXBElement<String> value) {
        this.regionCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the regionName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRegionName() {
        return regionName;
    }

    /**
     * Sets the value of the regionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRegionName(JAXBElement<String> value) {
        this.regionName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPostalCode(JAXBElement<String> value) {
        this.postalCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCity(JAXBElement<String> value) {
        this.city = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCountryCode(JAXBElement<String> value) {
        this.countryCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the countryName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCountryName() {
        return countryName;
    }

    /**
     * Sets the value of the countryName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCountryName(JAXBElement<String> value) {
        this.countryName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link AddressType }
     *     
     */
    public AddressType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressType }
     *     
     */
    public void setType(AddressType value) {
        this.type = value;
    }

    /**
     * Gets the value of the middleName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMiddleName() {
        return middleName;
    }

    /**
     * Sets the value of the middleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMiddleName(JAXBElement<String> value) {
        this.middleName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the sapid property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSAPID() {
        return sapid;
    }

    /**
     * Sets the value of the sapid property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSAPID(JAXBElement<String> value) {
        this.sapid = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the land property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLand() {
        return land;
    }

    /**
     * Sets the value of the land property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLand(JAXBElement<String> value) {
        this.land = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the mailStop property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getMailStop() {
        return mailStop;
    }

    /**
     * Sets the value of the mailStop property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setMailStop(JAXBElement<String> value) {
        this.mailStop = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the spras property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSPRAS() {
        return spras;
    }

    /**
     * Sets the value of the spras property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSPRAS(JAXBElement<String> value) {
        this.spras = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the displayText property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDisplayText() {
        return displayText;
    }

    /**
     * Sets the value of the displayText property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDisplayText(JAXBElement<String> value) {
        this.displayText = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the attention property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAttention() {
        return attention;
    }

    /**
     * Sets the value of the attention property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAttention(JAXBElement<String> value) {
        this.attention = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the additionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the value of the additionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdditionalInfo(JAXBElement<String> value) {
        this.additionalInfo = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyName(JAXBElement<String> value) {
        this.companyName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the dropShipLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDropShipLine1() {
        return dropShipLine1;
    }

    /**
     * Sets the value of the dropShipLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDropShipLine1(JAXBElement<String> value) {
        this.dropShipLine1 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the dropShipLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDropShipLine2() {
        return dropShipLine2;
    }

    /**
     * Sets the value of the dropShipLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDropShipLine2(JAXBElement<String> value) {
        this.dropShipLine2 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the dropShipLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDropShipLine3() {
        return dropShipLine3;
    }

    /**
     * Sets the value of the dropShipLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDropShipLine3(JAXBElement<String> value) {
        this.dropShipLine3 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the dropShipLine4 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDropShipLine4() {
        return dropShipLine4;
    }

    /**
     * Sets the value of the dropShipLine4 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDropShipLine4(JAXBElement<String> value) {
        this.dropShipLine4 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the faxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFaxNumber() {
        return faxNumber;
    }

    /**
     * Sets the value of the faxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFaxNumber(JAXBElement<String> value) {
        this.faxNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the phoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPhoneNumber(JAXBElement<String> value) {
        this.phoneNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the phoneNumberMobile property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPhoneNumberMobile() {
        return phoneNumberMobile;
    }

    /**
     * Sets the value of the phoneNumberMobile property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPhoneNumberMobile(JAXBElement<String> value) {
        this.phoneNumberMobile = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmailAddress(JAXBElement<String> value) {
        this.emailAddress = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the contactInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ShippingContactInfo }{@code >}
     *     
     */
    public JAXBElement<ShippingContactInfo> getContactInfo() {
        return contactInfo;
    }

    /**
     * Sets the value of the contactInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ShippingContactInfo }{@code >}
     *     
     */
    public void setContactInfo(JAXBElement<ShippingContactInfo> value) {
        this.contactInfo = ((JAXBElement<ShippingContactInfo> ) value);
    }

    /**
     * Gets the value of the cnTelephoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCNTelephoneNumber() {
        return cnTelephoneNumber;
    }

    /**
     * Sets the value of the cnTelephoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCNTelephoneNumber(JAXBElement<String> value) {
        this.cnTelephoneNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cnMobileNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCNMobileNumber() {
        return cnMobileNumber;
    }

    /**
     * Sets the value of the cnMobileNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCNMobileNumber(JAXBElement<String> value) {
        this.cnMobileNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the street property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getStreet() {
        return street;
    }

    /**
     * Sets the value of the street property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setStreet(JAXBElement<String> value) {
        this.street = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setState(JAXBElement<String> value) {
        this.state = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the lastAccessedAddressId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLastAccessedAddressId() {
        return lastAccessedAddressId;
    }

    /**
     * Sets the value of the lastAccessedAddressId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLastAccessedAddressId(JAXBElement<String> value) {
        this.lastAccessedAddressId = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserId(JAXBElement<String> value) {
        this.userId = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the addrType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddrType() {
        return addrType;
    }

    /**
     * Sets the value of the addrType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddrType(JAXBElement<String> value) {
        this.addrType = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the specialInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSpecialInstructions() {
        return specialInstructions;
    }

    /**
     * Sets the value of the specialInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSpecialInstructions(JAXBElement<String> value) {
        this.specialInstructions = ((JAXBElement<String> ) value);
    }

}
