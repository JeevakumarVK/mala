
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for Basket complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Basket">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BasketID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="Created" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="IsEmpty" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="LastModified" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="OrderForms" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfOrderForm" minOccurs="0"/>
 *         &lt;element name="Status" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}StatusCodes" minOccurs="0"/>
 *         &lt;element name="SubTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="TaxTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Total" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Addresses" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfAddress" minOccurs="0"/>
 *         &lt;element name="ShippingOptions" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ShippingOptions" minOccurs="0"/>
 *         &lt;element name="CreditCardPayment" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}CreditCard" minOccurs="0"/>
 *         &lt;element name="PONumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CybsAuthCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CybsSubscriptionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CybsNameOnCard" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CybsCardType" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}CreditCardType" minOccurs="0"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ShippingTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ContainsPartialShipItems" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="YourPriceTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="YourPriceSubTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproveeSapContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproveeSapCustomerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AdditionalInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsSAPUserKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ObsoleteLineItems" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfLineItem" minOccurs="0"/>
 *         &lt;element name="CartType" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}CartType" minOccurs="0"/>
 *         &lt;element name="GenomicsShippingTotal" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Basket", propOrder = {
    "basketID",
    "created",
    "isEmpty",
    "lastModified",
    "orderForms",
    "status",
    "subTotal",
    "taxTotal",
    "total",
    "addresses",
    "shippingOptions",
    "creditCardPayment",
    "poNumber",
    "cybsAuthCode",
    "cybsSubscriptionID",
    "cybsNameOnCard",
    "cybsCardType",
    "name",
    "shippingTotal",
    "containsPartialShipItems",
    "yourPriceTotal",
    "yourPriceSubTotal",
    "errorMessage",
    "currency",
    "approveeSapContactNumber",
    "approveeSapCustomerNumber",
    "additionalInfo",
    "isSAPUserKey",
    "obsoleteLineItems",
    "cartType",
    "genomicsShippingTotal"
})
public class Basket {

    @XmlElement(name = "BasketID")
    protected String basketID;
    @XmlElement(name = "Created")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar created;
    @XmlElement(name = "IsEmpty")
    protected Boolean isEmpty;
    @XmlElement(name = "LastModified")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar lastModified;
    @XmlElementRef(name = "OrderForms", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfOrderForm> orderForms;
    @XmlElement(name = "Status")
    protected String status;
    @XmlElement(name = "SubTotal")
    protected BigDecimal subTotal;
    @XmlElement(name = "TaxTotal")
    protected BigDecimal taxTotal;
    @XmlElement(name = "Total")
    protected BigDecimal total;
    @XmlElementRef(name = "Addresses", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfAddress> addresses;
    @XmlElementRef(name = "ShippingOptions", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ShippingOptions> shippingOptions;
    @XmlElementRef(name = "CreditCardPayment", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<CreditCard> creditCardPayment;
    @XmlElementRef(name = "PONumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> poNumber;
    @XmlElementRef(name = "CybsAuthCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> cybsAuthCode;
    @XmlElementRef(name = "CybsSubscriptionID", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> cybsSubscriptionID;
    @XmlElementRef(name = "CybsNameOnCard", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> cybsNameOnCard;
    @XmlElement(name = "CybsCardType")
    protected CreditCardType cybsCardType;
    @XmlElementRef(name = "Name", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> name;
    @XmlElement(name = "ShippingTotal")
    protected BigDecimal shippingTotal;
    @XmlElement(name = "ContainsPartialShipItems")
    protected Boolean containsPartialShipItems;
    @XmlElement(name = "YourPriceTotal")
    protected BigDecimal yourPriceTotal;
    @XmlElement(name = "YourPriceSubTotal")
    protected BigDecimal yourPriceSubTotal;
    @XmlElementRef(name = "ErrorMessage", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> errorMessage;
    @XmlElementRef(name = "Currency", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> currency;
    @XmlElementRef(name = "ApproveeSapContactNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapContactNumber;
    @XmlElementRef(name = "ApproveeSapCustomerNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapCustomerNumber;
    @XmlElementRef(name = "AdditionalInfo", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> additionalInfo;
    @XmlElementRef(name = "IsSAPUserKey", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> isSAPUserKey;
    @XmlElementRef(name = "ObsoleteLineItems", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfLineItem> obsoleteLineItems;
    @XmlElement(name = "CartType")
    protected CartType cartType;
    @XmlElement(name = "GenomicsShippingTotal")
    protected BigDecimal genomicsShippingTotal;

    /**
     * Gets the value of the basketID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBasketID() {
        return basketID;
    }

    /**
     * Sets the value of the basketID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBasketID(String value) {
        this.basketID = value;
    }

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreated(XMLGregorianCalendar value) {
        this.created = value;
    }

    /**
     * Gets the value of the isEmpty property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsEmpty() {
        return isEmpty;
    }

    /**
     * Sets the value of the isEmpty property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsEmpty(Boolean value) {
        this.isEmpty = value;
    }

    /**
     * Gets the value of the lastModified property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getLastModified() {
        return lastModified;
    }

    /**
     * Sets the value of the lastModified property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setLastModified(XMLGregorianCalendar value) {
        this.lastModified = value;
    }

    /**
     * Gets the value of the orderForms property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}
     *     
     */
    public JAXBElement<ArrayOfOrderForm> getOrderForms() {
        return orderForms;
    }

    /**
     * Sets the value of the orderForms property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}
     *     
     */
    public void setOrderForms(JAXBElement<ArrayOfOrderForm> value) {
        this.orderForms = ((JAXBElement<ArrayOfOrderForm> ) value);
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the subTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getSubTotal() {
        return subTotal;
    }

    /**
     * Sets the value of the subTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setSubTotal(BigDecimal value) {
        this.subTotal = value;
    }

    /**
     * Gets the value of the taxTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxTotal() {
        return taxTotal;
    }

    /**
     * Sets the value of the taxTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxTotal(BigDecimal value) {
        this.taxTotal = value;
    }

    /**
     * Gets the value of the total property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTotal() {
        return total;
    }

    /**
     * Sets the value of the total property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTotal(BigDecimal value) {
        this.total = value;
    }

    /**
     * Gets the value of the addresses property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}
     *     
     */
    public JAXBElement<ArrayOfAddress> getAddresses() {
        return addresses;
    }

    /**
     * Sets the value of the addresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}
     *     
     */
    public void setAddresses(JAXBElement<ArrayOfAddress> value) {
        this.addresses = ((JAXBElement<ArrayOfAddress> ) value);
    }

    /**
     * Gets the value of the shippingOptions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}
     *     
     */
    public JAXBElement<ShippingOptions> getShippingOptions() {
        return shippingOptions;
    }

    /**
     * Sets the value of the shippingOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}
     *     
     */
    public void setShippingOptions(JAXBElement<ShippingOptions> value) {
        this.shippingOptions = ((JAXBElement<ShippingOptions> ) value);
    }

    /**
     * Gets the value of the creditCardPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CreditCard }{@code >}
     *     
     */
    public JAXBElement<CreditCard> getCreditCardPayment() {
        return creditCardPayment;
    }

    /**
     * Sets the value of the creditCardPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CreditCard }{@code >}
     *     
     */
    public void setCreditCardPayment(JAXBElement<CreditCard> value) {
        this.creditCardPayment = ((JAXBElement<CreditCard> ) value);
    }

    /**
     * Gets the value of the poNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPONumber() {
        return poNumber;
    }

    /**
     * Sets the value of the poNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPONumber(JAXBElement<String> value) {
        this.poNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cybsAuthCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCybsAuthCode() {
        return cybsAuthCode;
    }

    /**
     * Sets the value of the cybsAuthCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCybsAuthCode(JAXBElement<String> value) {
        this.cybsAuthCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cybsSubscriptionID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCybsSubscriptionID() {
        return cybsSubscriptionID;
    }

    /**
     * Sets the value of the cybsSubscriptionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCybsSubscriptionID(JAXBElement<String> value) {
        this.cybsSubscriptionID = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cybsNameOnCard property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCybsNameOnCard() {
        return cybsNameOnCard;
    }

    /**
     * Sets the value of the cybsNameOnCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCybsNameOnCard(JAXBElement<String> value) {
        this.cybsNameOnCard = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the cybsCardType property.
     * 
     * @return
     *     possible object is
     *     {@link CreditCardType }
     *     
     */
    public CreditCardType getCybsCardType() {
        return cybsCardType;
    }

    /**
     * Sets the value of the cybsCardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CreditCardType }
     *     
     */
    public void setCybsCardType(CreditCardType value) {
        this.cybsCardType = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setName(JAXBElement<String> value) {
        this.name = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the shippingTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getShippingTotal() {
        return shippingTotal;
    }

    /**
     * Sets the value of the shippingTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setShippingTotal(BigDecimal value) {
        this.shippingTotal = value;
    }

    /**
     * Gets the value of the containsPartialShipItems property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isContainsPartialShipItems() {
        return containsPartialShipItems;
    }

    /**
     * Sets the value of the containsPartialShipItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setContainsPartialShipItems(Boolean value) {
        this.containsPartialShipItems = value;
    }

    /**
     * Gets the value of the yourPriceTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getYourPriceTotal() {
        return yourPriceTotal;
    }

    /**
     * Sets the value of the yourPriceTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setYourPriceTotal(BigDecimal value) {
        this.yourPriceTotal = value;
    }

    /**
     * Gets the value of the yourPriceSubTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getYourPriceSubTotal() {
        return yourPriceSubTotal;
    }

    /**
     * Sets the value of the yourPriceSubTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setYourPriceSubTotal(BigDecimal value) {
        this.yourPriceSubTotal = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setErrorMessage(JAXBElement<String> value) {
        this.errorMessage = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrency(JAXBElement<String> value) {
        this.currency = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the approveeSapContactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapContactNumber() {
        return approveeSapContactNumber;
    }

    /**
     * Sets the value of the approveeSapContactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapContactNumber(JAXBElement<String> value) {
        this.approveeSapContactNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the approveeSapCustomerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapCustomerNumber() {
        return approveeSapCustomerNumber;
    }

    /**
     * Sets the value of the approveeSapCustomerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapCustomerNumber(JAXBElement<String> value) {
        this.approveeSapCustomerNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the additionalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAdditionalInfo() {
        return additionalInfo;
    }

    /**
     * Sets the value of the additionalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAdditionalInfo(JAXBElement<String> value) {
        this.additionalInfo = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the isSAPUserKey property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getIsSAPUserKey() {
        return isSAPUserKey;
    }

    /**
     * Sets the value of the isSAPUserKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setIsSAPUserKey(JAXBElement<String> value) {
        this.isSAPUserKey = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the obsoleteLineItems property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}
     *     
     */
    public JAXBElement<ArrayOfLineItem> getObsoleteLineItems() {
        return obsoleteLineItems;
    }

    /**
     * Sets the value of the obsoleteLineItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}
     *     
     */
    public void setObsoleteLineItems(JAXBElement<ArrayOfLineItem> value) {
        this.obsoleteLineItems = ((JAXBElement<ArrayOfLineItem> ) value);
    }

    /**
     * Gets the value of the cartType property.
     * 
     * @return
     *     possible object is
     *     {@link CartType }
     *     
     */
    public CartType getCartType() {
        return cartType;
    }

    /**
     * Sets the value of the cartType property.
     * 
     * @param value
     *     allowed object is
     *     {@link CartType }
     *     
     */
    public void setCartType(CartType value) {
        this.cartType = value;
    }

    /**
     * Gets the value of the genomicsShippingTotal property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getGenomicsShippingTotal() {
        return genomicsShippingTotal;
    }

    /**
     * Sets the value of the genomicsShippingTotal property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setGenomicsShippingTotal(BigDecimal value) {
        this.genomicsShippingTotal = value;
    }

}
