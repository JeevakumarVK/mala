
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for BasketCopyCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BasketCopyCriteria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SourceUserID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="SourceBasketName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TargetUserID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="TargetBasketName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproveeSapContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproveeSapCustomerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasketCopyCriteria", propOrder = {
    "sourceUserID",
    "sourceBasketName",
    "targetUserID",
    "targetBasketName",
    "approveeSapContactNumber",
    "approveeSapCustomerNumber"
})
public class BasketCopyCriteria {

    @XmlElement(name = "SourceUserID")
    protected String sourceUserID;
    @XmlElementRef(name = "SourceBasketName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> sourceBasketName;
    @XmlElement(name = "TargetUserID")
    protected String targetUserID;
    @XmlElementRef(name = "TargetBasketName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> targetBasketName;
    @XmlElementRef(name = "ApproveeSapContactNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapContactNumber;
    @XmlElementRef(name = "ApproveeSapCustomerNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapCustomerNumber;

    /**
     * Gets the value of the sourceUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceUserID() {
        return sourceUserID;
    }

    /**
     * Sets the value of the sourceUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceUserID(String value) {
        this.sourceUserID = value;
    }

    /**
     * Gets the value of the sourceBasketName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSourceBasketName() {
        return sourceBasketName;
    }

    /**
     * Sets the value of the sourceBasketName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSourceBasketName(JAXBElement<String> value) {
        this.sourceBasketName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the targetUserID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTargetUserID() {
        return targetUserID;
    }

    /**
     * Sets the value of the targetUserID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTargetUserID(String value) {
        this.targetUserID = value;
    }

    /**
     * Gets the value of the targetBasketName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getTargetBasketName() {
        return targetBasketName;
    }

    /**
     * Sets the value of the targetBasketName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setTargetBasketName(JAXBElement<String> value) {
        this.targetBasketName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the approveeSapContactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapContactNumber() {
        return approveeSapContactNumber;
    }

    /**
     * Sets the value of the approveeSapContactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapContactNumber(JAXBElement<String> value) {
        this.approveeSapContactNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the approveeSapCustomerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapCustomerNumber() {
        return approveeSapCustomerNumber;
    }

    /**
     * Sets the value of the approveeSapCustomerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapCustomerNumber(JAXBElement<String> value) {
        this.approveeSapCustomerNumber = ((JAXBElement<String> ) value);
    }

}
