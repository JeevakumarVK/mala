
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for CartType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="CartType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="None"/>
 *     &lt;enumeration value="LSCA"/>
 *     &lt;enumeration value="Genomics"/>
 *     &lt;enumeration value="Mixed"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "CartType")
@XmlEnum
public enum CartType {

    @XmlEnumValue("None")
    NONE("None"),
    LSCA("LSCA"),
    @XmlEnumValue("Genomics")
    GENOMICS("Genomics"),
    @XmlEnumValue("Mixed")
    MIXED("Mixed");
    private final String value;

    CartType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static CartType fromValue(String v) {
        for (CartType c: CartType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
