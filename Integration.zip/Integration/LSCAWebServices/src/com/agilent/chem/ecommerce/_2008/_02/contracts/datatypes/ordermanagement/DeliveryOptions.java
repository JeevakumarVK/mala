
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeliveryOptions.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeliveryOptions">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="None"/>
 *     &lt;enumeration value="Standard"/>
 *     &lt;enumeration value="OverNight"/>
 *     &lt;enumeration value="SecondDayDelivery"/>
 *     &lt;enumeration value="SaturdayDelivery"/>
 *     &lt;enumeration value="DesiredDateOfDelivery"/>
 *     &lt;enumeration value="USAMDelivery"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DeliveryOptions")
@XmlEnum
public enum DeliveryOptions {

    @XmlEnumValue("None")
    NONE("None"),
    @XmlEnumValue("Standard")
    STANDARD("Standard"),
    @XmlEnumValue("OverNight")
    OVER_NIGHT("OverNight"),
    @XmlEnumValue("SecondDayDelivery")
    SECOND_DAY_DELIVERY("SecondDayDelivery"),
    @XmlEnumValue("SaturdayDelivery")
    SATURDAY_DELIVERY("SaturdayDelivery"),
    @XmlEnumValue("DesiredDateOfDelivery")
    DESIRED_DATE_OF_DELIVERY("DesiredDateOfDelivery"),
    @XmlEnumValue("USAMDelivery")
    USAM_DELIVERY("USAMDelivery");
    private final String value;

    DeliveryOptions(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static DeliveryOptions fromValue(String v) {
        for (DeliveryOptions c: DeliveryOptions.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
