
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DiscountRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DiscountRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BasketDisplayMessage_x0020_" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DiscountAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="DiscountId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="DiscountName_x0020__x0020_" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DiscountValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PromoCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PromoCodeDefinitionId" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DiscountRecord", propOrder = {
    "basketDisplayMessageX0020",
    "discountAmount",
    "discountId",
    "discountNameX0020X0020",
    "discountValue",
    "promoCode",
    "promoCodeDefinitionId"
})
public class DiscountRecord {

    @XmlElementRef(name = "BasketDisplayMessage_x0020_", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> basketDisplayMessageX0020;
    @XmlElement(name = "DiscountAmount")
    protected BigDecimal discountAmount;
    @XmlElement(name = "DiscountId")
    protected Integer discountId;
    @XmlElementRef(name = "DiscountName_x0020__x0020_", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> discountNameX0020X0020;
    @XmlElement(name = "DiscountValue")
    protected BigDecimal discountValue;
    @XmlElementRef(name = "PromoCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> promoCode;
    @XmlElement(name = "PromoCodeDefinitionId")
    protected Integer promoCodeDefinitionId;

    /**
     * Gets the value of the basketDisplayMessageX0020 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBasketDisplayMessageX0020() {
        return basketDisplayMessageX0020;
    }

    /**
     * Sets the value of the basketDisplayMessageX0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBasketDisplayMessageX0020(JAXBElement<String> value) {
        this.basketDisplayMessageX0020 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the discountAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    /**
     * Sets the value of the discountAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscountAmount(BigDecimal value) {
        this.discountAmount = value;
    }

    /**
     * Gets the value of the discountId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getDiscountId() {
        return discountId;
    }

    /**
     * Sets the value of the discountId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setDiscountId(Integer value) {
        this.discountId = value;
    }

    /**
     * Gets the value of the discountNameX0020X0020 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDiscountNameX0020X0020() {
        return discountNameX0020X0020;
    }

    /**
     * Sets the value of the discountNameX0020X0020 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDiscountNameX0020X0020(JAXBElement<String> value) {
        this.discountNameX0020X0020 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the discountValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscountValue() {
        return discountValue;
    }

    /**
     * Sets the value of the discountValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscountValue(BigDecimal value) {
        this.discountValue = value;
    }

    /**
     * Gets the value of the promoCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPromoCode() {
        return promoCode;
    }

    /**
     * Sets the value of the promoCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPromoCode(JAXBElement<String> value) {
        this.promoCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the promoCodeDefinitionId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getPromoCodeDefinitionId() {
        return promoCodeDefinitionId;
    }

    /**
     * Sets the value of the promoCodeDefinitionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setPromoCodeDefinitionId(Integer value) {
        this.promoCodeDefinitionId = value;
    }

}
