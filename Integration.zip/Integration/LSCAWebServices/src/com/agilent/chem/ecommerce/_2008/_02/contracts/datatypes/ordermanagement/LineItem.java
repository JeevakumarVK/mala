
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for LineItem complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LineItem">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Created" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DisplayName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ExtendedPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="LineItemDiscountAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="LineItemID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="ListPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="OrderLevelDiscountAmount" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PlacedPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PreorderPrice" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="ProductCatalog" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ProductCategory" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="VariantID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Quantity" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="YourPrice" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="ProductLine" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LineItemState" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}LineItemState"/>
 *         &lt;element name="IsConfigurable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="Notes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesUnit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="NetValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="Currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsConfigurationCompleted" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsEcd" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsPartialShipment" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsExchangeProduct" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="DiscountsApplied" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfLineItemDiscountDTO" minOccurs="0"/>
 *         &lt;element name="ConfigID" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="ConfigSummary" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CatalogLanguage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductNotAvailableInCatalog" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsNewPOLineItemFromSalesOrder" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="TaxPerLineItem" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="SapIdentificationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ProductCategoryHierarchyString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Amount" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="UnitQuantity" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CondType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CondValue" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="PriceGroup" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Apply_SAP_Discounts" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="UNSPSC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LineItem", propOrder = {
    "created",
    "description",
    "displayName",
    "extendedPrice",
    "lineItemDiscountAmount",
    "lineItemID",
    "listPrice",
    "orderLevelDiscountAmount",
    "placedPrice",
    "preorderPrice",
    "productCatalog",
    "productCategory",
    "productID",
    "variantID",
    "quantity",
    "yourPrice",
    "productLine",
    "lineItemState",
    "isConfigurable",
    "notes",
    "salesUnit",
    "netValue",
    "currency",
    "isConfigurationCompleted",
    "isEcd",
    "isPartialShipment",
    "isExchangeProduct",
    "discountsApplied",
    "configID",
    "configSummary",
    "catalogLanguage",
    "productNotAvailableInCatalog",
    "isNewPOLineItemFromSalesOrder",
    "taxPerLineItem",
    "sapIdentificationNumber",
    "productCategoryHierarchyString",
    "amount",
    "unitQuantity",
    "condType",
    "condValue",
    "priceGroup",
    "applySAPDiscounts",
    "unspsc"
})
public class LineItem {

    @XmlElement(name = "Created")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar created;
    @XmlElementRef(name = "Description", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> description;
    @XmlElementRef(name = "DisplayName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> displayName;
    @XmlElement(name = "ExtendedPrice")
    protected BigDecimal extendedPrice;
    @XmlElement(name = "LineItemDiscountAmount")
    protected BigDecimal lineItemDiscountAmount;
    @XmlElement(name = "LineItemID")
    protected String lineItemID;
    @XmlElement(name = "ListPrice")
    protected BigDecimal listPrice;
    @XmlElement(name = "OrderLevelDiscountAmount")
    protected BigDecimal orderLevelDiscountAmount;
    @XmlElement(name = "PlacedPrice")
    protected BigDecimal placedPrice;
    @XmlElement(name = "PreorderPrice")
    protected BigDecimal preorderPrice;
    @XmlElement(name = "ProductCatalog", required = true, nillable = true)
    protected String productCatalog;
    @XmlElementRef(name = "ProductCategory", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> productCategory;
    @XmlElement(name = "ProductID", required = true, nillable = true)
    protected String productID;
    @XmlElementRef(name = "VariantID", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> variantID;
    @XmlElement(name = "Quantity", required = true)
    protected BigDecimal quantity;
    @XmlElement(name = "YourPrice", required = true)
    protected BigDecimal yourPrice;
    @XmlElement(name = "ProductLine", required = true, nillable = true)
    protected String productLine;
    @XmlElement(name = "LineItemState", required = true)
    protected LineItemState lineItemState;
    @XmlElement(name = "IsConfigurable")
    protected Boolean isConfigurable;
    @XmlElementRef(name = "Notes", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> notes;
    @XmlElementRef(name = "SalesUnit", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> salesUnit;
    @XmlElement(name = "NetValue")
    protected BigDecimal netValue;
    @XmlElementRef(name = "Currency", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> currency;
    @XmlElement(name = "IsConfigurationCompleted")
    protected Boolean isConfigurationCompleted;
    @XmlElement(name = "IsEcd")
    protected Boolean isEcd;
    @XmlElement(name = "IsPartialShipment")
    protected Boolean isPartialShipment;
    @XmlElement(name = "IsExchangeProduct")
    protected Boolean isExchangeProduct;
    @XmlElementRef(name = "DiscountsApplied", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfLineItemDiscountDTO> discountsApplied;
    @XmlElement(name = "ConfigID")
    protected Integer configID;
    @XmlElementRef(name = "ConfigSummary", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> configSummary;
    @XmlElementRef(name = "CatalogLanguage", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> catalogLanguage;
    @XmlElement(name = "ProductNotAvailableInCatalog")
    protected Boolean productNotAvailableInCatalog;
    @XmlElement(name = "IsNewPOLineItemFromSalesOrder")
    protected Boolean isNewPOLineItemFromSalesOrder;
    @XmlElement(name = "TaxPerLineItem")
    protected BigDecimal taxPerLineItem;
    @XmlElementRef(name = "SapIdentificationNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> sapIdentificationNumber;
    @XmlElementRef(name = "ProductCategoryHierarchyString", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> productCategoryHierarchyString;
    @XmlElementRef(name = "Amount", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> amount;
    @XmlElementRef(name = "UnitQuantity", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> unitQuantity;
    @XmlElementRef(name = "CondType", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> condType;
    @XmlElement(name = "CondValue")
    protected BigDecimal condValue;
    @XmlElementRef(name = "PriceGroup", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> priceGroup;
    @XmlElement(name = "Apply_SAP_Discounts")
    protected Boolean applySAPDiscounts;
    @XmlElementRef(name = "UNSPSC", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> unspsc;

    /**
     * Gets the value of the created property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getCreated() {
        return created;
    }

    /**
     * Sets the value of the created property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreated(XMLGregorianCalendar value) {
        this.created = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDescription(JAXBElement<String> value) {
        this.description = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the displayName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getDisplayName() {
        return displayName;
    }

    /**
     * Sets the value of the displayName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setDisplayName(JAXBElement<String> value) {
        this.displayName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the extendedPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExtendedPrice() {
        return extendedPrice;
    }

    /**
     * Sets the value of the extendedPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExtendedPrice(BigDecimal value) {
        this.extendedPrice = value;
    }

    /**
     * Gets the value of the lineItemDiscountAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getLineItemDiscountAmount() {
        return lineItemDiscountAmount;
    }

    /**
     * Sets the value of the lineItemDiscountAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setLineItemDiscountAmount(BigDecimal value) {
        this.lineItemDiscountAmount = value;
    }

    /**
     * Gets the value of the lineItemID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineItemID() {
        return lineItemID;
    }

    /**
     * Sets the value of the lineItemID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineItemID(String value) {
        this.lineItemID = value;
    }

    /**
     * Gets the value of the listPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getListPrice() {
        return listPrice;
    }

    /**
     * Sets the value of the listPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setListPrice(BigDecimal value) {
        this.listPrice = value;
    }

    /**
     * Gets the value of the orderLevelDiscountAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLevelDiscountAmount() {
        return orderLevelDiscountAmount;
    }

    /**
     * Sets the value of the orderLevelDiscountAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLevelDiscountAmount(BigDecimal value) {
        this.orderLevelDiscountAmount = value;
    }

    /**
     * Gets the value of the placedPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPlacedPrice() {
        return placedPrice;
    }

    /**
     * Sets the value of the placedPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPlacedPrice(BigDecimal value) {
        this.placedPrice = value;
    }

    /**
     * Gets the value of the preorderPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getPreorderPrice() {
        return preorderPrice;
    }

    /**
     * Sets the value of the preorderPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setPreorderPrice(BigDecimal value) {
        this.preorderPrice = value;
    }

    /**
     * Gets the value of the productCatalog property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCatalog() {
        return productCatalog;
    }

    /**
     * Sets the value of the productCatalog property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCatalog(String value) {
        this.productCatalog = value;
    }

    /**
     * Gets the value of the productCategory property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProductCategory() {
        return productCategory;
    }

    /**
     * Sets the value of the productCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProductCategory(JAXBElement<String> value) {
        this.productCategory = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the productID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductID() {
        return productID;
    }

    /**
     * Sets the value of the productID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductID(String value) {
        this.productID = value;
    }

    /**
     * Gets the value of the variantID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getVariantID() {
        return variantID;
    }

    /**
     * Sets the value of the variantID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setVariantID(JAXBElement<String> value) {
        this.variantID = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setQuantity(BigDecimal value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the yourPrice property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getYourPrice() {
        return yourPrice;
    }

    /**
     * Sets the value of the yourPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setYourPrice(BigDecimal value) {
        this.yourPrice = value;
    }

    /**
     * Gets the value of the productLine property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductLine() {
        return productLine;
    }

    /**
     * Sets the value of the productLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductLine(String value) {
        this.productLine = value;
    }

    /**
     * Gets the value of the lineItemState property.
     * 
     * @return
     *     possible object is
     *     {@link LineItemState }
     *     
     */
    public LineItemState getLineItemState() {
        return lineItemState;
    }

    /**
     * Sets the value of the lineItemState property.
     * 
     * @param value
     *     allowed object is
     *     {@link LineItemState }
     *     
     */
    public void setLineItemState(LineItemState value) {
        this.lineItemState = value;
    }

    /**
     * Gets the value of the isConfigurable property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsConfigurable() {
        return isConfigurable;
    }

    /**
     * Sets the value of the isConfigurable property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsConfigurable(Boolean value) {
        this.isConfigurable = value;
    }

    /**
     * Gets the value of the notes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getNotes() {
        return notes;
    }

    /**
     * Sets the value of the notes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setNotes(JAXBElement<String> value) {
        this.notes = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the salesUnit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSalesUnit() {
        return salesUnit;
    }

    /**
     * Sets the value of the salesUnit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSalesUnit(JAXBElement<String> value) {
        this.salesUnit = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the netValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNetValue() {
        return netValue;
    }

    /**
     * Sets the value of the netValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNetValue(BigDecimal value) {
        this.netValue = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCurrency(JAXBElement<String> value) {
        this.currency = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the isConfigurationCompleted property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsConfigurationCompleted() {
        return isConfigurationCompleted;
    }

    /**
     * Sets the value of the isConfigurationCompleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsConfigurationCompleted(Boolean value) {
        this.isConfigurationCompleted = value;
    }

    /**
     * Gets the value of the isEcd property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsEcd() {
        return isEcd;
    }

    /**
     * Sets the value of the isEcd property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsEcd(Boolean value) {
        this.isEcd = value;
    }

    /**
     * Gets the value of the isPartialShipment property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPartialShipment() {
        return isPartialShipment;
    }

    /**
     * Sets the value of the isPartialShipment property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPartialShipment(Boolean value) {
        this.isPartialShipment = value;
    }

    /**
     * Gets the value of the isExchangeProduct property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsExchangeProduct() {
        return isExchangeProduct;
    }

    /**
     * Sets the value of the isExchangeProduct property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsExchangeProduct(Boolean value) {
        this.isExchangeProduct = value;
    }

    /**
     * Gets the value of the discountsApplied property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItemDiscountDTO }{@code >}
     *     
     */
    public JAXBElement<ArrayOfLineItemDiscountDTO> getDiscountsApplied() {
        return discountsApplied;
    }

    /**
     * Sets the value of the discountsApplied property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItemDiscountDTO }{@code >}
     *     
     */
    public void setDiscountsApplied(JAXBElement<ArrayOfLineItemDiscountDTO> value) {
        this.discountsApplied = ((JAXBElement<ArrayOfLineItemDiscountDTO> ) value);
    }

    /**
     * Gets the value of the configID property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getConfigID() {
        return configID;
    }

    /**
     * Sets the value of the configID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setConfigID(Integer value) {
        this.configID = value;
    }

    /**
     * Gets the value of the configSummary property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getConfigSummary() {
        return configSummary;
    }

    /**
     * Sets the value of the configSummary property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setConfigSummary(JAXBElement<String> value) {
        this.configSummary = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the catalogLanguage property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCatalogLanguage() {
        return catalogLanguage;
    }

    /**
     * Sets the value of the catalogLanguage property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCatalogLanguage(JAXBElement<String> value) {
        this.catalogLanguage = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the productNotAvailableInCatalog property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isProductNotAvailableInCatalog() {
        return productNotAvailableInCatalog;
    }

    /**
     * Sets the value of the productNotAvailableInCatalog property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setProductNotAvailableInCatalog(Boolean value) {
        this.productNotAvailableInCatalog = value;
    }

    /**
     * Gets the value of the isNewPOLineItemFromSalesOrder property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsNewPOLineItemFromSalesOrder() {
        return isNewPOLineItemFromSalesOrder;
    }

    /**
     * Sets the value of the isNewPOLineItemFromSalesOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsNewPOLineItemFromSalesOrder(Boolean value) {
        this.isNewPOLineItemFromSalesOrder = value;
    }

    /**
     * Gets the value of the taxPerLineItem property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTaxPerLineItem() {
        return taxPerLineItem;
    }

    /**
     * Sets the value of the taxPerLineItem property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTaxPerLineItem(BigDecimal value) {
        this.taxPerLineItem = value;
    }

    /**
     * Gets the value of the sapIdentificationNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSapIdentificationNumber() {
        return sapIdentificationNumber;
    }

    /**
     * Sets the value of the sapIdentificationNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSapIdentificationNumber(JAXBElement<String> value) {
        this.sapIdentificationNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the productCategoryHierarchyString property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getProductCategoryHierarchyString() {
        return productCategoryHierarchyString;
    }

    /**
     * Sets the value of the productCategoryHierarchyString property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setProductCategoryHierarchyString(JAXBElement<String> value) {
        this.productCategoryHierarchyString = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAmount(JAXBElement<String> value) {
        this.amount = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the unitQuantity property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUnitQuantity() {
        return unitQuantity;
    }

    /**
     * Sets the value of the unitQuantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUnitQuantity(JAXBElement<String> value) {
        this.unitQuantity = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the condType property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCondType() {
        return condType;
    }

    /**
     * Sets the value of the condType property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCondType(JAXBElement<String> value) {
        this.condType = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the condValue property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCondValue() {
        return condValue;
    }

    /**
     * Sets the value of the condValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCondValue(BigDecimal value) {
        this.condValue = value;
    }

    /**
     * Gets the value of the priceGroup property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPriceGroup() {
        return priceGroup;
    }

    /**
     * Sets the value of the priceGroup property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPriceGroup(JAXBElement<String> value) {
        this.priceGroup = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the applySAPDiscounts property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isApplySAPDiscounts() {
        return applySAPDiscounts;
    }

    /**
     * Sets the value of the applySAPDiscounts property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setApplySAPDiscounts(Boolean value) {
        this.applySAPDiscounts = value;
    }

    /**
     * Gets the value of the unspsc property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUNSPSC() {
        return unspsc;
    }

    /**
     * Sets the value of the unspsc property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUNSPSC(JAXBElement<String> value) {
        this.unspsc = ((JAXBElement<String> ) value);
    }

}
