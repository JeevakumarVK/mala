
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order.ShippingContactInfo;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order.User;
import com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PurchaseOrder_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PurchaseOrder");
    private final static QName _ArrayOfLineItemDiscountDTO_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfLineItemDiscountDTO");
    private final static QName _LineItemDiscountDTO_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LineItemDiscountDTO");
    private final static QName _PromotionCodeStatus_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PromotionCodeStatus");
    private final static QName _WebOrderDetails_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebOrderDetails");
    private final static QName _LineItemState_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LineItemState");
    private final static QName _WebOrderDTO_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebOrderDTO");
    private final static QName _SpecialCase_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SpecialCase");
    private final static QName _ArrayOfBasket_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfBasket");
    private final static QName _PaymentType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PaymentType");
    private final static QName _ArrayOfDiscountRecord_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfDiscountRecord");
    private final static QName _CartType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CartType");
    private final static QName _CreditCard_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CreditCard");
    private final static QName _ShippingOptions_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ShippingOptions");
    private final static QName _ArrayOfAddress_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfAddress");
    private final static QName _ArrayOfLineItem_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfLineItem");
    private final static QName _DeliveryOptions_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DeliveryOptions");
    private final static QName _CreditCardType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CreditCardType");
    private final static QName _SpecialCaseType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SpecialCaseType");
    private final static QName _OrderForm_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderForm");
    private final static QName _WebUser_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebUser");
    private final static QName _ArrayOfSpecialCase_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfSpecialCase");
    private final static QName _LineItem_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LineItem");
    private final static QName _BasketCopyCriteria_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "BasketCopyCriteria");
    private final static QName _DiscountType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DiscountType");
    private final static QName _WebOrderUpdate_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebOrderUpdate");
    private final static QName _AddressType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "AddressType");
    private final static QName _Address_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Address");
    private final static QName _OrderSearchCriteria_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderSearchCriteria");
    private final static QName _ArrayOfWebOrderDTO_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfWebOrderDTO");
    private final static QName _PromotionCodeRecord_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PromotionCodeRecord");
    private final static QName _ArrayOfOrderForm_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfOrderForm");
    private final static QName _Basket_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Basket");
    private final static QName _ShipOptions_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ShipOptions");
    private final static QName _ArrayOfPromotionCodeRecord_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ArrayOfPromotionCodeRecord");
    private final static QName _OrderType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderType");
    private final static QName _WebOrderSearchCriteria_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebOrderSearchCriteria");
    private final static QName _DiscountRecord_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DiscountRecord");
    private final static QName _StatusCodes_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "StatusCodes");
    private final static QName _BasketCopyCriteriaApproveeSapCustomerNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ApproveeSapCustomerNumber");
    private final static QName _BasketCopyCriteriaSourceBasketName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SourceBasketName");
    private final static QName _BasketCopyCriteriaApproveeSapContactNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ApproveeSapContactNumber");
    private final static QName _BasketCopyCriteriaTargetBasketName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "TargetBasketName");
    private final static QName _SpecialCaseSpecialCaseValue_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SpecialCaseValue");
    private final static QName _WebOrderDetailsCybsNameOnCard_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CybsNameOnCard");
    private final static QName _WebOrderDetailsPONumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PONumber");
    private final static QName _WebOrderDetailsAdditionalInfo_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "AdditionalInfo");
    private final static QName _WebOrderDetailsOrderForms_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderForms");
    private final static QName _WebOrderDetailsCybsAuthCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CybsAuthCode");
    private final static QName _WebOrderDetailsCybsSubscriptionID_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CybsSubscriptionID");
    private final static QName _WebOrderDetailsAddresses_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Addresses");
    private final static QName _WebOrderDetailsCurrency_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Currency");
    private final static QName _WebOrderDetailsCreditCardPayment_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CreditCardPayment");
    private final static QName _WebOrderDetailsErrorMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ErrorMessage");
    private final static QName _WebOrderDetailsName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Name");
    private final static QName _OrderFormFormName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "FormName");
    private final static QName _OrderFormDiscountsApplied_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DiscountsApplied");
    private final static QName _OrderFormLineItems_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LineItems");
    private final static QName _OrderFormPromoCodeRecords_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PromoCodeRecords");
    private final static QName _OrderFormPromoCodes_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PromoCodes");
    private final static QName _OrderFormModifiedBy_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ModifiedBy");
    private final static QName _OrderFormStatus_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Status");
    private final static QName _WebOrderDTOOrderProcessedBy_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderProcessedBy");
    private final static QName _WebOrderDTOWebOrderId_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "WebOrderId");
    private final static QName _WebOrderDTODeliveryOption_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DeliveryOption");
    private final static QName _WebOrderDTOLoginId_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LoginId");
    private final static QName _WebOrderDTOCustomer_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Customer");
    private final static QName _WebOrderDTOOrderStatus_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderStatus");
    private final static QName _WebOrderDTOComments_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Comments");
    private final static QName _WebOrderDTOTotalTimeTaken_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "TotalTimeTaken");
    private final static QName _WebOrderDTOOrderAcknowledgedTime_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderAcknowledgedTime");
    private final static QName _WebOrderDTOSalesOrg_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SalesOrg");
    private final static QName _WebOrderDTOEcomStatus_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "EcomStatus");
    private final static QName _WebOrderDTOMemberType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "MemberType");
    private final static QName _WebOrderDTOSAPOrderNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SAPOrderNumber");
    private final static QName _WebOrderDTOOrderHistory_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "OrderHistory");
    private final static QName _WebOrderDTOSAPContactNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SAPContactNumber");
    private final static QName _WebOrderDTOPL_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PL");
    private final static QName _DiscountRecordPromoCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PromoCode");
    private final static QName _DiscountRecordBasketDisplayMessageX0020_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "BasketDisplayMessage_x0020_");
    private final static QName _DiscountRecordDiscountNameX0020X0020_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DiscountName_x0020__x0020_");
    private final static QName _OrderSearchCriteriaQuoteReference_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "QuoteReference");
    private final static QName _OrderSearchCriteriaUser_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "User");
    private final static QName _OrderSearchCriteriaUserLogonName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "UserLogonName");
    private final static QName _OrderSearchCriteriaShoppingCartID_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ShoppingCartID");
    private final static QName _OrderSearchCriteriaBasketName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "BasketName");
    private final static QName _OrderSearchCriteriaPunchOutSource_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PunchOutSource");
    private final static QName _CreditCardCyberSourceSubscriptionID_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CyberSourceSubscriptionID");
    private final static QName _CreditCardCyberSourceAuthorizationCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CyberSourceAuthorizationCode");
    private final static QName _CreditCardCustomerNameOnCard_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CustomerNameOnCard");
    private final static QName _CreditCardCardNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CardNumber");
    private final static QName _WebUserSapContactNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SapContactNumber");
    private final static QName _WebUserLastName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LastName");
    private final static QName _WebUserSapCustomerNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SapCustomerNumber");
    private final static QName _WebUserUserMemberType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "UserMemberType");
    private final static QName _WebUserFirstName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "FirstName");
    private final static QName _WebUserEcommStatus_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "EcommStatus");
    private final static QName _WebUserLoginName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LoginName");
    private final static QName _WebUserSapOrderNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SapOrderNumber");
    private final static QName _PurchaseOrderTrackingId_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "TrackingId");
    private final static QName _LineItemDiscountDTOBasketDisplayMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "BasketDisplayMessage");
    private final static QName _LineItemDiscountDTODiscountName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DiscountName");
    private final static QName _BasketObsoleteLineItems_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ObsoleteLineItems");
    private final static QName _BasketIsSAPUserKey_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "IsSAPUserKey");
    private final static QName _LineItemDisplayName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DisplayName");
    private final static QName _LineItemCondType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CondType");
    private final static QName _LineItemCatalogLanguage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CatalogLanguage");
    private final static QName _LineItemProductCategoryHierarchyString_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ProductCategoryHierarchyString");
    private final static QName _LineItemProductCategory_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ProductCategory");
    private final static QName _LineItemConfigSummary_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ConfigSummary");
    private final static QName _LineItemPriceGroup_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PriceGroup");
    private final static QName _LineItemVariantID_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "VariantID");
    private final static QName _LineItemSapIdentificationNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SapIdentificationNumber");
    private final static QName _LineItemSalesUnit_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SalesUnit");
    private final static QName _LineItemDescription_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Description");
    private final static QName _LineItemAmount_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Amount");
    private final static QName _LineItemUNSPSC_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "UNSPSC");
    private final static QName _LineItemNotes_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Notes");
    private final static QName _LineItemUnitQuantity_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "UnitQuantity");
    private final static QName _AddressCNTelephoneNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CNTelephoneNumber");
    private final static QName _AddressCity_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "City");
    private final static QName _AddressCompanyName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CompanyName");
    private final static QName _AddressPhoneNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PhoneNumber");
    private final static QName _AddressLastAccessedAddressId_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "LastAccessedAddressId");
    private final static QName _AddressCNMobileNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CNMobileNumber");
    private final static QName _AddressLine2_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Line2");
    private final static QName _AddressRegionName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "RegionName");
    private final static QName _AddressSPRAS_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SPRAS");
    private final static QName _AddressLine1_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Line1");
    private final static QName _AddressAttention_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Attention");
    private final static QName _AddressAddrType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "AddrType");
    private final static QName _AddressRegionCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "RegionCode");
    private final static QName _AddressContactInfo_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "ContactInfo");
    private final static QName _AddressPhoneNumberMobile_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PhoneNumberMobile");
    private final static QName _AddressSAPID_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SAPID");
    private final static QName _AddressDropShipLine3_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DropShipLine3");
    private final static QName _AddressDropShipLine4_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DropShipLine4");
    private final static QName _AddressDropShipLine1_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DropShipLine1");
    private final static QName _AddressDropShipLine2_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DropShipLine2");
    private final static QName _AddressSpecialInstructions_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "SpecialInstructions");
    private final static QName _AddressMiddleName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "MiddleName");
    private final static QName _AddressPostalCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "PostalCode");
    private final static QName _AddressState_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "state");
    private final static QName _AddressLand_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "Land");
    private final static QName _AddressStreet_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "street");
    private final static QName _AddressMailStop_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "MailStop");
    private final static QName _AddressCountryName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CountryName");
    private final static QName _AddressEmailAddress_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "EmailAddress");
    private final static QName _AddressCountryCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CountryCode");
    private final static QName _AddressUserId_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "userId");
    private final static QName _AddressDisplayText_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "DisplayText");
    private final static QName _AddressFaxNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "FaxNumber");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BasketCopyCriteria }
     * 
     */
    public BasketCopyCriteria createBasketCopyCriteria() {
        return new BasketCopyCriteria();
    }

    /**
     * Create an instance of {@link SpecialCase }
     * 
     */
    public SpecialCase createSpecialCase() {
        return new SpecialCase();
    }

    /**
     * Create an instance of {@link ShippingOptions }
     * 
     */
    public ShippingOptions createShippingOptions() {
        return new ShippingOptions();
    }

    /**
     * Create an instance of {@link WebOrderDetails }
     * 
     */
    public WebOrderDetails createWebOrderDetails() {
        return new WebOrderDetails();
    }

    /**
     * Create an instance of {@link WebOrderUpdate }
     * 
     */
    public WebOrderUpdate createWebOrderUpdate() {
        return new WebOrderUpdate();
    }

    /**
     * Create an instance of {@link OrderForm }
     * 
     */
    public OrderForm createOrderForm() {
        return new OrderForm();
    }

    /**
     * Create an instance of {@link WebOrderDTO }
     * 
     */
    public WebOrderDTO createWebOrderDTO() {
        return new WebOrderDTO();
    }

    /**
     * Create an instance of {@link ArrayOfLineItemDiscountDTO }
     * 
     */
    public ArrayOfLineItemDiscountDTO createArrayOfLineItemDiscountDTO() {
        return new ArrayOfLineItemDiscountDTO();
    }

    /**
     * Create an instance of {@link ArrayOfPromotionCodeRecord }
     * 
     */
    public ArrayOfPromotionCodeRecord createArrayOfPromotionCodeRecord() {
        return new ArrayOfPromotionCodeRecord();
    }

    /**
     * Create an instance of {@link ArrayOfLineItem }
     * 
     */
    public ArrayOfLineItem createArrayOfLineItem() {
        return new ArrayOfLineItem();
    }

    /**
     * Create an instance of {@link DiscountRecord }
     * 
     */
    public DiscountRecord createDiscountRecord() {
        return new DiscountRecord();
    }

    /**
     * Create an instance of {@link ArrayOfAddress }
     * 
     */
    public ArrayOfAddress createArrayOfAddress() {
        return new ArrayOfAddress();
    }

    /**
     * Create an instance of {@link ArrayOfWebOrderDTO }
     * 
     */
    public ArrayOfWebOrderDTO createArrayOfWebOrderDTO() {
        return new ArrayOfWebOrderDTO();
    }

    /**
     * Create an instance of {@link OrderSearchCriteria }
     * 
     */
    public OrderSearchCriteria createOrderSearchCriteria() {
        return new OrderSearchCriteria();
    }

    /**
     * Create an instance of {@link CreditCard }
     * 
     */
    public CreditCard createCreditCard() {
        return new CreditCard();
    }

    /**
     * Create an instance of {@link ArrayOfBasket }
     * 
     */
    public ArrayOfBasket createArrayOfBasket() {
        return new ArrayOfBasket();
    }

    /**
     * Create an instance of {@link PromotionCodeRecord }
     * 
     */
    public PromotionCodeRecord createPromotionCodeRecord() {
        return new PromotionCodeRecord();
    }

    /**
     * Create an instance of {@link WebUser }
     * 
     */
    public WebUser createWebUser() {
        return new WebUser();
    }

    /**
     * Create an instance of {@link WebOrderSearchCriteria }
     * 
     */
    public WebOrderSearchCriteria createWebOrderSearchCriteria() {
        return new WebOrderSearchCriteria();
    }

    /**
     * Create an instance of {@link ArrayOfDiscountRecord }
     * 
     */
    public ArrayOfDiscountRecord createArrayOfDiscountRecord() {
        return new ArrayOfDiscountRecord();
    }

    /**
     * Create an instance of {@link PurchaseOrder }
     * 
     */
    public PurchaseOrder createPurchaseOrder() {
        return new PurchaseOrder();
    }

    /**
     * Create an instance of {@link LineItemDiscountDTO }
     * 
     */
    public LineItemDiscountDTO createLineItemDiscountDTO() {
        return new LineItemDiscountDTO();
    }

    /**
     * Create an instance of {@link ArrayOfSpecialCase }
     * 
     */
    public ArrayOfSpecialCase createArrayOfSpecialCase() {
        return new ArrayOfSpecialCase();
    }

    /**
     * Create an instance of {@link Basket }
     * 
     */
    public Basket createBasket() {
        return new Basket();
    }

    /**
     * Create an instance of {@link ArrayOfOrderForm }
     * 
     */
    public ArrayOfOrderForm createArrayOfOrderForm() {
        return new ArrayOfOrderForm();
    }

    /**
     * Create an instance of {@link LineItem }
     * 
     */
    public LineItem createLineItem() {
        return new LineItem();
    }

    /**
     * Create an instance of {@link Address }
     * 
     */
    public Address createAddress() {
        return new Address();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PurchaseOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PurchaseOrder")
    public JAXBElement<PurchaseOrder> createPurchaseOrder(PurchaseOrder value) {
        return new JAXBElement<PurchaseOrder>(_PurchaseOrder_QNAME, PurchaseOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItemDiscountDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfLineItemDiscountDTO")
    public JAXBElement<ArrayOfLineItemDiscountDTO> createArrayOfLineItemDiscountDTO(ArrayOfLineItemDiscountDTO value) {
        return new JAXBElement<ArrayOfLineItemDiscountDTO>(_ArrayOfLineItemDiscountDTO_QNAME, ArrayOfLineItemDiscountDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LineItemDiscountDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LineItemDiscountDTO")
    public JAXBElement<LineItemDiscountDTO> createLineItemDiscountDTO(LineItemDiscountDTO value) {
        return new JAXBElement<LineItemDiscountDTO>(_LineItemDiscountDTO_QNAME, LineItemDiscountDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PromotionCodeStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromotionCodeStatus")
    public JAXBElement<PromotionCodeStatus> createPromotionCodeStatus(PromotionCodeStatus value) {
        return new JAXBElement<PromotionCodeStatus>(_PromotionCodeStatus_QNAME, PromotionCodeStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebOrderDetails")
    public JAXBElement<WebOrderDetails> createWebOrderDetails(WebOrderDetails value) {
        return new JAXBElement<WebOrderDetails>(_WebOrderDetails_QNAME, WebOrderDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LineItemState }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LineItemState")
    public JAXBElement<LineItemState> createLineItemState(LineItemState value) {
        return new JAXBElement<LineItemState>(_LineItemState_QNAME, LineItemState.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebOrderDTO")
    public JAXBElement<WebOrderDTO> createWebOrderDTO(WebOrderDTO value) {
        return new JAXBElement<WebOrderDTO>(_WebOrderDTO_QNAME, WebOrderDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SpecialCase }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SpecialCase")
    public JAXBElement<SpecialCase> createSpecialCase(SpecialCase value) {
        return new JAXBElement<SpecialCase>(_SpecialCase_QNAME, SpecialCase.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBasket }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfBasket")
    public JAXBElement<ArrayOfBasket> createArrayOfBasket(ArrayOfBasket value) {
        return new JAXBElement<ArrayOfBasket>(_ArrayOfBasket_QNAME, ArrayOfBasket.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PaymentType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PaymentType")
    public JAXBElement<PaymentType> createPaymentType(PaymentType value) {
        return new JAXBElement<PaymentType>(_PaymentType_QNAME, PaymentType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfDiscountRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfDiscountRecord")
    public JAXBElement<ArrayOfDiscountRecord> createArrayOfDiscountRecord(ArrayOfDiscountRecord value) {
        return new JAXBElement<ArrayOfDiscountRecord>(_ArrayOfDiscountRecord_QNAME, ArrayOfDiscountRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CartType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CartType")
    public JAXBElement<CartType> createCartType(CartType value) {
        return new JAXBElement<CartType>(_CartType_QNAME, CartType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCard")
    public JAXBElement<CreditCard> createCreditCard(CreditCard value) {
        return new JAXBElement<CreditCard>(_CreditCard_QNAME, CreditCard.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShippingOptions")
    public JAXBElement<ShippingOptions> createShippingOptions(ShippingOptions value) {
        return new JAXBElement<ShippingOptions>(_ShippingOptions_QNAME, ShippingOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfAddress")
    public JAXBElement<ArrayOfAddress> createArrayOfAddress(ArrayOfAddress value) {
        return new JAXBElement<ArrayOfAddress>(_ArrayOfAddress_QNAME, ArrayOfAddress.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfLineItem")
    public JAXBElement<ArrayOfLineItem> createArrayOfLineItem(ArrayOfLineItem value) {
        return new JAXBElement<ArrayOfLineItem>(_ArrayOfLineItem_QNAME, ArrayOfLineItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeliveryOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DeliveryOptions")
    public JAXBElement<DeliveryOptions> createDeliveryOptions(DeliveryOptions value) {
        return new JAXBElement<DeliveryOptions>(_DeliveryOptions_QNAME, DeliveryOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCardType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCardType")
    public JAXBElement<CreditCardType> createCreditCardType(CreditCardType value) {
        return new JAXBElement<CreditCardType>(_CreditCardType_QNAME, CreditCardType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SpecialCaseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SpecialCaseType")
    public JAXBElement<SpecialCaseType> createSpecialCaseType(SpecialCaseType value) {
        return new JAXBElement<SpecialCaseType>(_SpecialCaseType_QNAME, SpecialCaseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderForm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderForm")
    public JAXBElement<OrderForm> createOrderForm(OrderForm value) {
        return new JAXBElement<OrderForm>(_OrderForm_QNAME, OrderForm.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebUser")
    public JAXBElement<WebUser> createWebUser(WebUser value) {
        return new JAXBElement<WebUser>(_WebUser_QNAME, WebUser.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfSpecialCase }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfSpecialCase")
    public JAXBElement<ArrayOfSpecialCase> createArrayOfSpecialCase(ArrayOfSpecialCase value) {
        return new JAXBElement<ArrayOfSpecialCase>(_ArrayOfSpecialCase_QNAME, ArrayOfSpecialCase.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LineItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LineItem")
    public JAXBElement<LineItem> createLineItem(LineItem value) {
        return new JAXBElement<LineItem>(_LineItem_QNAME, LineItem.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketCopyCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "BasketCopyCriteria")
    public JAXBElement<BasketCopyCriteria> createBasketCopyCriteria(BasketCopyCriteria value) {
        return new JAXBElement<BasketCopyCriteria>(_BasketCopyCriteria_QNAME, BasketCopyCriteria.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountType")
    public JAXBElement<String> createDiscountType(String value) {
        return new JAXBElement<String>(_DiscountType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderUpdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebOrderUpdate")
    public JAXBElement<WebOrderUpdate> createWebOrderUpdate(WebOrderUpdate value) {
        return new JAXBElement<WebOrderUpdate>(_WebOrderUpdate_QNAME, WebOrderUpdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddressType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "AddressType")
    public JAXBElement<AddressType> createAddressType(AddressType value) {
        return new JAXBElement<AddressType>(_AddressType_QNAME, AddressType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Address }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Address")
    public JAXBElement<Address> createAddress(Address value) {
        return new JAXBElement<Address>(_Address_QNAME, Address.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderSearchCriteria")
    public JAXBElement<OrderSearchCriteria> createOrderSearchCriteria(OrderSearchCriteria value) {
        return new JAXBElement<OrderSearchCriteria>(_OrderSearchCriteria_QNAME, OrderSearchCriteria.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWebOrderDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfWebOrderDTO")
    public JAXBElement<ArrayOfWebOrderDTO> createArrayOfWebOrderDTO(ArrayOfWebOrderDTO value) {
        return new JAXBElement<ArrayOfWebOrderDTO>(_ArrayOfWebOrderDTO_QNAME, ArrayOfWebOrderDTO.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PromotionCodeRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromotionCodeRecord")
    public JAXBElement<PromotionCodeRecord> createPromotionCodeRecord(PromotionCodeRecord value) {
        return new JAXBElement<PromotionCodeRecord>(_PromotionCodeRecord_QNAME, PromotionCodeRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfOrderForm")
    public JAXBElement<ArrayOfOrderForm> createArrayOfOrderForm(ArrayOfOrderForm value) {
        return new JAXBElement<ArrayOfOrderForm>(_ArrayOfOrderForm_QNAME, ArrayOfOrderForm.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Basket }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Basket")
    public JAXBElement<Basket> createBasket(Basket value) {
        return new JAXBElement<Basket>(_Basket_QNAME, Basket.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShipOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShipOptions")
    public JAXBElement<ShipOptions> createShipOptions(ShipOptions value) {
        return new JAXBElement<ShipOptions>(_ShipOptions_QNAME, ShipOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfPromotionCodeRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ArrayOfPromotionCodeRecord")
    public JAXBElement<ArrayOfPromotionCodeRecord> createArrayOfPromotionCodeRecord(ArrayOfPromotionCodeRecord value) {
        return new JAXBElement<ArrayOfPromotionCodeRecord>(_ArrayOfPromotionCodeRecord_QNAME, ArrayOfPromotionCodeRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderType")
    public JAXBElement<OrderType> createOrderType(OrderType value) {
        return new JAXBElement<OrderType>(_OrderType_QNAME, OrderType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderSearchCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebOrderSearchCriteria")
    public JAXBElement<WebOrderSearchCriteria> createWebOrderSearchCriteria(WebOrderSearchCriteria value) {
        return new JAXBElement<WebOrderSearchCriteria>(_WebOrderSearchCriteria_QNAME, WebOrderSearchCriteria.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DiscountRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountRecord")
    public JAXBElement<DiscountRecord> createDiscountRecord(DiscountRecord value) {
        return new JAXBElement<DiscountRecord>(_DiscountRecord_QNAME, DiscountRecord.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "StatusCodes")
    public JAXBElement<String> createStatusCodes(String value) {
        return new JAXBElement<String>(_StatusCodes_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapCustomerNumber", scope = BasketCopyCriteria.class)
    public JAXBElement<String> createBasketCopyCriteriaApproveeSapCustomerNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapCustomerNumber_QNAME, String.class, BasketCopyCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SourceBasketName", scope = BasketCopyCriteria.class)
    public JAXBElement<String> createBasketCopyCriteriaSourceBasketName(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaSourceBasketName_QNAME, String.class, BasketCopyCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapContactNumber", scope = BasketCopyCriteria.class)
    public JAXBElement<String> createBasketCopyCriteriaApproveeSapContactNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapContactNumber_QNAME, String.class, BasketCopyCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "TargetBasketName", scope = BasketCopyCriteria.class)
    public JAXBElement<String> createBasketCopyCriteriaTargetBasketName(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaTargetBasketName_QNAME, String.class, BasketCopyCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SpecialCaseValue", scope = SpecialCase.class)
    public JAXBElement<String> createSpecialCaseSpecialCaseValue(String value) {
        return new JAXBElement<String>(_SpecialCaseSpecialCaseValue_QNAME, String.class, SpecialCase.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsNameOnCard", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsCybsNameOnCard(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsNameOnCard_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapContactNumber", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsApproveeSapContactNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapContactNumber_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebUser }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebUser", scope = WebOrderDetails.class)
    public JAXBElement<WebUser> createWebOrderDetailsWebUser(WebUser value) {
        return new JAXBElement<WebUser>(_WebUser_QNAME, WebUser.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShippingOptions", scope = WebOrderDetails.class)
    public JAXBElement<ShippingOptions> createWebOrderDetailsShippingOptions(ShippingOptions value) {
        return new JAXBElement<ShippingOptions>(_ShippingOptions_QNAME, ShippingOptions.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PONumber", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsPONumber(String value) {
        return new JAXBElement<String>(_WebOrderDetailsPONumber_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "AdditionalInfo", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsAdditionalInfo(String value) {
        return new JAXBElement<String>(_WebOrderDetailsAdditionalInfo_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderForms", scope = WebOrderDetails.class)
    public JAXBElement<ArrayOfOrderForm> createWebOrderDetailsOrderForms(ArrayOfOrderForm value) {
        return new JAXBElement<ArrayOfOrderForm>(_WebOrderDetailsOrderForms_QNAME, ArrayOfOrderForm.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsAuthCode", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsCybsAuthCode(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsAuthCode_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsSubscriptionID", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsCybsSubscriptionID(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsSubscriptionID_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Addresses", scope = WebOrderDetails.class)
    public JAXBElement<ArrayOfAddress> createWebOrderDetailsAddresses(ArrayOfAddress value) {
        return new JAXBElement<ArrayOfAddress>(_WebOrderDetailsAddresses_QNAME, ArrayOfAddress.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Currency", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsCurrency(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCurrency_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapCustomerNumber", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsApproveeSapCustomerNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapCustomerNumber_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCardPayment", scope = WebOrderDetails.class)
    public JAXBElement<CreditCard> createWebOrderDetailsCreditCardPayment(CreditCard value) {
        return new JAXBElement<CreditCard>(_WebOrderDetailsCreditCardPayment_QNAME, CreditCard.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ErrorMessage", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsErrorMessage(String value) {
        return new JAXBElement<String>(_WebOrderDetailsErrorMessage_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Name", scope = WebOrderDetails.class)
    public JAXBElement<String> createWebOrderDetailsName(String value) {
        return new JAXBElement<String>(_WebOrderDetailsName_QNAME, String.class, WebOrderDetails.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Currency", scope = OrderForm.class)
    public JAXBElement<String> createOrderFormCurrency(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCurrency_QNAME, String.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "FormName", scope = OrderForm.class)
    public JAXBElement<String> createOrderFormFormName(String value) {
        return new JAXBElement<String>(_OrderFormFormName_QNAME, String.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfDiscountRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountsApplied", scope = OrderForm.class)
    public JAXBElement<ArrayOfDiscountRecord> createOrderFormDiscountsApplied(ArrayOfDiscountRecord value) {
        return new JAXBElement<ArrayOfDiscountRecord>(_OrderFormDiscountsApplied_QNAME, ArrayOfDiscountRecord.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LineItems", scope = OrderForm.class)
    public JAXBElement<ArrayOfLineItem> createOrderFormLineItems(ArrayOfLineItem value) {
        return new JAXBElement<ArrayOfLineItem>(_OrderFormLineItems_QNAME, ArrayOfLineItem.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfPromotionCodeRecord }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCodeRecords", scope = OrderForm.class)
    public JAXBElement<ArrayOfPromotionCodeRecord> createOrderFormPromoCodeRecords(ArrayOfPromotionCodeRecord value) {
        return new JAXBElement<ArrayOfPromotionCodeRecord>(_OrderFormPromoCodeRecords_QNAME, ArrayOfPromotionCodeRecord.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfstring }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCodes", scope = OrderForm.class)
    public JAXBElement<ArrayOfstring> createOrderFormPromoCodes(ArrayOfstring value) {
        return new JAXBElement<ArrayOfstring>(_OrderFormPromoCodes_QNAME, ArrayOfstring.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ModifiedBy", scope = OrderForm.class)
    public JAXBElement<String> createOrderFormModifiedBy(String value) {
        return new JAXBElement<String>(_OrderFormModifiedBy_QNAME, String.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Status", scope = OrderForm.class)
    public JAXBElement<String> createOrderFormStatus(String value) {
        return new JAXBElement<String>(_OrderFormStatus_QNAME, String.class, OrderForm.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderProcessedBy", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOOrderProcessedBy(String value) {
        return new JAXBElement<String>(_WebOrderDTOOrderProcessedBy_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "WebOrderId", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOWebOrderId(String value) {
        return new JAXBElement<String>(_WebOrderDTOWebOrderId_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DeliveryOption", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTODeliveryOption(String value) {
        return new JAXBElement<String>(_WebOrderDTODeliveryOption_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LoginId", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOLoginId(String value) {
        return new JAXBElement<String>(_WebOrderDTOLoginId_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Customer", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOCustomer(String value) {
        return new JAXBElement<String>(_WebOrderDTOCustomer_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderStatus", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOOrderStatus(String value) {
        return new JAXBElement<String>(_WebOrderDTOOrderStatus_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Comments", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOComments(String value) {
        return new JAXBElement<String>(_WebOrderDTOComments_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Currency", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOCurrency(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCurrency_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "TotalTimeTaken", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOTotalTimeTaken(String value) {
        return new JAXBElement<String>(_WebOrderDTOTotalTimeTaken_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderAcknowledgedTime", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOOrderAcknowledgedTime(String value) {
        return new JAXBElement<String>(_WebOrderDTOOrderAcknowledgedTime_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SalesOrg", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOSalesOrg(String value) {
        return new JAXBElement<String>(_WebOrderDTOSalesOrg_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "EcomStatus", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOEcomStatus(String value) {
        return new JAXBElement<String>(_WebOrderDTOEcomStatus_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "MemberType", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOMemberType(String value) {
        return new JAXBElement<String>(_WebOrderDTOMemberType_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SAPOrderNumber", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOSAPOrderNumber(String value) {
        return new JAXBElement<String>(_WebOrderDTOSAPOrderNumber_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderHistory", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOOrderHistory(String value) {
        return new JAXBElement<String>(_WebOrderDTOOrderHistory_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SAPContactNumber", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOSAPContactNumber(String value) {
        return new JAXBElement<String>(_WebOrderDTOSAPContactNumber_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PL", scope = WebOrderDTO.class)
    public JAXBElement<String> createWebOrderDTOPL(String value) {
        return new JAXBElement<String>(_WebOrderDTOPL_QNAME, String.class, WebOrderDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCode", scope = DiscountRecord.class)
    public JAXBElement<String> createDiscountRecordPromoCode(String value) {
        return new JAXBElement<String>(_DiscountRecordPromoCode_QNAME, String.class, DiscountRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "BasketDisplayMessage_x0020_", scope = DiscountRecord.class)
    public JAXBElement<String> createDiscountRecordBasketDisplayMessageX0020(String value) {
        return new JAXBElement<String>(_DiscountRecordBasketDisplayMessageX0020_QNAME, String.class, DiscountRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountName_x0020__x0020_", scope = DiscountRecord.class)
    public JAXBElement<String> createDiscountRecordDiscountNameX0020X0020(String value) {
        return new JAXBElement<String>(_DiscountRecordDiscountNameX0020X0020_QNAME, String.class, DiscountRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapContactNumber", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaApproveeSapContactNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapContactNumber_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShippingOptions", scope = OrderSearchCriteria.class)
    public JAXBElement<ShippingOptions> createOrderSearchCriteriaShippingOptions(ShippingOptions value) {
        return new JAXBElement<ShippingOptions>(_ShippingOptions_QNAME, ShippingOptions.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "QuoteReference", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaQuoteReference(String value) {
        return new JAXBElement<String>(_OrderSearchCriteriaQuoteReference_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PONumber", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaPONumber(String value) {
        return new JAXBElement<String>(_WebOrderDetailsPONumber_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link User }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "User", scope = OrderSearchCriteria.class)
    public JAXBElement<User> createOrderSearchCriteriaUser(User value) {
        return new JAXBElement<User>(_OrderSearchCriteriaUser_QNAME, User.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Addresses", scope = OrderSearchCriteria.class)
    public JAXBElement<ArrayOfAddress> createOrderSearchCriteriaAddresses(ArrayOfAddress value) {
        return new JAXBElement<ArrayOfAddress>(_WebOrderDetailsAddresses_QNAME, ArrayOfAddress.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapCustomerNumber", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaApproveeSapCustomerNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapCustomerNumber_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "UserLogonName", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaUserLogonName(String value) {
        return new JAXBElement<String>(_OrderSearchCriteriaUserLogonName_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShoppingCartID", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaShoppingCartID(String value) {
        return new JAXBElement<String>(_OrderSearchCriteriaShoppingCartID_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "BasketName", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaBasketName(String value) {
        return new JAXBElement<String>(_OrderSearchCriteriaBasketName_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LineItems", scope = OrderSearchCriteria.class)
    public JAXBElement<ArrayOfLineItem> createOrderSearchCriteriaLineItems(ArrayOfLineItem value) {
        return new JAXBElement<ArrayOfLineItem>(_OrderFormLineItems_QNAME, ArrayOfLineItem.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCardPayment", scope = OrderSearchCriteria.class)
    public JAXBElement<CreditCard> createOrderSearchCriteriaCreditCardPayment(CreditCard value) {
        return new JAXBElement<CreditCard>(_WebOrderDetailsCreditCardPayment_QNAME, CreditCard.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfstring }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCodes", scope = OrderSearchCriteria.class)
    public JAXBElement<ArrayOfstring> createOrderSearchCriteriaPromoCodes(ArrayOfstring value) {
        return new JAXBElement<ArrayOfstring>(_OrderFormPromoCodes_QNAME, ArrayOfstring.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PunchOutSource", scope = OrderSearchCriteria.class)
    public JAXBElement<String> createOrderSearchCriteriaPunchOutSource(String value) {
        return new JAXBElement<String>(_OrderSearchCriteriaPunchOutSource_QNAME, String.class, OrderSearchCriteria.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CyberSourceSubscriptionID", scope = CreditCard.class)
    public JAXBElement<String> createCreditCardCyberSourceSubscriptionID(String value) {
        return new JAXBElement<String>(_CreditCardCyberSourceSubscriptionID_QNAME, String.class, CreditCard.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CyberSourceAuthorizationCode", scope = CreditCard.class)
    public JAXBElement<String> createCreditCardCyberSourceAuthorizationCode(String value) {
        return new JAXBElement<String>(_CreditCardCyberSourceAuthorizationCode_QNAME, String.class, CreditCard.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CustomerNameOnCard", scope = CreditCard.class)
    public JAXBElement<String> createCreditCardCustomerNameOnCard(String value) {
        return new JAXBElement<String>(_CreditCardCustomerNameOnCard_QNAME, String.class, CreditCard.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CardNumber", scope = CreditCard.class)
    public JAXBElement<String> createCreditCardCardNumber(String value) {
        return new JAXBElement<String>(_CreditCardCardNumber_QNAME, String.class, CreditCard.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCode", scope = PromotionCodeRecord.class)
    public JAXBElement<String> createPromotionCodeRecordPromoCode(String value) {
        return new JAXBElement<String>(_DiscountRecordPromoCode_QNAME, String.class, PromotionCodeRecord.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SapContactNumber", scope = WebUser.class)
    public JAXBElement<String> createWebUserSapContactNumber(String value) {
        return new JAXBElement<String>(_WebUserSapContactNumber_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LastName", scope = WebUser.class)
    public JAXBElement<String> createWebUserLastName(String value) {
        return new JAXBElement<String>(_WebUserLastName_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderProcessedBy", scope = WebUser.class)
    public JAXBElement<String> createWebUserOrderProcessedBy(String value) {
        return new JAXBElement<String>(_WebOrderDTOOrderProcessedBy_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SapCustomerNumber", scope = WebUser.class)
    public JAXBElement<String> createWebUserSapCustomerNumber(String value) {
        return new JAXBElement<String>(_WebUserSapCustomerNumber_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SalesOrg", scope = WebUser.class)
    public JAXBElement<String> createWebUserSalesOrg(String value) {
        return new JAXBElement<String>(_WebOrderDTOSalesOrg_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "UserMemberType", scope = WebUser.class)
    public JAXBElement<String> createWebUserUserMemberType(String value) {
        return new JAXBElement<String>(_WebUserUserMemberType_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "FirstName", scope = WebUser.class)
    public JAXBElement<String> createWebUserFirstName(String value) {
        return new JAXBElement<String>(_WebUserFirstName_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "EcommStatus", scope = WebUser.class)
    public JAXBElement<String> createWebUserEcommStatus(String value) {
        return new JAXBElement<String>(_WebUserEcommStatus_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LoginName", scope = WebUser.class)
    public JAXBElement<String> createWebUserLoginName(String value) {
        return new JAXBElement<String>(_WebUserLoginName_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SapOrderNumber", scope = WebUser.class)
    public JAXBElement<String> createWebUserSapOrderNumber(String value) {
        return new JAXBElement<String>(_WebUserSapOrderNumber_QNAME, String.class, WebUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "TrackingId", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderTrackingId(String value) {
        return new JAXBElement<String>(_PurchaseOrderTrackingId_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsNameOnCard", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderCybsNameOnCard(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsNameOnCard_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShippingOptions", scope = PurchaseOrder.class)
    public JAXBElement<ShippingOptions> createPurchaseOrderShippingOptions(ShippingOptions value) {
        return new JAXBElement<ShippingOptions>(_ShippingOptions_QNAME, ShippingOptions.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ErrorMessage", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderErrorMessage(String value) {
        return new JAXBElement<String>(_WebOrderDetailsErrorMessage_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCardPayment", scope = PurchaseOrder.class)
    public JAXBElement<CreditCard> createPurchaseOrderCreditCardPayment(CreditCard value) {
        return new JAXBElement<CreditCard>(_WebOrderDetailsCreditCardPayment_QNAME, CreditCard.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PONumber", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderPONumber(String value) {
        return new JAXBElement<String>(_WebOrderDetailsPONumber_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsSubscriptionID", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderCybsSubscriptionID(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsSubscriptionID_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsAuthCode", scope = PurchaseOrder.class)
    public JAXBElement<String> createPurchaseOrderCybsAuthCode(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsAuthCode_QNAME, String.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderForms", scope = PurchaseOrder.class)
    public JAXBElement<ArrayOfOrderForm> createPurchaseOrderOrderForms(ArrayOfOrderForm value) {
        return new JAXBElement<ArrayOfOrderForm>(_WebOrderDetailsOrderForms_QNAME, ArrayOfOrderForm.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Addresses", scope = PurchaseOrder.class)
    public JAXBElement<ArrayOfAddress> createPurchaseOrderAddresses(ArrayOfAddress value) {
        return new JAXBElement<ArrayOfAddress>(_WebOrderDetailsAddresses_QNAME, ArrayOfAddress.class, PurchaseOrder.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "BasketDisplayMessage", scope = LineItemDiscountDTO.class)
    public JAXBElement<String> createLineItemDiscountDTOBasketDisplayMessage(String value) {
        return new JAXBElement<String>(_LineItemDiscountDTOBasketDisplayMessage_QNAME, String.class, LineItemDiscountDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PromoCode", scope = LineItemDiscountDTO.class)
    public JAXBElement<String> createLineItemDiscountDTOPromoCode(String value) {
        return new JAXBElement<String>(_DiscountRecordPromoCode_QNAME, String.class, LineItemDiscountDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountName", scope = LineItemDiscountDTO.class)
    public JAXBElement<String> createLineItemDiscountDTODiscountName(String value) {
        return new JAXBElement<String>(_LineItemDiscountDTODiscountName_QNAME, String.class, LineItemDiscountDTO.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ObsoleteLineItems", scope = Basket.class)
    public JAXBElement<ArrayOfLineItem> createBasketObsoleteLineItems(ArrayOfLineItem value) {
        return new JAXBElement<ArrayOfLineItem>(_BasketObsoleteLineItems_QNAME, ArrayOfLineItem.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsNameOnCard", scope = Basket.class)
    public JAXBElement<String> createBasketCybsNameOnCard(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsNameOnCard_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapContactNumber", scope = Basket.class)
    public JAXBElement<String> createBasketApproveeSapContactNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapContactNumber_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ShippingOptions", scope = Basket.class)
    public JAXBElement<ShippingOptions> createBasketShippingOptions(ShippingOptions value) {
        return new JAXBElement<ShippingOptions>(_ShippingOptions_QNAME, ShippingOptions.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PONumber", scope = Basket.class)
    public JAXBElement<String> createBasketPONumber(String value) {
        return new JAXBElement<String>(_WebOrderDetailsPONumber_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "AdditionalInfo", scope = Basket.class)
    public JAXBElement<String> createBasketAdditionalInfo(String value) {
        return new JAXBElement<String>(_WebOrderDetailsAdditionalInfo_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfOrderForm }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "OrderForms", scope = Basket.class)
    public JAXBElement<ArrayOfOrderForm> createBasketOrderForms(ArrayOfOrderForm value) {
        return new JAXBElement<ArrayOfOrderForm>(_WebOrderDetailsOrderForms_QNAME, ArrayOfOrderForm.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsAuthCode", scope = Basket.class)
    public JAXBElement<String> createBasketCybsAuthCode(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsAuthCode_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CybsSubscriptionID", scope = Basket.class)
    public JAXBElement<String> createBasketCybsSubscriptionID(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCybsSubscriptionID_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Addresses", scope = Basket.class)
    public JAXBElement<ArrayOfAddress> createBasketAddresses(ArrayOfAddress value) {
        return new JAXBElement<ArrayOfAddress>(_WebOrderDetailsAddresses_QNAME, ArrayOfAddress.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Currency", scope = Basket.class)
    public JAXBElement<String> createBasketCurrency(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCurrency_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ApproveeSapCustomerNumber", scope = Basket.class)
    public JAXBElement<String> createBasketApproveeSapCustomerNumber(String value) {
        return new JAXBElement<String>(_BasketCopyCriteriaApproveeSapCustomerNumber_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreditCard }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CreditCardPayment", scope = Basket.class)
    public JAXBElement<CreditCard> createBasketCreditCardPayment(CreditCard value) {
        return new JAXBElement<CreditCard>(_WebOrderDetailsCreditCardPayment_QNAME, CreditCard.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ErrorMessage", scope = Basket.class)
    public JAXBElement<String> createBasketErrorMessage(String value) {
        return new JAXBElement<String>(_WebOrderDetailsErrorMessage_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Name", scope = Basket.class)
    public JAXBElement<String> createBasketName(String value) {
        return new JAXBElement<String>(_WebOrderDetailsName_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "IsSAPUserKey", scope = Basket.class)
    public JAXBElement<String> createBasketIsSAPUserKey(String value) {
        return new JAXBElement<String>(_BasketIsSAPUserKey_QNAME, String.class, Basket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DisplayName", scope = LineItem.class)
    public JAXBElement<String> createLineItemDisplayName(String value) {
        return new JAXBElement<String>(_LineItemDisplayName_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CondType", scope = LineItem.class)
    public JAXBElement<String> createLineItemCondType(String value) {
        return new JAXBElement<String>(_LineItemCondType_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfLineItemDiscountDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DiscountsApplied", scope = LineItem.class)
    public JAXBElement<ArrayOfLineItemDiscountDTO> createLineItemDiscountsApplied(ArrayOfLineItemDiscountDTO value) {
        return new JAXBElement<ArrayOfLineItemDiscountDTO>(_OrderFormDiscountsApplied_QNAME, ArrayOfLineItemDiscountDTO.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CatalogLanguage", scope = LineItem.class)
    public JAXBElement<String> createLineItemCatalogLanguage(String value) {
        return new JAXBElement<String>(_LineItemCatalogLanguage_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ProductCategoryHierarchyString", scope = LineItem.class)
    public JAXBElement<String> createLineItemProductCategoryHierarchyString(String value) {
        return new JAXBElement<String>(_LineItemProductCategoryHierarchyString_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ProductCategory", scope = LineItem.class)
    public JAXBElement<String> createLineItemProductCategory(String value) {
        return new JAXBElement<String>(_LineItemProductCategory_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ConfigSummary", scope = LineItem.class)
    public JAXBElement<String> createLineItemConfigSummary(String value) {
        return new JAXBElement<String>(_LineItemConfigSummary_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PriceGroup", scope = LineItem.class)
    public JAXBElement<String> createLineItemPriceGroup(String value) {
        return new JAXBElement<String>(_LineItemPriceGroup_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "VariantID", scope = LineItem.class)
    public JAXBElement<String> createLineItemVariantID(String value) {
        return new JAXBElement<String>(_LineItemVariantID_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SapIdentificationNumber", scope = LineItem.class)
    public JAXBElement<String> createLineItemSapIdentificationNumber(String value) {
        return new JAXBElement<String>(_LineItemSapIdentificationNumber_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SalesUnit", scope = LineItem.class)
    public JAXBElement<String> createLineItemSalesUnit(String value) {
        return new JAXBElement<String>(_LineItemSalesUnit_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Description", scope = LineItem.class)
    public JAXBElement<String> createLineItemDescription(String value) {
        return new JAXBElement<String>(_LineItemDescription_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Amount", scope = LineItem.class)
    public JAXBElement<String> createLineItemAmount(String value) {
        return new JAXBElement<String>(_LineItemAmount_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Currency", scope = LineItem.class)
    public JAXBElement<String> createLineItemCurrency(String value) {
        return new JAXBElement<String>(_WebOrderDetailsCurrency_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "UNSPSC", scope = LineItem.class)
    public JAXBElement<String> createLineItemUNSPSC(String value) {
        return new JAXBElement<String>(_LineItemUNSPSC_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Notes", scope = LineItem.class)
    public JAXBElement<String> createLineItemNotes(String value) {
        return new JAXBElement<String>(_LineItemNotes_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "UnitQuantity", scope = LineItem.class)
    public JAXBElement<String> createLineItemUnitQuantity(String value) {
        return new JAXBElement<String>(_LineItemUnitQuantity_QNAME, String.class, LineItem.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CNTelephoneNumber", scope = Address.class)
    public JAXBElement<String> createAddressCNTelephoneNumber(String value) {
        return new JAXBElement<String>(_AddressCNTelephoneNumber_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "City", scope = Address.class)
    public JAXBElement<String> createAddressCity(String value) {
        return new JAXBElement<String>(_AddressCity_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CompanyName", scope = Address.class)
    public JAXBElement<String> createAddressCompanyName(String value) {
        return new JAXBElement<String>(_AddressCompanyName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PhoneNumber", scope = Address.class)
    public JAXBElement<String> createAddressPhoneNumber(String value) {
        return new JAXBElement<String>(_AddressPhoneNumber_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LastAccessedAddressId", scope = Address.class)
    public JAXBElement<String> createAddressLastAccessedAddressId(String value) {
        return new JAXBElement<String>(_AddressLastAccessedAddressId_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CNMobileNumber", scope = Address.class)
    public JAXBElement<String> createAddressCNMobileNumber(String value) {
        return new JAXBElement<String>(_AddressCNMobileNumber_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "AdditionalInfo", scope = Address.class)
    public JAXBElement<String> createAddressAdditionalInfo(String value) {
        return new JAXBElement<String>(_WebOrderDetailsAdditionalInfo_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Line2", scope = Address.class)
    public JAXBElement<String> createAddressLine2(String value) {
        return new JAXBElement<String>(_AddressLine2_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "RegionName", scope = Address.class)
    public JAXBElement<String> createAddressRegionName(String value) {
        return new JAXBElement<String>(_AddressRegionName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SPRAS", scope = Address.class)
    public JAXBElement<String> createAddressSPRAS(String value) {
        return new JAXBElement<String>(_AddressSPRAS_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Line1", scope = Address.class)
    public JAXBElement<String> createAddressLine1(String value) {
        return new JAXBElement<String>(_AddressLine1_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Attention", scope = Address.class)
    public JAXBElement<String> createAddressAttention(String value) {
        return new JAXBElement<String>(_AddressAttention_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "AddrType", scope = Address.class)
    public JAXBElement<String> createAddressAddrType(String value) {
        return new JAXBElement<String>(_AddressAddrType_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "RegionCode", scope = Address.class)
    public JAXBElement<String> createAddressRegionCode(String value) {
        return new JAXBElement<String>(_AddressRegionCode_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingContactInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "ContactInfo", scope = Address.class)
    public JAXBElement<ShippingContactInfo> createAddressContactInfo(ShippingContactInfo value) {
        return new JAXBElement<ShippingContactInfo>(_AddressContactInfo_QNAME, ShippingContactInfo.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PhoneNumberMobile", scope = Address.class)
    public JAXBElement<String> createAddressPhoneNumberMobile(String value) {
        return new JAXBElement<String>(_AddressPhoneNumberMobile_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SAPID", scope = Address.class)
    public JAXBElement<String> createAddressSAPID(String value) {
        return new JAXBElement<String>(_AddressSAPID_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DropShipLine3", scope = Address.class)
    public JAXBElement<String> createAddressDropShipLine3(String value) {
        return new JAXBElement<String>(_AddressDropShipLine3_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DropShipLine4", scope = Address.class)
    public JAXBElement<String> createAddressDropShipLine4(String value) {
        return new JAXBElement<String>(_AddressDropShipLine4_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DropShipLine1", scope = Address.class)
    public JAXBElement<String> createAddressDropShipLine1(String value) {
        return new JAXBElement<String>(_AddressDropShipLine1_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DropShipLine2", scope = Address.class)
    public JAXBElement<String> createAddressDropShipLine2(String value) {
        return new JAXBElement<String>(_AddressDropShipLine2_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "SpecialInstructions", scope = Address.class)
    public JAXBElement<String> createAddressSpecialInstructions(String value) {
        return new JAXBElement<String>(_AddressSpecialInstructions_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "MiddleName", scope = Address.class)
    public JAXBElement<String> createAddressMiddleName(String value) {
        return new JAXBElement<String>(_AddressMiddleName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "PostalCode", scope = Address.class)
    public JAXBElement<String> createAddressPostalCode(String value) {
        return new JAXBElement<String>(_AddressPostalCode_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "LastName", scope = Address.class)
    public JAXBElement<String> createAddressLastName(String value) {
        return new JAXBElement<String>(_WebUserLastName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "state", scope = Address.class)
    public JAXBElement<String> createAddressState(String value) {
        return new JAXBElement<String>(_AddressState_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "Land", scope = Address.class)
    public JAXBElement<String> createAddressLand(String value) {
        return new JAXBElement<String>(_AddressLand_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "street", scope = Address.class)
    public JAXBElement<String> createAddressStreet(String value) {
        return new JAXBElement<String>(_AddressStreet_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "MailStop", scope = Address.class)
    public JAXBElement<String> createAddressMailStop(String value) {
        return new JAXBElement<String>(_AddressMailStop_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CountryName", scope = Address.class)
    public JAXBElement<String> createAddressCountryName(String value) {
        return new JAXBElement<String>(_AddressCountryName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "FirstName", scope = Address.class)
    public JAXBElement<String> createAddressFirstName(String value) {
        return new JAXBElement<String>(_WebUserFirstName_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "EmailAddress", scope = Address.class)
    public JAXBElement<String> createAddressEmailAddress(String value) {
        return new JAXBElement<String>(_AddressEmailAddress_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "CountryCode", scope = Address.class)
    public JAXBElement<String> createAddressCountryCode(String value) {
        return new JAXBElement<String>(_AddressCountryCode_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "userId", scope = Address.class)
    public JAXBElement<String> createAddressUserId(String value) {
        return new JAXBElement<String>(_AddressUserId_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "DisplayText", scope = Address.class)
    public JAXBElement<String> createAddressDisplayText(String value) {
        return new JAXBElement<String>(_AddressDisplayText_QNAME, String.class, Address.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", name = "FaxNumber", scope = Address.class)
    public JAXBElement<String> createAddressFaxNumber(String value) {
        return new JAXBElement<String>(_AddressFaxNumber_QNAME, String.class, Address.class, value);
    }

}
