
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;

import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order.User;
import com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring;


/**
 * <p>Java class for OrderSearchCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderSearchCriteria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UserID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="UserLogonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BasketName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LineItems" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfLineItem" minOccurs="0"/>
 *         &lt;element name="PromoCodes" type="{http://schemas.microsoft.com/2003/10/Serialization/Arrays}ArrayOfstring" minOccurs="0"/>
 *         &lt;element name="Addresses" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfAddress" minOccurs="0"/>
 *         &lt;element name="ShippingOptions" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ShippingOptions" minOccurs="0"/>
 *         &lt;element name="CreditCardPayment" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}CreditCard" minOccurs="0"/>
 *         &lt;element name="PONumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SapUser" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PunchOutSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ShoppingCartID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="User" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile}User" minOccurs="0"/>
 *         &lt;element name="ApproveeSapContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ApproveeSapCustomerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="VATExemptionSelectedByUser" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsRunPipeline" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CartTotalExceed4000" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="DeliveryBlockFor04IN" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="MA9Checked" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="QuoteReference" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderSearchCriteria", propOrder = {
    "userID",
    "userLogonName",
    "basketName",
    "lineItems",
    "promoCodes",
    "addresses",
    "shippingOptions",
    "creditCardPayment",
    "poNumber",
    "sapUser",
    "punchOutSource",
    "shoppingCartID",
    "user",
    "approveeSapContactNumber",
    "approveeSapCustomerNumber",
    "vatExemptionSelectedByUser",
    "isRunPipeline",
    "cartTotalExceed4000",
    "deliveryBlockFor04IN",
    "ma9Checked",
    "quoteReference"
})
public class OrderSearchCriteria {

    @XmlElement(name = "UserID")
    protected String userID;
    @XmlElementRef(name = "UserLogonName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> userLogonName;
    @XmlElementRef(name = "BasketName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> basketName;
    @XmlElementRef(name = "LineItems", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfLineItem> lineItems;
    @XmlElementRef(name = "PromoCodes", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfstring> promoCodes;
    @XmlElementRef(name = "Addresses", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfAddress> addresses;
    @XmlElementRef(name = "ShippingOptions", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ShippingOptions> shippingOptions;
    @XmlElementRef(name = "CreditCardPayment", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<CreditCard> creditCardPayment;
    @XmlElementRef(name = "PONumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> poNumber;
    @XmlElement(name = "SapUser")
    protected Boolean sapUser;
    @XmlElementRef(name = "PunchOutSource", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> punchOutSource;
    @XmlElementRef(name = "ShoppingCartID", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> shoppingCartID;
    @XmlElementRef(name = "User", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<User> user;
    @XmlElementRef(name = "ApproveeSapContactNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapContactNumber;
    @XmlElementRef(name = "ApproveeSapCustomerNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> approveeSapCustomerNumber;
    @XmlElement(name = "VATExemptionSelectedByUser")
    protected Boolean vatExemptionSelectedByUser;
    @XmlElement(name = "IsRunPipeline")
    protected Boolean isRunPipeline;
    @XmlElement(name = "CartTotalExceed4000")
    protected Boolean cartTotalExceed4000;
    @XmlElement(name = "DeliveryBlockFor04IN")
    protected Boolean deliveryBlockFor04IN;
    @XmlElement(name = "MA9Checked")
    protected Boolean ma9Checked;
    @XmlElementRef(name = "QuoteReference", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> quoteReference;

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets the value of the userLogonName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getUserLogonName() {
        return userLogonName;
    }

    /**
     * Sets the value of the userLogonName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setUserLogonName(JAXBElement<String> value) {
        this.userLogonName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the basketName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBasketName() {
        return basketName;
    }

    /**
     * Sets the value of the basketName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBasketName(JAXBElement<String> value) {
        this.basketName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the lineItems property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}
     *     
     */
    public JAXBElement<ArrayOfLineItem> getLineItems() {
        return lineItems;
    }

    /**
     * Sets the value of the lineItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfLineItem }{@code >}
     *     
     */
    public void setLineItems(JAXBElement<ArrayOfLineItem> value) {
        this.lineItems = ((JAXBElement<ArrayOfLineItem> ) value);
    }

    /**
     * Gets the value of the promoCodes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfstring }{@code >}
     *     
     */
    public JAXBElement<ArrayOfstring> getPromoCodes() {
        return promoCodes;
    }

    /**
     * Sets the value of the promoCodes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfstring }{@code >}
     *     
     */
    public void setPromoCodes(JAXBElement<ArrayOfstring> value) {
        this.promoCodes = ((JAXBElement<ArrayOfstring> ) value);
    }

    /**
     * Gets the value of the addresses property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}
     *     
     */
    public JAXBElement<ArrayOfAddress> getAddresses() {
        return addresses;
    }

    /**
     * Sets the value of the addresses property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfAddress }{@code >}
     *     
     */
    public void setAddresses(JAXBElement<ArrayOfAddress> value) {
        this.addresses = ((JAXBElement<ArrayOfAddress> ) value);
    }

    /**
     * Gets the value of the shippingOptions property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}
     *     
     */
    public JAXBElement<ShippingOptions> getShippingOptions() {
        return shippingOptions;
    }

    /**
     * Sets the value of the shippingOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ShippingOptions }{@code >}
     *     
     */
    public void setShippingOptions(JAXBElement<ShippingOptions> value) {
        this.shippingOptions = ((JAXBElement<ShippingOptions> ) value);
    }

    /**
     * Gets the value of the creditCardPayment property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link CreditCard }{@code >}
     *     
     */
    public JAXBElement<CreditCard> getCreditCardPayment() {
        return creditCardPayment;
    }

    /**
     * Sets the value of the creditCardPayment property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link CreditCard }{@code >}
     *     
     */
    public void setCreditCardPayment(JAXBElement<CreditCard> value) {
        this.creditCardPayment = ((JAXBElement<CreditCard> ) value);
    }

    /**
     * Gets the value of the poNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPONumber() {
        return poNumber;
    }

    /**
     * Sets the value of the poNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPONumber(JAXBElement<String> value) {
        this.poNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the sapUser property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSapUser() {
        return sapUser;
    }

    /**
     * Sets the value of the sapUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSapUser(Boolean value) {
        this.sapUser = value;
    }

    /**
     * Gets the value of the punchOutSource property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPunchOutSource() {
        return punchOutSource;
    }

    /**
     * Sets the value of the punchOutSource property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPunchOutSource(JAXBElement<String> value) {
        this.punchOutSource = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the shoppingCartID property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getShoppingCartID() {
        return shoppingCartID;
    }

    /**
     * Sets the value of the shoppingCartID property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setShoppingCartID(JAXBElement<String> value) {
        this.shoppingCartID = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the user property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link User }{@code >}
     *     
     */
    public JAXBElement<User> getUser() {
        return user;
    }

    /**
     * Sets the value of the user property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link User }{@code >}
     *     
     */
    public void setUser(JAXBElement<User> value) {
        this.user = ((JAXBElement<User> ) value);
    }

    /**
     * Gets the value of the approveeSapContactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapContactNumber() {
        return approveeSapContactNumber;
    }

    /**
     * Sets the value of the approveeSapContactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapContactNumber(JAXBElement<String> value) {
        this.approveeSapContactNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the approveeSapCustomerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getApproveeSapCustomerNumber() {
        return approveeSapCustomerNumber;
    }

    /**
     * Sets the value of the approveeSapCustomerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setApproveeSapCustomerNumber(JAXBElement<String> value) {
        this.approveeSapCustomerNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the vatExemptionSelectedByUser property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isVATExemptionSelectedByUser() {
        return vatExemptionSelectedByUser;
    }

    /**
     * Sets the value of the vatExemptionSelectedByUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setVATExemptionSelectedByUser(Boolean value) {
        this.vatExemptionSelectedByUser = value;
    }

    /**
     * Gets the value of the isRunPipeline property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsRunPipeline() {
        return isRunPipeline;
    }

    /**
     * Sets the value of the isRunPipeline property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsRunPipeline(Boolean value) {
        this.isRunPipeline = value;
    }

    /**
     * Gets the value of the cartTotalExceed4000 property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCartTotalExceed4000() {
        return cartTotalExceed4000;
    }

    /**
     * Sets the value of the cartTotalExceed4000 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCartTotalExceed4000(Boolean value) {
        this.cartTotalExceed4000 = value;
    }

    /**
     * Gets the value of the deliveryBlockFor04IN property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeliveryBlockFor04IN() {
        return deliveryBlockFor04IN;
    }

    /**
     * Sets the value of the deliveryBlockFor04IN property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeliveryBlockFor04IN(Boolean value) {
        this.deliveryBlockFor04IN = value;
    }

    /**
     * Gets the value of the ma9Checked property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isMA9Checked() {
        return ma9Checked;
    }

    /**
     * Sets the value of the ma9Checked property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setMA9Checked(Boolean value) {
        this.ma9Checked = value;
    }

    /**
     * Gets the value of the quoteReference property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getQuoteReference() {
        return quoteReference;
    }

    /**
     * Sets the value of the quoteReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setQuoteReference(JAXBElement<String> value) {
        this.quoteReference = ((JAXBElement<String> ) value);
    }

}
