
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PromotionCodeRecord complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PromotionCodeRecord">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PromoApplied" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PromoCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PromoCodeReserved" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PromoCodeStatus" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}PromotionCodeStatus" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PromotionCodeRecord", propOrder = {
    "promoApplied",
    "promoCode",
    "promoCodeReserved",
    "promoCodeStatus"
})
public class PromotionCodeRecord {

    @XmlElement(name = "PromoApplied")
    protected Boolean promoApplied;
    @XmlElementRef(name = "PromoCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<String> promoCode;
    @XmlElement(name = "PromoCodeReserved")
    protected Boolean promoCodeReserved;
    @XmlElement(name = "PromoCodeStatus")
    protected PromotionCodeStatus promoCodeStatus;

    /**
     * Gets the value of the promoApplied property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPromoApplied() {
        return promoApplied;
    }

    /**
     * Sets the value of the promoApplied property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPromoApplied(Boolean value) {
        this.promoApplied = value;
    }

    /**
     * Gets the value of the promoCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPromoCode() {
        return promoCode;
    }

    /**
     * Sets the value of the promoCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPromoCode(JAXBElement<String> value) {
        this.promoCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the promoCodeReserved property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPromoCodeReserved() {
        return promoCodeReserved;
    }

    /**
     * Sets the value of the promoCodeReserved property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPromoCodeReserved(Boolean value) {
        this.promoCodeReserved = value;
    }

    /**
     * Gets the value of the promoCodeStatus property.
     * 
     * @return
     *     possible object is
     *     {@link PromotionCodeStatus }
     *     
     */
    public PromotionCodeStatus getPromoCodeStatus() {
        return promoCodeStatus;
    }

    /**
     * Sets the value of the promoCodeStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link PromotionCodeStatus }
     *     
     */
    public void setPromoCodeStatus(PromotionCodeStatus value) {
        this.promoCodeStatus = value;
    }

}
