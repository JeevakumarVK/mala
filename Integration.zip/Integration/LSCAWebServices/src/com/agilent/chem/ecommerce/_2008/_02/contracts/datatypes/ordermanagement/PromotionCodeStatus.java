
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PromotionCodeStatus.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PromotionCodeStatus">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="IdentityMismatch"/>
 *     &lt;enumeration value="Invalid"/>
 *     &lt;enumeration value="LimitReached"/>
 *     &lt;enumeration value="OK"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "PromotionCodeStatus")
@XmlEnum
public enum PromotionCodeStatus {

    @XmlEnumValue("IdentityMismatch")
    IDENTITY_MISMATCH("IdentityMismatch"),
    @XmlEnumValue("Invalid")
    INVALID("Invalid"),
    @XmlEnumValue("LimitReached")
    LIMIT_REACHED("LimitReached"),
    OK("OK");
    private final String value;

    PromotionCodeStatus(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PromotionCodeStatus fromValue(String v) {
        for (PromotionCodeStatus c: PromotionCodeStatus.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
