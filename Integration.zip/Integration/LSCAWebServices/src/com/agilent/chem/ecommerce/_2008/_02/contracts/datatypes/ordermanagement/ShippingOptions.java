
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for ShippingOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ShippingOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ShipOptions" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ShipOptions" minOccurs="0"/>
 *         &lt;element name="DeliveryOptions" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}DeliveryOptions" minOccurs="0"/>
 *         &lt;element name="DeliveryDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ShippingOptions", propOrder = {
    "shipOptions",
    "deliveryOptions",
    "deliveryDate"
})
public class ShippingOptions {

    @XmlElement(name = "ShipOptions")
    protected ShipOptions shipOptions;
    @XmlElement(name = "DeliveryOptions")
    protected DeliveryOptions deliveryOptions;
    @XmlElement(name = "DeliveryDate")
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar deliveryDate;

    /**
     * Gets the value of the shipOptions property.
     * 
     * @return
     *     possible object is
     *     {@link ShipOptions }
     *     
     */
    public ShipOptions getShipOptions() {
        return shipOptions;
    }

    /**
     * Sets the value of the shipOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ShipOptions }
     *     
     */
    public void setShipOptions(ShipOptions value) {
        this.shipOptions = value;
    }

    /**
     * Gets the value of the deliveryOptions property.
     * 
     * @return
     *     possible object is
     *     {@link DeliveryOptions }
     *     
     */
    public DeliveryOptions getDeliveryOptions() {
        return deliveryOptions;
    }

    /**
     * Sets the value of the deliveryOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeliveryOptions }
     *     
     */
    public void setDeliveryOptions(DeliveryOptions value) {
        this.deliveryOptions = value;
    }

    /**
     * Gets the value of the deliveryDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDeliveryDate() {
        return deliveryDate;
    }

    /**
     * Sets the value of the deliveryDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDeliveryDate(XMLGregorianCalendar value) {
        this.deliveryDate = value;
    }

}
