
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SpecialCaseType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="SpecialCaseType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="IsEmpty"/>
 *     &lt;enumeration value="EanNumber"/>
 *     &lt;enumeration value="MA9"/>
 *     &lt;enumeration value="PartialShipmentProduct"/>
 *     &lt;enumeration value="ExchangeProduct"/>
 *     &lt;enumeration value="EcdOrRadioActiveProduct"/>
 *     &lt;enumeration value="BlockOrder"/>
 *     &lt;enumeration value="VATExemption "/>
 *     &lt;enumeration value="JapanDropShipCondition3 "/>
 *     &lt;enumeration value="CartTotalExceed4000"/>
 *     &lt;enumeration value="DeliveryBlockFor04IN"/>
 *     &lt;enumeration value="QuoteReference"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "SpecialCaseType")
@XmlEnum
public enum SpecialCaseType {

    @XmlEnumValue("IsEmpty")
    IS_EMPTY("IsEmpty"),
    @XmlEnumValue("EanNumber")
    EAN_NUMBER("EanNumber"),
    @XmlEnumValue("MA9")
    MA_9("MA9"),
    @XmlEnumValue("PartialShipmentProduct")
    PARTIAL_SHIPMENT_PRODUCT("PartialShipmentProduct"),
    @XmlEnumValue("ExchangeProduct")
    EXCHANGE_PRODUCT("ExchangeProduct"),
    @XmlEnumValue("EcdOrRadioActiveProduct")
    ECD_OR_RADIO_ACTIVE_PRODUCT("EcdOrRadioActiveProduct"),
    @XmlEnumValue("BlockOrder")
    BLOCK_ORDER("BlockOrder"),
    @XmlEnumValue("VATExemption ")
    VAT_EXEMPTION("VATExemption "),
    @XmlEnumValue("JapanDropShipCondition3 ")
    JAPAN_DROP_SHIP_CONDITION_3("JapanDropShipCondition3 "),
    @XmlEnumValue("CartTotalExceed4000")
    CART_TOTAL_EXCEED_4000("CartTotalExceed4000"),
    @XmlEnumValue("DeliveryBlockFor04IN")
    DELIVERY_BLOCK_FOR_04_IN("DeliveryBlockFor04IN"),
    @XmlEnumValue("QuoteReference")
    QUOTE_REFERENCE("QuoteReference");
    private final String value;

    SpecialCaseType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static SpecialCaseType fromValue(String v) {
        for (SpecialCaseType c: SpecialCaseType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
