
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for WebOrderSearchCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WebOrderSearchCriteria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UnProcessedOrders" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TopNWebOrders" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="WebOrdersOn" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="SalesOrg" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WebOrderNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="WebOrderStartDateRange" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="WebOrderEndDateRange" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WebOrderSearchCriteria", propOrder = {
    "unProcessedOrders",
    "topNWebOrders",
    "webOrdersOn",
    "salesOrg",
    "webOrderNumber",
    "webOrderStartDateRange",
    "webOrderEndDateRange"
})
public class WebOrderSearchCriteria {

    @XmlElement(name = "UnProcessedOrders")
    protected boolean unProcessedOrders;
    @XmlElement(name = "TopNWebOrders")
    protected short topNWebOrders;
    @XmlElement(name = "WebOrdersOn", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar webOrdersOn;
    @XmlElement(name = "SalesOrg", required = true, nillable = true)
    protected String salesOrg;
    @XmlElement(name = "WebOrderNumber", required = true, nillable = true)
    protected String webOrderNumber;
    @XmlElement(name = "WebOrderStartDateRange", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar webOrderStartDateRange;
    @XmlElement(name = "WebOrderEndDateRange", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar webOrderEndDateRange;

    /**
     * Gets the value of the unProcessedOrders property.
     * 
     */
    public boolean isUnProcessedOrders() {
        return unProcessedOrders;
    }

    /**
     * Sets the value of the unProcessedOrders property.
     * 
     */
    public void setUnProcessedOrders(boolean value) {
        this.unProcessedOrders = value;
    }

    /**
     * Gets the value of the topNWebOrders property.
     * 
     */
    public short getTopNWebOrders() {
        return topNWebOrders;
    }

    /**
     * Sets the value of the topNWebOrders property.
     * 
     */
    public void setTopNWebOrders(short value) {
        this.topNWebOrders = value;
    }

    /**
     * Gets the value of the webOrdersOn property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getWebOrdersOn() {
        return webOrdersOn;
    }

    /**
     * Sets the value of the webOrdersOn property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setWebOrdersOn(XMLGregorianCalendar value) {
        this.webOrdersOn = value;
    }

    /**
     * Gets the value of the salesOrg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSalesOrg() {
        return salesOrg;
    }

    /**
     * Sets the value of the salesOrg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSalesOrg(String value) {
        this.salesOrg = value;
    }

    /**
     * Gets the value of the webOrderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getWebOrderNumber() {
        return webOrderNumber;
    }

    /**
     * Sets the value of the webOrderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setWebOrderNumber(String value) {
        this.webOrderNumber = value;
    }

    /**
     * Gets the value of the webOrderStartDateRange property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getWebOrderStartDateRange() {
        return webOrderStartDateRange;
    }

    /**
     * Sets the value of the webOrderStartDateRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setWebOrderStartDateRange(XMLGregorianCalendar value) {
        this.webOrderStartDateRange = value;
    }

    /**
     * Gets the value of the webOrderEndDateRange property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getWebOrderEndDateRange() {
        return webOrderEndDateRange;
    }

    /**
     * Sets the value of the webOrderEndDateRange property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setWebOrderEndDateRange(XMLGregorianCalendar value) {
        this.webOrderEndDateRange = value;
    }

}
