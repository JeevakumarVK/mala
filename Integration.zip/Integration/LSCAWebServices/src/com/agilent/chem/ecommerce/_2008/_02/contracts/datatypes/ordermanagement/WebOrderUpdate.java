
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for WebOrderUpdate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WebOrderUpdate">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="UserId" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid"/>
 *         &lt;element name="OrderGroupId" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid"/>
 *         &lt;element name="SapOrderNumber" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="OrderProcessedBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WebOrderUpdate", propOrder = {
    "userId",
    "orderGroupId",
    "sapOrderNumber",
    "orderProcessedBy"
})
public class WebOrderUpdate {

    @XmlElement(name = "UserId", required = true)
    protected String userId;
    @XmlElement(name = "OrderGroupId", required = true)
    protected String orderGroupId;
    @XmlElement(name = "SapOrderNumber", required = true, nillable = true)
    protected String sapOrderNumber;
    @XmlElement(name = "OrderProcessedBy", required = true, nillable = true)
    protected String orderProcessedBy;

    /**
     * Gets the value of the userId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets the value of the userId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserId(String value) {
        this.userId = value;
    }

    /**
     * Gets the value of the orderGroupId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderGroupId() {
        return orderGroupId;
    }

    /**
     * Sets the value of the orderGroupId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderGroupId(String value) {
        this.orderGroupId = value;
    }

    /**
     * Gets the value of the sapOrderNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSapOrderNumber() {
        return sapOrderNumber;
    }

    /**
     * Sets the value of the sapOrderNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSapOrderNumber(String value) {
        this.sapOrderNumber = value;
    }

    /**
     * Gets the value of the orderProcessedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderProcessedBy() {
        return orderProcessedBy;
    }

    /**
     * Sets the value of the orderProcessedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderProcessedBy(String value) {
        this.orderProcessedBy = value;
    }

}
