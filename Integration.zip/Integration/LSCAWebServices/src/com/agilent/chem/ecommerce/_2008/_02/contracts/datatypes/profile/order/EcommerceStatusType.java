
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for EcommerceStatusType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="EcommerceStatusType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="None"/>
 *     &lt;enumeration value="SAP"/>
 *     &lt;enumeration value="Web"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "EcommerceStatusType")
@XmlEnum
public enum EcommerceStatusType {

    @XmlEnumValue("None")
    NONE("None"),
    SAP("SAP"),
    @XmlEnumValue("Web")
    WEB("Web");
    private final String value;

    EcommerceStatusType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static EcommerceStatusType fromValue(String v) {
        for (EcommerceStatusType c: EcommerceStatusType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
