
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MemberTypes.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="MemberTypes">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="None"/>
 *     &lt;enumeration value="Member"/>
 *     &lt;enumeration value="Distributor"/>
 *     &lt;enumeration value="Customer"/>
 *     &lt;enumeration value="SalesRep"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "MemberTypes")
@XmlEnum
public enum MemberTypes {

    @XmlEnumValue("None")
    NONE("None"),
    @XmlEnumValue("Member")
    MEMBER("Member"),
    @XmlEnumValue("Distributor")
    DISTRIBUTOR("Distributor"),
    @XmlEnumValue("Customer")
    CUSTOMER("Customer"),
    @XmlEnumValue("SalesRep")
    SALES_REP("SalesRep");
    private final String value;

    MemberTypes(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static MemberTypes fromValue(String v) {
        for (MemberTypes c: MemberTypes.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
