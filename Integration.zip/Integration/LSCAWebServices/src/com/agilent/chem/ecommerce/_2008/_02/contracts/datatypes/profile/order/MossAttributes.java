
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for MossAttributes complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="MossAttributes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CanPlaceOrders" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanRecieveEmail" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanReceiveNewsletters" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanDownloadSoftware" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanScheduleOnlineService" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanBeRemembered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanAccessInformation" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanReceiveEnotes" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CanReceiveEnotesAsHTML" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="CommunitiesJoined" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="ProductsAndServicesInterests" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="LifeSciencesIndustryInterests" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="ChemicalIndustryInterests" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="InformationTypeInterests" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="ICPSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="BioAnalyzerSerialNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SalesOrganization" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MemberType" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile}MemberTypes" minOccurs="0"/>
 *         &lt;element name="SAPCustomerNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SAPContactNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CountryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CanApprove" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="EcommerceStatusType" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile}EcommerceStatusType" minOccurs="0"/>
 *         &lt;element name="Region" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ViewDutyFreeListPrice" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MossAttributes", propOrder = {
    "canPlaceOrders",
    "canRecieveEmail",
    "canReceiveNewsletters",
    "canDownloadSoftware",
    "canScheduleOnlineService",
    "canBeRemembered",
    "canAccessInformation",
    "canReceiveEnotes",
    "canReceiveEnotesAsHTML",
    "communitiesJoined",
    "productsAndServicesInterests",
    "lifeSciencesIndustryInterests",
    "chemicalIndustryInterests",
    "informationTypeInterests",
    "icpSerialNumber",
    "bioAnalyzerSerialNumber",
    "salesOrganization",
    "memberType",
    "sapCustomerNumber",
    "sapContactNumber",
    "countryCode",
    "canApprove",
    "ecommerceStatusType",
    "region",
    "viewDutyFreeListPrice"
})
public class MossAttributes {

    @XmlElement(name = "CanPlaceOrders")
    protected Boolean canPlaceOrders;
    @XmlElement(name = "CanRecieveEmail")
    protected Boolean canRecieveEmail;
    @XmlElement(name = "CanReceiveNewsletters")
    protected Boolean canReceiveNewsletters;
    @XmlElement(name = "CanDownloadSoftware")
    protected Boolean canDownloadSoftware;
    @XmlElement(name = "CanScheduleOnlineService")
    protected Boolean canScheduleOnlineService;
    @XmlElement(name = "CanBeRemembered")
    protected Boolean canBeRemembered;
    @XmlElement(name = "CanAccessInformation")
    protected Boolean canAccessInformation;
    @XmlElement(name = "CanReceiveEnotes")
    protected Boolean canReceiveEnotes;
    @XmlElement(name = "CanReceiveEnotesAsHTML")
    protected Boolean canReceiveEnotesAsHTML;
    @XmlElement(name = "CommunitiesJoined")
    protected Long communitiesJoined;
    @XmlElement(name = "ProductsAndServicesInterests")
    protected Long productsAndServicesInterests;
    @XmlElement(name = "LifeSciencesIndustryInterests")
    protected Long lifeSciencesIndustryInterests;
    @XmlElement(name = "ChemicalIndustryInterests")
    protected Long chemicalIndustryInterests;
    @XmlElement(name = "InformationTypeInterests")
    protected Long informationTypeInterests;
    @XmlElementRef(name = "ICPSerialNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> icpSerialNumber;
    @XmlElementRef(name = "BioAnalyzerSerialNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> bioAnalyzerSerialNumber;
    @XmlElementRef(name = "SalesOrganization", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> salesOrganization;
    @XmlElement(name = "MemberType")
    protected MemberTypes memberType;
    @XmlElementRef(name = "SAPCustomerNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> sapCustomerNumber;
    @XmlElementRef(name = "SAPContactNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> sapContactNumber;
    @XmlElementRef(name = "CountryCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> countryCode;
    @XmlElement(name = "CanApprove")
    protected Boolean canApprove;
    @XmlElement(name = "EcommerceStatusType")
    protected EcommerceStatusType ecommerceStatusType;
    @XmlElementRef(name = "Region", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> region;
    @XmlElement(name = "ViewDutyFreeListPrice")
    protected Boolean viewDutyFreeListPrice;

    /**
     * Gets the value of the canPlaceOrders property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanPlaceOrders() {
        return canPlaceOrders;
    }

    /**
     * Sets the value of the canPlaceOrders property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanPlaceOrders(Boolean value) {
        this.canPlaceOrders = value;
    }

    /**
     * Gets the value of the canRecieveEmail property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanRecieveEmail() {
        return canRecieveEmail;
    }

    /**
     * Sets the value of the canRecieveEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanRecieveEmail(Boolean value) {
        this.canRecieveEmail = value;
    }

    /**
     * Gets the value of the canReceiveNewsletters property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanReceiveNewsletters() {
        return canReceiveNewsletters;
    }

    /**
     * Sets the value of the canReceiveNewsletters property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanReceiveNewsletters(Boolean value) {
        this.canReceiveNewsletters = value;
    }

    /**
     * Gets the value of the canDownloadSoftware property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanDownloadSoftware() {
        return canDownloadSoftware;
    }

    /**
     * Sets the value of the canDownloadSoftware property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanDownloadSoftware(Boolean value) {
        this.canDownloadSoftware = value;
    }

    /**
     * Gets the value of the canScheduleOnlineService property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanScheduleOnlineService() {
        return canScheduleOnlineService;
    }

    /**
     * Sets the value of the canScheduleOnlineService property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanScheduleOnlineService(Boolean value) {
        this.canScheduleOnlineService = value;
    }

    /**
     * Gets the value of the canBeRemembered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanBeRemembered() {
        return canBeRemembered;
    }

    /**
     * Sets the value of the canBeRemembered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanBeRemembered(Boolean value) {
        this.canBeRemembered = value;
    }

    /**
     * Gets the value of the canAccessInformation property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanAccessInformation() {
        return canAccessInformation;
    }

    /**
     * Sets the value of the canAccessInformation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanAccessInformation(Boolean value) {
        this.canAccessInformation = value;
    }

    /**
     * Gets the value of the canReceiveEnotes property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanReceiveEnotes() {
        return canReceiveEnotes;
    }

    /**
     * Sets the value of the canReceiveEnotes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanReceiveEnotes(Boolean value) {
        this.canReceiveEnotes = value;
    }

    /**
     * Gets the value of the canReceiveEnotesAsHTML property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanReceiveEnotesAsHTML() {
        return canReceiveEnotesAsHTML;
    }

    /**
     * Sets the value of the canReceiveEnotesAsHTML property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanReceiveEnotesAsHTML(Boolean value) {
        this.canReceiveEnotesAsHTML = value;
    }

    /**
     * Gets the value of the communitiesJoined property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getCommunitiesJoined() {
        return communitiesJoined;
    }

    /**
     * Sets the value of the communitiesJoined property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setCommunitiesJoined(Long value) {
        this.communitiesJoined = value;
    }

    /**
     * Gets the value of the productsAndServicesInterests property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getProductsAndServicesInterests() {
        return productsAndServicesInterests;
    }

    /**
     * Sets the value of the productsAndServicesInterests property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setProductsAndServicesInterests(Long value) {
        this.productsAndServicesInterests = value;
    }

    /**
     * Gets the value of the lifeSciencesIndustryInterests property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getLifeSciencesIndustryInterests() {
        return lifeSciencesIndustryInterests;
    }

    /**
     * Sets the value of the lifeSciencesIndustryInterests property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setLifeSciencesIndustryInterests(Long value) {
        this.lifeSciencesIndustryInterests = value;
    }

    /**
     * Gets the value of the chemicalIndustryInterests property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getChemicalIndustryInterests() {
        return chemicalIndustryInterests;
    }

    /**
     * Sets the value of the chemicalIndustryInterests property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setChemicalIndustryInterests(Long value) {
        this.chemicalIndustryInterests = value;
    }

    /**
     * Gets the value of the informationTypeInterests property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getInformationTypeInterests() {
        return informationTypeInterests;
    }

    /**
     * Sets the value of the informationTypeInterests property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setInformationTypeInterests(Long value) {
        this.informationTypeInterests = value;
    }

    /**
     * Gets the value of the icpSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getICPSerialNumber() {
        return icpSerialNumber;
    }

    /**
     * Sets the value of the icpSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setICPSerialNumber(JAXBElement<String> value) {
        this.icpSerialNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the bioAnalyzerSerialNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getBioAnalyzerSerialNumber() {
        return bioAnalyzerSerialNumber;
    }

    /**
     * Sets the value of the bioAnalyzerSerialNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setBioAnalyzerSerialNumber(JAXBElement<String> value) {
        this.bioAnalyzerSerialNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the salesOrganization property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSalesOrganization() {
        return salesOrganization;
    }

    /**
     * Sets the value of the salesOrganization property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSalesOrganization(JAXBElement<String> value) {
        this.salesOrganization = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the memberType property.
     * 
     * @return
     *     possible object is
     *     {@link MemberTypes }
     *     
     */
    public MemberTypes getMemberType() {
        return memberType;
    }

    /**
     * Sets the value of the memberType property.
     * 
     * @param value
     *     allowed object is
     *     {@link MemberTypes }
     *     
     */
    public void setMemberType(MemberTypes value) {
        this.memberType = value;
    }

    /**
     * Gets the value of the sapCustomerNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSAPCustomerNumber() {
        return sapCustomerNumber;
    }

    /**
     * Sets the value of the sapCustomerNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSAPCustomerNumber(JAXBElement<String> value) {
        this.sapCustomerNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the sapContactNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSAPContactNumber() {
        return sapContactNumber;
    }

    /**
     * Sets the value of the sapContactNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSAPContactNumber(JAXBElement<String> value) {
        this.sapContactNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCountryCode() {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCountryCode(JAXBElement<String> value) {
        this.countryCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the canApprove property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCanApprove() {
        return canApprove;
    }

    /**
     * Sets the value of the canApprove property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCanApprove(Boolean value) {
        this.canApprove = value;
    }

    /**
     * Gets the value of the ecommerceStatusType property.
     * 
     * @return
     *     possible object is
     *     {@link EcommerceStatusType }
     *     
     */
    public EcommerceStatusType getEcommerceStatusType() {
        return ecommerceStatusType;
    }

    /**
     * Sets the value of the ecommerceStatusType property.
     * 
     * @param value
     *     allowed object is
     *     {@link EcommerceStatusType }
     *     
     */
    public void setEcommerceStatusType(EcommerceStatusType value) {
        this.ecommerceStatusType = value;
    }

    /**
     * Gets the value of the region property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getRegion() {
        return region;
    }

    /**
     * Sets the value of the region property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setRegion(JAXBElement<String> value) {
        this.region = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the viewDutyFreeListPrice property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isViewDutyFreeListPrice() {
        return viewDutyFreeListPrice;
    }

    /**
     * Sets the value of the viewDutyFreeListPrice property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setViewDutyFreeListPrice(Boolean value) {
        this.viewDutyFreeListPrice = value;
    }

}
