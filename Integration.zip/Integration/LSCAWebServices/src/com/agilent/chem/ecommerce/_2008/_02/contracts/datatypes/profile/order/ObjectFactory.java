
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EcommerceStatusType_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "EcommerceStatusType");
    private final static QName _ShippingContactInfo_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "ShippingContactInfo");
    private final static QName _MossAttributes_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "MossAttributes");
    private final static QName _User_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "User");
    private final static QName _MemberTypes_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "MemberTypes");
    private final static QName _ShippingContactInfoPerson_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "Person");
    private final static QName _ShippingContactInfoOrganization_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "Organization");
    private final static QName _ShippingContactInfoTelephone_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "Telephone");
    private final static QName _MossAttributesICPSerialNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "ICPSerialNumber");
    private final static QName _MossAttributesSAPCustomerNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "SAPCustomerNumber");
    private final static QName _MossAttributesBioAnalyzerSerialNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "BioAnalyzerSerialNumber");
    private final static QName _MossAttributesCountryCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "CountryCode");
    private final static QName _MossAttributesSalesOrganization_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "SalesOrganization");
    private final static QName _MossAttributesSAPContactNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "SAPContactNumber");
    private final static QName _MossAttributesRegion_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "Region");
    private final static QName _UserAddressLine1_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "AddressLine1");
    private final static QName _UserAddressLine2_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "AddressLine2");
    private final static QName _UserEmailAddress_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "EmailAddress");
    private final static QName _UserFirstName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "FirstName");
    private final static QName _UserState_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "State");
    private final static QName _UserFaxNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "FaxNumber");
    private final static QName _UserPostalCode_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "PostalCode");
    private final static QName _UserLastName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "LastName");
    private final static QName _UserCity_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "City");
    private final static QName _UserSelectedLocale_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "SelectedLocale");
    private final static QName _UserPhoneNumber_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "PhoneNumber");
    private final static QName _UserCompanyName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "CompanyName");
    private final static QName _UserLoginName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "LoginName");
    private final static QName _UserCommonName_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", "CommonName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ShippingContactInfo }
     * 
     */
    public ShippingContactInfo createShippingContactInfo() {
        return new ShippingContactInfo();
    }

    /**
     * Create an instance of {@link MossAttributes }
     * 
     */
    public MossAttributes createMossAttributes() {
        return new MossAttributes();
    }

    /**
     * Create an instance of {@link User }
     * 
     */
    public User createUser() {
        return new User();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EcommerceStatusType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "EcommerceStatusType")
    public JAXBElement<EcommerceStatusType> createEcommerceStatusType(EcommerceStatusType value) {
        return new JAXBElement<EcommerceStatusType>(_EcommerceStatusType_QNAME, EcommerceStatusType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ShippingContactInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "ShippingContactInfo")
    public JAXBElement<ShippingContactInfo> createShippingContactInfo(ShippingContactInfo value) {
        return new JAXBElement<ShippingContactInfo>(_ShippingContactInfo_QNAME, ShippingContactInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MossAttributes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "MossAttributes")
    public JAXBElement<MossAttributes> createMossAttributes(MossAttributes value) {
        return new JAXBElement<MossAttributes>(_MossAttributes_QNAME, MossAttributes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link User }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "User")
    public JAXBElement<User> createUser(User value) {
        return new JAXBElement<User>(_User_QNAME, User.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MemberTypes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "MemberTypes")
    public JAXBElement<MemberTypes> createMemberTypes(MemberTypes value) {
        return new JAXBElement<MemberTypes>(_MemberTypes_QNAME, MemberTypes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "Person", scope = ShippingContactInfo.class)
    public JAXBElement<String> createShippingContactInfoPerson(String value) {
        return new JAXBElement<String>(_ShippingContactInfoPerson_QNAME, String.class, ShippingContactInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "Organization", scope = ShippingContactInfo.class)
    public JAXBElement<String> createShippingContactInfoOrganization(String value) {
        return new JAXBElement<String>(_ShippingContactInfoOrganization_QNAME, String.class, ShippingContactInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "Telephone", scope = ShippingContactInfo.class)
    public JAXBElement<String> createShippingContactInfoTelephone(String value) {
        return new JAXBElement<String>(_ShippingContactInfoTelephone_QNAME, String.class, ShippingContactInfo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "ICPSerialNumber", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesICPSerialNumber(String value) {
        return new JAXBElement<String>(_MossAttributesICPSerialNumber_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "SAPCustomerNumber", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesSAPCustomerNumber(String value) {
        return new JAXBElement<String>(_MossAttributesSAPCustomerNumber_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "BioAnalyzerSerialNumber", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesBioAnalyzerSerialNumber(String value) {
        return new JAXBElement<String>(_MossAttributesBioAnalyzerSerialNumber_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "CountryCode", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesCountryCode(String value) {
        return new JAXBElement<String>(_MossAttributesCountryCode_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "SalesOrganization", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesSalesOrganization(String value) {
        return new JAXBElement<String>(_MossAttributesSalesOrganization_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "SAPContactNumber", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesSAPContactNumber(String value) {
        return new JAXBElement<String>(_MossAttributesSAPContactNumber_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "Region", scope = MossAttributes.class)
    public JAXBElement<String> createMossAttributesRegion(String value) {
        return new JAXBElement<String>(_MossAttributesRegion_QNAME, String.class, MossAttributes.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "AddressLine1", scope = User.class)
    public JAXBElement<String> createUserAddressLine1(String value) {
        return new JAXBElement<String>(_UserAddressLine1_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "AddressLine2", scope = User.class)
    public JAXBElement<String> createUserAddressLine2(String value) {
        return new JAXBElement<String>(_UserAddressLine2_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "EmailAddress", scope = User.class)
    public JAXBElement<String> createUserEmailAddress(String value) {
        return new JAXBElement<String>(_UserEmailAddress_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "FirstName", scope = User.class)
    public JAXBElement<String> createUserFirstName(String value) {
        return new JAXBElement<String>(_UserFirstName_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "State", scope = User.class)
    public JAXBElement<String> createUserState(String value) {
        return new JAXBElement<String>(_UserState_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "FaxNumber", scope = User.class)
    public JAXBElement<String> createUserFaxNumber(String value) {
        return new JAXBElement<String>(_UserFaxNumber_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "PostalCode", scope = User.class)
    public JAXBElement<String> createUserPostalCode(String value) {
        return new JAXBElement<String>(_UserPostalCode_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "LastName", scope = User.class)
    public JAXBElement<String> createUserLastName(String value) {
        return new JAXBElement<String>(_UserLastName_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "City", scope = User.class)
    public JAXBElement<String> createUserCity(String value) {
        return new JAXBElement<String>(_UserCity_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "SelectedLocale", scope = User.class)
    public JAXBElement<String> createUserSelectedLocale(String value) {
        return new JAXBElement<String>(_UserSelectedLocale_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MossAttributes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "MossAttributes", scope = User.class)
    public JAXBElement<MossAttributes> createUserMossAttributes(MossAttributes value) {
        return new JAXBElement<MossAttributes>(_MossAttributes_QNAME, MossAttributes.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "PhoneNumber", scope = User.class)
    public JAXBElement<String> createUserPhoneNumber(String value) {
        return new JAXBElement<String>(_UserPhoneNumber_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "CompanyName", scope = User.class)
    public JAXBElement<String> createUserCompanyName(String value) {
        return new JAXBElement<String>(_UserCompanyName_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "LoginName", scope = User.class)
    public JAXBElement<String> createUserLoginName(String value) {
        return new JAXBElement<String>(_UserLoginName_QNAME, String.class, User.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", name = "CommonName", scope = User.class)
    public JAXBElement<String> createUserCommonName(String value) {
        return new JAXBElement<String>(_UserCommonName_QNAME, String.class, User.class, value);
    }

}
