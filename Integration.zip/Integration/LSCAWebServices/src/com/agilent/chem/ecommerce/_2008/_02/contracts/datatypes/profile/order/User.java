
package com.agilent.chem.ecommerce._2008._02.contracts.datatypes.profile.order;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for User complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="User">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="LoginName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MossAttributes" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile}MossAttributes" minOccurs="0"/>
 *         &lt;element name="UserID" type="{http://schemas.microsoft.com/2003/10/Serialization/}guid" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToListPricing" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToYourPricing" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToAvailability" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToAddToCart" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToOrderStatus" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToCreateQuote" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsUserEntitledToViewQuote" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="FaxNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PhoneNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CompanyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddressLine1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="AddressLine2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EmailAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="City" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="State" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PostalCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="FirstName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CommonName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="LastName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="SelectedLocale" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IsPremiumCustomer" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsPremiumPlus" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="IsPunchoutUser" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "User", propOrder = {
    "loginName",
    "mossAttributes",
    "userID",
    "isUserEntitledToListPricing",
    "isUserEntitledToYourPricing",
    "isUserEntitledToAvailability",
    "isUserEntitledToAddToCart",
    "isUserEntitledToOrderStatus",
    "isUserEntitledToCreateQuote",
    "isUserEntitledToViewQuote",
    "faxNumber",
    "phoneNumber",
    "companyName",
    "addressLine1",
    "addressLine2",
    "emailAddress",
    "city",
    "state",
    "postalCode",
    "firstName",
    "commonName",
    "lastName",
    "selectedLocale",
    "isPremiumCustomer",
    "isPremiumPlus",
    "isPunchoutUser"
})
public class User {

    @XmlElementRef(name = "LoginName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> loginName;
    @XmlElementRef(name = "MossAttributes", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<MossAttributes> mossAttributes;
    @XmlElement(name = "UserID")
    protected String userID;
    @XmlElement(name = "IsUserEntitledToListPricing")
    protected Boolean isUserEntitledToListPricing;
    @XmlElement(name = "IsUserEntitledToYourPricing")
    protected Boolean isUserEntitledToYourPricing;
    @XmlElement(name = "IsUserEntitledToAvailability")
    protected Boolean isUserEntitledToAvailability;
    @XmlElement(name = "IsUserEntitledToAddToCart")
    protected Boolean isUserEntitledToAddToCart;
    @XmlElement(name = "IsUserEntitledToOrderStatus")
    protected Boolean isUserEntitledToOrderStatus;
    @XmlElement(name = "IsUserEntitledToCreateQuote")
    protected Boolean isUserEntitledToCreateQuote;
    @XmlElement(name = "IsUserEntitledToViewQuote")
    protected Boolean isUserEntitledToViewQuote;
    @XmlElementRef(name = "FaxNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> faxNumber;
    @XmlElementRef(name = "PhoneNumber", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> phoneNumber;
    @XmlElementRef(name = "CompanyName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> companyName;
    @XmlElementRef(name = "AddressLine1", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> addressLine1;
    @XmlElementRef(name = "AddressLine2", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> addressLine2;
    @XmlElementRef(name = "EmailAddress", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> emailAddress;
    @XmlElementRef(name = "City", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> city;
    @XmlElementRef(name = "State", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> state;
    @XmlElementRef(name = "PostalCode", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> postalCode;
    @XmlElementRef(name = "FirstName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> firstName;
    @XmlElementRef(name = "CommonName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> commonName;
    @XmlElementRef(name = "LastName", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> lastName;
    @XmlElementRef(name = "SelectedLocale", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Profile", type = JAXBElement.class)
    protected JAXBElement<String> selectedLocale;
    @XmlElement(name = "IsPremiumCustomer")
    protected Boolean isPremiumCustomer;
    @XmlElement(name = "IsPremiumPlus")
    protected Boolean isPremiumPlus;
    @XmlElement(name = "IsPunchoutUser")
    protected Boolean isPunchoutUser;

    /**
     * Gets the value of the loginName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLoginName() {
        return loginName;
    }

    /**
     * Sets the value of the loginName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLoginName(JAXBElement<String> value) {
        this.loginName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the mossAttributes property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link MossAttributes }{@code >}
     *     
     */
    public JAXBElement<MossAttributes> getMossAttributes() {
        return mossAttributes;
    }

    /**
     * Sets the value of the mossAttributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link MossAttributes }{@code >}
     *     
     */
    public void setMossAttributes(JAXBElement<MossAttributes> value) {
        this.mossAttributes = ((JAXBElement<MossAttributes> ) value);
    }

    /**
     * Gets the value of the userID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUserID() {
        return userID;
    }

    /**
     * Sets the value of the userID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUserID(String value) {
        this.userID = value;
    }

    /**
     * Gets the value of the isUserEntitledToListPricing property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToListPricing() {
        return isUserEntitledToListPricing;
    }

    /**
     * Sets the value of the isUserEntitledToListPricing property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToListPricing(Boolean value) {
        this.isUserEntitledToListPricing = value;
    }

    /**
     * Gets the value of the isUserEntitledToYourPricing property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToYourPricing() {
        return isUserEntitledToYourPricing;
    }

    /**
     * Sets the value of the isUserEntitledToYourPricing property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToYourPricing(Boolean value) {
        this.isUserEntitledToYourPricing = value;
    }

    /**
     * Gets the value of the isUserEntitledToAvailability property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToAvailability() {
        return isUserEntitledToAvailability;
    }

    /**
     * Sets the value of the isUserEntitledToAvailability property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToAvailability(Boolean value) {
        this.isUserEntitledToAvailability = value;
    }

    /**
     * Gets the value of the isUserEntitledToAddToCart property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToAddToCart() {
        return isUserEntitledToAddToCart;
    }

    /**
     * Sets the value of the isUserEntitledToAddToCart property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToAddToCart(Boolean value) {
        this.isUserEntitledToAddToCart = value;
    }

    /**
     * Gets the value of the isUserEntitledToOrderStatus property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToOrderStatus() {
        return isUserEntitledToOrderStatus;
    }

    /**
     * Sets the value of the isUserEntitledToOrderStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToOrderStatus(Boolean value) {
        this.isUserEntitledToOrderStatus = value;
    }

    /**
     * Gets the value of the isUserEntitledToCreateQuote property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToCreateQuote() {
        return isUserEntitledToCreateQuote;
    }

    /**
     * Sets the value of the isUserEntitledToCreateQuote property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToCreateQuote(Boolean value) {
        this.isUserEntitledToCreateQuote = value;
    }

    /**
     * Gets the value of the isUserEntitledToViewQuote property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsUserEntitledToViewQuote() {
        return isUserEntitledToViewQuote;
    }

    /**
     * Sets the value of the isUserEntitledToViewQuote property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsUserEntitledToViewQuote(Boolean value) {
        this.isUserEntitledToViewQuote = value;
    }

    /**
     * Gets the value of the faxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFaxNumber() {
        return faxNumber;
    }

    /**
     * Sets the value of the faxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFaxNumber(JAXBElement<String> value) {
        this.faxNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the phoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * Sets the value of the phoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPhoneNumber(JAXBElement<String> value) {
        this.phoneNumber = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the companyName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCompanyName() {
        return companyName;
    }

    /**
     * Sets the value of the companyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCompanyName(JAXBElement<String> value) {
        this.companyName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the addressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddressLine1() {
        return addressLine1;
    }

    /**
     * Sets the value of the addressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddressLine1(JAXBElement<String> value) {
        this.addressLine1 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the addressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getAddressLine2() {
        return addressLine2;
    }

    /**
     * Sets the value of the addressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setAddressLine2(JAXBElement<String> value) {
        this.addressLine2 = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the emailAddress property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getEmailAddress() {
        return emailAddress;
    }

    /**
     * Sets the value of the emailAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setEmailAddress(JAXBElement<String> value) {
        this.emailAddress = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the city property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCity() {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCity(JAXBElement<String> value) {
        this.city = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setState(JAXBElement<String> value) {
        this.state = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getPostalCode() {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setPostalCode(JAXBElement<String> value) {
        this.postalCode = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the firstName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getFirstName() {
        return firstName;
    }

    /**
     * Sets the value of the firstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setFirstName(JAXBElement<String> value) {
        this.firstName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the commonName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getCommonName() {
        return commonName;
    }

    /**
     * Sets the value of the commonName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setCommonName(JAXBElement<String> value) {
        this.commonName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the lastName property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getLastName() {
        return lastName;
    }

    /**
     * Sets the value of the lastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setLastName(JAXBElement<String> value) {
        this.lastName = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the selectedLocale property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public JAXBElement<String> getSelectedLocale() {
        return selectedLocale;
    }

    /**
     * Sets the value of the selectedLocale property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link String }{@code >}
     *     
     */
    public void setSelectedLocale(JAXBElement<String> value) {
        this.selectedLocale = ((JAXBElement<String> ) value);
    }

    /**
     * Gets the value of the isPremiumCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPremiumCustomer() {
        return isPremiumCustomer;
    }

    /**
     * Sets the value of the isPremiumCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPremiumCustomer(Boolean value) {
        this.isPremiumCustomer = value;
    }

    /**
     * Gets the value of the isPremiumPlus property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPremiumPlus() {
        return isPremiumPlus;
    }

    /**
     * Sets the value of the isPremiumPlus property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPremiumPlus(Boolean value) {
        this.isPremiumPlus = value;
    }

    /**
     * Gets the value of the isPunchoutUser property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsPunchoutUser() {
        return isPunchoutUser;
    }

    /**
     * Sets the value of the isPunchoutUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsPunchoutUser(Boolean value) {
        this.isPunchoutUser = value;
    }

}
