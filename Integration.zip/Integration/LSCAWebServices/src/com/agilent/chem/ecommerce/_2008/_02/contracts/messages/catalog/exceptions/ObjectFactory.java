
package com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.exceptions;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.exceptions.ProductNotFound;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.exceptions package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ProductNotFoundFaultMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog/Exceptions", "ProductNotFoundFaultMessage");
    private final static QName _ProductNotFoundFaultMessageProductNotFoundException_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog/Exceptions", "ProductNotFoundException");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.exceptions
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProductNotFoundFaultMessage }
     * 
     */
    public ProductNotFoundFaultMessage createProductNotFoundFaultMessage() {
        return new ProductNotFoundFaultMessage();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductNotFoundFaultMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog/Exceptions", name = "ProductNotFoundFaultMessage")
    public JAXBElement<ProductNotFoundFaultMessage> createProductNotFoundFaultMessage(ProductNotFoundFaultMessage value) {
        return new JAXBElement<ProductNotFoundFaultMessage>(_ProductNotFoundFaultMessage_QNAME, ProductNotFoundFaultMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductNotFound }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog/Exceptions", name = "ProductNotFoundException", scope = ProductNotFoundFaultMessage.class)
    public JAXBElement<ProductNotFound> createProductNotFoundFaultMessageProductNotFoundException(ProductNotFound value) {
        return new JAXBElement<ProductNotFound>(_ProductNotFoundFaultMessageProductNotFoundException_QNAME, ProductNotFound.class, ProductNotFoundFaultMessage.class, value);
    }

}
