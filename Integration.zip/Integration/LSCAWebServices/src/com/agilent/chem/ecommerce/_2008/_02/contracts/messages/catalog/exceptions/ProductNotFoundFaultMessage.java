
package com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.exceptions;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.exceptions.ProductNotFound;


/**
 * <p>Java class for ProductNotFoundFaultMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductNotFoundFaultMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ProductNotFoundException" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Catalog/Exceptions}ProductNotFound" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductNotFoundFaultMessage", propOrder = {
    "productNotFoundException"
})
public class ProductNotFoundFaultMessage {

    @XmlElementRef(name = "ProductNotFoundException", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog/Exceptions", type = JAXBElement.class)
    protected JAXBElement<ProductNotFound> productNotFoundException;

    /**
     * Gets the value of the productNotFoundException property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ProductNotFound }{@code >}
     *     
     */
    public JAXBElement<ProductNotFound> getProductNotFoundException() {
        return productNotFoundException;
    }

    /**
     * Sets the value of the productNotFoundException property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ProductNotFound }{@code >}
     *     
     */
    public void setProductNotFoundException(JAXBElement<ProductNotFound> value) {
        this.productNotFoundException = ((JAXBElement<ProductNotFound> ) value);
    }

}
