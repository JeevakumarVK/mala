
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.BasketCopyCriteria;


/**
 * <p>Java class for BasketCopyMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BasketCopyMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="BasketCopyCriteria" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}BasketCopyCriteria" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasketCopyMessage", propOrder = {
    "basketCopyCriteria"
})
public class BasketCopyMessage {

    @XmlElementRef(name = "BasketCopyCriteria", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<BasketCopyCriteria> basketCopyCriteria;

    /**
     * Gets the value of the basketCopyCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BasketCopyCriteria }{@code >}
     *     
     */
    public JAXBElement<BasketCopyCriteria> getBasketCopyCriteria() {
        return basketCopyCriteria;
    }

    /**
     * Sets the value of the basketCopyCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BasketCopyCriteria }{@code >}
     *     
     */
    public void setBasketCopyCriteria(JAXBElement<BasketCopyCriteria> value) {
        this.basketCopyCriteria = ((JAXBElement<BasketCopyCriteria> ) value);
    }

}
