
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfBasket;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.Basket;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.OrderSearchCriteria;


/**
 * <p>Java class for BasketMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BasketMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SearchCriteria" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}OrderSearchCriteria" minOccurs="0"/>
 *         &lt;element name="Basket" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}Basket" minOccurs="0"/>
 *         &lt;element name="BasketsForUser" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfBasket" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasketMessage", propOrder = {
    "searchCriteria",
    "basket",
    "basketsForUser"
})
public class BasketMessage {

    @XmlElementRef(name = "SearchCriteria", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<OrderSearchCriteria> searchCriteria;
    @XmlElementRef(name = "Basket", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<Basket> basket;
    @XmlElementRef(name = "BasketsForUser", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfBasket> basketsForUser;

    /**
     * Gets the value of the searchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}
     *     
     */
    public JAXBElement<OrderSearchCriteria> getSearchCriteria() {
        return searchCriteria;
    }

    /**
     * Sets the value of the searchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}
     *     
     */
    public void setSearchCriteria(JAXBElement<OrderSearchCriteria> value) {
        this.searchCriteria = ((JAXBElement<OrderSearchCriteria> ) value);
    }

    /**
     * Gets the value of the basket property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Basket }{@code >}
     *     
     */
    public JAXBElement<Basket> getBasket() {
        return basket;
    }

    /**
     * Sets the value of the basket property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Basket }{@code >}
     *     
     */
    public void setBasket(JAXBElement<Basket> value) {
        this.basket = ((JAXBElement<Basket> ) value);
    }

    /**
     * Gets the value of the basketsForUser property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBasket }{@code >}
     *     
     */
    public JAXBElement<ArrayOfBasket> getBasketsForUser() {
        return basketsForUser;
    }

    /**
     * Sets the value of the basketsForUser property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfBasket }{@code >}
     *     
     */
    public void setBasketsForUser(JAXBElement<ArrayOfBasket> value) {
        this.basketsForUser = ((JAXBElement<ArrayOfBasket> ) value);
    }

}
