
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfSpecialCase;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.OrderSearchCriteria;


/**
 * <p>Java class for BasketUpdateMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="BasketUpdateMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SearchCriteria" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}OrderSearchCriteria"/>
 *         &lt;element name="SpecialCases" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfSpecialCase"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "BasketUpdateMessage", propOrder = {
    "searchCriteria",
    "specialCases"
})
public class BasketUpdateMessage {

    @XmlElement(name = "SearchCriteria", required = true, nillable = true)
    protected OrderSearchCriteria searchCriteria;
    @XmlElement(name = "SpecialCases", required = true, nillable = true)
    protected ArrayOfSpecialCase specialCases;

    /**
     * Gets the value of the searchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link OrderSearchCriteria }
     *     
     */
    public OrderSearchCriteria getSearchCriteria() {
        return searchCriteria;
    }

    /**
     * Sets the value of the searchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderSearchCriteria }
     *     
     */
    public void setSearchCriteria(OrderSearchCriteria value) {
        this.searchCriteria = value;
    }

    /**
     * Gets the value of the specialCases property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfSpecialCase }
     *     
     */
    public ArrayOfSpecialCase getSpecialCases() {
        return specialCases;
    }

    /**
     * Sets the value of the specialCases property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfSpecialCase }
     *     
     */
    public void setSpecialCases(ArrayOfSpecialCase value) {
        this.specialCases = value;
    }

}
