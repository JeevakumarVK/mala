
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfBasket;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfWebOrderDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.Basket;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.BasketCopyCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.OrderSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.PurchaseOrder;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderDetails;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderUpdate;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _BasketUpdateMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "BasketUpdateMessage");
    private final static QName _BasketMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "BasketMessage");
    private final static QName _POMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "POMessage");
    private final static QName _WebOrderMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "WebOrderMessage");
    private final static QName _BasketCopyMessage_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "BasketCopyMessage");
    private final static QName _BasketCopyMessageBasketCopyCriteria_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "BasketCopyCriteria");
    private final static QName _BasketMessageBasketsForUser_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "BasketsForUser");
    private final static QName _BasketMessageBasket_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "Basket");
    private final static QName _BasketMessageSearchCriteria_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "SearchCriteria");
    private final static QName _WebOrderMessageWebOrdersList_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "WebOrdersList");
    private final static QName _WebOrderMessageWebOrderUpdate_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "WebOrderUpdate");
    private final static QName _WebOrderMessageWebOrderDetails_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "WebOrderDetails");
    private final static QName _POMessagePurchaseOrder_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", "PurchaseOrder");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link BasketUpdateMessage }
     * 
     */
    public BasketUpdateMessage createBasketUpdateMessage() {
        return new BasketUpdateMessage();
    }

    /**
     * Create an instance of {@link BasketCopyMessage }
     * 
     */
    public BasketCopyMessage createBasketCopyMessage() {
        return new BasketCopyMessage();
    }

    /**
     * Create an instance of {@link BasketMessage }
     * 
     */
    public BasketMessage createBasketMessage() {
        return new BasketMessage();
    }

    /**
     * Create an instance of {@link WebOrderMessage }
     * 
     */
    public WebOrderMessage createWebOrderMessage() {
        return new WebOrderMessage();
    }

    /**
     * Create an instance of {@link POMessage }
     * 
     */
    public POMessage createPOMessage() {
        return new POMessage();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "BasketUpdateMessage")
    public JAXBElement<BasketUpdateMessage> createBasketUpdateMessage(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_BasketUpdateMessage_QNAME, BasketUpdateMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "BasketMessage")
    public JAXBElement<BasketMessage> createBasketMessage(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_BasketMessage_QNAME, BasketMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link POMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "POMessage")
    public JAXBElement<POMessage> createPOMessage(POMessage value) {
        return new JAXBElement<POMessage>(_POMessage_QNAME, POMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "WebOrderMessage")
    public JAXBElement<WebOrderMessage> createWebOrderMessage(WebOrderMessage value) {
        return new JAXBElement<WebOrderMessage>(_WebOrderMessage_QNAME, WebOrderMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketCopyMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "BasketCopyMessage")
    public JAXBElement<BasketCopyMessage> createBasketCopyMessage(BasketCopyMessage value) {
        return new JAXBElement<BasketCopyMessage>(_BasketCopyMessage_QNAME, BasketCopyMessage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketCopyCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "BasketCopyCriteria", scope = BasketCopyMessage.class)
    public JAXBElement<BasketCopyCriteria> createBasketCopyMessageBasketCopyCriteria(BasketCopyCriteria value) {
        return new JAXBElement<BasketCopyCriteria>(_BasketCopyMessageBasketCopyCriteria_QNAME, BasketCopyCriteria.class, BasketCopyMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfBasket }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "BasketsForUser", scope = BasketMessage.class)
    public JAXBElement<ArrayOfBasket> createBasketMessageBasketsForUser(ArrayOfBasket value) {
        return new JAXBElement<ArrayOfBasket>(_BasketMessageBasketsForUser_QNAME, ArrayOfBasket.class, BasketMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Basket }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "Basket", scope = BasketMessage.class)
    public JAXBElement<Basket> createBasketMessageBasket(Basket value) {
        return new JAXBElement<Basket>(_BasketMessageBasket_QNAME, Basket.class, BasketMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "SearchCriteria", scope = BasketMessage.class)
    public JAXBElement<OrderSearchCriteria> createBasketMessageSearchCriteria(OrderSearchCriteria value) {
        return new JAXBElement<OrderSearchCriteria>(_BasketMessageSearchCriteria_QNAME, OrderSearchCriteria.class, BasketMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ArrayOfWebOrderDTO }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "WebOrdersList", scope = WebOrderMessage.class)
    public JAXBElement<ArrayOfWebOrderDTO> createWebOrderMessageWebOrdersList(ArrayOfWebOrderDTO value) {
        return new JAXBElement<ArrayOfWebOrderDTO>(_WebOrderMessageWebOrdersList_QNAME, ArrayOfWebOrderDTO.class, WebOrderMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderUpdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "WebOrderUpdate", scope = WebOrderMessage.class)
    public JAXBElement<WebOrderUpdate> createWebOrderMessageWebOrderUpdate(WebOrderUpdate value) {
        return new JAXBElement<WebOrderUpdate>(_WebOrderMessageWebOrderUpdate_QNAME, WebOrderUpdate.class, WebOrderMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderSearchCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "SearchCriteria", scope = WebOrderMessage.class)
    public JAXBElement<WebOrderSearchCriteria> createWebOrderMessageSearchCriteria(WebOrderSearchCriteria value) {
        return new JAXBElement<WebOrderSearchCriteria>(_BasketMessageSearchCriteria_QNAME, WebOrderSearchCriteria.class, WebOrderMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "WebOrderDetails", scope = WebOrderMessage.class)
    public JAXBElement<WebOrderDetails> createWebOrderMessageWebOrderDetails(WebOrderDetails value) {
        return new JAXBElement<WebOrderDetails>(_WebOrderMessageWebOrderDetails_QNAME, WebOrderDetails.class, WebOrderMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PurchaseOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "PurchaseOrder", scope = POMessage.class)
    public JAXBElement<PurchaseOrder> createPOMessagePurchaseOrder(PurchaseOrder value) {
        return new JAXBElement<PurchaseOrder>(_POMessagePurchaseOrder_QNAME, PurchaseOrder.class, POMessage.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", name = "SearchCriteria", scope = POMessage.class)
    public JAXBElement<OrderSearchCriteria> createPOMessageSearchCriteria(OrderSearchCriteria value) {
        return new JAXBElement<OrderSearchCriteria>(_BasketMessageSearchCriteria_QNAME, OrderSearchCriteria.class, POMessage.class, value);
    }

}
