
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfSpecialCase;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.OrderSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.PurchaseOrder;


/**
 * <p>Java class for POMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="POMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SearchCriteria" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}OrderSearchCriteria" minOccurs="0"/>
 *         &lt;element name="PurchaseOrder" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}PurchaseOrder" minOccurs="0"/>
 *         &lt;element name="SpecialCases" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfSpecialCase"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "POMessage", propOrder = {
    "searchCriteria",
    "purchaseOrder",
    "specialCases"
})
public class POMessage {

    @XmlElementRef(name = "SearchCriteria", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<OrderSearchCriteria> searchCriteria;
    @XmlElementRef(name = "PurchaseOrder", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<PurchaseOrder> purchaseOrder;
    @XmlElement(name = "SpecialCases", required = true, nillable = true)
    protected ArrayOfSpecialCase specialCases;

    /**
     * Gets the value of the searchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}
     *     
     */
    public JAXBElement<OrderSearchCriteria> getSearchCriteria() {
        return searchCriteria;
    }

    /**
     * Sets the value of the searchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link OrderSearchCriteria }{@code >}
     *     
     */
    public void setSearchCriteria(JAXBElement<OrderSearchCriteria> value) {
        this.searchCriteria = ((JAXBElement<OrderSearchCriteria> ) value);
    }

    /**
     * Gets the value of the purchaseOrder property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link PurchaseOrder }{@code >}
     *     
     */
    public JAXBElement<PurchaseOrder> getPurchaseOrder() {
        return purchaseOrder;
    }

    /**
     * Sets the value of the purchaseOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link PurchaseOrder }{@code >}
     *     
     */
    public void setPurchaseOrder(JAXBElement<PurchaseOrder> value) {
        this.purchaseOrder = ((JAXBElement<PurchaseOrder> ) value);
    }

    /**
     * Gets the value of the specialCases property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfSpecialCase }
     *     
     */
    public ArrayOfSpecialCase getSpecialCases() {
        return specialCases;
    }

    /**
     * Sets the value of the specialCases property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfSpecialCase }
     *     
     */
    public void setSpecialCases(ArrayOfSpecialCase value) {
        this.specialCases = value;
    }

}
