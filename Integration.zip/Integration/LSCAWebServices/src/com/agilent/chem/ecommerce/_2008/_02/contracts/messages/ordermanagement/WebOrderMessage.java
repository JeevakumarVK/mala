
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.ArrayOfWebOrderDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderDetails;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.WebOrderUpdate;


/**
 * <p>Java class for WebOrderMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="WebOrderMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SearchCriteria" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}WebOrderSearchCriteria" minOccurs="0"/>
 *         &lt;element name="WebOrderUpdate" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}WebOrderUpdate" minOccurs="0"/>
 *         &lt;element name="WebOrdersList" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}ArrayOfWebOrderDTO" minOccurs="0"/>
 *         &lt;element name="WebOrderDetails" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement}WebOrderDetails" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "WebOrderMessage", propOrder = {
    "searchCriteria",
    "webOrderUpdate",
    "webOrdersList",
    "webOrderDetails"
})
public class WebOrderMessage {

    @XmlElementRef(name = "SearchCriteria", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<WebOrderSearchCriteria> searchCriteria;
    @XmlElementRef(name = "WebOrderUpdate", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<WebOrderUpdate> webOrderUpdate;
    @XmlElementRef(name = "WebOrdersList", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<ArrayOfWebOrderDTO> webOrdersList;
    @XmlElementRef(name = "WebOrderDetails", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<WebOrderDetails> webOrderDetails;

    /**
     * Gets the value of the searchCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WebOrderSearchCriteria }{@code >}
     *     
     */
    public JAXBElement<WebOrderSearchCriteria> getSearchCriteria() {
        return searchCriteria;
    }

    /**
     * Sets the value of the searchCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WebOrderSearchCriteria }{@code >}
     *     
     */
    public void setSearchCriteria(JAXBElement<WebOrderSearchCriteria> value) {
        this.searchCriteria = ((JAXBElement<WebOrderSearchCriteria> ) value);
    }

    /**
     * Gets the value of the webOrderUpdate property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WebOrderUpdate }{@code >}
     *     
     */
    public JAXBElement<WebOrderUpdate> getWebOrderUpdate() {
        return webOrderUpdate;
    }

    /**
     * Sets the value of the webOrderUpdate property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WebOrderUpdate }{@code >}
     *     
     */
    public void setWebOrderUpdate(JAXBElement<WebOrderUpdate> value) {
        this.webOrderUpdate = ((JAXBElement<WebOrderUpdate> ) value);
    }

    /**
     * Gets the value of the webOrdersList property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWebOrderDTO }{@code >}
     *     
     */
    public JAXBElement<ArrayOfWebOrderDTO> getWebOrdersList() {
        return webOrdersList;
    }

    /**
     * Sets the value of the webOrdersList property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link ArrayOfWebOrderDTO }{@code >}
     *     
     */
    public void setWebOrdersList(JAXBElement<ArrayOfWebOrderDTO> value) {
        this.webOrdersList = ((JAXBElement<ArrayOfWebOrderDTO> ) value);
    }

    /**
     * Gets the value of the webOrderDetails property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link WebOrderDetails }{@code >}
     *     
     */
    public JAXBElement<WebOrderDetails> getWebOrderDetails() {
        return webOrderDetails;
    }

    /**
     * Sets the value of the webOrderDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link WebOrderDetails }{@code >}
     *     
     */
    public void setWebOrderDetails(JAXBElement<WebOrderDetails> value) {
        this.webOrderDetails = ((JAXBElement<WebOrderDetails> ) value);
    }

}
