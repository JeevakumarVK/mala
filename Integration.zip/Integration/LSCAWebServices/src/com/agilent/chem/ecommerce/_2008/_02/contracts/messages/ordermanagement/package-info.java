@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement;
