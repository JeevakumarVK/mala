
package com.agilent.chem.ecommerce._2008._02.contracts.services.ordermanagement;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AddItemsToCartResult" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "addItemsToCartResult"
})
@XmlRootElement(name = "AddItemsToCartResponse")
public class AddItemsToCartResponse {

    @XmlElement(name = "AddItemsToCartResult")
    protected Integer addItemsToCartResult;

    /**
     * Gets the value of the addItemsToCartResult property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAddItemsToCartResult() {
        return addItemsToCartResult;
    }

    /**
     * Sets the value of the addItemsToCartResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAddItemsToCartResult(Integer value) {
        this.addItemsToCartResult = value;
    }

}
