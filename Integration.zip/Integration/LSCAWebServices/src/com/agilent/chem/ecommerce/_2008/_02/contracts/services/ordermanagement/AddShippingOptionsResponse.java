
package com.agilent.chem.ecommerce._2008._02.contracts.services.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AddShippingOptionsResult" type="{http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/OrderManagement}BasketMessage" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "addShippingOptionsResult"
})
@XmlRootElement(name = "AddShippingOptionsResponse")
public class AddShippingOptionsResponse {

    @XmlElementRef(name = "AddShippingOptionsResult", namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", type = JAXBElement.class)
    protected JAXBElement<BasketMessage> addShippingOptionsResult;

    /**
     * Gets the value of the addShippingOptionsResult property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}
     *     
     */
    public JAXBElement<BasketMessage> getAddShippingOptionsResult() {
        return addShippingOptionsResult;
    }

    /**
     * Sets the value of the addShippingOptionsResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}
     *     
     */
    public void setAddShippingOptionsResult(JAXBElement<BasketMessage> value) {
        this.addShippingOptionsResult = ((JAXBElement<BasketMessage> ) value);
    }

}
