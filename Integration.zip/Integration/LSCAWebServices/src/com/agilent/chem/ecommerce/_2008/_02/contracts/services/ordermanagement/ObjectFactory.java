
package com.agilent.chem.ecommerce._2008._02.contracts.services.ordermanagement;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketCopyMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.POMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.WebOrderMessage;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.agilent.chem.ecommerce._2008._02.contracts.services.ordermanagement package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _UpdateSapOrderNumberRequest_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "request");
    private final static QName _CreateBasketResponseCreateBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "CreateBasketResult");
    private final static QName _ApplyPromotionPunchoutBasketResponseApplyPromotionPunchoutBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "ApplyPromotionPunchoutBasketResult");
    private final static QName _CopyBasketForApprovalResponseCopyBasketForApprovalResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "CopyBasketForApprovalResult");
    private final static QName _UpdateBasketResponseUpdateBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "UpdateBasketResult");
    private final static QName _GetBasketsForUserResponseGetBasketsForUserResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "GetBasketsForUserResult");
    private final static QName _GetWebOrdersResponseGetWebOrdersResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "GetWebOrdersResult");
    private final static QName _SaveBasketResponseSaveBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "SaveBasketResult");
    private final static QName _AddShippingOptionsResponseAddShippingOptionsResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "AddShippingOptionsResult");
    private final static QName _CheckoutResponseCheckoutResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "CheckoutResult");
    private final static QName _GetBasketResponseGetBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "GetBasketResult");
    private final static QName _AddAddressesResponseAddAddressesResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "AddAddressesResult");
    private final static QName _CalculateTotalResponseCalculateTotalResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "CalculateTotalResult");
    private final static QName _EmptyBasketResponseEmptyBasketResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "EmptyBasketResult");
    private final static QName _AddCreditCardResponseAddCreditCardResult_QNAME = new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", "AddCreditCardResult");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.agilent.chem.ecommerce._2008._02.contracts.services.ordermanagement
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateSapOrderNumber }
     * 
     */
    public UpdateSapOrderNumber createUpdateSapOrderNumber() {
        return new UpdateSapOrderNumber();
    }

    /**
     * Create an instance of {@link GetWebOrders }
     * 
     */
    public GetWebOrders createGetWebOrders() {
        return new GetWebOrders();
    }

    /**
     * Create an instance of {@link CreateBasketResponse }
     * 
     */
    public CreateBasketResponse createCreateBasketResponse() {
        return new CreateBasketResponse();
    }

    /**
     * Create an instance of {@link CopyBasketForApproval }
     * 
     */
    public CopyBasketForApproval createCopyBasketForApproval() {
        return new CopyBasketForApproval();
    }

    /**
     * Create an instance of {@link ApplyPromotionPunchoutBasketResponse }
     * 
     */
    public ApplyPromotionPunchoutBasketResponse createApplyPromotionPunchoutBasketResponse() {
        return new ApplyPromotionPunchoutBasketResponse();
    }

    /**
     * Create an instance of {@link CopyBasketForApprovalResponse }
     * 
     */
    public CopyBasketForApprovalResponse createCopyBasketForApprovalResponse() {
        return new CopyBasketForApprovalResponse();
    }

    /**
     * Create an instance of {@link UpdateSapOrderNumberResponse }
     * 
     */
    public UpdateSapOrderNumberResponse createUpdateSapOrderNumberResponse() {
        return new UpdateSapOrderNumberResponse();
    }

    /**
     * Create an instance of {@link UpdateBasketResponse }
     * 
     */
    public UpdateBasketResponse createUpdateBasketResponse() {
        return new UpdateBasketResponse();
    }

    /**
     * Create an instance of {@link GetBasketsForUserResponse }
     * 
     */
    public GetBasketsForUserResponse createGetBasketsForUserResponse() {
        return new GetBasketsForUserResponse();
    }

    /**
     * Create an instance of {@link GetBasketsForUser }
     * 
     */
    public GetBasketsForUser createGetBasketsForUser() {
        return new GetBasketsForUser();
    }

    /**
     * Create an instance of {@link GetBasket }
     * 
     */
    public GetBasket createGetBasket() {
        return new GetBasket();
    }

    /**
     * Create an instance of {@link AddAddresses }
     * 
     */
    public AddAddresses createAddAddresses() {
        return new AddAddresses();
    }

    /**
     * Create an instance of {@link AddShippingOptions }
     * 
     */
    public AddShippingOptions createAddShippingOptions() {
        return new AddShippingOptions();
    }

    /**
     * Create an instance of {@link GetWebOrdersResponse }
     * 
     */
    public GetWebOrdersResponse createGetWebOrdersResponse() {
        return new GetWebOrdersResponse();
    }

    /**
     * Create an instance of {@link DeleteBasketResponse }
     * 
     */
    public DeleteBasketResponse createDeleteBasketResponse() {
        return new DeleteBasketResponse();
    }

    /**
     * Create an instance of {@link ApplyPromotionPunchoutBasket }
     * 
     */
    public ApplyPromotionPunchoutBasket createApplyPromotionPunchoutBasket() {
        return new ApplyPromotionPunchoutBasket();
    }

    /**
     * Create an instance of {@link SaveBasket }
     * 
     */
    public SaveBasket createSaveBasket() {
        return new SaveBasket();
    }

    /**
     * Create an instance of {@link AddShippingOptionsResponse }
     * 
     */
    public AddShippingOptionsResponse createAddShippingOptionsResponse() {
        return new AddShippingOptionsResponse();
    }

    /**
     * Create an instance of {@link SaveBasketResponse }
     * 
     */
    public SaveBasketResponse createSaveBasketResponse() {
        return new SaveBasketResponse();
    }

    /**
     * Create an instance of {@link CheckoutResponse }
     * 
     */
    public CheckoutResponse createCheckoutResponse() {
        return new CheckoutResponse();
    }

    /**
     * Create an instance of {@link GetBasketResponse }
     * 
     */
    public GetBasketResponse createGetBasketResponse() {
        return new GetBasketResponse();
    }

    /**
     * Create an instance of {@link DeleteBasket }
     * 
     */
    public DeleteBasket createDeleteBasket() {
        return new DeleteBasket();
    }

    /**
     * Create an instance of {@link AddCreditCard }
     * 
     */
    public AddCreditCard createAddCreditCard() {
        return new AddCreditCard();
    }

    /**
     * Create an instance of {@link AddAddressesResponse }
     * 
     */
    public AddAddressesResponse createAddAddressesResponse() {
        return new AddAddressesResponse();
    }

    /**
     * Create an instance of {@link CreateBasket }
     * 
     */
    public CreateBasket createCreateBasket() {
        return new CreateBasket();
    }

    /**
     * Create an instance of {@link AddItemsToCart }
     * 
     */
    public AddItemsToCart createAddItemsToCart() {
        return new AddItemsToCart();
    }

    /**
     * Create an instance of {@link AddItemsToCartResponse }
     * 
     */
    public AddItemsToCartResponse createAddItemsToCartResponse() {
        return new AddItemsToCartResponse();
    }

    /**
     * Create an instance of {@link EmptyBasket }
     * 
     */
    public EmptyBasket createEmptyBasket() {
        return new EmptyBasket();
    }

    /**
     * Create an instance of {@link CalculateTotalResponse }
     * 
     */
    public CalculateTotalResponse createCalculateTotalResponse() {
        return new CalculateTotalResponse();
    }

    /**
     * Create an instance of {@link EmptyBasketResponse }
     * 
     */
    public EmptyBasketResponse createEmptyBasketResponse() {
        return new EmptyBasketResponse();
    }

    /**
     * Create an instance of {@link UpdateBasket }
     * 
     */
    public UpdateBasket createUpdateBasket() {
        return new UpdateBasket();
    }

    /**
     * Create an instance of {@link CalculateTotal }
     * 
     */
    public CalculateTotal createCalculateTotal() {
        return new CalculateTotal();
    }

    /**
     * Create an instance of {@link Checkout }
     * 
     */
    public Checkout createCheckout() {
        return new Checkout();
    }

    /**
     * Create an instance of {@link AddCreditCardResponse }
     * 
     */
    public AddCreditCardResponse createAddCreditCardResponse() {
        return new AddCreditCardResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = UpdateSapOrderNumber.class)
    public JAXBElement<WebOrderMessage> createUpdateSapOrderNumberRequest(WebOrderMessage value) {
        return new JAXBElement<WebOrderMessage>(_UpdateSapOrderNumberRequest_QNAME, WebOrderMessage.class, UpdateSapOrderNumber.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = GetWebOrders.class)
    public JAXBElement<WebOrderMessage> createGetWebOrdersRequest(WebOrderMessage value) {
        return new JAXBElement<WebOrderMessage>(_UpdateSapOrderNumberRequest_QNAME, WebOrderMessage.class, GetWebOrders.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "CreateBasketResult", scope = CreateBasketResponse.class)
    public JAXBElement<BasketMessage> createCreateBasketResponseCreateBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_CreateBasketResponseCreateBasketResult_QNAME, BasketMessage.class, CreateBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketCopyMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = CopyBasketForApproval.class)
    public JAXBElement<BasketCopyMessage> createCopyBasketForApprovalRequest(BasketCopyMessage value) {
        return new JAXBElement<BasketCopyMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketCopyMessage.class, CopyBasketForApproval.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "ApplyPromotionPunchoutBasketResult", scope = ApplyPromotionPunchoutBasketResponse.class)
    public JAXBElement<BasketMessage> createApplyPromotionPunchoutBasketResponseApplyPromotionPunchoutBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_ApplyPromotionPunchoutBasketResponseApplyPromotionPunchoutBasketResult_QNAME, BasketMessage.class, ApplyPromotionPunchoutBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "CopyBasketForApprovalResult", scope = CopyBasketForApprovalResponse.class)
    public JAXBElement<BasketMessage> createCopyBasketForApprovalResponseCopyBasketForApprovalResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_CopyBasketForApprovalResponseCopyBasketForApprovalResult_QNAME, BasketMessage.class, CopyBasketForApprovalResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "UpdateBasketResult", scope = UpdateBasketResponse.class)
    public JAXBElement<BasketMessage> createUpdateBasketResponseUpdateBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_UpdateBasketResponseUpdateBasketResult_QNAME, BasketMessage.class, UpdateBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "GetBasketsForUserResult", scope = GetBasketsForUserResponse.class)
    public JAXBElement<BasketMessage> createGetBasketsForUserResponseGetBasketsForUserResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_GetBasketsForUserResponseGetBasketsForUserResult_QNAME, BasketMessage.class, GetBasketsForUserResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = GetBasketsForUser.class)
    public JAXBElement<BasketMessage> createGetBasketsForUserRequest(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketMessage.class, GetBasketsForUser.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = GetBasket.class)
    public JAXBElement<BasketMessage> createGetBasketRequest(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketMessage.class, GetBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = AddAddresses.class)
    public JAXBElement<BasketUpdateMessage> createAddAddressesRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, AddAddresses.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link WebOrderMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "GetWebOrdersResult", scope = GetWebOrdersResponse.class)
    public JAXBElement<WebOrderMessage> createGetWebOrdersResponseGetWebOrdersResult(WebOrderMessage value) {
        return new JAXBElement<WebOrderMessage>(_GetWebOrdersResponseGetWebOrdersResult_QNAME, WebOrderMessage.class, GetWebOrdersResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = AddShippingOptions.class)
    public JAXBElement<BasketUpdateMessage> createAddShippingOptionsRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, AddShippingOptions.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link POMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = ApplyPromotionPunchoutBasket.class)
    public JAXBElement<POMessage> createApplyPromotionPunchoutBasketRequest(POMessage value) {
        return new JAXBElement<POMessage>(_UpdateSapOrderNumberRequest_QNAME, POMessage.class, ApplyPromotionPunchoutBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = SaveBasket.class)
    public JAXBElement<BasketUpdateMessage> createSaveBasketRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, SaveBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "SaveBasketResult", scope = SaveBasketResponse.class)
    public JAXBElement<BasketMessage> createSaveBasketResponseSaveBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_SaveBasketResponseSaveBasketResult_QNAME, BasketMessage.class, SaveBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "AddShippingOptionsResult", scope = AddShippingOptionsResponse.class)
    public JAXBElement<BasketMessage> createAddShippingOptionsResponseAddShippingOptionsResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_AddShippingOptionsResponseAddShippingOptionsResult_QNAME, BasketMessage.class, AddShippingOptionsResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link POMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "CheckoutResult", scope = CheckoutResponse.class)
    public JAXBElement<POMessage> createCheckoutResponseCheckoutResult(POMessage value) {
        return new JAXBElement<POMessage>(_CheckoutResponseCheckoutResult_QNAME, POMessage.class, CheckoutResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "GetBasketResult", scope = GetBasketResponse.class)
    public JAXBElement<BasketMessage> createGetBasketResponseGetBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_GetBasketResponseGetBasketResult_QNAME, BasketMessage.class, GetBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = DeleteBasket.class)
    public JAXBElement<BasketUpdateMessage> createDeleteBasketRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, DeleteBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = AddCreditCard.class)
    public JAXBElement<BasketUpdateMessage> createAddCreditCardRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, AddCreditCard.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "AddAddressesResult", scope = AddAddressesResponse.class)
    public JAXBElement<BasketMessage> createAddAddressesResponseAddAddressesResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_AddAddressesResponseAddAddressesResult_QNAME, BasketMessage.class, AddAddressesResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = CreateBasket.class)
    public JAXBElement<BasketMessage> createCreateBasketRequest(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketMessage.class, CreateBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = AddItemsToCart.class)
    public JAXBElement<BasketUpdateMessage> createAddItemsToCartRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, AddItemsToCart.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = EmptyBasket.class)
    public JAXBElement<BasketUpdateMessage> createEmptyBasketRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, EmptyBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "CalculateTotalResult", scope = CalculateTotalResponse.class)
    public JAXBElement<BasketMessage> createCalculateTotalResponseCalculateTotalResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_CalculateTotalResponseCalculateTotalResult_QNAME, BasketMessage.class, CalculateTotalResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "EmptyBasketResult", scope = EmptyBasketResponse.class)
    public JAXBElement<BasketMessage> createEmptyBasketResponseEmptyBasketResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_EmptyBasketResponseEmptyBasketResult_QNAME, BasketMessage.class, EmptyBasketResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = UpdateBasket.class)
    public JAXBElement<BasketUpdateMessage> createUpdateBasketRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, UpdateBasket.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = CalculateTotal.class)
    public JAXBElement<BasketUpdateMessage> createCalculateTotalRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, CalculateTotal.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketUpdateMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "request", scope = Checkout.class)
    public JAXBElement<BasketUpdateMessage> createCheckoutRequest(BasketUpdateMessage value) {
        return new JAXBElement<BasketUpdateMessage>(_UpdateSapOrderNumberRequest_QNAME, BasketUpdateMessage.class, Checkout.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BasketMessage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/OrderManagement", name = "AddCreditCardResult", scope = AddCreditCardResponse.class)
    public JAXBElement<BasketMessage> createAddCreditCardResponseAddCreditCardResult(BasketMessage value) {
        return new JAXBElement<BasketMessage>(_AddCreditCardResponseAddCreditCardResult_QNAME, BasketMessage.class, AddCreditCardResponse.class, value);
    }

}
