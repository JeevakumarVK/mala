
package com.agilent.chem.ecommerce.pricing;

import java.util.List;

public class PriceRequestVO {

    /**
     * Gets the value of partNumbers
     * 
     * @return returns the property partNumbers
     */
    public List<String> getPartNumbers() {
        return mPartNumbers;
    }

    /**
     * Sets the value of property partNumbers with value pPartNumbers
     * 
     * @param pPartNumbers
     *            the partNumbers to set
     */
    public void setPartNumbers( List<String> pPartNumbers) {
        mPartNumbers = pPartNumbers;
    }

    /**
     * Gets the value of salesOrg
     * 
     * @return returns the property salesOrg
     */
    public String getSalesOrg() {
        return mSalesOrg;
    }

    /**
     * Sets the value of property salesOrg with value pSalesOrg
     * 
     * @param pSalesOrg
     *            the salesOrg to set
     */
    public void setSalesOrg( String pSalesOrg) {
        mSalesOrg = pSalesOrg;
    }

    /**
     * Gets the value of yourPrice
     * 
     * @return returns the property yourPrice
     */
    public boolean isYourPrice() {
        return mYourPrice;
    }

    /**
     * Sets the value of property yourPrice with value pYourPrice
     * 
     * @param pYourPrice
     *            the yourPrice to set
     */
    public void setYourPrice( boolean pYourPrice) {
        mYourPrice = pYourPrice;
    }

    /**
     * Gets the value of siteId
     * 
     * @return returns the property siteId
     */
    public String getSiteId() {
        return mSiteId;
    }

    /**
     * Sets the value of property siteId with value pSiteId
     * 
     * @param pSiteId
     *            the siteId to set
     */
    public void setSiteId( String pSiteId) {
        mSiteId = pSiteId;
    }

    /**
     * Gets the value of sapContactNumber
     * 
     * @return returns the property sapContactNumber
     */
    public String getSapContactNumber() {
        return mSapContactNumber;
    }

    /**
     * Sets the value of property sapContactNumber with value pSapContactNumber
     * 
     * @param pSapContactNumber
     *            the sapContactNumber to set
     */
    public void setSapContactNumber( String pSapContactNumber) {
        mSapContactNumber = pSapContactNumber;
    }

    private List<String> mPartNumbers;
    private String       mSalesOrg;
    private boolean      mYourPrice;
    private String       mSiteId;
    private String       mSapContactNumber;

}
