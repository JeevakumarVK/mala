
package com.agilent.chem.ecommerce.pricing;

import java.util.List;

public class PriceResponseVO {

    List<PriceVO> mlistResposeVo;

    /**
     * Gets the value of mlistResposeVo
     * 
     * @return returns the property mlistResposeVo
     */
    public List<PriceVO> getListResposeVo() {
        return mlistResposeVo;
    }

    /**
     * Sets the value of property mlistResposeVo with value pMlistResposeVo
     * 
     * @param pMlistResposeVo
     *            the mlistResposeVo to set
     */
    public void setListResposeVo( List<PriceVO> pListResposeVo) {
        mlistResposeVo = pListResposeVo;
    }

}
