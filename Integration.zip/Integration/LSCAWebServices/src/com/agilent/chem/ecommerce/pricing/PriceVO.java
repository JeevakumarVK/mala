
package com.agilent.chem.ecommerce.pricing;

public class PriceVO {

    private Double mListPrice;

    /**
     * Gets the value of listPrice
     * 
     * @return returns the property listPrice
     */
    public Double getListPrice() {
        return mListPrice;
    }

    /**
     * Sets the value of property listPrice with value pListPrice
     * 
     * @param pListPrice
     *            the listPrice to set
     */
    public void setListPrice( Double pListPrice) {
        mListPrice = pListPrice;
    }

    /**
     * Gets the value of yourPrice
     * 
     * @return returns the property yourPrice
     */
    public Double getYourPrice() {
        return mYourPrice;
    }

    /**
     * Sets the value of property yourPrice with value pYourPrice
     * 
     * @param pYourPrice
     *            the yourPrice to set
     */
    public void setYourPrice( Double pYourPrice) {
        mYourPrice = pYourPrice;
    }

    /**
     * Gets the value of partNumber
     * 
     * @return returns the property partNumber
     */
    public String getPartNumber() {
        return mPartNumber;
    }

    /**
     * Sets the value of property partNumber with value pPartNumber
     * 
     * @param pPartNumber
     *            the partNumber to set
     */
    public void setPartNumber( String pPartNumber) {
        mPartNumber = pPartNumber;
    }

    private Double mYourPrice;
    private String mPartNumber;

}
