/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.utilities;

import java.util.logging.Logger;

import javax.xml.bind.JAXBElement;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS Utilities
 * </p>
 * 
 * @author Chitresh.Dayal
 * @project IntegrationLSCA
 * @updated DateTime: Sep 12, 2013 6:29:24 PM Author: Chitresh.Dayal
 */

public class CatalogUtils  {

    private final static Logger logger = Logger.getLogger(com.agilent.utilities.CatalogUtils.class.getName());

    public static String GetVirtualCatalogname( JAXBElement<String> SalesOrg, JAXBElement<String> CountryCode, boolean ShowDutyFreePrice) {
        /*try {

            String strCatalogName = "";
            String key = "";
            if ((ShowDutyFreePrice == true) && (CountryCode.trim() != null || !CountryCode.trim().isEmpty())) {
                key = SalesOrg + "_" + CountryCode + "_DF";
                // strCatalogName = System.Configuration.ConfigurationManager.AppSettings[key];
            }
            if ((CountryCode.trim() != null || !CountryCode.trim().isEmpty())) {
                SalesOrg = SalesOrg + "_" + CountryCode;
                // strCatalogName = System.Configuration.ConfigurationManager.AppSettings[SalesOrg];
            }
            if (strCatalogName.trim() == null || strCatalogName.trim().isEmpty()) {
                return "AgilentVirtual04US_US";
            } else {
                return strCatalogName;
            }
        } catch (Exception ex) {
            //logger.LogDebugInfo(ex.getMessage());
            return "AgilentVirtual04US_US";
        }*/
    	  return "AgilentVirtual04US_US";
    }

    public static String GetVirtualCatalogname( JAXBElement<String> SalesOrg, JAXBElement<String> CountryCode) {
        return GetVirtualCatalogname(SalesOrg, CountryCode, false);
    }
}
