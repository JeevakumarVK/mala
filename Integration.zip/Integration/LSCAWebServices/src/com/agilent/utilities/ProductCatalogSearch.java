/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.utilities;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.TransactionManager;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import atg.commerce.CommerceException;
import atg.commerce.order.CommerceItem;
import atg.commerce.order.CommerceItemImpl;
import atg.commerce.order.CommerceItemManager;
import atg.commerce.order.OrderManager;
import atg.commerce.order.OrderQueries;
import atg.commerce.order.ShippingGroup;
import atg.core.util.StringUtils;
import atg.dtm.TransactionDemarcation;
import atg.dtm.TransactionDemarcationException;
import atg.nucleus.GenericService;
import atg.nucleus.Nucleus;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.order.AgilentCommerceItem;
import com.agilent.base.commerce.order.AgilentConfigurableCommerceItem;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.commerce.services.AgilentPricingTools;
import com.agilent.base.common.services.SapManager;
import com.agilent.base.platform.CountryUtils;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ArrayOfFieldAndItemsCollectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ArrayOfFieldAndSelectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ArrayOfProductServiceProduct;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.FieldAndItemsCollectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.FieldAndSelectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductServiceCategory;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductServiceProduct;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductsSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.LineItem;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.ordermanagement.LineItemState;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage;
import com.degas.base.commerce.catalog.DakoProductUtilities;
import com.microsoft.schemas._2003._10.serialization.arrays.ArrayOfstring;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS ProductCatalogSearch
 * </p>
 * 
 * @author Chitresh.Dayal
 * @project IntegrationLSCA
 * @updated DateTime: Sep 13, 2013 1:43:57 PM Author: Chitresh.Dayal
 */

public class ProductCatalogSearch extends GenericService {

    private OrderManager        orderManager;
    private CommerceItemManager commerceItemManager;
    private AgilentCatalogTools catalogTools;
    private SapManager          sapManager;
    private TransactionManager  transactionManager;
    private OrderQueries        orderQueries;
    private String              catalogSiteId;
    private CountryUtils        countryUtils;
    private AgilentPricingTools pricingTools;
    private int	loopLimit;

    private DakoProductUtilities dakoProductUtilities;
    
    public DakoProductUtilities getDakoProductUtilities() {
		return dakoProductUtilities;
	}

	public void setDakoProductUtilities(DakoProductUtilities dakoProductUtilities) {
		this.dakoProductUtilities = dakoProductUtilities;
	}

    public AgilentPricingTools getPricingTools() {
		return pricingTools;
	}

	public void setPricingTools(AgilentPricingTools pPricingTools) {
		pricingTools = pPricingTools;
	}

	public OrderManager getOrderManager() {
        return orderManager;
    }

    public void setOrderManager( OrderManager orderManager) {
        this.orderManager = orderManager;
    }

    public CommerceItemManager getCommerceItemManager() {
        return commerceItemManager;
    }

    public void setCommerceItemManager( CommerceItemManager commerceItemManager) {
        this.commerceItemManager = commerceItemManager;
    }

    public AgilentCatalogTools getCatalogTools() {
        return catalogTools;
    }

    public void setCatalogTools( AgilentCatalogTools catalogTools) {
        this.catalogTools = catalogTools;
    }

    public SapManager getSapManager() {
        return sapManager;
    }

    public void setSapManager( SapManager sapManager) {
        this.sapManager = sapManager;
    }

    public TransactionManager getTransactionManager() {
        return transactionManager;
    }

    public void setTransactionManager( TransactionManager transactionManager) {
        this.transactionManager = transactionManager;
    }

    public OrderQueries getOrderQueries() {
        return orderQueries;
    }

    public void setOrderQueries( OrderQueries orderQueries) {
        this.orderQueries = orderQueries;
    }

    public String getCatalogSiteId() {
        return catalogSiteId;
    }

    public void setCatalogSiteId( String pCatalogIdSiteId) {
        catalogSiteId = pCatalogIdSiteId;
    }

    public CountryUtils getCountryUtils() {
        return countryUtils;
    }

    public void setCountryUtils( CountryUtils countryUtils) {
        this.countryUtils = countryUtils;
    }

    public JAXBElement<String> getJAXBElement( String data, String elementName) {
        JAXBElement<String> convertedData = new JAXBElement<String>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Catalog",
                elementName), String.class, data);
        return convertedData;
    }

    public JAXBElement<ArrayOfstring> getJAXBElement(ArrayOfstring data, String elementName) {
        JAXBElement<ArrayOfstring> convertedData = new JAXBElement<ArrayOfstring>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Catalog",
                elementName), ArrayOfstring.class, data);
        return convertedData;
    }

    @SuppressWarnings("unchecked")
    public List<RepositoryItem> getProductsForCategory( String catalogName, String categoryName, String searchClause, String language) {
    
    vlogDebug(".......................... Entered getProductsForCategory Method ......................");
     List<RepositoryItem> resultProducts = new ArrayList<RepositoryItem>();
     // if (searchClause == null || searchClause.trim().isEmpty()){
     categoryName=categoryName.replace("(Agilent)", "");
     
     vlogDebug(".......................... Category name after scripting (Agilent) : " + categoryName + "......................");
     Calendar cal = Calendar.getInstance();
     long StartTime=cal.getTimeInMillis();
     RepositoryItem category = getCatalogTools().getCategoryByName(categoryName, catalogName);
    
     vlogDebug(".......................... Return Category from method getCategoryByName() {0} ",category);
     if (category == null) {
           vlogDebug("category is Null so calling loop statement");
           int count=getLoopLimit();
           for(int i=1; i<=count;i++){
                  category = getCatalogTools().getCategoryByName(categoryName, catalogName);
                  if(category !=null)
                  {
                        vlogDebug("Number of Attempt taken : {0} ",i);
                        i=count;
                  }
                  else
                  {
                        vlogDebug("Category coming empty in attempt: {0} ",i);
                        
                  }
                  
           }
           
           
           if(category == null){
                  vlogDebug("category is Null after loop statement ");
                  return null;
           }
           else
           {
                   long endTime=cal.getTimeInMillis();
              long difference=endTime-StartTime;
                  vlogDebug("Time Taken by RQL in  millisecond  with Retry Attempt {0} ", difference);
           }
     }
     else
     {
            vlogDebug("without Retry Attempt category result came ");
            long endTime=cal.getTimeInMillis();
          long difference=endTime-StartTime;
       
           vlogDebug("Time Taken by RQL in  millisecond without Retry Attempt {0} ", difference);
     }
     vlogDebug(".......................... Category  repository Id from ATG: " + category.getRepositoryId() + "......................");
     
     List<RepositoryItem> products = (List<RepositoryItem>) category.getPropertyValue("childProducts");
     // get first category having products
     if (products == null || products.size() == 0) {
           vlogInfo("--------------------Either products is null Or size is zero ------------------");
         return null;
     }
     
     
     // add list of active products of category
     for ( RepositoryItem product : products) {
         String pDescription = (String) product.getPropertyValue("description");
         List<RepositoryItem> skus = (List<RepositoryItem>) product.getPropertyValue("childSKUs");
         if (skus != null && skus.size() > 0) {
             Boolean activeSku = (Boolean) skus.get(0).getPropertyValue("forSaleOnWeb");
             if (activeSku != null && activeSku) {
                 if (pDescription != null && !pDescription.trim().isEmpty()) {
                    // product=GetProduct(catalogName, product.ProductId,
                     // language, pdtConfig);
              //  vlogDebug(".......................... Child skus of product Id in ATG: " + products + "......................");
                     resultProducts.add(product);
                 } else {
                     // product=GetProduct(catalogName, product.ProductId,
                     // "en_US", pdtConfig);
                     resultProducts.add(product);
                 }
             }
         }

     }
     vlogDebug("Length of resultProducts ::----{0}", resultProducts.size());
     return resultProducts;

        // }
        // return null;
        // to do for search Clause

        // CategoryConfiguration catConfig =
        // dsHelper.CategoryConfigurationFilter();
        // ProductConfiguration pdtConfig =
        // dsHelper.ProductConfigurationFilter();

        /*
         * if (searchClause.trim() == null || searchClause.trim().isEmpty()){ Repository catalog= aCatalogTools.getCatalog(catalogName,language); category=
         * getCategory(categoryName,catConfig); for ( RepositoryItem cProduct : category.getChildProducts()) { if (cProduct.getDescription() != null &&
         * cProduct.getDescription().toString().trim() != "") { product=GetProduct(catalogName, product.ProductId, language, pdtConfig); products.add(product);
         * }else{ product=GetProduct(catalogName, product.ProductId, "en-US", pdtConfig); products.add(product); } } return products; }
         */

        /*
         * CatalogItemsDataSet ds; SpecificationSearch search; search = CommerceServerContext.CatalogContext.GetCatalog(catalogName,
         * language).BeginSpecificationSearch(categoryName); if (searchClause != null || !searchClause.isEmpty()) { String[] searchClauses =
         * searchClause.split("|"); for ( String searchClause : searchClauses) { // search.AddSearchClause(clause); } } search.SearchOptions.ClassTypes =
         * CatalogClassTypes.ProductClass | CatalogClassTypes.ProductFamilyClass | CatalogClassTypes.ProductFamilyForVariantsClass |
         * CatalogClassTypes.ProductVariantClass | CatalogClassTypes.ProductVariantsForFamilyClass; ds = search.Search(); foreach
         * (CatalogItemsDataSet.CatalogItem cProduct in ds.CatalogItems) { if (cProduct.getDescription() != null && cProduct.getDescription().toString().trim()
         * != "") { product=GetProduct(catalogName, product.ProductId, language, pdtConfig); products.add(product); }else{ product=GetProduct(catalogName,
         * product.ProductId, "en-US", pdtConfig); products.add(product); } } return products;
         */
    }

    public ArrayOfFieldAndItemsCollectionDTO getAllFieldAndItemsCollection( ArrayOfProductServiceProduct aProduct,
            List<FieldAndSelectionDTO> fieldAndSelectionList) {
    	vlogDebug("Inside getAllFieldAndItemsCollection");
        ArrayOfFieldAndItemsCollectionDTO fieldAndItemsCollectionList = new ArrayOfFieldAndItemsCollectionDTO();
        for ( FieldAndSelectionDTO item : fieldAndSelectionList) {
            FieldAndItemsCollectionDTO temp = new FieldAndItemsCollectionDTO();
            temp.setFieldName(item.getFieldName());
            ArrayOfstring fieldItemsList = new ArrayOfstring();

            for ( ProductServiceProduct a : aProduct.getProductServiceProduct()) {
                if (temp.getFieldName().getValue().equals("FieldAValue")) {
                    if (a.getFieldA().getValue() != null && !fieldItemsList.getString().contains(a.getFieldA().getValue()))
                        fieldItemsList.getString().add(a.getFieldA().getValue());
                } else if (temp.getFieldName().getValue().equals("FieldBValue")) {
                    if (a.getFieldB().getValue() != null && !fieldItemsList.getString().contains(a.getFieldB().getValue()))
                        fieldItemsList.getString().add(a.getFieldB().getValue());
                } else if (temp.getFieldName().getValue().equals("FieldCValue")) {
                    if (a.getFieldC().getValue() != null && !fieldItemsList.getString().contains(a.getFieldC().getValue()))
                        fieldItemsList.getString().add(a.getFieldC().getValue());
                } else if (temp.getFieldName().getValue().equals("FieldDValue")) {
                    if (a.getFieldD().getValue() != null && !fieldItemsList.getString().contains(a.getFieldD().getValue()))
                        fieldItemsList.getString().add(a.getFieldD().getValue());
                } else if (temp.getFieldName().getValue().equals("FieldEValue")) {
                    if (a.getFieldE().getValue() != null && !fieldItemsList.getString().contains(a.getFieldE().getValue()))
                        fieldItemsList.getString().add(a.getFieldE().getValue());
                }
            }
            Collections.sort(fieldItemsList.getString());
            JAXBElement<ArrayOfstring> jFieldItemsList = new JAXBElement<ArrayOfstring>(new QName(
                    "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Catalog", "fieldItemsList"), ArrayOfstring.class, fieldItemsList);
            temp.setFieldItemsList(jFieldItemsList);
            fieldAndItemsCollectionList.getFieldAndItemsCollectionDTO().add(temp);
        }
        return fieldAndItemsCollectionList;
    }

    @SuppressWarnings("unchecked")
	public ArrayOfProductServiceProduct getProducts( ProductsSearchCriteria pSearchCriteria) {
    	
    	
	    	vlogDebug(".......................... Inside getProducts of Buy Tab ...........................");
	        String salesOrg = pSearchCriteria.getSalesOrg().getValue();
	        if(salesOrg==null || salesOrg.isEmpty())
	        	salesOrg="04US";
	        
	        vlogDebug(".......................... salesOrg fetched : " + salesOrg + "......................");
	        String categoryName = pSearchCriteria.getCategory().getValue();
	        vlogDebug(".......................... categoryName from pSearchCriteria : " + categoryName + "......................");
	        String language = pSearchCriteria.getLanguage().getValue();// "en_US";//
	        
	        vlogDebug(".......................... language from pSearchCriteria : " + language + "......................");
	        
	        RepositoryItem catalogItem = null;
	        String catalogId = null;
	
	        catalogItem = getCatalogTools().getCatalogItemBySiteId(getCatalogSiteId());
	        
	       
	        if (catalogItem != null) {
	            catalogId = catalogItem.getRepositoryId();
	            vlogDebug(".......................... catalogItem  : " + catalogItem.getItemDisplayName() + "......................");
	            vlogDebug(".......................... catalogId  : " + catalogId + "......................");
	        }
	
	        vlogDebug(".......................... Entering getProductsforCategory method ......................");
	        List<RepositoryItem> products = getProductsForCategory(catalogId, categoryName, "", language);
	        int prdCount=0;
	        if(products !=null)
	        	prdCount=products.size();
	        
	        vlogDebug(".......................... product count from getProductsforCategory method -{0}",prdCount);
	        vlogDebug(".......................... leaving getProductsforCategory method ......................");
	
	        ArrayOfProductServiceProduct aProduct = new ArrayOfProductServiceProduct();
	        try{
		        if (products != null && products.size() > 0) {
		        	RepositoryItem priceList=getCatalogTools().getPriceListItem(salesOrg,getCatalogSiteId());
		        	 if(priceList!=null)
		        		 vlogDebug(".......................... Price list coming from method getPriceListItem {0} ",priceList);
		        	 else
		          vlogDebug("..........................Empty Price list coming from method getPriceListItem ");
		        	 
		        	 
		        	Map<String, RepositoryItem> productPrice=getPricingTools().priceAllProducts(priceList, products);
		        	if(productPrice!=null)
		        	{
		        		 vlogDebug(".........................Size Map of productPrice  {0}... ",productPrice.size());
		        	}
		        	else{
		        		
		        		 vlogDebug(".........................Return Map of productPrice is null... ");
		        	}
		        	
			        if(productPrice!=null){
			            for ( RepositoryItem product : products) {
			                ProductServiceProduct productBean = new ProductServiceProduct();
			                List<RepositoryItem> skus = (List<RepositoryItem>) product.getPropertyValue("childSKUs");
			                RepositoryItem prdTrnanslate=null;
			                Map<String, RepositoryItem> prdtranslationMap = (Map<String, RepositoryItem>) product.getPropertyValue("translations");
			                
			                if(prdtranslationMap != null){
				                prdTrnanslate = prdtranslationMap.get(language);
				                if (prdTrnanslate == null) {
				                	prdTrnanslate = product;
				                }
			                }else
			                	prdTrnanslate = product;
			                
			                if (skus != null && skus.size() > 0) {
			                    RepositoryItem sku = skus.get(0);
			                	 //Degas Changes Start
			                	String userCountry = pSearchCriteria.getCountryCode().getValue();
				                	//Degas CR008 changes - starts
				                	if(StringUtils.isEmpty(userCountry)){
				                		vlogDebug("Skipping Country based product Entitlement as country is empty. Class:{0}",getClass().toString());
				                	}else if(getDakoProductUtilities().isMedicalDeviceFlag(sku) && !getDakoProductUtilities().isCountryAvailabletWithinValidDateNormal(sku, userCountry)){
			                		continue;
			                	}
				                	//Degas CR008 changes - ends
			                	 //Degas Changes End
			                    RepositoryItem skuTranslate=null;
			                    Map<String, RepositoryItem> skuTranslationMap = (Map<String, RepositoryItem>) sku.getPropertyValue("translations");
			                    
			                    if(skuTranslationMap != null){
			                    	skuTranslate = skuTranslationMap.get(language);
					                if (skuTranslate == null) {
					                	skuTranslate = sku;
					                }
				                }else{
				                	skuTranslate = sku;
			                    }
			                   
			                    productBean.setDescription(getJAXBElement((String) prdTrnanslate.getPropertyValue("description"), "Description"));
			                    productBean.setDisplayName(getJAXBElement((String) skuTranslate.getPropertyValue("displayName"), "DisplayName"));
			                    productBean.setFieldA(getJAXBElement((String) product.getPropertyValue("fieldA"), "FieldA"));
			                    productBean.setFieldB(getJAXBElement((String) product.getPropertyValue("fieldB"), "FieldB"));
			                    productBean.setFieldC(getJAXBElement((String) product.getPropertyValue("fieldC"), "FieldC"));
			                    productBean.setFieldD(getJAXBElement((String) product.getPropertyValue("fieldD"), "FieldD"));
			                    productBean.setFieldE(getJAXBElement((String) product.getPropertyValue("fieldE"), "FieldE"));
			                    productBean.setImageFileName(getJAXBElement((String) sku.getPropertyValue("productImageURL"), "ImageFileName"));
			                    productBean.setLongDescription(getJAXBElement((String) prdTrnanslate.getPropertyValue("longDescription"), "LongDescription"));
			                    productBean.setProductID(getJAXBElement((String) sku.getPropertyValue("catalogId"), "ProductID"));
			                    productBean.setProductLine(getJAXBElement((String) sku.getPropertyValue("productLine"), "ProductLine"));
			                    productBean.setAmount(getJAXBElement((String) sku.getPropertyValue("catalogAmount"), "Amount"));
				                productBean.setUnit(getJAXBElement((String) skuTranslate.getPropertyValue("unit"), "Unit"));
				                productBean.setCurrency(getJAXBElement(getCountryUtils().getSalesOrgCurrencyCodeMap().get(salesOrg), "Currency"));
				                //Fix for the ticket APP-359
				                productBean.setUNSPSC(getJAXBElement((String) product.getPropertyValue("UNSPSC"), "UNSPSC"));
			                    //APP-6424 Starts
				                if(prdTrnanslate.getPropertyValue("description")==null)
			                    {
			                    	productBean.setDescription(getJAXBElement((String) product.getPropertyValue("description"), "Description"));
			                    }
			                    if(prdTrnanslate.getPropertyValue("longDescription")==null)
			                    {
			                    	productBean.setLongDescription(getJAXBElement((String) product.getPropertyValue("longDescription"), "LongDescription"));
			                    }
			                    //APP-6424 Ends
                                //Degas Changes Start
			                	productBean.setRegulatoryStatus(getJAXBElement(getDakoProductUtilities().getCountryBasedRegulatoryStatus(sku, userCountry), "RegulatoryStatus"));
			                	ArrayOfstring specificationSheetArray = null;
			                	List<String> specificationSheetIDList = (List<String>) sku.getPropertyValue("specificationSheetID");
				                if(specificationSheetIDList != null && !specificationSheetIDList.isEmpty()){
				                	specificationSheetArray = new ArrayOfstring();
				                	for(String specificationSheetID : specificationSheetIDList){
				                		specificationSheetArray.getString().add(specificationSheetID);
				                	}
				                	 vlogDebug("Specification Sheet URL List :: {0} ", specificationSheetArray);
				                }
				                productBean.setSpecificationSheetURL(getJAXBElement((ArrayOfstring) specificationSheetArray , "SpecificationSheetURL"));
				                //Degas Changes End
			                	RepositoryItem repositoryItem = productPrice.get(sku.getRepositoryId());
			                	
			                	 Double propertyPriceValue =0.0;
			                	 String productLine="";
			                	 String partNumber="";
			                	 Map<String, Object> params = new HashMap<String, Object>();
			                	if(repositoryItem!=null){
			                		propertyPriceValue=(Double) repositoryItem.getPropertyValue("listPrice");
			                		productLine=(String) sku.getPropertyValue("productLine");
			                		partNumber=(String) sku.getPropertyValue("catalogId");
			                		params.put("productLine", productLine);
		                            params.put("partNumber", partNumber);
			                	}
			                	propertyPriceValue = getPricingTools().computeTaxedPrice(propertyPriceValue, userCountry, params);
			                    productBean.setListPrice(BigDecimal.valueOf(propertyPriceValue));
			                   if(propertyPriceValue!=0.0){
			                	  aProduct.getProductServiceProduct().add(productBean);
			                       vlogDebug(".......................... propertyPriceValue is  {0} and added into aProduct Array...................... " + propertyPriceValue);
			                   }
			                   else
			                   {
			                	   vlogDebug(".......................... propertyPriceValue is zero not added into aProduct Array...................... ");
			                   }
			                    // productBean.setCurrency(getJAXBElement((String)
			                    // sku.getPropertyValue("currency")));
			                   
			                }
			
			            }
			        }
		        }else{
		        vlogDebug(".......................... Either aProduct is Empty or Null ...................... ");
		        }
	        
    	}catch(Exception e){
    		vlogError("exception " + e);
    		
    	}
	        return aProduct;
    }

    public ArrayOfFieldAndItemsCollectionDTO getSpecificFieldAndItemsCollection( ProductsSearchCriteria pSearchCriteria,
            ArrayOfFieldAndSelectionDTO fieldAndSelectionList, String pExcludedFilterName) throws RepositoryException {
    	vlogDebug("Inside getSpecificFieldAndItemsCollection");
        RepositoryItem catalogItem = null;
        String catalogId = null;

        catalogItem = getCatalogTools().getCatalogItemBySiteId(getCatalogSiteId());
        if (catalogItem != null) {
            catalogId = catalogItem.getRepositoryId();
        }

        String categoryName = pSearchCriteria.getCategory().getValue();
        categoryName=categoryName.replace("(Agilent)", "");
        String categoryId = getCategoryID(categoryName, catalogId);

        StringBuilder filterCondition = new StringBuilder();
        StringBuilder filterConditionWithOutExclude = new StringBuilder();
        int count = 0;
        int count1 = 0;
        Object[] params = new Object[10];
        Object[] params1 = new Object[10];
        for ( FieldAndSelectionDTO records : fieldAndSelectionList.getFieldAndSelectionDTO()) {
            if (records.getFieldName().getValue() != null && !records.getFieldSelection().getValue().equals("All")) {
                if (count < fieldAndSelectionList.getFieldAndSelectionDTO().size() && count > 0) {
                    filterCondition.append(" AND ");
                }
                filterCondition.append(getFieldName(records.getFieldName()) + " = ?" + count);
                params[count] = records.getFieldSelection().getValue();
                if (!records.getFieldName().getValue().equals(pExcludedFilterName)) {
                    if (count1 < fieldAndSelectionList.getFieldAndSelectionDTO().size() && count1 > 0) {
                        filterCondition.append(" AND ");
                    }
                    filterConditionWithOutExclude.append(getFieldName(records.getFieldName()) + " = ?" + count1);
                    params1[count1] = records.getFieldSelection().getValue();
                    count1++;
                }
                count++;
            }
        }
        String rql = " AND catalogs INCLUDES \"" + catalogId + "\"" + " AND parentCategories INCLUDES \"" + categoryId + "\"";
        filterCondition.append(rql);
        if (!filterConditionWithOutExclude.toString().equals("")) {
            filterConditionWithOutExclude.append(rql);
        } else {
            filterConditionWithOutExclude.append("catalogs INCLUDES \"" + catalogId + "\"" + " AND parentCategories INCLUDES \"" + categoryId + "\"");
        }
        
        vlogDebug("RQL filterCondition {0}", filterCondition.toString());
        vlogDebug("RQL filterConditionWithOutExclude {0}",filterConditionWithOutExclude.toString());
        RepositoryItem[] productList = getCatalogTools().getProductsByRQL(filterCondition.toString(), params);
        RepositoryItem[] productExcludeList = getCatalogTools().getProductsByRQL(filterConditionWithOutExclude.toString(), params1);

        ArrayOfFieldAndItemsCollectionDTO aList = new ArrayOfFieldAndItemsCollectionDTO();

        for ( FieldAndSelectionDTO records : fieldAndSelectionList.getFieldAndSelectionDTO()) {
            FieldAndItemsCollectionDTO fieldAndItemsCollection = new FieldAndItemsCollectionDTO();
            ArrayOfstring aos = new ArrayOfstring();
            String fieldName = getFieldName(records.getFieldName());
            if (!records.getFieldName().getValue().equals(pExcludedFilterName)) {
                // list for non ExcludedFilter
                fieldAndItemsCollection.setFieldName(records.getFieldName());
                for ( RepositoryItem product : productList) {
                    String value = (String) product.getPropertyValue(fieldName);
                    if (value != null && !aos.getString().contains(value))
                        aos.getString().add(value);
                }

            } else {
                // list for Excluded Filter
                fieldAndItemsCollection.setFieldName(records.getFieldName());
                for ( RepositoryItem product : productExcludeList) {
                    String value = (String) product.getPropertyValue(fieldName);
                    if (value != null && !aos.getString().contains(value))
                        aos.getString().add(value);
                }
            }
            Collections.sort(aos.getString());
            JAXBElement<ArrayOfstring> jFieldItemsList = new JAXBElement<ArrayOfstring>(new QName(
                    "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/Catalog", "fieldItemsList"), ArrayOfstring.class, aos);
            fieldAndItemsCollection.setFieldItemsList(jFieldItemsList);
            aList.getFieldAndItemsCollectionDTO().add(fieldAndItemsCollection);
        }
        return aList;

    }

    private String getFieldName( JAXBElement<String> fieldName) {
        if (fieldName.getValue().equals("FieldAValue")) {
            return "fieldA";
        } else if (fieldName.getValue().equals("FieldBValue")) {
            return "fieldB";
        } else if (fieldName.getValue().equals("FieldCValue")) {
            return "fieldC";
        } else if (fieldName.getValue().equals("FieldDValue")) {
            return "fieldD";
        } else if (fieldName.getValue().equals("FieldEValue")) {
            return "fieldE";
        }
        return null;
    }

    public String getCategoryID( String categoryName, String catalogName) {
        RepositoryItem category = getCatalogTools().getCategoryByName(categoryName, catalogName);
        if (category != null) {
            return category.getRepositoryId();
        }
        return null;
    }

    @SuppressWarnings({ "unused", "rawtypes", "unchecked" })
	public AgilentOrder updateOrder( String userId, BasketUpdateMessage request) {
    	vlogDebug("Inside updateOrder");
        AgilentOrder order = null;
        TransactionManager tm = getTransactionManager();
        TransactionDemarcation td = new TransactionDemarcation();
        boolean rollback = false;
        try {
            try {
                td.begin(tm, TransactionDemarcation.REQUIRED);

                for ( LineItem lineItem : request.getSearchCriteria().getLineItems().getValue().getLineItem()) {
                    // based on country code and sales org set catalog
                    lineItem.setLineItemState(LineItemState.NEW);
                    if (request.getSearchCriteria().getUser().getValue().getSelectedLocale().getValue() != null) {
                        lineItem.setCatalogLanguage(request.getSearchCriteria().getUser().getValue().getSelectedLocale());
                    } else {
                        JAXBElement<String> jLanguage = new JAXBElement<String>(new QName(
                                "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Datatypes/OrderManagement", "CatalogLanguage"), String.class, "en_US");
                        lineItem.setCatalogLanguage(jLanguage);
                    }
                }

                ArrayList a = (ArrayList) getOrderQueries().getOrderIdsForProfile(userId, 0, "lastModifiedDate", false);
                //getOrderIdsForProfile(String pProfileId, int 0, int -1, int pState, String pOrderByProperty, boolean pAscending);
                
                /*List<String> siteId= new ArrayList<String>();
                siteId.add(getCatalogSiteId());
                ArrayList profileOrders  =(ArrayList) getOrderQueries().getOrderIdsForProfile(userId, 0, -1, new int[0], "lastModifiedDate", false, siteId);
                */
                if(null != a && a.size()>0)
                {
                	for (Object orderId : a) {
                		order = (AgilentOrder) getOrderManager().loadOrder((String) orderId);
                		if(order!=null && !order.isExplicitlySaved()){
                			break;
                		}
					}
                }
                
                /*String orderId = (String) a.get(0);*/
                vlogDebug("orderId={0}",order.getId());
                if (getOrderManager() == null) {
                    OrderManager orderManagr = (OrderManager) Nucleus.getGlobalNucleus().resolveName("/atg/commerce/order/OrderManager");
                    setOrderManager(orderManagr);
                }

                //order = (AgilentOrder) getOrderManager().loadOrder(orderId);
                if (order == null) {
                    return order;
                }

                synchronized (order) {
                	vlogDebug("current Order Version= "+order.getVersion());
                	order.updateVersion();
                    String lineitemids = "";
                    for ( CommerceItem lineItem : (List<CommerceItem>) order.getCommerceItems()) {
                        lineitemids = lineitemids + lineItem.getCatalogRefId() + ",";
                    }
                    /*
                     * String shipGroupId = null; if (order.getShippingGroupCount() > 0) { ShippingGroup shipGroup = (ShippingGroup) order
                     * .getShippingGroups().get(0); shipGroupId = shipGroup.getId(); }
                     */
                    for ( LineItem lineItem : request.getSearchCriteria().getLineItems().getValue().getLineItem()) {
                        String partNumber = lineItem.getProductID();
                        partNumber=partNumber.replace("(Agilent)", "");
                        RepositoryItem skuItem = (RepositoryItem) getCatalogTools().getSkuFromCatalogId(partNumber.trim());// from
                        Set<String> siteIds= (Set<String>) skuItem.getPropertyValue("siteIds");
                        if (siteIds!=null && siteIds.size()>0 && siteIds.contains(getCatalogSiteId())){
	                        String productId = getCommerceItemManager().getProductIdFromSkuId(skuItem.getRepositoryId());
	                        Boolean activeProduct = (Boolean) skuItem.getPropertyValue("forSaleOnWeb");
	                       //check for replacement sku
	                        if (activeProduct == null || !activeProduct) {
                                Object replacementSku = skuItem.getPropertyValue("replacementPartNumber");
                                if (replacementSku != null) {
                                    if (replacementSku instanceof RepositoryItem) {
                                        skuItem = (RepositoryItem) replacementSku;
                                    } else {
                                        skuItem = getCatalogTools().getSkuFromCatalogId(((String) replacementSku).trim());
                                    }
                                }
                             }   
	                        if (activeProduct) {
	                        	 ShippingGroup shipGroup = (ShippingGroup) order.getShippingGroups().get(0);
	                            if (lineItem.getLineItemState().value().equals("New")) {
	                            	 vlogDebug("Inside add new Item= "+skuItem.getRepositoryId());
	                                long quantity = lineItem.getQuantity().longValue();
	                                String skuType=(String) skuItem.getPropertyValue("type");
	                                //check if sku already exist in the order 
	                                
	                                //
	                                
	                                //check for configurable sku	                                
	                                if (skuType!=null && skuType.equals("configurableSku")){
	                                	AgilentConfigurableCommerceItem newAgilentCommerceItem=(AgilentConfigurableCommerceItem) getCommerceItemManager().createCommerceItem("configurableCommerceItem", skuItem.getRepositoryId(), productId, quantity);
	                                	CommerceItemImpl item=(AgilentConfigurableCommerceItem) getCommerceItemManager().addItemToOrder(order, newAgilentCommerceItem);
	                                	if(item==null||item == newAgilentCommerceItem){
	                                		getCommerceItemManager().addItemQuantityToShippingGroup(order, newAgilentCommerceItem.getId(), shipGroup.getId(),newAgilentCommerceItem.getQuantity());
	                                	}else{
	                                		 getCommerceItemManager().addItemQuantityToShippingGroup(order, item.getId(), shipGroup.getId(),
	                                                 getCommerceItemManager().getShippingGroupManager().getRemainingQuantityForShippingGroup(item));
	                                	}
	                                	 
	                                }else {
	                                	AgilentCommerceItem newAgilentCommerceItem = (AgilentCommerceItem) getCommerceItemManager().createCommerceItem(skuItem.getRepositoryId(), productId, quantity);
	                                	CommerceItemImpl item=(AgilentCommerceItem) getCommerceItemManager().addItemToOrder(order, newAgilentCommerceItem);
	                                	if(item==null||item == newAgilentCommerceItem){
	                                		getCommerceItemManager().addItemQuantityToShippingGroup(order, newAgilentCommerceItem.getId(), shipGroup.getId(),newAgilentCommerceItem.getQuantity());
	                                	}else{
	                                		 getCommerceItemManager().addItemQuantityToShippingGroup(order, item.getId(), shipGroup.getId(),
	                                                 getCommerceItemManager().getShippingGroupManager().getRemainingQuantityForShippingGroup(item));
	                                	}
	                                }
	                               
	                            } else if (lineItem.getLineItemState().value().equals("Deleted")) {
	                            	 vlogDebug("Inside delete  Item= "+skuItem.getRepositoryId());
	                                if (lineitemids.contains(skuItem.getRepositoryId())) {
	                                    List<CommerceItem> ci = order.getCommerceItemsByCatalogRefId(skuItem.getRepositoryId());
	                                    getCommerceItemManager().removeItemFromOrder(order, ci.get(0).getId());
	                                }
	                            } else if (lineItem.getLineItemState().value().equals("Updated")) {
	                            	vlogDebug("Inside update  Item= "+skuItem.getRepositoryId());
	                                List<CommerceItem> ci = order.getCommerceItemsByCatalogRefId(skuItem.getRepositoryId());
	                                ci.get(0).setQuantity(lineItem.getQuantity().longValue());
	                            }
	                        }
                    	}
                    }

                    String countryCode = request.getSearchCriteria().getUser().getValue().getMossAttributes().getValue().getCountryCode().getValue();
                    if (getCountryUtils() == null) {
                        CountryUtils countryUtils = (CountryUtils) Nucleus.getGlobalNucleus().resolveName("/com/agilent/platform/CountryUtils");
                        setCountryUtils(countryUtils);
                    }

                    boolean emeaCountryUser = false;
                    emeaCountryUser = getCountryUtils().getEmeaCountryList().contains(countryCode);

                    int countGenomicsProduct = 0;
                    int countLSCAProduct = 0;
                    for ( CommerceItem lineItem : (List<CommerceItem>) order.getCommerceItems()) {
                        RepositoryItem skuItem = (RepositoryItem) getCatalogTools().findSKU(lineItem.getCatalogRefId());
                        String productLine = (String) skuItem.getPropertyValue("productLine");
                        if (productLine != null) {
                            if (productLine.equals("SR") || productLine.equals("GE") || productLine.equals("CB")
                                    || ((emeaCountryUser) && ((productLine.equals("V1")) || productLine.equals("29")))) {
                                countGenomicsProduct++;
                            } else {
                                countLSCAProduct++;
                            }
                        } else {
                            countLSCAProduct++;
                        }
                    }

                    if (countGenomicsProduct > 0 && countLSCAProduct > 0) {
                        order.setCartType("Mixed");
                    } else if (countGenomicsProduct > 0 && countLSCAProduct == 0) {
                        order.setCartType("Genomics");
                    } else {
                        order.setCartType("LSCA");
                    }

                    getOrderManager().updateOrder(order);
                    order.updateVersion();
                    vlogDebug("After Update Order Version= "+order.getVersion());
                }

            } catch (CommerceException e) {
                // TODO Auto-generated catch block
                rollback = true;
                vlogError(e, "");
            } catch (RepositoryException e) {
                // TODO Auto-generated catch block
                rollback = true;
                vlogError(e, "");
            } catch (Exception e) {
                // TODO Auto-generated catch block
                rollback = true;
                vlogError(e, "");
            } finally {
                td.end(rollback);
            }
        } catch (TransactionDemarcationException e) {
            vlogError(e, "");
        }
        vlogDebug("order Count = "+order.getCommerceItemCount());
        return order;
    }

    public ProductServiceCategory getCategory( ProductsSearchCriteria search) {
    	vlogDebug("Inside getCategory");
        String categoryName = search.getCategory().getValue();// "Columns";//
        RepositoryItem catalogItem = null;
        String catalogId = null;

        catalogItem = getCatalogTools().getCatalogItemBySiteId(getCatalogSiteId());
        if (catalogItem != null) {
            catalogId = catalogItem.getRepositoryId();
        }
        
        categoryName=categoryName.replace("(Agilent)", "");
        
        vlogDebug("Inside getCategory method :  categoryName after (Agilent ) : " + categoryName);
        
        RepositoryItem category = getCatalogTools().getCategoryByName(categoryName, catalogId);
        
        
        if (category == null) {
            vlogDebug("category is Null so calling loop statement in getCategory() method");
            int count=getLoopLimit();
            for(int i=1; i<=count;i++){
                   category = getCatalogTools().getCategoryByName(categoryName, catalogId);
                   if(category !=null)
                   {
                         vlogDebug("Number of Attempt taken : {0} in getCategory() method ",i);
                         i=count;
                   }
                   else
                   {
                         vlogDebug("Category coming empty in attempt: {0} in getCategory() method ",i);
                         
                   }
                   
            }
            
            
            if(category == null){
                   vlogDebug("category is Null after loop statement  in getCategory() method");
                   return null;
            }
             
      }
      else
      {
             vlogDebug("without Retry Attempt category result came in getCategory() method");
         
      }
           
        
        ProductServiceCategory categoryDetails = new ProductServiceCategory();
        try{
		        if (category != null) {
		        	
		        	//DCCOM-212 add translation for Locally Competitive
		        	String language = search.getLanguage().getValue();
		        	RepositoryItem categoryTrnanslation = category;
		        	Map<String, RepositoryItem> categoryTranslationMap = (Map<String, RepositoryItem>) category.getPropertyValue("translations");		        	
	                if(categoryTranslationMap != null && categoryTranslationMap.get(language) != null){
	                	categoryTrnanslation = categoryTranslationMap.get(language);
	                };
	                
	                String fieldADisplayNameTranslation = (String) categoryTrnanslation.getPropertyValue("fieldADisplayName");
	                String fieldBDisplayNameTranslation = (String) categoryTrnanslation.getPropertyValue("fieldBDisplayName");
	                String fieldCDisplayNameTranslation = (String) categoryTrnanslation.getPropertyValue("fieldCDisplayName");
	                String fieldDDisplayNameTranslation = (String) categoryTrnanslation.getPropertyValue("fieldDDisplayName");
	                String fieldEDisplayNameTranslation = (String) categoryTrnanslation.getPropertyValue("fieldEDisplayName");
	                String displayNameTranslation = (String) categoryTrnanslation.getPropertyValue("displayName");
	                
		            categoryDetails.setCategoryID(getJAXBElement((String) category.getPropertyValue("id"), "CategoryID"));
		            categoryDetails.setCategoryName(getJAXBElement(displayNameTranslation == null ? (String) category.getPropertyValue("displayName") : displayNameTranslation, "CategoryName"));
		            categoryDetails.setDisplayFieldA(getJAXBElement(fieldADisplayNameTranslation == null ? (String) category.getPropertyValue("fieldADisplayName") : fieldADisplayNameTranslation, "DisplayFieldA"));
		            categoryDetails.setDisplayFieldB(getJAXBElement(fieldBDisplayNameTranslation == null ? (String) category.getPropertyValue("fieldBDisplayName") : fieldBDisplayNameTranslation, "DisplayFieldB"));
		            categoryDetails.setDisplayFieldC(getJAXBElement(fieldCDisplayNameTranslation == null ? (String) category.getPropertyValue("fieldCDisplayName") : fieldCDisplayNameTranslation, "DisplayFieldC"));
		            categoryDetails.setDisplayFieldD(getJAXBElement(fieldDDisplayNameTranslation == null ? (String) category.getPropertyValue("fieldDDisplayName") : fieldDDisplayNameTranslation, "DisplayFieldD"));
		            categoryDetails.setDisplayFieldE(getJAXBElement(fieldEDisplayNameTranslation == null ? (String) category.getPropertyValue("fieldEDisplayName") : fieldEDisplayNameTranslation, "DisplayFieldE"));
		            
		            StringBuffer tableFields = new StringBuffer();
		            if(category.getPropertyValue("fieldADisplayName") !=null){
		            	tableFields.append("Field A");tableFields.append(", "); }
		        	if(category.getPropertyValue("fieldBDisplayName") !=null){
		        		tableFields.append("Field B");tableFields.append(", "); }
		        	if(category.getPropertyValue("fieldCDisplayName") !=null){
		        		tableFields.append("Field C");tableFields.append(", "); }
		        	if(category.getPropertyValue("fieldDDisplayName") !=null){
		        		tableFields.append("Field D");tableFields.append(", "); }
		        	if(category.getPropertyValue("fieldEDisplayName") !=null){
		        		tableFields.append("Field E");tableFields.append(", "); }
		        	if(tableFields.length()>0){
		        		tableFields=tableFields.delete(tableFields.length()-2,tableFields.length()-1);
		        	}
		        	categoryDetails.setTableFields(getJAXBElement(tableFields.toString(),"TableFields"));
		        	
		        	categoryDetails.setSortOnAttribute(getJAXBElement("Yes", "SortOnAttribute"));
		            categoryDetails.setCompareOnAttribute(false);
		            categoryDetails.setCompareADisplayName(getJAXBElement("", "CompareADisplayName"));
		            categoryDetails.setCompareBDisplayName(getJAXBElement("", "CompareBDisplayName"));
		            categoryDetails.setCompareCDisplayName(getJAXBElement("", "CompareCDisplayName"));
		            categoryDetails.setCompareDDisplayName(getJAXBElement("", "CompareDDisplayName"));
		            categoryDetails.setCompareEDisplayName(getJAXBElement("", "CompareEDisplayName"));
		        }
		        else{
		        vlogDebug(" category  objec is either null or empty:");
		        }
        }
        catch(Exception e){
        	vlogError(" Error Message : ...." + e);
        }
        return categoryDetails;
    }

	public JAXBElement<ArrayOfProductServiceProduct> getProductsForRelatedProductsTab(JAXBElement<ProductsSearchCriteria> pSearchCriteria) {
		vlogDebug("Inside getProductsForRelatedProductsTab()");
		String catalogId = null;
        RepositoryItem catalogItem = getCatalogTools().getCatalogItemBySiteId(getCatalogSiteId());
        if (catalogItem != null) {
            catalogId = catalogItem.getRepositoryId();
        }
        String language=pSearchCriteria.getValue().getLanguage().getValue();
        String salesOrg=pSearchCriteria.getValue().getSalesOrg().getValue();
        List<RepositoryItem> products = getProductsFromProductIdList(catalogId, pSearchCriteria.getValue().getProductIdList().getValue(), language);
        ArrayOfProductServiceProduct aProduct=mapProductsForBuyTab(products,language,salesOrg);
        JAXBElement<ArrayOfProductServiceProduct> jProduct = new JAXBElement<ArrayOfProductServiceProduct>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","Products"), ArrayOfProductServiceProduct.class, aProduct);
		return jProduct;
	}

	@SuppressWarnings("unchecked")
	private  List<RepositoryItem> getProductsFromProductIdList(String pCatalogId, String pProductIdList, String pLanguage) {
		vlogDebug("getProductsFromProductIdList(): pProductIdList={0}",pProductIdList);
		List<RepositoryItem> products = new ArrayList<RepositoryItem>();
        if (pProductIdList.contains(","))
        {
        	pProductIdList = pProductIdList.substring(0, pProductIdList.length() - 1);
        }
         String[] productIds = pProductIdList.split(",");
         for (String productId : productIds) {
        	 //check to remove (Agilent) from part no.
        	 if(productId.contains("(Agilent)")){
        		 productId=productId.replace("(Agilent)", "");
        	 }
        	 RepositoryItem product = getCatalogTools().getProductFromCatalogId(productId);
			if (product!=null )
			{
				 List<RepositoryItem> skus = (List<RepositoryItem>) product.getPropertyValue("childSKUs");
			        if (skus != null && skus.size() > 0) {
			            Boolean activeSku = (Boolean) skus.get(0).getPropertyValue("forSaleOnWeb");
			            if (activeSku != null && activeSku) {
			            	products.add(product);
			            	vlogDebug("Product Added :productId={0}", productId);
			            }
			        }
			}
		}
		return products;
	}
	
	@SuppressWarnings("unchecked")
	private ArrayOfProductServiceProduct mapProductsForBuyTab(List<RepositoryItem> pProducts,String pLanguage, String pSalesOrg) {
		ArrayOfProductServiceProduct aProduct=new ArrayOfProductServiceProduct();
		 
		RepositoryItem priceList=getCatalogTools().getPriceListItem(pSalesOrg,getCatalogSiteId());
     	Map<String, RepositoryItem> productPrice=getPricingTools().priceAllProducts(priceList, pProducts);
     	 if(productPrice!=null){    
		 for ( RepositoryItem product : pProducts) {
             ProductServiceProduct productBean = new ProductServiceProduct();
             List<RepositoryItem> skus = (List<RepositoryItem>) product.getPropertyValue("childSKUs");
             RepositoryItem prdTrnanslate=null;
             Map<String, RepositoryItem> prdtranslationMap = (Map<String, RepositoryItem>) product.getPropertyValue("translations");
             if(prdtranslationMap != null){
	                prdTrnanslate = prdtranslationMap.get(pLanguage);
	                if (prdTrnanslate == null) {
	                	prdTrnanslate = product;
	                }
             }else
             	prdTrnanslate = product;
             
             if (skus != null && skus.size() > 0) {
                 RepositoryItem sku = skus.get(0);
				Map<String, RepositoryItem> translationMap = (Map<String, RepositoryItem>) sku.getPropertyValue("translations");
                 RepositoryItem skuTrnanslate = translationMap.get(pLanguage);
                 if (skuTrnanslate == null) {
                     skuTrnanslate = sku;
                 }
                 
				 productBean.setDescription(getJAXBElement((String) prdTrnanslate.getPropertyValue("description"), "Description"));
				 productBean.setDisplayName(getJAXBElement((String) skuTrnanslate.getPropertyValue("displayName"), "DisplayName"));
				 productBean.setFieldA(getJAXBElement((String) product.getPropertyValue("fieldA"), "FieldA"));
				 productBean.setFieldB(getJAXBElement((String) product.getPropertyValue("fieldB"), "FieldB"));
				 productBean.setFieldC(getJAXBElement((String) product.getPropertyValue("fieldC"), "FieldC"));
				 productBean.setFieldD(getJAXBElement((String) product.getPropertyValue("fieldD"), "FieldD"));
				 productBean.setFieldE(getJAXBElement((String) product.getPropertyValue("fieldE"), "FieldE"));
				 productBean.setImageFileName(getJAXBElement((String) sku.getPropertyValue("productImageURL"), "ImageFileName"));
				 productBean.setLongDescription(getJAXBElement((String) prdTrnanslate.getPropertyValue("longDescription"), "LongDescription"));
				 productBean.setProductID(getJAXBElement((String) sku.getPropertyValue("catalogId"), "ProductID"));
				 productBean.setProductLine(getJAXBElement((String) sku.getPropertyValue("productLine"), "ProductLine"));
				 productBean.setAmount(getJAXBElement((String) sku.getPropertyValue("catalogAmount"), "Amount"));
                 productBean.setUnit(getJAXBElement((String) skuTrnanslate.getPropertyValue("unit"), "Unit"));
                 productBean.setCurrency(getJAXBElement(getCountryUtils().getSalesOrgCurrencyCodeMap().get(pSalesOrg), "Currency"));
             
             	RepositoryItem repositoryItem = productPrice.get(sku.getRepositoryId());
             	 Double propertyPriceValue =0.0;
             	if(repositoryItem!=null){
             		propertyPriceValue=(Double) repositoryItem.getPropertyValue("listPrice");
             	}
                 productBean.setListPrice(BigDecimal.valueOf(propertyPriceValue));
                if(propertyPriceValue!=0.0){
					aProduct.getProductServiceProduct().add(productBean);
                }
             }
		 	}
     	 }
		return aProduct; 
	}

	public int getLoopLimit() {
		return loopLimit;
	}

	public void setLoopLimit(int loopLimit) {
		this.loopLimit = loopLimit;
	}

	
	
}