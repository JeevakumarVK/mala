/**
 * 
 */
package com.agilent.utilities;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;

import atg.repository.RepositoryItem;
import atg.servlet.DynamoHttpServletRequest;
import atg.servlet.DynamoHttpServletResponse;
import atg.servlet.DynamoServlet;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;

/**
 * @author arjita.a
 *
 */
public class TestRQLDroplet extends DynamoServlet{

	private int count;
	private AgilentCatalogTools catalogTools; 
	private String mCategoryName;
	private String mCatalogName;
	private ProductCatalogSearch mProductCatalogSearch;
	
	

	@Override
	public void service(DynamoHttpServletRequest pRequest,
			DynamoHttpServletResponse pResponse) throws ServletException,
			IOException {
		System.out.println("value is,....");
		int count = getCount();
		System.out.println("value is,...."+count);
		vlogDebug(".......................... Entered service method ......................");
		String categoryName=getCategoryName();
		String catalogName=getCatalogName();
		vlogDebug("categoryName "+categoryName+"catalogName"+catalogName);
		String searchClause=""; 
		String language="en_US";
		List<RepositoryItem> category = null;
		vlogDebug("category "+category);
		for(int i=0; i<count;i++){
    		category = getProductCatalogSearch().getProductsForCategory(catalogName, categoryName, searchClause, language);
    	}
		pRequest.setParameter("categoryItem", category);
		pRequest.serviceLocalParameter("output", pRequest, pResponse);
}
	
	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	public AgilentCatalogTools getCatalogTools() {
        return catalogTools;
    }

    public void setCatalogTools( AgilentCatalogTools catalogTools) {
        this.catalogTools = catalogTools;
    }

	/**
	 * @return the mCategoryName
	 */
	public String getCategoryName() {
		return mCategoryName;
	}

	/**
	 * @param mCategoryName the mCategoryName to set
	 */
	public void setCategoryName(String mCategoryName) {
		this.mCategoryName = mCategoryName;
	}

	/**
	 * @return the mCatalogName
	 */
	public String getCatalogName() {
		return mCatalogName;
	}

	/**
	 * @param mCatalogName the mCatalogName to set
	 */
	public void setCatalogName(String mCatalogName) {
		this.mCatalogName = mCatalogName;
	}

	/**
	 * @return the mProductCatalogSearch
	 */
	public ProductCatalogSearch getProductCatalogSearch() {
		return mProductCatalogSearch;
	}

	/**
	 * @param mProductCatalogSearch the mProductCatalogSearch to set
	 */
	public void setProductCatalogSearch(ProductCatalogSearch mProductCatalogSearch) {
		this.mProductCatalogSearch = mProductCatalogSearch;
	}

	
}
