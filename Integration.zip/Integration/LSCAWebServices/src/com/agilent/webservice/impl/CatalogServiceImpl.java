/*
 * <Agilent Copyright> Copyright (C) 2012 Agilent All Rights Reserved. No use, copying or distribution of this work may be made except in accordance with a
 * valid license agreement from Agilent. This notice must be included on all copies, modifications and derivatives of this work. AGILENT MAKES NO
 * REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT. AGILENT SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
 * USING, MODIFYING OR DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES. </Agilent Copyright>
 */

package com.agilent.webservice.impl;

import java.util.logging.Logger;

import javax.jws.WebService;
import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;

import org.tempuri.CatalogService;
import org.tempuri.CatalogServiceGetAllFieldAndItemsCollectionProductNotFoundFaultMessageFaultFaultMessage;
import org.tempuri.CatalogServiceGetProductProductNotFoundFaultMessageFaultFaultMessage;
import org.tempuri.CatalogServiceGetProductsForBuyTabProductNotFoundFaultMessageFaultFaultMessage;
import org.tempuri.CatalogServiceGetProductsForRelatedProductTabProductNotFoundFaultMessageFaultFaultMessage;
import org.tempuri.CatalogServiceGetSpecificFieldAndItemsCollectionProductNotFoundFaultMessageFaultFaultMessage;

import atg.nucleus.Nucleus;
import atg.repository.RepositoryException;
import atg.repository.RepositoryItem;

import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ArrayOfFieldAndItemsCollectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ArrayOfProductServiceProduct;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.FieldAndItemsCollectionDTO;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductServiceCategory;
import com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductsSearchCriteria;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.CategoryCollectionMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.EcatalogMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.FieldAndItemsCollectionMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.FieldAndSelectionMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.GuidedNavOptionsMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductsCategoryCollectionMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.StoreSearchMessage;
import com.agilent.utilities.ProductCatalogSearch;

/**
 * <p>
 * MISSING COMMENTS FOR CLASS CatalogServiceImpl
 * </p>
 * 
 * @author Chitresh.Dayal
 * @project IntegrationLSCA
 * @updated DateTime: Sep 12, 2013 3:28:39 PM Author: Chitresh.Dayal
 */


@WebService( name = "CatalogService", portName = "CustomBinding_CatalogService" ,serviceName="CatalogService" , targetNamespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/Catalog", endpointInterface = "org.tempuri.CatalogService")

public class CatalogServiceImpl implements CatalogService {

    private final static Logger logger = Logger.getLogger(com.agilent.webservice.impl.CatalogServiceImpl.class.getName());

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProduct(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductMessage)
     */
    @Override
    public ProductMessage getProduct( ProductMessage pRequest) throws CatalogServiceGetProductProductNotFoundFaultMessageFaultFaultMessage {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProducts(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProducts( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getRootCategories(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.CategoryCollectionMessage)
     */
    @Override
    public CategoryCollectionMessage getRootCategories( CategoryCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsForCategory(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProductsForCategory( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductiDSForCategoryList(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProductiDSForCategoryList( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsFromProductIdList(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProductsFromProductIdList( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsForPDSPricing(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProductsForPDSPricing( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsForEcatalog(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.EcatalogMessage)
     */
    @Override
    public ProductCollectionMessage getProductsForEcatalog( EcatalogMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsForCategoryRecursive(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getProductsForCategoryRecursive( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#buildEcatalog(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.EcatalogMessage)
     */
    @Override
    public void buildEcatalog( EcatalogMessage pRequest) {
        //
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getRelatedProducts(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductCollectionMessage)
     */
    @Override
    public ProductCollectionMessage getRelatedProducts( ProductCollectionMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getGuidedNavOptions(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.GuidedNavOptionsMessage)
     */
    @Override
    public GuidedNavOptionsMessage getGuidedNavOptions( GuidedNavOptionsMessage pRequest) {
        return null;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#executeStoreSearch(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.StoreSearchMessage)
     */
    @Override
    public StoreSearchMessage executeStoreSearch( StoreSearchMessage pRequest) {
        return null;
    }
    
    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getProductsForBuyTab(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductsCategoryCollectionMessage)
     */
    @Override
   
    public ProductsCategoryCollectionMessage getProductsForBuyTab( ProductsCategoryCollectionMessage pSearchCriteria)
            throws CatalogServiceGetProductsForBuyTabProductNotFoundFaultMessageFaultFaultMessage {
    	ProductCatalogSearch productCatalogSearch = (ProductCatalogSearch) Nucleus.getGlobalNucleus().resolveName("/com/agilent/utilities/ProductCatalogSearch");
        ProductsCategoryCollectionMessage resultList =  new ProductsCategoryCollectionMessage();
        
    	/*populate products vo*/
    	ArrayOfProductServiceProduct  aProduct=productCatalogSearch.getProducts(pSearchCriteria.getSearchCriteria().getValue());
    	JAXBElement<ArrayOfProductServiceProduct> jProduct = new JAXBElement<ArrayOfProductServiceProduct>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","Products"), ArrayOfProductServiceProduct.class, aProduct);
    	resultList.setProducts(jProduct);
    	
    	/*populate category vo*/
    	ProductServiceCategory categoryBean=productCatalogSearch.getCategory(pSearchCriteria.getSearchCriteria().getValue());
        JAXBElement<ProductServiceCategory> jpsc = new JAXBElement<ProductServiceCategory>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","Category"),ProductServiceCategory.class ,categoryBean);
        resultList.setCategory(jpsc);
        
        /*populate search vo*/
        JAXBElement<ProductsSearchCriteria> spsc = new JAXBElement<ProductsSearchCriteria>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","SearchCriteria"),ProductsSearchCriteria.class ,pSearchCriteria.getSearchCriteria().getValue());
        resultList.setSearchCriteria(spsc);
        
        return resultList;
    }

    /*
     * (non-Javadoc)
     * @see org.tempuri.CatalogService#getAllFieldAndItemsCollection(com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductsSearchCriteria,
     * com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.FieldAndSelectionMessage)
     */
    @Override
    public FieldAndItemsCollectionMessage getAllFieldAndItemsCollection( ProductsSearchCriteria pSearchCriteria,
            FieldAndSelectionMessage pFieldAndSelectionMessage) throws CatalogServiceGetAllFieldAndItemsCollectionProductNotFoundFaultMessageFaultFaultMessage {
    	ProductCatalogSearch productCatalogSearch = (ProductCatalogSearch) Nucleus.getGlobalNucleus().resolveName("/com/agilent/utilities/ProductCatalogSearch");
    	FieldAndItemsCollectionMessage fieldAndItemsCollectionMessage= new FieldAndItemsCollectionMessage();
    	
    	ArrayOfProductServiceProduct  aProduct=productCatalogSearch.getProducts(pSearchCriteria);
    	ArrayOfFieldAndItemsCollectionDTO fieldAndItemsCollection=productCatalogSearch.getAllFieldAndItemsCollection(aProduct,pFieldAndSelectionMessage.getListFieldAndSelection().getValue().getFieldAndSelectionDTO());
    	JAXBElement<ArrayOfFieldAndItemsCollectionDTO> jFieldAndItemsCollection = new JAXBElement<ArrayOfFieldAndItemsCollectionDTO>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","listFieldAndItemsCollection"),ArrayOfFieldAndItemsCollectionDTO.class ,fieldAndItemsCollection);
    	fieldAndItemsCollectionMessage.setListFieldAndItemsCollection(jFieldAndItemsCollection);
    	
        return fieldAndItemsCollectionMessage;
    }


	/*
     * (non-Javadoc)
     * @see
     * org.tempuri.CatalogService#getSpecificFieldAndItemsCollection(com.agilent.chem.ecommerce._2008._02.contracts.datatypes.catalog.ProductsSearchCriteria,
     * com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.FieldAndSelectionMessage, java.lang.String)
     */
    @Override
    public FieldAndItemsCollectionMessage getSpecificFieldAndItemsCollection( ProductsSearchCriteria pSearchCriteria,
            FieldAndSelectionMessage pFieldAndSelectionMessage, String pExcludedFilterName)
            throws CatalogServiceGetSpecificFieldAndItemsCollectionProductNotFoundFaultMessageFaultFaultMessage {
    	ProductCatalogSearch productCatalogSearch = (ProductCatalogSearch) Nucleus.getGlobalNucleus().resolveName("/com/agilent/utilities/ProductCatalogSearch");
    	FieldAndItemsCollectionMessage fieldAndItemsCollectionMessage = new FieldAndItemsCollectionMessage();
    	ArrayOfFieldAndItemsCollectionDTO fieldAndItemsCollectionDTO = new ArrayOfFieldAndItemsCollectionDTO();
    	
		try {
			fieldAndItemsCollectionDTO = productCatalogSearch.getSpecificFieldAndItemsCollection(pSearchCriteria, pFieldAndSelectionMessage.getListFieldAndSelection().getValue(), pExcludedFilterName);
		} catch (RepositoryException e) {
			e.printStackTrace();
		}
		JAXBElement<ArrayOfFieldAndItemsCollectionDTO> jfieldAndItemsCollectionDTO = new JAXBElement<ArrayOfFieldAndItemsCollectionDTO>(new QName("http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Messages/Catalog","listFieldAndItemsCollection"),ArrayOfFieldAndItemsCollectionDTO.class ,fieldAndItemsCollectionDTO);
		fieldAndItemsCollectionMessage.setListFieldAndItemsCollection(jfieldAndItemsCollectionDTO);
		
    	return fieldAndItemsCollectionMessage;
    }

    /*
     * (non-Javadoc)
     * @see
     * org.tempuri.CatalogService#getProductsForRelatedProductTab(com.agilent.chem.ecommerce._2008._02.contracts.messages.catalog.ProductsCategoryCollectionMessage
     * )
     */
    @Override
    public ProductsCategoryCollectionMessage getProductsForRelatedProductTab( ProductsCategoryCollectionMessage pRequest)
            throws CatalogServiceGetProductsForRelatedProductTabProductNotFoundFaultMessageFaultFaultMessage {
    	ProductsCategoryCollectionMessage response= new ProductsCategoryCollectionMessage();
    	response.setSearchCriteria(pRequest.getSearchCriteria());
    	ProductCatalogSearch productCatalogSearch = (ProductCatalogSearch) Nucleus.getGlobalNucleus().resolveName("/com/agilent/utilities/ProductCatalogSearch");
    	response.setProducts(productCatalogSearch.getProductsForRelatedProductsTab(pRequest.getSearchCriteria()));
        return response;
    }
   
}



