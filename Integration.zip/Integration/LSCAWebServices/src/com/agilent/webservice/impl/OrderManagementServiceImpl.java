/**
 * 
 */
package com.agilent.webservice.impl;

import java.util.ArrayList;

import javax.jws.WebService;

import org.tempuri.OrderManagementService;

import atg.commerce.CommerceException;
import atg.commerce.order.Order;
import atg.commerce.order.OrderQueries;
import atg.nucleus.Nucleus;
import atg.repository.RepositoryItem;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.order.AgilentOrder;
import com.agilent.base.profile.AgilentProfileTools;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketCopyMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.POMessage;
import com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.WebOrderMessage;
import com.agilent.utilities.ProductCatalogSearch;

/**
 * @author Ankitk.S
 *
 */

@WebService( name = "OrderManagementService", portName = "CustomBinding_OrderManagementService", serviceName="OrderManagementService", targetNamespace = "http://www.chem.agilent.com/ECommerce/2008/02/Contracts/Services/Catalog", endpointInterface = "org.tempuri.OrderManagementService")


public class OrderManagementServiceImpl implements OrderManagementService {

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#createBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage)
	 */
	@Override
	public BasketMessage createBasket(BasketMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#getBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage)
	 */
	@Override
	public BasketMessage getBasket(BasketMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#getBasketsForUser(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketMessage)
	 */
	@Override
	public BasketMessage getBasketsForUser(BasketMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#updateBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage updateBasket(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#saveBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage saveBasket(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#emptyBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage emptyBasket(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#deleteBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public void deleteBasket(BasketUpdateMessage request) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#addAddresses(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage addAddresses(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#addShippingOptions(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage addShippingOptions(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#addCreditCard(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage addCreditCard(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#calculateTotal(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public BasketMessage calculateTotal(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#checkout(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public POMessage checkout(BasketUpdateMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#copyBasketForApproval(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketCopyMessage)
	 */
	@Override
	public BasketMessage copyBasketForApproval(BasketCopyMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#getWebOrders(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.WebOrderMessage)
	 */
	@Override
	public WebOrderMessage getWebOrders(WebOrderMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#updateSapOrderNumber(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.WebOrderMessage)
	 */
	@Override
	public void updateSapOrderNumber(WebOrderMessage request) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#addItemsToCart(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.BasketUpdateMessage)
	 */
	@Override
	public Integer addItemsToCart(BasketUpdateMessage request) {
		int basketCount = 0;
		ProductCatalogSearch productCatalogSearch = (ProductCatalogSearch) Nucleus.getGlobalNucleus().resolveName("/com/agilent/utilities/ProductCatalogSearch");
		
		if (request.getSearchCriteria().getUser().getValue() != null){
			//AgilentCatalogTools aCatalogTools = (AgilentCatalogTools) Nucleus.getGlobalNucleus().resolveName("/atg/commerce/catalog/CatalogTools");
			AgilentProfileTools profileTools=(AgilentProfileTools) Nucleus.getGlobalNucleus().resolveName("/atg/userprofiling/ProfileTools");
			String loginName=request.getSearchCriteria().getUser().getValue().getLoginName().getValue();
			RepositoryItem user=profileTools.getItemFromDotNetId(loginName);
			if (user ==null){
				return basketCount;
			}
			String userId=user.getRepositoryId();
			request.getSearchCriteria().setUserID(userId);
			AgilentOrder order=productCatalogSearch.updateOrder(userId,request);
			basketCount=order.getCommerceItemCount();
		}
		return basketCount;
	}

	/* (non-Javadoc)
	 * @see org.tempuri.OrderManagementService#applyPromotionPunchoutBasket(com.agilent.chem.ecommerce._2008._02.contracts.messages.ordermanagement.POMessage)
	 */
	@Override
	public BasketMessage applyPromotionPunchoutBasket(POMessage request) {
		// TODO Auto-generated method stub
		return null;
	}

}
