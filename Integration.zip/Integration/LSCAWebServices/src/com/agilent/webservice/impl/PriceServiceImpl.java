
package com.agilent.webservice.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.jws.WebService;

import org.tempuri.PriceService;

import atg.nucleus.Nucleus;
import atg.nucleus.ServiceEvent;
import atg.nucleus.ServiceException;
import atg.nucleus.ServiceListener;
import atg.nucleus.logging.ApplicationLoggingImpl;
import atg.nucleus.logging.ApplicationLoggingSender;
import atg.nucleus.logging.LoggingPropertied;
import atg.repository.RepositoryItem;

import com.agilent.base.commerce.catalog.AgilentCatalogTools;
import com.agilent.base.commerce.services.AgilentPricingTools;
import com.agilent.base.common.services.SapManager;
import com.agilent.chem.ecommerce.pricing.PriceRequestVO;
import com.agilent.chem.ecommerce.pricing.PriceResponseVO;
import com.agilent.chem.ecommerce.pricing.PriceVO;

@WebService( name = "PriceService", portName = "CustomBinding_PriceService", serviceName = "PriceService", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing", endpointInterface = "org.tempuri.PriceService")
public class PriceServiceImpl implements PriceService, LoggingPropertied, ServiceListener {

    ApplicationLoggingImpl mLogging = new ApplicationLoggingImpl(this.getClass().getName());

    @Override
    public ApplicationLoggingSender getLogging() {
        return mLogging;
    }

    @Override
    public void startService( ServiceEvent pEvent) throws ServiceException {
        mLogging.initializeFromServiceEvent(pEvent);
    }

    @Override
    public void stopService() {
        getLogging().logDebug("--------Stop Component : PriceServiceImpl");
    }

    @Override
    public PriceResponseVO getPrice( PriceRequestVO pRequest) {
        // TODO Auto-generated method stub
        boolean isYourPrice = false;
        PriceResponseVO responseVo = null;
        if (pRequest == null) {
            return null;
        }

        isYourPrice = pRequest.isYourPrice();

        if (isYourPrice) {
            responseVo = getListPrice(pRequest);
        } else {
            responseVo = getYourPrice(pRequest);
        }

        return responseVo;
    }

    /**
     * Retuns List Price for part Numbers
     * 
     * @param pRequest
     * @return
     */
    public PriceResponseVO getListPrice( PriceRequestVO pRequest) {
        AgilentPricingTools priceTools = (AgilentPricingTools) Nucleus.getGlobalNucleus().resolveName("/atg/commerce/pricing/PricingTools");
        List<RepositoryItem> productItems = new ArrayList<RepositoryItem>();
        List<PriceVO> priceVos = new ArrayList<PriceVO>();
        PriceResponseVO resposeVO = null;
        String siteId = pRequest.getSiteId();
        String salesOrg = pRequest.getSalesOrg();
        List<String> partNumbers = pRequest.getPartNumbers();

        for ( String partNumber : partNumbers) {
            RepositoryItem product = ((AgilentCatalogTools) priceTools.getCatalogTools()).getProductFromCatalogId(partNumber, siteId);
            if (product != null) {
                productItems.add(product);
            }
        }

        RepositoryItem pList = ((AgilentCatalogTools) priceTools.getCatalogTools()).getPriceListItem(salesOrg, siteId);

        if (pList == null) {
            return resposeVO;
        }

        Map<String, RepositoryItem> priceMap = priceTools.priceAllProducts(pList, productItems);
        if (priceMap != null && priceMap.size() > 0) {
            for ( String key : priceMap.keySet()) {
                PriceVO priceResponse = new PriceVO();
                priceResponse.setPartNumber(key);
                RepositoryItem price = priceMap.get(key);
                double listPrice = (Double) price.getPropertyValue("listPrice");
                priceResponse.setListPrice(listPrice);
                priceVos.add(priceResponse);
            }

            resposeVO = new PriceResponseVO();
            resposeVO.setListResposeVo(priceVos);
        }

        return resposeVO;
    }

    /**
     * Returns Your Price for part numbers based on sap contact number
     * 
     * @param pRequest
     * @return
     */
    public PriceResponseVO getYourPrice( PriceRequestVO pRequest) {

        SapManager sapManager = (SapManager) Nucleus.getGlobalNucleus().resolveName("/com/agilent/commerce/sap/SapManager");
        List<PriceVO> priceVos = new ArrayList<PriceVO>();
        PriceResponseVO resposeVO = null;
        String siteId = pRequest.getSiteId();
        String salesOrg = pRequest.getSalesOrg();
        String sapContactNumber = pRequest.getSapContactNumber();
        List<String> partNumbers = pRequest.getPartNumbers();

        if (sapContactNumber == null) {
            return null;
        }

        Map<String, Double> priceMap = sapManager.getCustomerSpecificPricingForPartNumbers(sapContactNumber, salesOrg, partNumbers, siteId);
        if (priceMap != null && priceMap.size() > 0) {
            for ( String key : priceMap.keySet()) {
                PriceVO priceResponse = new PriceVO();
                priceResponse.setPartNumber(key);

                priceResponse.setListPrice(priceMap.get(key));
                priceVos.add(priceResponse);
            }

            if (priceVos.size() > 0) {
                resposeVO = new PriceResponseVO();
                resposeVO.setListResposeVo(priceVos);
            }
        }

        return resposeVO;
    }
}
