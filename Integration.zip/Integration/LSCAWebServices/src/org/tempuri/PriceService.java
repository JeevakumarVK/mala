/**
 * 
 */

package org.tempuri;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

import com.agilent.chem.ecommerce.pricing.PriceRequestVO;
import com.agilent.chem.ecommerce.pricing.PriceResponseVO;

/**
 * @author Ankitk.S
 * 
 */

@javax.jws.WebService( name = "PriceService", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing")
public interface PriceService {

    @WebMethod( operationName = "GetPrice", action = "http://www.chem.agilent.com/ECommerce/Pricing/PriceService/GetPrice")
    @WebResult( name = "GetPriceResult", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing")
    @RequestWrapper( localName = "GetPrice", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing", className = "com.agilent.chem.ecommerce.pricing.GetPrice")
    @ResponseWrapper( localName = "GetPriceResponse", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing", className = "com.agilent.chem.ecommerce.pricing.GetPriceResponse")
    public PriceResponseVO getPrice( @WebParam( name = "request", targetNamespace = "http://www.chem.agilent.com/ECommerce/Pricing") PriceRequestVO request);

}
