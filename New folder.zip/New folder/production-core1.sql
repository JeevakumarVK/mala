select count(country_code) , country_code from agilent_cntry_entitlement where country_code in ('AT','BR','CZ','SG','TW','US','CN','JP','DZ','BH','BE','BA','BG','IC','HR','CY','DK','EG','EE','FI',
'FR','DE','GR','HU','IS','IN','IE','IM','IL','IT','JE','JO','KE','KW','LV','LB','LT','LU','MK','ML','MT','MC','MA','NP','NL','NO','OM','PK','PL','PT','QA','RE','RO','RU','SA','RS','SK','SI',
'ZA','ES','LK','SE','CH','TR','UA','AE','GB')
group by country_code having order by country_code DESC;

select * from agilent_cntry_entitlement where country_code like '%US%' and incl_start_dt like '%11-JUN-22%' and incl_end_dt like '%21-NOV-22%';

select * from agilent_cntry_entitlement where country_code='9P';
where part_nbr='G110972B-8' and country_code='ZA';

select * from agilent_sku; 
select *from dcs_sku; 
select *from agilent_sku; 
select *from dcs_product;
select * from dcspp_order where state like '%US%' and creation_date like '%11-JUN-22%' and creation_date like '%21-NOV-22%';
where creation_date between '11-jun-22'and '21-nov-22';
select * from agilent_order;
Select * from DPS_USER where email like '%eng-lee_teh@agilent.com%';
Select * from AGILENT_USER_EXT;
where user_country like '%US%;

Part k2500311 

select ID,Login,Email,First_name,Last_name,Lastactivity_date from dpi_user
where id in(select user_id from dpi_user_roles) and lastactivity_date <= sysdate-80;




SELECT
a.user_id,a.ad_login_name,b.email,b.first_name,b.last_name,a.enable_commerce,a.ECOMM_STATUS,a.mem_type,a.SAP_CUSTOMER_ID,crm_contact_id,a.sapsalesorg,a.user_country,b.registration_date,a.sap_shipto_address,a.sap_billto_address
FROM
agilent_user_ext a,dps_user b
WHERE
a.user_id = b.id AND b.email in ('sye@rhinobio.co.kr');

SELECT * from agilent_user_ext WHERE user_id=(select id from dps_user where email='sye@rhinobio.co.kr');

select * from agilent_user_ext where sapsalesorg='04CN' and mem_type='10001' and ecomm_status='10002' and sap_customer_id is not null; 
select * from dps_user where id like '%243611235%';731130618@qq.com
select * from dps_user where id like '%243612562%';44395746@qq.com
select * from dps_user where id like '%243873829%';1356275090@qq.com
select * from dps_user where id like '%245305599%';Seeker_Jack@163.com
select * from dps_user where id like '%246558731%';zhongying.yang@bioduro.com

select * from agilent_user_ext where ad_login_name like '%@mailinator.com%' and 
sapsalesorg='04CN' and mem_type='10001' and ecomm_status='10002' and sap_customer_id is not null;04CN-DISTMAR31@mailinator.com,cn-dist13@mailinator.com,cn-mem30@mailinator.com,cn-test@mailinator.com,us-testapr10@mailinator.com

243612562,243873829,245305599,246558731;
where sapsalesorg='04CN' and mem_type='10001' and ecomm_status='10002';

where email ='2475726942@qq.com';

select * from dps_user where email ='449130313@qq.com';447374168
select * from agilent_user_ext where user_id like '%447374168%';2902316,0307531455,o288041869
select * from dcspp_order where order_id like '%o288041869%';
select * from agilent_order where sap_contact_number like '%2902316%';

select * from agilent_user_ext where sap_customer_id like '%2902316%';

SELECT
a.user_id,a.ad_login_name,b.email,b.first_name,b.last_name,a.enable_commerce,a.ECOMM_STATUS,a.mem_type,a.SAP_CUSTOMER_ID,crm_contact_id,a.sapsalesorg,a.user_country,b.registration_date,a.sap_shipto_address,a.sap_billto_address
FROM
agilent_user_ext a,dps_user b
WHERE
a.user_id = b.id AND b.email in ('cakbay@uncfsu.edu');

SELECT
a.user_id,a.ad_login_name,b.email,b.first_name,b.last_name,a.enable_commerce,a.ECOMM_STATUS,a.mem_type,a.SAP_CUSTOMER_ID,crm_contact_id,a.sapsalesorg,a.user_country,b.registration_date,a.sap_shipto_address,a.sap_billto_address
FROM
agilent_user_ext a,dps_user b
WHERE
a.user_id = b.id AND a.sap_customer_id in ('3279259');



select * from sent_email_report where order_id in ('w387485038');

select * from agilent_user_ext where sap_customer_id like '%3279259%';
where id like '%80600097%';
select * from dps_user email like '%id-dist15@mailinator.com%';
select * from dps_user where id like '%345755439%';345755439,345338888

select * from agilent_order where order_id like '%w387485038%';

select * from dcspp_order where order_id like '%w387485038%';
w387485038,,311527782,3279259,318355563


Insert INTO agilent_order () VALUES ('8P');

select * from dps_user where id='80600097';

select * from agilent_order where order_id like '%w386916242%';

select order_id, sap_order_id, order_type, sales_org, sap_delivery_block from agilent_order where sales_org='04CN' and sales_org '04C9';

select * from dcspp_order where order_id like '%w361822142%';

select * from agilent_order where sap_order_id like '%2902316%';

select * from agilent_order where order_id like '%w387485038%';
select * from agilent_order where sap_order_id like'%0311527782%';

select * from dps_user where email like '%Us-testjun21@mailinator.com%';389661961

select * from dps_user where first_name like '%Thierry%' and last_name like '%Leclerc%';

select * from agilent_order where sap_order_id like'%0311525847%';3308287,w361822142
select * from agilent_order;

select order_ref,product_id,quantity from dcspp_item where order_ref in ('w361822142');


where user_id like'%389661961%';
311527782

select * from sent_email_report where order_id in ('w387485038');

select * from agilent_user_ext;

select * from dps_user where email ='eburke@nexeosolutions.com';

select * from agilent_order where order_id in ('311454051');

select * from agilent_order where order_id like '%w386127905%';
select order_id, sap_order_id, order_type, sales_org, sap_delivery_block from agilent_order where sap_order_id like '%0311454051%';

select * from agilent_order where order_id like '%w386127905%' and QUOTE_ID is not null;

SELECT * FROM
    agilent_user_ext a,dps_user du
WHERE
    a.user_id = du.id;

0310873406
    
select * from agilent_order where order_id like '%310873406%';

    SELECT a.ad_login_name,a.user_country,ECOMM_STATUS,SALES_ORG,TYPE ECOMM_APPR_STATUS FROM
    agilent_user_ext a,dps_user du
WHERE
    a.user_id = du.id and 
a.ad_login_name not like '%Test%' and a.ad_login_name not like '%TEST%' and a.ad_login_name not like '%dist%' and a.ad_login_name not like '%DIST%' and a.ad_login_name not like '%Dist%'  
and a.ad_login_name not like '%Gomez%' and du.email not like '%Gomez%'  
    and a.enable_commerce='1'and a.user_country = 'US';
SELECT * FROM
    agilent_user_ext a,dps_user du
WHERE
    a.user_id = du.id;
    
    
select order_ref,product_id,quantity from dcspp_item where order_ref in ('w381986157');
select * from agilent_order where sap_order_id like '%0311296627%';w381986157,2902316

select * from agilent_order where order_id like '%w381986157%';

select * from dcspp_order where order_id = 'w381986157';

select * from dcspp_order where order_id like '%0311296627%';
