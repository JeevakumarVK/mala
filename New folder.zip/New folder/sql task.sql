CREATE DATABASE STUDENT;
SHOW databases;
USE STUDENT;
CREATE TABLE students_information(
std_id int not null,
course_id varchar(10) not null,
std_fname varchar(50),
std_lname varchar(50),
std_gender char(10),
std_dob date,
std_doj date,
primary key(std_id),
foreign key(course_id)references courses(course_id)
);
CREATE TABLE staff(
staff_id int not null,
course_id varchar(10) not null,
staff_fname varchar(50),
staff_lname varchar(50),
staff_gender char(10),
primary key(staff_id),
foreign key(course_id)references courses(course_id)
);
CREATE TABLE courses(
course_id varchar(10) not null,
course_name varchar(100),
primary key(course_id)
);
insert into courses(course_id,course_name)values('J001','JAVA'),('JS001','JavaScript'),('H001','HTML'),('C001','CSS'),('S001','SQL');
INSERT INTO students_information(std_id,course_id,std_fname,std_lname,std_gender,std_dob,std_doj)
values(101,'J001','West','John','male','2003-02-21','2020-02-07'),
(102,'J001','Uma','Sree','Female','2002-02-17','2021-02-09'),
(103,'S001','Kavya','N','Female','2005-02-01','2021-02-21'),
(104,'JS001','Kylie','Jenner','Female','2003-02-11','2018-02-28'),
(105,'JS001','Ram','Kumar','male','2001-02-20','2020-02-24');
INSERT INTO staff(staff_id,course_id,staff_fname,staff_lname,staff_gender)values(
2001,'J001','Llla','Rao','Female'),(2002,'JS001','jai','Reddy','male'),
(2003,'H001','Sai','Kumar','male'),
(2004,'S001','Varun','Gwoda','Female'),
(2005,'C001','Kim','West','male');
update students_information 
set std_doj='2022-02-09'
WHERE std_id in(102,103);
select * from students_information;
select * from staff;
select *from courses;
delete from staff
where staff_id=2003;
select * from staff;
truncate table students_information;
truncate table staff;
drop table students_information,staff,courses;
drop DATABASE STUDENT;
